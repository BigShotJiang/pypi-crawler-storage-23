[ Skip to main content ](https://learn.microsoft.com/en-us/training/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
Welcome to Microsoft Learn
# Discover your path
Whether you're just starting in a career, or you're an experienced professional, our self-directed approach helps you arrive at your goals faster, with more confidence and at your own pace. Develop skills through interactive modules and paths or learn from an instructor. Learn and grow your way.
Master core concepts at your speed and on your schedule. Whether you've got 15 minutes or an hour, you can develop practical skills through interactive modules and paths. You can also register to learn from an instructor. Learn and grow your way.
[Browse all paths](https://learn.microsoft.com/en-us/training/browse/) Customize my path
![](https://learn.microsoft.com/en-us/training/media/career-paths/administrator/Modern%20Desktop%20Administrator.png)
## Looking for specific training content?
Learn new skills and discover the power of Microsoft products with step-by-step guidance. Start your journey today by exploring our learning paths, modules, and courses.
[Browse training](https://learn.microsoft.com/en-us/training/browse/)
## Working towards a career goal?
There are over 700 K job listings seeking candidates with Microsoft technical skills. Explore training and credentials aligned with your career goals.
[Explore career paths](https://learn.microsoft.com/en-us/training/career-paths/)
![](https://learn.microsoft.com/en-us/training/media/career-paths/career-path-overview.png)
![](https://learn.microsoft.com/en-us/training/media/student-hub/student-hub-overview.png)
## Student resources
The home for students to explore how to jumpstart a career in technology and stay connected with the Microsoft student developer community. Learn new skills through interactive learning paths and modules and find out about skilling events and resources.
[Explore Student Hub](https://learn.microsoft.com/en-us/training/student-hub)
  * ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_learningpath_light.png) ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_learningpath_dark.png)
Learning Paths
Learn on your own schedule
Explore a topic in-depth through guided paths or learn how to accomplish a specific task through individual modules.
[Browse learning paths and modules](https://learn.microsoft.com/en-us/training/browse/)
  * ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_community_light.png) ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_community_dark.png)
Career Paths
Find your career path
Learn more about career paths that intrigue you, follow the guided training paths to help you get credentialed, and get connected to help reach your career goals.
[Explore career paths](https://learn.microsoft.com/en-us/training/career-paths/)
  * ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_virtualtraining_light.png) ![](https://learn.microsoft.com/en-us/training/media/topics/cards/icon-card_virtualtraining_dark.png)
Student Hub
Student Resources
Learn technical skills to prepare you for your future. Find training, virtual events, and opportunities to connect with the Microsoft student developer community.
[Explore Student Hub](https://learn.microsoft.com/en-us/training/student-hub/)


## Popular learning paths and modules
Edit your interests
  * Learning Path
[Introduction to Cloud Infrastructure: Describe cloud concepts](https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/) ![](https://learn.microsoft.com/en-us/training/achievements/microsoft-azure-fundamentals-describe-cloud-concepts.svg)
    * Azure
    * Administrator
    * Beginner
76%
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Introduction to generative AI and agents](https://learn.microsoft.com/en-us/training/modules/fundamentals-generative-ai/) ![](https://learn.microsoft.com/en-us/training/achievements/fundamentals-generative-ai.svg)
    * Azure
    * AI Engineer
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Introduction to machine learning concepts](https://learn.microsoft.com/en-us/training/modules/fundamentals-machine-learning/) ![](https://learn.microsoft.com/en-us/training/achievements/fundamentals-of-machine-learning.svg)
    * Azure
    * AI Engineer
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Get started with AI agent development on Azure](https://learn.microsoft.com/en-us/training/modules/ai-agent-fundamentals/) ![](https://learn.microsoft.com/en-us/learn/achievements/generic-badge.svg)
    * Azure
    * AI Engineer
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Implement a responsible generative AI solution in Microsoft Foundry](https://learn.microsoft.com/en-us/training/modules/responsible-ai-studio/) ![](https://learn.microsoft.com/en-us/learn/achievements/generic-badge.svg)
    * Azure
    * AI Engineer
    * Intermediate
Completed
Add
Add to Collections Add to plan Add to Challenges
  * Learning Path
[Introduction to Cloud Infrastructure: Describe Azure management and governance](https://learn.microsoft.com/en-us/training/paths/describe-azure-management-governance/) ![](https://learn.microsoft.com/en-us/training/achievements/describe-azure-management-governance.svg)
    * Azure
    * Administrator
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Discover data analysis](https://learn.microsoft.com/en-us/training/modules/data-analytics-microsoft/) ![](https://learn.microsoft.com/en-us/training/achievements/data-analytics-and-microsoft.svg)
    * Microsoft Power Platform
    * Data Analyst
    * Intermediate
Add
Add to Collections Add to plan Add to Challenges
  * Module
[Describe the core architectural components of Azure](https://learn.microsoft.com/en-us/training/modules/describe-core-architectural-components-of-azure/) ![](https://learn.microsoft.com/en-us/training/achievements/describe-core-architectural-components-of-azure.svg)
    * Azure
    * Administrator
    * Beginner
Add
Add to Collections Add to plan Add to Challenges
  * Module
[(AI-900) Get started with speech in Microsoft Foundry](https://learn.microsoft.com/en-us/training/modules/recognize-synthesize-speech/) ![](https://learn.microsoft.com/en-us/training/achievements/convert-speech-to-text.svg)
    * Azure
    * AI Engineer
    * Beginner
Add
Add to Collections Add to plan Add to Challenges


[ See what others are learning ](https://learn.microsoft.com/en-us/learn/browse/)
## Our current favorites
## New and recently updated
  * ![](https://learn.microsoft.com/en-us/training/achievements/get-started-power-bi.svg)
Module
[Get started building with Power BI](https://learn.microsoft.com/en-us/training/modules/get-started-with-power-bi/)
    * Beginner
    * Data Analyst
    * Power BI
Add
Add to Collections Add to plan Add to Challenges
  * ![](https://learn.microsoft.com/en-us/training/achievements/get-started-ai-fundamentals.svg)
Module
[Introduction to AI concepts](https://learn.microsoft.com/en-us/training/modules/get-started-ai-fundamentals/)
    * Beginner
    * AI Engineer
    * Microsoft Copilot
Add
Add to Collections Add to plan Add to Challenges
  * ![](https://learn.microsoft.com/en-us/learn/achievements/generic-badge.svg)
Module
[Plan and prepare to develop AI solutions on Azure](https://learn.microsoft.com/en-us/training/modules/prepare-azure-ai-development/)
    * Beginner
    * AI Engineer
    * Azure AI services
Add
Add to Collections Add to plan Add to Challenges


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Ftraining%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
