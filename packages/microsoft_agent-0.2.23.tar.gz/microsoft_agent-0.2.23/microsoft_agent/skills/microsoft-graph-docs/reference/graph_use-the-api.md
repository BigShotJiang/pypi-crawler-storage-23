[ Skip to main content ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?view=graph-rest-1.0)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach?view=graph-rest-1.0)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments?view=graph-rest-1.0)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support?view=graph-rest-1.0)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph%2Fcontext&view=graph-rest-1.0)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services?view=graph-rest-1.0)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?view=graph-rest-1.0)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?view=graph-rest-1.0)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview?view=graph-rest-1.0)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview?view=graph-rest-1.0)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview?view=graph-rest-1.0)
  *     *       * [Overview](https://learn.microsoft.com/en-us/graph/use-the-api?view=graph-rest-1.0)
      * [Access data and methods](https://learn.microsoft.com/en-us/graph/traverse-the-graph?view=graph-rest-1.0)
      * [Paging](https://learn.microsoft.com/en-us/graph/paging?view=graph-rest-1.0)
      * [Batching](https://learn.microsoft.com/en-us/graph/json-batching?view=graph-rest-1.0)
      * [Work with long-running actions](https://learn.microsoft.com/en-us/graph/long-running-actions-overview?view=graph-rest-1.0)
      * [Enable metered APIs](https://learn.microsoft.com/en-us/graph/metered-api-setup?view=graph-rest-1.0)
      * [Metered APIs FAQ](https://learn.microsoft.com/en-us/graph/metered-api-faq?view=graph-rest-1.0)
      * [Work with Graph Explorer](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-features?view=graph-rest-1.0)
    * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview?view=graph-rest-1.0)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services?view=graph-rest-1.0)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept?view=graph-rest-1.0)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors?view=graph-rest-1.0)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/use-the-api.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fuse-the-api%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fuse-the-api%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fuse-the-api%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fuse-the-api%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Use the Microsoft Graph API
Feedback
Summarize this article for me
##  In this article
  1. [OData namespace](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#odata-namespace)
  2. [Call a REST API method](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#call-a-rest-api-method)
  3. [HTTP methods](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#http-methods)
  4. [Version](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#version)
  5. [Resource](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#resource)
  6. [Query parameters](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#query-parameters)
  7. [Headers](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#headers)
  8. [Tools for interacting with Microsoft Graph](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#tools-for-interacting-with-microsoft-graph)
  9. [Next steps](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#next-steps)

Show 5 more
Microsoft Graph is a RESTful web API that enables you to access Microsoft Cloud service resources. After you [register your app](https://learn.microsoft.com/en-us/graph/auth-register-app-v2) and [get authentication tokens for a user](https://learn.microsoft.com/en-us/graph/auth-v2-user) or [service](https://learn.microsoft.com/en-us/graph/auth-v2-service), you can make requests to the Microsoft Graph API.
How conditional access policies apply to Microsoft Graph is changing. Applications need to be updated to handle scenarios where conditional access policies are configured. For more information and guidance, see [Developer guidance for Microsoft Entra Conditional Access](https://learn.microsoft.com/en-us/azure/active-directory/develop/active-directory-conditional-access-developer).
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#odata-namespace)
## OData namespace
The Microsoft Graph API defines most of its resources, methods, and enumerations in the OData namespace, `microsoft.graph`, in the [Microsoft Graph metadata](https://learn.microsoft.com/en-us/graph/traverse-the-graph#microsoft-graph-api-metadata). A small number of API sets are defined in their sub-namespaces, such as the [call records API](https://learn.microsoft.com/en-us/graph/api/resources/callrecords-api-overview) which defines resources like [callRecord](https://learn.microsoft.com/en-us/graph/api/resources/callrecords-callrecord) in `microsoft.graph.callRecords`.
Unless explicitly specified in the corresponding topic, assume types, methods, and enumerations are part of the `microsoft.graph` namespace.
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#call-a-rest-api-method)
## Call a REST API method
To read from or write to a resource such as a user or an email message, you construct a request that looks like the following:
HTTP
Copy
```
{HTTP method} https://graph.microsoft.com/{version}/{resource}?{query-parameters}

```

The components of a request include:
  * [{HTTP method}](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#http-methods) - The HTTP method used on the request to Microsoft Graph.
  * [{version}](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#version) - The version of the Microsoft Graph API your application is using.
  * [{resource}](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#resource) - The resource in Microsoft Graph that you're referencing.
  * [{query-parameters}](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#query-parameters) - Optional OData query options or REST method parameters that customize the response.
  * [{headers}](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#headers) - Request headers that customize the request. Can be optional or required depending on the API.


After you make a request, a response is returned that includes:
  * Status code - An HTTP status code that indicates success or failure. For details about HTTP error codes, see [Errors](https://learn.microsoft.com/en-us/graph/errors).
  * Response message - The data that you requested or the result of the operation. The response message can be empty for some operations.
  * `@odata.nextLink` - If your request returns a lot of data, you need to page through it by using the URL returned in `@odata.nextLink`. For details, see [Paging](https://learn.microsoft.com/en-us/graph/paging).
  * Response headers - Additional information about the response, such as the type of content returned and the request-id that you can use to correlate the response to the request.


[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#http-methods)
## HTTP methods
Microsoft Graph uses the HTTP method on your request to determine what your request is doing. Depending on the resource, the API might support operations including actions, functions, or CRUD operations described below.
Expand table
**Method** | **Description**
---|---
GET | Read data from a resource.
POST | Create a new resource, or perform an action.
PATCH | Update a resource with new values, or upsert a resource (create if resource doesn't exist, update otherwise).
PUT | Replace a resource with a new one.
DELETE | Remove a resource.
  * For the CRUD methods `GET` and `DELETE`, no request body is required.
  * The `POST`, `PATCH`, and `PUT` methods require a request body, usually specified in JSON format, that contains additional information, such as the values for properties of the resource.


Write requests in the Microsoft Graph API have a size limit of 4 MB.
In some cases, the actual write request size limit is lower than 4 MB. For example, attaching a file to a user event by `POST /me/events/{id}/attachments` has a request size limit of 3 MB, because a file around 3.5 MB can become larger than 4 MB when encoded in base64.
Requests exceeding the size limit fail with the status code HTTP 413, and the error message "Request entity too large" or "Payload too large".
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#version)
## Version
Microsoft Graph currently supports two versions: `v1.0` and `beta`.
  * `v1.0` includes generally available APIs. Use the v1.0 version for all production apps.
  * `beta` includes APIs that are currently in preview. Because we might introduce breaking changes to our beta APIs, we recommend that you use the beta version only to test apps that are in development; do not use beta APIs in your production apps.


We are always looking for feedback on our beta APIs. To provide feedback or request features, see our [Microsoft 365 Developer Platform ideas forum](https://techcommunity.microsoft.com/t5/microsoft-365-developer-platform/idb-p/Microsoft365DeveloperPlatform/label-name/Microsoft%20Graph).
For more information about API versions, see [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support).
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#resource)
## Resource
A resource can be an entity or complex type, commonly defined with properties. Entities differ from complex types by always including an **id** property.
Your URL will include the resource you are interacting with in the request, such as `me`, **user** , **group** , **drive** , and **site**. Often, top-level resources also include _relationships_ , which you can use to access additional resources, like `me/messages` or `me/drive`. You can also interact with resources using _methods_ ; for example, to send an email, use `me/sendMail`. For more information, see [Access data and methods by navigating Microsoft Graph](https://learn.microsoft.com/en-us/graph/traverse-the-graph).
Each resource might require different permissions to access it. You will often need a higher level of permissions to create or update a resource than to read it. For details about required permissions, see the method reference topic.
For details about permissions, see [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference).
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#query-parameters)
## Query parameters
Query parameters can be OData system query options, or other strings that a method accepts to customize its response.
You can use optional OData system query options to include more or fewer properties than the default response, filter the response for items that match a custom query, or provide additional parameters for a method.
For example, adding the following `filter` parameter restricts the messages returned to only those with the `emailAddress` property of `jon@contoso.com`.
HTTP
Copy
```
GET https://graph.microsoft.com/v1.0/me/messages?$filter=emailAddress eq 'jon@contoso.com'

```

For more information about OData query options, see [Use query parameters to customize responses](https://learn.microsoft.com/en-us/graph/query-parameters).
Aside from OData query options, some methods require parameter values specified as part of the query URL. For example, you can get a collection of events that occurred during a time period in a user's calendar, by querying the **calendarView** relationship of a **user** , and specifying the period `startDateTime` and `endDateTime` values as query parameters:
HTTP
Copy
```
GET https://graph.microsoft.com/me/calendarView?startDateTime=2019-09-01T09:00:00.0000000&endDateTime=2019-09-01T17:00:00.0000000

```

[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#headers)
## Headers
Microsoft Graph supports both HTTP standard headers and custom headers.
Specific APIs might require additional headers to be included in the request. On the other hand, Microsoft Graph will always return mandatory headers, such as the `request-id` header in the response, or some headers might be specific to some APIs or functionality, for example, the `Retry-After` header is included when your app hits throttling limits; or the `Location` header that's included for long-running operations.
Headers are case-insensitive as defined in [rfc 9110](https://www.rfc-editor.org/rfc/rfc9110.html) unless explicitly specified otherwise.
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#tools-for-interacting-with-microsoft-graph)
## Tools for interacting with Microsoft Graph
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#graph-explorer)
### Graph Explorer
Graph Explorer is a web-based tool that you can use to build and test requests using Microsoft Graph APIs. You can access Graph Explorer at: <https://developer.microsoft.com/graph/graph-explorer>.
You can either access demo data without signing in, or you can sign in to a tenant of your own. Use the following steps to build the request:
  1. Select the HTTP method.
  2. Select the version of API that you want to use.
  3. Type the query in the request text box.
  4. Select **Run Query**.


The following example shows a request that returns information about users in the demo tenant:
![Screenshot of Graph Explorer with a GET user request highlighted](https://learn.microsoft.com/en-us/graph/images/graph-explorer.png)
Sample queries are provided in Graph Explorer to enable you to more quickly run common requests. To see the samples that are available, select **show more samples**. Select **On** for the set of samples that you want to see, and then after closing the selection window, you should see a list of predefined requests.
A status code and message are displayed after a request is sent and the response is shown in the **Response Preview** tab.
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#postman)
### Postman
Postman is a tool that you can use to build and test requests using the Microsoft Graph APIs. You can download Postman at: <https://www.getpostman.com/>. To interact with Microsoft Graph in Postman, you use the Microsoft Graph collection.
For more information, see [Use Postman with the Microsoft Graph API](https://learn.microsoft.com/en-us/graph/use-postman).
[](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#next-steps)
## Next steps
You're ready to get up and running with Microsoft Graph. Try the [Quick Start](https://developer.microsoft.com/graph/quick-start), or get started using one of our [SDKs and code samples](https://developer.microsoft.com/graph/code-samples-and-sdks).
* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ Use Graph Explorer to try Microsoft Graph APIs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?source=recommendations)
Try Microsoft Graph APIs on the default sample tenant to explore capabilities, or sign in to your tenant and use it as a prototyping tool to fulfill your app scenarios.
  * [ Access data and methods by navigating Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/traverse-the-graph?source=recommendations)
In addition to using the Microsoft Graph API to read and write data, you can use a number of request patterns to traverse through the resources in Microsoft Graph. The metadata document also helps you to understand the data model of the resources and relationships in Microsoft Graph.
  * [ Microsoft Graph REST API v1.0 endpoint reference - Microsoft Graph v1.0 ](https://learn.microsoft.com/en-us/graph/api/overview?source=recommendations)
Find reference content for Microsoft Graph REST APIs in the v1.0 endpoint, which includes APIs in general availability (GA) status.
  * [ Authentication and authorization basics - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/auth/auth-concepts?source=recommendations)
To call Microsoft Graph, you must register your app with the Microsoft identity platform, request permissions, and acquire an access token.
  * [ Microsoft Graph overview - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/overview?source=recommendations)
Use Microsoft Graph to derive insights and analytics from Microsoft 365 and Microsoft Entra data, and build unique, intelligent apps.
  * [ Calling the Microsoft Graph API - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/call-api?source=recommendations)
To access and manipulate a Microsoft Graph resource, you call and specify the resource URLs using one of the following operations:
  * [ Work with Graph Explorer - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-features?source=recommendations)
Use Graph Explorer to make Microsoft Graph REST API requests and view corresponding responses. Learn how to use some of the important features in Graph Explorer.
  * [ Microsoft Graph tutorials - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/tutorials/?source=recommendations)
Create a basic application that accesses data via Microsoft Graph in 30 minutes by using a step-by-step Microsoft Graph tutorial.


Show 5 more
Module
[ Explore Microsoft Graph - Training ](https://learn.microsoft.com/en-us/training/modules/microsoft-graph/?source=recommendations)
Explore Microsoft Graph
Certification
[ Microsoft Certified: Identity and Access Administrator Associate - Certifications ](https://learn.microsoft.com/en-us/credentials/certifications/identity-and-access-administrator/?source=recommendations)
Demonstrate the features of Microsoft Entra ID to modernize identity solutions, implement hybrid solutions, and implement identity governance.
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 11/07/2024


##  In this article
  1. [OData namespace](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#odata-namespace)
  2. [Call a REST API method](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#call-a-rest-api-method)
  3. [HTTP methods](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#http-methods)
  4. [Version](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#version)
  5. [Resource](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#resource)
  6. [Query parameters](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#query-parameters)
  7. [Headers](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#headers)
  8. [Tools for interacting with Microsoft Graph](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#tools-for-interacting-with-microsoft-graph)
  9. [Next steps](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#next-steps)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fuse-the-api%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
