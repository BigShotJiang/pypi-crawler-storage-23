[ Skip to main content ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Version Microsoft Graph REST API v1.0
  * [1.0](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
  * [beta](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-beta)


Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [API changelog](https://developer.microsoft.com/en-us/graph/changelog)
  * [Quick start](https://developer.microsoft.com/en-us/graph/quick-start)
  * [Authentication and authorization](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
  * [Use the API](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use SDKs](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use the toolkit](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Deploy with Bicep](https://learn.microsoft.com/en-us/graph/templates?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Known issues](https://developer.microsoft.com/graph/known-issues)
  * [Errors](https://learn.microsoft.com/en-us/graph/errors?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  *     * [Overview](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
    *       * [Overview](https://learn.microsoft.com/en-us/graph/api/resources/onedrive?view=graph-rest-1.0)
      *         * [Drive item](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
        * [Get item](https://learn.microsoft.com/en-us/graph/api/driveitem-get?view=graph-rest-1.0)
        * [Get analytics](https://learn.microsoft.com/en-us/graph/api/itemanalytics-get?view=graph-rest-1.0)
        * [Get activities by interval](https://learn.microsoft.com/en-us/graph/api/itemactivitystat-getactivitybyinterval?view=graph-rest-1.0)
        * [List children](https://learn.microsoft.com/en-us/graph/api/driveitem-list-children?view=graph-rest-1.0)
        * [List versions](https://learn.microsoft.com/en-us/graph/api/driveitem-list-versions?view=graph-rest-1.0)
        * [Create folder](https://learn.microsoft.com/en-us/graph/api/driveitem-post-children?view=graph-rest-1.0)
        * [Update item](https://learn.microsoft.com/en-us/graph/api/driveitem-update?view=graph-rest-1.0)
        * [Upload](https://learn.microsoft.com/en-us/graph/api/driveitem-put-content?view=graph-rest-1.0)
        * [Download file](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content?view=graph-rest-1.0)
        * [Download specific file format](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content-format?view=graph-rest-1.0)
        * [Delete item](https://learn.microsoft.com/en-us/graph/api/driveitem-delete?view=graph-rest-1.0)
        * [Restore item](https://learn.microsoft.com/en-us/graph/api/driveitem-restore?view=graph-rest-1.0)
        * [Permanently delete item](https://learn.microsoft.com/en-us/graph/api/driveitem-permanentdelete?view=graph-rest-1.0)
        * [Move item](https://learn.microsoft.com/en-us/graph/api/driveitem-move?view=graph-rest-1.0)
        * [Copy item](https://learn.microsoft.com/en-us/graph/api/driveitem-copy?view=graph-rest-1.0)
        * [Search items](https://learn.microsoft.com/en-us/graph/api/driveitem-search?view=graph-rest-1.0)
        * [Track changes](https://learn.microsoft.com/en-us/graph/api/driveitem-delta?view=graph-rest-1.0)
        * [Follow item](https://learn.microsoft.com/en-us/graph/api/driveitem-follow?view=graph-rest-1.0)
        * [Unfollow item](https://learn.microsoft.com/en-us/graph/api/driveitem-unfollow?view=graph-rest-1.0)
        * [Get thumbnails](https://learn.microsoft.com/en-us/graph/api/driveitem-list-thumbnails?view=graph-rest-1.0)
        * [Create sharing link](https://learn.microsoft.com/en-us/graph/api/driveitem-createlink?view=graph-rest-1.0)
        * [Add permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-invite?view=graph-rest-1.0)
        * [List permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-list-permissions?view=graph-rest-1.0)
        * [Delete permission](https://learn.microsoft.com/en-us/graph/api/permission-delete?view=graph-rest-1.0)
        * [Get WebSocket channel](https://learn.microsoft.com/en-us/graph/api/subscriptions-socketio?view=graph-rest-1.0)
        * [Preview item](https://learn.microsoft.com/en-us/graph/api/driveitem-preview?view=graph-rest-1.0)
        * [Check in files](https://learn.microsoft.com/en-us/graph/api/driveitem-checkin?view=graph-rest-1.0)
        * [Check out files](https://learn.microsoft.com/en-us/graph/api/driveitem-checkout?view=graph-rest-1.0)
        * [Discard checkout](https://learn.microsoft.com/en-us/graph/api/driveitem-discardcheckout?view=graph-rest-1.0)
        * [Extract sensitivity labels](https://learn.microsoft.com/en-us/graph/api/driveitem-extractsensitivitylabels?view=graph-rest-1.0)
        * [Assign sensitivity label](https://learn.microsoft.com/en-us/graph/api/driveitem-assignsensitivitylabel?view=graph-rest-1.0)
        * [Get retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-getretentionlabel?view=graph-rest-1.0)
        * [Set retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-setretentionlabel?view=graph-rest-1.0)
        * [Remove retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-removeretentionlabel?view=graph-rest-1.0)
        * [Lock or unlock record](https://learn.microsoft.com/en-us/graph/api/driveitem-lockorunlockrecord?view=graph-rest-1.0)
        * [Create upload session](https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/api-reference/v1.0/resources/driveitem.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fresources%2Fdriveitem%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fresources%2Fdriveitem%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fresources%2Fdriveitem%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fresources%2Fdriveitem%3Fview%3Dgraph-rest-1.0%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) or changing directories.
Access to this page requires authorization. You can try changing directories.
# driveItem resource type
Feedback
Summarize this article for me
##  In this article
  1. [Methods](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#methods)
  2. [Properties](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#properties)
  3. [Relationships](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#relationships)
  4. [Instance Attributes](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#instance-attributes)
  5. [JSON representation](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#json-representation)


Namespace: microsoft.graph
The **driveItem** resource represents a file, folder, or other item stored in a drive.
All file system objects in OneDrive and SharePoint are returned as **driveItem** resources. Items in SharePoint document libraries can be represented as [listItem](https://learn.microsoft.com/en-us/graph/api/resources/listitem?view=graph-rest-1.0) or **driveItem** resources.
There are two primary ways of addressing a **driveItem** resource:
  * By the **driveItem** unique identifier using `drive/items/{item-id}`
  * By file system path using `/drive/root:/path/to/file`


For more information, see [addressing driveItems](https://learn.microsoft.com/en-us/graph/onedrive-addressing-driveitems).
**driveItem** resources have facets modeled as properties that provide data about the driveItem's identities and capabilities. For example:
  * Folders have a [**folder facet**](https://learn.microsoft.com/en-us/graph/api/resources/folder?view=graph-rest-1.0)
  * Files have a [**file facet**](https://learn.microsoft.com/en-us/graph/api/resources/file?view=graph-rest-1.0).
  * Images have an [**image facet**](https://learn.microsoft.com/en-us/graph/api/resources/image?view=graph-rest-1.0) in addition to their file facet.
  * Images taken with a camera (photos) have a [**photo facet**](https://learn.microsoft.com/en-us/graph/api/resources/photo?view=graph-rest-1.0) that identifies the item as a photo and provides the properties of when the photo was taken and with what device.


Items with the **folder** facet act as containers of items and therefore have a `children` reference pointing to a collection of **driveItems** under the folder.
> **Note:** In OneDrive for Business or SharePoint document libraries, the **cTag** property isn't returned, if the **driveItem** has a [folder](https://learn.microsoft.com/en-us/graph/api/resources/folder?view=graph-rest-1.0) facet.
[](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#methods)
## Methods
Expand table
Method | Return Type | Description
---|---|---
[Get item](https://learn.microsoft.com/en-us/graph/api/driveitem-get?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Retrieve the metadata for a **driveItem** in a drive.
[Get analytics](https://learn.microsoft.com/en-us/graph/api/itemanalytics-get?view=graph-rest-1.0) | [itemAnalytics](https://learn.microsoft.com/en-us/graph/api/resources/itemanalytics?view=graph-rest-1.0) | Get analytics for this resource.
[Get activities by interval](https://learn.microsoft.com/en-us/graph/api/itemactivitystat-getactivitybyinterval?view=graph-rest-1.0) | [itemActivityStat](https://learn.microsoft.com/en-us/graph/api/resources/itemactivitystat?view=graph-rest-1.0) | Get a collection of **itemActivityStats** within the specified time interval.
[List children](https://learn.microsoft.com/en-us/graph/api/driveitem-list-children?view=graph-rest-1.0) |  [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) collection | Return a collection of **driveItems** in the children relationship of a **driveItem**.
[List versions](https://learn.microsoft.com/en-us/graph/api/driveitem-list-versions?view=graph-rest-1.0) |  [driveItemVersion](https://learn.microsoft.com/en-us/graph/api/resources/driveitemversion?view=graph-rest-1.0) collection | Retrieve the versions of a file in the current user's drive.
[Create folder](https://learn.microsoft.com/en-us/graph/api/driveitem-post-children?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Create a **driveItem** in the specified drive.
[Update item](https://learn.microsoft.com/en-us/graph/api/driveitem-update?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Update a **driveItem** in the drive.
[Upload](https://learn.microsoft.com/en-us/graph/api/driveitem-put-content?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Upload content to the **driveItem**.
[Download file](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content?view=graph-rest-1.0) | download Url | Download content of a **driveItem**.
[Download specific file format](https://learn.microsoft.com/en-us/graph/api/driveitem-get-content-format?view=graph-rest-1.0) | download Url | Download content of a **driveItem** with a specific format.
[Delete item](https://learn.microsoft.com/en-us/graph/api/driveitem-delete?view=graph-rest-1.0) | None | Delete a **driveItem**.
[Restore item](https://learn.microsoft.com/en-us/graph/api/driveitem-restore?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Restore a deleted [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) that is currently in the [recycle bin](https://learn.microsoft.com/en-us/graph/api/resources/recyclebin?view=graph-rest-1.0).
[Permanently delete item](https://learn.microsoft.com/en-us/graph/api/driveitem-permanentdelete?view=graph-rest-1.0) | None | Permanently delete a **driveItem** by using its ID.
[Move item](https://learn.microsoft.com/en-us/graph/api/driveitem-move?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Move a **driveItem** to a new parent item.
[Copy item](https://learn.microsoft.com/en-us/graph/api/driveitem-copy?view=graph-rest-1.0) | details about how to [monitor the progress](https://learn.microsoft.com/en-us/graph/long-running-actions-overview) of the copy | Create a copy of a **driveItem** (including any children).
[Search items](https://learn.microsoft.com/en-us/graph/api/driveitem-search?view=graph-rest-1.0) |  [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) collection | Search the hierarchy of items for items matching a query.
[Track changes](https://learn.microsoft.com/en-us/graph/api/driveitem-delta?view=graph-rest-1.0) | delta link | List any changes in the drive.
[Follow item](https://learn.microsoft.com/en-us/graph/api/driveitem-follow?view=graph-rest-1.0) | [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) | Follow a **driveItem**.
[Unfollow item](https://learn.microsoft.com/en-us/graph/api/driveitem-unfollow?view=graph-rest-1.0) | None | Unfollow a **driveItem**.
[Get thumbnails](https://learn.microsoft.com/en-us/graph/api/driveitem-list-thumbnails?view=graph-rest-1.0) |  [driveItem](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0) collection | List **driveItems** with their thumbnails.
[Create sharing link](https://learn.microsoft.com/en-us/graph/api/driveitem-createlink?view=graph-rest-1.0) | sharing link | Create a link to share the **driveItem**.
[Add permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-invite?view=graph-rest-1.0) |  [permission](https://learn.microsoft.com/en-us/graph/api/resources/permission?view=graph-rest-1.0) collection | Send a sharing invite to a user.
[List permissions](https://learn.microsoft.com/en-us/graph/api/driveitem-list-permissions?view=graph-rest-1.0) |  [permission](https://learn.microsoft.com/en-us/graph/api/resources/permission?view=graph-rest-1.0) collection | Retrieve the collection of permissions on an **driveItem**.
[Delete permission](https://learn.microsoft.com/en-us/graph/api/permission-delete?view=graph-rest-1.0) | None | Remove the permission from the **driveItem**.
[Get WebSocket channel](https://learn.microsoft.com/en-us/graph/api/subscriptions-socketio?view=graph-rest-1.0) | [subscription](https://learn.microsoft.com/en-us/graph/api/resources/subscription?view=graph-rest-1.0) | Receive near-real-time change notifications for a drive using socket.io.
[Preview item](https://learn.microsoft.com/en-us/graph/api/driveitem-preview?view=graph-rest-1.0) | json object | Obtain short-lived embeddable URLs for an item in order to render a temporary preview.
[Check in files](https://learn.microsoft.com/en-us/graph/api/driveitem-checkin?view=graph-rest-1.0) | None | Check in a checked out **driveItem** resource, which makes the version of the document available to others.
[Check out files](https://learn.microsoft.com/en-us/graph/api/driveitem-checkout?view=graph-rest-1.0) | None | Check out a **driveItem** resource to prevent others from editing the document, and prevent your changes from being visible until the documented is [checked in](https://learn.microsoft.com/en-us/graph/api/driveitem-checkin?view=graph-rest-1.0).
[Discard checkout](https://learn.microsoft.com/en-us/graph/api/driveitem-discardcheckout?view=graph-rest-1.0) | None | Discard a previously [checked out](https://learn.microsoft.com/en-us/graph/api/driveitem-checkout?view=graph-rest-1.0) **driveItem**.
[Extract sensitivity labels](https://learn.microsoft.com/en-us/graph/api/driveitem-extractsensitivitylabels?view=graph-rest-1.0) | [extractSensitivityLabelsResult](https://learn.microsoft.com/en-us/graph/api/resources/extractsensitivitylabelsresult?view=graph-rest-1.0) | Extract one or more sensitivity labels assigned to a drive item and update the metadata of a drive item with the latest details of the assigned label.
[Assign sensitivity label](https://learn.microsoft.com/en-us/graph/api/driveitem-assignsensitivitylabel?view=graph-rest-1.0) | String | Asynchronously assign a sensitivity label to a **driveItem**.
[Get retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-getretentionlabel?view=graph-rest-1.0) | [itemRetentionLabel](https://learn.microsoft.com/en-us/graph/api/resources/itemretentionlabel?view=graph-rest-1.0) | Get metadata information for a retention label applied on a **driveItem**.
[Set retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-setretentionlabel?view=graph-rest-1.0) | [itemRetentionLabel](https://learn.microsoft.com/en-us/graph/api/resources/itemretentionlabel?view=graph-rest-1.0) | Apply (set) a retention label on a **driveItem** (files and folders).
[Remove retention label](https://learn.microsoft.com/en-us/graph/api/driveitem-removeretentionlabel?view=graph-rest-1.0) | None | Remove a retention label from a **driveItem**.
[Lock or unlock record](https://learn.microsoft.com/en-us/graph/api/driveitem-lockorunlockrecord?view=graph-rest-1.0) | [itemRetentionLabel](https://learn.microsoft.com/en-us/graph/api/resources/itemretentionlabel?view=graph-rest-1.0) | Lock or unlock a retention label on a **driveItem** that classifies content as records.
[Create upload session](https://learn.microsoft.com/en-us/graph/api/driveitem-createuploadsession?view=graph-rest-1.0) | [uploadSession](https://learn.microsoft.com/en-us/graph/api/resources/uploadsession?view=graph-rest-1.0) | Create an upload session to allow your app to upload files up to the maximum file size.
[](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#properties)
## Properties
Expand table
Property | Type | Description
---|---|---
audio | [audio](https://learn.microsoft.com/en-us/graph/api/resources/audio?view=graph-rest-1.0) | Audio metadata, if the item is an audio file. Read-only. Read-only. Only on OneDrive Personal.
bundle | [bundle](https://learn.microsoft.com/en-us/graph/api/resources/bundle?view=graph-rest-1.0) | Bundle metadata, if the item is a bundle. Read-only.
content | Stream | The content stream, if the item represents a file.
createdBy | [identitySet](https://learn.microsoft.com/en-us/graph/api/resources/identityset?view=graph-rest-1.0) | Identity of the user, device, and application that created the item. Read-only.
createdDateTime | DateTimeOffset | Date and time of item creation. Read-only.
cTag | String | An eTag for the content of the item. This eTag isn't changed if only the metadata is changed. **Note** This property isn't returned if the item is a folder. Read-only.
deleted | [deleted](https://learn.microsoft.com/en-us/graph/api/resources/deleted?view=graph-rest-1.0) | Information about the deleted state of the item. Read-only.
description | String | Provides a user-visible description of the item. Read-write. Only on OneDrive Personal.
eTag | String | eTag for the entire item (metadata + content). Read-only.
file | [file](https://learn.microsoft.com/en-us/graph/api/resources/file?view=graph-rest-1.0) | File metadata, if the item is a file. Read-only.
fileSystemInfo | [fileSystemInfo](https://learn.microsoft.com/en-us/graph/api/resources/filesysteminfo?view=graph-rest-1.0) | File system information on client. Read-write.
folder | [folder](https://learn.microsoft.com/en-us/graph/api/resources/folder?view=graph-rest-1.0) | Folder metadata, if the item is a folder. Read-only.
id | String | The unique identifier of the item within the Drive. Read-only.
image | [image](https://learn.microsoft.com/en-us/graph/api/resources/image?view=graph-rest-1.0) | Image metadata, if the item is an image. Read-only.
lastModifiedBy | [identitySet](https://learn.microsoft.com/en-us/graph/api/resources/identityset?view=graph-rest-1.0) | Identity of the user, device, and application that last modified the item. Read-only.
lastModifiedDateTime | DateTimeOffset | Date and time the item was last modified. Read-only.
location | [geoCoordinates](https://learn.microsoft.com/en-us/graph/api/resources/geocoordinates?view=graph-rest-1.0) | Location metadata, if the item has location data. Read-only.
malware | [malware](https://learn.microsoft.com/en-us/graph/api/resources/malware?view=graph-rest-1.0) | Malware metadata, if the item was detected to contain malware. Read-only.
name | String | The name of the item (filename and extension). Read-write.
package | [package](https://learn.microsoft.com/en-us/graph/api/resources/package?view=graph-rest-1.0) | If present, indicates that this item is a package instead of a folder or file. Packages are treated like files in some contexts and folders in others. Read-only.
parentReference | [itemReference](https://learn.microsoft.com/en-us/graph/api/resources/itemreference?view=graph-rest-1.0) | Parent information, if the item has a parent. Read-write.
pendingOperations | [pendingOperations](https://learn.microsoft.com/en-us/graph/api/resources/pendingoperations?view=graph-rest-1.0) | If present, indicates that one or more operations that might affect the state of the driveItem are pending completion. Read-only.
photo | [photo](https://learn.microsoft.com/en-us/graph/api/resources/photo?view=graph-rest-1.0) | Photo metadata, if the item is a photo. Read-only.
publication | [publicationFacet](https://learn.microsoft.com/en-us/graph/api/resources/publicationfacet?view=graph-rest-1.0) | Provides information about the published or checked-out state of an item, in locations that support such actions. This property isn't returned by default. Read-only.
remoteItem | [remoteItem](https://learn.microsoft.com/en-us/graph/api/resources/remoteitem?view=graph-rest-1.0) | Remote item data, if the item is shared from a drive other than the one being accessed. Read-only.
root | [root](https://learn.microsoft.com/en-us/graph/api/resources/root?view=graph-rest-1.0) | If this property is non-null, it indicates that the driveItem is the top-most driveItem in the drive.
searchResult | [searchResult](https://learn.microsoft.com/en-us/graph/api/resources/searchresult?view=graph-rest-1.0) | Search metadata, if the item is from a search result. Read-only.
shared | [shared](https://learn.microsoft.com/en-us/graph/api/resources/shared?view=graph-rest-1.0) | Indicates that the item was shared with others and provides information about the shared state of the item. Read-only.
sharepointIds | [sharepointIds](https://learn.microsoft.com/en-us/graph/api/resources/sharepointids?view=graph-rest-1.0) | Returns identifiers useful for SharePoint REST compatibility. Read-only.
size | Int64 | Size of the item in bytes. Read-only.
specialFolder | [specialFolder](https://learn.microsoft.com/en-us/graph/api/resources/specialfolder?view=graph-rest-1.0) | If the current item is also available as a special folder, this facet is returned. Read-only.
video | [video](https://learn.microsoft.com/en-us/graph/api/resources/video?view=graph-rest-1.0) | Video metadata, if the item is a video. Read-only.
webDavUrl | String | WebDAV compatible URL for the item.
webUrl | String | URL that displays the resource in the browser. Read-only.
> **Note:** The eTag and cTag properties work differently on containers (folders). The cTag value is modified when content or metadata of any descendant of the folder is changed. The eTag value is only modified when the folder's properties are changed, except for properties that are derived from descendants (like **childCount** or **lastModifiedDateTime**).
[](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#relationships)
## Relationships
Expand table
Relationship | Type | Description
---|---|---
activities |  [itemActivity](https://learn.microsoft.com/en-us/graph/api/resources/itemactivity?view=graph-rest-1.0) collection | The list of recent activities that took place on this item.
analytics |  [itemAnalytics](https://learn.microsoft.com/en-us/graph/api/resources/itemanalytics?view=graph-rest-1.0) resource | Analytics about the view activities that took place on this item.
children | driveItem collection | Collection containing Item objects for the immediate children of Item. Only items representing folders have children. Read-only. Nullable.
createdByUser | [user](https://learn.microsoft.com/en-us/graph/api/resources/users) | Identity of the user who created the item. Read-only.
lastModifiedByUser | [user](https://learn.microsoft.com/en-us/graph/api/resources/users) | Identity of the user who last modified the item. Read-only.
listItem | [listItem](https://learn.microsoft.com/en-us/graph/api/resources/listitem?view=graph-rest-1.0) | For drives in SharePoint, the associated document library list item. Read-only. Nullable.
permissions |  [permission](https://learn.microsoft.com/en-us/graph/api/resources/permission?view=graph-rest-1.0) collection | The set of permissions for the item. Read-only. Nullable.
retentionLabel | [itemRetentionLabel](https://learn.microsoft.com/en-us/graph/api/resources/itemretentionlabel?view=graph-rest-1.0) | Information about retention label and settings enforced on the **driveItem**. Read-write.
subscriptions |  [subscription](https://learn.microsoft.com/en-us/graph/api/resources/subscription?view=graph-rest-1.0) collection | The set of subscriptions on the item. Only supported on the root of a drive.
thumbnails |  [thumbnailSet](https://learn.microsoft.com/en-us/graph/api/resources/thumbnailset?view=graph-rest-1.0) collection | Collection of [thumbnailSet](https://learn.microsoft.com/en-us/graph/api/resources/thumbnailset?view=graph-rest-1.0) objects associated with the item. For more information, see [getting thumbnails](https://learn.microsoft.com/en-us/graph/api/driveitem-list-thumbnails?view=graph-rest-1.0). Read-only. Nullable.
versions |  [driveItemVersion](https://learn.microsoft.com/en-us/graph/api/resources/driveitemversion?view=graph-rest-1.0) collection | The list of previous versions of the item. For more info, see [getting previous versions](https://learn.microsoft.com/en-us/graph/api/driveitem-list-versions?view=graph-rest-1.0). Read-only. Nullable.
workbook | [workbook](https://learn.microsoft.com/en-us/graph/api/resources/workbook?view=graph-rest-1.0) | For files that are Excel spreadsheets, access to the workbook API to work with the spreadsheet's contents. Nullable.
[](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#instance-attributes)
## Instance Attributes
Instance attributes are properties with special behaviors. These properties are temporary and either define behavior the service should perform or provide short-term property values, like a download URL for an item that expires.
Expand table
Property name | Type | Description
---|---|---
@microsoft.graph.conflictBehavior | string | The conflict resolution behavior for actions that create a new item. You can use the values _fail_ , _replace_ , or _rename_. The default for PUT is _replace_. An item is never returned with this annotation. Write-only.
@microsoft.graph.downloadUrl | string | A URL that can be used to download this file's content. Authentication isn't required with this URL. Read-only.
@microsoft.graph.sourceUrl | string | This instance annotation can be used to instruct the service to download the contents of the URL when issuing a PUT request, and stores it as the file. Write-only.
> **Notes:** The parameter `@microsoft.graph.conflictBehavior` should be included in the URL instead of the body of the request.
> The `@microsoft.graph.downloadUrl` value is a short-lived URL and can't be cached. The URL is invalidated after for a short period of time (1 hour). Removing file permissions for a user might not immediately invalidate the URL.
> Using the `@microsoft.graph.sourceUrl` property for file uploading is [not supported](https://learn.microsoft.com/en-us/onedrive/developer/rest-api/api/driveitem_upload_url?view=odsp-graph-online#remarks&preserve-view=true) in OneDrive for Business, SharePoint Online, and SharePoint Server 2016.
[](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#json-representation)
## JSON representation
The following JSON representation shows the resource type.
The **driveItem** resource is derived from [**baseItem**](https://learn.microsoft.com/en-us/graph/api/resources/baseitem?view=graph-rest-1.0) and inherits properties from that resource.
JSON
Copy
```
{
  "audio": { "@odata.type": "microsoft.graph.audio" },
  "bundle": { "@odata.type": "microsoft.graph.bundle" },
  "content": { "@odata.type": "Edm.Stream" },
  "cTag": "string (etag)",
  "deleted": { "@odata.type": "microsoft.graph.deleted"},
  "description": "string",
  "file": { "@odata.type": "microsoft.graph.file" },
  "fileSystemInfo": { "@odata.type": "microsoft.graph.fileSystemInfo" },
  "folder": { "@odata.type": "microsoft.graph.folder" },
  "image": { "@odata.type": "microsoft.graph.image" },
  "location": { "@odata.type": "microsoft.graph.geoCoordinates" },
  "malware": { "@odata.type": "microsoft.graph.malware" },
  "package": { "@odata.type": "microsoft.graph.package" },
  "pendingOperations": { "@odata.type": "microsoft.graph.pendingOperations" },
  "photo": { "@odata.type": "microsoft.graph.photo" },
  "publication": {"@odata.type": "microsoft.graph.publicationFacet"},
  "remoteItem": { "@odata.type": "microsoft.graph.remoteItem" },
  "root": { "@odata.type": "microsoft.graph.root" },
  "searchResult": { "@odata.type": "microsoft.graph.searchResult" },
  "shared": { "@odata.type": "microsoft.graph.shared" },
  "sharepointIds": { "@odata.type": "microsoft.graph.sharepointIds" },
  "size": 1024,
  "specialFolder": { "@odata.type": "microsoft.graph.specialFolder" },
  "video": { "@odata.type": "microsoft.graph.video" },
  "webDavUrl": "string",

  /* relationships */
  "activities": [{"@odata.type": "microsoft.graph.itemActivity"}],
  "analytics": {"@odata.type": "microsoft.graph.itemAnalytics"},
  "children": [{ "@odata.type": "microsoft.graph.driveItem" }],
  "createdByUser": { "@odata.type": "microsoft.graph.user" },
  "retentionLabel": { "@odata.type": "microsoft.graph.itemRetentionLabel" },
  "lastModifiedByUser": { "@odata.type": "microsoft.graph.user" },
  "permissions": [ {"@odata.type": "microsoft.graph.permission"} ],
  "subscriptions": [ {"@odata.type": "microsoft.graph.subscription"} ],
  "thumbnails": [ {"@odata.type": "microsoft.graph.thumbnailSet"}],
  "versions": [ {"@odata.type": "microsoft.graph.driveItemVersion"}],

  /* inherited from baseItem */
  "createdBy": {"@odata.type": "microsoft.graph.identitySet"},
  "createdDateTime": "String (timestamp)",
  "eTag": "string",
  "id": "string (identifier)",
  "lastModifiedBy": {"@odata.type": "microsoft.graph.identitySet"},
  "lastModifiedDateTime": "String (timestamp)",
  "name": "string",
  "parentReference": {"@odata.type": "microsoft.graph.itemReference"},
  "webUrl": "string",

  /* instance annotations */
  "@microsoft.graph.conflictBehavior": "string",
  "@microsoft.graph.downloadUrl": "url",
  "@microsoft.graph.sourceUrl": "url"
}

```

* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 06/28/2024


##  In this article
  1. [Methods](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#methods)
  2. [Properties](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#properties)
  3. [Relationships](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#relationships)
  4. [Instance Attributes](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#instance-attributes)
  5. [JSON representation](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0#json-representation)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/resources/driveitem?view=graph-rest-1.0)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fresources%2Fdriveitem%3Fview%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
