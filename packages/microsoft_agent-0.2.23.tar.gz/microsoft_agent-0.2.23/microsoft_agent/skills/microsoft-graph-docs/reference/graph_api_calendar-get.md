[ Skip to main content ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Version Microsoft Graph REST API v1.0
  * [1.0](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0)
  * [beta](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-beta)


Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [API changelog](https://developer.microsoft.com/en-us/graph/changelog)
  * [Quick start](https://developer.microsoft.com/en-us/graph/quick-start)
  * [Authentication and authorization](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference?view=graph-rest-1.0)
  * [Use the API](https://learn.microsoft.com/en-us/graph/use-the-api?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use SDKs](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Use the toolkit](https://learn.microsoft.com/en-us/graph/toolkit/overview?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Deploy with Bicep](https://learn.microsoft.com/en-us/graph/templates?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [Known issues](https://developer.microsoft.com/graph/known-issues)
  * [Errors](https://learn.microsoft.com/en-us/graph/errors?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  *     * [Overview](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
    *       * [Overview](https://learn.microsoft.com/en-us/graph/api/resources/groups-overview?view=graph-rest-1.0)
      *         * [Group](https://learn.microsoft.com/en-us/graph/api/resources/group?view=graph-rest-1.0)
        * [List](https://learn.microsoft.com/en-us/graph/api/group-list?view=graph-rest-1.0)
        * [Create](https://learn.microsoft.com/en-us/graph/api/group-post-groups?view=graph-rest-1.0)
        * [Get](https://learn.microsoft.com/en-us/graph/api/group-get?view=graph-rest-1.0)
        * [Update](https://learn.microsoft.com/en-us/graph/api/group-update?view=graph-rest-1.0)
        * [Upsert](https://learn.microsoft.com/en-us/graph/api/group-upsert?view=graph-rest-1.0)
        * [Delete](https://learn.microsoft.com/en-us/graph/api/group-delete?view=graph-rest-1.0)
        * [Get delta](https://learn.microsoft.com/en-us/graph/api/group-delta?view=graph-rest-1.0)
        *           * [Get calendar](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0)
          * [Update calendar](https://learn.microsoft.com/en-us/graph/api/calendar-update?view=graph-rest-1.0)
          * [List events](https://learn.microsoft.com/en-us/graph/api/group-list-events?view=graph-rest-1.0)
          * [Create event](https://learn.microsoft.com/en-us/graph/api/group-post-events?view=graph-rest-1.0)
          * [Get event](https://learn.microsoft.com/en-us/graph/api/group-get-event?view=graph-rest-1.0)
          * [Update event](https://learn.microsoft.com/en-us/graph/api/group-update-event?view=graph-rest-1.0)
          * [Delete event](https://learn.microsoft.com/en-us/graph/api/group-delete-event?view=graph-rest-1.0)
          * [List calendar view](https://learn.microsoft.com/en-us/graph/api/group-list-calendarview?view=graph-rest-1.0)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/api-reference/v1.0/api/calendar-get.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fcalendar-get%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fcalendar-get%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fcalendar-get%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fcalendar-get%3Fview%3Dgraph-rest-1.0%26tabs%3Dhttp%26WT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Get calendar
Feedback
Summarize this article for me
##  In this article
  1. [Permissions](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#permissions)
  2. [HTTP request](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#http-request)
  3. [Optional query parameters](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#optional-query-parameters)
  4. [Request headers](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-headers)
  5. [Request body](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-body)
  6. [Response](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#response)
  7. [Example](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#example)

Show 3 more
Namespace: microsoft.graph
Get the properties and relationships of a [calendar](https://learn.microsoft.com/en-us/graph/api/resources/calendar?view=graph-rest-1.0) object. The calendar can be one for a [user](https://learn.microsoft.com/en-us/graph/api/resources/user?view=graph-rest-1.0), or the default calendar of a Microsoft 365 [group](https://learn.microsoft.com/en-us/graph/api/resources/group?view=graph-rest-1.0).
There are two scenarios where an app can get another user's calendar:
  * If the app has application permissions, or,
  * If the app has the appropriate delegated [permissions](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#permissions) from one user, and another user has shared a calendar with that user, or, has given delegated access to that user. See [details and an example](https://learn.microsoft.com/en-us/graph/outlook-get-shared-events-calendars).


This API is available in the following [national cloud deployments](https://learn.microsoft.com/en-us/graph/deployments).
Expand table
Global service | US Government L4 | US Government L5 (DOD) | China operated by 21Vianet
---|---|---|---
✅ | ✅ | ✅ | ✅
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#permissions)
## Permissions
Depending on the type of calendar that the event is in and the permission type (delegated or application) requested, one of the following permissions is required to call this API. To learn more, including how to choose permissions, see [Permissions](https://learn.microsoft.com/en-us/graph/permissions-reference).
Expand table
Calendar | Delegated (work or school account) | Delegated (personal Microsoft account) | Application
---|---|---|---
user calendar | Calendars.ReadBasic, Calendars.Read, Calendars.ReadWrite | Calendars.ReadBasic, Calendars.Read, Calendars.ReadWrite | Calendars.ReadBasic, Calendars.Read, Calendars.ReadWrite
group calendar | Group.Read.All, Group.ReadWrite.All | Not supported. | Not supported.
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#http-request)
## HTTP request
A user's or group's default [calendar](https://learn.microsoft.com/en-us/graph/api/resources/calendar?view=graph-rest-1.0).
HTTP
Copy
```
GET /me/calendar
GET /users/{id | userPrincipalName}/calendar
GET /groups/{id}/calendar

```

A user's [calendar](https://learn.microsoft.com/en-us/graph/api/resources/calendar?view=graph-rest-1.0) in the default [calendarGroup](https://learn.microsoft.com/en-us/graph/api/resources/calendargroup?view=graph-rest-1.0).
HTTP
Copy
```
GET /me/calendars/{id}
GET /users/{id | userPrincipalName}/calendars/{id}

```

A user's [calendar](https://learn.microsoft.com/en-us/graph/api/resources/calendar?view=graph-rest-1.0) in a specific [calendarGroup](https://learn.microsoft.com/en-us/graph/api/resources/calendargroup?view=graph-rest-1.0).
HTTP
Copy
```
GET /me/calendarGroups/{id}/calendars/{id}
GET /users/{id | userPrincipalName}/calendarGroups/{id}/calendars/{id}

```

[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#optional-query-parameters)
## Optional query parameters
This method supports the [OData Query Parameters](https://learn.microsoft.com/en-us/graph/query-parameters) to help customize the response.
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-headers)
## Request headers
Expand table
Name | Type | Description
---|---|---
Authorization | string | Bearer {token}. Required. Learn more about [authentication and authorization](https://learn.microsoft.com/en-us/graph/auth/auth-concepts).
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-body)
## Request body
Don't supply a request body for this method.
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#response)
## Response
If successful, this method returns a `200 OK` response code and [calendar](https://learn.microsoft.com/en-us/graph/api/resources/calendar?view=graph-rest-1.0) object in the response body.
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#example)
## Example
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request)
### Request
The following example gets the signed-in user's default calendar.
  * [HTTP](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_http)
  * [C#](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_csharp)
  * [Go](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_go)
  * [Java](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_java)
  * [JavaScript](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_javascript)
  * [PHP](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_php)
  * [PowerShell](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_powershell)
  * [Python](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#tabpanel_1_python)


msgraph
Copy Try It
```
GET https://graph.microsoft.com/v1.0/me/calendar

```

C#
Copy
```

// Code snippets are only available for the latest version. Current version is 5.x

// To initialize your graphClient, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=csharp
var result = await graphClient.Me.Calendar.GetAsync();



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Go
Copy
```


// Code snippets are only available for the latest major version. Current major version is $v1.*

// Dependencies
import (
	  "context"
	  msgraphsdk "github.com/microsoftgraph/msgraph-sdk-go"
	  //other-imports
)


// To initialize your graphClient, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=go
calendar, err := graphClient.Me().Calendar().Get(context.Background(), nil)



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Java
Copy
```

// Code snippets are only available for the latest version. Current version is 6.x

GraphServiceClient graphClient = new GraphServiceClient(requestAdapter);

Calendar result = graphClient.me().calendar().get();



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
JavaScript
Copy
```

const options = {
	authProvider,
};

const client = Client.init(options);

let calendar = await client.api('/me/calendar')
	.get();


```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
PHP
Copy
```

<?php
use Microsoft\Graph\GraphServiceClient;


$graphServiceClient = new GraphServiceClient($tokenRequestContext, $scopes);


$result = $graphServiceClient->me()->calendar()->get()->wait();


```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
PowerShell
Copy
```

Import-Module Microsoft.Graph.Calendar

# A UPN can also be used as -UserId.
Get-MgUserDefaultCalendar -UserId $userId


```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
Python
Copy
```

# Code snippets are only available for the latest version. Current version is 1.x
from msgraph import GraphServiceClient
# To initialize your graph_client, see https://learn.microsoft.com/en-us/graph/sdks/create-client?from=snippets&tabs=python

result = await graph_client.me.calendar.get()



```

> For details about how to [add the SDK](https://learn.microsoft.com/en-us/graph/sdks/sdk-installation) to your project and [create an authProvider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers) instance, see the [SDK documentation](https://learn.microsoft.com/en-us/graph/sdks/sdks-overview).
[](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#response-1)
### Response
The following example shows the response. Note: The response object shown here might be shortened for readability.
HTTP
Copy
```
HTTP/1.1 200 OK
Content-type: application/json

{
    "@odata.context": "https://graph.microsoft.com/v1.0/$metadata#me/calendars/$entity",
    "@odata.id": "https://graph.microsoft.com/v1.0/users('ddfcd489-628b-40d7-b48b-57002df800e5@1717622f-1d94-4d0c-9d74-709fad664b77')/calendars('AAMkAGI2TGuLAAA=')",
    "id": "AAMkAGI2TGuLAAA=",
    "name": "Calendar",
    "color": "auto",
    "isDefaultCalendar": false,
    "changeKey": "nfZyf7VcrEKLNoU37KWlkQAAA0x0+w==",
    "canShare":true,
    "canViewPrivateItems":true,
    "hexColor": "",
    "canEdit":true,
    "allowedOnlineMeetingProviders": [
                "teamsForBusiness"
            ],
    "defaultOnlineMeetingProvider": "teamsForBusiness",
    "isTallyingResponses": true,
    "isRemovable": false,
    "owner":{
        "name":"Samantha Booth",
        "address":"samanthab@contoso.com"
    }
}

```

* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 07/23/2025


##  In this article
  1. [Permissions](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#permissions)
  2. [HTTP request](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#http-request)
  3. [Optional query parameters](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#optional-query-parameters)
  4. [Request headers](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-headers)
  5. [Request body](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#request-body)
  6. [Response](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#response)
  7. [Example](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http#example)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/api/calendar-get?view=graph-rest-1.0&tabs=http)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Fcalendar-get%3Fview%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
