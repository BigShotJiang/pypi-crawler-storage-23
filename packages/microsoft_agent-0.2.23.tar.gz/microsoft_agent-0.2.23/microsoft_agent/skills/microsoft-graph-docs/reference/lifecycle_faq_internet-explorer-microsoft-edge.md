[ Skip to main content ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Lifecycle  ](https://learn.microsoft.com/en-us/lifecycle)
  * [ Product Search ](https://learn.microsoft.com/en-us/lifecycle/products)
  * [ Product Export ](https://learn.microsoft.com/en-us/lifecycle/products/export)
  * More
    * [ Product Search ](https://learn.microsoft.com/en-us/lifecycle/products)
    * [ Product Export ](https://learn.microsoft.com/en-us/lifecycle/products/export)


Search
Suggestions will filter as you type
  * [Microsoft Lifecycle Policy](https://learn.microsoft.com/en-us/lifecycle/)
  * [Search by Product](https://learn.microsoft.com/en-us/lifecycle/products/)
  *     * [General](https://learn.microsoft.com/en-us/lifecycle/faq/general-lifecycle)
    * [Adobe Flash](https://learn.microsoft.com/en-us/lifecycle/faq/adobe-flash-player)
    * [Azure](https://learn.microsoft.com/en-us/lifecycle/faq/azure)
    * [Developer tools](https://learn.microsoft.com/en-us/lifecycle/faq/developer-tools)
    * [Dynamics](https://learn.microsoft.com/en-us/lifecycle/faq/dynamics)
    * [Extended Security Updates (ESU)](https://learn.microsoft.com/en-us/lifecycle/faq/extended-security-updates)
    * [Fixed Policy](https://learn.microsoft.com/en-us/lifecycle/faq/fixed-policy)
    * [Hardware and devices](https://learn.microsoft.com/en-us/lifecycle/faq/hardware)
    * [Internet Explorer and Microsoft Edge](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
    * [Modern Policy](https://learn.microsoft.com/en-us/lifecycle/faq/modern-policy)
    * [.NET Core](https://learn.microsoft.com/en-us/lifecycle/faq/dotnet-core)
    * [.NET Framework](https://learn.microsoft.com/en-us/lifecycle/faq/dotnet-framework)
    * [Office, Office 365, and Microsoft 365](https://learn.microsoft.com/en-us/lifecycle/faq/office)
    * [Visual C++](https://learn.microsoft.com/en-us/lifecycle/faq/visual-c-faq)
    * [Windows](https://learn.microsoft.com/en-us/lifecycle/faq/windows)
  * [Newsletters](https://learn.microsoft.com/en-us/lifecycle/newsletters/newsletters)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Microsoft Lifecycle Policy ](https://learn.microsoft.com/en-us/lifecycle/)


  1. [Learn](https://learn.microsoft.com/en-us/)
  2. [Microsoft Lifecycle Policy](https://learn.microsoft.com/en-us/lifecycle/)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge) Add to Collections Add to plan [ Edit ](https://github.com/MicrosoftDocs/lifecycle-pr/blob/main/lifecycle-docs/faq/internet-explorer-microsoft-edge.yml)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flifecycle%2Ffaq%2Finternet-explorer-microsoft-edge%3FWT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flifecycle%2Ffaq%2Finternet-explorer-microsoft-edge%3FWT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flifecycle%2Ffaq%2Finternet-explorer-microsoft-edge%3FWT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flifecycle%2Ffaq%2Finternet-explorer-microsoft-edge%3FWT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Lifecycle FAQ - Internet Explorer and Microsoft Edge
Feedback
Summarize this article for me
##  In this article
  1. [What is the Lifecycle policy for Microsoft Edge?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-microsoft-edge-)
  2. [What is the Lifecycle policy for Internet Explorer?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-internet-explorer-)
  3. [Is Internet Explorer 11 the last version of Internet Explorer?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#is-internet-explorer-11-the-last-version-of-internet-explorer-)
  4. [What if my enterprise line-of-business (LOB) application has a dependency on a version of Internet Explorer that reached end of support?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-if-my-enterprise-line-of-business--lob--application-has-a-dependency-on-a-version-of-internet-explorer-that-reached-end-of-support-)


![](https://learn.microsoft.com/en-us/lifecycle/media/search.png) Please go [here](https://learn.microsoft.com/en-us/lifecycle/products/) to search for your product's lifecycle.
[](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-microsoft-edge-)
## What is the Lifecycle policy for Microsoft Edge?
Microsoft Edge follows the [Modern Policy](https://learn.microsoft.com/en-us/lifecycle/policies/modern). Go [here](https://learn.microsoft.com/en-us/DeployEdge/microsoft-edge-support-lifecycle) for Microsoft Edge Lifecycle Policy details.
Support for the legacy version of the Microsoft Edge desktop app ended on March 9, 2021. The Microsoft Edge Legacy application will no longer receive security updates after that date. Go [here](https://techcommunity.microsoft.com/t5/microsoft-365-blog/new-microsoft-edge-to-replace-microsoft-edge-legacy-with-april-s/ba-p/2114224) to learn more.
For additional lifecycle information, see [servicing guidelines by channel](https://learn.microsoft.com/en-us/deployedge/microsoft-edge-channels) along with a list of supported [operating systems](https://learn.microsoft.com/en-us/deployedge/microsoft-edge-supported-operating-systems).
Microsoft recommends using Microsoft Edge as your default browser. [Go here to download.](https://www.microsoft.com/edge/business/download?form=MO12H4&OCID=MO12H4)
[](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-internet-explorer-)
## What is the Lifecycle policy for Internet Explorer?
Internet Explorer is a [component](https://learn.microsoft.com/en-us/lifecycle/definitions) of the Windows operating system (OS) and follows the Lifecycle Policy for the product on which it is [installed](https://learn.microsoft.com/en-us/lifecycle/products/?ts=0&products=windows) and supported.
Please note that the Internet Explorer (IE) 11 desktop application ended support for certain operating systems on June 15, 2022. Customers are encouraged to move to Microsoft Edge with IE mode. IE mode enables backward compatibility and will be supported through at least 2029. Additionally, Microsoft will provide notice one year prior to retiring IE mode. Please go [here](https://blogs.windows.com/windowsexperience/2021/05/19/the-future-of-internet-explorer-on-windows-10-is-in-microsoft-edge/) to learn more.
Some versions of Internet Explorer may be supported past the latest Windows OS end date when Extended Security Updates (ESUs) are available. Go [here](https://learn.microsoft.com/en-us/lifecycle/faq/extended-security-updates) for a list of products offering ESUs.
For help migrating from IE 11 to Edge, go [here](https://techcommunity.microsoft.com/t5/windows-it-pro-blog/proven-tools-to-accelerate-your-move-to-microsoft-edge/ba-p/2504818).
For information about Teams and Office 365/Microsoft 365 support on IE11, go [here](https://aka.ms/AA97tsw).
For information on Azure DevOps support on IE11, go [here](https://devblogs.microsoft.com/devops/azure-devops-services-to-end-support-for-internet-explorer-11-and-legacy-version-of-microsoft-edge/).
The tables below show the supported version of Internet Explorer for each operating system.
**Windows Desktop operating systems**
Expand table
Operating system | Internet Explorer version | Notes
---|---|---
Windows 7 ESU | Internet Explorer 11 |
Windows 8.1 Update | Internet Explorer 11 |
Windows 10 Semi-Annual Channel (SAC)  | Internet Explorer 11 | As of June 15, 2022,
the IE11 desktop
application is no
longer supported*.
Windows 10 IoT  | Internet Explorer 11 | As of June 15, 2022,
the IE11 desktop
application is no
longer supported.*
Windows 10 2015 LTSB | Internet Explorer 11 |
Windows 10 2016 LTSB | Internet Explorer 11 |
Windows 10 2019 LTSC | Internet Explorer 11 |
Windows 10 2021 LTSC | Internet Explorer 11 |
*The Internet Explorer 11 (IE11) desktop application has been permanently disabled on certain versions of Windows 10. Go [here](http://aka.ms/iemodefaq)to learn more.
**Windows Server operating systems**
Expand table
Operating system | Internet Explorer version | Notes
---|---|---
Windows Server 2008 ESU | Internet Explorer 9 |
Windows Server 2008 IA64 (Itanium) ESU | Internet Explorer 9 |
Windows Server 2008 R2 ESU | Internet Explorer 11 |
Windows Server 2008 R2 IA64 (Itanium) ESU | Internet Explorer 11 |
Windows Server 2012 | Internet Explorer 11 | As of February 12, 2020,
IE10 is no longer
supported.
Windows Server 2012 R2 | Internet Explorer 11 |
Windows Server 2016 | Internet Explorer 11 |
Windows Server 2019 | Internet Explorer 11 |
Windows Server 2022 | Internet Explorer 11 |


**Windows Embedded operating systems**
Expand table
Operating system | Internet Explorer version | Notes
---|---|---
Windows Embedded Compact 2013  | Internet Explorer 7 |
Windows Embedded Standard 7 | Internet Explorer 11 |
Windows Embedded POSReady 7 | Internet Explorer 11 |
Windows Thin PC | Internet Explorer 11 | On January 10, 2017,
IE11 replaced IE8 on
Windows Thin PC.
Windows Embedded 8 Standard | Internet Explorer 11 | As of February 12, 2020,
IE10 is no longer
supported.
Windows 8.1 Industry Update | Internet Explorer 11 |
[](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#is-internet-explorer-11-the-last-version-of-internet-explorer-)
## Is Internet Explorer 11 the last version of Internet Explorer?
Yes, Internet Explorer 11 is the last major version of Internet Explorer. The Internet Explorer 11 desktop application went out of support for certain operating systems starting June 15, 2022*. Customers are encouraged to move to Microsoft Edge with Internet Explorer (IE) mode. IE mode provides built-in legacy browser support for sites requiring Internet Explorer. For supported operating systems, Internet Explorer 11 will continue receiving security updates and technical support for the lifecycle of the Windows version on which it is installed. See [above](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-internet-explorer-) for a list of supported operating systems for Internet Explorer by version.
*The retired, out-of-support Internet Explorer 11 (IE11) desktop application has been permanently disabled on certain versions of Windows 10. Go [here](https://techcommunity.microsoft.com/t5/windows-it-pro-blog/internet-explorer-11-desktop-app-retirement-faq/ba-p/2366549) to learn more.
[](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-if-my-enterprise-line-of-business--lob--application-has-a-dependency-on-a-version-of-internet-explorer-that-reached-end-of-support-)
## What if my enterprise line-of-business (LOB) application has a dependency on a version of Internet Explorer that reached end of support?
Microsoft is committed to supporting [Internet Explorer mode](https://learn.microsoft.com/en-us/DeployEdge/edge-ie-mode) in Microsoft Edge through at least 2029, on supported operating systems. Additionally, Microsoft will provide a minimum of one year notice prior to end of support for IE mode. Windows support dates are documented on the [Product Lifecycle](https://learn.microsoft.com/en-us/lifecycle/products/) page and may require an Extended Security Updates (ESU) license, if available, to receive operating system security updates beyond its End of Support date.




* * *
##  Additional resources
##  In this article
  1. [What is the Lifecycle policy for Microsoft Edge?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-microsoft-edge-)
  2. [What is the Lifecycle policy for Internet Explorer?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-is-the-lifecycle-policy-for-internet-explorer-)
  3. [Is Internet Explorer 11 the last version of Internet Explorer?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#is-internet-explorer-11-the-last-version-of-internet-explorer-)
  4. [What if my enterprise line-of-business (LOB) application has a dependency on a version of Internet Explorer that reached end of support?](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge#what-if-my-enterprise-line-of-business--lob--application-has-a-dependency-on-a-version-of-internet-explorer-that-reached-end-of-support-)


##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flifecycle%2Ffaq%2Finternet-explorer-microsoft-edge)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
