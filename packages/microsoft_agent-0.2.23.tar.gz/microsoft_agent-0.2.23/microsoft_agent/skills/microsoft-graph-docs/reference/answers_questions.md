[ Skip to main content ](https://learn.microsoft.com/en-us/answers/questions/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/questions/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/questions/)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
Microsoft Q&A
# Questions
Discover questions that will help you on every step of your technical journey.
Filters
## Filter
* * *
### Content
[ All questions 1.8M  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=null) [ No answers 88.3K  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=unanswered) [ Has answers 1.7M  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=answered) [ No answers or comments 38.8K  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=withoutengagement) [ With accepted answer 460.9K  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=withacceptedanswer) [ With recommended answer 1.3K  ](https://learn.microsoft.com/en-us/answers/questions/?filterby=withrecommendedanswer)
##  1,754,483 questions
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/questions/?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/questions/?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/questions/?orderby=answercount&page=1)
2 answers
##  [ Technical Support Request: Access Permission Issue for School Admin Account (Teams) ](https://learn.microsoft.com/en-us/answers/questions/5790772/technical-support-request-access-permission-issue)
Organization: Sinpyeong Elementary School (신평초등학교) Error Message: "You don't have the required permissions to access this organization." Context: Occurs when attempting to log in with the School Administrator account. Dear Technical…
Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in
[ Microsoft Teams | Microsoft Teams for education | Sign up and Sign in | Sign in ](https://learn.microsoft.com/en-us/answers/tags/1216/office-teams-teams-education-signup-signin-teams-signin/)
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
469 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:29 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(211.20000000000002,%2072%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EA%3C/text%3E%3C/svg%3E)
[신평초등학교 관리자](https://learn.microsoft.com/en-us/users/na/?userid=6eaecdd6-725e-42ea-930c-25f68ccf3694) 0 Reputation points
answered Feb 27, 2026, 1:21 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(288,%2047%,%2037%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKE%3C/text%3E%3C/svg%3E)
[Kai-Ex](https://learn.microsoft.com/en-us/users/na/?userid=ca90a479-9219-4b7f-8ff3-f1e571eae548) 735 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Azure AD B2C ](https://learn.microsoft.com/en-us/answers/questions/5789574/azure-ad-b2c)
Summary Azure AD B2C: PKCE & invalid_request errors during sign‑in with OIDC (Microsoft Entra ID) identity provider in User Flow B2C_1_NONMFA. Problem Description We are experiencing authentication failures when users attempt to sign in to our…
Microsoft Security | Microsoft Entra | Microsoft Entra External ID
[ Microsoft Security | Microsoft Entra | Microsoft Entra External ID ](https://learn.microsoft.com/en-us/answers/tags/438/microsoft-security-entra-entra-external-id/)
Managing external identities to enable secure access for partners, customers, and other non-employees
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
3,735 questions
Sign in to follow  Follow
asked Feb 26, 2026, 3:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(172.8,%2042%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFD%3C/text%3E%3C/svg%3E)
[Fispoke DevOps](https://learn.microsoft.com/en-us/users/na/?userid=deacc5ca-4425-4d38-a50f-92bef28b606a) 0 Reputation points
edited a comment Feb 27, 2026, 1:20 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(201.6,%2099%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ER%3C/text%3E%3C/svg%3E)
[Rukmini](https://learn.microsoft.com/en-us/users/na/?userid=c639f9a1-87b9-4d0c-bfee-c4222c264ad4) 27,760 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ BADGE NOT RECIVED YET. ](https://learn.microsoft.com/en-us/answers/questions/5790788/badge-not-recived-yet)
Hi, I have completed a certification Microsoft Certified: Power BI Data Analyst Associate, with credential IDEEF0911492767FF8. I have completion mail, passed mail. But i am not able to see the badge so that i can share with my peers. Could you help me…
Community Center | Not monitored
[ Community Center | Not monitored ](https://learn.microsoft.com/en-us/answers/tags/808/community-center-not-monitored/)
Tag not monitored by Microsoft.
![](https://learn.microsoft.com/answers/media/logo_communitycenterQnA.svg)
50,424 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%209%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKS%3C/text%3E%3C/svg%3E)
[Konda Sasi Snehith Reddy](https://learn.microsoft.com/en-us/users/na/?userid=b8d609c6-bba7-4e15-9ea6-8a159f8283e6) 0 Reputation points
edited the question Feb 27, 2026, 1:20 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(60.8,%2022%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJ%3C/text%3E%3C/svg%3E)
[JuliaMarvin](https://learn.microsoft.com/en-us/users/na/?userid=aa1b9228-6a1f-47ea-b871-bfdfeabc7b77) 18,370 Reputation points • Volunteer Moderator
0 answers
##  [ I have granted permission in App registration to an App but it is showing SMTP error ](https://learn.microsoft.com/en-us/answers/questions/5790793/i-have-granted-permission-in-app-registration-to-a)
We are integrating a PHP web application to send emails via SMTP using the modern OAuth 2.0 (XOAUTH2) flow for the account: ******@bayebusinesssolutions.com. The Issue: We have successfully registered the Azure App. We have successfully granted Admin…
Azure App Service
[ Azure App Service ](https://learn.microsoft.com/en-us/answers/tags/436/azure-app-service/)
Azure App Service is a service used to create and deploy scalable, mission-critical web apps.
9,719 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(252.8,%2071%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFB%3C/text%3E%3C/svg%3E)
[Faruq Bello](https://learn.microsoft.com/en-us/users/na/?userid=79f7b146-8c1b-46f7-8af9-12fa41d95406) 20 Reputation points
asked Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(252.8,%2071%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFB%3C/text%3E%3C/svg%3E)
[Faruq Bello](https://learn.microsoft.com/en-us/users/na/?userid=79f7b146-8c1b-46f7-8af9-12fa41d95406) 20 Reputation points
1 answer
##  [ mails from mx.easyname.com are not delivered ](https://learn.microsoft.com/en-us/answers/questions/5790792/mails-from-mx-easyname-com-are-not-delivered)
this ist this is the second time i do not get mails sent from a easyname.com domain, maybe you can whitelist 77.244.243.83 or all other mx.easyname.com IPs ? This message was created automatically by mail delivery software. A message that you sent has…
Microsoft 365 and Office | Other
[ Microsoft 365 and Office | Other ](https://learn.microsoft.com/en-us/answers/tags/1241/m365-office-other-l1/)
Miscellaneous topics that do not fit into specific categories.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
7,127 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(201.6,%2016%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EEF%3C/text%3E%3C/svg%3E)
[Erich Freunberger](https://learn.microsoft.com/en-us/users/na/?userid=caa63ff1-616b-4289-aacd-b475836a4786) 0 Reputation points
answered Feb 27, 2026, 1:19 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
2 answers
##  [ Purview Exchange Mailbox (at-rest) Data Discovery and Classification ](https://learn.microsoft.com/en-us/answers/questions/5789316/purview-exchange-mailbox-\(at-rest\)-data-discovery)
Hello, I understand that currently Purview Information Protection (auto-labeling policies with SIT's as criteria) and Purview eDiscovery and Content Search may have limitations to scanning and classifying content in Exchange online emailboxes at-rest. …
Microsoft Security | Microsoft Purview
[ Microsoft Security | Microsoft Purview ](https://learn.microsoft.com/en-us/answers/tags/819/microsoft-security-microsoft-purview/)
A unified data governance solution that helps manage, protect, and discover data across your organization
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,969 questions
Sign in to follow  Follow
asked Feb 25, 2026, 10:15 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(307.2,%2076%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EA%3C/text%3E%3C/svg%3E)
[AzGeek](https://learn.microsoft.com/en-us/users/na/?userid=967ce652-761b-47da-aafc-215e9c85e700) 0 Reputation points
commented Feb 27, 2026, 1:19 AM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/zVd80QAABgAAAAAAAAAAAA.png?8DDC07)
[Vasil Michev](https://learn.microsoft.com/en-us/users/na/?userid=d17c57cd-0000-0006-0000-000000000000) 125.1K Reputation points • MVP • Volunteer Moderator
1 answer
##  [ Connectivity issue with hosted server on hyper-v while migrating to azure using azure migrate ](https://learn.microsoft.com/en-us/answers/questions/5786149/connectivity-issue-with-hosted-server-on-hyper-v-w)
For testing purposes, we have deployed an Azure VM with the Hyper‑V role enabled and are hosting a Windows Server 2008 R2 SP1 virtual machine on it. We are now attempting to migrate the Server 2008 VM to Azure using the Azure Migrate appliance. The…
Azure Migrate
[ Azure Migrate ](https://learn.microsoft.com/en-us/answers/tags/116/azure-migrate/)
A central hub of Azure cloud migration services and tools to discover, assess, and migrate workloads to the cloud.
1,056 questions
Sign in to follow  Follow
asked Feb 24, 2026, 1:50 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2074%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMM%3C/text%3E%3C/svg%3E)
[Manvi MS Admin](https://learn.microsoft.com/en-us/users/na/?userid=f1bcbabd-67a4-40cc-acb0-4a07fd953b8b) 0 Reputation points
commented Feb 27, 2026, 1:19 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(51.2,%2074%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMM%3C/text%3E%3C/svg%3E)
[Manvi MS Admin](https://learn.microsoft.com/en-us/users/na/?userid=f1bcbabd-67a4-40cc-acb0-4a07fd953b8b) 0 Reputation points
1 answer
##  [ hp notbook touchpad gets stuc/goes inside briefly. later i need to press from diagnoally then it will come out ](https://learn.microsoft.com/en-us/answers/questions/5790773/hp-notbook-touchpad-gets-stuc-goes-inside-briefly)
hp notbook touchpad gets stuc/goes inside briefly. later i need to press from diagnoally then it will come out
Windows for home | Windows 11 | Performance and system failures
[ Windows for home | Windows 11 | Performance and system failures ](https://learn.microsoft.com/en-us/answers/tags/1129/windows-home-windows-11-platform-windows-performance/)
![](https://learn.microsoft.com/en-us/media/logos/logo_windows.svg)
30,676 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:45 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2064%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAH%3C/text%3E%3C/svg%3E)
[ABHISHEK H N](https://learn.microsoft.com/en-us/users/na/?userid=076409de-6b8d-470b-baba-773eb21b5bd2) 0 Reputation points
answered Feb 27, 2026, 1:18 AM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/e8d00f0b575241fe8433069a7a2c2c78.png)
[DaveM121](https://learn.microsoft.com/en-us/users/na/?userid=873f553c-11b8-4f5c-b034-14c0940062ff) 846.3K Reputation points • Independent Advisor
3 answers
##  [ I need to reinstall Office 2021 on a new computer, not Office 2024 ](https://learn.microsoft.com/en-us/answers/questions/5790686/i-need-to-reinstall-office-2021-on-a-new-computer)
I have tried twice to install my old Office 2021 on a new refurbished computer. The download goes to the 2024 version, not the 2021 version and this computer cannot upgrade to a later OS. How do I install the Office 2021 that I had before? (I use Word,…
Microsoft 365 and Office | Word | For home | MacOS
[ Microsoft 365 and Office | Word | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1484/m365-office-office-word-home-macos/)
A family of Microsoft word processing software products for creating web, email, and print documents.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
4,172 questions
Sign in to follow  Follow
asked Feb 26, 2026, 10:04 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(192,%200%,%2028%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFF%3C/text%3E%3C/svg%3E)
[Felicity Fedele](https://learn.microsoft.com/en-us/users/na/?userid=6c0d0aa0-fa77-4319-88a9-99cd695defb5) 0 Reputation points
answered Feb 27, 2026, 1:17 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(192,%200%,%2028%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EFF%3C/text%3E%3C/svg%3E)
[Felicity Fedele](https://learn.microsoft.com/en-us/users/na/?userid=6c0d0aa0-fa77-4319-88a9-99cd695defb5) 0 Reputation points
1 answer
##  [ Not get 1 year of LinkedIn Premium benefit after purchasing Microsoft 365 Premium ](https://learn.microsoft.com/en-us/answers/questions/5790357/not-get-1-year-of-linkedin-premium-benefit-after-p)
Hi team, I hope you are doing well. I redeemed the "1 year Microsoft 365 Premium + LinkedIn Premium" benefit through link:…
Microsoft 365 and Office | Install, redeem, activate | For home | MacOS
[ Microsoft 365 and Office | Install, redeem, activate | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1528/m365-office-install-redeem-activate-home-macos/)
Processes in Microsoft 365 for setting up Office apps, redeeming product keys, and activating licenses.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,952 questions
Sign in to follow  Follow
asked Feb 26, 2026, 2:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(246.4,%2077%,%2033%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAM%3C/text%3E%3C/svg%3E)
[Alexa Miao](https://learn.microsoft.com/en-us/users/na/?userid=c7c77a77-a133-43a0-9c2a-847793634cc5) 0 Reputation points
edited the question Feb 27, 2026, 1:16 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Outlook / Emails ](https://learn.microsoft.com/en-us/answers/questions/5790732/outlook-emails)
Hello, I'm writing about the New Outlook. I have trouble in relation to my mailbox. Not all of the emails reach my mailbox. Also, I noticed a gap between the time an email is sent and the time it lands into my mailbox. Might my mailbox be corrupted ?…
Outlook | Windows | New Outlook for Windows | For home
[ Outlook | Windows | New Outlook for Windows | For home ](https://learn.microsoft.com/en-us/answers/tags/1551/office-outlook-platform-windows-new-outlook-windows-home/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
10,706 questions
Sign in to follow  Follow
asked Feb 26, 2026, 11:36 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(35.2,%2064%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ES%3C/text%3E%3C/svg%3E)
[si84m](https://learn.microsoft.com/en-us/users/na/?userid=d1164e18-091f-4dcf-a290-9d31e2e866b8) 0 Reputation points
answered Feb 27, 2026, 1:16 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(22.400000000000002,%2081%,%2012%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAD%3C/text%3E%3C/svg%3E)
[Arlene D](https://learn.microsoft.com/en-us/users/na/?userid=078c1776-0761-4eaa-8796-f350ab4d2851) 29,450 Reputation points • Independent Advisor
1 answer
##  [ Lock Screen - Folder isn't supported because of its location. - ](https://learn.microsoft.com/en-us/answers/questions/5544055/lock-screen-folder-isnt-supported-because-of-its-l)
Windows 11 Pro. I've adjusted my Lock Screen such that photos are displayed while the computer screen is locked. This works and appears to use the following directory: C:\Users<user profile><OneDrive>\Pictures However, if I try a…
Windows for business | Windows 365 Business
[ Windows for business | Windows 365 Business ](https://learn.microsoft.com/en-us/answers/tags/287/windows-business-windows365-business/)
![](https://learn.microsoft.com/en-us/media/logos/logo_windows.svg)
2,156 questions
Sign in to follow  Follow
asked Sep 3, 2025, 11:40 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(227.2,%202%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ED%3C/text%3E%3C/svg%3E)
[=D](https://learn.microsoft.com/en-us/users/na/?userid=fa710cbd-2e45-4d47-acb8-7271f1f7474e) 100 Reputation points
commented Feb 27, 2026, 1:15 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%2016%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EA%3C/text%3E%3C/svg%3E)
[Azura](https://learn.microsoft.com/en-us/users/na/?userid=a8c61af6-7cac-454d-b563-f90f63c3aaf7) 0 Reputation points
1 answer
##  [ Windows 11 VPN Connection - The L2TP connection attempt failed because the security layer ](https://learn.microsoft.com/en-us/answers/questions/5790176/windows-11-vpn-connection-the-l2tp-connection-atte)
Hi, I am trying to connect VPN via WireGaurd that used to work before. I can see that my wireguard is activated and it's sending and receiving handshakes but when I try to connect to vpn I'm getting this error: Windows 11 VPN Connection Error: The L2TP…
Windows for business | Windows 365 Business
[ Windows for business | Windows 365 Business ](https://learn.microsoft.com/en-us/answers/tags/287/windows-business-windows365-business/)
![](https://learn.microsoft.com/en-us/media/logos/logo_windows.svg)
2,156 questions
Sign in to follow  Follow
asked Feb 26, 2026, 11:35 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(102.4,%2035%,%2019%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ETS%3C/text%3E%3C/svg%3E)
[Tanima Sonar](https://learn.microsoft.com/en-us/users/na/?userid=3c235fd3-aa8a-412d-9361-edb26003e46d) 0 Reputation points
answered Feb 27, 2026, 1:15 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(134.4,%2047%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ED%3C/text%3E%3C/svg%3E)
[DustinTran](https://learn.microsoft.com/en-us/users/na/?userid=e424e7ce-798b-419b-a94b-2599fba04484) 445 Reputation points • Moderator
0 answers
##  [ Not open Windows Micro Soft Office ](https://learn.microsoft.com/en-us/answers/questions/5790789/not-open-windows-micro-soft-office)
Not open Windows Micro Soft Office excel so need some help
Microsoft 365 and Office | Excel | For business | Windows
[ Microsoft 365 and Office | Excel | For business | Windows ](https://learn.microsoft.com/en-us/answers/tags/379/m365-office-office-excel-business-platform-windows/)
A family of Microsoft spreadsheet software with tools for analyzing, charting, and communicating data
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
20,220 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(89.60000000000001,%2043%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESP%3C/text%3E%3C/svg%3E)
[sakthi p](https://learn.microsoft.com/en-us/users/na/?userid=28437a62-1a31-4177-81ea-8e2860505332) 0 Reputation points
asked Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(89.60000000000001,%2043%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESP%3C/text%3E%3C/svg%3E)
[sakthi p](https://learn.microsoft.com/en-us/users/na/?userid=28437a62-1a31-4177-81ea-8e2860505332) 0 Reputation points
1 answer
##  [ hi team yesterday night i cleared the mb820 exam but still not able to see cerificate ](https://learn.microsoft.com/en-us/answers/questions/5790684/hi-team-yesterday-night-i-cleared-the-mb820-exam-b)
cerificate issue of mb820 which i was cleared yesterday bt still not able to see cerificate Moved from Microsoft 365 and Office | Other
Community Center | Not monitored
[ Community Center | Not monitored ](https://learn.microsoft.com/en-us/answers/tags/808/community-center-not-monitored/)
Tag not monitored by Microsoft.
![](https://learn.microsoft.com/answers/media/logo_communitycenterQnA.svg)
50,424 questions
Sign in to follow  Follow
asked Feb 26, 2026, 10:00 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(240,%2055.00000000000001%,%2033%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAA%3C/text%3E%3C/svg%3E)
[AKSHATHA A](https://learn.microsoft.com/en-us/users/na/?userid=75eecef5-5ab9-429c-8ed7-f0c3a9543a43) 0 Reputation points
edited the question Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(230.39999999999998,%2049%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EIT%3C/text%3E%3C/svg%3E)
[Ian-T](https://learn.microsoft.com/en-us/users/na/?userid=7249daf2-daa1-403f-b371-74e08ef8246e) 7,375 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ how do I mirror pc on tv ](https://learn.microsoft.com/en-us/answers/questions/5790787/how-do-i-mirror-pc-on-tv)
Don't know where to find mirroring on pc to broadcast to tv
Windows for home | Windows 11 | Apps
[ Windows for home | Windows 11 | Apps ](https://learn.microsoft.com/en-us/answers/tags/273/windows-home-windows-11-platform-apps/)
![](https://learn.microsoft.com/en-us/media/logos/logo_windows.svg)
1,875 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:12 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%2018%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGN%3C/text%3E%3C/svg%3E)
[Greg N](https://learn.microsoft.com/en-us/users/na/?userid=8ea618ea-9108-48c8-80b8-4bc34c7341f1) 0 Reputation points
answered Feb 27, 2026, 1:12 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
1 answer
##  [ Newly registered personal Outlook email accounts cannot pass SMTP authentication when using MailKit ](https://learn.microsoft.com/en-us/answers/questions/5790786/newly-registered-personal-outlook-email-accounts-c)
Hello, I recently created a new personal Outlook mailbox in 2026. The following method fails to authenticate, whereas previously created mailboxes work fine with the same approach: using (var client = new…
Developer technologies | C#
[ Developer technologies | C# ](https://learn.microsoft.com/en-us/answers/tags/823/developer-technologies-csharp/)
An object-oriented and type-safe programming language that has its roots in the C family of languages and includes support for component-oriented programming.
11,801 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:12 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(185.6,%2077%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESL%3C/text%3E%3C/svg%3E)
[shen li](https://learn.microsoft.com/en-us/users/na/?userid=58776517-5fdc-4d66-8db5-2d5639c32293) 0 Reputation points
answered Feb 27, 2026, 1:12 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
0 answers
##  [ How to change password in email account Outlook account ](https://learn.microsoft.com/en-us/answers/questions/5790784/how-to-change-password-in-email-account-outlook-ac)
Unable to login somebody change outlook email password Moved from Microsoft 365 Insider | Install, activate, and update | Windows
Outlook | Web | Outlook.com | Account management, security, and privacy
[ Outlook | Web | Outlook.com | Account management, security, and privacy ](https://learn.microsoft.com/en-us/answers/tags/1466/office-outlook-web-outlook-dotcom-outlook-account/)
![](https://learn.microsoft.com/answers/media/logo_outlook.svg)
20,525 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:10 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(304,%2027%,%2039%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMB%3C/text%3E%3C/svg%3E)
[Michael Barroquillo](https://learn.microsoft.com/en-us/users/na/?userid=f9b52713-1a0f-443f-850b-9d2f03e915d9) 0 Reputation points
edited the question Feb 27, 2026, 1:12 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(230.39999999999998,%2049%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EIT%3C/text%3E%3C/svg%3E)
[Ian-T](https://learn.microsoft.com/en-us/users/na/?userid=7249daf2-daa1-403f-b371-74e08ef8246e) 7,375 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Domain name cannot obtain verification DNS record information immediately after creation via Graph API. ](https://learn.microsoft.com/en-us/answers/questions/5790709/domain-name-cannot-obtain-verification-dns-record)
I create domain via Graph API : POST https://graph.microsoft.com/v1.0/domains, After response 201 created. I can't immediately get the domain info via Graph Get https://graph.microsoft.com/v1.0/domains/{domain} and Graph Get…
Microsoft Teams | Development
[ Microsoft Teams | Development ](https://learn.microsoft.com/en-us/answers/tags/339/office-teams-development-routing/)
Building, integrating, or customizing apps and workflows within Microsoft Teams using developer tools and APIs
![](https://learn.microsoft.com/answers/media/logo_teams.svg)
4,822 questions
Sign in to follow  Follow
asked Feb 26, 2026, 11:01 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(64,%2044%,%2016%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ELS%3C/text%3E%3C/svg%3E)
[Lin Sun](https://learn.microsoft.com/en-us/users/na/?userid=a20d4ac4-4003-46dc-9a93-56bb4f851ffb) 0 Reputation points
answered Feb 27, 2026, 1:11 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2054%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESN%3C/text%3E%3C/svg%3E)
[Steven-N](https://learn.microsoft.com/en-us/users/na/?userid=105e4edd-52b2-49a4-81fb-896b4e431f97) 21,000 Reputation points • Microsoft External Staff • Moderator
One of the answers was accepted by the question author.
##  [ Locked out of Microsoft 365 Admin portal ](https://learn.microsoft.com/en-us/answers/questions/5790751/locked-out-of-microsoft-365-admin-portal)
Hello there. We accidentally enabled MFA for Phishing resistance for Admin accounts and currently locked out. ******@companydomain.com You can't get there from here Additional sign-in methods are required to access this resource. Contact your…
Microsoft Security | Microsoft Entra | Microsoft Entra ID
[ Microsoft Security | Microsoft Entra | Microsoft Entra ID ](https://learn.microsoft.com/en-us/answers/tags/455/microsoft-security-entra-entra-id/)
A cloud-based identity and access management service for securing user authentication and resource access
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
29,066 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:07 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(166.4,%2040%,%2026%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGN%3C/text%3E%3C/svg%3E)
[Gilbert Ngetich](https://learn.microsoft.com/en-us/users/na/?userid=cbc524ed-0000-0003-0000-000000000000) 0 Reputation points
edited an answer Feb 27, 2026, 1:10 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(201.6,%2099%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ER%3C/text%3E%3C/svg%3E)
[Rukmini](https://learn.microsoft.com/en-us/users/na/?userid=c639f9a1-87b9-4d0c-bfee-c4222c264ad4) 27,760 Reputation points • Microsoft External Staff • Moderator
  * [ ](https://learn.microsoft.com/en-us/answers/questions/?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/questions/?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/questions/?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/questions/?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/questions/?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/questions/?page=4)
  * ...
  * [ 87725 ](https://learn.microsoft.com/en-us/answers/questions/?page=87725)
  * [ ](https://learn.microsoft.com/en-us/answers/questions/?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Fquestions%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
