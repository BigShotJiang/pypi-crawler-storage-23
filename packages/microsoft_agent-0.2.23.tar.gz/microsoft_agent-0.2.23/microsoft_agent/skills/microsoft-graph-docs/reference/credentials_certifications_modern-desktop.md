[ Skip to main content ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification)
[ Credentials  ](https://learn.microsoft.com/en-us/credentials/)
  * [ Browse Credentials ](https://learn.microsoft.com/en-us/credentials/browse)
  * [ Certification Renewals ](https://learn.microsoft.com/en-us/certifications/renew-your-microsoft-certification)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/certifications/help/)
  * More
    * [ Browse Credentials ](https://learn.microsoft.com/en-us/credentials/browse)
    * [ Certification Renewals ](https://learn.microsoft.com/en-us/certifications/renew-your-microsoft-certification)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/certifications/help/)


[ Read in English ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations) Add to Collections Add to plan
![](https://learn.microsoft.com/en-us/media/learn/certification/badges/microsoft-certified-associate-badge.svg)
Certification
# Microsoft 365 Certified: Endpoint Administrator Associate
Plan and execute an endpoint deployment strategy, using essential elements of modern management, co-management approaches, and Microsoft Intune integration.
Congratulations
You've earned this credential
* * *
[View my credential](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification)
##  At a glance
  * Level
[Intermediate](https://learn.microsoft.com/en-us/credentials/browse/?levels=intermediate&credential_types=certification)
  * Product
[Microsoft 365](https://learn.microsoft.com/en-us/credentials/browse/?products=m365&credential_types=certification)
  * Role
[Administrator](https://learn.microsoft.com/en-us/credentials/browse/?roles=administrator&credential_types=certification)
  * Renewal Frequency
12 months
  * Last Updated
01/23/2026


## Jump to
[Prepare for the exam](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#certification-prepare-for-the-exam)
[Practice for the exam](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#certification-practice-for-the-exam)
[Take the exam](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#certification-take-the-exam)
[Renew your certification](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#certification-renew-your-certification)
[Certification resources](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#certification-resources)
Show more
## Overview
As a candidate for this certification, you have subject matter expertise managing devices and client applications in a Microsoft 365 tenant by using Microsoft Intune. You’re responsible for:
  * Implementing solutions for efficient deployment and management of endpoints on various operating systems, platforms, and device types.
  * Implementing and managing endpoints at scale by using Microsoft Intune, Microsoft Intune Suite, Windows Autopilot, Microsoft Copilot for Security, Microsoft Defender for Endpoint, Microsoft Entra ID, Azure Virtual Desktop, and Windows 365.
  * Implementing identity, security, access, policies, updates, and apps for endpoints.


As an endpoint administrator, you collaborate with architects, Microsoft 365 administrators, security administrators, and other workload administrators to plan and implement a modern workplace strategy that meets the business needs of an organization.
You must have experience with Microsoft Entra ID and Microsoft 365 technologies, including Intune, as well as strong skills and experience in deploying, configuring, and maintaining Windows client and non-Windows devices.
###  Skills earned upon completion
  * [ Manage authentication and compliance in Windows ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#list-card-ax-8)
  * [ Manage endpoint security using Intune ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/?source=recommendations&practice-assessment-type=certification#list-card-ax-9)


## Prepare for the exam
Hide completed
  * ![](https://learn.microsoft.com/media/learn/credential/badges/course.svg)
Course
[Microsoft 365 Endpoint Administrator](https://learn.microsoft.com/en-us/training/courses/md-102t00/)
[ Continue course ](https://learn.microsoft.com/en-us/training/courses/md-102t00/)
Training in this course
    * ![](https://learn.microsoft.com/training/achievements/explore-endpoint-management.svg)
[MD-102 Explore endpoint management](https://learn.microsoft.com/training/paths/explore-endpoint-management/)
      * Learning Path
      * 4 modules
    * ![](https://learn.microsoft.com/training/achievements/execute-device-enrollment.svg)
[MD-102 Execute device enrollment](https://learn.microsoft.com/training/paths/execute-device-enrollment/)
      * Learning Path
      * 3 modules
    * ![](https://learn.microsoft.com/training/achievements/onfigure-profiles-user-device.svg)
[MD-102 Configure profiles for user and devices](https://learn.microsoft.com/training/paths/configure-profiles-user-device/)
      * Learning Path
      * 3 modules
    * ![](https://learn.microsoft.com/training/achievements/examine-application-management.svg)
[MD-102 Examine application management](https://learn.microsoft.com/training/paths/examine-application-management/)
      * Learning Path
      * 3 modules
    * ![](https://learn.microsoft.com/training/achievements/authentication-compliance.svg)
[MD-102 Manage authentication and compliance](https://learn.microsoft.com/training/paths/authentication-compliance/)
      * Learning Path
      * 4 modules
Manage authentication and complian...
##  Skill
Manage authentication and compliance in Windows
    * ![](https://learn.microsoft.com/training/achievements/manage-endpoint-security.svg)
[MD-102 Manage endpoint security](https://learn.microsoft.com/training/paths/manage-endpoint-security/)
      * Learning Path
      * 4 modules
Manage endpoint security using Int...
##  Skill
Manage endpoint security using Intune
    * ![](https://learn.microsoft.com/training/achievements/deploy-on-premise-based-tools.svg)
[MD-102 Deploy using on-premises based tools](https://learn.microsoft.com/training/paths/deploy-on-premise-based-tools/)
      * Learning Path
      * 3 modules
    * ![](https://learn.microsoft.com/training/achievements/generic-trophy.svg)
[MD-102 Deploy using cloud based tools](https://learn.microsoft.com/training/paths/deploy-cloud-based-tools/)
      * Learning Path
      * 6 modules
See more
Add
Add to Collections Add to plan


## Practice for the exam
![](https://learn.microsoft.com/en-us/media/learn/certification/icons/exam.svg?branch=main)
Practice Assessment
Assess your knowledge
Practice assessments provide you with an overview of the style, wording, and difficulty of the questions you're likely to experience on the exam. Through these assessments, you're able to assess your readiness, determine where additional preparation is needed, and fill knowledge gaps bringing you one step closer to the likelihood of passing your exam.
[Take the practice assessment](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/practice/assessment?assessment-type=practice&assessmentId=76&practice-assessment-type=certification)
Previous attempts
See reports of your previous attempts.
![](https://learn.microsoft.com/en-us/media/learn/certification/icons/learning-lab.svg?branch=main)
Exam Sandbox
Experience demo
Experience the look and feel of the exam before taking it. You'll be able to interact with different question types in the same user interface you'll use during the exam.
[Launch the sandbox](https://go.microsoft.com/fwlink/?linkid=2226877)
## Take the exam
You will have 100 minutes to complete this assessment.
Exam policy
This exam will be proctored. You may have interactive components to complete as part of this exam. To learn more about exam duration and experience, visit: [Exam duration and exam experience](https://learn.microsoft.com/en-us/credentials/support/exam-duration-exam-experience).
If you fail a certification exam, don’t worry. You can retake it 24 hours after the first attempt. For subsequent retakes, the amount of time varies. For full details, visit: [Exam retake policy](https://learn.microsoft.com/en-us/credentials/support/retake-policy).
Assessed on this exam
  * Prepare infrastructure for devices
  * Manage and maintain devices
  * Manage applications
  * Protect devices


Need accommodations?
We offer a variety of accommodations to support you.
[Learn More](https://learn.microsoft.com/en-us/credentials/certifications/accommodations)
This exam is offered in the following languages:
English, Chinese (Simplified), German, Spanish, French, Japanese, Portuguese (Brazil)
Schedule through Pearson Vue
[ Schedule exam ](https://learn.microsoft.com/en-us/credentials/certifications/schedule-through-pearson-vue?examUid=exam.MD-102&examUrl=https://learn.microsoft.com/credentials/certifications)
We strongly recommend that you register for an exam with a personal MSA account. If you register with an organizational (work/school) AAD account, your exam records will be lost if you leave your organization and they will be unrecoverable.
Afghanistan  Aland Islands  Albania  Algeria  American Samoa  Andorra  Angola  Anguilla  Antarctica  Antigua and Barbuda  Argentina  Armenia  Aruba  Australia  Austria  Azerbaijan  Bahamas, The  Bahrain  Bangladesh  Barbados  Belarus  Belgium  Belize  Benin  Bermuda  Bhutan  Bolivia  Bonaire Saint Eustatius and Saba  Bosnia and Herzegovina  Botswana  Bouvet Island  Brazil  British Indian Ocean Territory  British Virgin Islands  Brunei  Bulgaria  Burkina Faso  Burundi  Cambodia  Cameroon  Canada  Cape Verde  Cayman Islands  Central African Republic  Chad  Chile  China  Christmas Island  Cocos (Keeling) Islands  Colombia  Comoros  Congo  Congo (DRC)  Cook Islands  Costa Rica  Côte d'Ivoire  Croatia  Curaçao  Cyprus  Czech Republic  Denmark  Djibouti  Dominica  Dominican Republic  Ecuador  Egypt  El Salvador  Equatorial Guinea  Eritrea  Estonia  Ethiopia  Falkland Islands  Faroe Islands  Fiji  Finland  France  French Guiana  French Polynesia  French Southern Territories  Gabon  Gambia  Georgia  Germany  Ghana  Gibraltar  Greece  Greenland  Grenada  Guadeloupe  Guam  Guatemala  Guernsey  Guinea  Guinea-Bissau  Guyana  Haiti  Heard Island / McDonald Islands  Honduras  Hong Kong SAR  Hungary  Iceland  India  Indonesia  Iraq  Ireland  Isle of Man  Israel  Italy  Jamaica  Japan  Jersey  Jordan  Kazakhstan  Kenya  Kiribati  Korean  Kuwait  Kyrgyzstan  Laos  Latvia  Lebanon  Lesotho  Liberia  Libya  Liechtenstein  Lithuania  Luxembourg  Macao SAR  Macedonia FYRO  Madagascar  Malawi  Malaysia  Maldives  Mali  Malta  Marshall Islands  Martinique  Mauritania  Mauritius  Mayotte  Mexico  Micronesia  Moldova  Monaco  Mongolia  Montenegro  Montserrat  Morocco  Mozambique  Myanmar  Namibia  Nauru  Nepal  Netherlands  New Caledonia  New Zealand  Nicaragua  Niger  Nigeria  Niue  Norfolk Island  Northern Mariana Islands  Norway  Oman  Pakistan  Palau  Palestine, State of  Panama  Papua New Guinea  Paraguay  Peru  Philippines  Pitcairn  Poland  Portugal  Puerto Rico  Qatar  Réunion  Romania  Russia  Rwanda  Saint Barthelemy  Saint Kitts and Nevis  Saint Lucia  Saint Martin  Saint Vincent and the Grenadines  Samoa  San Marino  Sao Tome and Principe  Saudi Arabia  Schweiz / Suisse  Senegal  Serbia  Seychelles  Sierra Leone  Singapore  Sint Maarten  Slovakia  Slovenia  Solomon Islands  Somalia  South Africa  South Georgia and the South Sandwich Islands  South Sudan  Spain  Sri Lanka  St. Helena  St. Pierre and Miquelon  Suriname  Svalbard and Jan Mayen  Swaziland  Sweden  Taiwan  Tajikistan  Tanzania  Thailand  Timor-Leste  Togo  Tokelau  Tonga  Trinidad and Tobago  Tunisia  Turkey  Turkmenistan  Turks and Caicos Islands  Tuvalu  Uganda  Ukraine  United Arab Emirates  United Kingdom  United States  Uruguay  US Minor Outlying Islands  US Virgin Islands  Uzbekistan  Vanuatu  Vatican City State  Venezuela  Vietnam  Wallis and Futuna Islands  Yemen  Zambia  Zimbabwe
$165 USD*
Price based on the country or region in which the exam is proctored.
## Renew your certification
Do you know that Microsoft role-based and specialty certifications expire unless they are renewed? Learn the latest updates to the technology for your job role and renew your certification at no cost by passing an online assessment on Microsoft Learn.
[Learn more about renewing ](https://learn.microsoft.com/en-us/credentials/certifications/modern-desktop/renew/)
## Certification resources
[Exam MD-102 study guide](https://aka.ms/md102-StudyGuide)
Focus your studies as you prepare for the exam. Review the study guide to learn about the topics the exam covers, updates, and additional resources.
[Certification poster](https://arch-center.azureedge.net/Credentials/Certification-Poster_en-us.pdf)
Check out an overview of fundamentals, role-based, and specialty certifications.
[Exam Replay](https://learn.microsoft.com/en-us/credentials/certifications/deals)
Boost your odds of success with this great offer.
[Support for credentials](https://learn.microsoft.com/en-us/credentials/support/help)
Get help through Microsoft Credentials support forums. A forum moderator will respond in one business day, Monday–Friday.
[Choose your Microsoft Credential](https://arch-center.azureedge.net/Credentials/choose-your-microsoft-credential.pdf)
Microsoft Applied Skills or Microsoft Certifications? Choose the path that fits your career goals, desired skillset, and schedule.
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fcredentials%2Fcertifications%2Fmodern-desktop%2F%3Fsource%3Drecommendations)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
