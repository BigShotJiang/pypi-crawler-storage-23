[ Skip to main content ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0#main)
AI Apps & Agents Dev Days: Experiment with what's next in AI-driven apps and agent design [ Register now ](https://aka.ms/AIAppsandAgentsLearn) Dismiss alert
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview?view=graph-rest-1.0)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach?view=graph-rest-1.0)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments?view=graph-rest-1.0)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support?view=graph-rest-1.0)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph%2Fcontext&view=graph-rest-1.0)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services?view=graph-rest-1.0)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview?view=graph-rest-1.0)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?view=graph-rest-1.0)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview?view=graph-rest-1.0)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview?view=graph-rest-1.0)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview?view=graph-rest-1.0)
  *     *       * [Overview](https://learn.microsoft.com/en-us/graph/auth/?view=graph-rest-1.0)
      * [Basics](https://learn.microsoft.com/en-us/graph/auth/auth-concepts?view=graph-rest-1.0)
      * [Register your app](https://learn.microsoft.com/en-us/graph/auth-register-app-v2?view=graph-rest-1.0)
      * [Get access on behalf of a user](https://learn.microsoft.com/en-us/graph/auth-v2-user?view=graph-rest-1.0)
      * [Get access without a user](https://learn.microsoft.com/en-us/graph/auth-v2-service?view=graph-rest-1.0)
      * [Manage app access (CSPs)](https://learn.microsoft.com/en-us/graph/auth-cloudsolutionprovider?view=graph-rest-1.0)
      * [Limit mailbox access](https://learn.microsoft.com/en-us/exchange/permissions-exo/application-rbac?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
      * [Resolve authorization errors](https://learn.microsoft.com/en-us/graph/resolve-auth-errors?view=graph-rest-1.0)
    * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview?view=graph-rest-1.0)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services?view=graph-rest-1.0)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept?view=graph-rest-1.0)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors?view=graph-rest-1.0)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=%2Fgraph%2Ftoc.json&view=graph-rest-1.0)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
  1. [ Learn ](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


  1. [Learn](https://learn.microsoft.com/en-us/?view=graph-rest-1.0)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/?view=graph-rest-1.0)


Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/auth/?context=graph%2Fapi%2F1.0&view=graph-rest-1.0) [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/auth/index.yml)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fauth%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fauth%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fauth%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fauth%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0%26WT.mc_id%3Dlinkedin) Email
# Microsoft Graph authentication and authorization overview
Learn how to authenticate and get your app authorized to securely access data through Microsoft Graph. Explore concepts for building and authorizing apps that call Microsoft Graph, and efficiently managing app access.
## Get started
  * [Authentication and authorization basics](https://learn.microsoft.com/en-us/graph/auth/auth-concepts)
  * [App registration](https://learn.microsoft.com/en-us/graph/auth-register-app-v2)
  * [Choose an authentication provider](https://learn.microsoft.com/en-us/graph/sdks/choose-authentication-providers)
  * [Permissions overview](https://learn.microsoft.com/en-us/graph/permissions-overview)


  * [Microsoft Graph and app registration (7:29)](https://www.youtube.com/watch?v=93j0MmRruFo)


## Authorize your app
  * [Get access on behalf of a user](https://learn.microsoft.com/en-us/graph/auth-v2-user)
  * [Get access without a user](https://learn.microsoft.com/en-us/graph/auth-v2-service)


  * [Permissions reference](https://learn.microsoft.com/en-us/graph/permissions-reference)


## Manage your app
  * [Manage app access](https://learn.microsoft.com/en-us/graph/auth-cloudsolutionprovider)
  * [Limit mailbox access](https://learn.microsoft.com/en-us/graph/auth-limit-mailbox-access)
  * [Manage throttling](https://learn.microsoft.com/en-us/graph/throttling)
  * [Use query parameters](https://learn.microsoft.com/en-us/graph/query-parameters)


  * [Error responses](https://learn.microsoft.com/en-us/graph/errors)
  * [Authorization errors](https://learn.microsoft.com/en-us/graph/resolve-auth-errors)
  * [Service-specific throttling limits](https://learn.microsoft.com/en-us/graph/throttling-limits)


## Auth SDKs - MSAL
  * [Android](https://github.com/AzureAD/microsoft-authentication-library-for-android)
  * [Angular](https://github.com/AzureAD/microsoft-authentication-library-for-js)
  * [ASP.NET](https://github.com/AzureAD/microsoft-authentication-library-for-dotnet)
  * [iOS](https://github.com/AzureAD/microsoft-authentication-library-for-objc)
  * [JavaScript](https://github.com/AzureAD/microsoft-authentication-library-for-js)
  * [Python](https://github.com/AzureAD/microsoft-authentication-library-for-python)
  * [UWP](https://github.com/AzureAD/microsoft-authentication-library-for-dotnet)
  * [Xamarin](https://github.com/AzureAD/microsoft-authentication-library-for-dotnet)


## Auth SDKs - Open source
  * [Android](https://github.com/openid/AppAuth-Android)
  * [iOS](https://github.com/openid/AppAuth-iOS)
  * [Java](https://github.com/scribejava/scribejava)
  * [JavaScript](https://adodson.com/hello.js/)
  * [Node.js](https://github.com/panva/node-openid-client)
  * [PHP](https://github.com/thephpleague/oauth2-client)
  * [Python](https://github.com/requests/requests-oauthlib)
  * [Ruby](https://github.com/omniauth/omniauth/wiki)
  * [React Native](https://github.com/FormidableLabs/react-native-app-auth)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fauth%2F%3Fcontext%3Dgraph%252Fapi%252F1.0%26view%3Dgraph-rest-1.0)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
