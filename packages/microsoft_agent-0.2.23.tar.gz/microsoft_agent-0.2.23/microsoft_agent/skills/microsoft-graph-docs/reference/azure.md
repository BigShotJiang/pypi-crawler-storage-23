[ Skip to main content ](https://learn.microsoft.com/en-us/azure/?product=popular#main)
Agents League: Join the AI Agents Challenge from Feb 16-27. Build agents, watch live competitions, win prizes. [ Learn more ](https://aka.ms/agentsleague?wt.mc_id=agentsleague_learnpromo_1pevents_cxa_learncomm) Dismiss alert
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/azure/?product=popular)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/azure/?product=popular)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/azure/?product=popular)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/azure/?product=popular)
[ Azure  ](https://learn.microsoft.com/en-us/azure/)
  * Products
    * Popular products
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/azure/ai-foundry/)
      * [ Azure App Service ](https://learn.microsoft.com/en-us/azure/app-service/)
      * [ Azure Databricks ](https://learn.microsoft.com/en-us/azure/databricks/)
      * [ Azure DevOps ](https://learn.microsoft.com/en-us/azure/devops/)
      * [ Azure Functions ](https://learn.microsoft.com/en-us/azure/azure-functions/)
      * [ Azure Monitor ](https://learn.microsoft.com/en-us/azure/azure-monitor/)
      * [ Azure Virtual Machines ](https://learn.microsoft.com/en-us/azure/virtual-machines/)
    * Popular categories
      * [ Compute ](https://learn.microsoft.com/en-us/azure/?product=compute)
      * [ Networking ](https://learn.microsoft.com/en-us/azure/?product=networking)
      * [ Storage ](https://learn.microsoft.com/en-us/azure/?product=storage)
      * [ AI & machine learning ](https://learn.microsoft.com/en-us/azure/?product=ai-machine-learning)
      * [ Analytics ](https://learn.microsoft.com/en-us/azure/?product=analytics)
      * [ Databases ](https://learn.microsoft.com/en-us/azure/?product=databases)
      * [ Security ](https://learn.microsoft.com/en-us/azure/?product=security)
    * [ View all products ](https://learn.microsoft.com/en-us/azure/)
  * Architecture
    * [ Cloud Adoption Framework ](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/)
    * [ Well-Architected Framework ](https://learn.microsoft.com/en-us/azure/well-architected/)
    * [ Azure Architecture Center ](https://learn.microsoft.com/en-us/azure/architecture/)
  * Develop
    * [ Python ](https://learn.microsoft.com/en-us/azure/developer/python/)
    * [ .NET ](https://learn.microsoft.com/en-us/dotnet/azure/)
    * [ JavaScript ](https://learn.microsoft.com/en-us/azure/developer/javascript/)
    * [ Java ](https://learn.microsoft.com/en-us/azure/developer/java/)
    * [ PowerShell ](https://learn.microsoft.com/en-us/powershell/azure/)
    * [ Azure CLI ](https://learn.microsoft.com/en-us/cli/azure/)
    * [ View all developer resources ](https://learn.microsoft.com/en-us/azure/developer/)
  * Learn Azure
    * [ Start your AI learning assessment ](https://learn.microsoft.com/en-us/assessments/1c032171-8ca0-4032-8962-a38a5cc424a8/)
    * Top learning paths
      * [ Cloud concepts ](https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/)
      * [ AI fundamentals ](https://learn.microsoft.com/en-us/training/paths/get-started-with-artificial-intelligence-on-azure/)
      * [ Intro to generative AI ](https://learn.microsoft.com/en-us/training/paths/introduction-generative-ai/)
      * [ Azure Architecture fundamentals ](https://learn.microsoft.com/en-us/training/paths/azure-fundamentals-describe-azure-architecture-services/)
    * [ Earn credentials ](https://learn.microsoft.com/en-us/credentials/browse/?products=azure)
    * [ Instructor-led courses ](https://learn.microsoft.com/en-us/training/browse/?products=azure&resource_type=course)
    * [ View all training ](https://learn.microsoft.com/en-us/training/azure/)
  * [ Troubleshooting ](https://learn.microsoft.com/en-us/troubleshoot/azure/)
  * Resources
    * [ Product overview ](https://azure.microsoft.com/get-started)
    * [ Latest blog posts ](https://azure.microsoft.com/blog/)
    * [ Pricing information ](https://azure.microsoft.com/pricing/)
    * [ Support options ](https://azure.microsoft.com/support/options/)
  * More
    * Products
      * Popular products
        * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/azure/ai-foundry/)
        * [ Azure App Service ](https://learn.microsoft.com/en-us/azure/app-service/)
        * [ Azure Databricks ](https://learn.microsoft.com/en-us/azure/databricks/)
        * [ Azure DevOps ](https://learn.microsoft.com/en-us/azure/devops/)
        * [ Azure Functions ](https://learn.microsoft.com/en-us/azure/azure-functions/)
        * [ Azure Monitor ](https://learn.microsoft.com/en-us/azure/azure-monitor/)
        * [ Azure Virtual Machines ](https://learn.microsoft.com/en-us/azure/virtual-machines/)
      * Popular categories
        * [ Compute ](https://learn.microsoft.com/en-us/azure/?product=compute)
        * [ Networking ](https://learn.microsoft.com/en-us/azure/?product=networking)
        * [ Storage ](https://learn.microsoft.com/en-us/azure/?product=storage)
        * [ AI & machine learning ](https://learn.microsoft.com/en-us/azure/?product=ai-machine-learning)
        * [ Analytics ](https://learn.microsoft.com/en-us/azure/?product=analytics)
        * [ Databases ](https://learn.microsoft.com/en-us/azure/?product=databases)
        * [ Security ](https://learn.microsoft.com/en-us/azure/?product=security)
      * [ View all products ](https://learn.microsoft.com/en-us/azure/)
    * Architecture
      * [ Cloud Adoption Framework ](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/)
      * [ Well-Architected Framework ](https://learn.microsoft.com/en-us/azure/well-architected/)
      * [ Azure Architecture Center ](https://learn.microsoft.com/en-us/azure/architecture/)
    * Develop
      * [ Python ](https://learn.microsoft.com/en-us/azure/developer/python/)
      * [ .NET ](https://learn.microsoft.com/en-us/dotnet/azure/)
      * [ JavaScript ](https://learn.microsoft.com/en-us/azure/developer/javascript/)
      * [ Java ](https://learn.microsoft.com/en-us/azure/developer/java/)
      * [ PowerShell ](https://learn.microsoft.com/en-us/powershell/azure/)
      * [ Azure CLI ](https://learn.microsoft.com/en-us/cli/azure/)
      * [ View all developer resources ](https://learn.microsoft.com/en-us/azure/developer/)
    * Learn Azure
      * [ Start your AI learning assessment ](https://learn.microsoft.com/en-us/assessments/1c032171-8ca0-4032-8962-a38a5cc424a8/)
      * Top learning paths
        * [ Cloud concepts ](https://learn.microsoft.com/en-us/training/paths/microsoft-azure-fundamentals-describe-cloud-concepts/)
        * [ AI fundamentals ](https://learn.microsoft.com/en-us/training/paths/get-started-with-artificial-intelligence-on-azure/)
        * [ Intro to generative AI ](https://learn.microsoft.com/en-us/training/paths/introduction-generative-ai/)
        * [ Azure Architecture fundamentals ](https://learn.microsoft.com/en-us/training/paths/azure-fundamentals-describe-azure-architecture-services/)
      * [ Earn credentials ](https://learn.microsoft.com/en-us/credentials/browse/?products=azure)
      * [ Instructor-led courses ](https://learn.microsoft.com/en-us/training/browse/?products=azure&resource_type=course)
      * [ View all training ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Troubleshooting ](https://learn.microsoft.com/en-us/troubleshoot/azure/)
    * Resources
      * [ Product overview ](https://azure.microsoft.com/get-started)
      * [ Latest blog posts ](https://azure.microsoft.com/blog/)
      * [ Pricing information ](https://azure.microsoft.com/pricing/)
      * [ Support options ](https://azure.microsoft.com/support/options/)


[ Portal ](https://portal.azure.com) [ Free account ](https://azure.microsoft.com/pricing/purchase-options/azure-account?cid=msft_learn)
# Azure documentation
Learn how to build and manage powerful applications using Microsoft Azure cloud services. Get documentation, example code, tutorials, and more.
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-get-started.svg?branch=main)
Get started
[Get started for Azure developers](https://learn.microsoft.com/en-us/azure/developer/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-training.svg?branch=main)
Training
[Build skills with Microsoft Learn for Azure](https://learn.microsoft.com/en-us/training/azure)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-architecture.svg?branch=main)
Architecture
[Design your app using the Azure Architecture Center](https://learn.microsoft.com/en-us/azure/architecture/)
![](https://learn.microsoft.com/en-us/media/hubs/shared/icon-overview.svg?branch=main)
Overview
[Achieve organizational goals with the Cloud Adoption Framework](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/)
[](https://learn.microsoft.com/en-us/azure/?product=popular#browse-azure-products)
## Browse Azure products
  * Popular
  * AI + Machine Learning
  * Analytics
  * Compute
  * Containers
  * Databases
  * Developer Tools
  * DevOps
  * Hybrid + multicloud
  * Identity
  * Integration
  * Internet of Things
  * Management and Governance
  * Media
  * Migration
  * Mixed Reality
  * Mobile
  * Networking
  * Security
  * Storage
  * Virtual Desktop Infrastructure
  * Web

Popular
  * Popular
  * AI + Machine Learning
  * Analytics
  * Compute
  * Containers
  * Databases
  * Developer Tools
  * DevOps
  * Hybrid + multicloud
  * Identity
  * Integration
  * Internet of Things
  * Management and Governance
  * Media
  * Migration
  * Mixed Reality
  * Mobile
  * Networking
  * Security
  * Storage
  * Virtual Desktop Infrastructure
  * Web


### Popular
![](https://learn.microsoft.com/en-us/azure/media/index/azure-networking.svg) [All networking services](https://learn.microsoft.com/en-us/azure/networking/)
Provide connectivity to your resources in Azure, deliver and protect applications, and help secure your network.
[All networking services](https://learn.microsoft.com/en-us/azure/networking/)
![](https://learn.microsoft.com/en-us/azure/media/index/api-management.svg) [API Management](https://learn.microsoft.com/en-us/azure/api-management/)
Publish APIs to developers, partners, and employees securely and at scale
[API Management](https://learn.microsoft.com/en-us/azure/api-management/)
![](https://learn.microsoft.com/en-us/azure/media/index/app-configuration.svg) [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
[App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
![](https://learn.microsoft.com/en-us/azure/media/index/app-service.svg) [App Service](https://learn.microsoft.com/en-us/azure/app-service/)
Quickly create powerful cloud apps for web and mobile
[App Service](https://learn.microsoft.com/en-us/azure/app-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/application-gateways.svg) [Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/)
Build secure, scalable, and highly available web front ends in Azure
[Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-explorer.svg) [Archive Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/access-tiers-overview)
Industry leading price point for storing rarely accessed data
[Archive Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/access-tiers-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/resource-groups.svg) [ARM templates](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/)
Deliver infrastructure as code for all your Azure resources using Resource Manager
[ARM templates](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/)
![](https://learn.microsoft.com/en-us/azure/media/index/automation.svg) [Automation](https://learn.microsoft.com/en-us/azure/automation/)
Simplify cloud management with process automation
[Automation](https://learn.microsoft.com/en-us/azure/automation/)
![](https://learn.microsoft.com/en-us/azure/media/index/advisor.svg) [Azure Advisor](https://learn.microsoft.com/en-us/azure/advisor/)
Your personalized Azure best practices recommendation engine
[Azure Advisor](https://learn.microsoft.com/en-us/azure/advisor/)
![](https://learn.microsoft.com/en-us/azure/media/index/bot-services.svg) [Azure AI Bot Service](https://learn.microsoft.com/en-us/azure/bot-service/)
Intelligent, serverless bot service that scales on demand
[Azure AI Bot Service](https://learn.microsoft.com/en-us/azure/bot-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/content-safety.svg) [Azure AI Content Safety](https://learn.microsoft.com/en-us/azure/ai-services/content-safety/)
Use AI to monitor text and image content for safety
[Azure AI Content Safety](https://learn.microsoft.com/en-us/azure/ai-services/content-safety/)
![](https://learn.microsoft.com/en-us/azure/media/index/custom-vision.svg) [Azure AI Custom Vision](https://learn.microsoft.com/en-us/azure/ai-services/custom-vision-service/)
Easily customize your own state-of-the-art computer vision models for your unique use case
[Azure AI Custom Vision](https://learn.microsoft.com/en-us/azure/ai-services/custom-vision-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/face.svg) [Azure AI Face](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/overview-identity)
Detect, identify, analyze, organize, and tag faces in photos
[Azure AI Face](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/overview-identity)
![](https://learn.microsoft.com/en-us/azure/media/index/immersive-reader.svg) [Azure AI Immersive Reader](https://learn.microsoft.com/en-us/azure/ai-services/immersive-reader/)
Empower users of all ages and abilities to read and comprehend text
[Azure AI Immersive Reader](https://learn.microsoft.com/en-us/azure/ai-services/immersive-reader/)
![](https://learn.microsoft.com/en-us/azure/media/index/search.svg) [Azure AI Search](https://learn.microsoft.com/en-us/azure/search/)
AI-powered cloud search service for mobile and web app development
[Azure AI Search](https://learn.microsoft.com/en-us/azure/search/)
![](https://learn.microsoft.com/en-us/azure/media/index/video-indexer.svg) [Azure AI Video Indexer](https://learn.microsoft.com/en-us/azure/azure-video-indexer/)
Unlock video insights
[Azure AI Video Indexer](https://learn.microsoft.com/en-us/azure/azure-video-indexer/)
![](https://learn.microsoft.com/en-us/azure/media/index/analysis-services.svg) [Azure Analysis Services](https://learn.microsoft.com/en-us/azure/analysis-services/)
Enterprise-grade analytics engine as a service
[Azure Analysis Services](https://learn.microsoft.com/en-us/azure/analysis-services/)
![](https://learn.microsoft.com/en-us/azure/media/index/api-for-fhir.svg) [Azure API for FHIR](https://learn.microsoft.com/en-us/azure/healthcare-apis/azure-api-for-fhir/)
Easily create and deploy a FHIR service for health data solutions and interoperability
[Azure API for FHIR](https://learn.microsoft.com/en-us/azure/healthcare-apis/azure-api-for-fhir/)
![](https://learn.microsoft.com/en-us/azure/media/index/load-testing.svg) [Azure App Testing](https://learn.microsoft.com/en-us/azure/app-testing/)
Test your app holistically with Azure Load Testing and Playwright Workspaces
[Azure App Testing](https://learn.microsoft.com/en-us/azure/app-testing/)
![](https://learn.microsoft.com/en-us/azure/media/index/arc.svg) [Azure Arc](https://learn.microsoft.com/en-us/azure/azure-arc/)
Bring Azure services and management to any infrastructure
[Azure Arc](https://learn.microsoft.com/en-us/azure/azure-arc/)
![](https://learn.microsoft.com/en-us/azure/media/index/artifacts.svg) [Azure Artifacts](https://learn.microsoft.com/en-us/azure/devops/artifacts/)
Create, host, and share packages with your team
[Azure Artifacts](https://learn.microsoft.com/en-us/azure/devops/artifacts/)
![](https://learn.microsoft.com/en-us/azure/media/index/recovery-services-vaults.svg) [Azure Backup](https://learn.microsoft.com/en-us/azure/backup/)
Simplify data protection and protect against ransomware
[Azure Backup](https://learn.microsoft.com/en-us/azure/backup/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-accounts.svg) [Azure Blob Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/)
REST-based object storage for unstructured data
[Azure Blob Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/)
![](https://learn.microsoft.com/en-us/azure/media/index/blueprints.svg) [Azure Blueprints (Preview)](https://learn.microsoft.com/en-us/azure/governance/blueprints/)
Enabling quick, repeatable creation of governed environments
[Azure Blueprints (Preview)](https://learn.microsoft.com/en-us/azure/governance/blueprints/)
![](https://learn.microsoft.com/en-us/azure/media/index/boards.svg) [Azure Boards](https://learn.microsoft.com/en-us/azure/devops/boards/)
Plan, track, and discuss work across your teams
[Azure Boards](https://learn.microsoft.com/en-us/azure/devops/boards/)
![](https://learn.microsoft.com/en-us/azure/media/index/cache-redis.svg) [Azure Cache for Redis](https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/)
Power applications with high-throughput, low-latency data access
[Azure Cache for Redis](https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/)
![](https://learn.microsoft.com/en-us/azure/media/index/chaos-studio.svg) [Azure Chaos Studio](https://learn.microsoft.com/en-us/azure/chaos-studio/)
Improve application resilience by introducing faults and simulating outages
[Azure Chaos Studio](https://learn.microsoft.com/en-us/azure/chaos-studio/)
![](https://learn.microsoft.com/en-us/azure/media/index/cloud-shell.svg) [Azure Cloud Shell](https://learn.microsoft.com/en-us/azure/cloud-shell/overview)
Streamline Azure administration with a browser-based shell
[Azure Cloud Shell](https://learn.microsoft.com/en-us/azure/cloud-shell/overview)
![](https://learn.microsoft.com/en-us/azure/media/index/communication-services.svg) [Azure Communication Services](https://learn.microsoft.com/en-us/azure/communication-services/overview)
Build rich communication experiences with the same secure platform used by Microsoft Teams
[Azure Communication Services](https://learn.microsoft.com/en-us/azure/communication-services/overview)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-machine.svg) [Azure Compute Fleet (Preview)](https://learn.microsoft.com/en-us/azure/azure-compute-fleet/overview)
Easily provision and manage Azure compute capacity at scale
[Azure Compute Fleet (Preview)](https://learn.microsoft.com/en-us/azure/azure-compute-fleet/overview)
![](https://learn.microsoft.com/en-us/azure/media/index/confidential-ledger.svg) [Azure confidential ledger](https://learn.microsoft.com/en-us/azure/confidential-ledger/)
Tamperproof, unstructured data store hosted in trusted execution environments (TEEs) and backed by cryptographically verifiable evidence
[Azure confidential ledger](https://learn.microsoft.com/en-us/azure/confidential-ledger/)
![](https://learn.microsoft.com/en-us/azure/media/index/container-apps.svg) [Azure Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/)
Build and deploy modern apps and microservices using serverless containers
[Azure Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/)
![](https://learn.microsoft.com/en-us/azure/media/index/container-instances.svg) [Azure Container Instances](https://learn.microsoft.com/en-us/azure/container-instances/)
Easily run containers on Azure without managing servers
[Azure Container Instances](https://learn.microsoft.com/en-us/azure/container-instances/)
![](https://learn.microsoft.com/en-us/azure/media/index/container-registry.svg) [Azure Container Registry](https://learn.microsoft.com/en-us/azure/container-registry/)
Store and manage container images across all types of Azure deployments
[Azure Container Registry](https://learn.microsoft.com/en-us/azure/container-registry/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Azure Container Storage](https://learn.microsoft.com/en-us/azure/storage/container-storage/)
Manage persistent volumes for stateful container applications
[Azure Container Storage](https://learn.microsoft.com/en-us/azure/storage/container-storage/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure-copilot.svg) [Azure Copilot](https://learn.microsoft.com/en-us/azure/copilot)
Simplify operations and management from cloud to edge with an AI companion
[Azure Copilot](https://learn.microsoft.com/en-us/azure/copilot)
![](https://learn.microsoft.com/en-us/azure/media/index/cosmos-db.svg) [Azure Cosmos DB](https://learn.microsoft.com/en-us/azure/cosmos-db/)
Fast NoSQL database with open APIs for any scale
[Azure Cosmos DB](https://learn.microsoft.com/en-us/azure/cosmos-db/)
![](https://learn.microsoft.com/en-us/azure/media/index/logo_cyclecloud.svg) [Azure CycleCloud](https://learn.microsoft.com/en-us/azure/cyclecloud/index)
Create, manage, operate, and optimize HPC and big compute clusters of any scale
[Azure CycleCloud](https://learn.microsoft.com/en-us/azure/cyclecloud/index)
![](https://learn.microsoft.com/en-us/azure/media/index/data-box.svg) [Azure Data Box](https://learn.microsoft.com/en-us/azure/databox/)
Appliances and solutions for data transfer to Azure
[Azure Data Box](https://learn.microsoft.com/en-us/azure/databox/)
![](https://learn.microsoft.com/en-us/azure/media/index/data-explorer.svg) [Azure Data Explorer](https://learn.microsoft.com/en-us/azure/data-explorer)
Fast and highly scalable data exploration service
[Azure Data Explorer](https://learn.microsoft.com/en-us/azure/data-explorer)
![](https://learn.microsoft.com/en-us/azure/media/index/data-factory.svg) [Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
Hybrid data integration at enterprise scale, made easy
[Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-accounts.svg) [Azure Data Lake Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction)
Massively scalable, secure data lake functionality built on Azure Blob Storage
[Azure Data Lake Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction)
![](https://learn.microsoft.com/en-us/azure/media/index/energy-data-services.svg) [Azure Data Manager for Agriculture (Preview)](https://learn.microsoft.com/en-us/azure/data-manager-for-agri/)
Create a more sustainable future by innovating with agriculture data
[Azure Data Manager for Agriculture (Preview)](https://learn.microsoft.com/en-us/azure/data-manager-for-agri/)
![](https://learn.microsoft.com/en-us/azure/media/index/data-shares.svg) [Azure Data Share](https://learn.microsoft.com/en-us/azure/data-share/)
A simple and safe service for sharing big data with external organizations
[Azure Data Share](https://learn.microsoft.com/en-us/azure/data-share/)
![](https://learn.microsoft.com/en-us/azure/media/index/database-mariadb-server.svg) [Azure Database for MariaDB](https://learn.microsoft.com/en-us/azure/mariadb/)
Managed MariaDB database service for app developers
[Azure Database for MariaDB](https://learn.microsoft.com/en-us/azure/mariadb/)
![](https://learn.microsoft.com/en-us/azure/media/index/database-mysql-server.svg) [Azure Database for MySQL](https://learn.microsoft.com/en-us/azure/mysql/)
Managed MySQL database service for app developers
[Azure Database for MySQL](https://learn.microsoft.com/en-us/azure/mysql/)
![](https://learn.microsoft.com/en-us/azure/media/index/database-postgresql-server.svg) [Azure Database for PostgreSQL](https://learn.microsoft.com/en-us/azure/postgresql/)
Managed PostgreSQL database service for app developers
[Azure Database for PostgreSQL](https://learn.microsoft.com/en-us/azure/postgresql/)
![](https://learn.microsoft.com/en-us/azure/media/index/database-migration-services.svg) [Azure Database Migration Service](https://learn.microsoft.com/en-us/azure/dms/)
Simplify on-premises database migration to the cloud
[Azure Database Migration Service](https://learn.microsoft.com/en-us/azure/dms/)
![](https://learn.microsoft.com/en-us/azure/media/index/databricks.svg) [Azure Databricks](https://learn.microsoft.com/en-us/azure/databricks/)
Fast, easy, and collaborative Apache Spark-based analytics platform
[Azure Databricks](https://learn.microsoft.com/en-us/azure/databricks/)
![](https://learn.microsoft.com/en-us/azure/media/index/ddos-protection.svg) [Azure DDoS Protection](https://learn.microsoft.com/en-us/azure/ddos-protection/)
Protect your applications from Distributed Denial of Service (DDoS) attacks
[Azure DDoS Protection](https://learn.microsoft.com/en-us/azure/ddos-protection/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-machine.svg) [Azure Dedicated Host](https://learn.microsoft.com/en-us/azure/virtual-machines/dedicated-hosts)
A dedicated physical server to host your Azure VMs for Windows and Linux
[Azure Dedicated Host](https://learn.microsoft.com/en-us/azure/virtual-machines/dedicated-hosts)
![](https://learn.microsoft.com/en-us/azure/media/index/dedicated-hsm.svg) [Azure Dedicated HSM](https://learn.microsoft.com/en-us/azure/dedicated-hsm/)
Manage hardware security modules that you use in the cloud
[Azure Dedicated HSM](https://learn.microsoft.com/en-us/azure/dedicated-hsm/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Azure Deployment Environments](https://learn.microsoft.com/en-us/azure/deployment-environments/)
Quickly spin up app infrastructure environments with project-based templates
[Azure Deployment Environments](https://learn.microsoft.com/en-us/azure/deployment-environments/)
![](https://learn.microsoft.com/en-us/azure/media/index/devops.svg) [Azure DevOps](https://learn.microsoft.com/en-us/azure/devops/)
Services for teams to share code, track work, and ship software
[Azure DevOps](https://learn.microsoft.com/en-us/azure/devops/)
![](https://learn.microsoft.com/en-us/azure/media/index/devtest-labs.svg) [Azure DevTest Labs](https://learn.microsoft.com/en-us/azure/devtest-labs/)
Quickly create environments using reusable templates and artifacts
[Azure DevTest Labs](https://learn.microsoft.com/en-us/azure/devtest-labs/)
![](https://learn.microsoft.com/en-us/azure/media/index/digital-twins.svg) [Azure Digital Twins](https://learn.microsoft.com/en-us/azure/digital-twins/)
Build next-generation IoT spatial intelligence solutions
[Azure Digital Twins](https://learn.microsoft.com/en-us/azure/digital-twins/)
![](https://learn.microsoft.com/en-us/azure/media/index/disk-storage.svg) [Azure Disk Storage](https://learn.microsoft.com/en-us/azure/virtual-machines/managed-disks-overview)
High-performance, highly durable block storage for Azure Virtual Machines
[Azure Disk Storage](https://learn.microsoft.com/en-us/azure/virtual-machines/managed-disks-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/dns.svg) [Azure DNS](https://learn.microsoft.com/en-us/azure/dns/)
Host your DNS domain in Azure
[Azure DNS](https://learn.microsoft.com/en-us/azure/dns/)
![](https://learn.microsoft.com/en-us/azure/media/index/document-intelligence.svg) [Azure Document Intelligence in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/)
The AI-powered document extraction service that understands your forms
[Azure Document Intelligence in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/)
![](https://learn.microsoft.com/en-us/azure/media/index/documentdb.svg) [Azure DocumentDB](https://learn.microsoft.com/en-us/azure/documentdb/)
Powerful MongoDB-compatible open-source document database for modern apps
[Azure DocumentDB](https://learn.microsoft.com/en-us/azure/documentdb/)
![](https://learn.microsoft.com/en-us/azure/media/index/elastic-san.svg) [Azure Elastic SAN](https://learn.microsoft.com/en-us/azure/storage/elastic-san/)
Elastic SAN is a cloud-native Storage Area Network (SAN) service built on Azure. Gain access to an end-to-end experience like your on-premises SAN.
[Azure Elastic SAN](https://learn.microsoft.com/en-us/azure/storage/elastic-san/)
![](https://learn.microsoft.com/en-us/azure/media/index/express-route.svg) [Azure ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/)
Dedicated private network fiber connections to Azure
[Azure ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-azure-files.svg) [Azure Files](https://learn.microsoft.com/en-us/azure/storage/files/)
Simple, secure and serverless enterprise-grade cloud file shares
[Azure Files](https://learn.microsoft.com/en-us/azure/storage/files/)
![](https://learn.microsoft.com/en-us/azure/media/index/firewall.svg) [Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/)
Native firewalling capabilities with built-in high availability, unrestricted cloud scalability, and zero maintenance
[Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/)
![](https://learn.microsoft.com/en-us/azure/media/index/fluid-relay.svg) [Azure Fluid Relay](https://learn.microsoft.com/en-us/azure/azure-fluid-relay/)
Easily add real-time collaborative experiences to your apps with Fluid Framework
[Azure Fluid Relay](https://learn.microsoft.com/en-us/azure/azure-fluid-relay/)
![](https://learn.microsoft.com/en-us/azure/media/index/front-door.svg) [Azure Front Door](https://learn.microsoft.com/en-us/azure/frontdoor/)
Scalable, security-enhanced delivery point for global, microservice-based web applications
[Azure Front Door](https://learn.microsoft.com/en-us/azure/frontdoor/)
![](https://learn.microsoft.com/en-us/azure/media/index/cdn-profiles.svg) [Azure Front Door and Content Delivery Network (CDN)](https://learn.microsoft.com/en-us/azure/frontdoor/)
Ensure secure, reliable content delivery with broad global reach
[Azure Front Door and Content Delivery Network (CDN)](https://learn.microsoft.com/en-us/azure/frontdoor/)
![](https://learn.microsoft.com/en-us/azure/media/index/functions.svg) [Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
Process events with serverless code
[Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
![](https://learn.microsoft.com/en-us/azure/media/index/api-for-fhir.svg) [Azure Health Data Services](https://learn.microsoft.com/en-us/azure/healthcare-apis/)
A unified solution that helps protect and combine health data in the cloud and generates healthcare insights with analytics
[Azure Health Data Services](https://learn.microsoft.com/en-us/azure/healthcare-apis/)
![](https://learn.microsoft.com/en-us/azure/media/index/information-protection.svg) [Azure Information Protection](https://learn.microsoft.com/en-us/azure/information-protection/)
Better protect your sensitive information—anytime, anywhere
[Azure Information Protection](https://learn.microsoft.com/en-us/azure/information-protection/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Azure IoT](https://learn.microsoft.com/en-us/azure/iot/)
A collection of Microsoft-managed cloud and edge services that connect, monitor, and control billions of IoT assets.
[Azure IoT](https://learn.microsoft.com/en-us/azure/iot/)
![](https://learn.microsoft.com/en-us/azure/media/index/iot-central.svg) [Azure IoT Central](https://learn.microsoft.com/en-us/azure/iot-central/)
Accelerate the creation of IoT solutions
[Azure IoT Central](https://learn.microsoft.com/en-us/azure/iot-central/)
![](https://learn.microsoft.com/en-us/azure/media/index/iot-edge.svg) [Azure IoT Edge](https://learn.microsoft.com/en-us/azure/iot-edge/)
Extend cloud intelligence and analytics to edge devices
[Azure IoT Edge](https://learn.microsoft.com/en-us/azure/iot-edge/)
![](https://learn.microsoft.com/en-us/azure/media/index/iot-hub.svg) [Azure IoT Hub](https://learn.microsoft.com/en-us/azure/iot-hub/)
Connect, monitor, and manage billions of IoT assets
[Azure IoT Hub](https://learn.microsoft.com/en-us/azure/iot-hub/)
![](https://learn.microsoft.com/en-us/azure/media/index/iot-operations.svg) [Azure IoT Operations](https://learn.microsoft.com/en-us/azure/iot-operations/)
Unlock insights for intelligent local actions and global visibility
[Azure IoT Operations](https://learn.microsoft.com/en-us/azure/iot-operations/)
![](https://learn.microsoft.com/en-us/azure/media/index/kubernetes-fleet-manager.svg) [Azure Kubernetes Fleet Manager](https://learn.microsoft.com/en-us/azure/kubernetes-fleet/)
Enable multi-cluster and at-scale scenarios for Azure Kubernetes Service clusters
[Azure Kubernetes Fleet Manager](https://learn.microsoft.com/en-us/azure/kubernetes-fleet/)
![](https://learn.microsoft.com/en-us/azure/media/index/kubernetes-services.svg) [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/en-us/azure/aks/)
Simplify the deployment, management, and operations of Kubernetes
[Azure Kubernetes Service (AKS)](https://learn.microsoft.com/en-us/azure/aks/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/en-us/azure/aks/hybrid/aks-edge-overview)
An on-premises Kubernetes implementation of Azure Kubernetes Service (AKS) that automates running containerized applications at scale
[Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/en-us/azure/aks/hybrid/aks-edge-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/lab-services.svg) [Azure Lab Services](https://learn.microsoft.com/en-us/azure/lab-services/)
Set up virtual labs for classes, training, hackathons, and other related scenarios
[Azure Lab Services](https://learn.microsoft.com/en-us/azure/lab-services/)
![](https://learn.microsoft.com/en-us/azure/media/index/language.svg) [Azure Language in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/language-service/)
Easily evaluate sentiment and topics to understand what users want
[Azure Language in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/language-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/lighthouse.svg) [Azure Lighthouse](https://learn.microsoft.com/en-us/azure/lighthouse/)
Empowering service providers to manage customers at scale and with precision
[Azure Lighthouse](https://learn.microsoft.com/en-us/azure/lighthouse/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure-local.svg) [Azure Local](https://learn.microsoft.com/en-us/azure/azure-local/)
Operate infrastructure across distributed locations enabled by Azure Arc
[Azure Local](https://learn.microsoft.com/en-us/azure/azure-local/)
![](https://learn.microsoft.com/en-us/azure/media/index/machine-learning.svg) [Azure Machine Learning](https://learn.microsoft.com/en-us/azure/machine-learning/)
Bring AI to everyone with an end-to-end, scalable, trusted platform with experimentation and model management
[Azure Machine Learning](https://learn.microsoft.com/en-us/azure/machine-learning/)
![](https://learn.microsoft.com/en-us/azure/media/index/managed-applications.svg) [Azure Managed Applications](https://learn.microsoft.com/en-us/azure/azure-resource-manager/managed-applications/)
Simplify management of cloud offerings
[Azure Managed Applications](https://learn.microsoft.com/en-us/azure/azure-resource-manager/managed-applications/)
![](https://learn.microsoft.com/en-us/azure/media/index/managed-grafana.svg) [Azure Managed Grafana](https://learn.microsoft.com/en-us/azure/managed-grafana/)
Deploy Grafana dashboards as a fully managed Azure service
[Azure Managed Grafana](https://learn.microsoft.com/en-us/azure/managed-grafana/)
![](https://learn.microsoft.com/en-us/azure/media/index/managed-instance-apache-cassandra.svg) [Azure Managed Instance for Apache Cassandra](https://learn.microsoft.com/en-us/azure/managed-instance-apache-cassandra/)
Automate deployment and scaling for managed open-source Apache Cassandra datacenters
[Azure Managed Instance for Apache Cassandra](https://learn.microsoft.com/en-us/azure/managed-instance-apache-cassandra/)
![](https://learn.microsoft.com/en-us/azure/media/index/managed-lustre.svg) [Azure Managed Lustre](https://learn.microsoft.com/en-us/azure/azure-managed-lustre/)
A fully managed, cloud based parallel file system that enables customers to run their high performance computing (HPC) workloads in the cloud
[Azure Managed Lustre](https://learn.microsoft.com/en-us/azure/azure-managed-lustre/)
![](https://learn.microsoft.com/en-us/azure/media/index/managed-redis.svg) [Azure Managed Redis](https://learn.microsoft.com/en-us/azure/redis/)
Power applications with a high-performance, managed cache
[Azure Managed Redis](https://learn.microsoft.com/en-us/azure/redis/)
![](https://learn.microsoft.com/en-us/azure/media/index/maps.svg) [Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/)
Simple and secure location APIs provide geospatial context to data
[Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/)
![](https://learn.microsoft.com/en-us/azure/media/index/media-services.svg) [Azure Media Player](https://learn.microsoft.com/en-us/azure/media-services/latest/player-media-players-concept)
A single player for all your playback needs
[Azure Media Player](https://learn.microsoft.com/en-us/azure/media-services/latest/player-media-players-concept)
![](https://learn.microsoft.com/en-us/azure/media/index/migrate.svg) [Azure Migrate](https://learn.microsoft.com/en-us/azure/migrate/)
Easily discover, assess, right-size, and migrate your on-premises VMs to Azure
[Azure Migrate](https://learn.microsoft.com/en-us/azure/migrate/)
![](https://learn.microsoft.com/en-us/azure/media/index/monitor.svg) [Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/)
Full observability into your applications, infrastructure, and network
[Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/)
![](https://learn.microsoft.com/en-us/azure/media/index/netapp-files.svg) [Azure NetApp Files](https://learn.microsoft.com/en-us/azure/azure-netapp-files/)
Enterprise-grade Azure file shares, powered by NetApp
[Azure NetApp Files](https://learn.microsoft.com/en-us/azure/azure-netapp-files/)
![](https://learn.microsoft.com/en-us/azure/media/index/open-datasets.svg) [Azure Open Datasets](https://learn.microsoft.com/en-us/azure/open-datasets/)
Cloud platform to host and share curated open datasets to accelerate development of machine learning models
[Azure Open Datasets](https://learn.microsoft.com/en-us/azure/open-datasets/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure-openai.svg) [Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
Apply advanced coding and language models to various use cases
[Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
![](https://learn.microsoft.com/en-us/azure/media/index/operator-insights.svg) [Azure Operator Insights](https://learn.microsoft.com/en-us/azure/operator-insights/)
Analyze network data from multiple sources
[Azure Operator Insights](https://learn.microsoft.com/en-us/azure/operator-insights/)
![](https://learn.microsoft.com/en-us/azure/media/index/operator-nexus.svg) [Azure Operator Nexus](https://learn.microsoft.com/en-us/azure/operator-nexus/)
Build your mission-critical mobile networks with a carrier-grade, hybrid cloud platform
[Azure Operator Nexus](https://learn.microsoft.com/en-us/azure/operator-nexus/)
![](https://learn.microsoft.com/en-us/azure/media/index/operator-service-manager.svg) [Azure Operator Service Manager](https://learn.microsoft.com/en-us/azure/operator-service-manager/)
Manage network services across hybrid cloud sites
[Azure Operator Service Manager](https://learn.microsoft.com/en-us/azure/operator-service-manager/)
![](https://learn.microsoft.com/en-us/azure/media/index/pipelines.svg) [Azure Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)
Continuously build, test, and deploy to any platform and cloud
[Azure Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)
![](https://learn.microsoft.com/en-us/azure/media/index/policy.svg) [Azure Policy](https://learn.microsoft.com/en-us/azure/governance/policy/)
Implement corporate governance and standards at scale for Azure resources
[Azure Policy](https://learn.microsoft.com/en-us/azure/governance/policy/)
![](https://learn.microsoft.com/en-us/azure/media/index/private-link.svg) [Azure Private Link](https://learn.microsoft.com/en-us/azure/private-link/)
Private access to services hosted on the Azure platform, keeping your data on the Microsoft network
[Azure Private Link](https://learn.microsoft.com/en-us/azure/private-link/)
![](https://learn.microsoft.com/en-us/azure/media/index/quantum.svg) [Azure Quantum (Preview)](https://learn.microsoft.com/en-us/azure/quantum/)
Experience quantum impact today on Azure
[Azure Quantum (Preview)](https://learn.microsoft.com/en-us/azure/quantum/)
![](https://learn.microsoft.com/en-us/azure/media/index/openshift.svg) [Azure Red Hat OpenShift](https://learn.microsoft.com/en-us/azure/openshift/)
Fully managed OpenShift service, jointly operated with Red Hat
[Azure Red Hat OpenShift](https://learn.microsoft.com/en-us/azure/openshift/)
![](https://learn.microsoft.com/en-us/azure/media/index/repos.svg) [Azure Repos](https://learn.microsoft.com/en-us/azure/devops/repos/)
Get unlimited, cloud-hosted private Git repos for your project
[Azure Repos](https://learn.microsoft.com/en-us/azure/devops/repos/)
![](https://learn.microsoft.com/en-us/azure/media/index/resource-groups.svg) [Azure Resource Manager](https://learn.microsoft.com/en-us/azure/azure-resource-manager/)
Simplify how you manage your app resources
[Azure Resource Manager](https://learn.microsoft.com/en-us/azure/azure-resource-manager/)
![](https://learn.microsoft.com/en-us/azure/media/index/resource-mover.svg) [Azure Resource Mover](https://learn.microsoft.com/en-us/azure/resource-mover/)
Simplify how you move multiple resources between Azure regions
[Azure Resource Mover](https://learn.microsoft.com/en-us/azure/resource-mover/)
![](https://learn.microsoft.com/en-us/azure/media/index/service-fabric-clusters.svg) [Azure Service Fabric](https://learn.microsoft.com/en-us/azure/service-fabric/)
Develop microservices and orchestrate containers on Windows or Linux
[Azure Service Fabric](https://learn.microsoft.com/en-us/azure/service-fabric/)
![](https://learn.microsoft.com/en-us/azure/media/index/service-health.svg) [Azure Service Health](https://learn.microsoft.com/en-us/azure/service-health/)
Personalized guidance and support for when issues in Azure services affect you
[Azure Service Health](https://learn.microsoft.com/en-us/azure/service-health/)
![](https://learn.microsoft.com/en-us/azure/media/index/signalr-service.svg) [Azure SignalR Service](https://learn.microsoft.com/en-us/azure/azure-signalr/)
Add real-time web functionality easily
[Azure SignalR Service](https://learn.microsoft.com/en-us/azure/azure-signalr/)
![](https://learn.microsoft.com/en-us/azure/media/index/recovery-services-vaults.svg) [Azure Site Recovery](https://learn.microsoft.com/en-us/azure/site-recovery/)
Keep your business running with built-in disaster recovery service
[Azure Site Recovery](https://learn.microsoft.com/en-us/azure/site-recovery/)
![](https://learn.microsoft.com/en-us/azure/media/index/sphere.svg) [Azure Sphere](https://learn.microsoft.com/en-us/azure-sphere/)
Securely connect MCU-powered devices from the silicon to the cloud
[Azure Sphere](https://learn.microsoft.com/en-us/azure-sphere/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-machine.svg) [Azure Spot Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/spot-vms)
Provision unused compute capacity at deep discounts to run interruptible workloads
[Azure Spot Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/spot-vms)
![](https://learn.microsoft.com/en-us/azure/media/index/spring-cloud.svg) [Azure Spring Apps](https://learn.microsoft.com/en-us/azure/spring-apps/)
A fully managed Spring Cloud service, built and operated with Pivotal
[Azure Spring Apps](https://learn.microsoft.com/en-us/azure/spring-apps/)
![](https://learn.microsoft.com/en-us/azure/media/index/sql.svg) [Azure SQL](https://learn.microsoft.com/en-us/azure/azure-sql/index)
Modern SQL family for migration and app modernization
[Azure SQL](https://learn.microsoft.com/en-us/azure/azure-sql/index)
![](https://learn.microsoft.com/en-us/azure/media/index/sql-database.svg) [Azure SQL Database](https://learn.microsoft.com/en-us/azure/azure-sql/database/index)
Managed, intelligent SQL in the cloud
[Azure SQL Database](https://learn.microsoft.com/en-us/azure/azure-sql/database/index)
![](https://learn.microsoft.com/en-us/azure/media/index/sql-managed-instance.svg) [Azure SQL Managed Instance](https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/index)
Managed, always up-to-date SQL instance in the cloud
[Azure SQL Managed Instance](https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/index)
![](https://learn.microsoft.com/en-us/azure/media/index/stack-edge.svg) [Azure Stack Edge](https://learn.microsoft.com/en-us/azure/databox-online/)
An Azure managed appliance that brings the compute, storage, and intelligence of Azure to the edge
[Azure Stack Edge](https://learn.microsoft.com/en-us/azure/databox-online/)
![](https://learn.microsoft.com/en-us/azure/media/index/stack-hub.svg) [Azure Stack Hub](https://learn.microsoft.com/en-us/azure-stack/operator/)
Azure Stack Hub is sold as an integrated hardware system, with software preinstalled on validated hardware
[Azure Stack Hub](https://learn.microsoft.com/en-us/azure-stack/operator/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-actions.svg) [Azure Storage Actions](https://learn.microsoft.com/en-us/azure/storage-actions/storage-tasks/)
Simplify storage data management at massive scale
[Azure Storage Actions](https://learn.microsoft.com/en-us/azure/storage-actions/storage-tasks/)
![](https://learn.microsoft.com/en-us/azure/media/index/stream-analytics.svg) [Azure Stream Analytics](https://learn.microsoft.com/en-us/azure/stream-analytics/)
Real-time analytics on fast moving streams of data from applications and devices
[Azure Stream Analytics](https://learn.microsoft.com/en-us/azure/stream-analytics/)
![](https://learn.microsoft.com/en-us/azure/media/index/synapse.svg) [Azure Synapse Analytics](https://learn.microsoft.com/en-us/azure/synapse-analytics/)
Limitless analytics service with unmatched time to insight
[Azure Synapse Analytics](https://learn.microsoft.com/en-us/azure/synapse-analytics/)
![](https://learn.microsoft.com/en-us/azure/media/index/test-plans.svg) [Azure Test Plans](https://learn.microsoft.com/en-us/azure/devops/test/)
Test and ship with confidence with a manual and exploratory testing toolkit
[Azure Test Plans](https://learn.microsoft.com/en-us/azure/devops/test/)
![](https://learn.microsoft.com/en-us/azure/media/index/update-center.svg) [Azure Update Manager](https://learn.microsoft.com/en-us/azure/update-manager/)
Centrally manage updates and compliance at scale
[Azure Update Manager](https://learn.microsoft.com/en-us/azure/update-manager/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-desktop.svg) [Azure Virtual Desktop](https://learn.microsoft.com/en-us/azure/virtual-desktop/)
The best virtual desktop experience, delivered on Azure
[Azure Virtual Desktop](https://learn.microsoft.com/en-us/azure/virtual-desktop/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure-vmware.svg) [Azure VMware Solution](https://learn.microsoft.com/en-us/azure/azure-vmware/)
Run your VMware workloads natively on Azure
[Azure VMware Solution](https://learn.microsoft.com/en-us/azure/azure-vmware/)
![](https://learn.microsoft.com/en-us/azure/media/index/web-pubsub.svg) [Azure Web PubSub](https://learn.microsoft.com/en-us/azure/azure-web-pubsub/)
Easily build real-time messaging web applications using WebSockets and the publish-subscribe pattern
[Azure Web PubSub](https://learn.microsoft.com/en-us/azure/azure-web-pubsub/)
![](https://learn.microsoft.com/en-us/azure/media/index/batch-accounts.svg) [Batch](https://learn.microsoft.com/en-us/azure/batch/)
Cloud-scale job scheduling and compute management
[Batch](https://learn.microsoft.com/en-us/azure/batch/)
![](https://learn.microsoft.com/en-us/azure/media/index/cloud-services.svg) [Cloud Services](https://learn.microsoft.com/en-us/azure/cloud-services-extended-support/)
Create highly available, infinitely scalable cloud applications and APIs
[Cloud Services](https://learn.microsoft.com/en-us/azure/cloud-services-extended-support/)
![](https://learn.microsoft.com/en-us/azure/media/index/media-protection.svg) [Content Protection](https://learn.microsoft.com/en-us/azure/media-services/latest/drm-content-protection-concept)
Securely deliver content using AES, PlayReady, Widevine, and Fairplay
[Content Protection](https://learn.microsoft.com/en-us/azure/media-services/latest/drm-content-protection-concept)
![](https://learn.microsoft.com/en-us/azure/media/index/cost-management.svg) [Cost Management + Billing](https://learn.microsoft.com/en-us/azure/cost-management-billing/)
Optimize what you spend on the cloud, while maximizing cloud potential
[Cost Management + Billing](https://learn.microsoft.com/en-us/azure/cost-management-billing/)
![](https://learn.microsoft.com/en-us/azure/media/index/data-lake-analytics.svg) [Data Lake Analytics](https://learn.microsoft.com/en-us/azure/data-lake-analytics/)
Distributed analytics service that makes big data easy
[Data Lake Analytics](https://learn.microsoft.com/en-us/azure/data-lake-analytics/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-machine.svg) [Data Science Virtual Machines](https://learn.microsoft.com/en-us/azure/machine-learning/data-science-virtual-machine/)
Rich preconfigured environment for AI development
[Data Science Virtual Machines](https://learn.microsoft.com/en-us/azure/machine-learning/data-science-virtual-machine/)
![](https://learn.microsoft.com/en-us/azure/media/index/media-services.svg) [Encoding](https://learn.microsoft.com/en-us/azure/media-services/latest/encode-concept)
Studio grade encoding at cloud scale
[Encoding](https://learn.microsoft.com/en-us/azure/media-services/latest/encode-concept)
![](https://learn.microsoft.com/en-us/azure/media/index/event-grid-domains.svg) [Event Grid](https://learn.microsoft.com/en-us/azure/event-grid/)
Get reliable event delivery at massive scale
[Event Grid](https://learn.microsoft.com/en-us/azure/event-grid/)
![](https://learn.microsoft.com/en-us/azure/media/index/event-hubs.svg) [Event Hubs](https://learn.microsoft.com/en-us/azure/event-hubs/)
Receive telemetry from millions of devices
[Event Hubs](https://learn.microsoft.com/en-us/azure/event-hubs/)
![](https://learn.microsoft.com/en-us/azure/media/index/hdinsight.svg) [HDInsight](https://learn.microsoft.com/en-us/azure/hdinsight/)
Provision cloud Hadoop, Spark, R Server, HBase, and Storm clusters
[HDInsight](https://learn.microsoft.com/en-us/azure/hdinsight/)
![](https://learn.microsoft.com/en-us/azure/media/index/health-bot-logo.svg) [Health Bot](https://learn.microsoft.com/en-us/azure/health-bot/)
A managed service purpose-built for development of virtual healthcare assistants.
[Health Bot](https://learn.microsoft.com/en-us/azure/health-bot/)
![](https://learn.microsoft.com/en-us/azure/media/index/key-vault.svg) [Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/)
Safeguard and maintain control of keys and other secrets
[Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/)
![](https://learn.microsoft.com/en-us/azure/media/index/media-services.svg) [Live and On-Demand Streaming](https://learn.microsoft.com/en-us/azure/media-services/latest/stream-live-tutorial-with-api)
Deliver content to virtually all devices with scale to meet business needs
[Live and On-Demand Streaming](https://learn.microsoft.com/en-us/azure/media-services/latest/stream-live-tutorial-with-api)
![](https://learn.microsoft.com/en-us/azure/media/index/load-balancer.svg) [Load Balancer](https://learn.microsoft.com/en-us/azure/load-balancer/)
Deliver high availability and network performance to your applications
[Load Balancer](https://learn.microsoft.com/en-us/azure/load-balancer/)
![](https://learn.microsoft.com/en-us/azure/media/index/logic-apps.svg) [Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/)
Automate the access and use of data across clouds without writing code
[Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/)
![](https://learn.microsoft.com/en-us/azure/media/index/media-services.svg) [Media Services](https://learn.microsoft.com/en-us/azure/media-services/latest/)
Encode, store, and stream video and audio at scale
[Media Services](https://learn.microsoft.com/en-us/azure/media-services/latest/)
![](https://learn.microsoft.com/en-us/azure/media/index/energy-data-services.svg) [Microsoft Azure Data Manager for Energy (Preview)](https://learn.microsoft.com/en-us/azure/energy-data-services/)
Accelerate your journey to energy data modernization and digital transformation
[Microsoft Azure Data Manager for Energy (Preview)](https://learn.microsoft.com/en-us/azure/energy-data-services/)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Microsoft Azure portal](https://learn.microsoft.com/en-us/azure/azure-portal/)
Build, manage, and monitor all Azure products in a single, unified console
[Microsoft Azure portal](https://learn.microsoft.com/en-us/azure/azure-portal/)
![](https://learn.microsoft.com/en-us/azure/media/index/defender.svg) [Microsoft Defender for Cloud](https://learn.microsoft.com/en-us/azure/defender-for-cloud/)
Security posture management and advanced threat protection across Azure, hybrid, and multicloud workloads
[Microsoft Defender for Cloud](https://learn.microsoft.com/en-us/azure/defender-for-cloud/)
![](https://learn.microsoft.com/en-us/azure/media/index/defender-easm.svg) [Microsoft Defender for External Attack Surface Management](https://learn.microsoft.com/en-us/azure/external-attack-surface-management/overview)
Safeguard the digital experience by discovering all internet-exposed resources
[Microsoft Defender for External Attack Surface Management](https://learn.microsoft.com/en-us/azure/external-attack-surface-management/overview)
![](https://learn.microsoft.com/en-us/azure/media/index/defender-iot.svg) [Microsoft Defender for IoT](https://learn.microsoft.com/en-us/azure/defender-for-iot/)
Continuous asset management and threat detection for both unmanaged and managed IoT/OT devices
[Microsoft Defender for IoT](https://learn.microsoft.com/en-us/azure/defender-for-iot/)
![](https://learn.microsoft.com/en-us/azure/media/index/dev-box.svg) [Microsoft Dev Box](https://learn.microsoft.com/en-us/azure/dev-box/)
Streamline development with secure, ready-to-code workstations in the cloud
[Microsoft Dev Box](https://learn.microsoft.com/en-us/azure/dev-box/)
![](https://learn.microsoft.com/en-us/azure/media/index/ad-domain-services.svg) [Microsoft Entra Domain Services](https://learn.microsoft.com/en-us/entra/identity/domain-services/)
Join Azure virtual machines to a domain without domain controllers
[Microsoft Entra Domain Services](https://learn.microsoft.com/en-us/entra/identity/domain-services/)
![](https://learn.microsoft.com/en-us/azure/media/index/active-directory-b2c.svg) [Microsoft Entra External ID](https://learn.microsoft.com/en-us/entra/external-id/)
Consumer identity and access management in the cloud
[Microsoft Entra External ID](https://learn.microsoft.com/en-us/entra/external-id/)
![](https://learn.microsoft.com/en-us/azure/media/index/active-directory.svg) [Microsoft Entra ID](https://learn.microsoft.com/en-us/entra/identity/)
Synchronize on-premises directories and enable single sign-on
[Microsoft Entra ID](https://learn.microsoft.com/en-us/entra/identity/)
![](https://learn.microsoft.com/en-us/azure/media/index/fabric.svg) [Microsoft Fabric](https://learn.microsoft.com/en-us/fabric/fundamentals/microsoft-fabric-overview)
Import, transform, analyze, and govern data
[Microsoft Fabric](https://learn.microsoft.com/en-us/fabric/fundamentals/microsoft-fabric-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/ai-studio.svg) [Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
Build market-ready applications for your organization with AI
[Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
![](https://learn.microsoft.com/en-us/azure/media/index/playwright-testing-icon.svg) [Microsoft Playwright Testing (Preview)](https://learn.microsoft.com/en-us/azure/playwright-testing/)
Run end-to-end Playwright tests at scale
[Microsoft Playwright Testing (Preview)](https://learn.microsoft.com/en-us/azure/playwright-testing/)
![](https://learn.microsoft.com/en-us/azure/media/index/purview.svg) [Microsoft Purview](https://learn.microsoft.com/en-us/purview/index)
Maximize business value with unified data governance
[Microsoft Purview](https://learn.microsoft.com/en-us/purview/index)
![](https://learn.microsoft.com/en-us/azure/media/index/sentinel.svg) [Microsoft Sentinel](https://learn.microsoft.com/en-us/azure/sentinel/)
Put cloud-native SIEM and intelligent security analytics to work to help protect your enterprise
[Microsoft Sentinel](https://learn.microsoft.com/en-us/azure/sentinel/)
![](https://learn.microsoft.com/en-us/azure/media/index/nat-gateway.svg) [NAT Gateway](https://learn.microsoft.com/en-us/azure/nat-gateway/)
Provide highly reliable, secure, and scalable outbound connectivity to the internet
[NAT Gateway](https://learn.microsoft.com/en-us/azure/nat-gateway/)
![](https://learn.microsoft.com/en-us/azure/media/index/notification-hubs.svg) [Notification Hubs](https://learn.microsoft.com/en-us/azure/notification-hubs/)
Send push notifications to any platform from any back end
[Notification Hubs](https://learn.microsoft.com/en-us/azure/notification-hubs/)
![](https://learn.microsoft.com/en-us/azure/media/index/power-bi.svg) [Power BI](https://learn.microsoft.com/en-us/power-bi/developer/azure-pbie-what-is-power-bi-embedded)
Turn your data into visually immersive and interactive insights
[Power BI](https://learn.microsoft.com/en-us/power-bi/developer/azure-pbie-what-is-power-bi-embedded)
![](https://learn.microsoft.com/en-us/azure/media/index/power-bi-embedded.svg) [Power BI Embedded](https://learn.microsoft.com/en-us/power-bi/fundamentals/power-bi-overview)
Embed fully interactive, stunning data visualizations in your applications
[Power BI Embedded](https://learn.microsoft.com/en-us/power-bi/fundamentals/power-bi-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-accounts.svg) [Queue Storage](https://learn.microsoft.com/en-us/azure/storage/queues/)
Effectively scale apps according to traffic
[Queue Storage](https://learn.microsoft.com/en-us/azure/storage/queues/)
![](https://learn.microsoft.com/en-us/azure/media/index/service-bus.svg) [Service Bus](https://learn.microsoft.com/en-us/azure/service-bus-messaging/)
Connect across private and public cloud environments
[Service Bus](https://learn.microsoft.com/en-us/azure/service-bus-messaging/)
![](https://learn.microsoft.com/en-us/azure/media/index/speech.svg) [Speech](https://learn.microsoft.com/en-us/azure/ai-services/speech-service/)
Speech to text, text to speech, translation, and speaker recognition
[Speech](https://learn.microsoft.com/en-us/azure/ai-services/speech-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/sql-server-vm.svg) [SQL Server on Virtual Machines](https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
Host enterprise SQL Server apps in the cloud
[SQL Server on Virtual Machines](https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
![](https://learn.microsoft.com/en-us/azure/media/index/static-apps.svg) [Static Web Apps](https://learn.microsoft.com/en-us/azure/static-web-apps/)
A modern web app service that offers streamlined full-stack development from source code to global high availability
[Static Web Apps](https://learn.microsoft.com/en-us/azure/static-web-apps/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-accounts.svg) [Storage](https://learn.microsoft.com/en-us/azure/storage/)
Durable, highly available, and massively scalable cloud storage
[Storage](https://learn.microsoft.com/en-us/azure/storage/)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-explorer.svg) [Storage Explorer](https://learn.microsoft.com/en-us/azure/vs-azure-tools-storage-manage-with-storage-explorer)
View and interact with Azure Storage resources
[Storage Explorer](https://learn.microsoft.com/en-us/azure/vs-azure-tools-storage-manage-with-storage-explorer)
![](https://learn.microsoft.com/en-us/azure/media/index/storage-accounts.svg) [Table Storage](https://learn.microsoft.com/en-us/azure/storage/tables/table-storage-overview)
NoSQL key-value store using semi-structured datasets
[Table Storage](https://learn.microsoft.com/en-us/azure/storage/tables/table-storage-overview)
![](https://learn.microsoft.com/en-us/azure/media/index/translator.svg) [Translator](https://learn.microsoft.com/en-us/azure/ai-services/translator/)
Easily conduct machine translation with a simple REST API call
[Translator](https://learn.microsoft.com/en-us/azure/ai-services/translator/)
![](https://learn.microsoft.com/en-us/azure/media/index/vm-scale-sets.svg) [Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/)
Manage and scale up to thousands of Linux and Windows virtual machines
[Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-machine.svg) [Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/)
Provision virtual machines for Ubuntu, Red Hat, Windows, and more
[Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-networks.svg) [Virtual Network](https://learn.microsoft.com/en-us/azure/virtual-network/)
Provision private networks, optionally connect to on-premises datacenters
[Virtual Network](https://learn.microsoft.com/en-us/azure/virtual-network/)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-wans.svg) [Virtual WAN](https://learn.microsoft.com/en-us/azure/virtual-wan/)
Microsoft-managed hub and spoke service for connectivity and security
[Virtual WAN](https://learn.microsoft.com/en-us/azure/virtual-wan/)
![](https://learn.microsoft.com/en-us/azure/media/index/vision.svg) [Vision](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/)
Distill actionable information from images
[Vision](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/)
![](https://learn.microsoft.com/en-us/media/logos/logo_visual-studio.svg) [Visual Studio](https://learn.microsoft.com/en-us/visualstudio/windows)
The powerful and flexible environment for developing applications in the cloud
[Visual Studio](https://learn.microsoft.com/en-us/visualstudio/windows)
![](https://learn.microsoft.com/en-us/media/logos/logo_vs-mobile-center.svg) [Visual Studio App Center](https://learn.microsoft.com/en-us/appcenter/)
Continuously build, test, release, and monitor your mobile and desktop apps
[Visual Studio App Center](https://learn.microsoft.com/en-us/appcenter/)
![](https://learn.microsoft.com/en-us/media/logos/logo_vs-code.svg) [Visual Studio Code](https://code.visualstudio.com/docs)
A powerful, lightweight code editor for cloud development
[Visual Studio Code](https://code.visualstudio.com/docs)
![](https://learn.microsoft.com/en-us/azure/media/index/virtual-network-gateways.svg) [VPN Gateway](https://learn.microsoft.com/en-us/azure/vpn-gateway/)
Establish secure, cross-premises connectivity
[VPN Gateway](https://learn.microsoft.com/en-us/azure/vpn-gateway/)
![](https://learn.microsoft.com/en-us/azure/media/index/web-apps-containers.svg) [Web App for Containers](https://learn.microsoft.com/en-us/azure/app-service/)
Easily deploy and run containerized web apps that scale with your business
[Web App for Containers](https://learn.microsoft.com/en-us/azure/app-service/)
![](https://learn.microsoft.com/en-us/azure/media/index/frontdoor-waf-policies.svg) [Web Application Firewall](https://learn.microsoft.com/en-us/azure/web-application-firewall/)
A cloud-native web application firewall (WAF) service that provides powerful protection for web apps
[Web Application Firewall](https://learn.microsoft.com/en-us/azure/web-application-firewall/)
![](https://learn.microsoft.com/en-us/azure/media/index/iot-windows10-core-services.svg) [Windows 10 IoT Core Services](https://learn.microsoft.com/en-us/windows-hardware/manufacture/iot/iotcoreservicesoverview)
Long-term OS support and services to manage device updates and assess device health
[Windows 10 IoT Core Services](https://learn.microsoft.com/en-us/windows-hardware/manufacture/iot/iotcoreservicesoverview)
![](https://learn.microsoft.com/en-us/azure/media/index/azure.svg) [Windows for IoT](https://learn.microsoft.com/en-us/windows/iot/)
Build intelligent edge solutions with world-class developer tools, long-term support, and enterprise-grade security
[Windows for IoT](https://learn.microsoft.com/en-us/windows/iot/)
### AI + Machine Learning
  * [Azure AI Bot Service](https://learn.microsoft.com/en-us/azure/bot-service/)
Intelligent, serverless bot service that scales on demand
  * [Azure AI Content Safety](https://learn.microsoft.com/en-us/azure/ai-services/content-safety/)
Use AI to monitor text and image content for safety
  * [Azure AI Custom Vision](https://learn.microsoft.com/en-us/azure/ai-services/custom-vision-service/)
Easily customize your own state-of-the-art computer vision models for your unique use case
  * [Azure AI Face](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/overview-identity)
Detect, identify, analyze, organize, and tag faces in photos
  * [Azure AI Immersive Reader](https://learn.microsoft.com/en-us/azure/ai-services/immersive-reader/)
Empower users of all ages and abilities to read and comprehend text
  * [Azure AI Search](https://learn.microsoft.com/en-us/azure/search/)
AI-powered cloud search service for mobile and web app development
  * [Azure AI Video Indexer](https://learn.microsoft.com/en-us/azure/azure-video-indexer/)
Unlock video insights
  * [Azure Databricks](https://learn.microsoft.com/en-us/azure/databricks/)
Fast, easy, and collaborative Apache Spark-based analytics platform
  * [Azure Document Intelligence in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/document-intelligence/)
The AI-powered document extraction service that understands your forms
  * [Azure Language in Foundry Tools](https://learn.microsoft.com/en-us/azure/ai-services/language-service/)
Easily evaluate sentiment and topics to understand what users want
  * [Azure Machine Learning](https://learn.microsoft.com/en-us/azure/machine-learning/)
Bring AI to everyone with an end-to-end, scalable, trusted platform with experimentation and model management
  * [Azure Open Datasets](https://learn.microsoft.com/en-us/azure/open-datasets/)
Cloud platform to host and share curated open datasets to accelerate development of machine learning models
  * [Azure OpenAI Service](https://learn.microsoft.com/en-us/azure/ai-services/openai/)
Apply advanced coding and language models to various use cases
  * [Data Science Virtual Machines](https://learn.microsoft.com/en-us/azure/machine-learning/data-science-virtual-machine/)
Rich preconfigured environment for AI development
  * [Health Bot](https://learn.microsoft.com/en-us/azure/health-bot/)
A managed service purpose-built for development of virtual healthcare assistants.
  * [Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
Build market-ready applications for your organization with AI
  * [Speech](https://learn.microsoft.com/en-us/azure/ai-services/speech-service/)
Speech to text, text to speech, translation, and speaker recognition
  * [Translator](https://learn.microsoft.com/en-us/azure/ai-services/translator/)
Easily conduct machine translation with a simple REST API call
  * [Vision](https://learn.microsoft.com/en-us/azure/ai-services/computer-vision/)
Distill actionable information from images


### Analytics
  * [Azure Analysis Services](https://learn.microsoft.com/en-us/azure/analysis-services/)
Enterprise-grade analytics engine as a service
  * [Azure Chaos Studio](https://learn.microsoft.com/en-us/azure/chaos-studio/)
Improve application resilience by introducing faults and simulating outages
  * [Azure Data Explorer](https://learn.microsoft.com/en-us/azure/data-explorer)
Fast and highly scalable data exploration service
  * [Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
Hybrid data integration at enterprise scale, made easy
  * [Azure Data Lake Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction)
Massively scalable, secure data lake functionality built on Azure Blob Storage
  * [Azure Data Share](https://learn.microsoft.com/en-us/azure/data-share/)
A simple and safe service for sharing big data with external organizations
  * [Azure Databricks](https://learn.microsoft.com/en-us/azure/databricks/)
Fast, easy, and collaborative Apache Spark-based analytics platform
  * [Azure Stream Analytics](https://learn.microsoft.com/en-us/azure/stream-analytics/)
Real-time analytics on fast moving streams of data from applications and devices
  * [Azure Synapse Analytics](https://learn.microsoft.com/en-us/azure/synapse-analytics/)
Limitless analytics service with unmatched time to insight
  * [Data Lake Analytics](https://learn.microsoft.com/en-us/azure/data-lake-analytics/)
Distributed analytics service that makes big data easy
  * [Event Hubs](https://learn.microsoft.com/en-us/azure/event-hubs/)
Receive telemetry from millions of devices
  * [HDInsight](https://learn.microsoft.com/en-us/azure/hdinsight/)
Provision cloud Hadoop, Spark, R Server, HBase, and Storm clusters
  * [Microsoft Fabric](https://learn.microsoft.com/en-us/fabric/fundamentals/microsoft-fabric-overview)
Import, transform, analyze, and govern data
  * [Microsoft Purview](https://learn.microsoft.com/en-us/purview/index)
Maximize business value with unified data governance
  * [Power BI](https://learn.microsoft.com/en-us/power-bi/developer/azure-pbie-what-is-power-bi-embedded)
Turn your data into visually immersive and interactive insights
  * [Power BI Embedded](https://learn.microsoft.com/en-us/power-bi/fundamentals/power-bi-overview)
Embed fully interactive, stunning data visualizations in your applications


### Compute
  * [App Service](https://learn.microsoft.com/en-us/azure/app-service/)
Quickly create powerful cloud apps for web and mobile
  * [Azure Compute Fleet (Preview)](https://learn.microsoft.com/en-us/azure/azure-compute-fleet/overview)
Easily provision and manage Azure compute capacity at scale
  * [Azure Container Instances](https://learn.microsoft.com/en-us/azure/container-instances/)
Easily run containers on Azure without managing servers
  * [Azure CycleCloud](https://learn.microsoft.com/en-us/azure/cyclecloud/index)
Create, manage, operate, and optimize HPC and big compute clusters of any scale
  * [Azure Dedicated Host](https://learn.microsoft.com/en-us/azure/virtual-machines/dedicated-hosts)
A dedicated physical server to host your Azure VMs for Windows and Linux
  * [Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
Process events with serverless code
  * [Azure Kubernetes Fleet Manager](https://learn.microsoft.com/en-us/azure/kubernetes-fleet/)
Enable multi-cluster and at-scale scenarios for Azure Kubernetes Service clusters
  * [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/en-us/azure/aks/)
Simplify the deployment, management, and operations of Kubernetes
  * [Azure Quantum (Preview)](https://learn.microsoft.com/en-us/azure/quantum/)
Experience quantum impact today on Azure
  * [Azure Service Fabric](https://learn.microsoft.com/en-us/azure/service-fabric/)
Develop microservices and orchestrate containers on Windows or Linux
  * [Azure Spot Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/spot-vms)
Provision unused compute capacity at deep discounts to run interruptible workloads
  * [Azure Spring Apps](https://learn.microsoft.com/en-us/azure/spring-apps/)
A fully managed Spring Cloud service, built and operated with Pivotal
  * [Azure Virtual Desktop](https://learn.microsoft.com/en-us/azure/virtual-desktop/)
The best virtual desktop experience, delivered on Azure
  * [Azure VMware Solution](https://learn.microsoft.com/en-us/azure/azure-vmware/)
Run your VMware workloads natively on Azure
  * [Batch](https://learn.microsoft.com/en-us/azure/batch/)
Cloud-scale job scheduling and compute management
  * [Cloud Services](https://learn.microsoft.com/en-us/azure/cloud-services-extended-support/)
Create highly available, infinitely scalable cloud applications and APIs
  * [SQL Server on Virtual Machines](https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
Host enterprise SQL Server apps in the cloud
  * [Static Web Apps](https://learn.microsoft.com/en-us/azure/static-web-apps/)
A modern web app service that offers streamlined full-stack development from source code to global high availability
  * [Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/)
Manage and scale up to thousands of Linux and Windows virtual machines
  * [Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/)
Provision virtual machines for Ubuntu, Red Hat, Windows, and more


### Containers
  * [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
  * [Azure Container Apps](https://learn.microsoft.com/en-us/azure/container-apps/)
Build and deploy modern apps and microservices using serverless containers
  * [Azure Container Instances](https://learn.microsoft.com/en-us/azure/container-instances/)
Easily run containers on Azure without managing servers
  * [Azure Container Registry](https://learn.microsoft.com/en-us/azure/container-registry/)
Store and manage container images across all types of Azure deployments
  * [Azure Container Storage](https://learn.microsoft.com/en-us/azure/storage/container-storage/)
Manage persistent volumes for stateful container applications
  * [Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
Process events with serverless code
  * [Azure Kubernetes Fleet Manager](https://learn.microsoft.com/en-us/azure/kubernetes-fleet/)
Enable multi-cluster and at-scale scenarios for Azure Kubernetes Service clusters
  * [Azure Kubernetes Service (AKS)](https://learn.microsoft.com/en-us/azure/aks/)
Simplify the deployment, management, and operations of Kubernetes
  * [Azure Red Hat OpenShift](https://learn.microsoft.com/en-us/azure/openshift/)
Fully managed OpenShift service, jointly operated with Red Hat
  * [Azure Service Fabric](https://learn.microsoft.com/en-us/azure/service-fabric/)
Develop microservices and orchestrate containers on Windows or Linux
  * [Web App for Containers](https://learn.microsoft.com/en-us/azure/app-service/)
Easily deploy and run containerized web apps that scale with your business


### Databases
  * [Azure Cache for Redis](https://learn.microsoft.com/en-us/azure/azure-cache-for-redis/)
Power applications with high-throughput, low-latency data access
  * [Azure confidential ledger](https://learn.microsoft.com/en-us/azure/confidential-ledger/)
Tamperproof, unstructured data store hosted in trusted execution environments (TEEs) and backed by cryptographically verifiable evidence
  * [Azure Cosmos DB](https://learn.microsoft.com/en-us/azure/cosmos-db/)
Fast NoSQL database with open APIs for any scale
  * [Azure Data Factory](https://learn.microsoft.com/en-us/azure/data-factory/)
Hybrid data integration at enterprise scale, made easy
  * [Azure Database for MariaDB](https://learn.microsoft.com/en-us/azure/mariadb/)
Managed MariaDB database service for app developers
  * [Azure Database for MySQL](https://learn.microsoft.com/en-us/azure/mysql/)
Managed MySQL database service for app developers
  * [Azure Database for PostgreSQL](https://learn.microsoft.com/en-us/azure/postgresql/)
Managed PostgreSQL database service for app developers
  * [Azure Database Migration Service](https://learn.microsoft.com/en-us/azure/dms/)
Simplify on-premises database migration to the cloud
  * [Azure DocumentDB](https://learn.microsoft.com/en-us/azure/documentdb/)
Powerful MongoDB-compatible open-source document database for modern apps
  * [Azure Managed Instance for Apache Cassandra](https://learn.microsoft.com/en-us/azure/managed-instance-apache-cassandra/)
Automate deployment and scaling for managed open-source Apache Cassandra datacenters
  * [Azure Managed Redis](https://learn.microsoft.com/en-us/azure/redis/)
Power applications with a high-performance, managed cache
  * [Azure SQL](https://learn.microsoft.com/en-us/azure/azure-sql/index)
Modern SQL family for migration and app modernization
  * [Azure SQL Database](https://learn.microsoft.com/en-us/azure/azure-sql/database/index)
Managed, intelligent SQL in the cloud
  * [Azure SQL Managed Instance](https://learn.microsoft.com/en-us/azure/azure-sql/managed-instance/index)
Managed, always up-to-date SQL instance in the cloud
  * [SQL Server on Virtual Machines](https://learn.microsoft.com/en-us/azure/azure-sql/virtual-machines/windows/sql-server-on-azure-vm-iaas-what-is-overview?toc=/azure/virtual-machines/windows/toc.json)
Host enterprise SQL Server apps in the cloud
  * [Table Storage](https://learn.microsoft.com/en-us/azure/storage/tables/table-storage-overview)
NoSQL key-value store using semi-structured datasets


### Developer Tools
  * [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
  * [Azure Boards](https://learn.microsoft.com/en-us/azure/devops/boards/)
Plan, track, and discuss work across your teams
  * [Azure DevOps](https://learn.microsoft.com/en-us/azure/devops/)
Services for teams to share code, track work, and ship software
  * [Azure DevTest Labs](https://learn.microsoft.com/en-us/azure/devtest-labs/)
Quickly create environments using reusable templates and artifacts
  * [Azure Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)
Continuously build, test, and deploy to any platform and cloud
  * [Microsoft Dev Box](https://learn.microsoft.com/en-us/azure/dev-box/)
Streamline development with secure, ready-to-code workstations in the cloud
  * [Microsoft Playwright Testing (Preview)](https://learn.microsoft.com/en-us/azure/playwright-testing/)
Run end-to-end Playwright tests at scale
  * [Visual Studio](https://learn.microsoft.com/en-us/visualstudio/windows)
The powerful and flexible environment for developing applications in the cloud
  * [Visual Studio Code](https://code.visualstudio.com/docs)
A powerful, lightweight code editor for cloud development


### DevOps
  * [Azure App Testing](https://learn.microsoft.com/en-us/azure/app-testing/)
Test your app holistically with Azure Load Testing and Playwright Workspaces
  * [Azure Artifacts](https://learn.microsoft.com/en-us/azure/devops/artifacts/)
Create, host, and share packages with your team
  * [Azure Boards](https://learn.microsoft.com/en-us/azure/devops/boards/)
Plan, track, and discuss work across your teams
  * [Azure Deployment Environments](https://learn.microsoft.com/en-us/azure/deployment-environments/)
Quickly spin up app infrastructure environments with project-based templates
  * [Azure DevOps](https://learn.microsoft.com/en-us/azure/devops/)
Services for teams to share code, track work, and ship software
  * [Azure DevTest Labs](https://learn.microsoft.com/en-us/azure/devtest-labs/)
Quickly create environments using reusable templates and artifacts
  * [Azure Managed Grafana](https://learn.microsoft.com/en-us/azure/managed-grafana/)
Deploy Grafana dashboards as a fully managed Azure service
  * [Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/)
Full observability into your applications, infrastructure, and network
  * [Azure Pipelines](https://learn.microsoft.com/en-us/azure/devops/pipelines/)
Continuously build, test, and deploy to any platform and cloud
  * [Azure Repos](https://learn.microsoft.com/en-us/azure/devops/repos/)
Get unlimited, cloud-hosted private Git repos for your project
  * [Azure Test Plans](https://learn.microsoft.com/en-us/azure/devops/test/)
Test and ship with confidence with a manual and exploratory testing toolkit
  * [Microsoft Dev Box](https://learn.microsoft.com/en-us/azure/dev-box/)
Streamline development with secure, ready-to-code workstations in the cloud
  * [Microsoft Playwright Testing (Preview)](https://learn.microsoft.com/en-us/azure/playwright-testing/)
Run end-to-end Playwright tests at scale


### Hybrid + multicloud
  * [Azure Arc](https://learn.microsoft.com/en-us/azure/azure-arc/)
Bring Azure services and management to any infrastructure
  * [Azure Database for PostgreSQL](https://learn.microsoft.com/en-us/azure/postgresql/)
Managed PostgreSQL database service for app developers
  * [Azure DevOps](https://learn.microsoft.com/en-us/azure/devops/)
Services for teams to share code, track work, and ship software
  * [Azure ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/)
Dedicated private network fiber connections to Azure
  * [Azure IoT Edge](https://learn.microsoft.com/en-us/azure/iot-edge/)
Extend cloud intelligence and analytics to edge devices
  * [Azure Kubernetes Service Edge Essentials](https://learn.microsoft.com/en-us/azure/aks/hybrid/aks-edge-overview)
An on-premises Kubernetes implementation of Azure Kubernetes Service (AKS) that automates running containerized applications at scale
  * [Azure Local](https://learn.microsoft.com/en-us/azure/azure-local/)
Operate infrastructure across distributed locations enabled by Azure Arc
  * [Azure Operator Insights](https://learn.microsoft.com/en-us/azure/operator-insights/)
Analyze network data from multiple sources
  * [Azure Operator Nexus](https://learn.microsoft.com/en-us/azure/operator-nexus/)
Build your mission-critical mobile networks with a carrier-grade, hybrid cloud platform
  * [Azure Operator Service Manager](https://learn.microsoft.com/en-us/azure/operator-service-manager/)
Manage network services across hybrid cloud sites
  * [Azure SQL](https://learn.microsoft.com/en-us/azure/azure-sql/index)
Modern SQL family for migration and app modernization
  * [Azure Stack Edge](https://learn.microsoft.com/en-us/azure/databox-online/)
An Azure managed appliance that brings the compute, storage, and intelligence of Azure to the edge
  * [Azure Stack Hub](https://learn.microsoft.com/en-us/azure-stack/operator/)
Azure Stack Hub is sold as an integrated hardware system, with software preinstalled on validated hardware
  * [Microsoft Entra ID](https://learn.microsoft.com/en-us/entra/identity/)
Synchronize on-premises directories and enable single sign-on
  * [Microsoft Sentinel](https://learn.microsoft.com/en-us/azure/sentinel/)
Put cloud-native SIEM and intelligent security analytics to work to help protect your enterprise


### Identity
  * [Azure Information Protection](https://learn.microsoft.com/en-us/azure/information-protection/)
Better protect your sensitive information—anytime, anywhere
  * [Microsoft Entra Domain Services](https://learn.microsoft.com/en-us/entra/identity/domain-services/)
Join Azure virtual machines to a domain without domain controllers
  * [Microsoft Entra External ID](https://learn.microsoft.com/en-us/entra/external-id/)
Consumer identity and access management in the cloud
  * [Microsoft Entra ID](https://learn.microsoft.com/en-us/entra/identity/)
Synchronize on-premises directories and enable single sign-on


### Integration
  * [API Management](https://learn.microsoft.com/en-us/azure/api-management/)
Publish APIs to developers, partners, and employees securely and at scale
  * [Azure API for FHIR](https://learn.microsoft.com/en-us/azure/healthcare-apis/azure-api-for-fhir/)
Easily create and deploy a FHIR service for health data solutions and interoperability
  * [Azure Data Manager for Agriculture (Preview)](https://learn.microsoft.com/en-us/azure/data-manager-for-agri/)
Create a more sustainable future by innovating with agriculture data
  * [Azure Health Data Services](https://learn.microsoft.com/en-us/azure/healthcare-apis/)
A unified solution that helps protect and combine health data in the cloud and generates healthcare insights with analytics
  * [Azure Web PubSub](https://learn.microsoft.com/en-us/azure/azure-web-pubsub/)
Easily build real-time messaging web applications using WebSockets and the publish-subscribe pattern
  * [Event Grid](https://learn.microsoft.com/en-us/azure/event-grid/)
Get reliable event delivery at massive scale
  * [Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/)
Automate the access and use of data across clouds without writing code
  * [Microsoft Azure Data Manager for Energy (Preview)](https://learn.microsoft.com/en-us/azure/energy-data-services/)
Accelerate your journey to energy data modernization and digital transformation
  * [Service Bus](https://learn.microsoft.com/en-us/azure/service-bus-messaging/)
Connect across private and public cloud environments


### Internet of Things
  * [API Management](https://learn.microsoft.com/en-us/azure/api-management/)
Publish APIs to developers, partners, and employees securely and at scale
  * [Azure Cosmos DB](https://learn.microsoft.com/en-us/azure/cosmos-db/)
Fast NoSQL database with open APIs for any scale
  * [Azure Digital Twins](https://learn.microsoft.com/en-us/azure/digital-twins/)
Build next-generation IoT spatial intelligence solutions
  * [Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
Process events with serverless code
  * [Azure IoT](https://learn.microsoft.com/en-us/azure/iot/)
A collection of Microsoft-managed cloud and edge services that connect, monitor, and control billions of IoT assets.
  * [Azure IoT Central](https://learn.microsoft.com/en-us/azure/iot-central/)
Accelerate the creation of IoT solutions
  * [Azure IoT Edge](https://learn.microsoft.com/en-us/azure/iot-edge/)
Extend cloud intelligence and analytics to edge devices
  * [Azure IoT Hub](https://learn.microsoft.com/en-us/azure/iot-hub/)
Connect, monitor, and manage billions of IoT assets
  * [Azure IoT Operations](https://learn.microsoft.com/en-us/azure/iot-operations/)
Unlock insights for intelligent local actions and global visibility
  * [Azure Machine Learning](https://learn.microsoft.com/en-us/azure/machine-learning/)
Bring AI to everyone with an end-to-end, scalable, trusted platform with experimentation and model management
  * [Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/)
Simple and secure location APIs provide geospatial context to data
  * [Azure Sphere](https://learn.microsoft.com/en-us/azure-sphere/)
Securely connect MCU-powered devices from the silicon to the cloud
  * [Azure Stream Analytics](https://learn.microsoft.com/en-us/azure/stream-analytics/)
Real-time analytics on fast moving streams of data from applications and devices
  * [Event Grid](https://learn.microsoft.com/en-us/azure/event-grid/)
Get reliable event delivery at massive scale
  * [Logic Apps](https://learn.microsoft.com/en-us/azure/logic-apps/)
Automate the access and use of data across clouds without writing code
  * [Microsoft Defender for IoT](https://learn.microsoft.com/en-us/azure/defender-for-iot/)
Continuous asset management and threat detection for both unmanaged and managed IoT/OT devices
  * [Notification Hubs](https://learn.microsoft.com/en-us/azure/notification-hubs/)
Send push notifications to any platform from any back end
  * [Windows 10 IoT Core Services](https://learn.microsoft.com/en-us/windows-hardware/manufacture/iot/iotcoreservicesoverview)
Long-term OS support and services to manage device updates and assess device health
  * [Windows for IoT](https://learn.microsoft.com/en-us/windows/iot/)
Build intelligent edge solutions with world-class developer tools, long-term support, and enterprise-grade security


### Management and Governance
  * [ARM templates](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/)
Deliver infrastructure as code for all your Azure resources using Resource Manager
  * [Automation](https://learn.microsoft.com/en-us/azure/automation/)
Simplify cloud management with process automation
  * [Azure Advisor](https://learn.microsoft.com/en-us/azure/advisor/)
Your personalized Azure best practices recommendation engine
  * [Azure Backup](https://learn.microsoft.com/en-us/azure/backup/)
Simplify data protection and protect against ransomware
  * [Azure Blueprints (Preview)](https://learn.microsoft.com/en-us/azure/governance/blueprints/)
Enabling quick, repeatable creation of governed environments
  * [Azure Chaos Studio](https://learn.microsoft.com/en-us/azure/chaos-studio/)
Improve application resilience by introducing faults and simulating outages
  * [Azure Cloud Shell](https://learn.microsoft.com/en-us/azure/cloud-shell/overview)
Streamline Azure administration with a browser-based shell
  * [Azure Copilot](https://learn.microsoft.com/en-us/azure/copilot)
Simplify operations and management from cloud to edge with an AI companion
  * [Azure Lighthouse](https://learn.microsoft.com/en-us/azure/lighthouse/)
Empowering service providers to manage customers at scale and with precision
  * [Azure Managed Applications](https://learn.microsoft.com/en-us/azure/azure-resource-manager/managed-applications/)
Simplify management of cloud offerings
  * [Azure Managed Grafana](https://learn.microsoft.com/en-us/azure/managed-grafana/)
Deploy Grafana dashboards as a fully managed Azure service
  * [Azure Migrate](https://learn.microsoft.com/en-us/azure/migrate/)
Easily discover, assess, right-size, and migrate your on-premises VMs to Azure
  * [Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/)
Full observability into your applications, infrastructure, and network
  * [Azure Policy](https://learn.microsoft.com/en-us/azure/governance/policy/)
Implement corporate governance and standards at scale for Azure resources
  * [Azure Resource Manager](https://learn.microsoft.com/en-us/azure/azure-resource-manager/)
Simplify how you manage your app resources
  * [Azure Resource Mover](https://learn.microsoft.com/en-us/azure/resource-mover/)
Simplify how you move multiple resources between Azure regions
  * [Azure Service Health](https://learn.microsoft.com/en-us/azure/service-health/)
Personalized guidance and support for when issues in Azure services affect you
  * [Azure Site Recovery](https://learn.microsoft.com/en-us/azure/site-recovery/)
Keep your business running with built-in disaster recovery service
  * [Azure Update Manager](https://learn.microsoft.com/en-us/azure/update-manager/)
Centrally manage updates and compliance at scale
  * [Cost Management + Billing](https://learn.microsoft.com/en-us/azure/cost-management-billing/)
Optimize what you spend on the cloud, while maximizing cloud potential
  * [Microsoft Azure portal](https://learn.microsoft.com/en-us/azure/azure-portal/)
Build, manage, and monitor all Azure products in a single, unified console
  * [Microsoft Defender for External Attack Surface Management](https://learn.microsoft.com/en-us/azure/external-attack-surface-management/overview)
Safeguard the digital experience by discovering all internet-exposed resources
  * [Microsoft Purview](https://learn.microsoft.com/en-us/purview/index)
Maximize business value with unified data governance


### Media
  * [Azure AI Video Indexer](https://learn.microsoft.com/en-us/azure/azure-video-indexer/)
Unlock video insights
  * [Azure Front Door and Content Delivery Network (CDN)](https://learn.microsoft.com/en-us/azure/frontdoor/)
Ensure secure, reliable content delivery with broad global reach
  * [Azure Media Player](https://learn.microsoft.com/en-us/azure/media-services/latest/player-media-players-concept)
A single player for all your playback needs
  * [Content Protection](https://learn.microsoft.com/en-us/azure/media-services/latest/drm-content-protection-concept)
Securely deliver content using AES, PlayReady, Widevine, and Fairplay
  * [Encoding](https://learn.microsoft.com/en-us/azure/media-services/latest/encode-concept)
Studio grade encoding at cloud scale
  * [Live and On-Demand Streaming](https://learn.microsoft.com/en-us/azure/media-services/latest/stream-live-tutorial-with-api)
Deliver content to virtually all devices with scale to meet business needs
  * [Media Services](https://learn.microsoft.com/en-us/azure/media-services/latest/)
Encode, store, and stream video and audio at scale


### Migration
  * [Azure Data Box](https://learn.microsoft.com/en-us/azure/databox/)
Appliances and solutions for data transfer to Azure
  * [Azure Database Migration Service](https://learn.microsoft.com/en-us/azure/dms/)
Simplify on-premises database migration to the cloud
  * [Azure Migrate](https://learn.microsoft.com/en-us/azure/migrate/)
Easily discover, assess, right-size, and migrate your on-premises VMs to Azure
  * [Azure Site Recovery](https://learn.microsoft.com/en-us/azure/site-recovery/)
Keep your business running with built-in disaster recovery service
  * [Cost Management + Billing](https://learn.microsoft.com/en-us/azure/cost-management-billing/)
Optimize what you spend on the cloud, while maximizing cloud potential


### Mixed Reality
  * [Azure Digital Twins](https://learn.microsoft.com/en-us/azure/digital-twins/)
Build next-generation IoT spatial intelligence solutions


### Mobile
  * [API Management](https://learn.microsoft.com/en-us/azure/api-management/)
Publish APIs to developers, partners, and employees securely and at scale
  * [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
  * [App Service](https://learn.microsoft.com/en-us/azure/app-service/)
Quickly create powerful cloud apps for web and mobile
  * [Azure AI Search](https://learn.microsoft.com/en-us/azure/search/)
AI-powered cloud search service for mobile and web app development
  * [Azure Communication Services](https://learn.microsoft.com/en-us/azure/communication-services/overview)
Build rich communication experiences with the same secure platform used by Microsoft Teams
  * [Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/)
Simple and secure location APIs provide geospatial context to data
  * [Microsoft Foundry](https://learn.microsoft.com/en-us/azure/ai-foundry/)
Build market-ready applications for your organization with AI
  * [Notification Hubs](https://learn.microsoft.com/en-us/azure/notification-hubs/)
Send push notifications to any platform from any back end
  * [Visual Studio App Center](https://learn.microsoft.com/en-us/appcenter/)
Continuously build, test, release, and monitor your mobile and desktop apps


### Networking
  * [All networking services](https://learn.microsoft.com/en-us/azure/networking/)
Provide connectivity to your resources in Azure, deliver and protect applications, and help secure your network.
  * [Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/)
Build secure, scalable, and highly available web front ends in Azure
  * [Azure DDoS Protection](https://learn.microsoft.com/en-us/azure/ddos-protection/)
Protect your applications from Distributed Denial of Service (DDoS) attacks
  * [Azure DNS](https://learn.microsoft.com/en-us/azure/dns/)
Host your DNS domain in Azure
  * [Azure ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/)
Dedicated private network fiber connections to Azure
  * [Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/)
Native firewalling capabilities with built-in high availability, unrestricted cloud scalability, and zero maintenance
  * [Azure Front Door](https://learn.microsoft.com/en-us/azure/frontdoor/)
Scalable, security-enhanced delivery point for global, microservice-based web applications
  * [Azure Private Link](https://learn.microsoft.com/en-us/azure/private-link/)
Private access to services hosted on the Azure platform, keeping your data on the Microsoft network
  * [Load Balancer](https://learn.microsoft.com/en-us/azure/load-balancer/)
Deliver high availability and network performance to your applications
  * [NAT Gateway](https://learn.microsoft.com/en-us/azure/nat-gateway/)
Provide highly reliable, secure, and scalable outbound connectivity to the internet
  * [Virtual Network](https://learn.microsoft.com/en-us/azure/virtual-network/)
Provision private networks, optionally connect to on-premises datacenters
  * [Virtual WAN](https://learn.microsoft.com/en-us/azure/virtual-wan/)
Microsoft-managed hub and spoke service for connectivity and security
  * [VPN Gateway](https://learn.microsoft.com/en-us/azure/vpn-gateway/)
Establish secure, cross-premises connectivity
  * [Web Application Firewall](https://learn.microsoft.com/en-us/azure/web-application-firewall/)
A cloud-native web application firewall (WAF) service that provides powerful protection for web apps


### Security
  * [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
  * [Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/)
Build secure, scalable, and highly available web front ends in Azure
  * [Azure confidential ledger](https://learn.microsoft.com/en-us/azure/confidential-ledger/)
Tamperproof, unstructured data store hosted in trusted execution environments (TEEs) and backed by cryptographically verifiable evidence
  * [Azure DDoS Protection](https://learn.microsoft.com/en-us/azure/ddos-protection/)
Protect your applications from Distributed Denial of Service (DDoS) attacks
  * [Azure Dedicated HSM](https://learn.microsoft.com/en-us/azure/dedicated-hsm/)
Manage hardware security modules that you use in the cloud
  * [Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/)
Native firewalling capabilities with built-in high availability, unrestricted cloud scalability, and zero maintenance
  * [Azure Front Door](https://learn.microsoft.com/en-us/azure/frontdoor/)
Scalable, security-enhanced delivery point for global, microservice-based web applications
  * [Azure Information Protection](https://learn.microsoft.com/en-us/azure/information-protection/)
Better protect your sensitive information—anytime, anywhere
  * [Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/)
Safeguard and maintain control of keys and other secrets
  * [Microsoft Defender for Cloud](https://learn.microsoft.com/en-us/azure/defender-for-cloud/)
Security posture management and advanced threat protection across Azure, hybrid, and multicloud workloads
  * [Microsoft Defender for External Attack Surface Management](https://learn.microsoft.com/en-us/azure/external-attack-surface-management/overview)
Safeguard the digital experience by discovering all internet-exposed resources
  * [Microsoft Defender for IoT](https://learn.microsoft.com/en-us/azure/defender-for-iot/)
Continuous asset management and threat detection for both unmanaged and managed IoT/OT devices
  * [Microsoft Entra Domain Services](https://learn.microsoft.com/en-us/entra/identity/domain-services/)
Join Azure virtual machines to a domain without domain controllers
  * [Microsoft Entra ID](https://learn.microsoft.com/en-us/entra/identity/)
Synchronize on-premises directories and enable single sign-on
  * [Microsoft Sentinel](https://learn.microsoft.com/en-us/azure/sentinel/)
Put cloud-native SIEM and intelligent security analytics to work to help protect your enterprise
  * [VPN Gateway](https://learn.microsoft.com/en-us/azure/vpn-gateway/)
Establish secure, cross-premises connectivity
  * [Web Application Firewall](https://learn.microsoft.com/en-us/azure/web-application-firewall/)
A cloud-native web application firewall (WAF) service that provides powerful protection for web apps


### Storage
  * [Archive Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/access-tiers-overview)
Industry leading price point for storing rarely accessed data
  * [Azure Backup](https://learn.microsoft.com/en-us/azure/backup/)
Simplify data protection and protect against ransomware
  * [Azure Blob Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/)
REST-based object storage for unstructured data
  * [Azure confidential ledger](https://learn.microsoft.com/en-us/azure/confidential-ledger/)
Tamperproof, unstructured data store hosted in trusted execution environments (TEEs) and backed by cryptographically verifiable evidence
  * [Azure Container Storage](https://learn.microsoft.com/en-us/azure/storage/container-storage/)
Manage persistent volumes for stateful container applications
  * [Azure Data Box](https://learn.microsoft.com/en-us/azure/databox/)
Appliances and solutions for data transfer to Azure
  * [Azure Data Lake Storage](https://learn.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-introduction)
Massively scalable, secure data lake functionality built on Azure Blob Storage
  * [Azure Data Share](https://learn.microsoft.com/en-us/azure/data-share/)
A simple and safe service for sharing big data with external organizations
  * [Azure Disk Storage](https://learn.microsoft.com/en-us/azure/virtual-machines/managed-disks-overview)
High-performance, highly durable block storage for Azure Virtual Machines
  * [Azure Elastic SAN](https://learn.microsoft.com/en-us/azure/storage/elastic-san/)
Elastic SAN is a cloud-native Storage Area Network (SAN) service built on Azure. Gain access to an end-to-end experience like your on-premises SAN.
  * [Azure Files](https://learn.microsoft.com/en-us/azure/storage/files/)
Simple, secure and serverless enterprise-grade cloud file shares
  * [Azure Managed Lustre](https://learn.microsoft.com/en-us/azure/azure-managed-lustre/)
A fully managed, cloud based parallel file system that enables customers to run their high performance computing (HPC) workloads in the cloud
  * [Azure NetApp Files](https://learn.microsoft.com/en-us/azure/azure-netapp-files/)
Enterprise-grade Azure file shares, powered by NetApp
  * [Azure Storage Actions](https://learn.microsoft.com/en-us/azure/storage-actions/storage-tasks/)
Simplify storage data management at massive scale
  * [Queue Storage](https://learn.microsoft.com/en-us/azure/storage/queues/)
Effectively scale apps according to traffic
  * [Storage](https://learn.microsoft.com/en-us/azure/storage/)
Durable, highly available, and massively scalable cloud storage
  * [Storage Explorer](https://learn.microsoft.com/en-us/azure/vs-azure-tools-storage-manage-with-storage-explorer)
View and interact with Azure Storage resources


### Virtual Desktop Infrastructure
  * [Azure Lab Services](https://learn.microsoft.com/en-us/azure/lab-services/)
Set up virtual labs for classes, training, hackathons, and other related scenarios
  * [Azure Virtual Desktop](https://learn.microsoft.com/en-us/azure/virtual-desktop/)
The best virtual desktop experience, delivered on Azure
  * [Microsoft Dev Box](https://learn.microsoft.com/en-us/azure/dev-box/)
Streamline development with secure, ready-to-code workstations in the cloud


### Web
  * [API Management](https://learn.microsoft.com/en-us/azure/api-management/)
Publish APIs to developers, partners, and employees securely and at scale
  * [App Configuration](https://learn.microsoft.com/en-us/azure/azure-app-configuration/)
Fast, scalable parameter storage for app configuration
  * [App Service](https://learn.microsoft.com/en-us/azure/app-service/)
Quickly create powerful cloud apps for web and mobile
  * [Azure AI Search](https://learn.microsoft.com/en-us/azure/search/)
AI-powered cloud search service for mobile and web app development
  * [Azure Communication Services](https://learn.microsoft.com/en-us/azure/communication-services/overview)
Build rich communication experiences with the same secure platform used by Microsoft Teams
  * [Azure Fluid Relay](https://learn.microsoft.com/en-us/azure/azure-fluid-relay/)
Easily add real-time collaborative experiences to your apps with Fluid Framework
  * [Azure Front Door and Content Delivery Network (CDN)](https://learn.microsoft.com/en-us/azure/frontdoor/)
Ensure secure, reliable content delivery with broad global reach
  * [Azure Functions](https://learn.microsoft.com/en-us/azure/azure-functions/)
Process events with serverless code
  * [Azure Maps](https://learn.microsoft.com/en-us/azure/azure-maps/)
Simple and secure location APIs provide geospatial context to data
  * [Azure SignalR Service](https://learn.microsoft.com/en-us/azure/azure-signalr/)
Add real-time web functionality easily
  * [Azure Spring Apps](https://learn.microsoft.com/en-us/azure/spring-apps/)
A fully managed Spring Cloud service, built and operated with Pivotal
  * [Azure Web PubSub](https://learn.microsoft.com/en-us/azure/azure-web-pubsub/)
Easily build real-time messaging web applications using WebSockets and the publish-subscribe pattern
  * [Microsoft Playwright Testing (Preview)](https://learn.microsoft.com/en-us/azure/playwright-testing/)
Run end-to-end Playwright tests at scale
  * [Notification Hubs](https://learn.microsoft.com/en-us/azure/notification-hubs/)
Send push notifications to any platform from any back end
  * [Static Web Apps](https://learn.microsoft.com/en-us/azure/static-web-apps/)
A modern web app service that offers streamlined full-stack development from source code to global high availability
  * [Web App for Containers](https://learn.microsoft.com/en-us/azure/app-service/)
Easily deploy and run containerized web apps that scale with your business


[](https://learn.microsoft.com/en-us/azure/?product=popular#languages-and-tools)
## Languages and tools
![](https://learn.microsoft.com/en-us/media/logos/logo_python.svg)
[Python](https://learn.microsoft.com/en-us/azure/developer/python/)
![](https://learn.microsoft.com/en-us/azure/media/index/net-logo.svg)
[.NET](https://learn.microsoft.com/en-us/dotnet/azure/)
![](https://learn.microsoft.com/en-us/media/logos/logo_js.svg)
[JavaScript](https://learn.microsoft.com/en-us/azure/developer/javascript/)
![](https://learn.microsoft.com/en-us/media/logos/logo_java.svg)
[Java](https://learn.microsoft.com/en-us/azure/developer/java/)
![](https://learn.microsoft.com/en-us/media/logos/logo_Go-lightblue.svg)
[Go](https://learn.microsoft.com/en-us/azure/developer/go/)
![](https://learn.microsoft.com/en-us/media/logos/logo_REST.svg)
[REST API](https://learn.microsoft.com/en-us/rest/api/)
![](https://learn.microsoft.com/en-us/media/logos/logo_powershell.svg)
[Azure PowerShell](https://learn.microsoft.com/en-us/powershell/azure/)
![](https://learn.microsoft.com/en-us/media/logos/logo_CLIgeneric.svg)
[Azure CLI](https://learn.microsoft.com/en-us/cli/azure/)
![](https://learn.microsoft.com/en-us/azure/media/index/resource-groups.svg)
[ARM templates](https://learn.microsoft.com/en-us/azure/azure-resource-manager/templates/)
![](https://learn.microsoft.com/en-us/azure/media/index/bicep.svg)
[Bicep](https://learn.microsoft.com/en-us/azure/azure-resource-manager/bicep/)
![](https://learn.microsoft.com/en-us/media/logos/logo_jenkins.svg)
[Jenkins](https://learn.microsoft.com/en-us/azure/developer/jenkins)
![](https://learn.microsoft.com/en-us/media/logos/logo_terraform.svg)
[Terraform](https://learn.microsoft.com/en-us/azure/developer/terraform/)
[](https://learn.microsoft.com/en-us/azure/?product=popular#azure-clouds)
## Azure clouds
###  [Azure Government](https://learn.microsoft.com/en-us/azure/azure-government/)
A dedicated cloud for U.S. government agencies and their partners.
###  [Microsoft Azure operated by 21Vianet](https://learn.microsoft.com/en-us/azure/china/)
A dedicated cloud located in China and operated by 21Vianet.
[](https://learn.microsoft.com/en-us/azure/?product=popular#partner-solutions)
## Partner solutions
###  [Commercial marketplace](https://learn.microsoft.com/en-us/azure/marketplace/)
An online marketplace of applications and services from independent software vendor (ISV) partners.
###  [Azure Native ISV Services](https://learn.microsoft.com/en-us/azure/partner-solutions/)
Integrated partner solutions that you can use in Azure to enhance your cloud infrastructure.
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fazure%2F%3Fproduct%3Dpopular)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
