[ Skip to main content ](https://learn.microsoft.com/en-us/locale/?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Foverview%3Fview%3Dgraph-rest-1.0%26preserve-view%3Dtrue#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/locale/?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Foverview%3Fview%3Dgraph-rest-1.0%26preserve-view%3Dtrue)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/locale/?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Foverview%3Fview%3Dgraph-rest-1.0%26preserve-view%3Dtrue)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/locale/?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Foverview%3Fview%3Dgraph-rest-1.0%26preserve-view%3Dtrue)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/locale/?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fapi%2Foverview%3Fview%3Dgraph-rest-1.0%26preserve-view%3Dtrue)
# Select a language
Current Selection: **English (United States)**
Filter the list of languages by typing the language name or locale code. Find a language
  * [Bahasa Indonesia](https://learn.microsoft.com/id-id/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Indonesian")
  * [Bahasa Melayu](https://learn.microsoft.com/ms-my/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Malay \(Malaysia\)")
  * [Bosanski](https://learn.microsoft.com/bs-latn-ba/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Bosnian \(Latin\)")
  * [Català](https://learn.microsoft.com/ca-es/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Catalan")
  * [Čeština](https://learn.microsoft.com/cs-cz/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Czech")
  * [Dansk](https://learn.microsoft.com/da-dk/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Danish")
  * [Deutsch (Österreich)](https://learn.microsoft.com/de-at/graph/api/overview?view=graph-rest-1.0&preserve-view=true "German \(Austria\)")
  * [Deutsch (Schweiz)](https://learn.microsoft.com/de-ch/graph/api/overview?view=graph-rest-1.0&preserve-view=true "German \(Switzerland\)")
  * [Deutsch](https://learn.microsoft.com/de-de/graph/api/overview?view=graph-rest-1.0&preserve-view=true "German")
  * [Eesti](https://learn.microsoft.com/et-ee/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Estonian")
  * [English (Australia)](https://learn.microsoft.com/en-au/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(Australia\)")
  * [English (Canada)](https://learn.microsoft.com/en-ca/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(Canada\)")
  * [English (India)](https://learn.microsoft.com/en-in/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(India\)")
  * [English (Ireland)](https://learn.microsoft.com/en-ie/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(Ireland\)")
  * [English (Malaysia)](https://learn.microsoft.com/en-my/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(Malaysia\)")
  * [English (New Zealand)](https://learn.microsoft.com/en-nz/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(New Zealand\)")
  * [English (Singapore)](https://learn.microsoft.com/en-sg/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(Singapore\)")
  * [English (South Africa)](https://learn.microsoft.com/en-za/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(South Africa\)")
  * [English (United Kingdom)](https://learn.microsoft.com/en-gb/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(United Kingdom\)")
  * [English (United States)](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true "English \(United States\)")
  * [Español (México)](https://learn.microsoft.com/es-mx/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Spanish \(Mexico\)")
  * [Español](https://learn.microsoft.com/es-es/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Spanish")
  * [Euskara](https://learn.microsoft.com/eu-es/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Basque")
  * [Filipino](https://learn.microsoft.com/fil-ph/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Filipino")
  * [Français (Belgique)](https://learn.microsoft.com/fr-be/graph/api/overview?view=graph-rest-1.0&preserve-view=true "French \(Belgium\)")
  * [Français (Canada)](https://learn.microsoft.com/fr-ca/graph/api/overview?view=graph-rest-1.0&preserve-view=true "French \(Canada\)")
  * [Français (Suisse)](https://learn.microsoft.com/fr-ch/graph/api/overview?view=graph-rest-1.0&preserve-view=true "French \(Switzerland\)")
  * [Français](https://learn.microsoft.com/fr-fr/graph/api/overview?view=graph-rest-1.0&preserve-view=true "French")
  * [Gaeilge](https://learn.microsoft.com/ga-ie/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Irish")
  * [Galego](https://learn.microsoft.com/gl-es/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Galician")
  * [ქართული](https://learn.microsoft.com/ka-ge/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Georgian")
  * [Hrvatski](https://learn.microsoft.com/hr-hr/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Croatian")
  * [Íslenska](https://learn.microsoft.com/is-is/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Icelandic")
  * [Italiano (Svizzera)](https://learn.microsoft.com/it-ch/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Italian \(Switzerland\)")
  * [Italiano](https://learn.microsoft.com/it-it/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Italian")
  * [Latviešu](https://learn.microsoft.com/lv-lv/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Latvian")
  * [Lëtzebuergesch](https://learn.microsoft.com/lb-lu/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Luxembourgish")
  * [Lietuvių](https://learn.microsoft.com/lt-lt/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Lithuanian")
  * [Magyar](https://learn.microsoft.com/hu-hu/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Hungarian")
  * [Malti](https://learn.microsoft.com/mt-mt/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Maltese")
  * [Nederlands (België)](https://learn.microsoft.com/nl-be/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Dutch \(Belgium\)")
  * [Nederlands](https://learn.microsoft.com/nl-nl/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Dutch")
  * [Norsk Bokmål](https://learn.microsoft.com/nb-no/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Norwegian Bokmål")
  * [Polski](https://learn.microsoft.com/pl-pl/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Polish")
  * [Português (Brasil)](https://learn.microsoft.com/pt-br/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Portuguese \(Brazil\)")
  * [Português (Portugal)](https://learn.microsoft.com/pt-pt/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Portuguese \(Portugal\)")
  * [Română](https://learn.microsoft.com/ro-ro/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Romanian")
  * [Slovenčina](https://learn.microsoft.com/sk-sk/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Slovak")
  * [Slovenski](https://learn.microsoft.com/sl-si/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Slovenian")
  * [Srbija - Srpski](https://learn.microsoft.com/sr-latn-rs/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Serbian \(Latin\)")
  * [Suomi](https://learn.microsoft.com/fi-fi/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Finnish")
  * [Svenska](https://learn.microsoft.com/sv-se/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Swedish")
  * [TiếngViệt](https://learn.microsoft.com/vi-vn/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Vietnamese")
  * [Türkçe](https://learn.microsoft.com/tr-tr/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Turkish")
  * [Ελληνικά](https://learn.microsoft.com/el-gr/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Greek")
  * [Български](https://learn.microsoft.com/bg-bg/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Bulgarian")
  * [қазақ тілі](https://learn.microsoft.com/kk-kz/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Kazakh")
  * [Русский](https://learn.microsoft.com/ru-ru/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Russian")
  * [Српски](https://learn.microsoft.com/sr-cyrl-rs/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Serbian \(Cyrillic\)")
  * [Українська](https://learn.microsoft.com/uk-ua/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Ukrainian")
  * [עברית‏](https://learn.microsoft.com/he-il/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Hebrew")
  * [العربية](https://learn.microsoft.com/ar-sa/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Arabic")
  * [हिंदी](https://learn.microsoft.com/hi-in/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Hindi")
  * [ไทย](https://learn.microsoft.com/th-th/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Thai")
  * [한국어](https://learn.microsoft.com/ko-kr/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Korean")
  * [中文 (简体)](https://learn.microsoft.com/zh-cn/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Chinese \(Simplified\)")
  * [中文 (繁體)](https://learn.microsoft.com/zh-tw/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Chinese \(Traditional\)")
  * [中文 (繁體 香港特別行政區)](https://learn.microsoft.com/zh-hk/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Chinese \(Traditional, Hong Kong SAR\)")
  * [日本語](https://learn.microsoft.com/ja-jp/graph/api/overview?view=graph-rest-1.0&preserve-view=true "Japanese")


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Flocale%2F%3Ftarget%3Dhttps%253A%252F%252Flearn.microsoft.com%252Fen-us%252Fgraph%252Fapi%252Foverview%253Fview%253Dgraph-rest-1.0%2526preserve-view%253Dtrue)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
