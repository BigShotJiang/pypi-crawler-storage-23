[ Skip to main content ](https://learn.microsoft.com/en-us/training/organizations#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/organizations)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/organizations)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/organizations)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/organizations)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
# Microsoft Learn for Organizations
Drive more success by boosting your team’s technical skills with curated offerings from Microsoft Learn for Organizations. Jump-start team training and close skills gaps with the tailored learning and Microsoft-verified credentials workforce needs to keep pace with fast-evolving technology and new roles and responsibilities.
## Discover top picks
Get started training your team with the latest resources from Microsoft Learn for Organizations.
  * ![](https://learn.microsoft.com/en-us/training/images/aisn-icon.png)
[Build skills faster with AI Skills Navigator](https://AISkillsNavigator.microsoft.com?UTM_Source=LFO&UTM_Medium=LFO&UTM_Campaign=Webpage&UTM_Content=WWL)
AI Skills Navigator makes learning more accessible and personalized, helping people build future-ready skills and organizations move faster.
  * ![](https://learn.microsoft.com/en-us/training/images/copilot-kit-icon.png)
[Train your team on Copilot: Download the kit](https://aka.ms/CopilotTrainingKit?wt.mc_id=lfo_content_webpage_wwl)
Get started with use cases, prompting techniques, and tips to help your team boost productivity and streamline workflows with Copilot.
  * ![](https://learn.microsoft.com/en-us/training/images/security-kit-icon.png)
[Build security skills: Download the kit](https://aka.ms/SecuritySkillingKit?wt.mc_id=lfo_content_webpage_wwl)
Curated resources, learning paths, and engagement ideas to strengthen your teams’ security skills.
  * ![](https://learn.microsoft.com/en-us/training/images/tsp-icon.png)
[Connect with a Microsoft Training Services Partner ](https://learn.microsoft.com/en-us/training/training-services-partners)
Learn how a trusted Microsoft partner can help your workforce quickly build AI skills for business and technical teams.


![AI skilling for bus leaders image.](https://learn.microsoft.com/en-us/training/images/ai-skilling-for-bus-leaders.png)
## AI skilling for business leaders
This guide brings together curated learning resources and thought leadership to help senior decision makers understand AI’s impact, identify opportunities, make informed decisions, and stay ahead of emerging trends across the organization.
[Explore the guide](https://aka.ms/BDMTrainingKit?wt.mc_id=lfo_content_webpage_wwl)
## Why skilling?
Investing in skills today builds resilience for tomorrow
The business landscape is changing rapidly, and staying competitive means prioritizing upskilling and reskilling. Skilling drives innovation and helps your organization build a resilient, future-ready workforce. That’s why we created the Organizational Skilling Playbook—a step-by-step guide to help you identify and address skill gaps, create effective skilling plans, foster collaboration, and track progress to ensure you’re celebrating success along the way.
[Get started with the skilling playbook](https://aka.ms/LFO_Playbook?wt.mc_id=lfo_content_webpage_wwl)
![](https://learn.microsoft.com/en-us/training/images/lfo-playbook-1.png)
## Get your team started with training and certification
Support your team’s growth with targeted skills development, certifications, and expert-led training.
  * ![](https://learn.microsoft.com/en-us/training/images/microsoft-applied-skills-round.png)
Microsoft Applied Skills
Get your employees project-ready with Applied Skills. These Microsoft-verified credentials validate specific skill sets for real-world technical scenarios. Earned through interactive, lab-based assessments on Microsoft Learn, employees can complete these credentials at their own pace, aligning with project timelines.
[Browse Applied Skills >](https://aka.ms/LFO_AppliedSkills?wt.mc_id=lfo_content_webpage_wwl)
  * ![](https://learn.microsoft.com/en-us/training/images/microsoft-certifications-round.png)
Microsoft Certifications
Build organizational productivity by keeping your employees current on the latest technology. Microsoft’s industry-recognized certifications are the most trusted way to upskill your workforce. Plus, your commitment to employee growth shows how you value employees, encouraging retention.
[Browse Certifications >](https://learn.microsoft.com/en-us/credentials/?wt.mc_id=lfo_content_webpage_wwl)
  * ![](https://learn.microsoft.com/en-us/training/images/training-services-partners-round.png)
Training Services Partners
Microsoft Training Services Partners (TSPs) offer a breadth of Microsoft Cloud and AI skilling solutions tailored to your organization’s specific needs and learning styles. TSPs provide high levels of instructional and technical expertise offering targeted skilling to deep technical courses and credentialing.
[Find a Training Services Partner >](https://aka.ms/LFO_TSP?wt.mc_id=lfo_content_webpage_wwl)


## Insights and strategies for building a learning culture
  * ![5 Key Considerations for Empowering Your Teams with Skill-Building](https://learn.microsoft.com/en-us/training/images/article-ebook-icon.png)
5 Key Considerations for Empowering Your Teams with Skill-Building
eBook
"Find practical tips to help leaders overcome skill-building challenges, foster a skills-first culture, and align growth with business goals."
[Read the eBook](https://aka.ms/5KeyConsiderations)
  * ![10 Best Practices to Accelerate Your Employees’ AI Skills](https://learn.microsoft.com/en-us/training/images/article-ebook-icon.png)
10 Best Practices to Accelerate Your Employees’ AI Skills
eBook
"In this ebook, you’ll find real-world examples and guidance from Microsoft to help you build successful AI learning initiatives for your organization."
[Get the ebook](https://aka.ms/AISkillsAtMicrosoft_lfo?wt.mc_id=lfo_content_webpage_wwl)
  * ![Accelerate AI transformation with skill building](https://learn.microsoft.com/en-us/training/images/whitepaper-icon.png)
Accelerate AI transformation with skill building
Thought leadership
"Learn why organizations should invest in AI skill building and how Microsoft Learn can help accelerate the journey."
[Read the paper](https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RW1jMq4)
  * ![Skilling for secure AI: How Frontier Firms lead the way](https://learn.microsoft.com/en-us/training/images/whitepaper-icon.png)
Skilling for secure AI: How Frontier Firms lead the way
Thought leadership
"AI is transforming innovation and risk management, requiring organizations to embed continuous security skill-building across all roles to defend against evolving AI-driven threats."
[Download the paper](https://aka.ms/SecuritySkillsForAI_LFO)


![](https://learn.microsoft.com/en-us/training/images/section-testimonials_light-8661c.jpg) ![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_dark.jpg)
## Explore how organizations achieve a culture of learning
Learn more about how organizations around the world are using Microsoft Learn to skill up their teams.
  * ![](https://learn.microsoft.com/en-us/training/images/epam.png)
[EPAM](https://www.microsoft.com/customers/story/25354-epam-systems-fejleszto-kft-microsoft-fabric)
EPAM fast-tracks AI readiness and project outcomes with Microsoft Applied Skills to accelerate delivery and drive innovation.
  * ![](https://learn.microsoft.com/en-us/training/images/the-adecco-group.png)
[The Adecco Group](https://aka.ms/TheAdeccoGroup_Story?wt.mc_id=lfo_content_webpage_wwl)
AI and the human advantage: Adecco Group’s AI skilling strategy fuels productivity with Microsoft Copilot.
  * ![](https://learn.microsoft.com/en-us/training/images/bupa-apac.png)
[Bupa APAC](https://aka.ms/AISKillsBupa_Story-LFO)
Bupa APAC is driving smarter healthcare solutions with an AI-ready workforce and Microsoft Copilot.
  * ![](https://learn.microsoft.com/en-us/training/images/commonwealth-bank.png)
[Commonwealth Bank of Australia](https://aka.ms/AISKillsCommBank_Story-LFO)
Commonwealth Bank of Australia invests in AI skills and Microsoft Copilot to drive innovation.


## What organizations are saying
  * ![Caroline Basyn](https://learn.microsoft.com/en-us/training/images/quote-mark.png)
Caroline Basyn
Chief Digital and Information Officer, The Adecco Group
"AI is reshaping industries, and we’re helping our employees and clients stay ahead. Every customer we meet asks how we’re using AI internally and how we can help them do the same. Equipping our teams with AI skills ensures we can have those conversations with confidence."
[Read Caroline’s story](https://aka.ms/TheAdeccoGroup_Story?wt.mc_id=lfo_content_webpage_wwl)
  * ![Ed Falconer](https://learn.microsoft.com/en-us/training/images/quote-mark.png)
Ed Falconer
Chief Data Officer, Bupa APAC
"Our vision is to use AI to support our customers in the pursuit of our purpose, which is helping them live longer, healthier, and happier lives. It’s about how we use the data that we have on our customers to fulfill that promise."
[Read Ed’s story](https://aka.ms/AISKillsBupa_Story-LFO)
  * ![Jane Adams](https://learn.microsoft.com/en-us/training/images/quote-mark.png)
Jane Adams
Domain Lead HR Business Partnering Learning and Skilling, CommBank
"Skilling is really important for us because people are at the heart of our organization. We need to enable our people to engage with AI, use new tools, and embrace new ways of working."
[Read Jane’s story](https://aka.ms/AISKillsCommBank_Story-LFO)


![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_light.jpg?branch=main) ![](https://learn.microsoft.com/en-us/media/home-and-directory/section-testimonials_dark.jpg?branch=main)
## Additional learning resources for your team
Explore a variety of tailored training hubs, events, and resources designed to help your team build in-demand skills, from AI and cybersecurity to Microsoft Copilot and beyond.
  * ![](https://learn.microsoft.com/en-us/training/images/copilot-icon.png)
[Copilot learning hub](https://learn.microsoft.com/en-us/copilot/?wt.mc_id=lfo_content_webpage_wwl)
Find curated resources on Microsoft Copilot for technical professionals.
  * ![](https://learn.microsoft.com/en-us/training/images/ai-learning-hub-icon.png)
[AI learning hub](https://learn.microsoft.com/en-us/ai/?wt.mc_id=lfo_content_webpage_wwl&tabs=developer)
Start your AI learning journey, and build practical AI skills to use right away.
  * ![](https://learn.microsoft.com/en-us/training/images/security-hub-icon.png)
[Security hub](https://learn.microsoft.com/en-us/security/?wt.mc_id=lfo_content_webpage_wwl)
Find resources and training offerings for building foundational and advanced cybersecurity skills.
  * ![](https://learn.microsoft.com/en-us/training/images/microsoft-virtual-training-days-icon.png)
[Microsoft Virtual Training Days](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl)
Free training events designed to build your skills and prepare you for certifications.
  * ![](https://learn.microsoft.com/en-us/training/images/business-user-training-icon.png)
[Business leaders: From strategy to success](https://setup.cloud.microsoft/?Q=learn?wt.mc_id=lfo_content_webpage_wwl)
Access expert resources, insights, and guidance to help drive successful implementation.
  * ![](https://learn.microsoft.com/en-us/training/images/more-copilot-training-icon.png)
[More Copilot training](https://learn.microsoft.com/en-us/training/browse/?terms=copilot&wt.mc_id=lfo_content_webpage_wwl)
Browse all courses, learning paths, and modules related to Microsoft Copilot.
  * ![](https://learn.microsoft.com/en-us/training/images/tech-community-icon-2.png)
[Tech community for small and medium businesses](https://techcommunity.microsoft.com/category/SMB?wt.mc_id=lfo_content_webpage_wwl)
Get the latest news and best practices on Microsoft’s offerings for SMB customers.
  * ![](https://learn.microsoft.com/en-us/training/images/microsoft-ai-tour-icon.png)
[Microsoft AI Tour](https://aitour.microsoft.com/home?wt.mc_id=lfo_content_webpage_wwl)
Join experts, industry leaders, and technical practitioners to explore the ways AI can drive growth and create lasting value at this free, one-day event.


## Microsoft skilling
Enable a more competitive and productive workforce across your enterprise organization by boosting technical skills through the Learner Experience Portal (LxP). Access to the LxP is exclusively available to invited members enrolled in the premium program.
[Sign in for current members >](https://aka.ms/ESILogIn?wt.mc_id=lfo_content_webpage_wwl)
![](https://learn.microsoft.com/en-us/training/images/organizations-enterprise-skills-initiative.png)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Ftraining%2Forganizations)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
