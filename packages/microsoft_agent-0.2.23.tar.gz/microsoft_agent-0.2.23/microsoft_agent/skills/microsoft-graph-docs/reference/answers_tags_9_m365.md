[ Skip to main content ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office)
[ Q&A  ](https://learn.microsoft.com/en-us/answers/)
  * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
  * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
  * [ Help ](https://learn.microsoft.com/en-us/answers/support/)
  * More
    * [ Questions ](https://learn.microsoft.com/en-us/answers/questions/)
    * [ Tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ Help ](https://learn.microsoft.com/en-us/answers/support/)


[ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/?id=aHR0cHM6Ly9taWNyb3NvZnQtZGV2cmVsLnBvb2xwYXJ0eS5iaXovUW5BTW9kZWwvYTljOGEwYmItMWJhZi00MjFiLWJhMGItZDJiMTgxMzUyODVj&styleGuideLabel=Microsoft%20365%20and%20Office)
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
Microsoft Q&A
#  Microsoft 365 and Office
460,866 questions
A comprehensive suite of productivity tools and cloud services that enhance collaboration, communication, and efficiency. Combining classic Office apps with advanced Microsoft 365 features, it supports both personal and business needs
Sign in to follow  Follow
Filters
## Filter
* * *
### Content
[ All questions 460.9K  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=null) [ No answers 12.3K  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=unanswered) [ Has answers 448.5K  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=answered) [ No answers or comments 8.9K  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=withoutengagement) [ With accepted answer 144K  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=withacceptedanswer) [ With recommended answer 310  ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?filterby=withrecommendedanswer)
##  460,866 questions with Microsoft 365 and Office-related tags
Sort by:  Updated
[Updated](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?orderby=updatedat&page=1) [Created](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?orderby=createdat&page=1) [Answers](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?orderby=answercount&page=1)
1 answer
##  [ Not get 1 year of LinkedIn Premium benefit after purchasing Microsoft 365 Premium ](https://learn.microsoft.com/en-us/answers/questions/5790357/not-get-1-year-of-linkedin-premium-benefit-after-p)
Hi team, I hope you are doing well. I redeemed the "1 year Microsoft 365 Premium + LinkedIn Premium" benefit through link:…
Microsoft 365 and Office | Install, redeem, activate | For home | MacOS
[ Microsoft 365 and Office | Install, redeem, activate | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1528/m365-office-install-redeem-activate-home-macos/)
Processes in Microsoft 365 for setting up Office apps, redeeming product keys, and activating licenses.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,952 questions
Sign in to follow  Follow
asked Feb 26, 2026, 2:07 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(246.4,%2077%,%2033%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAM%3C/text%3E%3C/svg%3E)
[Alexa Miao](https://learn.microsoft.com/en-us/users/na/?userid=c7c77a77-a133-43a0-9c2a-847793634cc5) 0 Reputation points
edited an answer Feb 27, 2026, 1:16 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ Not open Windows Micro Soft Office ](https://learn.microsoft.com/en-us/answers/questions/5790789/not-open-windows-micro-soft-office)
Not open Windows Micro Soft Office excel so need some help
Microsoft 365 and Office | Excel | For business | Windows
[ Microsoft 365 and Office | Excel | For business | Windows ](https://learn.microsoft.com/en-us/answers/tags/379/m365-office-office-excel-business-platform-windows/)
A family of Microsoft spreadsheet software with tools for analyzing, charting, and communicating data
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
20,220 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(89.60000000000001,%2043%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESP%3C/text%3E%3C/svg%3E)
[sakthi p](https://learn.microsoft.com/en-us/users/na/?userid=28437a62-1a31-4177-81ea-8e2860505332) 0 Reputation points
asked Feb 27, 2026, 1:13 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(89.60000000000001,%2043%,%2018%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESP%3C/text%3E%3C/svg%3E)
[sakthi p](https://learn.microsoft.com/en-us/users/na/?userid=28437a62-1a31-4177-81ea-8e2860505332) 0 Reputation points
1 answer
##  [ Microsoft 365 Subscription is creating thousands of files on my Apple computer everyday ](https://learn.microsoft.com/en-us/answers/questions/5790268/microsoft-365-subscription-is-creating-thousands-o)
I bought a brand new $2K Apple computer in the spring. I then opened a Microsoft 365 computer and now my computer is a complete mess. Every time I use my computer, Microsoft 365 is creating thousands and thousands of files which are unnecessary and…
Microsoft 365 and Office | Subscription, account, billing | For home | MacOS
[ Microsoft 365 and Office | Subscription, account, billing | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1462/m365-office-subscription-account-billing-home-macos/)
Microsoft 365 features that help users manage their subscriptions, account settings, and billing information.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,673 questions
Sign in to follow  Follow
asked Feb 26, 2026, 12:48 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(179.20000000000002,%2070%,%2027%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKD%3C/text%3E%3C/svg%3E)
[Kelly Donnelly](https://learn.microsoft.com/en-us/users/na/?userid=56aa70a9-6ae4-4cab-bb5b-204d4c3a3224) 0 Reputation points
answered Feb 27, 2026, 1:06 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Cannot access Grammarly Add in? ](https://learn.microsoft.com/en-us/answers/questions/5790589/cannot-access-grammarly-add-in)
I have been using the Grammarly add-in for Mac for years. Suddenly, it will not load. I get this error message every time I try to add it: Request Id: [Moderation note: Personal information removed] Correlation Id: [Moderation note: Personal information…
Microsoft 365 and Office | Word | For home | MacOS
[ Microsoft 365 and Office | Word | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1484/m365-office-office-word-home-macos/)
A family of Microsoft word processing software products for creating web, email, and print documents.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
4,172 questions
Sign in to follow  Follow
asked Feb 26, 2026, 7:18 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(204.8,%2047%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3E0%3C/text%3E%3C/svg%3E)
[0zfrank](https://learn.microsoft.com/en-us/users/na/?userid=dddb6efd-fd4a-4732-a905-10504b5e7dc6) 0 Reputation points
answered Feb 27, 2026, 1:06 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(230.39999999999998,%2049%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EIT%3C/text%3E%3C/svg%3E)
[Ian-T](https://learn.microsoft.com/en-us/users/na/?userid=7249daf2-daa1-403f-b371-74e08ef8246e) 7,375 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ WANT TO USE MORRORING ](https://learn.microsoft.com/en-us/answers/questions/5790783/want-to-use-morroring)
Can't find out how to use mirroring or where the selection is located.
Microsoft 365 and Office | Other
[ Microsoft 365 and Office | Other ](https://learn.microsoft.com/en-us/answers/tags/1241/m365-office-other-l1/)
Miscellaneous topics that do not fit into specific categories.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
7,126 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:05 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(275.2,%2018%,%2036%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGN%3C/text%3E%3C/svg%3E)
[Greg N](https://learn.microsoft.com/en-us/users/na/?userid=8ea618ea-9108-48c8-80b8-4bc34c7341f1) 0 Reputation points
answered Feb 27, 2026, 1:06 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
1 answer
##  [ wait a moment stuck microsoft account ](https://learn.microsoft.com/en-us/answers/questions/5790782/wait-a-moment-stuck-microsoft-account)
Please help! I reset my computer yesterday, and when I try to log into my Microsoft account, it keeps saying "wait a moment" and won't load. I managed to log in somehow, but when I shut down the computer, it asked me to sign in again, and the…
Microsoft 365 and Office | Access | Other | Windows
[ Microsoft 365 and Office | Access | Other | Windows ](https://learn.microsoft.com/en-us/answers/tags/1529/m365-office-office-access-unknown-routing-platform-windows/)
A family of Microsoft relational database management systems designed for ease of use.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
442 questions
Sign in to follow  Follow
asked Feb 27, 2026, 1:03 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(137.6,%206%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EA%3C/text%3E%3C/svg%3E)
[Adam](https://learn.microsoft.com/en-us/users/na/?userid=43062d07-b4b8-4269-bf37-67c7f7ff6da3) 0 Reputation points
answered Feb 27, 2026, 1:03 AM
![](https://learn.microsoft.com/en-us/media/profile/user-copilot.png)
Q&A Assist
1 answer
##  [ MS Office apps on a tablet. ](https://learn.microsoft.com/en-us/answers/questions/5790727/ms-office-apps-on-a-tablet)
Hi. My uni says they have the Microsoft Office 365 Education Pack. With this particular subscription, can I use MS Office apps on an 11.5 inch Android tablet? I read the article…
Microsoft 365 and Office | OneNote | For education | Android
[ Microsoft 365 and Office | OneNote | For education | Android ](https://learn.microsoft.com/en-us/answers/tags/1319/m365-office-office-onenote-education-android/)
A family of Microsoft products that enable users to capture, organize, and reuse notes electronically.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
138 questions
Sign in to follow  Follow
asked Feb 26, 2026, 11:27 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(156.8,%205%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ES7%3C/text%3E%3C/svg%3E)
[Sarah-7050](https://learn.microsoft.com/en-us/users/na/?userid=49a05e51-3dd4-465b-9606-303addf3418c) 0 Reputation points
answered Feb 27, 2026, 12:57 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(41.6,%2025%,%2014%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGN%3C/text%3E%3C/svg%3E)
[Gabriel-N](https://learn.microsoft.com/en-us/users/na/?userid=1ae325b5-84fa-4ee4-9617-19b43234cae5) 13,695 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Indesign is crashing when saving the files to Onedrive ](https://learn.microsoft.com/en-us/answers/questions/5789436/indesign-is-crashing-when-saving-the-files-to-oned)
Hi Team, I am experiencing an issue that InDesign is crashing when saving the edited files to OneDrive Desktop. It works when saving it to C drive. I have a doubt its because of some recent updates. Can anyone please let me know which KB update has the…
Microsoft 365 and Office | OneDrive | For home | Other
[ Microsoft 365 and Office | OneDrive | For home | Other ](https://learn.microsoft.com/en-us/answers/tags/1384/m365-office-office-onedrive-home-unknown-platform/)
A Microsoft file hosting and synchronization service.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
839 questions
Sign in to follow  Follow
asked Feb 26, 2026, 1:15 AM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/mNOUG9v0LES0pHQTL_YVGg.png?8DC893)
[Rajesh Bhandari](https://learn.microsoft.com/en-us/users/na/?userid=1b94d398-f4db-442c-b4a4-74132ff6151a) 180 Reputation points
commented Feb 27, 2026, 12:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
0 answers
##  [ "Tenant does not have a SPO license" error on Graph API despite active SharePoint Online licenses ](https://learn.microsoft.com/en-us/answers/questions/5790777/tenant-does-not-have-a-spo-license-error-on-graph)
We are calling the Microsoft Graph API using application-level (client credentials) authentication. All requests to any SharePoint/OneDrive endpoint return: { "code": "BadRequest", "message": "Tenant does not have a…
Microsoft 365 and Office | OneDrive | For business | MacOS
[ Microsoft 365 and Office | OneDrive | For business | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1286/m365-office-office-onedrive-business-macos/)
A Microsoft file hosting and synchronization service.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
930 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(137.6,%2049%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EL%3C/text%3E%3C/svg%3E)
[LegalAtoms](https://learn.microsoft.com/en-us/users/na/?userid=c4d34962-f40d-4cd7-8fad-b3262ed868f2) 0 Reputation points
asked Feb 27, 2026, 12:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(137.6,%2049%,%2023%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EL%3C/text%3E%3C/svg%3E)
[LegalAtoms](https://learn.microsoft.com/en-us/users/na/?userid=c4d34962-f40d-4cd7-8fad-b3262ed868f2) 0 Reputation points
1 answer
##  [ Needing to sort out my Microsoft three account seem some confusion ](https://learn.microsoft.com/en-us/answers/questions/5789326/needing-to-sort-out-my-microsoft-three-account-see)
Today I received a lot of emails from Microsoft about my account, which doesn't make sense. I believe I have paid the 356 premium account up to date, which is due in December 2026. Currently, you're telling me that I am full in some areas, which I don't…
Microsoft 365 and Office | Other
[ Microsoft 365 and Office | Other ](https://learn.microsoft.com/en-us/answers/tags/1241/m365-office-other-l1/)
Miscellaneous topics that do not fit into specific categories.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
7,126 questions
Sign in to follow  Follow
asked Feb 25, 2026, 10:32 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(211.20000000000002,%2076%,%2030%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EMF%3C/text%3E%3C/svg%3E)
[Max Fehring](https://learn.microsoft.com/en-us/users/na/?userid=66fbc761-e553-42c3-bf93-60a2c89c8fc2) 0 Reputation points
commented Feb 27, 2026, 12:52 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ My Onedrive is about to be deleted by Microsoft even though I have paid for year subs via Apple-pay ](https://learn.microsoft.com/en-us/answers/questions/5789062/my-onedrive-is-about-to-be-deleted-by-microsoft-ev)
I paid for an annual subscription for my Onedrive. But, for the second time, I have received an email from Microsoft stating that my Onedrive is about to be deleted/deactivated. I paid via Apple pay about 6 weeks ago for an annual subscription. Now…
Microsoft 365 and Office | OneDrive | For home | Android
[ Microsoft 365 and Office | OneDrive | For home | Android ](https://learn.microsoft.com/en-us/answers/tags/1404/m365-office-office-onedrive-home-android/)
A Microsoft file hosting and synchronization service.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,087 questions
Sign in to follow  Follow
asked Feb 25, 2026, 4:36 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(249.60000000000002,%2069%,%2034%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EKM%3C/text%3E%3C/svg%3E)
[katy monaghan](https://learn.microsoft.com/en-us/users/na/?userid=7cc86982-d0f8-4033-9ac0-46ff7bc1d55e) 0 Reputation points
commented Feb 27, 2026, 12:51 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ Can't sign in to 365 copilot on my Android tablet ](https://learn.microsoft.com/en-us/answers/questions/5789003/cant-sign-in-to-365-copilot-on-my-android-tablet)
I have a family subscription but when I try to sign in on my tablet I get this error message: Correlation Id: [Moderator Note: Personal Info Removed] Timestamp: [Moderator Note: Personal Info Removed] DPTI: [Moderator Note: Personal Info Removed]…
Microsoft 365 and Office | Install, redeem, activate | For home | Android
[ Microsoft 365 and Office | Install, redeem, activate | For home | Android ](https://learn.microsoft.com/en-us/answers/tags/1463/m365-office-install-redeem-activate-home-android/)
Processes in Microsoft 365 for setting up Office apps, redeeming product keys, and activating licenses.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
121 questions
Sign in to follow  Follow
asked Feb 25, 2026, 3:23 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(108.80000000000001,%2060%,%2020%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EL%3C/text%3E%3C/svg%3E)
[Lee](https://learn.microsoft.com/en-us/users/na/?userid=f34f6d01-b8c3-4a61-abf4-74c23c1b1ad3) 0 Reputation points
commented Feb 27, 2026, 12:50 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ My personal acct has the same email address as my business, causing login problems for my business ](https://learn.microsoft.com/en-us/answers/questions/5789381/my-personal-acct-has-the-same-email-address-as-my)
I was told to login to my personal account to and change the email address, but I cancelled that account over 5 years ago, so I cannot login. I got a new computer and am trying to move my business account email to it, but the personal account email is…
Microsoft 365 and Office | Subscription, account, billing | For home | Other
[ Microsoft 365 and Office | Subscription, account, billing | For home | Other ](https://learn.microsoft.com/en-us/answers/tags/1527/m365-office-subscription-account-billing-home-unknown-platform/)
Microsoft 365 features that help users manage their subscriptions, account settings, and billing information.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
2,661 questions
Sign in to follow  Follow
asked Feb 25, 2026, 11:52 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(294.40000000000003,%2060%,%2038%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGW%3C/text%3E%3C/svg%3E)
[GERALD WILSON](https://learn.microsoft.com/en-us/users/na/?userid=92608680-fa67-49e6-87ff-dde1d9946be4) 0 Reputation points
edited an answer Feb 27, 2026, 12:49 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(230.39999999999998,%2049%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EIT%3C/text%3E%3C/svg%3E)
[Ian-T](https://learn.microsoft.com/en-us/users/na/?userid=7249daf2-daa1-403f-b371-74e08ef8246e) 7,375 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How do I reinstall office19 Home & student ](https://learn.microsoft.com/en-us/answers/questions/5789205/how-do-i-reinstall-office19-home-student)
my Office 19 was deleted when I took computer in for debugging. How do I reinstall? Moved from: <Microsoft 365 and Office | Office Online Server>
Microsoft 365 and Office | Install, redeem, activate | For home | Other
[ Microsoft 365 and Office | Install, redeem, activate | For home | Other ](https://learn.microsoft.com/en-us/answers/tags/1186/m365-office-install-redeem-activate-home-unknown-platform/)
Processes in Microsoft 365 for setting up Office apps, redeeming product keys, and activating licenses.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
11,881 questions
Sign in to follow  Follow
asked Feb 25, 2026, 7:51 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(124.80000000000001,%2086%,%2022%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ESA%3C/text%3E%3C/svg%3E)
[Sandra Addison](https://learn.microsoft.com/en-us/users/na/?userid=3c98bd6a-e252-4d18-8070-3eccef698fa9) 0 Reputation points
commented Feb 27, 2026, 12:48 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
1 answer
##  [ How to get back access to my account when Authenticator has me locked out? ](https://learn.microsoft.com/en-us/answers/questions/5790747/how-to-get-back-access-to-my-account-when-authenti)
I am unable to receive a code through Authenticator to log into my business account. It keeps sending me through loops and it is very frustrating. I am locked out of Teams and Forms. Can I submit a request here?
Microsoft 365 and Office | Microsoft Forms | For business
[ Microsoft 365 and Office | Microsoft Forms | For business ](https://learn.microsoft.com/en-us/answers/tags/1222/m365-office-office-forms-business/)
A web-based tool in Microsoft 365 that enables users to quickly create surveys, quizzes, polls, and feedback forms.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
1,585 questions
Sign in to follow  Follow
asked Feb 27, 2026, 12:02 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(57.599999999999994,%2038%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EC%3C/text%3E%3C/svg%3E)
[Crystal](https://learn.microsoft.com/en-us/users/na/?userid=1e8ed3d8-6667-4110-9480-f94147722d2e) 0 Reputation points
commented Feb 27, 2026, 12:43 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(57.599999999999994,%2038%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EC%3C/text%3E%3C/svg%3E)
[Crystal](https://learn.microsoft.com/en-us/users/na/?userid=1e8ed3d8-6667-4110-9480-f94147722d2e) 0 Reputation points
1 answer
##  [ can't log in to use word ](https://learn.microsoft.com/en-us/answers/questions/5786888/cant-log-in-to-use-word)
this message keeps popping up No License was found for [Moderator Note: Personal Info Removed] buy Microsoft 365 for this account. I have already bought Microsoft 365 it is installed on my Mac book pro but I have no access to it, other than "Skip to…
Microsoft 365 and Office | Word | For home | MacOS
[ Microsoft 365 and Office | Word | For home | MacOS ](https://learn.microsoft.com/en-us/answers/tags/1484/m365-office-office-word-home-macos/)
A family of Microsoft word processing software products for creating web, email, and print documents.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
4,172 questions
Sign in to follow  Follow
asked Feb 24, 2026, 12:12 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(54.400000000000006,%2051%,%2015%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EOA%3C/text%3E%3C/svg%3E)
[Omari A](https://learn.microsoft.com/en-us/users/na/?userid=1c751e11-1f1e-4aa2-96f8-257c0c0ade37) 0 Reputation points
commented Feb 27, 2026, 12:40 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(32,%2084%,%2013%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EXD%3C/text%3E%3C/svg%3E)
[Xavier-D](https://learn.microsoft.com/en-us/users/na/?userid=afaf1dd0-8452-4ad2-aa64-1bb3081614f7) 5,215 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Cannot change my primary username on M365 account. ](https://learn.microsoft.com/en-us/answers/questions/5790527/cannot-change-my-primary-username-on-m365-account)
I switched from my former ISP, Bell Canada and opened a M365 account. My primary username is now that old Sympatico address. When I go to "Manage how you sign in to your account" to make my Outlook email the primary, I get an error. It says…
Microsoft 365 and Office | Subscription, account, billing | For home | Other
[ Microsoft 365 and Office | Subscription, account, billing | For home | Other ](https://learn.microsoft.com/en-us/answers/tags/1527/m365-office-subscription-account-billing-home-unknown-platform/)
Microsoft 365 features that help users manage their subscriptions, account settings, and billing information.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
2,661 questions
Sign in to follow  Follow
asked Feb 26, 2026, 5:17 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(297.6,%2025%,%2038%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EGO%3C/text%3E%3C/svg%3E)
[Glenn O'Brien](https://learn.microsoft.com/en-us/users/na/?userid=93253bbb-7492-4fa3-bb28-93b041634302) 0 Reputation points
answered Feb 27, 2026, 12:36 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(230.39999999999998,%2049%,%2032%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EIT%3C/text%3E%3C/svg%3E)
[Ian-T](https://learn.microsoft.com/en-us/users/na/?userid=7249daf2-daa1-403f-b371-74e08ef8246e) 7,375 Reputation points • Microsoft External Staff • Moderator
3 answers
##  [ quicklinks webpart to site's documentlibrary's not working any more since latest release ](https://learn.microsoft.com/en-us/answers/questions/5782424/quicklinks-webpart-to-sites-documentlibrarys-not-w)
hello, i noticed a new interface when modifying my pages. I use the quicklink part a lot for creating buttons to my documentlibraries. But since the update i'm not able to do this. Even if a use the option to copy paste the link in the add link option…
Microsoft 365 and Office | SharePoint | For business | Windows
[ Microsoft 365 and Office | SharePoint | For business | Windows ](https://learn.microsoft.com/en-us/answers/tags/344/m365-office-office-sp-business-platform-windows/)
A group of Microsoft Products and technologies used for sharing and managing content, knowledge, and applications.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
29,716 questions
Sign in to follow  Follow
asked Feb 20, 2026, 9:56 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(262.40000000000003,%2028.000000000000004%,%2035%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EWS%3C/text%3E%3C/svg%3E)
[Wendy Schuppen](https://learn.microsoft.com/en-us/users/na/?userid=e822d8db-33e9-4ab0-a473-2e7c19c0a2a4) 15 Reputation points
commented Feb 27, 2026, 12:30 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(121.6,%2082%,%2021%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EAK%3C/text%3E%3C/svg%3E)
[Amit Kumar Tomar](https://learn.microsoft.com/en-us/users/na/?userid=3882b48c-dd2a-4e16-99ee-86eba1807ec8) 0 Reputation points
2 answers
##  [ How to update payment method ](https://learn.microsoft.com/en-us/answers/questions/5519044/how-to-update-payment-method)
How do I update payment method on my accounts … work and personal
Microsoft 365 and Office | Subscription, account, billing | For business | iOS
[ Microsoft 365 and Office | Subscription, account, billing | For business | iOS ](https://learn.microsoft.com/en-us/answers/tags/1244/m365-office-subscription-account-billing-business-ios/)
Microsoft 365 features that help users manage their subscriptions, account settings, and billing information.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
44 questions
Sign in to follow  Follow
asked Aug 9, 2025, 5:52 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(294.40000000000003,%208%,%2038%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3ECM%3C/text%3E%3C/svg%3E)
[Catherine Minteer](https://learn.microsoft.com/en-us/users/na/?userid=920863b8-2b1e-4f58-98e7-e0a27db292b4) 0 Reputation points
edited an answer Feb 27, 2026, 12:25 AM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(204.8,%201%,%2029%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EJN%3C/text%3E%3C/svg%3E)
[Jade Ng](https://learn.microsoft.com/en-us/users/na/?userid=ebdb64a0-1638-42b8-803b-0276210b81e8) 9,270 Reputation points • Microsoft External Staff • Moderator
2 answers
##  [ Active Microsoft 365 ](https://learn.microsoft.com/en-us/answers/questions/5790579/active-microsoft-365)
Im a student at Willis ISD. I had Microsoft 365 to use word, excel and Ppt. My access was removed somehow. Not sure how to reactivate it. I also have a produce key for microsoft software my dad gave me. Product Key: [Moderation note: Personal…
Microsoft 365 and Office | PowerPoint | For home | Other
[ Microsoft 365 and Office | PowerPoint | For home | Other ](https://learn.microsoft.com/en-us/answers/tags/1199/m365-office-office-powerpoint-home-unknown-platform/)
A family of Microsoft presentation graphics products that offer tools for creating presentations and adding graphic effects like multimedia objects and special effects with text.
![](https://learn.microsoft.com/answers/media/logo-microsoft.svg)
84 questions
Sign in to follow  Follow
asked Feb 26, 2026, 7:04 PM
![](data:image/svg+xml,%20%3Csvg%20xmlns='http://www.w3.org/2000/svg'%20height='64'%20class='font-weight-bold'%20style='font:%20600%2030.11764705882353px%20"SegoeUI",%20Arial'%20width='64'%3E%3Ccircle%20fill='hsl\(160,%203%,%2025%\)'%20cx='32'%20cy='32'%20r='32'%20/%3E%3Ctext%20x='50%25'%20y='55%25'%20dominant-baseline='middle'%20text-anchor='middle'%20fill='%23FFF'%20%3EPN%3C/text%3E%3C/svg%3E)
[Parker Neumann](https://learn.microsoft.com/en-us/users/na/?userid=c5003e4b-261a-4d94-b01f-8f7ef13afd82) 0 Reputation points
answered Feb 27, 2026, 12:25 AM
![](https://learn.microsoft.com/api/profile-avatar-storage/images/e8d00f0b575241fe8433069a7a2c2c78.png)
[DaveM121](https://learn.microsoft.com/en-us/users/na/?userid=873f553c-11b8-4f5c-b034-14c0940062ff) 846.3K Reputation points • Independent Advisor
  * [ ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=0)
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=1)
  * ...
  * [ 1 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=1)
  * [ 2 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=2)
  * [ 3 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=3)
  * [ 4 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=4)
  * ...
  * [ 23044 ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=23044)
  * [ ](https://learn.microsoft.com/en-us/answers/tags/831/m365-office?page=2)


[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fanswers%2Ftags%2F831%2Fm365-office)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Code of Conduct](https://aka.ms/msftqacodeconduct)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
