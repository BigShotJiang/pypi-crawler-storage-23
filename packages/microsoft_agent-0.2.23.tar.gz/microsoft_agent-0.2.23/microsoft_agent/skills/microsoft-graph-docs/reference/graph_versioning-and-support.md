[ Skip to main content ](https://learn.microsoft.com/en-us/graph/versioning-and-support#main) [ Skip to Ask Learn chat experience ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
[ Microsoft Graph  ](https://learn.microsoft.com/en-us/graph/)
  * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
  * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
  * Resources
    * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
    * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
    * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
    * [ Community calls ](https://aka.ms/M365DevCalls)
    * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
    * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
    * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
    * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
    * [ Support ](https://developer.microsoft.com/en-us/graph/support)
    * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
    * Developer program
      * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
      * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
      * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
      * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)
  * More
    * [ Guides ](https://learn.microsoft.com/en-us/graph/overview)
    * [ API Reference ](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0)
    * Resources
      * [ All resources ](https://developer.microsoft.com/en-us/graph/gallery)
      * [ Blog ](https://devblogs.microsoft.com/microsoft365dev/category/microsoft-graph/)
      * [ Changelog ](https://developer.microsoft.com/en-us/graph/changelog)
      * [ Community calls ](https://aka.ms/M365DevCalls)
      * [ Samples & SDKs ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Samples,SDKs)
      * [ Training ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Training)
      * [ Tools ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Tools)
      * [ Videos & podcasts ](https://developer.microsoft.com/en-us/graph/gallery/?filterBy=Podcasts,Videos)
      * [ Support ](https://developer.microsoft.com/en-us/graph/support)
      * [ My apps ](https://go.microsoft.com/fwlink/?linkid=2083908)
      * Developer program
        * [ Join ](https://developer.microsoft.com/en-us/microsoft-365/dev-program)
        * [ Dashboard ](https://developer.microsoft.com/en-us/microsoft-365/profile)
        * [ Developer program docs ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program)
        * [ FAQ ](https://learn.microsoft.com/en-us/office/developer-program/microsoft-365-developer-program-faq)


[ Download SDKs ](https://learn.microsoft.com/graph/sdks/sdks-overview) [ Open Graph Explorer ](https://developer.microsoft.com/en-us/graph/graph-explorer)
Search
Suggestions will filter as you type
  * [Overview of Microsoft Graph](https://learn.microsoft.com/en-us/graph/overview)
  * [Users you can reach](https://learn.microsoft.com/en-us/graph/users-you-can-reach)
  * [National cloud deployments](https://learn.microsoft.com/en-us/graph/deployments)
  * [Versioning and support](https://learn.microsoft.com/en-us/graph/versioning-and-support)
  * [Terms of use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=graph/context)
  *     * [Services and features](https://learn.microsoft.com/en-us/graph/overview-major-services)
    * [What's new](https://learn.microsoft.com/en-us/graph/whats-new-overview)
    * [API changelog](https://developer.microsoft.com/graph/changelog)
  *     * [Try the APIs](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview)
    * [Quick start](https://developer.microsoft.com/graph/quick-start)
    * [Deploy in IaC with templates](https://learn.microsoft.com/en-us/graph/templates?toc=/graph/toc.json)
  *     * [Compliance](https://learn.microsoft.com/en-us/graph/compliance-concept-overview)
    * [Financials (preview)](https://learn.microsoft.com/en-us/graph/dynamics-business-central-concept-overview)
    * [Industry data ETL (preview)](https://learn.microsoft.com/en-us/graph/industrydata-concept-overview)
  *     * [Microsoft Graph activity logs](https://learn.microsoft.com/en-us/graph/microsoft-graph-activity-logs-overview)
    * [Configure Connected Services](https://learn.microsoft.com/en-us/graph/office-365-connected-services)
    * [Best practices](https://learn.microsoft.com/en-us/graph/best-practices-concept)
    * [Known issues](https://developer.microsoft.com/graph/known-issues)
    * [Errors](https://learn.microsoft.com/en-us/graph/errors)
    * [Microsoft Entra service limits](https://learn.microsoft.com/en-us/entra/identity/users/directory-service-limits-restrictions?toc=/graph/toc.json)
  * [API v1.0 reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true)
  * [API beta reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true)


Download PDF
Table of contents  Exit editor mode
  1. [ Learn ](https://learn.microsoft.com/en-us/)
  2. [ Microsoft Graph ](https://learn.microsoft.com/en-us/graph/)


  1. [Learn](https://learn.microsoft.com/en-us/)
  2. [Microsoft Graph](https://learn.microsoft.com/en-us/graph/)


Ask Learn Ask Learn Focus mode
Table of contents [ Read in English ](https://learn.microsoft.com/en-us/graph/versioning-and-support) Add to Collections Add to plan [ Edit ](https://github.com/microsoftgraph/microsoft-graph-docs-contrib/blob/main/concepts/versioning-and-support.md)
* * *
#### Share via
[ Facebook ](https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fversioning-and-support%3FWT.mc_id%3Dfacebook) [ x.com ](https://twitter.com/intent/tweet?original_referer=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fversioning-and-support%3FWT.mc_id%3Dtwitter&tw_p=tweetbutton&url=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fversioning-and-support%3FWT.mc_id%3Dtwitter) [ LinkedIn ](https://www.linkedin.com/feed/?shareActive=true&text=%0A%0D%0Ahttps%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fversioning-and-support%3FWT.mc_id%3Dlinkedin) Email
* * *
Copy Markdown Print
* * *
Note
Access to this page requires authorization. You can try [signing in](https://learn.microsoft.com/en-us/graph/versioning-and-support) or changing directories.
Access to this page requires authorization. You can try changing directories.
# Versioning, support, and breaking change policies for Microsoft Graph
Feedback
Summarize this article for me
##  In this article
  1. [Support policy and deprecation information](https://learn.microsoft.com/en-us/graph/versioning-and-support#support-policy-and-deprecation-information)
  2. [Versions](https://learn.microsoft.com/en-us/graph/versioning-and-support#versions)
  3. [Preview status](https://learn.microsoft.com/en-us/graph/versioning-and-support#preview-status)
  4. [Terms of use](https://learn.microsoft.com/en-us/graph/versioning-and-support#terms-of-use)


This article describes the support and breaking change policies for Microsoft Graph and the versions of the Microsoft Graph API that are currently available.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#support-policy-and-deprecation-information)
## Support policy and deprecation information
Microsoft Graph follows the [Microsoft Lifecycle Policy](https://support.microsoft.com/lifecycle).
As new versions of the Microsoft Graph REST APIs are released, earlier versions will be retired. Microsoft declares a version as deprecated at least 24 months in advance of retiring it. Similarly, for individual APIs that reached general availability (GA), Microsoft declares an API as deprecated at least 24 months in advance of removing it from the GA version.
For Microsoft Graph SDKs, only the latest major version of any given library is supported and updated with new features, bug fixes, and workarounds. The major version that precedes the latest version is supported for 12 months from the release date of the latest major version, for security fixes only. We recommend that you upgrade to the latest version of the SDKs whenever possible.
When we increment the major version of the API (for example, from v1.0 to v2.0), we're announcing that the current version (in this example, v1.0) is immediately deprecated and we'll no longer support it 24 months after the announcement. We make exceptions to this policy for service security or health reliability issues.
When an API is marked as deprecated, we strongly recommend that you migrate to the latest version as soon as possible. In some cases, we'll announce that new applications will have to start using the new APIs a short time after the original APIs are deprecated. In those cases, only active applications that currently use the deprecated APIs can continue to use them.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#api-contract-and-nonbackward-compatible-changes)
### API contract and nonbackward compatible changes
Microsoft Graph has a log of changes across versions. These changes are listed in the [Microsoft Graph changelog](https://developer.microsoft.com/graph/changelog). As new functionality and data are added to Microsoft Graph, we increment the API version number for any nonbackward compatible changes to the API.
The following are examples of nonbackward compatible changes:
  * Changes to the URL or fundamental request/response associated with a resource
  * Removal, rename, or change to the type of a declared property
  * Removal or rename of APIs or API parameters
  * Addition of a required request header


The following are examples of backward compatible changes:
  * Addition of properties that are nullable or have a default value
  * Addition of a member to an enumeration
  * Removal, rename, or change to the type of an open extension
  * Removal, rename, or change to the type of an annotation
  * Introduction of paging to existing collections
  * Changes to error codes
  * Changes to the order of properties
  * Changes to the length or format of opaque strings, such as resource IDs


> **Note:** Over time, we update the list of backward compatible changes. If you generate your own client proxies (like WCF clients), our guidance is that your client applications should be prepared to receive properties and derived types not previously defined by the Microsoft Graph API service. Microsoft Graph API follows the guidance described in the [Model Versioning](https://github.com/Microsoft/api-guidelines/blob/master/Guidelines.md#12-versioning) section in the [Microsoft REST API guidelines](https://github.com/microsoft/api-guidelines/).
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#versions)
## Versions
The following versions of the Microsoft Graph API are currently available.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#beta-version)
### Beta version
In general, APIs debut in the beta version and are accessible in the `https://graph.microsoft.com/beta` endpoint. For beta API documentation, see [Microsoft Graph beta endpoint reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-beta&preserve-view=true). Expect breaking changes and deprecation of APIs in the beta version from time to time. Use of beta APIs in production applications is not supported.
We make no guarantees that a beta feature will be promoted to the current version. When the Microsoft Graph API team believes that a beta feature is ready for general availability, we add that feature to the latest current version. If the promotion of the feature would result in a breaking change to the current version, the version number is incremented, with the new version becoming the current version.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#current-version)
### Current version
The current version of Microsoft Graph is v1.0. These APIs are accessible in the `https://graph.microsoft.com/v1.0` endpoint. The Microsoft Graph API v1.0 version contains features that are generally available and ready for production use. For v1.0 API documentation, see [Microsoft Graph v1.0 endpoint reference](https://learn.microsoft.com/en-us/graph/api/overview?view=graph-rest-1.0&preserve-view=true).
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#preview-status)
## Preview status
An API or feature in Microsoft Graph is labeled as "(preview)" to indicate that its behavior is _unique_ in the beta endpoint.
The behavior of most APIs and features in the v1.0 version is in parity with the beta version. Some APIs are marked as "preview" for one of the following reasons:
  * The APIs are available in beta only
  * The behavior of the APIs is different in beta than v1.0


Like any other API in the beta endpoint, we can introduce breaking changes to APIs that are marked as preview without notice. Don't access APIs from the beta endpoint in production apps.
> **Note:** APIs can be in preview even when the feature or product itself is generally available.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#deprecated-and-unsupported-versions)
### Deprecated and unsupported versions
Currently, no versions of Microsoft Graph are deprecated or unsupported.
[](https://learn.microsoft.com/en-us/graph/versioning-and-support#terms-of-use)
## Terms of use
By using the Microsoft Graph APIs, you agree to the [Microsoft APIs Terms of Use](https://learn.microsoft.com/en-us/legal/microsoft-apis/terms-of-use?context=/graph/context).
Your feedback is important to us. Connect with us on [Microsoft Q&A](https://learn.microsoft.com/en-us/answers/products/m365#microsoft-graph). Tag your questions with [microsoft-graph-*].
* * *
## Feedback
Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
* * *
##  Additional resources
  * [ What's new in Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/whats-new-overview?source=recommendations)
Find out what's new in Microsoft Graph APIs, SDKs, documentation, and other resources.
  * [ Use Graph Explorer to try Microsoft Graph APIs - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/graph-explorer/graph-explorer-overview?source=recommendations)
Try Microsoft Graph APIs on the default sample tenant to explore capabilities, or sign in to your tenant and use it as a prototyping tool to fulfill your app scenarios.
  * [ Microsoft Graph REST API v1.0 endpoint reference - Microsoft Graph v1.0 ](https://learn.microsoft.com/en-us/graph/api/overview?source=recommendations)
Find reference content for Microsoft Graph REST APIs in the v1.0 endpoint, which includes APIs in general availability (GA) status.
  * [ Microsoft Graph national cloud deployments - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/deployments?source=recommendations)
Learn about Microsoft Graph national cloud deployments and the capabilities that are available to developers within each.
  * [ Microsoft Graph overview - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/overview?source=recommendations)
Use Microsoft Graph to derive insights and analytics from Microsoft 365 and Microsoft Entra data, and build unique, intelligent apps.
  * [ Best practices for working with Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/best-practices-concept?source=recommendations)
Apply these best practices to improve your Microsoft Graph application's performance and make your app more reliable for end users.
  * [ Major services and features in Microsoft Graph - Microsoft Graph ](https://learn.microsoft.com/en-us/graph/overview-major-services?source=recommendations)
Learn how Microsoft Graph's network of services and features manage, protect, and extract data to support a wide range of scenarios.


Show 4 more
Module
[ What is Microsoft Graph? - Training ](https://learn.microsoft.com/en-us/training/modules/msgraph-intro-overview/?source=recommendations)
Microsoft Graph provides access to data stored across Microsoft 365 services. Custom applications can use the Microsoft Graph API to connect to data and use it in custom applications to enhance organizational productivity.
[ AI Apps & Agents Dev Days ](https://aka.ms/AIAppsandAgentsLearn)
Feb 27, 1 AM - Feb 27, 1 AM
Experiment with what's next in AI-driven apps and agent design
[ Register now ](https://aka.ms/AIAppsandAgentsLearn)
* * *
  * Last updated on 11/07/2024


##  In this article
  1. [Support policy and deprecation information](https://learn.microsoft.com/en-us/graph/versioning-and-support#support-policy-and-deprecation-information)
  2. [Versions](https://learn.microsoft.com/en-us/graph/versioning-and-support#versions)
  3. [Preview status](https://learn.microsoft.com/en-us/graph/versioning-and-support#preview-status)
  4. [Terms of use](https://learn.microsoft.com/en-us/graph/versioning-and-support#terms-of-use)


Was this page helpful?
Yes No No
Need help with this topic?
Want to try using Ask Learn to clarify or guide you through this topic?
Ask Learn Ask Learn
Suggest a fix?
##
Ask Learn
Preview
Ask Learn is an AI assistant that can answer questions, clarify concepts, and define terms using trusted Microsoft documentation.
Please sign in to use Ask Learn.
[ Sign in ](https://learn.microsoft.com/en-us/graph/versioning-and-support)
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Fgraph%2Fversioning-and-support)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
