[ Skip to main content ](https://learn.microsoft.com/en-us/training/student-hub/#main)
This browser is no longer supported.
Upgrade to Microsoft Edge to take advantage of the latest features, security updates, and technical support.
[ Download Microsoft Edge ](https://go.microsoft.com/fwlink/p/?LinkID=2092881%20) [ More info about Internet Explorer and Microsoft Edge ](https://learn.microsoft.com/en-us/lifecycle/faq/internet-explorer-microsoft-edge)
[ Learn ](https://learn.microsoft.com/en-us/) [ ](https://www.microsoft.com)
Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/student-hub/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/student-hub/)
[ ](https://www.microsoft.com) [ Learn ](https://learn.microsoft.com/en-us/)
  * Documentation
    * [ All product documentation ](https://learn.microsoft.com/en-us/docs/)
    * [ Azure documentation ](https://learn.microsoft.com/en-us/azure/?product=popular)
    * [ Dynamics 365 documentation ](https://learn.microsoft.com/en-us/dynamics365/)
    * [ Microsoft Copilot documentation ](https://learn.microsoft.com/en-us/copilot/)
    * [ Microsoft 365 documentation ](https://learn.microsoft.com/en-us/microsoft-365/)
    * [ Power Platform documentation ](https://learn.microsoft.com/en-us/power-platform/)
    * [ Code samples ](https://learn.microsoft.com/en-us/samples/)
    * [ Troubleshooting documentation ](https://learn.microsoft.com/en-us/troubleshoot/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Training & Labs
    * [ All training ](https://learn.microsoft.com/en-us/training/)
    * [ Azure training ](https://learn.microsoft.com/en-us/training/browse/?products=azure)
    * [ Dynamics 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=dynamics-365)
    * [ Microsoft Copilot training ](https://learn.microsoft.com/en-us/training/browse/?products=ms-copilot)
    * [ Microsoft 365 training ](https://learn.microsoft.com/en-us/training/browse/?products=m365)
    * [ Microsoft Power Platform training ](https://learn.microsoft.com/en-us/training/browse/?products=power-platform)
    * [ Labs ](https://learn.microsoft.com/en-us/labs/)
    * [ Credentials ](https://learn.microsoft.com/en-us/credentials/)
    * [ Career paths ](https://learn.microsoft.com/en-us/training/career-paths/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Q&A
    * [ Ask a question ](https://learn.microsoft.com/en-us/answers/questions/ask/)
    * [ Azure questions ](https://learn.microsoft.com/en-us/answers/tags/133/azure/)
    * [ Windows questions ](https://learn.microsoft.com/en-us/answers/tags/60/windows/)
    * [ Microsoft 365 questions ](https://learn.microsoft.com/en-us/answers/tags/9/m365/)
    * [ Microsoft Outlook questions ](https://learn.microsoft.com/en-us/answers/tags/131/office-outlook/)
    * [ Microsoft Teams questions ](https://learn.microsoft.com/en-us/answers/tags/108/office-teams/)
    * [ Popular tags ](https://learn.microsoft.com/en-us/answers/tags/)
    * [ All questions ](https://learn.microsoft.com/en-us/answers/questions/)
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.
  * Topics
    * [ Artificial intelligence ](https://learn.microsoft.com/en-us/ai/)
Learning hub to build AI skills
    * [ Compliance ](https://learn.microsoft.com/en-us/compliance/)
Compliance resources you need to get started with your business
    * [ DevOps ](https://learn.microsoft.com/en-us/devops/)
DevOps practices, Git version control and Agile methods
    * [ Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations/)
Curated offerings from Microsoft to boost your team’s technical skills
    * [ Platform engineering ](https://learn.microsoft.com/en-us/platform-engineering/)
Tools from Microsoft and others to build personalized developer experiences
    * [ Security ](https://learn.microsoft.com/en-us/security/)
Guidance to help you tackle security challenges
    * [ Assessments ](https://learn.microsoft.com/en-us/assessments/)
Interactive guidance with custom recommendations
    * [ Student hub ](https://learn.microsoft.com/en-us/training/student-hub/)
Self-paced and interactive training for students
    * [ Educator center ](https://learn.microsoft.com/en-us/training/educator-center/)
Resources for educators to bring technical innovation in their classroom
Free to join. Request to attend.
[ Microsoft AI Tour ](https://aitour.microsoft.com/?wt.mc_id=itour26_learnmarketingspot_wwl)
Take your business to the AI frontier.


Suggestions will filter as you type
[ Sign in ](https://learn.microsoft.com/en-us/training/student-hub/)
  * [ Profile ](https://learn.microsoft.com/en-us/users/me/activity/)
  * [ Settings ](https://learn.microsoft.com/en-us/users/me/settings/)


[ Sign out ](https://learn.microsoft.com/en-us/training/student-hub/)
[ Training  ](https://learn.microsoft.com/en-us/training/)
  * Products
    * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
    * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
    * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
    * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
    * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
    * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
    * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
    * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
    * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
    * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
    * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
    * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Career Paths
    * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
    * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
    * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
    * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
    * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
    * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
    * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
    * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
    * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
    * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
    * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
    * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
    * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
    * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
    * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
    * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
  * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
  * Learn for Organizations
    * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
    * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
    * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
    * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
    * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
    * Resources
      * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
  * Educator Center
    * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
    * Professional development
      * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
      * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
      * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
      * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
      * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
      * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
      * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * Product guides
      * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
      * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
      * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
      * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
      * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
      * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
      * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
      * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
      * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
      * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
      * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
    * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
    * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
  * Student Hub
    * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
    * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
  * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)
  * More
    * Products
      * [ Azure ](https://learn.microsoft.com/en-us/training/azure/)
      * [ Microsoft Foundry ](https://learn.microsoft.com/en-us/training/azure/ai-foundry/)
      * [ Dynamics 365 ](https://learn.microsoft.com/en-us/training/dynamics365/)
      * [ Defender ](https://learn.microsoft.com/en-us/training/defender/)
      * [ .NET ](https://learn.microsoft.com/en-us/training/dotnet/)
      * [ GitHub ](https://learn.microsoft.com/en-us/training/github/)
      * [ Microsoft 365 ](https://learn.microsoft.com/en-us/training/m365/)
      * [ Microsoft Entra ](https://learn.microsoft.com/en-us/training/entra/)
      * [ Microsoft Fabric ](https://learn.microsoft.com/en-us/training/fabric/)
      * [ Power Platform ](https://learn.microsoft.com/en-us/training/powerplatform/)
      * [ Purview ](https://learn.microsoft.com/en-us/training/purview/)
      * [ Teams ](https://learn.microsoft.com/en-us/training/teams/)
      * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Career Paths
      * [ Administrator ](https://learn.microsoft.com/en-us/training/career-paths/administrator/)
      * [ AI Engineer ](https://learn.microsoft.com/en-us/training/career-paths/ai-engineer/)
      * [ App Maker ](https://learn.microsoft.com/en-us/training/career-paths/app-maker/)
      * [ Auditor ](https://learn.microsoft.com/en-us/training/career-paths/auditor/)
      * [ Business User ](https://learn.microsoft.com/en-us/training/career-paths/business-user/)
      * [ Data Analyst ](https://learn.microsoft.com/en-us/training/career-paths/data-analyst/)
      * [ Data Engineer ](https://learn.microsoft.com/en-us/training/career-paths/data-engineer/)
      * [ Data Scientist ](https://learn.microsoft.com/en-us/training/career-paths/data-scientist/)
      * [ Developer ](https://learn.microsoft.com/en-us/training/career-paths/developer/)
      * [ DevOps Engineer ](https://learn.microsoft.com/en-us/training/career-paths/devops-engineer/)
      * [ Functional Consultant ](https://learn.microsoft.com/en-us/training/career-paths/functional-consultant/)
      * [ Identity and Access Administrator ](https://learn.microsoft.com/en-us/training/career-paths/identity-and-access-admin/)
      * [ Information Security Administrator ](https://learn.microsoft.com/en-us/training/career-paths/information-protection-admin/)
      * [ Security Operations Analyst ](https://learn.microsoft.com/en-us/training/career-paths/security-operations-analyst/)
      * [ Security Engineer ](https://learn.microsoft.com/en-us/training/career-paths/security-engineer/)
      * [ Solutions Architect ](https://learn.microsoft.com/en-us/training/career-paths/solution-architect/)
    * [ Browse all training ](https://learn.microsoft.com/en-us/training/browse/)
    * Learn for Organizations
      * [ Microsoft Learn for Organizations ](https://learn.microsoft.com/en-us/training/organizations)
      * [ Structured learning (Plans) ](https://learn.microsoft.com/en-us/training/plans-on-microsoft-learn)
      * [ Watch training (Course videos) ](https://learn.microsoft.com/en-us/training/course-videos-on-shows)
      * [ Classroom training (TSP) ](https://learn.microsoft.com/en-us/training/training-services-partners)
      * [ Gamified training (Challenges) ](https://learn.microsoft.com/en-us/training/topics/event-challenges)
      * Resources
        * [ Event training (VTDs) ](https://events.microsoft.com/mvtd?wt.mc_id=lfo_content_webpage_wwl&language=English&deliverylanguage=English&clientTimeZone=1&startTime=08:00&endTime=17:00)
    * Educator Center
      * [ Overview ](https://learn.microsoft.com/en-us/training/educator-center/)
      * Professional development
        * [ Accessibility and inclusivity ](https://learn.microsoft.com/en-us/training/educator-center/topics/accessibility/)
        * [ AI for education ](https://learn.microsoft.com/en-us/training/educator-center/topics/ai-for-education/)
        * [ Cybersecurity ](https://learn.microsoft.com/en-us/training/educator-center/topics/cybersecurity)
        * [ Education leadership and staff collaboration ](https://learn.microsoft.com/en-us/training/educator-center/topics/education-leadership/)
        * [ Learning Accelerators ](https://learn.microsoft.com/en-us/training/educator-center/topics/learning-accelerators/)
        * [ Social emotional learning ](https://learn.microsoft.com/en-us/training/educator-center/topics/social-emotional-learning/)
        * [ STEM, coding, and esports ](https://learn.microsoft.com/en-us/training/educator-center/topics/stem/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * Product guides
        * [ Copilot in education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/copilot/)
        * [ Microsoft 365 for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/office/)
        * [ Microsoft Teams for Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/teams/)
        * [ OneNote for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/onenote/)
        * [ Minecraft Education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/minecraft/)
        * [ Reading Progress ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/reading-progress/)
        * [ Search Progress and Coach ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/search-coach/)
        * [ Immersive Reader ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/immersive-reader/)
        * [ PowerPoint for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/powerpoint/)
        * [ Windows for education ](https://learn.microsoft.com/en-us/training/educator-center/product-guides/windows/)
        * [ Browse all ](https://learn.microsoft.com/en-us/training/browse/?roles=k-12-educator%2Chigher-ed-educator%2Cschool-leader%2Cparent-guardian)
      * [ Instructor materials ](https://learn.microsoft.com/en-us/training/educator-center/instructor-materials/)
      * [ Educator programs ](https://learn.microsoft.com/en-us/training/educator-center/programs/)
    * Student Hub
      * [ Overview ](https://learn.microsoft.com/en-us/training/student-hub/)
      * [ Student certifications ](https://learn.microsoft.com/en-us/training/student-hub/certifications/)
    * [ FAQ & Help ](https://learn.microsoft.com/en-us/training/support/)


1%
Microsoft Learn
# Student Hub
All the tools, training, and community support to assist you build, learn, and succeed
Discover what’s possible with Microsoft AI. Through guided resources, expert-led content, and hands-on support, you’ll learn how to design, refine, and submit your Minumum Viable Product (MVP). Whether you’re optimizing a solution that’s ready to scale or shaping your first prototype, Microsoft gives you the tools and knowledge to move faster and aim higher.
![Student Innovator Series Graphic](https://learn.microsoft.com/en-us/training/media/student-hub/SH-Azure-Activate.png)
## Activate your Azure subscription
Build fast, scale smart, and grow reach with trusted AI, secure cloud tools, and up to $5,000 USD in Azure credits; giving you the foundation to develop with confidence. Unlock your Azure benefits today.
[Start building with Azure today](https://go.microsoft.com/fwlink/?linkid=2312920)
## Supercharge your Red Bull Basement project
Start building your solutions using Microsoft’s AI capabilities
  * ![](https://learn.microsoft.com/en-us/training/media/student-hub/SH-Azure-Quickstarts.png)
[Azure Quickstarts](https://aka.ms/shazuresamplecode)
Get started with Microsoft developer tools and technologies. Explore code samples and discover the things you can build.
  * ![](https://learn.microsoft.com/en-us/training/media/student-hub/Studentcopilot1.png)
[Microsoft Copilot Studio](https://learn.microsoft.com/en-us/microsoft-copilot-studio/)
Build and customize AI copilots fast with Copilot Studio—add chat features and take your Red Bull Basement project further.
  * ![](https://learn.microsoft.com/en-us/training/media/student-hub/MF.png)
[Microsoft Fabric](https://learn.microsoft.com/en-us/fabric/)
Use Microsoft Fabric to organize, analyze, and visualize data—giving your Red Bull Basement project clarity, insight, and a competitive edge.
  * ![](https://learn.microsoft.com/en-us/training/media/student-hub/GH.png)
[GitHub Student Developer Pack](https://education.github.com/pack)
Get free access to tools and resources with the GitHub Student Developer Pack—build, test, and ship software while gaining hands-on experience.


Apply now: [Red Bull Basement 2026](https://go.microsoft.com/fwlink/?linkid=2346494)
## Imagine Cup 2026
Follow the Imagine Cup finalists to the winners stage! All the submissions are in and now each submission will be judged with the winners advancing to the World Finals.
[Follow us on LinkedIn](https://www.linkedin.com/company/microsoft-imagine-cup) [Follow us on Instagram](https://www.instagram.com/microsoftimaginecup/)
![Imagine Cup 2026 Graphic](https://learn.microsoft.com/en-us/training/media/student-hub/SH-IC-2026.png)
## Student Essentials for Microsoft
Advance your journey with curated resources that help you build core skills in AI, data science, Cybersecurity and beyond, equipping you to create with confidence.
  * [AI for Beginners](https://github.com/microsoft/ai-for-beginners)
Learn AI fundamentals in a 12-week program—explore neural networks, deep learning, and hands-on work with TensorFlow and PyTorch.
  * [Data Science for Beginners](https://github.com/microsoft/Data-Science-For-Beginners)
Dive into data science with a 12-week program—explore ethics, prep, analysis, visualization, and real-world use cases.
  * [Machine Learning for Beginners](https://github.com/microsoft/ML-For-Beginners)
Master core machine learning in 12 weeks—focus on classic methods with Scikit-learn, a perfect companion to AI and Data Science for Beginners.
  * [Cybersecurity for Beginners](https://github.com/microsoft/Security-101)
Strengthen your cybersecurity skills with bite-sized lessons—learn key concepts, test your knowledge, and build confidence in the AI era.
  * [AI Agents for Beginners](https://github.com/microsoft/ai-agents-for-beginners)
Explore AI Agents in a 10-lesson course—covering core concepts in a clear, flexible format with multi-language support to help you start fast.
  * [Generative AI for Beginners](https://github.com/microsoft/generative-ai-for-beginners/tree/main?WT.mc_id=academic-105485-koreyst)
Develop Generative AI apps in Microsoft’s 21-lesson course—grasp core concepts and apply them with hands-on coding in Python and TypeScript.
  * [Mastering GitHub Copilot](https://github.com/microsoft/Mastering-GitHub-Copilot-for-Paired-Programming)
Boost your coding with GitHub Copilot—learn to integrate AI assistance, improve collaboration in VS Code, and streamline workflows.
  * [Copilot Adventures](https://github.com/microsoft/copilotadventures)
Level up your coding through GitHub Copilot Adventures—tackle challenges, master new languages, and unlock smarter, faster development.


## Follow us on the web
[ Facebook ](https://www.facebook.com/MSFTImagine "Facebook") [ Twitter ](https://twitter.com/MSFTImagine "Twitter") [ LinkedIn ](https://www.linkedin.com/groups/13893743/ "LinkedIn") [ Instagram ](https://www.instagram.com/microsoftimaginecup/ "Instagram") [ YouTube ](https://www.youtube.com/@MSFTImagine "YouTube")
[English (United States)](https://learn.microsoft.com/en-us/locale?target=https%3A%2F%2Flearn.microsoft.com%2Fen-us%2Ftraining%2Fstudent-hub%2F)
[ Your Privacy Choices](https://aka.ms/yourcaliforniaprivacychoices)
Theme
  * Light
  * Dark
  * High contrast


  * [AI Disclaimer](https://learn.microsoft.com/en-us/principles-for-ai-generated-content)
  * [Previous Versions](https://learn.microsoft.com/en-us/previous-versions/)
  * [Blog](https://techcommunity.microsoft.com/t5/microsoft-learn-blog/bg-p/MicrosoftLearnBlog)
  * [Contribute](https://learn.microsoft.com/en-us/contribute)
  * [Privacy](https://go.microsoft.com/fwlink/?LinkId=521839)
  * [Terms of Use](https://learn.microsoft.com/en-us/legal/termsofuse)
  * [Trademarks](https://www.microsoft.com/legal/intellectualproperty/Trademarks/)
  * © Microsoft 2026
