"""deeper-research placeholder package."""

__all__ = ["placeholder"]
__version__ = "0.0.1"


def placeholder() -> str:
    """Return placeholder message."""
    return "deeper-research placeholder package"
