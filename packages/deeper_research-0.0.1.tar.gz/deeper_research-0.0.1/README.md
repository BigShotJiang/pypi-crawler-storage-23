# deeper-research

This is a placeholder package intended to reserve the `deeper-research` name on PyPI.

It currently provides only minimal functionality.
