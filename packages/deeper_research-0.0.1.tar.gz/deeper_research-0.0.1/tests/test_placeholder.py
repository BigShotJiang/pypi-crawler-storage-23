from deeper_research import placeholder


def test_placeholder():
    assert placeholder() == "deeper-research placeholder package"
