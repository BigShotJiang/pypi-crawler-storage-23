import pytest
from dotenv import load_dotenv
from tortoise.backends.asyncpg import AsyncpgDBClient
from x_model import init_db


# from xync_schema.models import User

from xync_schema import TORM

load_dotenv()


@pytest.fixture
async def dbc() -> AsyncpgDBClient:
    cn: AsyncpgDBClient = await init_db(TORM, True)
    yield cn
    await cn.close()


async def test_init_db(dbc):
    assert isinstance(dbc, AsyncpgDBClient), "DB corrupt"


# async def test_trans(dbc):
#     sndr = await User[0]
#     tx = await sndr.send(2, sndr.id, 50000)
#     assert tx.check(sndr.pub)
#     # await XyncBot(PAY_TOKEN, dbc, "https://local.xync.net").tx_send_tg(tx)
#     assert tx.status == TransactionStatus.verified, "No verified tx"


# async def test_user_keys(dbc):
#     for user in await User.filter(prv__isnull=True, pub__isnull=True).all():
#         user.keygen()
#         await user.save()
#     assert 1, "DB corrupt"


# async def test_models(dbc):
#     c = await Ex.first()
#     assert isinstance(c, Ex), "No exs"
