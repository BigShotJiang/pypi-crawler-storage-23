# django-url-tokenizer
A python package that provides a Django app that allows you to generate tokenized urls and send them to users via email.
