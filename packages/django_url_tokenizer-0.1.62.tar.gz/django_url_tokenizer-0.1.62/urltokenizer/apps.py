from django.apps import AppConfig


class UrltokenizerConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "urltokenizer"
