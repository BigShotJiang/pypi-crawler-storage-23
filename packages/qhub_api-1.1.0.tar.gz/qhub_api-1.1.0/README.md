# Kipu Quantum Hub API SDK

## Installation

The package is published on PyPI and can be installed via `pip`:

```bash
pip install --upgrade qhub-api
```

## License

[Apache-2.0](https://www.apache.org/licenses/LICENSE-2.0) | Copyright 2026-now Kipu Quantum GmbH
