import json
import yaml
from pathlib import Path
from dtsdance.bytecloud import ByteCloudClient
from dtsdance.tcc_open import TCCClient
from dtsdance.tcc_inner import TCCInnerClient
from config import ConfigLoader

loader = ConfigLoader.get_instance()
loader.load_from_file(["boe", "cn", "eu-ttp", "us-ttp"])
# loader.load_from_file(["eu-ttp"])
site_configs = loader.get_site_configs()


# pytest tests/test_tcc.py::test_get_config -s
def test_get_config():
    site_info = site_configs["boe"]
    client_open = TCCClient(site_info.svc_account, site_info.svc_secret, endpoint=site_info.endpoint)
    config_ctrl_env = client_open.get_config(ns_name="bytedts.mgr.api", region="China-BOE", dir="/default", conf_name="ctrl_env")
    print(f"ctrl_env: {config_ctrl_env}")


# pytest tests/test_tcc.py::test_list_all_configs -s
def test_list_all_configs():
    bytecloud_client = ByteCloudClient(site_configs)
    client_inner = TCCInnerClient(bytecloud_client)
    # configs = client_inner.list_all_configs(site="boe", ns_name="bytedts.mgr.api", region="China-BOE", dir="/default", conf_name="route")
    configs = client_inner.list_all_configs(site="cn", ns_name="bytedts.mgr.api", region="China-East", dir="/default", conf_name="")
    # configs = client_inner.list_all_configs(site="us-ttp", ns_name="bytedts.mgr.api", region="US-TTP", dir="/default", conf_name="route")
    # configs = client_inner.list_all_configs(site="eu-ttp", ns_name="bytedts.mgr.api", region="EU-TTP", dir="/default", conf_name="route")
    conf_names = [conf.get("conf_name", "") for conf in configs]
    print(f"count: {len(conf_names)}, conf_names: {json.dumps(conf_names, ensure_ascii=False, indent=2)}")


# pytest tests/test_tcc.py::test_list_regions -s
def test_list_regions():
    bytecloud_client = ByteCloudClient(site_configs)
    client_inner = TCCInnerClient(bytecloud_client)
    regions = client_inner.list_regions(site="cn", ns_name="bytedts.mgr.api")
    print(f"regions: {json.dumps(regions, ensure_ascii=False, indent=2)}")


# pytest tests/test_tcc.py::test_list_dirs -s
def test_list_dirs():
    bytecloud_client = ByteCloudClient(site_configs)
    client_inner = TCCInnerClient(bytecloud_client)
    dirs = client_inner.list_dirs(site="cn", ns_name="bytedts.mgr.api")
    print(f"dirs: {json.dumps(dirs, ensure_ascii=False, indent=2)}")


# pytest tests/test_tcc.py::test_convert_to_yaml -s
def test_convert_to_yaml():
    bytecloud_client = ByteCloudClient(site_configs)
    client_inner = TCCInnerClient(bytecloud_client)
    configs = client_inner.list_all_configs(site="cn", ns_name="bytedts.dsmgr.cn_north", region="China-East", dir="/default", conf_name="")
    config_models = []
    for config in configs:
        conf_name = config.get("conf_name", "")
        online_version_data = config.get("online_version_data", {})
        data_raw = online_version_data.get("base", "")
        data_type = online_version_data.get("data_type", "")
        enable_encryption = online_version_data.get("enable_encryption", False)
        if enable_encryption:
            print(f"配置 {conf_name} 已加密，跳过处理")
            continue

        try:
            data = json.loads(data_raw) if data_type == "json" else data_raw
            config_models.append(
                {
                    "apiVersion": "v1",
                    "kind": "TCC",
                    "metadata": {
                        "name": conf_name,
                        "data_type": data_type,
                    },
                    "data": data,
                }
            )
        except Exception as e:
            print(f"配置 {conf_name} error: {e}")

    # if 1 == 1:
    #     return

    # 转换为 YAML 格式
    yaml_documents = []
    for config in config_models:
        # 转换为 YAML
        yaml_str = yaml.dump(config, allow_unicode=True, default_flow_style=False, sort_keys=False)
        yaml_documents.append(yaml_str)

    # 使用 --- 分隔多个 YAML 文档
    yaml_content = "---\n".join(yaml_documents)

    # 保存到文件
    output_file = Path("output_configs3.yaml")
    output_file.write_text(yaml_content, encoding="utf-8")

    print(f"已保存 {len(yaml_documents)} 个配置到文件: {output_file.absolute()}")
    print(f"文件大小: {output_file.stat().st_size} bytes")
