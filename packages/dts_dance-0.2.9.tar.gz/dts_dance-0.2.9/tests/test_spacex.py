from dtsdance.bytecloud import ByteCloudClient
from dtsdance.spacex import SpaceXClient
from config import ConfigLoader

loader = ConfigLoader.get_instance()
loader.load_from_file(["cn"])
site_configs = loader.get_site_configs()
bytecloud_client = ByteCloudClient(site_configs)
spacex_client = SpaceXClient(bytecloud_client)

# pytest tests/test_spacex.py::test_create_migration_order -s
def test_create_migration_order():
    link = spacex_client.create_migration_order("cn", "mahang", ["1768533581841328833"])
    print(f"link: {link}")
