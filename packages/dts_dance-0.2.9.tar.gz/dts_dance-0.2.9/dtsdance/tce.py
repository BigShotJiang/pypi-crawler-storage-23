from typing import Any
from venv import logger
import requests

from .bytecloud import ByteCloudClient


class TCEError(Exception):
    pass


class TCEErrorServiceExist(Exception):
    pass


class TCEErrorClusterExist(Exception):
    pass


class TCEClient:
    """Client for TCE deployment API."""

    def __init__(self, bytecloud_client: ByteCloudClient) -> None:
        """
        Initialize TCE client.

        Args:
            base_url: TCE API base URL
            jwt_token: JWT token for authentication (can be fetched automatically)
        """
        self.bytecloud_client = bytecloud_client

    def create_service(self, site: str, ctrl_name: str, bytetree_parent_id: int) -> int | None:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/deployment/service/create/"

        service_info = {
            "meta": {"name": f"bytedts.cm.{ctrl_name}", "psm": f"bytedts.cm.{ctrl_name}", "env": "prod"},
            "auth": {
                "galaxy_info": {"parent_id": bytetree_parent_id},
                "approval_controls": ["reset"],
                "iam_info": {"owners": [{"username": site_info.svc_account}, {"username": "mahang"}]},
                "owner_name": site_info.svc_account,
            },
            "extra_features": {
                "service_token": {
                    "tech_stack": {"language": "go", "framework": "custom", "platform_types_v_2": {"tce": ["http"]}},
                    "deploy": {"type": "stateless_compute", "scale": {"enable": True}, "descale": {"enable": True}},
                    "level": "P2",
                    "purpose": "convention",
                    "contain_user_personal_info": False,
                    "data_sensitivity_level": "L2",
                }
            },
            "build": {
                "dependency_mode": "default",
                "base_image": "debian.bookworm.tce_service:latest",
                "install_package_info": [],
                "scm_repo_info": [
                    {"name": "bytedts/dflow/dtscm", "remote_id": 387073, "main_repo": True, "path": "dts-cm"},
                    {"name": "toutiao/load", "remote_id": 667, "path": "toutiao/load"},
                    {"name": "toutiao/runtime", "remote_id": 631, "path": "toutiao/runtime"},
                ],
                "language": "go",
                "framework_support": "none",
                "tech_stack": "custom",
            },
            "runtime": {
                "umount_ss_conf": False,
                "new_ports": [
                    {"intent": "primary", "port": 8088, "is_primary": True, "type": "tcp"},
                    {"intent": "other", "port": 3033, "is_primary": False, "type": "tcp"},
                ],
                "is_runtime": False,
                "app_path": "dts-cm/bootstrap.sh",
                "enable_iast": False,
            },
        }

        payload = {"service_info": service_info}

        try:
            headers = self.bytecloud_client.build_request_headers(site)
            response = requests.post(url, json=payload, headers=headers, timeout=60)
            logger.debug(f"create_service response.text: {response.text}")

            if response.status_code != 200:
                if "already exists" in response.text:
                    raise TCEErrorServiceExist("TCE cluster with the same name already exists")

                raise TCEError(f"TCE API request failed with status {response.status_code}\n" f"Response: {response.text}")

            result = response.json()
            if result.get("code", 0) == -1:
                raise TCEError(f"TCE API error: {result.get('error')}")

            return result.get("data", {}).get("service", 0)

        except requests.RequestException as e:
            raise TCEError(f"Failed to create TCE cluster: {str(e)}") from e

    def create_cluster(self, site: str, cluster_info: dict[str, Any], service: int) -> int | None:
        """
        Create TCE cluster.

        Args:
            cluster_info: Cluster configuration (meta, resource, runtime)
            service: Service ID

        Returns:
            The created cluster ID, or None if creation failed

        Raises:
            TCEError: If API call fails
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/deployment/cluster/create/"
        payload = {"cluster_info": cluster_info, "service": service}

        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site), timeout=60)
            if response.status_code != 200:
                if "a same named TCE cluster already exists" in response.text:
                    raise TCEErrorClusterExist("TCE cluster with the same name already exists")

                raise TCEError(f"TCE API request failed with status {response.status_code}\n" f"Response: {response.text}")

            result = response.json()

            # Check for errors in response
            if not isinstance(result, dict):
                raise TCEError(f"Unexpected response format: {result}")

            # TCE API may return error information in different formats
            if result.get("code", 0) == -1:
                raise TCEError(f"TCE API error: {result.get('error')}")

            data = result.get("data", {})
            create_success = data.get("deployment_type", "") == "create" and data.get("status", "") == "pending"
            if not create_success:
                raise TCEError(f"TCE cluster creation failed: {result}")

            cluster_id = data.get("cluster_info", {}).get("meta", {}).get("id", 0)
            # Ensure cluster_id is an integer
            return int(cluster_id) if cluster_id else 0

        except requests.RequestException as e:
            raise TCEError(f"Failed to create TCE cluster: {str(e)}") from e

    def delete_cluster(self, site: str, cluster_id: int, service_id: int, cluster_name: str) -> int | None:
        """
        Delete TCE cluster (reset/destroy).

        Args:
            site: Site identifier
            cluster_id: Cluster ID to delete
            service_id: Service ID
            cluster_name: Cluster name

        Returns:
            Response data

        Raises:
            TCEError: If API call fails
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/deployment/cluster/reset/"
        payload = {"cluster": cluster_id, "service": service_id}

        # print(f"Deleting TCE cluster {cluster_id} for service {service_id}")
        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site), timeout=60)
            if response.status_code != 200:
                raise TCEError(f"TCE API request failed with status {response.status_code}\n" f"Response: {response.text}")

            result = response.json()
            if result.get("code", 0) == -1:
                error_msg = result.get("error", "")
                if "do not exist" in error_msg:
                    print(f"cluster {cluster_name} not exist, maybe already deleted")
                    return None

                raise TCEError(f"TCE API error: {error_msg}")

            data = result.get("data", {})
            # 查找 "人工确认" step 的 id
            steps = data.get("steps", [])
            for step in steps:
                if step.get("step_type") == "ConfirmStep":
                    return step.get("id")

            return None

        except requests.RequestException as e:
            raise TCEError(f"Failed to delete TCE cluster: {cluster_name}, msg: {str(e)}") from e

    def get_cluster_info(self, site: str, cluster_id: int) -> dict[str, Any]:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/clusters/{cluster_id}/"

        try:
            response = requests.get(url, headers=self.bytecloud_client.build_request_headers(site), timeout=60)
            if response.status_code != 200:
                raise TCEError(f"TCE API request failed with status {response.status_code}\n" f"Response: {response.text}")

            # print(f"get_cluster_info response.text: {response.text}")
            result = response.json()
            if result.get("code", 0) == -1:
                raise TCEError(f"TCE API error: {result.get('error')}")

            return result.get("data", {})

        except requests.RequestException as e:
            raise TCEError(f"Failed to create TCE cluster: {str(e)}") from e

    def is_cluster_running(self, site: str, cluster_id: int | None) -> bool:
        if cluster_id is None:
            return False

        cluster_info = self.get_cluster_info(site, cluster_id)
        return cluster_info.get("meta", {}).get("status", "unknown") == "running"

    def restart_cluster(self, site: str, service_id: int, cluster_id: int) -> list[int]:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/deployment/cluster/pod_exec/"

        payload = {
            "service": service_id,
            "cluster": cluster_id,
            "exec_command": "rebuild",
            "exec_params": {
                "surge_percent": 25,
                "ready_seconds": 10,
                "timeout": 120,
                "tolerance_num": 3,
                "failed_policy": "remain",
                "need_check": True,
            },
            "exec_type": "rebuild",
            "parallel_mode": True,
        }

        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site), timeout=60)
            if response.status_code != 200:
                raise TCEError(f"TCE API request failed with status {response.status_code}\n" f"Response: {response.text}")

            result = response.json()
            if result.get("code", 0) == -1:
                raise TCEError(f"TCE API error: {result.get('error')}")

            steps = result.get("data", {}).get("steps", [])
            step_ids = [step.get("id", 0) for step in steps]
            return step_ids

        except requests.RequestException as e:
            raise TCEError(f"Failed to create TCE cluster: {str(e)}") from e

    def confirm_step(self, site: str, step_id: int, action: str = "confirm") -> bool:
        """
        Confirm a step in TCE cluster deployment.

        Args:
            step_id: Step ID

        Returns:
            Response data

        Raises:
            TCEError: If API call fails
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v1/tce/open-apis/v1/deployment_steps/{step_id}/actions/"
        payload = {"action": action}

        try:
            response = requests.post(url, json=payload, headers=self.bytecloud_client.build_request_headers(site), timeout=60)
            # print(f"Confirm step response: {response.text}")

            response.raise_for_status()
            result = response.json()

            # Check for errors in response
            if not isinstance(result, dict):
                raise TCEError(f"Unexpected response format: {result}")

            if result.get("code", 0) == -1:
                raise TCEError(f"TCE API error: {result.get('error')}")

            return True

        except requests.RequestException as e:
            raise TCEError(f"Failed to confirm ticket, msg: {str(e)}") from e
