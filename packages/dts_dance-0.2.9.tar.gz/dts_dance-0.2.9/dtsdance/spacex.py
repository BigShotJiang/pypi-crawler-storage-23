from datetime import datetime, timezone, timedelta
from .bytecloud import ByteCloudClient
import requests
from loguru import logger


class SpaceXClient:

    def __init__(self, bytecloud_client: ByteCloudClient):
        """
        SpaceX API 客户端
        """
        self.bytecloud_client = bytecloud_client

    def _build_request_headers(self, site: str, secret_api: bool = False) -> dict[str, str]:
        """
        构建请求头

        Args:
            env: 环境名称
            include_auth: 是否包含 Authorization 头

        Returns:
            dict[str, str]: 请求头字典
        """
        jwt_token = self.bytecloud_client.get_jwt_token(site)
        return {
            "X-Jwt-Token": jwt_token,
            "x-spacex-env": site,
            "x-biz-app": "null",
            "x-spacex-tenant": "bytedts",
        }

    def _compute_change_time_window(self) -> list[str]:
        """
        根据当前时间返回合法的变更时间窗口。
        变更窗口：上午 10:00 ~ 12:00，下午 14:00 ~ 18:00
        返回时间格式为 UTC ISO 8601 格式

        Returns:
            List[str]: 包含开始时间和结束时间的列表 [start_time, end_time]
        """
        # 获取当前UTC时间
        now_utc = datetime.now(timezone.utc)

        # 转换为北京时间 (UTC+8) 来判断时间窗口
        beijing_tz = timezone(timedelta(hours=8))
        now_beijing = now_utc.astimezone(beijing_tz)

        # 获取今天的日期
        today = now_beijing.date()

        # 定义变更窗口 (北京时间)
        morning_start = datetime.combine(today, datetime.min.time().replace(hour=10, minute=0), beijing_tz)
        morning_end = datetime.combine(today, datetime.min.time().replace(hour=12, minute=0), beijing_tz)
        afternoon_start = datetime.combine(today, datetime.min.time().replace(hour=14, minute=0), beijing_tz)
        afternoon_end = datetime.combine(today, datetime.min.time().replace(hour=18, minute=0), beijing_tz)

        # 判断当前时间在哪个窗口
        if morning_start <= now_beijing < morning_end:
            # 当前在上午窗口内
            start_time = now_utc
            end_time = morning_end.astimezone(timezone.utc)
        elif afternoon_start <= now_beijing < afternoon_end:
            # 当前在下午窗口内
            start_time = now_utc
            end_time = afternoon_end.astimezone(timezone.utc)
        elif now_beijing < morning_start:
            # 当前时间早于上午窗口，使用上午窗口
            start_time = morning_start.astimezone(timezone.utc)
            end_time = morning_end.astimezone(timezone.utc)
        elif morning_end <= now_beijing < afternoon_start:
            # 当前时间在上午和下午窗口之间，使用下午窗口
            start_time = afternoon_start.astimezone(timezone.utc)
            end_time = afternoon_end.astimezone(timezone.utc)
        else:
            # 当前时间晚于下午窗口，使用明天的上午窗口
            tomorrow = today + timedelta(days=1)
            tomorrow_morning_start = datetime.combine(tomorrow, datetime.min.time().replace(hour=10, minute=0), beijing_tz)
            tomorrow_morning_end = datetime.combine(tomorrow, datetime.min.time().replace(hour=12, minute=0), beijing_tz)
            start_time = tomorrow_morning_start.astimezone(timezone.utc)
            end_time = tomorrow_morning_end.astimezone(timezone.utc)

        # 转换为ISO 8601格式的字符串
        start_time_str = start_time.isoformat().replace("+00:00", "Z")
        end_time_str = end_time.isoformat().replace("+00:00", "Z")

        logger.info(f"Generated valid change time window, input : {beijing_tz}, output : {start_time_str} to {end_time_str}")
        return [start_time_str, end_time_str]

    def create_migration_order(self, site: str, username: str, task_ids: list[str]) -> str:
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint_spacex}/nocode/action/run"

        # 获取合法的变更时间窗口
        change_plan_time = self._compute_change_time_window()
        body = {
            "actionType": "API",
            "ticketTags": [],
            "elementId": "widget-7c589761-e223-48f9-9792-cd688219480a",
            "entityType": "unknown",
            "entityValue": "unknown",
            "actionId": 99999,
            "actionMeta": {
                "method": "POST",
                "url": "https://spacex-diyops.byted.org/api/v1/ticket/sample",
                "params": {
                    "change_plan_time": change_plan_time,
                    "trigger_type": "manual_trigger",
                    "tags": [],
                    "name": "DSyncer批量迁往DFlow",
                    "args": {"env": site, "username": username, "task_ids": task_ids},
                    "tod_change_control_param": {
                        "strategyScenes": "DEFAULT",
                        "changeLevel": "L3",
                        "isUrgent": False,
                        "changeDesc": "DSyncer 任务迁移至 DFlow",
                        "effectScope": "针对迁移的任务，数据正确性、迁移效率等有影响",
                        "rollbackPlan": "人工确认后，可再流程中执行回滚操作",
                    },
                    "task_unique_name": "dsync_batch_migrate_dflow",
                    "in_frame": False,
                    "context_args": {"standardObjects": {"cmdbSelfLink": ""}},
                    "product": "ByteDTS",
                },
                "__detailFormKv": "{}",
                "customHeaders": {},
                "referer": "",
            },
            "actionName": "submit_change",
            "actionLabel": "submit_change",
            "node": "module@@scenario-operation|app|T:createSampleScene.195bbb19-ffe7-41b3-c142-3a457029a0ad",
            "orderType": "changefree",
            "processorInfo": {},
            "notifyDataJson": None,
            "enableJwt": True,
            "isSyncSpacexTicketCenter": False,
            "spacexTicketType": "change",
            "product": "ByteDTS",
            "changeRiskControlApplyMeta": {"enabled": False},
        }

        try:
            response = requests.post(url, json=body, headers=self._build_request_headers(site))
            logger.debug(f"create_migration_order response: {response.text}")

            # 检查响应状态码
            response.raise_for_status()
            result = response.json()
            if result.get("code") != 0:
                logger.warning(f"create_migration_order failed, site: {site}, task_ids: {task_ids}, error: {result.get('message', 'Unknown error')}")
                return ""

            logger.info(f"create_migration_order success, site: {site}, task_ids: {task_ids}")
            ticket_id = result.get("data", {}).get("id", "")
            return f"https://bytedts.sre.bytedance.net/settings/sops/scenario-operation-and-maintenance/ticket-detail-old?id={ticket_id}"

        except Exception as e:
            logger.error(f"create_migration_order occur error, site: {site}, task_ids: {task_ids}, error: {e}")
            raise
