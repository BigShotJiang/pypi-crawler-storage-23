"""TCC (Toutiao Config Center) API client."""

from typing import Any
import requests

from dtsdance.bytecloud import ByteCloudClient
from dtsdance.tcc_open import TCCError


class TCCInnerClient:
    """Client for TCC OpenAPI."""

    def __init__(self, bytecloud_client: ByteCloudClient) -> None:
        self.bytecloud_client = bytecloud_client

    def list_configs(
        self,
        site: str,
        ns_name: str,
        region: str,
        dir: str,
        conf_name: str,
        pn: int = 1,
        rn: int = 100,
    ) -> dict[str, Any]:
        """
        List TCC configurations with pagination support.

        Returns:
            Full response including data, base_resp, and page_info
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v3/tcc/bcc/config/list_v2"

        payload = {
            "ns_name": ns_name,
            "region": region,
            "dir_path": dir,
            "keyword": conf_name,
            "env": "prod",
            "scope": "all",
            "condition": "name",
            "pn": pn,
            "rn": rn,
        }

        try:
            headers = self.bytecloud_client.build_request_headers(site)

            # from . import ddutil
            # curl_cmd = ddutil.output_curl(url, headers, payload)
            # print(f"Equivalent curl:\n{curl_cmd}")

            response = requests.post(url, headers=headers, json=payload, timeout=30)
            response.raise_for_status()

            result = response.json()

            # Check for errors in response
            base_resp = result.get("base_resp", {})
            if base_resp.get("error_code", 0) != 0:
                raise TCCError(f"TCC API error: {base_resp.get('error_message', 'Unknown error')}")

            return result

        except requests.RequestException as e:
            raise TCCError(f"Failed to get TCC config: {str(e)}") from e

    def list_all_configs(
        self,
        site: str,
        ns_name: str,
        region: str,
        dir: str = "",
        conf_name: str = "",
        page_size: int = 100,
    ) -> list[dict[str, Any]]:
        """
        List all TCC configurations by automatically handling pagination.

        Args:
            site: Site name
            ns_name: Namespace name
            region: Region
            dir: Directory path, defaults to ""
            conf_name: Config name keyword for search, defaults to ""
            page_size: Number of items per page, defaults to 100

        Returns:
            List of all configuration items
        """
        all_configs = []
        pn = 1

        while True:
            result = self.list_configs(
                site=site,
                ns_name=ns_name,
                region=region,
                dir=dir,
                conf_name=conf_name,
                pn=pn,
                rn=page_size,
            )

            data = result.get("data", [])
            all_configs.extend(data)

            page_info = result.get("page_info", {})
            total = page_info.get("total", 0)
            current_count = pn * page_size

            # If we've retrieved all items, break
            if current_count >= total or not data:
                break

            pn += 1

        return all_configs

    def list_regions(
        self,
        site: str,
        ns_name: str,
    ) -> list[str]:
        """
        List All Regions for a given namespace.
        Args:
            site: Site name
            ns_name: Namespace name
        Returns:
            List of region names
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v3/tcc/bcc/namespace/get?name={ns_name}"

        try:
            headers = self.bytecloud_client.build_request_headers(site)
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()

            result = response.json()

            # Check for errors in response
            base_resp = result.get("base_resp", {})
            if base_resp.get("error_code", 0) != 0:
                raise TCCError(f"TCC API error: {base_resp.get('error_message', 'Unknown error')}")

            return result.get("data", {}).get("regions", [])

        except requests.RequestException as e:
            raise TCCError(f"Failed to list TCC regions: {str(e)}") from e

    def list_dirs(
        self,
        site: str,
        ns_name: str,
    ) -> list[str]:
        """
        List All Directories for a given namespace.
        Args:
            site: Site name
            ns_name: Namespace name
        Returns:
            List of directory names
        """
        site_info = self.bytecloud_client.get_site_config(site)
        url = f"{site_info.endpoint}/api/v3/tcc/bcc/dir/list?ns_name={ns_name}"

        try:
            headers = self.bytecloud_client.build_request_headers(site)
            response = requests.get(url, headers=headers, timeout=30)
            response.raise_for_status()

            result = response.json()

            # Check for errors in response
            base_resp = result.get("base_resp", {})
            if base_resp.get("error_code", 0) != 0:
                raise TCCError(f"TCC API error: {base_resp.get('error_message', 'Unknown error')}")

            data_dirs = result.get("data", [])
            return [d.get("path", "") for d in data_dirs]
        except requests.RequestException as e:
            raise TCCError(f"Failed to list TCC directories: {str(e)}") from e
