"""
SimGen PyTorch Backend — Utilities
"""

import ctypes
from pathlib import Path
import warnings

_lib = None
_available = None

def _load_backend():
    """Load the SimGen CUDA backend."""
    global _lib, _available

    if _available is not None:
        return _available

    candidates = [
        Path(__file__).parent.parent / "bin" / "simgen_torch.dll",
        Path(__file__).parent.parent.parent / "build" / "simgen_torch.dll",
        Path(r"C:\SimGen\build\simgen_torch.dll"),
    ]

    for path in candidates:
        if path.exists():
            try:
                _lib = ctypes.CDLL(str(path))
                _configure_functions()
                _available = True
                return True
            except Exception as e:
                warnings.warn(f"Failed to load SimGen backend: {e}")

    _available = False
    return False

def _configure_functions():
    """Configure ctypes function signatures."""
    global _lib

    P_F = ctypes.POINTER(ctypes.c_float)

    # eft_accumulate
    _lib.eft_accumulate.argtypes = [P_F, P_F, P_F, ctypes.c_int]
    _lib.eft_accumulate.restype = ctypes.c_int

    # eft_accumulate_scaled
    _lib.eft_accumulate_scaled.argtypes = [P_F, P_F, P_F, ctypes.c_float, ctypes.c_int]
    _lib.eft_accumulate_scaled.restype = ctypes.c_int

    # eft_sgd_step
    _lib.eft_sgd_step.argtypes = [
        P_F, P_F, P_F,  # weight, comp, grad
        ctypes.c_float, ctypes.c_float,  # lr, weight_decay
        ctypes.c_int  # n
    ]
    _lib.eft_sgd_step.restype = ctypes.c_int

    # eft_adam_step
    _lib.eft_adam_step.argtypes = [
        P_F, P_F, P_F,  # weight, weight_comp, grad
        P_F, P_F,  # exp_avg, exp_avg_sq
        P_F, P_F,  # exp_avg_comp, exp_avg_sq_comp
        ctypes.c_float, ctypes.c_float, ctypes.c_float,  # lr, beta1, beta2
        ctypes.c_float, ctypes.c_float,  # eps, weight_decay
        ctypes.c_int, ctypes.c_int  # step, n
    ]
    _lib.eft_adam_step.restype = ctypes.c_int

    # eft_matmul
    _lib.eft_matmul.argtypes = [P_F, P_F, P_F, ctypes.c_int, ctypes.c_int, ctypes.c_int]
    _lib.eft_matmul.restype = ctypes.c_int

    # eft_reduce_sum
    _lib.eft_reduce_sum.argtypes = [P_F, P_F, P_F, ctypes.c_int]
    _lib.eft_reduce_sum.restype = ctypes.c_int

    # eft_zero_compensation
    _lib.eft_zero_compensation.argtypes = [P_F, ctypes.c_int]
    _lib.eft_zero_compensation.restype = ctypes.c_int

def get_lib():
    """Get the loaded library, loading if necessary."""
    if not _load_backend():
        raise RuntimeError(
            "SimGen PyTorch backend not available. "
            "Ensure CUDA is installed and simgen_torch.dll is built."
        )
    return _lib

def is_available() -> bool:
    """Check if EFT backend is available."""
    return _load_backend()

def get_backend_info() -> dict:
    """Get backend information."""
    if not _load_backend():
        return {"available": False}

    try:
        version = _lib.simgen_torch_version()
        version_str = ctypes.cast(version, ctypes.c_char_p).value.decode()
    except:
        version_str = "Unknown"

    return {
        "available": True,
        "version": version_str,
        "precision": "GPU128 (FP64-class from FP32)"
    }
