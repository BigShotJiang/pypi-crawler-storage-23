"""
SimGen PyTorch Backend — EFT for Stable AI Training
====================================================

Drop-in replacements for PyTorch optimizers with EFT precision.

Solves the #1 problem in AI training: gradient accumulation precision loss.

Usage:
    # Instead of:
    from torch.optim import Adam

    # Use:
    from simgen.torch import Adam

    # Your training code works unchanged, but:
    # - Stable FP16 training without loss scaling
    # - No gradient explosion
    # - Better final accuracy

Example:
    import torch
    from simgen.torch import Adam, SGD

    model = MyModel().cuda()
    optimizer = Adam(model.parameters(), lr=1e-3)  # EFT-powered

    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        optimizer.step()  # Precise gradient accumulation
        optimizer.zero_grad()

Copyright (c) 2026 Clouthier Simulation Labs — simgen.dev
"""

from .optim import SGD, Adam, AdamW
from .functional import eft_matmul, eft_sum, eft_accumulate
from .utils import get_backend_info, is_available

__all__ = [
    'SGD', 'Adam', 'AdamW',
    'eft_matmul', 'eft_sum', 'eft_accumulate',
    'get_backend_info', 'is_available'
]
