"""
SimGen PyTorch Backend — EFT Optimizers
========================================

Drop-in replacements for torch.optim with EFT precision accumulation.

These optimizers track compensation terms for each parameter, ensuring
that gradient accumulation over millions of steps maintains precision.
"""

import torch
from torch.optim import Optimizer
from typing import List, Optional, Callable, Iterable
import ctypes
from .utils import get_lib, is_available

def _ptr(tensor):
    """Get ctypes pointer to tensor data."""
    if tensor is None:
        return None
    return ctypes.cast(tensor.data_ptr(), ctypes.POINTER(ctypes.c_float))


class SGD(Optimizer):
    """
    EFT-powered Stochastic Gradient Descent.

    Drop-in replacement for torch.optim.SGD with precise gradient accumulation.

    Args:
        params: Iterable of parameters to optimize
        lr: Learning rate
        momentum: Momentum factor (default: 0)
        dampening: Dampening for momentum (default: 0)
        weight_decay: Weight decay (L2 penalty) (default: 0)
        nesterov: Enables Nesterov momentum (default: False)

    Example:
        >>> from simgen.torch import SGD
        >>> optimizer = SGD(model.parameters(), lr=0.01, momentum=0.9)
    """

    def __init__(
        self,
        params: Iterable[torch.nn.Parameter],
        lr: float = 1e-3,
        momentum: float = 0,
        dampening: float = 0,
        weight_decay: float = 0,
        nesterov: bool = False
    ):
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if momentum < 0.0:
            raise ValueError(f"Invalid momentum value: {momentum}")
        if weight_decay < 0.0:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")
        if nesterov and (momentum <= 0 or dampening != 0):
            raise ValueError("Nesterov momentum requires a momentum and zero dampening")

        defaults = dict(
            lr=lr, momentum=momentum, dampening=dampening,
            weight_decay=weight_decay, nesterov=nesterov
        )
        super().__init__(params, defaults)

        self._use_eft = is_available()
        if self._use_eft:
            self._lib = get_lib()

        # Initialize compensation buffers
        for group in self.param_groups:
            for p in group['params']:
                state = self.state[p]
                state['weight_comp'] = torch.zeros_like(p.data)
                if momentum != 0:
                    state['momentum_buffer'] = torch.zeros_like(p.data)
                    state['momentum_comp'] = torch.zeros_like(p.data)

    @torch.no_grad()
    def step(self, closure: Optional[Callable] = None):
        """Performs a single optimization step."""
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            lr = group['lr']
            momentum = group['momentum']
            dampening = group['dampening']
            weight_decay = group['weight_decay']
            nesterov = group['nesterov']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                state = self.state[p]

                if self._use_eft and p.is_cuda and p.dtype == torch.float32:
                    # Use EFT kernel
                    n = p.numel()

                    if momentum != 0:
                        # TODO: Implement momentum with EFT
                        # For now, fall back to standard for momentum
                        self._standard_step(p, grad, state, group)
                    else:
                        # Pure SGD with EFT
                        self._lib.eft_sgd_step(
                            _ptr(p.data),
                            _ptr(state['weight_comp']),
                            _ptr(grad),
                            ctypes.c_float(lr),
                            ctypes.c_float(weight_decay),
                            ctypes.c_int(n)
                        )
                else:
                    # Fallback to standard PyTorch
                    self._standard_step(p, grad, state, group)

        return loss

    def _standard_step(self, p, grad, state, group):
        """Standard PyTorch SGD step (fallback)."""
        weight_decay = group['weight_decay']
        momentum = group['momentum']
        dampening = group['dampening']
        nesterov = group['nesterov']
        lr = group['lr']

        if weight_decay != 0:
            grad = grad.add(p.data, alpha=weight_decay)

        if momentum != 0:
            buf = state.get('momentum_buffer')
            if buf is None:
                buf = torch.clone(grad).detach()
                state['momentum_buffer'] = buf
            else:
                buf.mul_(momentum).add_(grad, alpha=1 - dampening)

            if nesterov:
                grad = grad.add(buf, alpha=momentum)
            else:
                grad = buf

        p.data.add_(grad, alpha=-lr)


class Adam(Optimizer):
    """
    EFT-powered Adam optimizer.

    Drop-in replacement for torch.optim.Adam with precise moment accumulation.

    The key insight: Adam's moment estimates (m and v) accumulate small updates
    over millions of steps. Standard FP32 loses precision. EFT tracks the
    exact error, ensuring stable training.

    Args:
        params: Iterable of parameters to optimize
        lr: Learning rate (default: 1e-3)
        betas: Coefficients for computing running averages (default: (0.9, 0.999))
        eps: Term added to denominator for numerical stability (default: 1e-8)
        weight_decay: Weight decay (L2 penalty) (default: 0)
        amsgrad: Whether to use AMSGrad variant (default: False)

    Example:
        >>> from simgen.torch import Adam
        >>> optimizer = Adam(model.parameters(), lr=1e-3)
    """

    def __init__(
        self,
        params: Iterable[torch.nn.Parameter],
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 0,
        amsgrad: bool = False
    ):
        if lr < 0.0:
            raise ValueError(f"Invalid learning rate: {lr}")
        if eps < 0.0:
            raise ValueError(f"Invalid epsilon value: {eps}")
        if not 0.0 <= betas[0] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 0: {betas[0]}")
        if not 0.0 <= betas[1] < 1.0:
            raise ValueError(f"Invalid beta parameter at index 1: {betas[1]}")
        if weight_decay < 0.0:
            raise ValueError(f"Invalid weight_decay value: {weight_decay}")

        defaults = dict(lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, amsgrad=amsgrad)
        super().__init__(params, defaults)

        self._use_eft = is_available()
        if self._use_eft:
            self._lib = get_lib()

    def _init_state(self, p):
        """Initialize state for a parameter."""
        state = self.state[p]
        state['step'] = 0
        state['exp_avg'] = torch.zeros_like(p.data)
        state['exp_avg_sq'] = torch.zeros_like(p.data)

        # EFT compensation buffers
        state['weight_comp'] = torch.zeros_like(p.data)
        state['exp_avg_comp'] = torch.zeros_like(p.data)
        state['exp_avg_sq_comp'] = torch.zeros_like(p.data)

        return state

    @torch.no_grad()
    def step(self, closure: Optional[Callable] = None):
        """Performs a single optimization step."""
        loss = None
        if closure is not None:
            with torch.enable_grad():
                loss = closure()

        for group in self.param_groups:
            beta1, beta2 = group['betas']
            lr = group['lr']
            eps = group['eps']
            weight_decay = group['weight_decay']
            amsgrad = group['amsgrad']

            for p in group['params']:
                if p.grad is None:
                    continue

                grad = p.grad.data
                if grad.is_sparse:
                    raise RuntimeError("Adam does not support sparse gradients")

                # Initialize state if needed
                state = self.state[p]
                if len(state) == 0:
                    state = self._init_state(p)

                state['step'] += 1
                step = state['step']

                if self._use_eft and p.is_cuda and p.dtype == torch.float32 and not amsgrad:
                    # Use EFT kernel
                    n = p.numel()

                    self._lib.eft_adam_step(
                        _ptr(p.data),
                        _ptr(state['weight_comp']),
                        _ptr(grad),
                        _ptr(state['exp_avg']),
                        _ptr(state['exp_avg_sq']),
                        _ptr(state['exp_avg_comp']),
                        _ptr(state['exp_avg_sq_comp']),
                        ctypes.c_float(lr),
                        ctypes.c_float(beta1),
                        ctypes.c_float(beta2),
                        ctypes.c_float(eps),
                        ctypes.c_float(weight_decay),
                        ctypes.c_int(step),
                        ctypes.c_int(n)
                    )
                else:
                    # Fallback to standard PyTorch Adam
                    self._standard_step(p, grad, state, group)

        return loss

    def _standard_step(self, p, grad, state, group):
        """Standard PyTorch Adam step (fallback)."""
        beta1, beta2 = group['betas']
        lr = group['lr']
        eps = group['eps']
        weight_decay = group['weight_decay']
        amsgrad = group['amsgrad']
        step = state['step']

        exp_avg = state['exp_avg']
        exp_avg_sq = state['exp_avg_sq']

        if weight_decay != 0:
            grad = grad.add(p.data, alpha=weight_decay)

        # Decay the first and second moment running average coefficient
        exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
        exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

        if amsgrad:
            max_exp_avg_sq = state.get('max_exp_avg_sq')
            if max_exp_avg_sq is None:
                max_exp_avg_sq = torch.zeros_like(p.data)
                state['max_exp_avg_sq'] = max_exp_avg_sq
            torch.maximum(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
            denom = (max_exp_avg_sq.sqrt() / (1 - beta2 ** step) ** 0.5).add_(eps)
        else:
            bias_correction1 = 1 - beta1 ** step
            bias_correction2 = 1 - beta2 ** step
            denom = (exp_avg_sq.sqrt() / (bias_correction2 ** 0.5)).add_(eps)

        step_size = lr / (1 - beta1 ** step) if not amsgrad else lr / (1 - beta1 ** step)
        p.data.addcdiv_(exp_avg, denom, value=-step_size)


class AdamW(Adam):
    """
    EFT-powered AdamW optimizer (Adam with decoupled weight decay).

    Same as Adam but with proper weight decay (not L2 regularization).

    Example:
        >>> from simgen.torch import AdamW
        >>> optimizer = AdamW(model.parameters(), lr=1e-3, weight_decay=0.01)
    """

    def __init__(
        self,
        params: Iterable[torch.nn.Parameter],
        lr: float = 1e-3,
        betas: tuple = (0.9, 0.999),
        eps: float = 1e-8,
        weight_decay: float = 1e-2,
        amsgrad: bool = False
    ):
        super().__init__(params, lr=lr, betas=betas, eps=eps, weight_decay=weight_decay, amsgrad=amsgrad)

    def _standard_step(self, p, grad, state, group):
        """AdamW step - weight decay applied directly to weights."""
        beta1, beta2 = group['betas']
        lr = group['lr']
        eps = group['eps']
        weight_decay = group['weight_decay']
        amsgrad = group['amsgrad']
        step = state['step']

        exp_avg = state['exp_avg']
        exp_avg_sq = state['exp_avg_sq']

        # Decoupled weight decay (applied to weights, not gradients)
        if weight_decay != 0:
            p.data.mul_(1 - lr * weight_decay)

        # Standard Adam update
        exp_avg.mul_(beta1).add_(grad, alpha=1 - beta1)
        exp_avg_sq.mul_(beta2).addcmul_(grad, grad, value=1 - beta2)

        if amsgrad:
            max_exp_avg_sq = state.get('max_exp_avg_sq')
            if max_exp_avg_sq is None:
                max_exp_avg_sq = torch.zeros_like(p.data)
                state['max_exp_avg_sq'] = max_exp_avg_sq
            torch.maximum(max_exp_avg_sq, exp_avg_sq, out=max_exp_avg_sq)
            denom = (max_exp_avg_sq.sqrt() / (1 - beta2 ** step) ** 0.5).add_(eps)
        else:
            bias_correction1 = 1 - beta1 ** step
            bias_correction2 = 1 - beta2 ** step
            denom = (exp_avg_sq.sqrt() / (bias_correction2 ** 0.5)).add_(eps)

        step_size = lr / (1 - beta1 ** step)
        p.data.addcdiv_(exp_avg, denom, value=-step_size)
