"""
SimGen VLA License Management
=============================

Handles license activation, validation, and usage tracking.

Usage:
    # Login via browser (recommended)
    simgen login

    # Or activate with key
    simgen activate <LICENSE_KEY>

    # Check status
    simgen status
"""

import os
import json
import hashlib
import platform
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, Any

# License server endpoint (SimGen's own Firebase project)
LICENSE_API = "https://us-central1-simgen-e33a6.cloudfunctions.net"

# Local config directory
CONFIG_DIR = Path.home() / ".simgen"
LICENSE_FILE = CONFIG_DIR / "license.json"
USAGE_FILE = CONFIG_DIR / "usage.json"

# License tiers and limits
TIER_LIMITS = {
    "FREE": {"operations_day": 10000, "commercial": False, "price": 0},
    "PRO": {"operations_day": float("inf"), "commercial": True, "price": 49},
    "TEAM": {"operations_day": float("inf"), "commercial": True, "price": 199},
    "ENTERPRISE": {"operations_day": float("inf"), "commercial": True, "price": "custom"},
}

# Session tracking
_session_start = None
_session_ops = 0


def _get_machine_id() -> str:
    """Generate a unique machine identifier."""
    data = f"{platform.node()}-{platform.machine()}-{platform.processor()}"
    return hashlib.sha256(data.encode()).hexdigest()[:16]


def _ensure_config_dir():
    """Create config directory if it doesn't exist."""
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def _load_license() -> Optional[Dict[str, Any]]:
    """Load license from local file."""
    if not LICENSE_FILE.exists():
        return None
    try:
        with open(LICENSE_FILE) as f:
            return json.load(f)
    except:
        return None


def _save_license(data: Dict[str, Any]):
    """Save license to local file."""
    _ensure_config_dir()
    with open(LICENSE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def _load_usage() -> Dict[str, Any]:
    """Load usage tracking data."""
    if not USAGE_FILE.exists():
        return {"sessions": [], "ops": 0, "day": datetime.now().strftime("%Y-%m-%d")}
    try:
        with open(USAGE_FILE) as f:
            data = json.load(f)
            # Reset if new day
            current_day = datetime.now().strftime("%Y-%m-%d")
            if data.get("day") != current_day:
                data = {"sessions": [], "ops": 0, "day": current_day}
            return data
    except:
        return {"sessions": [], "ops": 0, "day": datetime.now().strftime("%Y-%m-%d")}


def _save_usage(data: Dict[str, Any]):
    """Save usage tracking data."""
    _ensure_config_dir()
    with open(USAGE_FILE, "w") as f:
        json.dump(data, f, indent=2)


def login() -> Dict[str, Any]:
    """
    Browser-based login flow.
    Opens browser for user to authenticate, then automatically activates.

    Returns:
        dict with activation status and tier info
    """
    import webbrowser
    import time as _time

    machine_id = _get_machine_id()

    # Step 1: Request device auth code
    try:
        req_data = json.dumps({
            "machineId": machine_id,
            "platform": platform.system(),
            "product": "simgen",  # Identify as SimGen
        }).encode()

        req = urllib.request.Request(
            f"{LICENSE_API}/createDeviceAuth",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())

    except urllib.error.URLError:
        raise ConnectionError("Cannot reach license server. Check your internet connection.")

    device_code = result.get("deviceCode")
    auth_url = result.get("authUrl")

    if not device_code or not auth_url:
        raise ValueError("Failed to initiate login flow")

    # Step 2: Open browser
    print(f"\nOpening browser to complete login...")
    print(f"If browser doesn't open, visit: {auth_url}\n")
    webbrowser.open(auth_url)

    # Step 3: Poll for completion
    print("Waiting for authentication", end="", flush=True)
    for _ in range(60):  # 2 minute timeout
        _time.sleep(2)
        print(".", end="", flush=True)

        try:
            req = urllib.request.Request(
                f"{LICENSE_API}/checkDeviceAuth?code={device_code}&product=simgen",
                method="GET"
            )
            with urllib.request.urlopen(req, timeout=5) as resp:
                status = json.loads(resp.read().decode())

            if status.get("completed"):
                print(" Done!\n")

                # Save license
                license_data = {
                    "key": status.get("licenseKey"),
                    "tier": status.get("tier", "FREE"),
                    "email": status.get("email"),
                    "product": "simgen",
                    "activated_at": datetime.now().isoformat(),
                    "machine_id": machine_id,
                }
                _save_license(license_data)

                return {
                    "status": "activated",
                    "tier": license_data["tier"],
                    "email": license_data["email"],
                    "message": f"Login successful! Tier: {license_data['tier']}"
                }

        except:
            pass

    print(" Timeout")
    raise TimeoutError("Login timed out. Please try again.")


def activate(license_key: str) -> Dict[str, Any]:
    """
    Activate a license key.

    Args:
        license_key: License key from simgen.dev dashboard

    Returns:
        dict with activation status and tier info

    Raises:
        ValueError: If license key is invalid
    """
    if not license_key:
        raise ValueError("License key required")

    machine_id = _get_machine_id()

    # Validate with server
    try:
        req_data = json.dumps({
            "licenseKey": license_key,
            "machineId": machine_id,
            "platform": platform.system(),
            "pythonVersion": platform.python_version(),
            "product": "simgen",
        }).encode()

        req = urllib.request.Request(
            f"{LICENSE_API}/activateLicense",
            data=req_data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode())

    except urllib.error.HTTPError as e:
        error_body = e.read().decode() if e.fp else str(e)
        raise ValueError(f"Activation failed: {error_body}")
    except urllib.error.URLError:
        raise ConnectionError("Cannot reach license server. Check your internet connection.")

    if not result.get("valid"):
        raise ValueError(result.get("error", "Invalid license key"))

    # Save locally
    license_data = {
        "key": license_key,
        "tier": result.get("tier", "FREE"),
        "uid": result.get("uid"),
        "product": "simgen",
        "activated_at": datetime.now().isoformat(),
        "machine_id": machine_id,
    }
    _save_license(license_data)

    return {
        "status": "activated",
        "tier": license_data["tier"],
        "message": f"License activated! Tier: {license_data['tier']}"
    }


def deactivate():
    """Remove license from this machine."""
    if LICENSE_FILE.exists():
        LICENSE_FILE.unlink()
    if USAGE_FILE.exists():
        USAGE_FILE.unlink()
    print("License deactivated.")


def get_license_info() -> Dict[str, Any]:
    """Get current license information."""
    license_data = _load_license()
    usage = _load_usage()
    ops_used = usage.get("ops", 0)

    if not license_data:
        return {
            "tier": None,
            "activated": False,
            "usage": {
                "ops_used": ops_used,
                "ops_limit": 0,
                "day": usage.get("day"),
            }
        }

    tier = license_data.get("tier", "FREE")
    limits = TIER_LIMITS.get(tier, TIER_LIMITS["FREE"])

    return {
        "tier": tier,
        "activated": True,
        "email": license_data.get("email"),
        "key": license_data.get("key", "")[:12] + "...",
        "activated_at": license_data.get("activated_at"),
        "limits": limits,
        "usage": {
            "ops_used": ops_used,
            "ops_limit": limits["operations_day"],
            "day": usage.get("day"),
        }
    }


def check_license(silent: bool = False) -> bool:
    """
    Check if license is valid. Called on import.

    Args:
        silent: If True, don't print messages

    Returns:
        True if valid (FREE tier is valid)
    """
    license_data = _load_license()

    if not license_data:
        # Allow usage but show message once
        if not silent:
            _show_signup_message()
        # Still allow FREE tier usage
        return True

    return True


def _show_signup_message():
    """Show signup message (only once per session)."""
    flag_file = CONFIG_DIR / ".shown_signup"
    if flag_file.exists():
        return

    msg = """
================================================================================
SimGen VLA - Zero-Error Arithmetic

Free for personal/research use. Sign up for commercial use:
  https://simgen.dev

To remove this message:
  simgen login
================================================================================
"""
    print(msg)
    _ensure_config_dir()
    flag_file.touch()


def track_operation(count: int = 1):
    """Track operations for usage limiting."""
    global _session_ops
    _session_ops += count

    # Check limits periodically
    if _session_ops % 1000 == 0:
        _check_usage_limits()


def _check_usage_limits():
    """Check if usage limits exceeded."""
    info = get_license_info()

    usage = _load_usage()
    usage["ops"] = usage.get("ops", 0) + _session_ops
    _save_usage(usage)

    ops_limit = info["usage"]["ops_limit"]
    ops_used = usage["ops"]

    if ops_limit != float("inf") and ops_used > ops_limit:
        tier = info.get("tier", "FREE")
        raise UsageLimitError(
            f"\n{'='*60}\n"
            f"Daily limit reached ({ops_used:,} / {ops_limit:,} operations).\n\n"
            f"Upgrade for unlimited: https://simgen.dev/pricing\n"
            f"{'='*60}"
        )


class LicenseError(Exception):
    """License validation error."""
    pass


class UsageLimitError(Exception):
    """Usage limit exceeded."""
    pass


# CLI interface
def main():
    """CLI entry point for license management."""
    import sys

    if len(sys.argv) < 2:
        _print_status()
        return

    cmd = sys.argv[1].lower()

    if cmd == "login":
        try:
            result = login()
            print(f"\nSuccess! {result['message']}")
            if result.get('email'):
                print(f"Logged in as: {result['email']}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

    elif cmd == "activate":
        if len(sys.argv) < 3:
            print("Usage: simgen activate <LICENSE_KEY>")
            sys.exit(1)
        key = sys.argv[2]
        try:
            result = activate(key)
            print(f"\nSuccess! {result['message']}")
        except Exception as e:
            print(f"Error: {e}")
            sys.exit(1)

    elif cmd == "deactivate":
        deactivate()

    elif cmd == "status":
        _print_status()

    else:
        print(f"Unknown command: {cmd}")
        print("\nCommands:")
        print("  simgen login           - Login via browser")
        print("  simgen activate <KEY>  - Activate with license key")
        print("  simgen deactivate      - Remove license")
        print("  simgen status          - Show license info")
        sys.exit(1)


def _print_status():
    """Print license status."""
    print("\nSimGen VLA License Status")
    print("=" * 40)

    info = get_license_info()

    if not info["activated"]:
        print("Status: Free tier (not logged in)")
        print(f"Usage today: {info['usage']['ops_used']:,} operations")
        print("\nSign up: https://simgen.dev")
        print("Then run: simgen login")
    else:
        print(f"Status: Activated")
        print(f"Tier: {info['tier']}")
        if info.get('email'):
            print(f"Email: {info['email']}")
        print(f"Key: {info.get('key', 'N/A')}")
        print(f"\nUsage today:")
        limit = info['usage']['ops_limit']
        limit_str = "unlimited" if limit == float("inf") else f"{limit:,}"
        print(f"  Operations: {info['usage']['ops_used']:,} / {limit_str}")

        if info['tier'] == 'FREE':
            print(f"\nUpgrade for unlimited: https://simgen.dev/pricing")


if __name__ == "__main__":
    main()
