## Installation

```bash
pip install piki_bots_common