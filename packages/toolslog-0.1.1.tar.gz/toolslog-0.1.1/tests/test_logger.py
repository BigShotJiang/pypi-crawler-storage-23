"""Tests for toolslog logger configuration."""

import json
import logging
import os
import unittest
from unittest.mock import patch


class TestGetLogger(unittest.TestCase):
    """Tests for get_logger."""

    def test_returns_logger_named_after_file(self):
        from toolslog import get_logger

        logger = get_logger("/some/path/my_script.py")
        self.assertEqual(logger.name, "my_script")

    def test_strips_extension(self):
        from toolslog import get_logger

        logger = get_logger("app.py")
        self.assertEqual(logger.name, "app")

    def test_strips_directory(self):
        from toolslog import get_logger

        logger = get_logger("/home/user/projects/main.py")
        self.assertEqual(logger.name, "main")


class TestLocalFormatter(unittest.TestCase):
    """Tests for local (non-GCP) log format."""

    def setUp(self):
        # Force re-setup as local
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {}, clear=True):
            _setup_root_logger()

        self.root = logging.getLogger()
        self.handler = self.root.handlers[0]

    def test_no_milliseconds_in_timestamp(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="", lineno=0,
            msg="hello", args=(), exc_info=None,
        )
        record.funcName = "my_func"
        output = self.handler.formatter.format(record)
        # should NOT contain comma followed by digits (milliseconds)
        self.assertNotRegex(output, r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2},\d+")
        # should contain clean timestamp
        self.assertRegex(output, r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2} \|")

    def test_contains_function_name(self):
        record = logging.LogRecord(
            name="mymod", level=logging.WARNING, pathname="", lineno=0,
            msg="oops", args=(), exc_info=None,
        )
        record.funcName = "process_data"
        output = self.handler.formatter.format(record)
        self.assertIn("| process_data |", output)

    def test_field_order(self):
        record = logging.LogRecord(
            name="mymod", level=logging.ERROR, pathname="", lineno=0,
            msg="broken", args=(), exc_info=None,
        )
        record.funcName = "do_thing"
        output = self.handler.formatter.format(record)
        parts = [p.strip() for p in output.split("|")]
        # timestamp, level, name, funcName, message
        self.assertEqual(len(parts), 5)
        self.assertEqual(parts[1], "ERROR")
        self.assertEqual(parts[2], "mymod")
        self.assertEqual(parts[3], "do_thing")
        self.assertEqual(parts[4], "broken")

    def test_outputs_to_stdout(self):
        import sys

        self.assertIs(self.handler.stream, sys.stdout)


class TestCloudRunFormatter(unittest.TestCase):
    """Tests for GCP (Cloud Run) JSON format."""

    def setUp(self):
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {"K_SERVICE": "my-service"}, clear=True):
            _setup_root_logger()

        self.root = logging.getLogger()
        self.handler = self.root.handlers[0]

    def tearDown(self):
        # Restore local formatter
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {}, clear=True):
            _setup_root_logger()

    def test_outputs_valid_json(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="app.py", lineno=42,
            msg="hello", args=(), exc_info=None,
        )
        record.funcName = "run"
        output = self.handler.formatter.format(record)
        parsed = json.loads(output)
        self.assertIsInstance(parsed, dict)

    def test_severity_field(self):
        record = logging.LogRecord(
            name="test", level=logging.ERROR, pathname="app.py", lineno=1,
            msg="fail", args=(), exc_info=None,
        )
        record.funcName = "run"
        output = self.handler.formatter.format(record)
        parsed = json.loads(output)
        self.assertEqual(parsed["severity"], "ERROR")

    def test_source_location_includes_function(self):
        record = logging.LogRecord(
            name="test", level=logging.INFO, pathname="app.py", lineno=10,
            msg="hi", args=(), exc_info=None,
        )
        record.funcName = "my_handler"
        output = self.handler.formatter.format(record)
        parsed = json.loads(output)
        src = parsed["logging.googleapis.com/sourceLocation"]
        self.assertEqual(src["function"], "my_handler")
        self.assertEqual(src["file"], "app.py")
        self.assertEqual(src["line"], 10)

    def test_outputs_to_stderr(self):
        import sys

        self.assertIs(self.handler.stream, sys.stderr)

    def test_traceback_included_on_exception(self):
        try:
            raise ValueError("test error")
        except ValueError:
            import sys

            exc_info = sys.exc_info()

        record = logging.LogRecord(
            name="test", level=logging.ERROR, pathname="app.py", lineno=1,
            msg="fail", args=(), exc_info=exc_info,
        )
        record.funcName = "run"
        output = self.handler.formatter.format(record)
        parsed = json.loads(output)
        self.assertIn("traceback", parsed)
        self.assertIn("ValueError", parsed["traceback"])


class TestGCPDetection(unittest.TestCase):
    """Tests for _is_running_on_gcp."""

    def test_not_on_gcp_by_default(self):
        from toolslog.logger import _is_running_on_gcp

        with patch.dict(os.environ, {}, clear=True):
            self.assertFalse(_is_running_on_gcp())

    def test_k_service_detected(self):
        from toolslog.logger import _is_running_on_gcp

        with patch.dict(os.environ, {"K_SERVICE": "my-svc"}, clear=True):
            self.assertTrue(_is_running_on_gcp())

    def test_cloud_run_job_detected(self):
        from toolslog.logger import _is_running_on_gcp

        with patch.dict(os.environ, {"CLOUD_RUN_JOB": "my-job"}, clear=True):
            self.assertTrue(_is_running_on_gcp())


class TestLogLevel(unittest.TestCase):
    """Tests for LOG_LEVEL env var."""

    def test_default_level_is_info(self):
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {}, clear=True):
            _setup_root_logger()
        self.assertEqual(logging.getLogger().level, logging.INFO)

    def test_log_level_env_var(self):
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {"LOG_LEVEL": "DEBUG"}, clear=True):
            _setup_root_logger()
        self.assertEqual(logging.getLogger().level, logging.DEBUG)

    def test_log_level_case_insensitive(self):
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {"LOG_LEVEL": "warning"}, clear=True):
            _setup_root_logger()
        self.assertEqual(logging.getLogger().level, logging.WARNING)

    def test_invalid_log_level_falls_back_to_info(self):
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {"LOG_LEVEL": "NONSENSE"}, clear=True):
            _setup_root_logger()
        self.assertEqual(logging.getLogger().level, logging.INFO)

    def tearDown(self):
        # Restore default
        from toolslog.logger import _setup_root_logger

        with patch.dict(os.environ, {}, clear=True):
            _setup_root_logger()


if __name__ == "__main__":
    unittest.main()
