"""
toolslog - Shared logging configuration for Python scripts and Cloud Run/Functions.

Configures the root logger once on import.
Works on Cloud Run/Functions (JSON with severity) and locally (plain text to stdout).
Note: this is opinionated — it takes over the root logger. Only use in your own entry points.
Libraries (toolsbq etc.) should only do: logging.getLogger(__name__)

=== Setup ===

    from toolslog import get_logger
    logger = get_logger(__file__)

    logger.debug("verbose detail")         # hidden by default (level=INFO)
    logger.info("normal flow")
    logger.warning("potential issue")
    logger.error("something failed")
    logger.critical("system-level failure")

=== Log level control ===

    Default level is INFO. Override via LOG_LEVEL environment variable.

    # everything DEBUG (all modules):
    LOG_LEVEL=DEBUG python main.py

    # check / set / unset env var in current shell session:
    echo $LOG_LEVEL
    export LOG_LEVEL=DEBUG
    unset LOG_LEVEL

    # only current script to DEBUG (add in script, imported modules stay at INFO):
    import logging
    logger.setLevel(logging.DEBUG)

    # only a specific library to DEBUG:
    logging.getLogger("toolsbq").setLevel(logging.DEBUG)

    # silence a noisy library:
    logging.getLogger("toolsbq").setLevel(logging.WARNING)

    # suppress urllib3 connection/retry warnings:
    logging.getLogger("urllib3").setLevel(logging.WARNING)

    # suppress google-auth / google-api / discovery noise:
    logging.getLogger("google").setLevel(logging.WARNING)
    logging.getLogger("googleapiclient.discovery_cache").setLevel(logging.ERROR)

=== Searching logs locally ===

    # errors and tracebacks:
    grep -E "(\\| ERROR \\||\\| CRITICAL \\||Traceback|Error:|Exception:)" app.log

    # warnings and above:
    grep -E "\\| (WARNING|ERROR|CRITICAL) \\|" app.log

    # specific module:
    grep "| toolsbq |" app.log

    # specific function:
    grep "| fetch_data |" app.log

=== Local output format ===

    2026-02-26 15:03:17 | INFO | main | run | Starting execution
    2026-02-26 15:03:17 | ERROR | toolsbq | fetch_data | Query failed: timeout

=== Cloud Run output format (auto-detected) ===

    {"severity": "INFO", "message": "Starting execution", "logger": "main", ...}
"""

import json
import logging
import os
import sys


class _CloudRunFormatter(logging.Formatter):
    """JSON with 'severity' key for Cloud Logging.
    https://cloud.google.com/logging/docs/structured-logging
    """

    def format(self, record):
        log_entry = {
            "severity": record.levelname,
            "message": record.getMessage(),
            "logger": record.name,
            "logging.googleapis.com/sourceLocation": {
                "file": record.pathname,
                "line": record.lineno,
                "function": record.funcName,
            },
        }
        if record.exc_info and record.exc_info[0] is not None:
            log_entry["traceback"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)


def _is_running_on_gcp() -> bool:
    return any(
        os.environ.get(k)
        for k in (
            "K_SERVICE",  # Cloud Run (services)
            # "K_REVISION",          # Cloud Run (revisions)
            "CLOUD_RUN_JOB",  # Cloud Run (jobs)
            # "FUNCTION_TARGET",     # Cloud Functions (1st gen)
        )
    )


def _setup_root_logger() -> None:
    """Force-configure the root logger.
    Does not rely on basicConfig (which is a no-op if another library
    like functions_framework already configured logging)."""

    root = logging.getLogger()

    # LOG_LEVEL env var overrides default INFO
    level_name = os.environ.get("LOG_LEVEL", "INFO").upper()
    root.setLevel(getattr(logging, level_name, logging.INFO))

    # Remove any existing handlers (e.g. from functions_framework)
    root.handlers.clear()

    if _is_running_on_gcp():
        handler = logging.StreamHandler(sys.stderr)
        handler.setFormatter(_CloudRunFormatter())
    else:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s | %(levelname)s | %(name)s | %(funcName)s | %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )

    root.addHandler(handler)


# ── run once on import ────────────────────────────────────────────────────────
_setup_root_logger()
# ──────────────────────────────────────────────────────────────────────────────


def get_logger(caller_file: str) -> logging.Logger:
    """Return a logger named after the calling script's filename (without extension)."""
    name = os.path.splitext(os.path.basename(caller_file))[0]
    return logging.getLogger(name)
