"""
Diagnostic test: verify the full Django signal → EventBus → Soketi chain works.
"""
import os
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'tests.settings')

import django
django.setup()

from unittest.mock import patch, MagicMock
from django.test import TestCase, TransactionTestCase
from tests.django_app.models import DummyModel, DummyRelatedModel
from statezero.adaptors.django.config import config


class SoketiEmitTest(TransactionTestCase):
    """
    Uses TransactionTestCase so on_commit callbacks actually fire.
    """

    def test_direct_trigger_to_soketi(self):
        """Raw pusher client trigger to Soketi works."""
        import pusher

        client = pusher.Pusher(
            app_id=os.environ['PUSHER_APP_ID'],
            key=os.environ['PUSHER_KEY'],
            secret=os.environ['PUSHER_SECRET'],
            host=os.environ['PUSHER_HOST'],
            port=int(os.environ.get('PUSHER_PORT', '443')),
            ssl=True,
        )
        result = client.trigger('private-test', 'create', {'test': True})
        self.assertTrue(result.get('ok'), f"Direct trigger failed: {result}")
        print(f"\n  Direct trigger result: {result}")

    def test_model_create_triggers_soketi_emit(self):
        """
        Create a DummyModel instance and verify the broadcast emitter's
        emit() method is called with the right args.
        """
        emitter = config.event_bus.broadcast_emitter
        print(f"\n  Emitter class: {type(emitter).__name__}")
        print(f"  Has pusher_client: {hasattr(emitter, 'pusher_client')}")

        with patch.object(emitter, 'emit', wraps=emitter.emit) as mock_emit:
            instance = DummyModel.objects.create(name="SoketiSignalTest", value=99)
            print(f"  Created instance pk={instance.pk}")

            # on_commit fires here because TransactionTestCase doesn't wrap in txn
            if mock_emit.called:
                print(f"  emit() was called {mock_emit.call_count} time(s)")
                for call in mock_emit.call_args_list:
                    print(f"    args: {call}")
            else:
                print("  WARNING: emit() was NOT called!")

            self.assertTrue(mock_emit.called, "emit() was never called after model create")

    def test_model_create_actually_reaches_soketi(self):
        """
        Create a DummyModel and verify the pusher trigger returns ok.
        Patches the pusher client's trigger to capture the call and still execute it.
        """
        emitter = config.event_bus.broadcast_emitter
        if not hasattr(emitter, 'pusher_client'):
            self.fail("Emitter is not a PusherEventEmitter")

        original_trigger = emitter.pusher_client.trigger
        trigger_results = []

        def capturing_trigger(*args, **kwargs):
            result = original_trigger(*args, **kwargs)
            trigger_results.append({'args': args, 'kwargs': kwargs, 'result': result})
            print(f"\n    pusher.trigger called: channel={args[0]}, event={args[1]}")
            print(f"    data={args[2] if len(args) > 2 else kwargs.get('data')}")
            print(f"    result={result}")
            return result

        with patch.object(emitter.pusher_client, 'trigger', side_effect=capturing_trigger):
            instance = DummyModel.objects.create(name="SoketiFullTest", value=123)
            print(f"\n  Created instance pk={instance.pk}")

        if trigger_results:
            print(f"\n  Soketi received {len(trigger_results)} trigger(s)")
            for tr in trigger_results:
                self.assertTrue(tr['result'].get('ok'), f"Soketi trigger failed: {tr['result']}")
        else:
            self.fail("pusher_client.trigger was never called - events are not reaching Soketi")
