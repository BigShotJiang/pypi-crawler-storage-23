<img src="https://raw.githubusercontent.com/databio/pypiper/master/logo_pypiper.svg?sanitize=true" alt="Pypiper logo" height="70" align="left"/>

# Pypiper

[![Build Status](https://github.com/databio/pypiper/actions/workflows/run-pytest.yml/badge.svg)](https://github.com/databio/pypiper/actions/workflows/run-pytest.yml)
[![pypi-badge](https://img.shields.io/pypi/v/piper)](https://pypi.org/project/piper)

A lightweight Python toolkit for gluing together restartable, robust shell pipelines. Pypiper manages shell command execution with automatic restartability, file integrity protection, resource monitoring, and detailed logging -- useful for any multi-step workflow that calls command-line tools. Learn more in the [documentation](https://pep.databio.org/pypiper/).
