"""FastAPI REST API for the review system (serves the Angular UI)."""

from __future__ import annotations

import os
from contextlib import asynccontextmanager
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from . import db

REVIEW_PORT = int(os.environ.get("REVIEW_PORT", "3200"))


@asynccontextmanager
async def lifespan(_app: FastAPI):
    await db.init_db()
    yield


app = FastAPI(title="Review System API", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------- Models ---------------


class ReviewCreate(BaseModel):
    author: str = "anonymous"
    text: str


class ReviewUpdate(BaseModel):
    status: Optional[str] = None
    text: Optional[str] = None
    resolved_by: Optional[str] = None


# --------------- Endpoints ---------------


@app.get("/api/reviews/summary")
async def summary():
    return await db.get_summary()


@app.get("/api/reviews")
async def all_reviews():
    return await db.get_reviews()


@app.get("/api/reviews/{page_id:path}")
async def page_reviews(page_id: str):
    return await db.get_reviews(page_id)


@app.post("/api/reviews/{page_id:path}", status_code=201)
async def create_review(page_id: str, body: ReviewCreate):
    return await db.insert_review(page_id, body.author, body.text)


@app.patch("/api/review/{review_id}")
async def patch_review(review_id: int, body: ReviewUpdate):
    fields: dict = {}
    if body.status is not None:
        fields["status"] = body.status
        if body.status == "resolved":
            from datetime import datetime, timezone
            fields["resolved_at"] = datetime.now(timezone.utc).isoformat()
            fields["resolved_by"] = body.resolved_by or "user"
        elif body.status == "open":
            fields["resolved_at"] = None
            fields["resolved_by"] = None
    if body.text is not None:
        fields["text"] = body.text

    result = await db.update_review(review_id, **fields)
    if result is None:
        raise HTTPException(404, "Review not found")
    return result


@app.delete("/api/review/{review_id}")
async def remove_review(review_id: int):
    ok = await db.delete_review(review_id)
    if not ok:
        raise HTTPException(404, "Review not found")
    return {"deleted": True}


# --------------- Main ---------------

if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=REVIEW_PORT)
