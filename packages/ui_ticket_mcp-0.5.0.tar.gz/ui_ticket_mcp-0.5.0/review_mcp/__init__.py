"""Review system – MCP server + FastAPI REST API."""
