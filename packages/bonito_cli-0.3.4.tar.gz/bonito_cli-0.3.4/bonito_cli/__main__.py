"""Allow running as `python -m bonito_cli`."""
from bonito_cli.app import app

app()
