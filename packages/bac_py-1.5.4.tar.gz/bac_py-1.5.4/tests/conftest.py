"""Shared test fixtures for bac-py."""
