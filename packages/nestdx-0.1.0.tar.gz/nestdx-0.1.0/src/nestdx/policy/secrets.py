"""Secrets scanner — detect leaked credentials in file contents."""

from __future__ import annotations

import logging
import re
from pathlib import Path

import yaml

from nestdx.config.schema import SecretsPolicy
from nestdx.session.models import FileChange, PolicyViolation

logger = logging.getLogger(__name__)

# Chunk size for binary detection
_BINARY_CHECK_SIZE = 8192


def _is_binary(path: Path) -> bool:
    """Check if a file is binary by looking for null bytes."""
    try:
        chunk = path.read_bytes()[:_BINARY_CHECK_SIZE]
        return b"\x00" in chunk
    except OSError:
        return True


def _load_custom_patterns(file_path: Path) -> list[str]:
    """Load custom secret patterns from a YAML file.

    Expected format: a YAML list of regex strings.

    Returns an empty list on parse errors (with warning logged).
    Raises FileNotFoundError if the file does not exist.
    """
    if not file_path.is_file():
        raise FileNotFoundError(f"Custom patterns file not found: {file_path}")

    try:
        raw = yaml.safe_load(file_path.read_text())
    except yaml.YAMLError as e:
        logger.warning("Failed to parse custom patterns file '%s': %s", file_path, e)
        return []

    if raw is None:
        return []

    if not isinstance(raw, list):
        logger.warning(
            "Custom patterns file '%s' must be a YAML list of regex strings.", file_path
        )
        return []

    patterns: list[str] = []
    for item in raw:
        if isinstance(item, str):
            patterns.append(item)
        else:
            logger.warning("Skipping non-string pattern in '%s': %r", file_path, item)

    return patterns


class SecretsScanner:
    """Scan file contents for leaked secrets using regex patterns."""

    def __init__(self, policy: SecretsPolicy, project_root: Path | None = None):
        self.policy = policy
        self._compiled: list[tuple[str, re.Pattern]] = []

        # Collect all patterns: built-in + custom file
        all_patterns = list(policy.block_patterns)

        if policy.custom_patterns_file and project_root:
            custom_path = project_root / policy.custom_patterns_file
            try:
                custom = _load_custom_patterns(custom_path)
                all_patterns.extend(custom)
            except FileNotFoundError:
                logger.error("Custom patterns file not found: %s", custom_path)

        for pattern_str in all_patterns:
            try:
                self._compiled.append((pattern_str, re.compile(pattern_str)))
            except re.error as e:
                logger.warning("Skipping invalid secret pattern '%s': %s", pattern_str, e)

    def scan_file(self, file_path: Path) -> list[PolicyViolation]:
        """Scan a single file for secrets. Returns violations found."""
        if not file_path.is_file():
            return []

        if _is_binary(file_path):
            logger.debug("Skipping binary file: %s", file_path)
            return []

        violations: list[PolicyViolation] = []
        try:
            lines = file_path.read_text(errors="replace").splitlines()
        except OSError as e:
            logger.warning("Cannot read file %s: %s", file_path, e)
            return []

        for line_num, line in enumerate(lines, start=1):
            for pattern_str, compiled in self._compiled:
                if compiled.search(line):
                    violations.append(
                        PolicyViolation(
                            rule="secrets.block_patterns",
                            severity="error",
                            message=f"Possible secret detected: pattern '{pattern_str}' matched",
                            file=str(file_path),
                            line=line_num,
                            pattern=pattern_str,
                        )
                    )
        return violations

    def scan_changes(
        self, file_changes: list[FileChange], project_root: Path
    ) -> list[PolicyViolation]:
        """Scan all changed files for secrets."""
        violations: list[PolicyViolation] = []
        for change in file_changes:
            if change.change_type == "deleted":
                continue
            file_path = project_root / change.path
            file_violations = self.scan_file(file_path)
            # Store relative path in violations
            for v in file_violations:
                v.file = change.path
            violations.extend(file_violations)
        return violations
