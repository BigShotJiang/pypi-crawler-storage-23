"""Tool adapters — abstract base, concrete implementations, and registry."""

from __future__ import annotations

from nestdx.adapters.base import ToolAdapter
from nestdx.adapters.claude_code import ClaudeCodeAdapter
from nestdx.adapters.codex import CodexAdapter
from nestdx.adapters.cursor import CursorAdapter
from nestdx.adapters.generic import GenericAdapter
from nestdx.adapters.hatchdx import HatchDXAdapter

ADAPTER_REGISTRY: dict[str, type[ToolAdapter]] = {
    "claude-code": ClaudeCodeAdapter,
    "codex": CodexAdapter,
    "cursor": CursorAdapter,
    "hdx-agent": HatchDXAdapter,
}


def resolve_adapter(
    tool_name: str | None,
    command: list[str] | None = None,
) -> ToolAdapter:
    """Return the appropriate adapter for *tool_name*.

    If *tool_name* is found in :data:`ADAPTER_REGISTRY`, instantiate and
    return the registered adapter.  Otherwise fall back to
    :class:`GenericAdapter` using *command* (which must not be empty).
    """
    if tool_name and tool_name in ADAPTER_REGISTRY:
        return ADAPTER_REGISTRY[tool_name]()

    # Unknown tool name or generic invocation — wrap as a generic command.
    cmd = command or ([tool_name] if tool_name else [])
    if not cmd:
        raise ValueError("Cannot resolve adapter: no tool name or command provided.")
    return GenericAdapter(cmd)


__all__ = [
    "ADAPTER_REGISTRY",
    "ClaudeCodeAdapter",
    "CodexAdapter",
    "CursorAdapter",
    "GenericAdapter",
    "HatchDXAdapter",
    "ToolAdapter",
    "resolve_adapter",
]
