"""NestDX CLI entry point."""

import logging

import click

from nestdx import __version__
from nestdx.cli.audit_cmd import audit_cmd
from nestdx.cli.init_cmd import init_cmd
from nestdx.cli.log_cmd import log_cmd
from nestdx.cli.report_cmd import report_cmd
from nestdx.cli.run_cmd import run_cmd
from nestdx.cli.sessions_cmd import sessions_cmd
from nestdx.cli.start_cmd import start_cmd
from nestdx.cli.stop_cmd import stop_cmd


def _setup_logging(verbose: bool, quiet: bool) -> None:
    """Configure logging based on CLI flags."""
    if verbose:
        level = logging.DEBUG
        fmt = "%(asctime)s %(name)s %(levelname)s: %(message)s"
    elif quiet:
        level = logging.WARNING
        fmt = "%(levelname)s: %(message)s"
    else:
        level = logging.INFO
        fmt = "%(levelname)s: %(message)s"

    logging.basicConfig(level=level, format=fmt, force=True)


@click.group()
@click.version_option(version=__version__, prog_name="nestdx")
@click.option("--verbose", "-v", is_flag=True, help="Enable debug output.")
@click.option("--quiet", "-q", is_flag=True, help="Suppress non-essential output.")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, quiet: bool):
    """NestDX — Secure workspaces for AI-assisted development."""
    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    _setup_logging(verbose, quiet)


cli.add_command(init_cmd, "init")
cli.add_command(start_cmd, "start")
cli.add_command(stop_cmd, "stop")
cli.add_command(run_cmd, "run")
cli.add_command(log_cmd, "log")
cli.add_command(audit_cmd, "audit")
cli.add_command(sessions_cmd, "sessions")
cli.add_command(report_cmd, "report")
