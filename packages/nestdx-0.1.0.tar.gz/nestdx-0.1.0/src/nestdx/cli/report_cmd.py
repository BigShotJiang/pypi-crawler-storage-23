"""nestdx report — generate usage reports from session history."""

from __future__ import annotations

from pathlib import Path

import click

from nestdx.config.parser import load_config
from nestdx.reporting.generator import ReportGenerator
from nestdx.session.manager import SessionManager
from nestdx.utils.console import console


@click.command()
@click.option("--days", "-d", default=30, help="Time range in days (default: 30).")
@click.option("--by-tool", is_flag=True, help="Breakdown by tool.")
@click.option("--by-engineer", is_flag=True, help="Breakdown by git author.")
@click.option(
    "--format",
    "fmt",
    type=click.Choice(["rich", "json", "csv"]),
    default="rich",
    help="Output format (default: rich).",
)
def report_cmd(days: int, by_tool: bool, by_engineer: bool, fmt: str):
    """Generate a usage report from session history."""
    project_root = Path.cwd()

    try:
        config = load_config()
    except Exception as e:
        console.print(f"[red]Error:[/red] {e}")
        raise SystemExit(1)

    manager = SessionManager(config, project_root)
    generator = ReportGenerator(manager.store)

    group_by = None
    if by_tool:
        group_by = "tool"
    elif by_engineer:
        group_by = "engineer"

    result = generator.generate(days=days, group_by=group_by, fmt=fmt)
    if result is not None:
        click.echo(result)
