"""Holds basic metadata on the fore optics of Lux"""

# Standard library
from dataclasses import dataclass

# Third-party
import astropy.units as u
import astropy.io.fits as fits
import numpy as np

# Local
from . import config

@dataclass
class Hardware:
    """Holds basic metadata on the optics of Lux

    Args:
        mirror_diameter (float): Diameter of the Lux primary mirror
    """

    def __repr__(self):
        return "Lux Fore Optics"

    @property
    def primary_mirror_physical_diameter(self):
        """Diameter of Lux's primary mirror that will reflect light."""
        return 44.25 * u.cm

    @property
    def secondary_mirror_physical_diameter(self):
        """Diameter of Pandora's secondary mirror that will block light."""
        return 10.6 * u.cm
        
    @property
    def primary_mirror_spider_area(self):
    	"""Area primary mirror spiders that will block light."""
    	return ((18.0 * u.cm) * (0.965 * u.cm))
    	
    @property
    def number_primary_mirror_spiders(self):
    	"""Number of primary mirror spiders that will block light."""
    	return 4
    	
    @property
    def primary_mirror_effective_diameter(self):
        """Diameter of Lux's mirror. This should be the effective diameter of the primary, removing the secondary diameter and spiders."""
        A_primary = np.pi * (self.primary_mirror_physical_diameter / 2) ** 2
        A_secondary = (
            np.pi * (self.secondary_mirror_physical_diameter / 2) ** 2
        )
        A_spiders = self.number_primary_mirror_spiders * self.primary_mirror_spider_area
        r_primary = ((A_primary - A_secondary - A_spiders) / np.pi) ** 0.5
        return r_primary * 2
        
    @property
    def fore_throughput(self):
    	"""Throughput of primary and secondary (fore) optics"""
    	f = fits.open(config.DATADIR + "Fore_Optics_Throughput.fits")
    	return f[1].data["Throughput"]