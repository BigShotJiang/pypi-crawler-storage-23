"""
Setup configuration for pump-swap-sdk-python
"""

from setuptools import setup, find_packages
import os

# Read the README file for long description
def read_long_description():
    here = os.path.abspath(os.path.dirname(__file__))
    readme_path = os.path.join(here, "README.md")
    if os.path.exists(readme_path):
        with open(readme_path, "r", encoding="utf-8") as f:
            return f.read()
    return ""

# Read version from __init__.py
def get_version():
    version = {}
    here = os.path.abspath(os.path.dirname(__file__))
    version_path = os.path.join(here, "pump_swap_sdk", "__init__.py")
    try:
        with open(version_path) as fp:
            exec(fp.read(), version)
        return version.get("__version__", "1.0.0")
    except (FileNotFoundError, KeyError):
        return "1.0.0"

setup(
    name="pumpswap-python-sdk",
    version=get_version(),
    description="Python SDK for interacting with Pump Swap AMM protocol on Solana",
    long_description=read_long_description(),
    long_description_content_type="text/markdown",
    author="PumpSwap Python SDK Contributors",
    author_email="dev@pump.fun",
    url="https://github.com/pump-fun/pump-swap-sdk-python",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business :: Financial :: Investment",
        "Topic :: System :: Networking",
    ],
    keywords=[
        "solana",
        "blockchain",
        "defi",
        "amm",
        "swap",
        "liquidity",
        "pump",
        "cryptocurrency",
        "trading"
    ],
    python_requires=">=3.8",
    install_requires=[
        "solders>=0.20.0",
        "solana>=0.32.0",
        "construct>=2.10.0",
        "typing-extensions>=4.0.0;python_version<'3.10'",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "pytest-asyncio>=0.21.0",
            "black>=23.0.0",
            "isort>=5.0.0",
            "flake8>=6.0.0",
            "mypy>=1.0.0",
            "pre-commit>=3.0.0",
        ],
        "docs": [
            "sphinx>=6.0.0",
            "sphinx-rtd-theme>=1.2.0",
            "myst-parser>=1.0.0",
        ],
        "testing": [
            "pytest>=7.0.0",
            "pytest-cov>=4.0.0",
            "pytest-asyncio>=0.21.0",
            "responses>=0.23.0",
        ]
    },
    entry_points={
        "console_scripts": [
            "pump-swap-cli=pump_swap_sdk.cli:main",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    project_urls={
        "Documentation": "https://docs.pump.fun/sdk/python",
        "Source": "https://github.com/pump-fun/pump-swap-sdk-python",
        "Tracker": "https://github.com/pump-fun/pump-swap-sdk-python/issues",
        "Homepage": "https://pump.fun",
    },
)