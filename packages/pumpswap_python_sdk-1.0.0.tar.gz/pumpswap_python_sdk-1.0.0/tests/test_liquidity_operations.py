"""
Test liquidity operations (deposit/withdraw calculations)
"""

import pytest
import math
from pump_swap_sdk.sdk.liquidity_operations import (
    deposit_token0, deposit_lp_token, withdraw,
    deposit_quote_and_lp_token_from_base,
    deposit_base_and_lp_token_from_quote,
    withdraw_autocomplete_base_and_quote_from_lp_token,
    validate_deposit_amounts
)
from pump_swap_sdk.exceptions import ValidationError, LiquidityError


class TestLiquidityOperations:
    """Test liquidity deposit and withdrawal operations"""

    def setup_method(self):
        """Set up test data"""
        self.base_reserve = 1_000_000_000  # 1B base tokens
        self.quote_reserve = 2_000_000_000  # 2B quote tokens (2:1 ratio)
        self.lp_total_supply = 1_000_000_000  # 1B LP tokens
        self.slippage = 100  # 1% slippage

    def test_deposit_token0_basic(self):
        """Test basic deposit with token0 (base) input"""
        base_deposit = 1_000_000  # 1 token

        result = deposit_token0(
            token0=base_deposit,
            slippage=self.slippage,
            token0_reserve=self.base_reserve,
            token1_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'quote')
        assert hasattr(result, 'lp_token')
        assert hasattr(result, 'max_base')
        assert hasattr(result, 'max_quote')

        # Verify amounts are positive
        assert result.quote > 0
        assert result.lp_token > 0
        assert result.max_base > 0
        assert result.max_quote > 0

        # Verify proportional deposit
        expected_quote = (base_deposit * self.quote_reserve + self.base_reserve - 1) // self.base_reserve  # Ceiling division
        assert result.quote == expected_quote

        # Verify LP tokens calculation
        expected_lp = (base_deposit * self.lp_total_supply) // self.base_reserve
        assert result.lp_token == expected_lp

        # Verify slippage protection
        assert result.max_base > base_deposit
        assert result.max_quote > result.quote

    def test_deposit_token0_zero_supply(self):
        """Test deposit with zero LP supply (initial deposit)"""
        base_deposit = 1_000_000

        with pytest.raises((ValueError, LiquidityError)):
            deposit_token0(
                token0=base_deposit,
                slippage=self.slippage,
                token0_reserve=self.base_reserve,
                token1_reserve=self.quote_reserve,
                total_lp_supply=0  # Zero LP supply
            )

    def test_deposit_lp_token_basic(self):
        """Test deposit by specifying desired LP token amount"""
        lp_desired = 1_000_000  # 1 LP token

        result = deposit_lp_token(
            lp_token=lp_desired,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'max_base')
        assert hasattr(result, 'max_quote')

        # Verify amounts are positive
        assert result.max_base > 0
        assert result.max_quote > 0

        # Calculate expected amounts
        expected_base = (lp_desired * self.base_reserve + self.lp_total_supply - 1) // self.lp_total_supply
        expected_quote = (lp_desired * self.quote_reserve + self.lp_total_supply - 1) // self.lp_total_supply

        # With slippage, max amounts should be higher
        assert result.max_base >= expected_base
        assert result.max_quote >= expected_quote

    def test_deposit_lp_token_initial_liquidity(self):
        """Test initial liquidity deposit"""
        lp_desired = 1_000_000

        result = deposit_lp_token(
            lp_token=lp_desired,
            slippage=self.slippage,
            base_reserve=0,  # Initial deposit
            quote_reserve=0,
            total_lp_supply=0
        )

        # For initial deposit, should estimate equal amounts
        assert result.max_base > 0
        assert result.max_quote > 0

    def test_withdraw_basic(self):
        """Test basic liquidity withdrawal"""
        lp_to_burn = 1_000_000  # 1 LP token

        result = withdraw(
            lp_amount=lp_to_burn,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'base')
        assert hasattr(result, 'quote')
        assert hasattr(result, 'min_base')
        assert hasattr(result, 'min_quote')

        # Verify amounts are positive
        assert result.base > 0
        assert result.quote > 0
        assert result.min_base >= 0
        assert result.min_quote >= 0

        # Verify proportional withdrawal
        expected_base = (lp_to_burn * self.base_reserve) // self.lp_total_supply
        expected_quote = (lp_to_burn * self.quote_reserve) // self.lp_total_supply

        assert result.base == expected_base
        assert result.quote == expected_quote

        # Verify slippage protection
        assert result.min_base < result.base
        assert result.min_quote < result.quote

    def test_withdraw_excessive_amount(self):
        """Test withdrawal with excessive LP amount"""
        excessive_lp = self.lp_total_supply + 1

        with pytest.raises((ValueError, LiquidityError)):
            withdraw(
                lp_amount=excessive_lp,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                total_lp_supply=self.lp_total_supply
            )

    def test_withdraw_zero_supply(self):
        """Test withdrawal with zero LP supply"""
        with pytest.raises((ValueError, LiquidityError)):
            withdraw(
                lp_amount=1000,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                total_lp_supply=0
            )

    def test_deposit_quote_and_lp_from_base(self):
        """Test autocomplete deposit calculation from base input"""
        base_input = 1_000_000

        result = deposit_quote_and_lp_token_from_base(
            base=base_input,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'quote')
        assert hasattr(result, 'lp_token')

        # Verify amounts are positive
        assert result.quote > 0
        assert result.lp_token > 0

        # Should match the full deposit calculation
        full_result = deposit_token0(
            token0=base_input,
            slippage=self.slippage,
            token0_reserve=self.base_reserve,
            token1_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        assert result.quote == full_result.quote
        assert result.lp_token == full_result.lp_token

    def test_deposit_base_and_lp_from_quote(self):
        """Test autocomplete deposit calculation from quote input"""
        quote_input = 2_000_000

        result = deposit_base_and_lp_token_from_quote(
            quote=quote_input,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'base')
        assert hasattr(result, 'lp_token')

        # Verify amounts are positive
        assert result.base > 0
        assert result.lp_token > 0

        # Verify proportionality
        expected_base = (quote_input * self.base_reserve + self.quote_reserve - 1) // self.quote_reserve
        expected_lp = (quote_input * self.lp_total_supply) // self.quote_reserve

        assert result.base == expected_base
        assert result.lp_token == expected_lp

    def test_withdraw_autocomplete(self):
        """Test autocomplete withdrawal calculation"""
        lp_amount = 1_000_000

        result = withdraw_autocomplete_base_and_quote_from_lp_token(
            lp_amount=lp_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Verify result structure
        assert hasattr(result, 'base')
        assert hasattr(result, 'quote')

        # Verify amounts are positive
        assert result.base > 0
        assert result.quote > 0

        # Should match the full withdrawal calculation (without slippage adjustments)
        full_result = withdraw(
            lp_amount=lp_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        assert result.base == full_result.base
        assert result.quote == full_result.quote

    def test_validate_deposit_amounts(self):
        """Test deposit amount validation"""
        base_amount = 1_000_000
        quote_amount = 2_000_000  # Correct 2:1 ratio

        # Valid amounts
        assert validate_deposit_amounts(
            base_amount, quote_amount,
            self.base_reserve, self.quote_reserve
        ) == True

        # Invalid ratio (too much tolerance)
        assert validate_deposit_amounts(
            base_amount, quote_amount * 2,  # Wrong ratio
            self.base_reserve, self.quote_reserve
        ) == False

        # Initial deposit (any ratio is valid)
        assert validate_deposit_amounts(
            base_amount, quote_amount * 10,  # Any ratio
            0, 0  # Initial deposit
        ) == True

    def test_zero_amounts_validation(self):
        """Test validation with zero amounts"""
        with pytest.raises((ValueError, ValidationError)):
            deposit_token0(
                token0=0,
                slippage=self.slippage,
                token0_reserve=self.base_reserve,
                token1_reserve=self.quote_reserve,
                total_lp_supply=self.lp_total_supply
            )

        with pytest.raises((ValueError, ValidationError)):
            withdraw(
                lp_amount=0,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                total_lp_supply=self.lp_total_supply
            )

    def test_high_slippage_tolerance(self):
        """Test operations with high slippage tolerance"""
        base_deposit = 1_000_000
        high_slippage = 5000  # 50%

        result = deposit_token0(
            token0=base_deposit,
            slippage=high_slippage,
            token0_reserve=self.base_reserve,
            token1_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Max amounts should be significantly higher
        base_slippage = result.max_base - base_deposit
        expected_base_slippage = base_deposit * high_slippage // 10000

        assert abs(base_slippage - expected_base_slippage) <= 1

    def test_liquidity_math_consistency(self):
        """Test that deposit and withdrawal are inverse operations"""
        # Deposit some liquidity
        base_deposit = 1_000_000

        deposit_result = deposit_token0(
            token0=base_deposit,
            slippage=0,  # No slippage for exact calculation
            token0_reserve=self.base_reserve,
            token1_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # Calculate new pool state after deposit
        new_base_reserve = self.base_reserve + base_deposit
        new_quote_reserve = self.quote_reserve + deposit_result.quote
        new_lp_supply = self.lp_total_supply + deposit_result.lp_token

        # Now withdraw the same LP tokens
        withdraw_result = withdraw(
            lp_amount=deposit_result.lp_token,
            slippage=0,
            base_reserve=new_base_reserve,
            quote_reserve=new_quote_reserve,
            total_lp_supply=new_lp_supply
        )

        # Should get approximately the same amounts back (within rounding)
        assert abs(withdraw_result.base - base_deposit) <= 1
        assert abs(withdraw_result.quote - deposit_result.quote) <= 1

    def test_large_deposit_impact(self):
        """Test large deposit impact on pool ratios"""
        # Large deposit (10% of pool)
        large_base = self.base_reserve // 10

        result = deposit_token0(
            token0=large_base,
            slippage=1000,  # 10% slippage for large deposit
            token0_reserve=self.base_reserve,
            token1_reserve=self.quote_reserve,
            total_lp_supply=self.lp_total_supply
        )

        # LP tokens should represent appropriate share
        lp_share = result.lp_token / (self.lp_total_supply + result.lp_token)
        deposit_share = large_base / (self.base_reserve + large_base)

        # Shares should be approximately equal (within small tolerance)
        assert abs(lp_share - deposit_share) < 0.001