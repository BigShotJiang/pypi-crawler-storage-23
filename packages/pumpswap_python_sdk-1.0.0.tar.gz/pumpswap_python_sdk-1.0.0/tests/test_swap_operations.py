"""
Test swap operations (buy/sell calculations)
"""

import pytest
from pump_swap_sdk.sdk.swap_operations import (
    buy_base_input, buy_quote_input,
    sell_base_input, sell_quote_input
)
from pump_swap_sdk.types.amm_types import GlobalConfig, FeeConfig
from pump_swap_sdk.exceptions import ValidationError, InsufficientLiquidityError
from solders.pubkey import Pubkey


class TestSwapOperations:
    """Test buy and sell operations"""

    def setup_method(self):
        """Set up test data"""
        self.base_reserve = 1_000_000_000  # 1B base tokens
        self.quote_reserve = 2_000_000_000  # 2B quote tokens (2:1 ratio)
        self.slippage = 100  # 1% slippage

        # Mock global config
        self.global_config = GlobalConfig(
            admin=Pubkey.from_string("11111111111111111111111111111111"),
            fee_recipient=Pubkey.from_string("11111111111111111111111111111111"),
            protocol_fee_rate_bps=5,
            creator_fee_rate_bps=0,
            max_pool_count=1000,
            is_paused=False,
            is_mayhem_mode=False,
            token_incentives_enabled=False,
            daily_token_incentives_amount=0
        )

        # Mock fee config with minimal fees for testing
        self.fee_config = FeeConfig(
            fee_tiers=[],
            default_lp_fee_rate_bps=25,      # 0.25%
            default_protocol_fee_rate_bps=5,  # 0.05%
            default_creator_fee_rate_bps=0    # 0%
        )

    def test_buy_base_input_basic(self):
        """Test basic buy base input calculation"""
        base_amount = 1_000_000  # 1 token

        result = buy_base_input(
            base=base_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Verify result structure
        assert hasattr(result, 'internal_quote_amount')
        assert hasattr(result, 'ui_quote')
        assert hasattr(result, 'max_quote')

        # Verify amounts are positive
        assert result.internal_quote_amount > 0
        assert result.ui_quote > 0
        assert result.max_quote > 0

        # Verify slippage protection
        assert result.max_quote > result.ui_quote

        # UI quote should be higher than internal due to fees
        assert result.ui_quote >= result.internal_quote_amount

    def test_buy_base_input_large_amount(self):
        """Test buy with large amount (high price impact)"""
        # Try to buy 10% of the pool
        large_base_amount = self.base_reserve // 10

        result = buy_base_input(
            base=large_base_amount,
            slippage=1000,  # 10% slippage for large trade
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Should have significant price impact
        effective_price = result.ui_quote / large_base_amount
        market_price = self.quote_reserve / self.base_reserve

        # Price should be higher than market price due to impact
        assert effective_price > market_price

    def test_buy_base_input_insufficient_liquidity(self):
        """Test buy with insufficient liquidity"""
        # Try to buy more than available
        excessive_amount = self.base_reserve

        with pytest.raises((ValueError, InsufficientLiquidityError)):
            buy_base_input(
                base=excessive_amount,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                global_config=self.global_config,
                fee_config=self.fee_config
            )

    def test_buy_quote_input_basic(self):
        """Test basic buy quote input calculation"""
        quote_amount = 1_000_000  # 1 quote token

        result = buy_quote_input(
            quote=quote_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Verify result structure
        assert hasattr(result, 'base')
        assert hasattr(result, 'internal_quote_without_fees')
        assert hasattr(result, 'max_quote')

        # Verify amounts are positive
        assert result.base > 0
        assert result.internal_quote_without_fees > 0
        assert result.max_quote > 0

        # After fees, internal quote should be less than input
        assert result.internal_quote_without_fees < quote_amount

    def test_sell_base_input_basic(self):
        """Test basic sell base input calculation"""
        base_amount = 1_000_000  # 1 token

        result = sell_base_input(
            base=base_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Verify result structure
        assert hasattr(result, 'ui_quote')
        assert hasattr(result, 'min_quote')
        assert hasattr(result, 'internal_quote_amount_out')

        # Verify amounts are positive
        assert result.ui_quote > 0
        assert result.min_quote >= 0
        assert result.internal_quote_amount_out > 0

        # Verify slippage protection
        assert result.min_quote < result.ui_quote

        # UI quote should be less than internal due to fees
        assert result.ui_quote <= result.internal_quote_amount_out

    def test_sell_quote_input_basic(self):
        """Test basic sell quote input calculation"""
        quote_amount = 1_000_000  # 1 quote token

        result = sell_quote_input(
            quote=quote_amount,
            slippage=self.slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Verify result structure
        assert hasattr(result, 'internal_raw_quote')
        assert hasattr(result, 'base')
        assert hasattr(result, 'min_quote')

        # Verify amounts are positive
        assert result.internal_raw_quote > 0
        assert result.base > 0
        assert result.min_quote >= 0

        # Raw quote should be higher than desired quote due to fees
        assert result.internal_raw_quote > quote_amount

    def test_price_consistency(self):
        """Test that buy and sell prices are consistent"""
        base_amount = 1_000_000

        # Buy base tokens
        buy_result = buy_base_input(
            base=base_amount,
            slippage=0,  # No slippage for exact calculation
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Sell the same amount
        sell_result = sell_base_input(
            base=base_amount,
            slippage=0,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Buy price should be higher than sell price (due to fees and slippage)
        buy_price = buy_result.ui_quote / base_amount
        sell_price = sell_result.ui_quote / base_amount

        assert buy_price > sell_price

    def test_zero_amounts(self):
        """Test edge cases with zero amounts"""
        with pytest.raises((ValueError, ValidationError)):
            buy_base_input(
                base=0,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                global_config=self.global_config,
                fee_config=self.fee_config
            )

        with pytest.raises((ValueError, ValidationError)):
            sell_base_input(
                base=0,
                slippage=self.slippage,
                base_reserve=self.base_reserve,
                quote_reserve=self.quote_reserve,
                global_config=self.global_config,
                fee_config=self.fee_config
            )

    def test_high_slippage(self):
        """Test operations with high slippage tolerance"""
        base_amount = 1_000_000
        high_slippage = 5000  # 50% slippage

        result = buy_base_input(
            base=base_amount,
            slippage=high_slippage,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Max quote should be significantly higher with high slippage
        slippage_amount = result.max_quote - result.ui_quote
        expected_slippage = result.ui_quote * high_slippage // 10000

        # Allow some variance due to ceiling division
        assert abs(slippage_amount - expected_slippage) <= 1

    def test_fee_impact(self):
        """Test impact of fees on swap calculations"""
        base_amount = 1_000_000

        # Calculate with default fees
        result_with_fees = buy_base_input(
            base=base_amount,
            slippage=0,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Calculate with zero fees (modify fee config)
        zero_fee_config = FeeConfig(
            fee_tiers=[],
            default_lp_fee_rate_bps=0,
            default_protocol_fee_rate_bps=0,
            default_creator_fee_rate_bps=0
        )

        result_no_fees = buy_base_input(
            base=base_amount,
            slippage=0,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=zero_fee_config
        )

        # With fees should require more quote tokens
        assert result_with_fees.ui_quote > result_no_fees.ui_quote

    def test_constant_product_formula(self):
        """Test that operations follow constant product formula"""
        base_amount = 1_000_000

        # Buy operation should increase quote reserve and decrease base reserve
        buy_result = buy_base_input(
            base=base_amount,
            slippage=0,
            base_reserve=self.base_reserve,
            quote_reserve=self.quote_reserve,
            global_config=self.global_config,
            fee_config=self.fee_config
        )

        # Calculate new reserves after buy (before fees for verification)
        new_base_reserve = self.base_reserve - base_amount
        new_quote_reserve = self.quote_reserve + buy_result.internal_quote_amount

        # Product should be preserved (within rounding tolerance)
        original_product = self.base_reserve * self.quote_reserve
        new_product = new_base_reserve * new_quote_reserve

        # Allow for small variance due to fees and rounding
        variance = abs(new_product - original_product) / original_product
        assert variance < 0.01  # Less than 1% variance