"""
Test utilities and mathematical functions
"""

import pytest
import math
from pump_swap_sdk.sdk.utils import (
    ceil_div, floor_div, fee, apply_slippage,
    pool_market_cap, calculate_swap_price, calculate_inverse_swap_price,
    calculate_lp_tokens_for_deposit, calculate_tokens_for_lp_withdrawal,
    validate_slippage, lamports_to_sol, sol_to_lamports
)
from pump_swap_sdk.exceptions import ValidationError


class TestMathUtils:
    """Test mathematical utility functions"""

    def test_ceil_div(self):
        """Test ceiling division"""
        assert ceil_div(10, 3) == 4
        assert ceil_div(9, 3) == 3
        assert ceil_div(1, 2) == 1
        assert ceil_div(0, 5) == 0

        with pytest.raises(ValueError):
            ceil_div(10, 0)

    def test_floor_div(self):
        """Test floor division"""
        assert floor_div(10, 3) == 3
        assert floor_div(9, 3) == 3
        assert floor_div(1, 2) == 0
        assert floor_div(0, 5) == 0

        with pytest.raises(ValueError):
            floor_div(10, 0)

    def test_fee_calculation(self):
        """Test fee calculation from basis points"""
        # 1% fee (100 bps) on 10000
        assert fee(10000, 100) == 100

        # 0.25% fee (25 bps) on 10000
        assert fee(10000, 25) == 25

        # Edge case: small amount with fee
        assert fee(1, 100) == 1  # Ceiling division ensures at least 1

        # No fee
        assert fee(10000, 0) == 0

    def test_apply_slippage(self):
        """Test slippage application"""
        amount = 10000

        # Maximum amount (adds slippage)
        max_amount = apply_slippage(amount, 100, is_maximum=True)  # 1% slippage
        assert max_amount == 10100

        # Minimum amount (subtracts slippage)
        min_amount = apply_slippage(amount, 100, is_maximum=False)
        assert min_amount == 9900

        # Edge case: zero amount
        assert apply_slippage(0, 100, is_maximum=True) == 0
        assert apply_slippage(0, 100, is_maximum=False) == 0

        # Large slippage
        large_slippage = apply_slippage(100, 9000, is_maximum=False)  # 90% slippage
        assert large_slippage == 10

    def test_pool_market_cap(self):
        """Test market cap calculation"""
        supply = 1000000000  # 1B tokens
        base_reserve = 1000000  # 1M base tokens
        quote_reserve = 2000000  # 2M quote tokens (2:1 ratio)

        market_cap = pool_market_cap(supply, base_reserve, quote_reserve)
        expected = supply * quote_reserve // base_reserve  # 2B
        assert market_cap == expected

        # Edge case: zero base reserve
        assert pool_market_cap(supply, 0, quote_reserve) == 0

    def test_calculate_swap_price(self):
        """Test swap price calculation using constant product formula"""
        reserve_in = 1000000
        reserve_out = 2000000
        amount_in = 100000

        # Without fees
        amount_out = calculate_swap_price(amount_in, reserve_in, reserve_out, 0)
        expected = (reserve_out * amount_in) // (reserve_in + amount_in)
        assert amount_out == expected

        # With 1% fee
        amount_out_with_fee = calculate_swap_price(amount_in, reserve_in, reserve_out, 100)
        assert amount_out_with_fee < amount_out  # Should be less due to fees

        # Edge cases
        with pytest.raises(ValueError):
            calculate_swap_price(amount_in, 0, reserve_out, 0)  # Zero reserve

    def test_calculate_inverse_swap_price(self):
        """Test inverse swap price calculation"""
        reserve_in = 1000000
        reserve_out = 2000000
        amount_out = 100000

        # Without fees
        amount_in = calculate_inverse_swap_price(amount_out, reserve_in, reserve_out, 0)

        # Verify by calculating forward
        calculated_out = calculate_swap_price(amount_in, reserve_in, reserve_out, 0)
        assert abs(calculated_out - amount_out) <= 1  # Allow for rounding

        # With fees
        amount_in_with_fee = calculate_inverse_swap_price(amount_out, reserve_in, reserve_out, 100)
        assert amount_in_with_fee > amount_in  # Should need more input due to fees

        # Edge cases
        with pytest.raises(ValueError):
            calculate_inverse_swap_price(amount_out, 0, reserve_out, 0)

        with pytest.raises(ValueError):
            calculate_inverse_swap_price(reserve_out, reserve_in, reserve_out, 0)  # Insufficient liquidity


class TestLiquidityCalculations:
    """Test liquidity-related calculations"""

    def test_calculate_lp_tokens_for_deposit(self):
        """Test LP token calculation for deposits"""
        token0_amount = 100000
        token1_amount = 200000
        reserve0 = 1000000
        reserve1 = 2000000
        total_lp = 1000000

        # Proportional deposit
        lp_tokens = calculate_lp_tokens_for_deposit(
            token0_amount, token1_amount, reserve0, reserve1, total_lp
        )

        # Should be based on the smaller ratio
        expected_from_token0 = token0_amount * total_lp // reserve0
        expected_from_token1 = token1_amount * total_lp // reserve1
        expected = min(expected_from_token0, expected_from_token1)

        assert lp_tokens == expected

        # Initial deposit (zero LP supply)
        initial_lp = calculate_lp_tokens_for_deposit(
            token0_amount, token1_amount, reserve0, reserve1, 0
        )
        expected_initial = int(math.sqrt(token0_amount * token1_amount))
        assert initial_lp == expected_initial

    def test_calculate_tokens_for_lp_withdrawal(self):
        """Test token calculation for LP withdrawal"""
        lp_amount = 100000
        reserve0 = 1000000
        reserve1 = 2000000
        total_lp = 1000000

        token0, token1 = calculate_tokens_for_lp_withdrawal(
            lp_amount, reserve0, reserve1, total_lp
        )

        expected_token0 = lp_amount * reserve0 // total_lp
        expected_token1 = lp_amount * reserve1 // total_lp

        assert token0 == expected_token0
        assert token1 == expected_token1

        # Edge case: zero LP supply
        zero_token0, zero_token1 = calculate_tokens_for_lp_withdrawal(
            lp_amount, reserve0, reserve1, 0
        )
        assert zero_token0 == 0
        assert zero_token1 == 0


class TestValidation:
    """Test validation functions"""

    def test_validate_slippage(self):
        """Test slippage validation"""
        # Valid slippage
        validate_slippage(100)  # 1%
        validate_slippage(0)    # 0%
        validate_slippage(1000) # 10%

        # Invalid slippage
        with pytest.raises(ValidationError):
            validate_slippage(-1)  # Negative

        with pytest.raises(ValidationError):
            validate_slippage(10001)  # Over 100%


class TestConversions:
    """Test conversion functions"""

    def test_lamports_sol_conversion(self):
        """Test SOL/lamports conversion"""
        # SOL to lamports
        assert sol_to_lamports(1.0) == 1_000_000_000
        assert sol_to_lamports(0.5) == 500_000_000
        assert sol_to_lamports(0.000000001) == 1

        # Lamports to SOL
        assert lamports_to_sol(1_000_000_000) == 1.0
        assert lamports_to_sol(500_000_000) == 0.5
        assert lamports_to_sol(1) == 0.000000001

        # Round trip
        original_sol = 1.23456789
        lamports = sol_to_lamports(original_sol)
        converted_back = lamports_to_sol(lamports)
        assert abs(converted_back - original_sol) < 1e-9