"""
Pytest configuration and fixtures
"""

import pytest
from solders.pubkey import Pubkey
from pump_swap_sdk.types.amm_types import (
    GlobalConfig, FeeConfig, Pool, PoolStatus,
    UserVolumeAccumulator, GlobalVolumeAccumulator
)
from pump_swap_sdk.types.sdk_types import (
    SwapSolanaState, LiquiditySolanaState,
    SwapAccounts, LiquidityAccounts
)


@pytest.fixture
def mock_pubkey():
    """Create a mock pubkey for testing"""
    return Pubkey.from_string("11111111111111111111111111111111")


@pytest.fixture
def global_config(mock_pubkey):
    """Create a mock global config for testing"""
    return GlobalConfig(
        admin=mock_pubkey,
        fee_recipient=mock_pubkey,
        protocol_fee_rate_bps=5,
        creator_fee_rate_bps=0,
        max_pool_count=1000,
        is_paused=False,
        is_mayhem_mode=False,
        token_incentives_enabled=False,
        daily_token_incentives_amount=0
    )


@pytest.fixture
def fee_config():
    """Create a mock fee config for testing"""
    return FeeConfig(
        fee_tiers=[
            FeeConfig.FeeTier(
                market_cap_threshold=0,
                lp_fee_rate_bps=25,
                protocol_fee_rate_bps=5,
                creator_fee_rate_bps=0
            ),
            FeeConfig.FeeTier(
                market_cap_threshold=1_000_000_000,  # 1B market cap
                lp_fee_rate_bps=20,
                protocol_fee_rate_bps=3,
                creator_fee_rate_bps=2
            )
        ],
        default_lp_fee_rate_bps=25,
        default_protocol_fee_rate_bps=5,
        default_creator_fee_rate_bps=0
    )


@pytest.fixture
def pool(mock_pubkey):
    """Create a mock pool for testing"""
    return Pool(
        index=0,
        creator=mock_pubkey,
        base_mint=mock_pubkey,
        quote_mint=mock_pubkey,
        lp_mint=mock_pubkey,
        base_vault=mock_pubkey,
        quote_vault=mock_pubkey,
        base_vault_authority=mock_pubkey,
        quote_vault_authority=mock_pubkey,
        status=PoolStatus.ACTIVE,
        created_at=1640995200,  # 2022-01-01
        updated_at=1640995200,
        total_lp_supply=1_000_000_000,
        coin_creator=mock_pubkey,
        coin_creator_fee_rate_bps=0
    )


@pytest.fixture
def global_volume_accumulator():
    """Create a mock global volume accumulator"""
    return GlobalVolumeAccumulator(
        total_volume=1_000_000_000_000,  # 1T total volume
        total_fees=1_000_000_000,       # 1B total fees
        daily_volume=10_000_000_000,    # 10B daily volume
        daily_fees=10_000_000,          # 10M daily fees
        last_updated_day=19358          # Days since epoch
    )


@pytest.fixture
def user_volume_accumulator(mock_pubkey):
    """Create a mock user volume accumulator"""
    return UserVolumeAccumulator(
        user=mock_pubkey,
        total_volume=100_000_000,      # 100M user volume
        total_fees=1_000_000,          # 1M user fees
        daily_volume=1_000_000,        # 1M daily volume
        daily_fees=10_000,             # 10K daily fees
        last_updated_day=19358,        # Days since epoch
        unclaimed_token_incentives=50_000,  # 50K unclaimed tokens
        last_claim_day=19357           # Last claim yesterday
    )


@pytest.fixture
def swap_accounts(mock_pubkey):
    """Create mock swap accounts"""
    return SwapAccounts(
        user=mock_pubkey,
        pool=mock_pubkey,
        base_mint=mock_pubkey,
        quote_mint=mock_pubkey,
        lp_mint=mock_pubkey,
        base_vault=mock_pubkey,
        quote_vault=mock_pubkey,
        user_base_ata=mock_pubkey,
        user_quote_ata=mock_pubkey,
        base_vault_authority=mock_pubkey,
        quote_vault_authority=mock_pubkey,
        fee_recipient=mock_pubkey
    )


@pytest.fixture
def liquidity_accounts(mock_pubkey):
    """Create mock liquidity accounts"""
    return LiquidityAccounts(
        user=mock_pubkey,
        pool=mock_pubkey,
        base_mint=mock_pubkey,
        quote_mint=mock_pubkey,
        lp_mint=mock_pubkey,
        base_vault=mock_pubkey,
        quote_vault=mock_pubkey,
        user_base_ata=mock_pubkey,
        user_quote_ata=mock_pubkey,
        user_lp_ata=mock_pubkey,
        base_vault_authority=mock_pubkey,
        quote_vault_authority=mock_pubkey
    )


@pytest.fixture
def swap_state(
    global_config, fee_config, pool, global_volume_accumulator,
    user_volume_accumulator, swap_accounts
):
    """Create a complete swap state for testing"""
    return SwapSolanaState(
        global_config=global_config,
        fee_config=fee_config,
        global_volume_accumulator=global_volume_accumulator,
        user_volume_accumulator=user_volume_accumulator,
        pool=pool,
        pool_base_amount=1_000_000_000,  # 1B base tokens
        pool_quote_amount=2_000_000_000,  # 2B quote tokens (2:1 ratio)
        accounts=swap_accounts
    )


@pytest.fixture
def liquidity_state(
    global_config, fee_config, pool, global_volume_accumulator,
    user_volume_accumulator, liquidity_accounts
):
    """Create a complete liquidity state for testing"""
    return LiquiditySolanaState(
        global_config=global_config,
        fee_config=fee_config,
        global_volume_accumulator=global_volume_accumulator,
        user_volume_accumulator=user_volume_accumulator,
        pool=pool,
        pool_base_amount=1_000_000_000,  # 1B base tokens
        pool_quote_amount=2_000_000_000,  # 2B quote tokens
        lp_total_supply=1_000_000_000,   # 1B LP tokens
        accounts=liquidity_accounts
    )


@pytest.fixture
def pool_reserves():
    """Standard pool reserves for testing"""
    return {
        'base_reserve': 1_000_000_000,  # 1B base tokens
        'quote_reserve': 2_000_000_000,  # 2B quote tokens (2:1 ratio)
        'lp_supply': 1_000_000_000      # 1B LP tokens
    }