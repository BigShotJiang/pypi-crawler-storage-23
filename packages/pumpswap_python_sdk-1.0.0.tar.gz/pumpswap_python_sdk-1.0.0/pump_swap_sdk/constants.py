"""
Constants used throughout the PumpSwap SDK
"""

from solders.pubkey import Pubkey
from typing import Final

# Program IDs
PUMP_AMM_PROGRAM_ID: Final[Pubkey] = Pubkey.from_string("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P")
TOKEN_PROGRAM_ID: Final[Pubkey] = Pubkey.from_string("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA")
TOKEN_2022_PROGRAM_ID: Final[Pubkey] = Pubkey.from_string("TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb")
ASSOCIATED_TOKEN_PROGRAM_ID: Final[Pubkey] = Pubkey.from_string("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL")
NATIVE_MINT: Final[Pubkey] = Pubkey.from_string("So11111111111111111111111111111111111111112")

# Pool Constants
POOL_ACCOUNT_NEW_SIZE: Final[int] = 288

# Global PDAs
GLOBAL_CONFIG_SEED: Final[str] = "global_config"
GLOBAL_VOLUME_ACCUMULATOR_SEED: Final[str] = "global_volume_accumulator"
PUMP_AMM_EVENT_AUTHORITY_SEED: Final[str] = "event_authority"

# Fee Configuration
DEFAULT_SLIPPAGE_BPS: Final[int] = 100  # 1%
MAX_SLIPPAGE_BPS: Final[int] = 1000     # 10%
BASIS_POINTS: Final[int] = 10000        # 100%

# Precision
LAMPORTS_PER_SOL: Final[int] = 1_000_000_000
TOKEN_DECIMALS: Final[int] = 6