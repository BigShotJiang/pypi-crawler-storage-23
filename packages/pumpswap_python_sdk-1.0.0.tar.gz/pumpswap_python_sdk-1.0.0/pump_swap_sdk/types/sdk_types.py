"""
SDK-specific type definitions and data classes
"""

from dataclasses import dataclass
from typing import Optional, List, Dict, Any
from solders.pubkey import Pubkey
from solders.account import Account
from solana.rpc.types import TokenAccountOpts


@dataclass
class DepositBaseResult:
    quote: int
    lp_token: int
    max_base: int
    max_quote: int


@dataclass
class DepositQuoteAndLpTokenFromBaseResult:
    quote: int
    lp_token: int


@dataclass
class DepositQuoteResult:
    base: int
    lp_token: int
    max_base: int
    max_quote: int


@dataclass
class DepositBaseAndLpTokenFromQuoteResult:
    base: int
    lp_token: int


@dataclass
class DepositLpTokenResult:
    max_base: int
    max_quote: int


@dataclass
class WithdrawResult:
    base: int
    quote: int
    min_base: int
    min_quote: int


@dataclass
class WithdrawAutocompleteResult:
    base: int
    quote: int


@dataclass
class BuyBaseInputResult:
    internal_quote_amount: int
    ui_quote: int
    max_quote: int


@dataclass
class BuyQuoteInputResult:
    base: int
    internal_quote_without_fees: int
    max_quote: int


@dataclass
class SellBaseInputResult:
    ui_quote: int
    min_quote: int
    internal_quote_amount_out: int


@dataclass
class SellQuoteInputResult:
    internal_raw_quote: int
    base: int
    min_quote: int


@dataclass
class SwapAccounts:
    """Accounts needed for swap operations"""
    user: Pubkey
    pool: Pubkey
    base_mint: Pubkey
    quote_mint: Pubkey
    lp_mint: Pubkey
    base_vault: Pubkey
    quote_vault: Pubkey
    user_base_ata: Pubkey
    user_quote_ata: Pubkey
    base_vault_authority: Pubkey
    quote_vault_authority: Pubkey
    fee_recipient: Pubkey


@dataclass
class LiquidityAccounts:
    """Accounts needed for liquidity operations"""
    user: Pubkey
    pool: Pubkey
    base_mint: Pubkey
    quote_mint: Pubkey
    lp_mint: Pubkey
    base_vault: Pubkey
    quote_vault: Pubkey
    user_base_ata: Pubkey
    user_quote_ata: Pubkey
    user_lp_ata: Pubkey
    base_vault_authority: Pubkey
    quote_vault_authority: Pubkey


@dataclass
class CommonSolanaState:
    """Base state common to all operations"""
    global_config: "GlobalConfig"
    fee_config: "FeeConfig"
    global_volume_accumulator: "GlobalVolumeAccumulator"
    user_volume_accumulator: Optional["UserVolumeAccumulator"] = None


@dataclass
class SwapSolanaState(CommonSolanaState):
    """State for swap operations"""
    pool: "Pool" = None
    pool_base_amount: int = 0
    pool_quote_amount: int = 0
    accounts: SwapAccounts = None


@dataclass
class LiquiditySolanaState(CommonSolanaState):
    """State for liquidity operations"""
    pool: "Pool" = None
    pool_base_amount: int = 0
    pool_quote_amount: int = 0
    lp_total_supply: int = 0
    accounts: LiquidityAccounts = None


@dataclass
class CreatePoolSolanaState(CommonSolanaState):
    """State for pool creation"""
    index: int = 0
    creator: Pubkey = None
    base_mint: Pubkey = None
    quote_mint: Pubkey = None
    pool: Pubkey = None
    lp_mint: Pubkey = None
    base_vault: Pubkey = None
    quote_vault: Pubkey = None
    base_vault_authority: Pubkey = None
    quote_vault_authority: Pubkey = None


@dataclass
class CollectCoinCreatorFeeSolanaState:
    """State for collecting coin creator fees"""
    creator: Pubkey
    coin_creator_vault_ata: Pubkey
    coin_creator_vault_authority: Pubkey
    creator_ata: Pubkey
    mint: Pubkey


@dataclass
class TokenAccount:
    """Represents a token account"""
    address: Pubkey
    mint: Pubkey
    owner: Pubkey
    amount: int
    decimals: int


@dataclass
class MintInfo:
    """Represents mint information"""
    address: Pubkey
    mint_authority: Optional[Pubkey]
    supply: int
    decimals: int
    is_initialized: bool
    freeze_authority: Optional[Pubkey]