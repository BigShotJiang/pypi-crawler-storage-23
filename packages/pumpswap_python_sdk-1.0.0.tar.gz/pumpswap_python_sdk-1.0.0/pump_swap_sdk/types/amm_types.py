"""
AMM-specific type definitions and data classes based on the Anchor program
"""

from dataclasses import dataclass
from typing import Optional, List, Dict
from solders.pubkey import Pubkey
from enum import Enum


class PoolStatus(Enum):
    """Pool status enumeration"""
    ACTIVE = 0
    PAUSED = 1
    DISABLED = 2


@dataclass
class Pool:
    """Pool account structure"""
    # Basic pool info
    index: int
    creator: Pubkey
    base_mint: Pubkey
    quote_mint: Pubkey
    lp_mint: Pubkey

    # Vaults
    base_vault: Pubkey
    quote_vault: Pubkey
    base_vault_authority: Pubkey
    quote_vault_authority: Pubkey

    # Pool state
    status: PoolStatus
    created_at: int
    updated_at: int

    # Reserves and liquidity
    total_lp_supply: int

    # Fee collection
    coin_creator: Optional[Pubkey] = None
    coin_creator_fee_rate_bps: int = 0


@dataclass
class GlobalConfig:
    """Global configuration for the AMM"""
    # Admin settings
    admin: Pubkey
    fee_recipient: Pubkey

    # Protocol settings
    protocol_fee_rate_bps: int
    creator_fee_rate_bps: int
    max_pool_count: int

    # Feature flags
    is_paused: bool
    is_mayhem_mode: bool

    # Token incentives
    token_incentives_enabled: bool
    token_incentives_mint: Optional[Pubkey] = None
    daily_token_incentives_amount: int = 0


@dataclass
class FeeConfig:
    """Fee configuration with market cap tiers"""

    @dataclass
    class FeeTier:
        """Individual fee tier"""
        market_cap_threshold: int
        lp_fee_rate_bps: int
        protocol_fee_rate_bps: int
        creator_fee_rate_bps: int

    fee_tiers: List[FeeTier]
    default_lp_fee_rate_bps: int
    default_protocol_fee_rate_bps: int
    default_creator_fee_rate_bps: int


@dataclass
class GlobalVolumeAccumulator:
    """Global volume tracking"""
    total_volume: int
    total_fees: int
    daily_volume: int
    daily_fees: int
    last_updated_day: int


@dataclass
class UserVolumeAccumulator:
    """User-specific volume tracking"""
    user: Pubkey
    total_volume: int
    total_fees: int
    daily_volume: int
    daily_fees: int
    last_updated_day: int

    # Token incentives tracking
    unclaimed_token_incentives: int
    last_claim_day: int


@dataclass
class ComputeFeesResult:
    """Result of fee calculations"""
    lp_fee_bps: int
    protocol_fee_bps: int
    creator_fee_bps: int
    total_fee_bps: int


@dataclass
class SwapParams:
    """Parameters for swap operations"""
    amount_in: int
    minimum_amount_out: int
    slippage_bps: int


@dataclass
class LiquidityParams:
    """Parameters for liquidity operations"""
    max_base: int
    max_quote: int
    lp_token_amount: int
    slippage_bps: int


@dataclass
class PoolReserves:
    """Pool reserve amounts"""
    base_reserve: int
    quote_reserve: int
    lp_supply: int


@dataclass
class MarketData:
    """Market data for a pool"""
    market_cap: int
    price: float
    volume_24h: int
    fees_24h: int
    tvl: int  # Total Value Locked