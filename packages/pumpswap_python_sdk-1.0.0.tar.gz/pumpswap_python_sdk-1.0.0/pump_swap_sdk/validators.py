"""
Input validation utilities for the PumpSwap SDK
"""

from typing import Optional, Union
from solders.pubkey import Pubkey
from .constants import MAX_SLIPPAGE_BPS, BASIS_POINTS
from .exceptions import ValidationError


def validate_amount(amount: int, name: str = "amount", allow_zero: bool = False) -> None:
    """
    Validate token amount

    Args:
        amount: Amount to validate
        name: Parameter name for error messages
        allow_zero: Whether zero is allowed

    Raises:
        ValidationError: If amount is invalid
    """
    if not isinstance(amount, int):
        raise ValidationError(f"{name} must be an integer")

    if amount < 0:
        raise ValidationError(f"{name} cannot be negative")

    if not allow_zero and amount == 0:
        raise ValidationError(f"{name} must be greater than zero")

    # Check for unreasonably large values (overflow protection)
    max_u64 = 2**64 - 1
    if amount > max_u64:
        raise ValidationError(f"{name} exceeds maximum allowed value")


def validate_slippage(slippage_bps: int) -> None:
    """
    Validate slippage tolerance

    Args:
        slippage_bps: Slippage in basis points

    Raises:
        ValidationError: If slippage is invalid
    """
    validate_amount(slippage_bps, "slippage", allow_zero=True)

    if slippage_bps > MAX_SLIPPAGE_BPS:
        raise ValidationError(f"Slippage ({slippage_bps} bps) exceeds maximum ({MAX_SLIPPAGE_BPS} bps)")


def validate_fee_rate(fee_bps: int, name: str = "fee rate") -> None:
    """
    Validate fee rate in basis points

    Args:
        fee_bps: Fee rate in basis points
        name: Parameter name for error messages

    Raises:
        ValidationError: If fee rate is invalid
    """
    validate_amount(fee_bps, name, allow_zero=True)

    if fee_bps > BASIS_POINTS:
        raise ValidationError(f"{name} ({fee_bps} bps) cannot exceed 100% ({BASIS_POINTS} bps)")


def validate_pubkey(pubkey: Union[str, Pubkey], name: str = "pubkey") -> Pubkey:
    """
    Validate and convert pubkey

    Args:
        pubkey: Pubkey as string or Pubkey object
        name: Parameter name for error messages

    Returns:
        Validated Pubkey object

    Raises:
        ValidationError: If pubkey is invalid
    """
    if isinstance(pubkey, str):
        try:
            return Pubkey.from_string(pubkey)
        except Exception as e:
            raise ValidationError(f"Invalid {name}: {str(e)}")

    if isinstance(pubkey, Pubkey):
        return pubkey

    raise ValidationError(f"{name} must be a string or Pubkey object")


def validate_pool_reserves(base_reserve: int, quote_reserve: int) -> None:
    """
    Validate pool reserves

    Args:
        base_reserve: Base token reserve
        quote_reserve: Quote token reserve

    Raises:
        ValidationError: If reserves are invalid
    """
    validate_amount(base_reserve, "base_reserve")
    validate_amount(quote_reserve, "quote_reserve")

    # Check for minimum liquidity
    min_liquidity = 1000  # Minimum tokens to prevent precision issues
    if base_reserve < min_liquidity:
        raise ValidationError(f"Base reserve ({base_reserve}) below minimum ({min_liquidity})")

    if quote_reserve < min_liquidity:
        raise ValidationError(f"Quote reserve ({quote_reserve}) below minimum ({min_liquidity})")


def validate_lp_supply(lp_supply: int, allow_zero: bool = False) -> None:
    """
    Validate LP token supply

    Args:
        lp_supply: LP token supply
        allow_zero: Whether zero supply is allowed (for initial pools)

    Raises:
        ValidationError: If supply is invalid
    """
    validate_amount(lp_supply, "lp_supply", allow_zero=allow_zero)


def validate_swap_parameters(
    amount_in: int,
    amount_out_min: int,
    slippage_bps: int
) -> None:
    """
    Validate swap parameters

    Args:
        amount_in: Input amount
        amount_out_min: Minimum output amount
        slippage_bps: Slippage tolerance

    Raises:
        ValidationError: If parameters are invalid
    """
    validate_amount(amount_in, "amount_in")
    validate_amount(amount_out_min, "amount_out_min", allow_zero=True)
    validate_slippage(slippage_bps)


def validate_deposit_parameters(
    base_amount: int,
    quote_amount: int,
    lp_amount: int,
    slippage_bps: int
) -> None:
    """
    Validate liquidity deposit parameters

    Args:
        base_amount: Base token amount
        quote_amount: Quote token amount
        lp_amount: Expected LP token amount
        slippage_bps: Slippage tolerance

    Raises:
        ValidationError: If parameters are invalid
    """
    validate_amount(base_amount, "base_amount", allow_zero=True)
    validate_amount(quote_amount, "quote_amount", allow_zero=True)
    validate_amount(lp_amount, "lp_amount")
    validate_slippage(slippage_bps)

    # At least one token amount must be positive
    if base_amount == 0 and quote_amount == 0:
        raise ValidationError("Either base_amount or quote_amount must be positive")


def validate_withdrawal_parameters(
    lp_amount: int,
    min_base: int,
    min_quote: int,
    slippage_bps: int
) -> None:
    """
    Validate liquidity withdrawal parameters

    Args:
        lp_amount: LP token amount to burn
        min_base: Minimum base token amount
        min_quote: Minimum quote token amount
        slippage_bps: Slippage tolerance

    Raises:
        ValidationError: If parameters are invalid
    """
    validate_amount(lp_amount, "lp_amount")
    validate_amount(min_base, "min_base", allow_zero=True)
    validate_amount(min_quote, "min_quote", allow_zero=True)
    validate_slippage(slippage_bps)


def validate_pool_creation_parameters(
    index: int,
    creator: Union[str, Pubkey],
    base_mint: Union[str, Pubkey],
    quote_mint: Union[str, Pubkey],
    initial_base: int,
    initial_quote: int
) -> None:
    """
    Validate pool creation parameters

    Args:
        index: Pool index
        creator: Pool creator address
        base_mint: Base token mint
        quote_mint: Quote token mint
        initial_base: Initial base token amount
        initial_quote: Initial quote token amount

    Raises:
        ValidationError: If parameters are invalid
    """
    validate_amount(index, "index", allow_zero=True)
    validate_pubkey(creator, "creator")
    validate_pubkey(base_mint, "base_mint")
    validate_pubkey(quote_mint, "quote_mint")
    validate_amount(initial_base, "initial_base")
    validate_amount(initial_quote, "initial_quote")

    # Base and quote mints must be different
    base_pubkey = validate_pubkey(base_mint, "base_mint")
    quote_pubkey = validate_pubkey(quote_mint, "quote_mint")

    if base_pubkey == quote_pubkey:
        raise ValidationError("Base mint and quote mint cannot be the same")


def validate_fee_calculation_inputs(
    market_cap: int,
    volume: int,
    fee_rates: dict
) -> None:
    """
    Validate inputs for fee calculation

    Args:
        market_cap: Token market cap
        volume: Trading volume
        fee_rates: Dictionary of fee rates

    Raises:
        ValidationError: If inputs are invalid
    """
    validate_amount(market_cap, "market_cap", allow_zero=True)
    validate_amount(volume, "volume", allow_zero=True)

    required_rates = ["lp_fee_bps", "protocol_fee_bps", "creator_fee_bps"]
    for rate_name in required_rates:
        if rate_name not in fee_rates:
            raise ValidationError(f"Missing required fee rate: {rate_name}")
        validate_fee_rate(fee_rates[rate_name], rate_name)

    # Validate total fee rate
    total_fee_bps = sum(fee_rates[rate] for rate in required_rates)
    if total_fee_bps > BASIS_POINTS:
        raise ValidationError(f"Total fee rates ({total_fee_bps} bps) exceed 100%")


def validate_range(
    value: int,
    min_value: int,
    max_value: int,
    name: str = "value"
) -> None:
    """
    Validate that a value is within a specific range

    Args:
        value: Value to validate
        min_value: Minimum allowed value
        max_value: Maximum allowed value
        name: Parameter name for error messages

    Raises:
        ValidationError: If value is out of range
    """
    if not isinstance(value, int):
        raise ValidationError(f"{name} must be an integer")

    if value < min_value or value > max_value:
        raise ValidationError(f"{name} ({value}) must be between {min_value} and {max_value}")


def validate_percentage(percentage: float, name: str = "percentage") -> None:
    """
    Validate percentage value (0-100)

    Args:
        percentage: Percentage value
        name: Parameter name for error messages

    Raises:
        ValidationError: If percentage is invalid
    """
    if not isinstance(percentage, (int, float)):
        raise ValidationError(f"{name} must be a number")

    if percentage < 0 or percentage > 100:
        raise ValidationError(f"{name} ({percentage}%) must be between 0 and 100")