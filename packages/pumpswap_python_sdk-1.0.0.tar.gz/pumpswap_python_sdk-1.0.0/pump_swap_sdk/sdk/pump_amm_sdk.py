"""
Main PumpAmmSdk class - the high-level SDK interface for offline operations
"""

from typing import Optional, List, Dict, Any
from solders.pubkey import Pubkey
from solders.transaction import Transaction
from solders.instruction import Instruction

from ..types.sdk_types import (
    SwapSolanaState, LiquiditySolanaState, CreatePoolSolanaState,
    BuyBaseInputResult, BuyQuoteInputResult,
    SellBaseInputResult, SellQuoteInputResult,
    DepositBaseResult, DepositQuoteResult, DepositLpTokenResult,
    WithdrawResult, WithdrawAutocompleteResult
)
from ..types.amm_types import Pool, GlobalConfig, FeeConfig, UserVolumeAccumulator
from .swap_operations import buy_base_input, buy_quote_input, sell_base_input, sell_quote_input
from .liquidity_operations import (
    deposit_token0, deposit_lp_token, withdraw,
    withdraw_autocomplete_base_and_quote_from_lp_token,
    deposit_quote_and_lp_token_from_base, deposit_base_and_lp_token_from_quote
)
from .fees import compute_fees_bps
from .utils import pool_market_cap, validate_slippage
from .pda import *


class PumpAmmSdk:
    """
    High-level SDK for PumpSwap AMM operations

    This class provides easy-to-use methods for:
    - Creating pools
    - Performing swaps
    - Managing liquidity
    - Fee calculations

    Suitable for UI integrations and most common use cases.
    """

    def __init__(self, program_id: Optional[Pubkey] = None):
        """
        Initialize the PumpAmmSdk

        Args:
            program_id: Optional custom program ID (defaults to mainnet)
        """
        self.program_id = program_id or PUMP_AMM_PROGRAM_ID

    # Account decoding methods
    def decode_global_config(self, account_data: bytes) -> GlobalConfig:
        """
        Decode global configuration account data

        Args:
            account_data: Raw account data bytes

        Returns:
            GlobalConfig object
        """
        # This would implement the actual Borsh deserialization
        # For now, returning a mock object
        raise NotImplementedError("Account decoding requires Borsh deserialization")

    def decode_fee_config(self, account_data: bytes) -> FeeConfig:
        """
        Decode fee configuration account data

        Args:
            account_data: Raw account data bytes

        Returns:
            FeeConfig object
        """
        raise NotImplementedError("Account decoding requires Borsh deserialization")

    def decode_pool(self, account_data: bytes) -> Pool:
        """
        Decode pool account data

        Args:
            account_data: Raw account data bytes

        Returns:
            Pool object
        """
        raise NotImplementedError("Account decoding requires Borsh deserialization")

    def decode_user_volume_accumulator(self, account_data: bytes) -> UserVolumeAccumulator:
        """
        Decode user volume accumulator account data

        Args:
            account_data: Raw account data bytes

        Returns:
            UserVolumeAccumulator object
        """
        raise NotImplementedError("Account decoding requires Borsh deserialization")

    # Pool creation methods
    def create_pool_instructions(
        self,
        create_pool_state: CreatePoolSolanaState,
        base_in: int,
        quote_in: int
    ) -> List[Instruction]:
        """
        Create instructions for pool creation

        Args:
            create_pool_state: Pool creation state
            base_in: Initial base token amount
            quote_in: Initial quote token amount

        Returns:
            List of transaction instructions
        """
        instructions = []

        # Create pool account instruction
        # This would build the actual Solana instruction
        # For now, returning empty list as placeholder
        raise NotImplementedError("Instruction building requires Solana program integration")

    def create_autocomplete_initial_pool_price(
        self,
        initial_base: int,
        initial_quote: int
    ) -> float:
        """
        Calculate initial pool price for UI display

        Args:
            initial_base: Initial base token amount
            initial_quote: Initial quote token amount

        Returns:
            Initial price (quote per base)
        """
        if initial_base == 0:
            return 0.0
        return initial_quote / initial_base

    # Swap operations
    def buy_base_input(
        self,
        swap_state: SwapSolanaState,
        base: int,
        slippage: int
    ) -> BuyBaseInputResult:
        """
        Calculate quote needed to buy specific base amount

        Args:
            swap_state: Swap state with pool and account information
            base: Desired base token amount
            slippage: Slippage tolerance in basis points

        Returns:
            BuyBaseInputResult with quote amounts
        """
        validate_slippage(slippage)

        return buy_base_input(
            base=base,
            slippage=slippage,
            base_reserve=swap_state.pool_base_amount,
            quote_reserve=swap_state.pool_quote_amount,
            global_config=swap_state.global_config,
            creator=swap_state.pool.creator,
            fee_config=swap_state.fee_config
        )

    def buy_quote_input(
        self,
        swap_state: SwapSolanaState,
        quote: int,
        slippage: int
    ) -> BuyQuoteInputResult:
        """
        Calculate base received for specific quote amount

        Args:
            swap_state: Swap state with pool and account information
            quote: Quote token amount to spend
            slippage: Slippage tolerance in basis points

        Returns:
            BuyQuoteInputResult with base amount
        """
        validate_slippage(slippage)

        return buy_quote_input(
            quote=quote,
            slippage=slippage,
            base_reserve=swap_state.pool_base_amount,
            quote_reserve=swap_state.pool_quote_amount,
            global_config=swap_state.global_config,
            creator=swap_state.pool.creator,
            fee_config=swap_state.fee_config
        )

    def sell_base_input(
        self,
        swap_state: SwapSolanaState,
        base: int,
        slippage: int
    ) -> SellBaseInputResult:
        """
        Calculate quote received for selling base amount

        Args:
            swap_state: Swap state with pool and account information
            base: Base token amount to sell
            slippage: Slippage tolerance in basis points

        Returns:
            SellBaseInputResult with quote amounts
        """
        validate_slippage(slippage)

        return sell_base_input(
            base=base,
            slippage=slippage,
            base_reserve=swap_state.pool_base_amount,
            quote_reserve=swap_state.pool_quote_amount,
            global_config=swap_state.global_config,
            creator=swap_state.pool.creator,
            fee_config=swap_state.fee_config
        )

    def sell_quote_input(
        self,
        swap_state: SwapSolanaState,
        quote: int,
        slippage: int
    ) -> SellQuoteInputResult:
        """
        Calculate base needed to receive specific quote amount

        Args:
            swap_state: Swap state with pool and account information
            quote: Desired quote token amount to receive
            slippage: Slippage tolerance in basis points

        Returns:
            SellQuoteInputResult with base amount
        """
        validate_slippage(slippage)

        return sell_quote_input(
            quote=quote,
            slippage=slippage,
            base_reserve=swap_state.pool_base_amount,
            quote_reserve=swap_state.pool_quote_amount,
            global_config=swap_state.global_config,
            creator=swap_state.pool.creator,
            fee_config=swap_state.fee_config
        )

    # Liquidity operations
    def deposit_instructions(
        self,
        liquidity_state: LiquiditySolanaState,
        lp_token: int,
        slippage: int
    ) -> List[Instruction]:
        """
        Create instructions for liquidity deposit

        Args:
            liquidity_state: Liquidity state with pool and account information
            lp_token: LP token amount to mint
            slippage: Slippage tolerance in basis points

        Returns:
            List of transaction instructions
        """
        validate_slippage(slippage)
        raise NotImplementedError("Instruction building requires Solana program integration")

    def deposit_base_input(
        self,
        liquidity_state: LiquiditySolanaState,
        base: int,
        slippage: int
    ) -> DepositBaseResult:
        """
        Calculate deposit amounts when providing base token

        Args:
            liquidity_state: Liquidity state
            base: Base token amount
            slippage: Slippage tolerance

        Returns:
            DepositBaseResult with quote and LP amounts
        """
        validate_slippage(slippage)

        return deposit_token0(
            token0=base,
            slippage=slippage,
            token0_reserve=liquidity_state.pool_base_amount,
            token1_reserve=liquidity_state.pool_quote_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

    def deposit_quote_input(
        self,
        liquidity_state: LiquiditySolanaState,
        quote: int,
        slippage: int
    ) -> DepositQuoteResult:
        """
        Calculate deposit amounts when providing quote token

        Args:
            liquidity_state: Liquidity state
            quote: Quote token amount
            slippage: Slippage tolerance

        Returns:
            DepositQuoteResult with base and LP amounts
        """
        validate_slippage(slippage)

        # Use the base logic but swap parameters
        result = deposit_token0(
            token0=quote,
            slippage=slippage,
            token0_reserve=liquidity_state.pool_quote_amount,
            token1_reserve=liquidity_state.pool_base_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

        # Convert to DepositQuoteResult format
        return DepositQuoteResult(
            base=result.quote,  # Swapped because we're using quote as input
            lp_token=result.lp_token,
            max_base=result.max_quote,  # Swapped
            max_quote=result.max_base   # Swapped
        )

    def deposit_autocomplete_quote_and_lp_token_from_base(
        self,
        liquidity_state: LiquiditySolanaState,
        base: int,
        slippage: int
    ):
        """
        Autocomplete quote and LP token amounts from base input

        Args:
            liquidity_state: Liquidity state
            base: Base token amount
            slippage: Slippage tolerance

        Returns:
            Quote and LP token amounts
        """
        validate_slippage(slippage)

        return deposit_quote_and_lp_token_from_base(
            base=base,
            slippage=slippage,
            base_reserve=liquidity_state.pool_base_amount,
            quote_reserve=liquidity_state.pool_quote_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

    def deposit_autocomplete_base_and_lp_token_from_quote(
        self,
        liquidity_state: LiquiditySolanaState,
        quote: int,
        slippage: int
    ):
        """
        Autocomplete base and LP token amounts from quote input

        Args:
            liquidity_state: Liquidity state
            quote: Quote token amount
            slippage: Slippage tolerance

        Returns:
            Base and LP token amounts
        """
        validate_slippage(slippage)

        return deposit_base_and_lp_token_from_quote(
            quote=quote,
            slippage=slippage,
            base_reserve=liquidity_state.pool_base_amount,
            quote_reserve=liquidity_state.pool_quote_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

    def withdraw_instructions(
        self,
        liquidity_state: LiquiditySolanaState,
        lp_token: int,
        slippage: int
    ) -> List[Instruction]:
        """
        Create instructions for liquidity withdrawal

        Args:
            liquidity_state: Liquidity state
            lp_token: LP token amount to burn
            slippage: Slippage tolerance

        Returns:
            List of transaction instructions
        """
        validate_slippage(slippage)
        raise NotImplementedError("Instruction building requires Solana program integration")

    def withdraw_inputs(
        self,
        liquidity_state: LiquiditySolanaState,
        lp_amount: int,
        slippage: int
    ) -> WithdrawResult:
        """
        Calculate withdrawal amounts for LP tokens

        Args:
            liquidity_state: Liquidity state
            lp_amount: LP token amount to burn
            slippage: Slippage tolerance

        Returns:
            WithdrawResult with token amounts
        """
        validate_slippage(slippage)

        return withdraw(
            lp_amount=lp_amount,
            slippage=slippage,
            base_reserve=liquidity_state.pool_base_amount,
            quote_reserve=liquidity_state.pool_quote_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

    def withdraw_autocomplete_base_and_quote_from_lp_token(
        self,
        liquidity_state: LiquiditySolanaState,
        lp_amount: int,
        slippage: int
    ) -> WithdrawAutocompleteResult:
        """
        Autocomplete withdrawal amounts

        Args:
            liquidity_state: Liquidity state
            lp_amount: LP token amount
            slippage: Slippage tolerance

        Returns:
            WithdrawAutocompleteResult with base and quote amounts
        """
        validate_slippage(slippage)

        return withdraw_autocomplete_base_and_quote_from_lp_token(
            lp_amount=lp_amount,
            slippage=slippage,
            base_reserve=liquidity_state.pool_base_amount,
            quote_reserve=liquidity_state.pool_quote_amount,
            total_lp_supply=liquidity_state.lp_total_supply
        )

    # Fee calculation methods
    def calculate_fees(
        self,
        global_config: GlobalConfig,
        fee_config: FeeConfig,
        creator: Optional[Pubkey] = None,
        market_cap: int = 0,
        mint: Optional[Pubkey] = None
    ):
        """
        Calculate fee rates for operations

        Args:
            global_config: Global configuration
            fee_config: Fee configuration
            creator: Pool creator
            market_cap: Token market cap
            mint: Token mint

        Returns:
            ComputeFeesResult with fee rates
        """
        return compute_fees_bps(
            global_config=global_config,
            fee_config=fee_config,
            creator=creator,
            market_cap=market_cap,
            mint=mint
        )