"""
Fee calculation utilities for the PumpSwap SDK
"""

from typing import Optional
from solders.pubkey import Pubkey
from ..types.amm_types import FeeConfig, GlobalConfig, ComputeFeesResult
from ..constants import BASIS_POINTS
from .utils import is_pump_pool


def calculate_fee_tier(fee_tiers: list, market_cap: int) -> Optional[FeeConfig.FeeTier]:
    """
    Find the appropriate fee tier based on market cap

    Args:
        fee_tiers: List of fee tiers ordered by market cap threshold
        market_cap: Current market cap

    Returns:
        Matching fee tier or None
    """
    # Tiers should be ordered by threshold (ascending)
    for tier in reversed(fee_tiers):
        if market_cap >= tier.market_cap_threshold:
            return tier
    return None


def compute_fees_bps(
    global_config: GlobalConfig,
    fee_config: FeeConfig,
    creator: Optional[Pubkey] = None,
    market_cap: int = 0,
    mint: Optional[Pubkey] = None
) -> ComputeFeesResult:
    """
    Compute fee rates in basis points for a swap

    Args:
        global_config: Global configuration
        fee_config: Fee configuration with tiers
        creator: Pool creator (for pump pool detection)
        market_cap: Current market cap of the token
        mint: Token mint (for pump pool detection)

    Returns:
        ComputeFeesResult with all fee rates
    """
    # Start with default fees
    lp_fee_bps = fee_config.default_lp_fee_rate_bps
    protocol_fee_bps = fee_config.default_protocol_fee_rate_bps
    creator_fee_bps = fee_config.default_creator_fee_rate_bps

    # Check if mayhem mode is active (higher fees)
    if global_config.is_mayhem_mode:
        # Apply mayhem mode multiplier (example: 2x fees)
        lp_fee_bps *= 2
        protocol_fee_bps *= 2
        creator_fee_bps *= 2

    # Find appropriate fee tier based on market cap
    fee_tier = calculate_fee_tier(fee_config.fee_tiers, market_cap)
    if fee_tier:
        lp_fee_bps = fee_tier.lp_fee_rate_bps
        protocol_fee_bps = fee_tier.protocol_fee_rate_bps
        creator_fee_bps = fee_tier.creator_fee_rate_bps

    # Special handling for pump pools
    if mint and creator and is_pump_pool(mint, creator):
        # Pump pools might have different fee structures
        # This would be implemented based on specific pump.fun requirements
        pass

    # Calculate total fee rate
    total_fee_bps = lp_fee_bps + protocol_fee_bps + creator_fee_bps

    # Ensure total fees don't exceed 100%
    if total_fee_bps > BASIS_POINTS:
        raise ValueError(f"Total fees ({total_fee_bps} bps) exceed 100%")

    return ComputeFeesResult(
        lp_fee_bps=lp_fee_bps,
        protocol_fee_bps=protocol_fee_bps,
        creator_fee_bps=creator_fee_bps,
        total_fee_bps=total_fee_bps
    )


def get_fee_recipient(
    global_config: GlobalConfig,
    pool_creator: Optional[Pubkey] = None
) -> Pubkey:
    """
    Get the fee recipient address

    Args:
        global_config: Global configuration
        pool_creator: Pool creator (unused for now, but could be used for dynamic routing)

    Returns:
        Fee recipient address
    """
    return global_config.fee_recipient


def calculate_swap_fees(
    amount_in: int,
    fees_result: ComputeFeesResult
) -> dict:
    """
    Calculate actual fee amounts for a swap

    Args:
        amount_in: Input amount
        fees_result: Fee rates from compute_fees_bps

    Returns:
        Dictionary with fee amounts
    """
    from .utils import fee

    lp_fee_amount = fee(amount_in, fees_result.lp_fee_bps)
    protocol_fee_amount = fee(amount_in, fees_result.protocol_fee_bps)
    creator_fee_amount = fee(amount_in, fees_result.creator_fee_bps)
    total_fee_amount = lp_fee_amount + protocol_fee_amount + creator_fee_amount

    return {
        "lp_fee_amount": lp_fee_amount,
        "protocol_fee_amount": protocol_fee_amount,
        "creator_fee_amount": creator_fee_amount,
        "total_fee_amount": total_fee_amount,
        "amount_after_fees": amount_in - total_fee_amount
    }


def validate_fee_rates(
    lp_fee_bps: int,
    protocol_fee_bps: int,
    creator_fee_bps: int
) -> None:
    """
    Validate that fee rates are reasonable

    Args:
        lp_fee_bps: LP fee rate in basis points
        protocol_fee_bps: Protocol fee rate in basis points
        creator_fee_bps: Creator fee rate in basis points

    Raises:
        ValueError: If fees are invalid
    """
    # Check individual fee rates
    if lp_fee_bps < 0 or lp_fee_bps > BASIS_POINTS:
        raise ValueError(f"Invalid LP fee rate: {lp_fee_bps} bps")

    if protocol_fee_bps < 0 or protocol_fee_bps > BASIS_POINTS:
        raise ValueError(f"Invalid protocol fee rate: {protocol_fee_bps} bps")

    if creator_fee_bps < 0 or creator_fee_bps > BASIS_POINTS:
        raise ValueError(f"Invalid creator fee rate: {creator_fee_bps} bps")

    # Check total fees
    total_fee_bps = lp_fee_bps + protocol_fee_bps + creator_fee_bps
    if total_fee_bps > BASIS_POINTS:
        raise ValueError(f"Total fees exceed 100%: {total_fee_bps} bps")

    # Reasonable maximum (e.g., 10% total fees)
    max_reasonable_fee = BASIS_POINTS // 10  # 10%
    if total_fee_bps > max_reasonable_fee:
        raise ValueError(f"Total fees too high: {total_fee_bps} bps (max reasonable: {max_reasonable_fee} bps)")