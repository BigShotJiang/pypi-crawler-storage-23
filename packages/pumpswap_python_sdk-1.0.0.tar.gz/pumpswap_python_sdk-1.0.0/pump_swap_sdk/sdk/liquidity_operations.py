"""
Liquidity operation implementations (deposit/withdraw) for the PumpSwap SDK
"""

import math
from typing import Tuple
from ..types.sdk_types import (
    DepositBaseResult, DepositQuoteResult, DepositLpTokenResult,
    DepositBaseAndLpTokenFromQuoteResult, DepositQuoteAndLpTokenFromBaseResult,
    WithdrawResult, WithdrawAutocompleteResult
)
from .utils import (
    ceil_div, floor_div, apply_slippage,
    calculate_lp_tokens_for_deposit, calculate_tokens_for_lp_withdrawal
)


def deposit_token0(
    token0: int,
    slippage: int,
    token0_reserve: int,
    token1_reserve: int,
    total_lp_supply: int
) -> DepositBaseResult:
    """
    Calculate deposit amounts when user provides token0 amount

    Args:
        token0: Amount of token0 to deposit
        slippage: Slippage tolerance in basis points
        token0_reserve: Current token0 reserve
        token1_reserve: Current token1 reserve
        total_lp_supply: Current total LP supply

    Returns:
        DepositBaseResult with calculated amounts
    """
    if token0 <= 0:
        raise ValueError("Token0 amount must be positive")

    if total_lp_supply == 0:
        # Initial liquidity - special case
        # For initial deposit, we can accept any ratio
        # LP tokens = sqrt(token0 * token1) where token1 is provided
        raise ValueError("Use deposit_lp_token for initial liquidity provision")

    if token0_reserve == 0:
        raise ValueError("Invalid token0 reserve")

    # Calculate proportional token1 amount needed
    # token1 = token0 * token1_reserve / token0_reserve
    quote = ceil_div(token0 * token1_reserve, token0_reserve)

    # Calculate LP tokens to be minted
    # lp_tokens = token0 * total_lp_supply / token0_reserve
    lp_token = floor_div(token0 * total_lp_supply, token0_reserve)

    if lp_token == 0:
        raise ValueError("Deposit amount too small")

    # Apply slippage protection
    max_base = apply_slippage(token0, slippage, is_maximum=True)
    max_quote = apply_slippage(quote, slippage, is_maximum=True)

    return DepositBaseResult(
        quote=quote,
        lp_token=lp_token,
        max_base=max_base,
        max_quote=max_quote
    )


def deposit_quote_and_lp_token_from_base(
    base: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    total_lp_supply: int
) -> DepositQuoteAndLpTokenFromBaseResult:
    """
    Calculate quote amount and LP tokens when user provides base amount

    Args:
        base: Base token amount to deposit
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        total_lp_supply: Current total LP supply

    Returns:
        DepositQuoteAndLpTokenFromBaseResult
    """
    if base <= 0:
        raise ValueError("Base amount must be positive")

    if total_lp_supply == 0 or base_reserve == 0:
        raise ValueError("Pool not initialized")

    # Calculate proportional quote amount needed
    quote = ceil_div(base * quote_reserve, base_reserve)

    # Calculate LP tokens to be minted
    lp_token = floor_div(base * total_lp_supply, base_reserve)

    if lp_token == 0:
        raise ValueError("Deposit amount too small")

    return DepositQuoteAndLpTokenFromBaseResult(
        quote=quote,
        lp_token=lp_token
    )


def deposit_base_and_lp_token_from_quote(
    quote: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    total_lp_supply: int
) -> DepositBaseAndLpTokenFromQuoteResult:
    """
    Calculate base amount and LP tokens when user provides quote amount

    Args:
        quote: Quote token amount to deposit
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        total_lp_supply: Current total LP supply

    Returns:
        DepositBaseAndLpTokenFromQuoteResult
    """
    if quote <= 0:
        raise ValueError("Quote amount must be positive")

    if total_lp_supply == 0 or quote_reserve == 0:
        raise ValueError("Pool not initialized")

    # Calculate proportional base amount needed
    base = ceil_div(quote * base_reserve, quote_reserve)

    # Calculate LP tokens to be minted
    lp_token = floor_div(quote * total_lp_supply, quote_reserve)

    if lp_token == 0:
        raise ValueError("Deposit amount too small")

    return DepositBaseAndLpTokenFromQuoteResult(
        base=base,
        lp_token=lp_token
    )


def deposit_lp_token(
    lp_token: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    total_lp_supply: int
) -> DepositLpTokenResult:
    """
    Calculate token amounts needed for a specific LP token amount

    Args:
        lp_token: Desired LP token amount
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        total_lp_supply: Current total LP supply

    Returns:
        DepositLpTokenResult with maximum token amounts needed
    """
    if lp_token <= 0:
        raise ValueError("LP token amount must be positive")

    if total_lp_supply == 0:
        # Initial liquidity case
        # For initial deposit, we use the geometric mean
        # lp_token = sqrt(base_amount * quote_amount)
        # This means base_amount * quote_amount = lp_token^2
        # We need to determine the ratio, but for now return equal amounts
        estimated_base = int(math.sqrt(lp_token))
        estimated_quote = int(math.sqrt(lp_token))

        max_base = apply_slippage(estimated_base, slippage, is_maximum=True)
        max_quote = apply_slippage(estimated_quote, slippage, is_maximum=True)

        return DepositLpTokenResult(
            max_base=max_base,
            max_quote=max_quote
        )

    # Calculate required token amounts proportionally
    # base_amount = lp_token * base_reserve / total_lp_supply
    max_base_needed = ceil_div(lp_token * base_reserve, total_lp_supply)
    max_quote_needed = ceil_div(lp_token * quote_reserve, total_lp_supply)

    # Apply slippage protection
    max_base = apply_slippage(max_base_needed, slippage, is_maximum=True)
    max_quote = apply_slippage(max_quote_needed, slippage, is_maximum=True)

    return DepositLpTokenResult(
        max_base=max_base,
        max_quote=max_quote
    )


def withdraw(
    lp_amount: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    total_lp_supply: int
) -> WithdrawResult:
    """
    Calculate token amounts received when withdrawing LP tokens

    Args:
        lp_amount: LP token amount to withdraw
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        total_lp_supply: Current total LP supply

    Returns:
        WithdrawResult with token amounts and slippage protection
    """
    if lp_amount <= 0:
        raise ValueError("LP amount must be positive")

    if lp_amount > total_lp_supply:
        raise ValueError("LP amount exceeds total supply")

    if total_lp_supply == 0:
        raise ValueError("No liquidity to withdraw")

    # Calculate proportional token amounts
    base, quote = calculate_tokens_for_lp_withdrawal(
        lp_amount, base_reserve, quote_reserve, total_lp_supply
    )

    if base == 0 and quote == 0:
        raise ValueError("Withdrawal amount too small")

    # Apply slippage protection for minimum amounts
    min_base = apply_slippage(base, slippage, is_maximum=False)
    min_quote = apply_slippage(quote, slippage, is_maximum=False)

    return WithdrawResult(
        base=base,
        quote=quote,
        min_base=min_base,
        min_quote=min_quote
    )


def withdraw_autocomplete_base_and_quote_from_lp_token(
    lp_amount: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    total_lp_supply: int
) -> WithdrawAutocompleteResult:
    """
    Simple autocomplete calculation for withdrawal amounts

    Args:
        lp_amount: LP token amount to withdraw
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        total_lp_supply: Current total LP supply

    Returns:
        WithdrawAutocompleteResult with base and quote amounts
    """
    if lp_amount <= 0:
        raise ValueError("LP amount must be positive")

    if total_lp_supply == 0:
        return WithdrawAutocompleteResult(base=0, quote=0)

    # Calculate proportional amounts without slippage
    base, quote = calculate_tokens_for_lp_withdrawal(
        lp_amount, base_reserve, quote_reserve, total_lp_supply
    )

    return WithdrawAutocompleteResult(
        base=base,
        quote=quote
    )


def validate_deposit_amounts(
    base_amount: int,
    quote_amount: int,
    base_reserve: int,
    quote_reserve: int,
    tolerance_bps: int = 100  # 1% tolerance
) -> bool:
    """
    Validate that deposit amounts maintain proper pool ratio

    Args:
        base_amount: Base token amount to deposit
        quote_amount: Quote token amount to deposit
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        tolerance_bps: Allowed deviation in basis points

    Returns:
        True if amounts are within tolerance
    """
    if base_reserve == 0 or quote_reserve == 0:
        # Initial deposit - any ratio is acceptable
        return True

    # Calculate expected ratio
    expected_ratio = quote_reserve * 10000 // base_reserve  # Scale up for precision
    actual_ratio = quote_amount * 10000 // base_amount

    # Check if within tolerance
    deviation = abs(actual_ratio - expected_ratio)
    max_deviation = expected_ratio * tolerance_bps // 10000

    return deviation <= max_deviation