"""
Program Derived Address (PDA) utilities for the PumpSwap SDK
"""

from typing import Tuple
from solders.pubkey import Pubkey
from ..constants import (
    PUMP_AMM_PROGRAM_ID,
    GLOBAL_CONFIG_SEED,
    GLOBAL_VOLUME_ACCUMULATOR_SEED,
    PUMP_AMM_EVENT_AUTHORITY_SEED,
    ASSOCIATED_TOKEN_PROGRAM_ID,
    TOKEN_PROGRAM_ID
)


def find_pda(seeds: list, program_id: Pubkey) -> Tuple[Pubkey, int]:
    """
    Find a Program Derived Address

    Args:
        seeds: List of seed bytes
        program_id: Program ID

    Returns:
        Tuple of (PDA, bump)
    """
    return Pubkey.find_program_address(seeds, program_id)


def global_config_pda() -> Tuple[Pubkey, int]:
    """
    Get the global config PDA

    Returns:
        Tuple of (PDA, bump)
    """
    return find_pda([GLOBAL_CONFIG_SEED.encode()], PUMP_AMM_PROGRAM_ID)


def global_volume_accumulator_pda() -> Tuple[Pubkey, int]:
    """
    Get the global volume accumulator PDA

    Returns:
        Tuple of (PDA, bump)
    """
    return find_pda([GLOBAL_VOLUME_ACCUMULATOR_SEED.encode()], PUMP_AMM_PROGRAM_ID)


def pump_amm_event_authority_pda() -> Tuple[Pubkey, int]:
    """
    Get the pump AMM event authority PDA

    Returns:
        Tuple of (PDA, bump)
    """
    return find_pda([PUMP_AMM_EVENT_AUTHORITY_SEED.encode()], PUMP_AMM_PROGRAM_ID)


def pool_pda(index: int, owner: Pubkey, base_mint: Pubkey, quote_mint: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the pool PDA

    Args:
        index: Pool index
        owner: Pool owner
        base_mint: Base token mint
        quote_mint: Quote token mint

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [
        b"pool",
        index.to_bytes(8, byteorder='little'),
        bytes(owner),
        bytes(base_mint),
        bytes(quote_mint)
    ]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def lp_mint_pda(pool: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the LP mint PDA

    Args:
        pool: Pool address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"lp_mint", bytes(pool)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def base_vault_pda(pool: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the base vault PDA

    Args:
        pool: Pool address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"base_vault", bytes(pool)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def quote_vault_pda(pool: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the quote vault PDA

    Args:
        pool: Pool address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"quote_vault", bytes(pool)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def base_vault_authority_pda(pool: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the base vault authority PDA

    Args:
        pool: Pool address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"base_vault_authority", bytes(pool)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def quote_vault_authority_pda(pool: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the quote vault authority PDA

    Args:
        pool: Pool address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"quote_vault_authority", bytes(pool)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def user_volume_accumulator_pda(user: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the user volume accumulator PDA

    Args:
        user: User address

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"user_volume_accumulator", bytes(user)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def coin_creator_vault_ata_pda(creator: Pubkey, mint: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the coin creator vault associated token account PDA

    Args:
        creator: Creator address
        mint: Token mint

    Returns:
        Tuple of (PDA, bump)
    """
    # This is an associated token account
    return get_associated_token_address(creator, mint), 0


def coin_creator_vault_authority_pda(creator: Pubkey, mint: Pubkey) -> Tuple[Pubkey, int]:
    """
    Get the coin creator vault authority PDA

    Args:
        creator: Creator address
        mint: Token mint

    Returns:
        Tuple of (PDA, bump)
    """
    seeds = [b"coin_creator_vault_authority", bytes(creator), bytes(mint)]
    return find_pda(seeds, PUMP_AMM_PROGRAM_ID)


def get_associated_token_address(owner: Pubkey, mint: Pubkey) -> Pubkey:
    """
    Get the associated token account address

    Args:
        owner: Token account owner
        mint: Token mint

    Returns:
        Associated token account address
    """
    seeds = [bytes(owner), bytes(TOKEN_PROGRAM_ID), bytes(mint)]
    pda, _ = find_pda(seeds, ASSOCIATED_TOKEN_PROGRAM_ID)
    return pda


def fee_config_pda() -> Tuple[Pubkey, int]:
    """
    Get the fee config PDA

    Returns:
        Tuple of (PDA, bump)
    """
    return find_pda([b"fee_config"], PUMP_AMM_PROGRAM_ID)


def token_incentives_pda() -> Tuple[Pubkey, int]:
    """
    Get the token incentives PDA

    Returns:
        Tuple of (PDA, bump)
    """
    return find_pda([b"token_incentives"], PUMP_AMM_PROGRAM_ID)