"""
Swap operation implementations (buy/sell) for the PumpSwap SDK
"""

from typing import Dict, Any
from ..types.sdk_types import (
    BuyBaseInputResult, BuyQuoteInputResult,
    SellBaseInputResult, SellQuoteInputResult
)
from ..types.amm_types import PoolReserves, GlobalConfig, ComputeFeesResult
from .utils import (
    ceil_div, floor_div, fee, apply_slippage,
    calculate_swap_price, calculate_inverse_swap_price
)
from .fees import compute_fees_bps, calculate_swap_fees


def buy_base_input(
    base: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    global_config: GlobalConfig,
    creator=None,
    fee_config=None,
    market_cap: int = 0
) -> BuyBaseInputResult:
    """
    Calculate quote amount needed to buy a specific base amount

    Uses the constant product formula: quote_in = ceil_div(quote_reserve * base, base_reserve - base)

    Args:
        base: Desired base token amount to buy
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        global_config: Global configuration
        creator: Pool creator (for fee calculation)
        fee_config: Fee configuration
        market_cap: Token market cap (for fee tier calculation)

    Returns:
        BuyBaseInputResult with quote amounts and slippage protection
    """
    if base >= base_reserve:
        raise ValueError("Insufficient base token liquidity")

    if base <= 0:
        raise ValueError("Base amount must be positive")

    # Calculate fees
    fees_result = compute_fees_bps(
        global_config=global_config,
        fee_config=fee_config or _default_fee_config(),
        creator=creator,
        market_cap=market_cap
    )

    # Calculate quote amount needed using constant product formula
    # x * y = k, where x is base reserve, y is quote reserve
    # When buying base tokens: new_base = base_reserve - base
    # new_quote * new_base = k = quote_reserve * base_reserve
    # new_quote = (quote_reserve * base_reserve) / (base_reserve - base)
    # quote_in = new_quote - quote_reserve
    numerator = quote_reserve * base
    denominator = base_reserve - base
    internal_quote_amount = ceil_div(numerator, denominator)

    # Calculate fees on the quote input
    fee_amounts = calculate_swap_fees(internal_quote_amount, fees_result)

    # Total quote needed including fees
    ui_quote = internal_quote_amount + fee_amounts["total_fee_amount"]

    # Apply slippage protection for maximum quote
    max_quote = apply_slippage(ui_quote, slippage, is_maximum=True)

    return BuyBaseInputResult(
        internal_quote_amount=internal_quote_amount,
        ui_quote=ui_quote,
        max_quote=max_quote
    )


def buy_quote_input(
    quote: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    global_config: GlobalConfig,
    creator=None,
    fee_config=None,
    market_cap: int = 0
) -> BuyQuoteInputResult:
    """
    Calculate base amount received when spending a specific quote amount

    Args:
        quote: Quote token amount to spend
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        global_config: Global configuration
        creator: Pool creator (for fee calculation)
        fee_config: Fee configuration
        market_cap: Token market cap (for fee tier calculation)

    Returns:
        BuyQuoteInputResult with base amount and fee details
    """
    if quote <= 0:
        raise ValueError("Quote amount must be positive")

    # Calculate fees
    fees_result = compute_fees_bps(
        global_config=global_config,
        fee_config=fee_config or _default_fee_config(),
        creator=creator,
        market_cap=market_cap
    )

    # Calculate fee amounts
    fee_amounts = calculate_swap_fees(quote, fees_result)
    internal_quote_without_fees = fee_amounts["amount_after_fees"]

    if internal_quote_without_fees <= 0:
        raise ValueError("Quote amount too small after fees")

    # Calculate base amount using constant product formula
    # base_out = (base_reserve * internal_quote_without_fees) / (quote_reserve + internal_quote_without_fees)
    numerator = base_reserve * internal_quote_without_fees
    denominator = quote_reserve + internal_quote_without_fees
    base = floor_div(numerator, denominator)

    if base <= 0:
        raise ValueError("Insufficient output amount")

    # Apply slippage protection for maximum quote (in case of price movement)
    max_quote = apply_slippage(quote, slippage, is_maximum=True)

    return BuyQuoteInputResult(
        base=base,
        internal_quote_without_fees=internal_quote_without_fees,
        max_quote=max_quote
    )


def sell_base_input(
    base: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    global_config: GlobalConfig,
    creator=None,
    fee_config=None,
    market_cap: int = 0
) -> SellBaseInputResult:
    """
    Calculate quote amount received when selling a specific base amount

    Uses the constant product formula: quote_out = (quote_reserve * base) / (base_reserve + base)

    Args:
        base: Base token amount to sell
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        global_config: Global configuration
        creator: Pool creator (for fee calculation)
        fee_config: Fee configuration
        market_cap: Token market cap (for fee tier calculation)

    Returns:
        SellBaseInputResult with quote amounts and slippage protection
    """
    if base <= 0:
        raise ValueError("Base amount must be positive")

    # Calculate fees
    fees_result = compute_fees_bps(
        global_config=global_config,
        fee_config=fee_config or _default_fee_config(),
        creator=creator,
        market_cap=market_cap
    )

    # Calculate quote output using constant product formula
    # x * y = k, where x is base reserve, y is quote reserve
    # When selling base tokens: new_base = base_reserve + base
    # new_quote * new_base = k = quote_reserve * base_reserve
    # new_quote = (quote_reserve * base_reserve) / (base_reserve + base)
    # quote_out = quote_reserve - new_quote
    numerator = quote_reserve * base
    denominator = base_reserve + base
    internal_quote_amount_out = floor_div(numerator, denominator)

    # Calculate fees on the quote output
    fee_amounts = calculate_swap_fees(internal_quote_amount_out, fees_result)

    # Quote amount user receives after fees
    ui_quote = internal_quote_amount_out - fee_amounts["total_fee_amount"]

    if ui_quote <= 0:
        raise ValueError("Output amount too small after fees")

    # Apply slippage protection for minimum quote
    min_quote = apply_slippage(ui_quote, slippage, is_maximum=False)

    return SellBaseInputResult(
        ui_quote=ui_quote,
        min_quote=min_quote,
        internal_quote_amount_out=internal_quote_amount_out
    )


def sell_quote_input(
    quote: int,
    slippage: int,
    base_reserve: int,
    quote_reserve: int,
    global_config: GlobalConfig,
    creator=None,
    fee_config=None,
    market_cap: int = 0
) -> SellQuoteInputResult:
    """
    Calculate base amount needed to sell to receive a specific quote amount

    Args:
        quote: Desired quote token amount to receive
        slippage: Slippage tolerance in basis points
        base_reserve: Current base token reserve
        quote_reserve: Current quote token reserve
        global_config: Global configuration
        creator: Pool creator (for fee calculation)
        fee_config: Fee configuration
        market_cap: Token market cap (for fee tier calculation)

    Returns:
        SellQuoteInputResult with base amount and fee details
    """
    if quote <= 0:
        raise ValueError("Quote amount must be positive")

    # Calculate fees
    fees_result = compute_fees_bps(
        global_config=global_config,
        fee_config=fee_config or _default_fee_config(),
        creator=creator,
        market_cap=market_cap
    )

    # We need to find the raw quote amount before fees that would give us the desired quote after fees
    # Let raw_quote = quote amount before fees
    # quote_after_fees = raw_quote - fees
    # quote = raw_quote * (1 - total_fee_rate)
    # raw_quote = quote / (1 - total_fee_rate)

    total_fee_rate = fees_result.total_fee_bps / 10000  # Convert to decimal
    if total_fee_rate >= 1.0:
        raise ValueError("Fee rate too high")

    # Calculate raw quote needed before fees
    internal_raw_quote = ceil_div(quote * 10000, 10000 - fees_result.total_fee_bps)

    if internal_raw_quote >= quote_reserve:
        raise ValueError("Insufficient quote token liquidity")

    # Calculate base amount needed using inverse constant product formula
    # base_in = (base_reserve * internal_raw_quote) / (quote_reserve - internal_raw_quote)
    numerator = base_reserve * internal_raw_quote
    denominator = quote_reserve - internal_raw_quote

    if denominator <= 0:
        raise ValueError("Insufficient liquidity for desired quote amount")

    base = ceil_div(numerator, denominator)

    if base <= 0:
        raise ValueError("Invalid base amount calculated")

    # Apply slippage protection for minimum quote
    min_quote = apply_slippage(quote, slippage, is_maximum=False)

    return SellQuoteInputResult(
        internal_raw_quote=internal_raw_quote,
        base=base,
        min_quote=min_quote
    )


def _default_fee_config():
    """Create a default fee configuration for testing"""
    from ..types.amm_types import FeeConfig

    return FeeConfig(
        fee_tiers=[],
        default_lp_fee_rate_bps=25,      # 0.25%
        default_protocol_fee_rate_bps=5,  # 0.05%
        default_creator_fee_rate_bps=0    # 0%
    )