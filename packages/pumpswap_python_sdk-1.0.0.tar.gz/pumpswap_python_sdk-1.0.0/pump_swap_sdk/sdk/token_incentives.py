"""
Token incentives functionality for the PumpSwap SDK
"""

from typing import Optional
from solders.pubkey import Pubkey
from ..types.amm_types import UserVolumeAccumulator, GlobalVolumeAccumulator


def total_unclaimed_tokens(user_volume_accumulator: UserVolumeAccumulator) -> int:
    """
    Calculate total unclaimed token incentives for a user

    Args:
        user_volume_accumulator: User's volume accumulator data

    Returns:
        Total unclaimed token amount
    """
    return user_volume_accumulator.unclaimed_token_incentives


def current_day_tokens(
    user_volume_accumulator: UserVolumeAccumulator,
    global_volume_accumulator: GlobalVolumeAccumulator,
    daily_incentives_pool: int,
    current_day: int
) -> int:
    """
    Calculate token incentives earned for the current day

    Args:
        user_volume_accumulator: User's volume accumulator data
        global_volume_accumulator: Global volume accumulator data
        daily_incentives_pool: Total daily incentives available
        current_day: Current day identifier

    Returns:
        Token incentives earned today
    """
    # Check if user has any volume today
    if (user_volume_accumulator.last_updated_day != current_day or
        user_volume_accumulator.daily_volume == 0):
        return 0

    # Check if global volume exists
    if (global_volume_accumulator.last_updated_day != current_day or
        global_volume_accumulator.daily_volume == 0):
        return 0

    # Calculate user's share of daily incentives
    # Formula: user_daily_volume / global_daily_volume * daily_incentives_pool
    user_share = (user_volume_accumulator.daily_volume * daily_incentives_pool) // global_volume_accumulator.daily_volume

    return user_share


def calculate_volume_based_incentives(
    user_volume: int,
    total_volume: int,
    incentive_pool: int,
    minimum_volume_threshold: int = 0
) -> int:
    """
    Calculate incentives based on volume proportion

    Args:
        user_volume: User's trading volume
        total_volume: Total trading volume
        incentive_pool: Total incentives to distribute
        minimum_volume_threshold: Minimum volume required to earn incentives

    Returns:
        User's share of incentives
    """
    if user_volume < minimum_volume_threshold:
        return 0

    if total_volume == 0:
        return 0

    # Proportional distribution
    return (user_volume * incentive_pool) // total_volume


def calculate_fee_based_incentives(
    user_fees_paid: int,
    total_fees_collected: int,
    incentive_pool: int
) -> int:
    """
    Calculate incentives based on fees paid proportion

    Args:
        user_fees_paid: Fees paid by user
        total_fees_collected: Total fees collected
        incentive_pool: Total incentives to distribute

    Returns:
        User's share of incentives
    """
    if total_fees_collected == 0:
        return 0

    return (user_fees_paid * incentive_pool) // total_fees_collected


def calculate_time_weighted_incentives(
    user_volume: int,
    days_active: int,
    base_incentive: int,
    time_multiplier: float = 1.1
) -> int:
    """
    Calculate incentives with time weighting for consistent users

    Args:
        user_volume: User's trading volume
        days_active: Number of consecutive active days
        base_incentive: Base incentive amount
        time_multiplier: Multiplier per active day

    Returns:
        Time-weighted incentive amount
    """
    if user_volume == 0 or days_active == 0:
        return 0

    # Apply time multiplier (capped at reasonable maximum)
    max_multiplier = 3.0  # 3x maximum
    effective_multiplier = min(time_multiplier ** (days_active - 1), max_multiplier)

    return int(base_incentive * effective_multiplier)


def get_current_day() -> int:
    """
    Get current day identifier (days since epoch)

    Returns:
        Current day as integer
    """
    import time
    return int(time.time()) // (24 * 60 * 60)  # Days since Unix epoch


def is_eligible_for_incentives(
    user_volume_accumulator: UserVolumeAccumulator,
    minimum_volume: int = 0,
    minimum_fees: int = 0
) -> bool:
    """
    Check if user is eligible for token incentives

    Args:
        user_volume_accumulator: User's volume data
        minimum_volume: Minimum volume requirement
        minimum_fees: Minimum fees requirement

    Returns:
        True if eligible for incentives
    """
    return (user_volume_accumulator.daily_volume >= minimum_volume and
            user_volume_accumulator.daily_fees >= minimum_fees)


def estimate_daily_incentives(
    projected_volume: int,
    estimated_total_volume: int,
    daily_incentive_pool: int
) -> int:
    """
    Estimate daily incentives based on projected trading volume

    Args:
        projected_volume: User's projected daily volume
        estimated_total_volume: Estimated total daily volume
        daily_incentive_pool: Total daily incentives available

    Returns:
        Estimated daily incentive amount
    """
    if estimated_total_volume == 0:
        return 0

    return (projected_volume * daily_incentive_pool) // estimated_total_volume


def calculate_claimable_amount(
    user_volume_accumulator: UserVolumeAccumulator,
    current_day: int
) -> int:
    """
    Calculate total claimable token amount for a user

    Args:
        user_volume_accumulator: User's volume accumulator
        current_day: Current day identifier

    Returns:
        Total claimable token amount
    """
    base_claimable = user_volume_accumulator.unclaimed_token_incentives

    # If user has activity today and hasn't claimed today's rewards yet
    if (user_volume_accumulator.last_updated_day == current_day and
        user_volume_accumulator.last_claim_day < current_day):
        # Add today's estimated rewards
        # This would need global data to calculate precisely
        # For now, return base amount
        pass

    return base_claimable


def update_user_volume_accumulator(
    user_volume_accumulator: UserVolumeAccumulator,
    volume_increase: int,
    fees_increase: int,
    current_day: int
) -> UserVolumeAccumulator:
    """
    Update user volume accumulator with new trading activity

    Args:
        user_volume_accumulator: Current user volume data
        volume_increase: Additional volume to add
        fees_increase: Additional fees to add
        current_day: Current day identifier

    Returns:
        Updated user volume accumulator
    """
    # Create a copy to avoid mutating the original
    updated = UserVolumeAccumulator(
        user=user_volume_accumulator.user,
        total_volume=user_volume_accumulator.total_volume + volume_increase,
        total_fees=user_volume_accumulator.total_fees + fees_increase,
        daily_volume=user_volume_accumulator.daily_volume,
        daily_fees=user_volume_accumulator.daily_fees,
        last_updated_day=current_day,
        unclaimed_token_incentives=user_volume_accumulator.unclaimed_token_incentives,
        last_claim_day=user_volume_accumulator.last_claim_day
    )

    # Reset daily counters if it's a new day
    if user_volume_accumulator.last_updated_day != current_day:
        updated.daily_volume = volume_increase
        updated.daily_fees = fees_increase
    else:
        updated.daily_volume += volume_increase
        updated.daily_fees += fees_increase

    return updated