"""
OnlinePumpAmmSdk class - SDK with blockchain connection for live data
"""

from typing import Optional, Dict, Any
from solders.pubkey import Pubkey
from solana.rpc.async_api import AsyncClient
from solana.rpc.api import Client
from solana.rpc.types import TokenAccountOpts

from ..types.sdk_types import (
    SwapSolanaState, LiquiditySolanaState, CreatePoolSolanaState,
    CollectCoinCreatorFeeSolanaState, CommonSolanaState,
    SwapAccounts, LiquidityAccounts
)
from ..types.amm_types import Pool, GlobalConfig, FeeConfig, GlobalVolumeAccumulator, UserVolumeAccumulator
from .pump_amm_sdk import PumpAmmSdk
from .pda import *
from .token_incentives import total_unclaimed_tokens, current_day_tokens, get_current_day


class OnlinePumpAmmSdk(PumpAmmSdk):
    """
    Online SDK with blockchain connectivity for fetching live data

    This class extends PumpAmmSdk with methods that fetch data from the blockchain,
    making it suitable for applications that need real-time pool data.
    """

    def __init__(
        self,
        connection: Optional[Client] = None,
        async_connection: Optional[AsyncClient] = None,
        program_id: Optional[Pubkey] = None
    ):
        """
        Initialize the OnlinePumpAmmSdk

        Args:
            connection: Solana RPC client for synchronous operations
            async_connection: Async Solana RPC client
            program_id: Optional custom program ID
        """
        super().__init__(program_id)
        self.connection = connection
        self.async_connection = async_connection

        if not connection and not async_connection:
            # Default to mainnet connection
            self.connection = Client("https://api.mainnet-beta.solana.com")

    # Account fetching methods
    def fetch_global_config_account(self) -> GlobalConfig:
        """
        Fetch global configuration from the blockchain

        Returns:
            GlobalConfig object
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        global_config_pda_address, _ = global_config_pda()
        account_info = self.connection.get_account_info(global_config_pda_address)

        if not account_info.value:
            raise ValueError("Global config account not found")

        return self.decode_global_config(account_info.value.data)

    def fetch_fee_config_account(self) -> FeeConfig:
        """
        Fetch fee configuration from the blockchain

        Returns:
            FeeConfig object
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        fee_config_pda_address, _ = fee_config_pda()
        account_info = self.connection.get_account_info(fee_config_pda_address)

        if not account_info.value:
            raise ValueError("Fee config account not found")

        return self.decode_fee_config(account_info.value.data)

    def fetch_pool(self, pool_address: Pubkey) -> Pool:
        """
        Fetch pool data from the blockchain

        Args:
            pool_address: Pool account address

        Returns:
            Pool object
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        account_info = self.connection.get_account_info(pool_address)

        if not account_info.value:
            raise ValueError(f"Pool account not found: {pool_address}")

        return self.decode_pool(account_info.value.data)

    def fetch_global_volume_accumulator(self) -> GlobalVolumeAccumulator:
        """
        Fetch global volume accumulator from the blockchain

        Returns:
            GlobalVolumeAccumulator object
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        global_volume_pda_address, _ = global_volume_accumulator_pda()
        account_info = self.connection.get_account_info(global_volume_pda_address)

        if not account_info.value:
            raise ValueError("Global volume accumulator account not found")

        # Would decode the account data here
        raise NotImplementedError("Account decoding requires Borsh deserialization")

    def fetch_user_volume_accumulator(self, user: Pubkey) -> Optional[UserVolumeAccumulator]:
        """
        Fetch user volume accumulator from the blockchain

        Args:
            user: User address

        Returns:
            UserVolumeAccumulator object or None if doesn't exist
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        user_volume_pda_address, _ = user_volume_accumulator_pda(user)
        account_info = self.connection.get_account_info(user_volume_pda_address)

        if not account_info.value:
            return None

        return self.decode_user_volume_accumulator(account_info.value.data)

    def fetch_token_account_balance(self, token_account: Pubkey) -> int:
        """
        Fetch token account balance

        Args:
            token_account: Token account address

        Returns:
            Token balance
        """
        if not self.connection:
            raise ValueError("Connection required for online operations")

        account_info = self.connection.get_token_account_balance(token_account)
        return int(account_info.value.amount)

    # State building methods
    def create_pool_solana_state(
        self,
        index: int,
        creator: Pubkey,
        base_mint: Pubkey,
        quote_mint: Pubkey
    ) -> CreatePoolSolanaState:
        """
        Build state for pool creation

        Args:
            index: Pool index
            creator: Pool creator
            base_mint: Base token mint
            quote_mint: Quote token mint

        Returns:
            CreatePoolSolanaState
        """
        # Fetch common state
        global_config = self.fetch_global_config_account()
        fee_config = self.fetch_fee_config_account()
        global_volume = self.fetch_global_volume_accumulator()

        # Generate PDAs
        pool_address, _ = pool_pda(index, creator, base_mint, quote_mint)
        lp_mint_address, _ = lp_mint_pda(pool_address)
        base_vault_address, _ = base_vault_pda(pool_address)
        quote_vault_address, _ = quote_vault_pda(pool_address)
        base_vault_authority_address, _ = base_vault_authority_pda(pool_address)
        quote_vault_authority_address, _ = quote_vault_authority_pda(pool_address)

        return CreatePoolSolanaState(
            global_config=global_config,
            fee_config=fee_config,
            global_volume_accumulator=global_volume,
            index=index,
            creator=creator,
            base_mint=base_mint,
            quote_mint=quote_mint,
            pool=pool_address,
            lp_mint=lp_mint_address,
            base_vault=base_vault_address,
            quote_vault=quote_vault_address,
            base_vault_authority=base_vault_authority_address,
            quote_vault_authority=quote_vault_authority_address
        )

    def swap_solana_state(self, pool_address: Pubkey, user: Pubkey) -> SwapSolanaState:
        """
        Build state for swap operations

        Args:
            pool_address: Pool address
            user: User address

        Returns:
            SwapSolanaState
        """
        # Fetch pool and common data
        pool = self.fetch_pool(pool_address)
        global_config = self.fetch_global_config_account()
        fee_config = self.fetch_fee_config_account()
        global_volume = self.fetch_global_volume_accumulator()
        user_volume = self.fetch_user_volume_accumulator(user)

        # Get vault balances
        pool_base_amount = self.fetch_token_account_balance(pool.base_vault)
        pool_quote_amount = self.fetch_token_account_balance(pool.quote_vault)

        # Build accounts
        user_base_ata = get_associated_token_address(user, pool.base_mint)
        user_quote_ata = get_associated_token_address(user, pool.quote_mint)

        accounts = SwapAccounts(
            user=user,
            pool=pool_address,
            base_mint=pool.base_mint,
            quote_mint=pool.quote_mint,
            lp_mint=pool.lp_mint,
            base_vault=pool.base_vault,
            quote_vault=pool.quote_vault,
            user_base_ata=user_base_ata,
            user_quote_ata=user_quote_ata,
            base_vault_authority=pool.base_vault_authority,
            quote_vault_authority=pool.quote_vault_authority,
            fee_recipient=global_config.fee_recipient
        )

        return SwapSolanaState(
            global_config=global_config,
            fee_config=fee_config,
            global_volume_accumulator=global_volume,
            user_volume_accumulator=user_volume,
            pool=pool,
            pool_base_amount=pool_base_amount,
            pool_quote_amount=pool_quote_amount,
            accounts=accounts
        )

    def liquidity_solana_state(self, pool_address: Pubkey, user: Pubkey) -> LiquiditySolanaState:
        """
        Build state for liquidity operations

        Args:
            pool_address: Pool address
            user: User address

        Returns:
            LiquiditySolanaState
        """
        # Fetch pool and common data
        pool = self.fetch_pool(pool_address)
        global_config = self.fetch_global_config_account()
        fee_config = self.fetch_fee_config_account()
        global_volume = self.fetch_global_volume_accumulator()
        user_volume = self.fetch_user_volume_accumulator(user)

        # Get vault balances and LP supply
        pool_base_amount = self.fetch_token_account_balance(pool.base_vault)
        pool_quote_amount = self.fetch_token_account_balance(pool.quote_vault)

        # Get LP token total supply
        lp_mint_info = self.connection.get_token_supply(pool.lp_mint)
        lp_total_supply = int(lp_mint_info.value.amount)

        # Build accounts
        user_base_ata = get_associated_token_address(user, pool.base_mint)
        user_quote_ata = get_associated_token_address(user, pool.quote_mint)
        user_lp_ata = get_associated_token_address(user, pool.lp_mint)

        accounts = LiquidityAccounts(
            user=user,
            pool=pool_address,
            base_mint=pool.base_mint,
            quote_mint=pool.quote_mint,
            lp_mint=pool.lp_mint,
            base_vault=pool.base_vault,
            quote_vault=pool.quote_vault,
            user_base_ata=user_base_ata,
            user_quote_ata=user_quote_ata,
            user_lp_ata=user_lp_ata,
            base_vault_authority=pool.base_vault_authority,
            quote_vault_authority=pool.quote_vault_authority
        )

        return LiquiditySolanaState(
            global_config=global_config,
            fee_config=fee_config,
            global_volume_accumulator=global_volume,
            user_volume_accumulator=user_volume,
            pool=pool,
            pool_base_amount=pool_base_amount,
            pool_quote_amount=pool_quote_amount,
            lp_total_supply=lp_total_supply,
            accounts=accounts
        )

    def collect_coin_creator_fee_solana_state(self, creator: Pubkey) -> CollectCoinCreatorFeeSolanaState:
        """
        Build state for collecting coin creator fees

        Args:
            creator: Creator address

        Returns:
            CollectCoinCreatorFeeSolanaState
        """
        # This would need mint information to build the state properly
        raise NotImplementedError("Need mint information to build creator fee state")

    # Token incentives methods
    def get_total_unclaimed_tokens(self, user: Pubkey) -> int:
        """
        Get total unclaimed token incentives for a user

        Args:
            user: User address

        Returns:
            Total unclaimed token amount
        """
        user_volume = self.fetch_user_volume_accumulator(user)
        if not user_volume:
            return 0

        return total_unclaimed_tokens(user_volume)

    def get_current_day_tokens(self, user: Pubkey) -> int:
        """
        Get current day token incentives for a user

        Args:
            user: User address

        Returns:
            Current day token amount
        """
        user_volume = self.fetch_user_volume_accumulator(user)
        if not user_volume:
            return 0

        global_volume = self.fetch_global_volume_accumulator()
        global_config = self.fetch_global_config_account()

        return current_day_tokens(
            user_volume_accumulator=user_volume,
            global_volume_accumulator=global_volume,
            daily_incentives_pool=global_config.daily_token_incentives_amount,
            current_day=get_current_day()
        )

    def get_coin_creator_vault_balance(self, creator: Pubkey, mint: Pubkey) -> int:
        """
        Get coin creator vault balance

        Args:
            creator: Creator address
            mint: Token mint

        Returns:
            Vault balance
        """
        vault_address, _ = coin_creator_vault_ata_pda(creator, mint)
        return self.fetch_token_account_balance(vault_address)

    # Pool utility methods
    def get_pool_market_cap(self, pool_address: Pubkey) -> int:
        """
        Get current market cap for a pool

        Args:
            pool_address: Pool address

        Returns:
            Market cap in lamports
        """
        pool = self.fetch_pool(pool_address)
        base_reserve = self.fetch_token_account_balance(pool.base_vault)
        quote_reserve = self.fetch_token_account_balance(pool.quote_vault)

        # Get token supply
        base_mint_info = self.connection.get_token_supply(pool.base_mint)
        supply = int(base_mint_info.value.amount)

        from .utils import pool_market_cap
        return pool_market_cap(supply, base_reserve, quote_reserve)

    def get_pool_reserves(self, pool_address: Pubkey) -> Dict[str, int]:
        """
        Get current pool reserves

        Args:
            pool_address: Pool address

        Returns:
            Dictionary with reserve amounts
        """
        pool = self.fetch_pool(pool_address)
        base_reserve = self.fetch_token_account_balance(pool.base_vault)
        quote_reserve = self.fetch_token_account_balance(pool.quote_vault)

        return {
            "base_reserve": base_reserve,
            "quote_reserve": quote_reserve
        }