"""
Custom exceptions for the PumpSwap SDK
"""


class PumpSwapSDKError(Exception):
    """Base exception class for PumpSwap SDK errors"""
    pass


class ValidationError(PumpSwapSDKError):
    """Raised when input validation fails"""
    pass


class InsufficientLiquidityError(PumpSwapSDKError):
    """Raised when there's insufficient liquidity for an operation"""
    pass


class SlippageExceededError(PumpSwapSDKError):
    """Raised when slippage tolerance is exceeded"""
    pass


class InvalidPoolError(PumpSwapSDKError):
    """Raised when pool data is invalid or corrupted"""
    pass


class AccountNotFoundError(PumpSwapSDKError):
    """Raised when a required account is not found on-chain"""
    pass


class UnauthorizedError(PumpSwapSDKError):
    """Raised when user lacks required permissions"""
    pass


class ConfigurationError(PumpSwapSDKError):
    """Raised when SDK configuration is invalid"""
    pass


class FeeCalculationError(PumpSwapSDKError):
    """Raised when fee calculation fails"""
    pass


class NetworkError(PumpSwapSDKError):
    """Raised when network operations fail"""
    pass


class SerializationError(PumpSwapSDKError):
    """Raised when data serialization/deserialization fails"""
    pass


class InstructionBuildError(PumpSwapSDKError):
    """Raised when instruction building fails"""
    pass


class TokenAccountError(PumpSwapSDKError):
    """Raised when token account operations fail"""
    pass


class PoolCreationError(PumpSwapSDKError):
    """Raised when pool creation fails"""
    pass


class SwapError(PumpSwapSDKError):
    """Raised when swap operations fail"""
    pass


class LiquidityError(PumpSwapSDKError):
    """Raised when liquidity operations fail"""
    pass