"""
Liquidity Management Example

This example demonstrates how to add and remove liquidity from pools.
"""

import asyncio
from solana.rpc.api import Client
from solders.pubkey import Pubkey
from pump_swap_sdk import OnlinePumpAmmSdk
from pump_swap_sdk.exceptions import ValidationError, LiquidityError


async def liquidity_management_example():
    """
    Example of managing liquidity in a pool
    """
    # Initialize connection and SDK
    connection = Client("https://api.mainnet-beta.solana.com")
    sdk = OnlinePumpAmmSdk(connection=connection)

    # Pool and user addresses (replace with actual addresses)
    pool_address = Pubkey.from_string("POOL_ADDRESS_HERE")
    user_address = Pubkey.from_string("USER_ADDRESS_HERE")

    try:
        # Get liquidity state
        print("Fetching liquidity state...")
        liquidity_state = sdk.liquidity_solana_state(pool_address, user_address)

        # Display pool information
        print(f"Pool: {pool_address}")
        print(f"Base Reserve: {liquidity_state.pool_base_amount:,}")
        print(f"Quote Reserve: {liquidity_state.pool_quote_amount:,}")
        print(f"LP Total Supply: {liquidity_state.lp_total_supply:,}")

        # Calculate current pool ratio
        if liquidity_state.pool_base_amount > 0:
            pool_ratio = liquidity_state.pool_quote_amount / liquidity_state.pool_base_amount
            print(f"Pool Ratio: {pool_ratio:.6f} quote per base token")

        # Example 1: Add liquidity by specifying base amount
        print("\n=== Add Liquidity (Base Input) ===")
        base_deposit = 1_000_000  # 1 base token
        slippage = 100  # 1% slippage

        deposit_base_result = sdk.deposit_base_input(
            liquidity_state=liquidity_state,
            base=base_deposit,
            slippage=slippage
        )

        print(f"Base tokens to deposit: {base_deposit:,}")
        print(f"Quote tokens needed: {deposit_base_result.quote:,}")
        print(f"LP tokens to receive: {deposit_base_result.lp_token:,}")
        print(f"Max base with slippage: {deposit_base_result.max_base:,}")
        print(f"Max quote with slippage: {deposit_base_result.max_quote:,}")

        # Calculate LP token share
        if liquidity_state.lp_total_supply > 0:
            lp_share = (deposit_base_result.lp_token /
                       (liquidity_state.lp_total_supply + deposit_base_result.lp_token)) * 100
            print(f"Your pool share after deposit: {lp_share:.4f}%")

        # Example 2: Add liquidity by specifying quote amount
        print("\n=== Add Liquidity (Quote Input) ===")
        quote_deposit = 50_000_000  # 50 quote tokens

        deposit_quote_result = sdk.deposit_quote_input(
            liquidity_state=liquidity_state,
            quote=quote_deposit,
            slippage=slippage
        )

        print(f"Quote tokens to deposit: {quote_deposit:,}")
        print(f"Base tokens needed: {deposit_quote_result.base:,}")
        print(f"LP tokens to receive: {deposit_quote_result.lp_token:,}")

        # Example 3: Autocomplete calculations
        print("\n=== Autocomplete Calculations ===")

        # From base amount, calculate quote and LP
        autocomplete_base = 2_000_000  # 2 base tokens
        auto_result = sdk.deposit_autocomplete_quote_and_lp_token_from_base(
            liquidity_state=liquidity_state,
            base=autocomplete_base,
            slippage=slippage
        )

        print(f"Base input: {autocomplete_base:,}")
        print(f"Quote needed: {auto_result.quote:,}")
        print(f"LP tokens: {auto_result.lp_token:,}")

        # From quote amount, calculate base and LP
        autocomplete_quote = 100_000_000  # 100 quote tokens
        auto_quote_result = sdk.deposit_autocomplete_base_and_lp_token_from_quote(
            liquidity_state=liquidity_state,
            quote=autocomplete_quote,
            slippage=slippage
        )

        print(f"Quote input: {autocomplete_quote:,}")
        print(f"Base needed: {auto_quote_result.base:,}")
        print(f"LP tokens: {auto_quote_result.lp_token:,}")

        # Example 4: Remove liquidity
        print("\n=== Remove Liquidity ===")

        # Simulate having LP tokens
        lp_to_withdraw = 500_000  # 0.5 LP tokens

        withdraw_result = sdk.withdraw_inputs(
            liquidity_state=liquidity_state,
            lp_amount=lp_to_withdraw,
            slippage=slippage
        )

        print(f"LP tokens to burn: {lp_to_withdraw:,}")
        print(f"Base tokens to receive: {withdraw_result.base:,}")
        print(f"Quote tokens to receive: {withdraw_result.quote:,}")
        print(f"Min base with slippage: {withdraw_result.min_base:,}")
        print(f"Min quote with slippage: {withdraw_result.min_quote:,}")

        # Calculate withdrawal share
        if liquidity_state.lp_total_supply > 0:
            withdrawal_share = (lp_to_withdraw / liquidity_state.lp_total_supply) * 100
            print(f"Pool share being withdrawn: {withdrawal_share:.4f}%")

        # Example 5: Autocomplete withdrawal
        print("\n=== Autocomplete Withdrawal ===")

        autocomplete_withdraw = sdk.withdraw_autocomplete_base_and_quote_from_lp_token(
            liquidity_state=liquidity_state,
            lp_amount=lp_to_withdraw,
            slippage=slippage
        )

        print(f"LP tokens: {lp_to_withdraw:,}")
        print(f"Base to receive: {autocomplete_withdraw.base:,}")
        print(f"Quote to receive: {autocomplete_withdraw.quote:,}")

    except ValidationError as e:
        print(f"Validation Error: {e}")
    except LiquidityError as e:
        print(f"Liquidity Error: {e}")
    except Exception as e:
        print(f"Error: {e}")


def calculate_liquidity_metrics(sdk: OnlinePumpAmmSdk, liquidity_state) -> dict:
    """
    Calculate various liquidity pool metrics
    """
    metrics = {}

    # Total Value Locked (TVL) - assuming quote token is the reference
    metrics['tvl_quote_tokens'] = liquidity_state.pool_quote_amount * 2  # Both sides in quote terms

    # Pool utilization (how much of the pool would be affected by a large trade)
    large_trade = liquidity_state.pool_base_amount // 10  # 10% of base reserve
    try:
        impact_result = sdk.buy_base_input(liquidity_state, large_trade, 0)
        price_before = liquidity_state.pool_quote_amount / liquidity_state.pool_base_amount
        price_after = impact_result.internal_quote_amount / large_trade
        price_impact = ((price_after - price_before) / price_before) * 100
        metrics['price_impact_10pct'] = price_impact
    except:
        metrics['price_impact_10pct'] = None

    # LP token value in terms of underlying assets
    if liquidity_state.lp_total_supply > 0:
        lp_value_base = liquidity_state.pool_base_amount / liquidity_state.lp_total_supply
        lp_value_quote = liquidity_state.pool_quote_amount / liquidity_state.lp_total_supply
        metrics['lp_token_value'] = {
            'base_per_lp': lp_value_base,
            'quote_per_lp': lp_value_quote
        }

    return metrics


def simulate_liquidity_scenarios():
    """
    Simulate different liquidity scenarios
    """
    connection = Client("https://api.mainnet-beta.solana.com")
    sdk = OnlinePumpAmmSdk(connection=connection)

    # Replace with actual addresses
    pool_address = Pubkey.from_string("POOL_ADDRESS_HERE")
    user_address = Pubkey.from_string("USER_ADDRESS_HERE")

    try:
        liquidity_state = sdk.liquidity_solana_state(pool_address, user_address)

        print("=== Liquidity Scenarios ===")

        # Scenario 1: Small deposit
        small_deposit = 100_000  # 0.1 base token
        small_result = sdk.deposit_base_input(liquidity_state, small_deposit, 100)
        print(f"Small deposit ({small_deposit:,} base):")
        print(f"  Quote needed: {small_result.quote:,}")
        print(f"  LP tokens: {small_result.lp_token:,}")

        # Scenario 2: Large deposit
        large_deposit = 10_000_000  # 10 base tokens
        try:
            large_result = sdk.deposit_base_input(liquidity_state, large_deposit, 100)
            print(f"Large deposit ({large_deposit:,} base):")
            print(f"  Quote needed: {large_result.quote:,}")
            print(f"  LP tokens: {large_result.lp_token:,}")
        except Exception as e:
            print(f"Large deposit failed: {e}")

        # Calculate metrics
        metrics = calculate_liquidity_metrics(sdk, liquidity_state)
        print(f"\n=== Pool Metrics ===")
        print(f"TVL (in quote tokens): {metrics.get('tvl_quote_tokens', 'N/A'):,}")
        if metrics.get('price_impact_10pct'):
            print(f"10% trade price impact: {metrics['price_impact_10pct']:.2f}%")

        if metrics.get('lp_token_value'):
            lp_val = metrics['lp_token_value']
            print(f"LP token value: {lp_val['base_per_lp']:.6f} base + {lp_val['quote_per_lp']:.6f} quote")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    print("PumpSwap SDK - Liquidity Management Example")
    print("=" * 50)

    # Run liquidity management example
    asyncio.run(liquidity_management_example())

    print("\n" + "=" * 50)
    print("Liquidity Scenarios")
    print("=" * 50)

    # Run scenario simulations
    simulate_liquidity_scenarios()