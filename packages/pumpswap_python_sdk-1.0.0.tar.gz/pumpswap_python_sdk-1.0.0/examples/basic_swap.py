"""
Basic Swap Example

This example demonstrates how to perform a simple token swap using the PumpSwap SDK.
"""

import asyncio
from solana.rpc.api import Client
from solders.pubkey import Pubkey
from pump_swap_sdk import OnlinePumpAmmSdk
from pump_swap_sdk.exceptions import InsufficientLiquidityError, SlippageExceededError


async def basic_swap_example():
    """
    Example of performing a basic token swap
    """
    # Initialize connection and SDK
    connection = Client("https://api.mainnet-beta.solana.com")
    sdk = OnlinePumpAmmSdk(connection=connection)

    # Pool and user addresses (replace with actual addresses)
    pool_address = Pubkey.from_string("POOL_ADDRESS_HERE")
    user_address = Pubkey.from_string("USER_ADDRESS_HERE")

    try:
        # Get swap state
        print("Fetching swap state...")
        swap_state = sdk.swap_solana_state(pool_address, user_address)

        # Display pool information
        print(f"Pool: {pool_address}")
        print(f"Base Reserve: {swap_state.pool_base_amount:,}")
        print(f"Quote Reserve: {swap_state.pool_quote_amount:,}")

        # Calculate current price
        if swap_state.pool_base_amount > 0:
            price = swap_state.pool_quote_amount / swap_state.pool_base_amount
            print(f"Current Price: {price:.6f} quote per base token")

        # Example 1: Buy 1 base token (calculate quote needed)
        print("\n=== Buy 1 Base Token ===")
        base_amount = 1_000_000  # 1 token with 6 decimals
        slippage = 100  # 1% slippage

        buy_result = sdk.buy_base_input(
            swap_state=swap_state,
            base=base_amount,
            slippage=slippage
        )

        print(f"Base tokens to buy: {base_amount:,}")
        print(f"Quote tokens needed: {buy_result.ui_quote:,}")
        print(f"Max quote with slippage: {buy_result.max_quote:,}")
        print(f"Effective price: {buy_result.ui_quote / base_amount:.6f}")

        # Example 2: Spend 100 quote tokens (calculate base received)
        print("\n=== Spend 100 Quote Tokens ===")
        quote_amount = 100_000_000  # 100 tokens with 6 decimals

        buy_quote_result = sdk.buy_quote_input(
            swap_state=swap_state,
            quote=quote_amount,
            slippage=slippage
        )

        print(f"Quote tokens to spend: {quote_amount:,}")
        print(f"Base tokens to receive: {buy_quote_result.base:,}")
        print(f"Max quote with slippage: {buy_quote_result.max_quote:,}")
        print(f"Effective price: {quote_amount / buy_quote_result.base:.6f}")

        # Example 3: Sell 0.5 base tokens
        print("\n=== Sell 0.5 Base Tokens ===")
        sell_amount = 500_000  # 0.5 tokens with 6 decimals

        sell_result = sdk.sell_base_input(
            swap_state=swap_state,
            base=sell_amount,
            slippage=slippage
        )

        print(f"Base tokens to sell: {sell_amount:,}")
        print(f"Quote tokens to receive: {sell_result.ui_quote:,}")
        print(f"Min quote with slippage: {sell_result.min_quote:,}")
        print(f"Effective price: {sell_result.ui_quote / sell_amount:.6f}")

        # Example 4: Calculate fees
        print("\n=== Fee Information ===")
        fees = sdk.calculate_fees(
            global_config=swap_state.global_config,
            fee_config=swap_state.fee_config,
            creator=swap_state.pool.creator,
            market_cap=sdk.get_pool_market_cap(pool_address)
        )

        print(f"LP Fee: {fees.lp_fee_bps} bps ({fees.lp_fee_bps/100:.2f}%)")
        print(f"Protocol Fee: {fees.protocol_fee_bps} bps ({fees.protocol_fee_bps/100:.2f}%)")
        print(f"Creator Fee: {fees.creator_fee_bps} bps ({fees.creator_fee_bps/100:.2f}%)")
        print(f"Total Fee: {fees.total_fee_bps} bps ({fees.total_fee_bps/100:.2f}%)")

    except InsufficientLiquidityError:
        print("Error: Insufficient liquidity for this trade size")
    except SlippageExceededError:
        print("Error: Price movement exceeded slippage tolerance")
    except Exception as e:
        print(f"Error: {e}")


def calculate_price_impact(
    sdk: OnlinePumpAmmSdk,
    swap_state,
    base_amount: int
) -> float:
    """
    Calculate price impact for a trade
    """
    # Current price
    current_price = swap_state.pool_quote_amount / swap_state.pool_base_amount

    # Price after trade
    result = sdk.buy_base_input(swap_state, base_amount, 0)  # 0 slippage for exact calculation
    effective_price = result.internal_quote_amount / base_amount

    # Price impact percentage
    price_impact = ((effective_price - current_price) / current_price) * 100
    return price_impact


def simulate_trades():
    """
    Simulate various trade sizes and show price impact
    """
    connection = Client("https://api.mainnet-beta.solana.com")
    sdk = OnlinePumpAmmSdk(connection=connection)

    # Replace with actual addresses
    pool_address = Pubkey.from_string("POOL_ADDRESS_HERE")
    user_address = Pubkey.from_string("USER_ADDRESS_HERE")

    try:
        swap_state = sdk.swap_solana_state(pool_address, user_address)

        print("=== Price Impact Analysis ===")
        trade_sizes = [100_000, 500_000, 1_000_000, 5_000_000, 10_000_000]  # Various sizes

        for size in trade_sizes:
            try:
                impact = calculate_price_impact(sdk, swap_state, size)
                result = sdk.buy_base_input(swap_state, size, 100)

                print(f"Trade Size: {size:,} base tokens")
                print(f"Price Impact: {impact:.2f}%")
                print(f"Quote Needed: {result.ui_quote:,}")
                print(f"---")
            except Exception as e:
                print(f"Trade Size: {size:,} - Error: {e}")

    except Exception as e:
        print(f"Error: {e}")


if __name__ == "__main__":
    print("PumpSwap SDK - Basic Swap Example")
    print("=" * 40)

    # Run basic swap example
    asyncio.run(basic_swap_example())

    print("\n" + "=" * 40)
    print("Price Impact Simulation")
    print("=" * 40)

    # Run price impact simulation
    simulate_trades()