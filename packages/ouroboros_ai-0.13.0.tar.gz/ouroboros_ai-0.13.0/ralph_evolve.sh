#!/bin/bash
# ralph_evolve.sh — Ralph loop driver for Ouroboros evolutionary cycles
#
# Usage:
#   ./ralph_evolve.sh <lineage_id> [seed.yaml]
#
# Ralph DoD = "evolutionary loop converged"
#
# Cycle 1: evolve_step(lineage_id, seed) → Gen 1 → action
# Cycle N: evolve_step(lineage_id)       → Gen N → action
# Stops when action ≠ continue
#
# Exit codes (from ralph_evolve.py):
#   0  = converged
#   10 = continue
#   20 = stagnated
#   30 = exhausted
#   1  = failed

set -uo pipefail

LINEAGE_ID="${1:?Usage: $0 <lineage_id> [seed.yaml]}"
SEED_FILE="${2:-}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON_SCRIPT="${SCRIPT_DIR}/ralph_evolve.py"

MAX_GENERATIONS=30
generation=0

echo "==========================================="
echo "  Ralph x Ouroboros Evolutionary Loop"
echo "  Lineage: ${LINEAGE_ID}"
echo "==========================================="

while [ "$generation" -lt "$MAX_GENERATIONS" ]; do
    generation=$((generation + 1))
    echo ""
    echo "---- Generation ${generation} ----"

    EXIT_CODE=0

    if [ "$generation" -eq 1 ] && [ -n "$SEED_FILE" ]; then
        echo "  Seed: ${SEED_FILE}"
        python3 "$PYTHON_SCRIPT" "$LINEAGE_ID" --seed "$SEED_FILE" || EXIT_CODE=$?
    else
        python3 "$PYTHON_SCRIPT" "$LINEAGE_ID" || EXIT_CODE=$?
    fi

    case $EXIT_CODE in
        0)
            echo ""
            echo "==========================================="
            echo "  CONVERGED after ${generation} generation(s)"
            echo "  Ralph DoD met: evolutionary loop converged"
            echo "==========================================="
            exit 0
            ;;
        10)
            echo "  -> action=CONTINUE"
            ;;
        20)
            echo ""
            echo "  STAGNATED at generation ${generation}"
            echo "  Ontology unchanged for 3+ generations"
            exit 20
            ;;
        30)
            echo ""
            echo "  EXHAUSTED at generation ${generation}"
            exit 30
            ;;
        *)
            echo ""
            echo "  FAILED at generation ${generation} (exit=${EXIT_CODE})"
            exit 1
            ;;
    esac
done

echo ""
echo "  Reached max generations (${MAX_GENERATIONS})"
exit 30
