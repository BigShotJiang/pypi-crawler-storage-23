"""Unit tests for ouroboros.persistence module."""
