"""Tests for plugin state module."""
