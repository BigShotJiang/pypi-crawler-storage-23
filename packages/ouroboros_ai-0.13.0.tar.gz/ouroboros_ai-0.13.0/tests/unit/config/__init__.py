"""Unit tests for ouroboros.config module."""
