"""MCP client unit tests package."""
