"""MCP unit tests package."""
