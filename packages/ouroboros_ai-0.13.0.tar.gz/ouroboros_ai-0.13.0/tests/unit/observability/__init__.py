"""Unit tests for ouroboros.observability module."""
