#!/usr/bin/env python3
"""Ralph × Ouroboros bridge: call evolve_step via MCP stdio transport.

Each invocation is stateless — state is reconstructed from EventStore.
Exit codes encode the action for the shell driver:
  0  = converged (Ralph DoD met)
  10 = continue  (next generation needed)
  20 = stagnated (ontology unchanged 3+ gens)
  30 = exhausted (max generations reached)
  1  = failed
"""

from __future__ import annotations

import argparse
import asyncio
import json
import re
import sys
from pathlib import Path

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# --- Exit codes ---
EXIT_CONVERGED = 0
EXIT_CONTINUE = 10
EXIT_STAGNATED = 20
EXIT_EXHAUSTED = 30
EXIT_FAILED = 1

ACTION_TO_EXIT = {
    "converged": EXIT_CONVERGED,
    "continue": EXIT_CONTINUE,
    "stagnated": EXIT_STAGNATED,
    "exhausted": EXIT_EXHAUSTED,
    "failed": EXIT_FAILED,
}

# Regex to extract **Action**: <value> from MCP text output
ACTION_RE = re.compile(r"\*\*Action\*\*:\s*(\w+)")


async def call_evolve_step(
    lineage_id: str,
    seed_content: str | None = None,
    server_cmd: str = "uvx",
    server_args: list[str] | None = None,
) -> dict:
    """Call ouroboros_evolve_step through MCP stdio transport.

    Spawns the MCP server as a subprocess, sends one tool call, returns result.
    The server subprocess is cleaned up automatically on exit.
    """
    if server_args is None:
        server_args = ["--from", "ouroboros-ai", "--python", "3.14", "ouroboros", "mcp", "serve"]

    server_params = StdioServerParameters(
        command=server_cmd,
        args=server_args,
    )

    async with stdio_client(server_params) as streams:
        async with ClientSession(*streams) as session:
            await session.initialize()

            # Build tool arguments
            arguments: dict[str, str] = {"lineage_id": lineage_id}
            if seed_content:
                arguments["seed_content"] = seed_content

            result = await session.call_tool("ouroboros_evolve_step", arguments)

            # Extract text from content blocks
            text_parts = []
            for block in result.content:
                if hasattr(block, "text"):
                    text_parts.append(block.text)

            text = "\n".join(text_parts)

            # Parse action from text
            match = ACTION_RE.search(text)
            action = match.group(1).lower() if match else "failed"

            return {
                "text": text,
                "action": action,
                "is_error": getattr(result, "isError", False),
            }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Call ouroboros_evolve_step via MCP (one generation per call)",
    )
    parser.add_argument("lineage_id", help="Lineage ID to evolve")
    parser.add_argument(
        "--seed", "-s",
        help="Path to seed YAML file (Gen 1 only)",
    )
    parser.add_argument(
        "--json", "-j",
        action="store_true",
        dest="json_output",
        help="Output raw JSON instead of formatted text",
    )
    args = parser.parse_args()

    # Read seed file if provided
    seed_content = None
    if args.seed:
        seed_path = Path(args.seed)
        if not seed_path.exists():
            print(f"Error: seed file not found: {seed_path}", file=sys.stderr)
            sys.exit(EXIT_FAILED)
        seed_content = seed_path.read_text()

    # Run the MCP call
    result = asyncio.run(call_evolve_step(args.lineage_id, seed_content))

    # Output
    if args.json_output:
        print(json.dumps(result, indent=2, default=str))
    else:
        print(result["text"])

    # Exit code encodes the action
    sys.exit(ACTION_TO_EXIT.get(result["action"], EXIT_FAILED))


if __name__ == "__main__":
    main()
