# Task Manager Example

This is a standalone example CLI app kept under `examples/` and not part of the
`ouroboros-ai` package runtime.

Run:

```bash
python -m examples.task_manager --help
```

