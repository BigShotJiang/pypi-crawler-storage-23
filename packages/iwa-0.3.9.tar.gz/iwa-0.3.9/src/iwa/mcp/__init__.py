"""MCP server for iwa — blockchain interaction platform for AI agents."""
