"""JMeter rules for perf-lint."""

from perf_lint.rules.jmeter import rules  # noqa: F401 - triggers registration
