"""Gatling rules for perf-lint."""

from perf_lint.rules.gatling import rules  # noqa: F401 - triggers registration
