"""Rule system for perf-lint."""
