"""K6 rules for perf-lint."""

from perf_lint.rules.k6 import rules  # noqa: F401 - triggers registration
