"""Intermediate representation models."""
