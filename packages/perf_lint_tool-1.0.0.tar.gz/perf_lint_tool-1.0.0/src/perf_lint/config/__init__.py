"""Configuration loading and schema."""
