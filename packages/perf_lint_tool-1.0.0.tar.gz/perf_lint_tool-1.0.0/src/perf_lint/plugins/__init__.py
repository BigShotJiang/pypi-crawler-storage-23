"""Plugin system for perf-lint custom rules."""
