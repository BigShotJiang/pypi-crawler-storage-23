"""Output reporters for perf-lint."""
