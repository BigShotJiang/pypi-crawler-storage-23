"""perf-lint: A static analyser for performance test scripts."""

__version__ = "1.0.0"
