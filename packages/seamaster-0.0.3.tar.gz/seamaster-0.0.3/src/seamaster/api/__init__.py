"""
Docstring for seamaster.api
"""

from .game_api import GameAPI

__all__ = [
    "GameAPI",
]
