def giveNumber():
    return 12
