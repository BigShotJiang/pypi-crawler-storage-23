from typing import List, Literal, Optional, Tuple, Union

import cupy as cp
import numpy as np
import scipy.sparse as sp

# ---------- dense path: atomicAdd directly into (V x V) float32 ----------

_DENSE_KERNEL = cp.RawKernel(
    r'''
extern "C" __global__
void count_cooc_dense(
    const int* ids_ext,
    float* matrix,
    const int L,
    const int window,
    const int vocab_size
){
    long long t = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    long long P = (long long)L * (2 * window);
    if (t >= P) return;

    int i_local = (int)(t / (2 * window));
    int k       = (int)(t % (2 * window));
    int off     = k - window;
    if (off >= 0) off += 1;

    int wi = ids_ext[i_local + window];
    int wj = ids_ext[i_local + window + off];

    if (wi >= 0 && wj >= 0 && wi < vocab_size && wj < vocab_size){
        atomicAdd(&matrix[(long long)wi * vocab_size + wj], 1.0f);
    }
}
''',
    "count_cooc_dense",
)

# ---------- sparse path: emit linearised pair indices, cp.unique ----------

_SPARSE_KERNEL = cp.RawKernel(
    r'''
extern "C" __global__
void make_pairs(
    const int* ids_ext,
    long long* linear_out,
    const int L,
    const int window,
    const int vocab_size
){
    long long t = (long long)blockIdx.x * blockDim.x + threadIdx.x;
    long long P = (long long)L * (2 * window);
    if (t >= P) return;

    int i_local = (int)(t / (2 * window));
    int k       = (int)(t % (2 * window));
    int off     = k - window;
    if (off >= 0) off += 1;

    int wi = ids_ext[i_local + window];
    int wj = ids_ext[i_local + window + off];

    long long out = -1;
    if (wi >= 0 && wj >= 0 && wi < vocab_size && wj < vocab_size){
        out = (long long)wi * (long long)vocab_size + (long long)wj;
    }
    linear_out[t] = out;
}
''',
    "make_pairs",
)

# -------------------------------------------------------------------------


def _dense_matrix_bytes(n_vocab: int) -> int:
    return n_vocab * n_vocab * 4


def _pick_mode(
    mode: Literal["auto", "dense", "sparse"],
    n_vocab: int,
    max_vram_gb: float,
) -> Literal["dense", "sparse"]:
    if mode != "auto":
        return mode
    mat_bytes = _dense_matrix_bytes(n_vocab)
    budget = int(max_vram_gb * (1024**3))
    return "dense" if mat_bytes <= budget * 0.8 else "sparse"


# ---- chunking helpers ---------------------------------------------------


def _chunk_L_dense(max_vram_bytes: int, matrix_bytes: int) -> int:
    remaining = max(0, int(max_vram_bytes * 0.65) - matrix_bytes)
    return max(100_000, remaining // 4)


def _chunk_L_sparse(max_vram_bytes: int, window: int) -> int:
    per_tok = max(64, (2 * window) * 16)
    return max(10_000, int((max_vram_bytes * 0.65) // per_tok))


# ---- shared: build the padded ids_ext for a chunk ----------------------


def _prepare_chunk(
    corpus_ids: np.ndarray, s: int, e: int, window: int, N: int,
) -> np.ndarray:
    left = max(0, s - window)
    right = min(N, e + window)
    ids_ext = corpus_ids[left:right]
    pad_l = max(0, window - s)
    pad_r = max(0, (e + window) - N)
    if pad_l or pad_r:
        ids_ext = np.pad(ids_ext, (pad_l, pad_r), constant_values=-1)
    return ids_ext


# ---- dense impl --------------------------------------------------------


def _count_dense(
    corpus_ids: np.ndarray,
    n_vocab: int,
    window: int,
    max_vram_bytes: int,
    progress_every_tokens: int,
) -> cp.ndarray:
    mat_bytes = _dense_matrix_bytes(n_vocab)
    if mat_bytes > max_vram_bytes * 0.8:
        raise MemoryError(
            f"Dense matrix needs {mat_bytes / 1e9:.1f} GB "
            f"(vocab={n_vocab:,}), exceeds VRAM budget."
        )

    matrix = cp.zeros((n_vocab, n_vocab), dtype=cp.float32)
    chunk_L = _chunk_L_dense(max_vram_bytes, mat_bytes)
    N = len(corpus_ids)
    threads = 256

    for s in range(0, N, chunk_L):
        e = min(N, s + chunk_L)
        ids_ext = _prepare_chunk(corpus_ids, s, e, window, N)
        ids_cp = cp.asarray(ids_ext, dtype=cp.int32)
        L = e - s
        P = L * (2 * window)
        blocks = (P + threads - 1) // threads
        _DENSE_KERNEL((blocks,), (threads,), (ids_cp, matrix, L, window, n_vocab))
        if progress_every_tokens > 0 and e % progress_every_tokens < chunk_L and e > 0:
            print(f"  {e:,} tokens processed...")

    cp.cuda.Stream.null.synchronize()
    return matrix


# ---- sparse impl -------------------------------------------------------


def _assemble_triplets(
    rows_parts: List[np.ndarray],
    cols_parts: List[np.ndarray],
    cnt_parts: List[np.ndarray],
    shape: Tuple[int, int],
) -> sp.csr_matrix:
    if not rows_parts:
        return sp.csr_matrix(shape, dtype=np.int64)
    rows = np.concatenate(rows_parts)
    cols = np.concatenate(cols_parts)
    cnts = np.concatenate(cnt_parts)
    return sp.coo_matrix((cnts, (rows, cols)), shape=shape, dtype=np.int64).tocsr()


def _count_sparse(
    corpus_ids: np.ndarray,
    n_vocab: int,
    window: int,
    max_vram_bytes: int,
    flush_triplets_every: int,
    progress_every_tokens: int,
) -> sp.csr_matrix:
    chunk_L = _chunk_L_sparse(max_vram_bytes, window)
    N = len(corpus_ids)
    threads = 256

    rows_parts: List[np.ndarray] = []
    cols_parts: List[np.ndarray] = []
    cnt_parts: List[np.ndarray] = []
    partials: List[sp.csr_matrix] = []
    staged_nnz = 0

    for s in range(0, N, chunk_L):
        e = min(N, s + chunk_L)
        ids_ext = _prepare_chunk(corpus_ids, s, e, window, N)
        ids_cp = cp.asarray(ids_ext, dtype=cp.int32)
        L = e - s
        P = L * (2 * window)
        linear = cp.empty(P, dtype=cp.int64)
        blocks = (P + threads - 1) // threads
        _SPARSE_KERNEL((blocks,), (threads,), (ids_cp, linear, L, window, n_vocab))

        valid = linear[linear >= 0]
        if valid.size:
            uniq, cnt = cp.unique(valid, return_counts=True)
            uniq_np = cp.asnumpy(uniq)
            cnt_np = cp.asnumpy(cnt).astype(np.int64, copy=False)
            rows_parts.append((uniq_np // n_vocab).astype(np.int32, copy=False))
            cols_parts.append((uniq_np % n_vocab).astype(np.int32, copy=False))
            cnt_parts.append(cnt_np)
            staged_nnz += len(cnt_np)

        if flush_triplets_every > 0 and staged_nnz >= flush_triplets_every:
            partials.append(_assemble_triplets(rows_parts, cols_parts, cnt_parts, (n_vocab, n_vocab)))
            rows_parts.clear()
            cols_parts.clear()
            cnt_parts.clear()
            staged_nnz = 0

        if progress_every_tokens > 0 and e % progress_every_tokens < chunk_L and e > 0:
            print(f"  {e:,} tokens processed...")

    if rows_parts:
        partials.append(_assemble_triplets(rows_parts, cols_parts, cnt_parts, (n_vocab, n_vocab)))
    if not partials:
        return sp.csr_matrix((n_vocab, n_vocab), dtype=np.int64)

    out = partials[0]
    for p in partials[1:]:
        out = out + p
    out.sum_duplicates()
    return out


# ---- public API ---------------------------------------------------------


def count_cooc_gpu(
    corpus_ids: np.ndarray,
    n_vocab: int,
    window: int = 5,
    max_vram_gb: float = 20.0,
    mode: Literal["auto", "dense", "sparse"] = "auto",
    flush_triplets_every: int = 20_000_000,
    progress_every_tokens: int = 0,
) -> Union[cp.ndarray, sp.csr_matrix]:
    """Build co-occurrence matrix on GPU.

    mode="auto" picks dense when the (V x V) matrix fits in VRAM, sparse otherwise.
    Returns cp.ndarray (dense) or scipy.sparse.csr_matrix (sparse).
    """
    if corpus_ids.dtype != np.int32:
        raise ValueError("corpus_ids must be np.int32")

    resolved = _pick_mode(mode, n_vocab, max_vram_gb)
    max_vram_bytes = int(max_vram_gb * (1024**3))

    if resolved == "dense":
        return _count_dense(corpus_ids, n_vocab, window, max_vram_bytes, progress_every_tokens)
    return _count_sparse(corpus_ids, n_vocab, window, max_vram_bytes, flush_triplets_every, progress_every_tokens)


def collapse(matrix: cp.ndarray) -> np.ndarray:
    """log1p -> center columns -> L2 normalize rows.  Returns CPU numpy array."""
    mat = cp.log1p(matrix)
    mat -= mat.mean(axis=0, keepdims=True)
    norms = cp.linalg.norm(mat, axis=1, keepdims=True)
    norms[norms == 0] = 1
    mat /= norms
    return cp.asnumpy(mat)
