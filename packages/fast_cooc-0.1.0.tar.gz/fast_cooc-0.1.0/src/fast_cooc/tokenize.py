import re
from collections import Counter
from dataclasses import dataclass
from typing import Callable, Dict, Iterable, Iterator, Optional, Protocol, Tuple

import warpdata as wd


class TokenizerBackend(Protocol):
    def tokenize(self, text: str) -> Iterable[str]:
        ...


@dataclass
class RegexTokenizer:
    pattern: str = r"[A-Za-z0-9_']+"
    lowercase: bool = True

    def __post_init__(self) -> None:
        self._rx = re.compile(self.pattern)

    def tokenize(self, text: str) -> Iterable[str]:
        src = text.lower() if self.lowercase else text
        return self._rx.findall(src)


@dataclass
class CallableTokenizer:
    fn: Callable[[str], Iterable[str]]

    def tokenize(self, text: str) -> Iterable[str]:
        return self.fn(text)


@dataclass
class HFTokenizer:
    model_name: str
    lowercase: bool = False
    use_fast: bool = True

    def __post_init__(self) -> None:
        try:
            from transformers import AutoTokenizer
        except Exception as e:
            raise ImportError(
                "HFTokenizer requires `transformers`. Install with: pip install transformers"
            ) from e
        self._tok = AutoTokenizer.from_pretrained(self.model_name, use_fast=self.use_fast)

    def tokenize(self, text: str) -> Iterable[str]:
        src = text.lower() if self.lowercase else text
        ids = self._tok.encode(src, add_special_tokens=False)
        return self._tok.convert_ids_to_tokens(ids)


def make_tokenizer(
    kind: str = "regex",
    *,
    pattern: str = r"[A-Za-z0-9_']+",
    lowercase: bool = True,
    hf_model: str = "bert-base-uncased",
    fn: Optional[Callable[[str], Iterable[str]]] = None,
) -> TokenizerBackend:
    if kind == "regex":
        return RegexTokenizer(pattern=pattern, lowercase=lowercase)
    if kind == "hf":
        return HFTokenizer(model_name=hf_model, lowercase=lowercase)
    if kind == "callable":
        if fn is None:
            raise ValueError("kind='callable' requires fn")
        return CallableTokenizer(fn=fn)
    raise ValueError(f"Unknown tokenizer kind: {kind}")


def iter_tokens(
    dataset_id: str,
    row_limit: Optional[int],
    tokenizer: TokenizerBackend,
) -> Iterator[str]:
    ds = wd.dataset(dataset_id)
    limit = row_limit if row_limit is not None and row_limit > 0 else None
    for row in ds.rows(limit=limit):
        text = row.get("text")
        if not text:
            continue
        yield from tokenizer.tokenize(str(text))


def build_vocab(
    dataset_id: str,
    min_freq: int,
    max_vocab: int,
    row_limit: Optional[int],
    tokenizer: Optional[TokenizerBackend] = None,
) -> Tuple[Dict[str, int], int]:
    if tokenizer is None:
        tokenizer = RegexTokenizer()
    freq = Counter()
    total_tokens = 0
    for tok in iter_tokens(dataset_id, row_limit, tokenizer):
        freq[tok] += 1
        total_tokens += 1

    items = [(w, c) for w, c in freq.items() if c >= min_freq]
    items.sort(key=lambda x: x[1], reverse=True)
    if max_vocab > 0:
        items = items[:max_vocab]
    word2idx = {w: i for i, (w, _) in enumerate(items)}
    return word2idx, total_tokens
