import argparse

from .config import CountConfig, VocabConfig
from .pipeline import run_warp_pipeline
from .tokenize import HFTokenizer, RegexTokenizer


def main() -> None:
    ap = argparse.ArgumentParser(prog="fast-cooc")
    ap.add_argument("--dataset", default="nlp/wikipedia")
    ap.add_argument("--workdir", default="wiki_cooc_work")
    ap.add_argument("--row-limit", type=int, default=0)
    ap.add_argument("--min-freq", type=int, default=10)
    ap.add_argument("--max-vocab", type=int, default=300000)
    ap.add_argument("--window", type=int, default=5)
    ap.add_argument("--max-vram-gb", type=float, default=20.0)
    ap.add_argument("--mode", choices=["auto", "dense", "sparse"], default="auto")
    ap.add_argument("--flush-triplets-every", type=int, default=20_000_000)
    ap.add_argument("--tokenizer", choices=["regex", "hf"], default="regex")
    ap.add_argument("--hf-model", default="bert-base-uncased")
    args = ap.parse_args()

    tokenizer = RegexTokenizer()
    if args.tokenizer == "hf":
        tokenizer = HFTokenizer(model_name=args.hf_model)

    out = run_warp_pipeline(
        dataset_id=args.dataset,
        workdir=args.workdir,
        row_limit=(args.row_limit if args.row_limit > 0 else None),
        vocab_cfg=VocabConfig(min_freq=args.min_freq, max_vocab=args.max_vocab),
        count_cfg=CountConfig(
            window=args.window,
            max_vram_gb=args.max_vram_gb,
            mode=args.mode,
            flush_triplets_every=args.flush_triplets_every,
        ),
        tokenizer=tokenizer,
    )
    print(out)


if __name__ == "__main__":
    main()
