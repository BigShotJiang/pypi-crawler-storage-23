import json
from pathlib import Path
from typing import Optional

import numpy as np
import scipy.sparse as sp

from .config import CountConfig, VocabConfig
from .gpu_count import collapse, count_cooc_gpu
from .tokenize import RegexTokenizer, TokenizerBackend, build_vocab, iter_tokens


def write_ids_memmap(
    dataset_id: str,
    row_limit: Optional[int],
    word2idx: dict,
    total_tokens: int,
    out_path: Path,
    tokenizer: TokenizerBackend,
) -> np.memmap:
    out = np.memmap(out_path, mode="w+", dtype=np.int32, shape=(total_tokens,))
    p = 0
    for tok in iter_tokens(dataset_id, row_limit, tokenizer):
        out[p] = word2idx.get(tok, -1)
        p += 1
    out.flush()
    return out


def run_warp_pipeline(
    dataset_id: str,
    workdir: str,
    row_limit: Optional[int] = None,
    vocab_cfg: VocabConfig = VocabConfig(),
    count_cfg: CountConfig = CountConfig(),
    tokenizer: Optional[TokenizerBackend] = None,
) -> Path:
    if tokenizer is None:
        tokenizer = RegexTokenizer()

    wd = Path(workdir)
    wd.mkdir(parents=True, exist_ok=True)

    word2idx, total_tokens = build_vocab(
        dataset_id=dataset_id,
        min_freq=vocab_cfg.min_freq,
        max_vocab=vocab_cfg.max_vocab,
        row_limit=row_limit,
        tokenizer=tokenizer,
    )

    with open(wd / "word2idx.json", "w", encoding="utf-8") as f:
        json.dump(word2idx, f)

    ids = write_ids_memmap(
        dataset_id=dataset_id,
        row_limit=row_limit,
        word2idx=word2idx,
        total_tokens=total_tokens,
        out_path=wd / "corpus_ids.i32",
        tokenizer=tokenizer,
    )

    result = count_cooc_gpu(
        corpus_ids=np.asarray(ids, dtype=np.int32),
        n_vocab=len(word2idx),
        window=count_cfg.window,
        max_vram_gb=count_cfg.max_vram_gb,
        mode=count_cfg.mode,
        flush_triplets_every=count_cfg.flush_triplets_every,
    )

    if sp.issparse(result):
        out = wd / "cooc_final.npz"
        sp.save_npz(out, result, compressed=False)
    else:
        embeddings = collapse(result)
        out = wd / "embeddings.npy"
        np.save(out, embeddings)

    return out
