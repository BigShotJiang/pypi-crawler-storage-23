from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class VocabConfig:
    min_freq: int = 10
    max_vocab: int = 300_000


@dataclass(frozen=True)
class CountConfig:
    window: int = 5
    max_vram_gb: float = 20.0
    mode: Literal["auto", "dense", "sparse"] = "auto"
    flush_triplets_every: int = 20_000_000
