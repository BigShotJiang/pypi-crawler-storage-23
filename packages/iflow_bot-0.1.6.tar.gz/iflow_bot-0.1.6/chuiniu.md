# 🤖 iflow-bot：开源免费的多平台 AI 助手，国内直接用！

## 一句话介绍

基于iflow CLI 的 iflow-bot，打通多平台 —— Telegram、钉钉、飞书、QQ、Discord、Slack、微信……让 AI 助手无处不在。

---

## 为什么你需要它？

### 🌍 多渠道，一个不落

工作用钉钉？生活用 Telegram？团队用 Slack？

**别再给每个平台单独配 AI 了！**

iflow-bot 一套配置，同时接入：

| 国内平台 | 海外平台 |
|---------|---------|
| 钉钉 ✅ | Telegram ✅ |
| 飞书 ✅ | Discord ✅ |
| QQ ✅ | Slack ✅ |
| 企业微信 🚧 | WhatsApp ✅ |
| 微信 🚧 | Email ✅ |

### 🇨🇳 国内可用，无需魔法

很多 AI 机器人依赖 OpenAI，国内用不了。

iflow-bot 基于 **iflow CLI**，支持：
- **GLM-5**（智谱 AI，国内直连）
- **Kimi K2.5**（月之暗面，国内直连）
- iflow cli 所有支持的模型……

**无需 VPN，无需海外账号，打开即用。**

### ⚡ 流式输出，打字机效果

等 AI 回复太慢？试试流式输出！

- **Telegram**：消息实时编辑，看 AI 一个字一个字"打"出来
![Telegram 流式输出](https://github.com/kai648846760/iflow-bot/raw/master/testcase/Lark20260225-200437.gif)
- **钉钉**：AI Card 流式更新，秒回卡片 + 实时内容填充
![钉钉 流式输出](https://github.com/kai648846760/iflow-bot/raw/master/testcase/Lark20260225-200423.gif)


### 🧠 智能记忆，越用越懂你

每个机器人实例拥有独立工作空间：
- 记住你的偏好和习惯
- 支持长期记忆和日常日志
- 跨对话上下文保持

---

## 3 分钟上手

**方式一：pip 安装（推荐）**

```bash
# 1. 安装 iflow CLI
npm i -g @iflow-ai/iflow-cli@latest

# 2. 登录（会打开浏览器，国内直连）
iflow

# 3. 安装 iflow-bot
pip install iflow-bot

# 4. 初始化配置
iflow-bot onboard

# 5. 启动！
iflow-bot gateway run
```

**方式二：从源码安装**

```bash
# 1. 安装 iflow CLI
npm i -g @iflow-ai/iflow-cli@latest

# 2. 登录（会打开浏览器，国内直连）
iflow

# 3. 克隆项目
git clone https://github.com/kai648846760/iflow-bot.git
cd iflow-bot

# 4. 安装依赖
uv sync

# 5. 初始化配置
uv run iflow-bot onboard

# 6. 启动！
uv run iflow-bot gateway run
```

---

## 谁适合用？

| 用户 | 场景 |
|------|------|
| 程序员 | 多平台自动化助手、代码审查、技术问答 |
| 产品经理 | 需求分析、文档撰写、会议纪要 |
| 运营 | 多渠道客服、内容生成、数据分析 |
| 学生 | 学习辅导、论文助手、知识管理 |
| 团队 | 协作机器人、知识库问答、流程自动化 |

---

## 开源地址

GitHub: https://github.com/kai648846760/iflow-bot

欢迎 Star ⭐、Fork 🍴、Issue 💬

---

## 一句话总结

**iflow-bot = 免费 + 多平台 + 国内可用 + 流式输出 + 开源可定制**

如果你需要一个能同时跑在钉钉、飞书、Telegram、QQ 上的 AI 助手，而且一分钱不用花……

**这就是你要找的。**

---

> 💡 觉得有用？给个 Star 支持一下开发者吧！  
> GitHub: https://github.com/kai648846760/iflow-bot
