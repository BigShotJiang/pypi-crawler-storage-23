"""Phantom — Automated documentation asset generation."""

__version__ = "0.2.0"
