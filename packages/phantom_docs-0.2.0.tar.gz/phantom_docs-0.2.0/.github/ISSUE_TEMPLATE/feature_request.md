---
name: Feature Request
about: Suggest a new feature or improvement
title: ""
labels: enhancement
assignees: ""
---

## Problem

A clear description of the problem this feature would solve.

## Proposed solution

How you'd like this to work. Include manifest snippets, CLI examples, or API sketches if applicable.

## Alternatives considered

Other approaches you've thought about and why you prefer the proposed solution.

## Additional context

Any other information, screenshots, or references that support this request.
