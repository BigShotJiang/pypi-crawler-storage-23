# pre-commit-localupdate

A CLI tool to automatically update dependencies in `pre-commit-config.yml` files. It specifically targets `additional_dependencies` within local Python, Julia, Rust, and Node.js hooks to ensure your tooling stays up-to-date. It also adds version to unversioned packages and pins exact version of loosely defined ones. You can also pin a specific package to an older version by adding a `# freeze` comment.

## Installation

```shell
pip install pre-commit-localupdate
```

## Usage

To check and update the `additional_dependencies` in your `.pre-commit-config.yaml` file, simply run:

```shell
pre-commit-localupdate
```

By default, the tool looks for `.pre-commit-config.yaml` in the current directory. To specify a custom file path, use the `-c` or `--config` argument:

```shell
pre-commit-localupdate --config path/to/.pre-commit-config.yaml
```

To check the dependencies without updating, use the `--dry-run` flag. The command will exit with a non-zero status code if any package needs updating:

```shell
pre-commit-localupdate --dry-run
```

To get debug output use `--debug` flag:

```shell
pre-commit-localupdate --debug
```

## Example

Given a `.pre-commit-config.yaml` with the following content:

```yaml
# File header is preserved. If there is no document start marker (---), it won't be added
---
repos:
  # External hooks won't be touched. Use 'pre-commit autoupdate' command to update them
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v2.3.0
    hooks:
      - id: end-of-file-fixer
      - id: trailing-whitespace

  - repo: local
    hooks:
      # All comment are preserved
      - id: black
        name: black
        description: "Long strings are automatically folded into multilines by ruamel-yaml library!"
        entry: black
        language: python
        minimum_pre_commit_version: 2.9.2
        require_serial: true
        types_or: [python, pyi]
        additional_dependencies:
          # Loose version definitions are pinned to an exact version
          - "black>=25.1.0"
          # Updates can be prevented by adding a 'freeze' comment to them as:
          - "white==0.1.0"  # freeze

      - id: julia-format
        name: format julia code
        description: Run `JuliaFormatter.jl` against Julia source files
        language: julia
        types: [julia]
        entry: tools/formatter.jl
        additional_dependencies:
          # Double/single quoting style is preserved and version is added to packages with no version definition
          - 'JuliaFormatter'

      - id: mdbook-lint
        name: mdbook-lint
        description: rust package to lint markdown
        entry: mdbook-lint lint --fix
        language: rust
        types: [markdown]
        # Updating packages defined in flow style is also supported
        additional_dependencies: ["cli:mdbook-lint"]
```

Running `pre-commit-localupdate` will update the file to (hypothetical latest versions):

```yaml
# File header is preserved. If there is no document start marker (---), it won't be added
---
repos:
  # External hooks won't be touched. Use 'pre-commit autoupdate' command to update them
  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v2.3.0
    hooks:
      - id: end-of-file-fixer
      - id: trailing-whitespace

  - repo: local
    hooks:
      # All comment are preserved
      - id: black
        name: black
        description: "Long strings are automatically folded into multilines by ruamel-yaml
          library!"
        entry: black
        language: python
        minimum_pre_commit_version: 2.9.2
        require_serial: true
        types_or: [python, pyi]
        additional_dependencies:
          # Loose version definitions are pinned to an exact version
          - "black==26.1.0"
          # Updates can be prevented by adding a 'freeze' comment to them as:
          - "white==0.1.0"  # freeze

      - id: julia-format
        name: format julia code
        description: Run `JuliaFormatter.jl` against Julia source files
        language: julia
        types: [julia]
        entry: tools/formatter.jl
        additional_dependencies:
          # Double/single quoting style is preserved and version is added to packages with no version definition
          - 'JuliaFormatter@2.3.0'

      - id: mdbook-lint
        name: mdbook-lint
        description: rust package to lint markdown
        entry: mdbook-lint lint --fix
        language: rust
        types: [markdown]
        # Updating packages defined in flow style is also supported
        additional_dependencies: ["cli:mdbook-lint:0.14.2"]
```

## Formatting

A considerable amount of effort has been put into making `pre-commit-localupdate` respect the original style and preserve the comments in the pre-commit configuration files. Although it is currently folding long strings (for example, in description lines) and enforcing block indentation for better readability.

## Requirements

- ruamel.yaml
- requests

## License

- Copyright 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics (MPP)

All rights reserved.
This software may be modified and distributed under the terms of the GNU Lesser General Public License (LGPL). See the `LICENSE` file for details.
