# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import argparse

from pre_commit_localupdate import __version__


def parse_args() -> argparse.Namespace:
    """Parse command line arguments."""
    parser = argparse.ArgumentParser(
        description="Automatically update additional dependencies within local Python, Julia, Rust, and Node.js hooks in a pre-commit config file.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Dry run mode. Do not update the file and exit with a non-zero code if the configuration file require an update.",
    )
    parser.add_argument(
        "-c",
        "--config",
        type=str,
        help="pre-commit config file path",
        default=".pre-commit-config.yaml",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"pre-commit-localupdate {__version__}",
    )
    return parser.parse_args()
