# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

from .julia import JuliaPackage
from .node import NodePackage
from .package import PackageBase
from .python import PyPackage
from .rust import RustPackage

SUPPORTED_PACKAGES: dict[str, type[PackageBase]] = {
    "julia": JuliaPackage,
    "node": NodePackage,
    "python": PyPackage,
    "rust": RustPackage,
}
