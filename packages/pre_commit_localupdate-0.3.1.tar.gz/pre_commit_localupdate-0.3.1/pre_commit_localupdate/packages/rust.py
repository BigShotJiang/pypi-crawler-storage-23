# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
from typing import Any, cast

import requests

from .package import PackageBase

CRATES_API_URL = "https://crates.io/api/v1/crates/{package_name}"
REQUEST_TIMEOUT = 10


class RustPackage(PackageBase):
    """Represents a Rust package.

    Attributes:
        cli: Package is a CLI tool.
    """

    cli: bool = False

    def __init__(self, **kwargs: Any) -> None:
        self.cli = kwargs.pop("cli", False)
        super().__init__(**kwargs)

    @classmethod
    def from_specification(package, spec: str) -> "RustPackage" | None:
        """Parse a package specification string into a Package object.

        Handles formats like 'package', 'package:1.2.3', or 'cli:package:1.2.3'.

        Args:
            spec: The package specification string.

        Returns:
            A Package instance if parsing succeeds, otherwise None.

        """
        clean_spec = spec.strip().strip('"').strip("'")

        match = re.match(
            r"^(?:(?P<cli>cli):)?(?P<name>[a-zA-Z0-9_-]+)(?::(?P<version>[^:]+))?$",
            clean_spec,
        )
        if not match:
            logging.warning("Could not parse the package specification: %s", clean_spec)
            return None

        name = match.group("name")
        version = match.group("version")
        cli = True if match.group("cli") else False

        raw_spec = f":{version}" if version else None
        latest_version = package._get_latest_version(name)

        return package(
            name=name, raw_spec=raw_spec, latest_version=latest_version, cli=cli
        )

    @staticmethod
    def _get_latest_version(package_name: str) -> str | None:
        """Fetch the latest version of a package from crates.io.

        Returns:
            The latest version string if found, otherwise None.

        """
        logging.debug("Fetching latest version for %s", package_name)
        try:
            url = CRATES_API_URL.format(package_name=package_name)
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()
            version = data.get("crate", {}).get("max_version")
            if version and isinstance(version, str):
                return cast("str", version)

            return None
        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_name, exc
            )
            return None
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", package_name, exc)
            return None

    def latest_version_specification(package) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            The latest version specification string if found, otherwise None.

        """
        if not package.latest_version:
            return None
        if package.cli:
            return f"cli:{package.name}:{package.latest_version}"
        else:
            return f"{package.name}:{package.latest_version}"
