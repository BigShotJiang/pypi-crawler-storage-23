# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
import tomllib

import requests

from .package import PackageBase

# Julia General Registry Source
JULIA_PKG_API_URL = "https://raw.githubusercontent.com/JuliaRegistries/General/refs/heads/master/{package_name_first_letter}/{package_name}/Versions.toml"
REQUEST_TIMEOUT = 10


class JuliaPackage(PackageBase):
    """Represents a Julia package."""

    @classmethod
    def from_specification(package, spec: str) -> "JuliaPackage" | None:
        """Parse a package specification string into a Package object.

        Handles formats like 'Example@0.4.1', 'Example@0.4', or just 'Example'.

        Args:
            spec: The package specification string.

        Returns:
            A Package instance if parsing succeeds, otherwise None.

        """
        clean_spec = spec.strip().strip('"').strip("'")
        match = re.match(r"^([a-zA-Z0-9_]+)(?:@([a-zA-Z0-9._+,-]+))?$", clean_spec)

        if not match:
            logging.warning("Could not parse the package specification: %s", clean_spec)
            return None

        name = match.group(1)
        raw_spec = match.group(2)
        latest_version = package._get_latest_version(name)

        return package(
            name=name,
            raw_spec=raw_spec,
            latest_version=latest_version,
        )

    @staticmethod
    def _get_latest_version(package_name: str) -> str | None:
        """Fetch the latest version of a package from the Julia General Registry.

        Returns:
            The latest version string if found, otherwise None.

        """
        logging.debug("Fetching latest version for %s", package_name)
        try:
            url = JULIA_PKG_API_URL.format(
                package_name=package_name, package_name_first_letter=package_name[0]
            )
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()

            data = tomllib.loads(response.text)

            versions = list(data.keys())
            if not versions:
                return None

            versions.sort(reverse=True)
            latest = versions[0]

            if latest and isinstance(latest, str):
                return latest

            return None
        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_name, exc
            )
            return None
        except (KeyError, ValueError, tomllib.TOMLDecodeError) as exc:
            logging.warning("Could not parse response for %s: %s", package_name, exc)
            return None

    def latest_version_specification(package) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            The latest version specification string if found, otherwise None.
            Format: PackageName@version

        """
        if not package.latest_version:
            return None

        return f"{package.name}@{package.latest_version}"
