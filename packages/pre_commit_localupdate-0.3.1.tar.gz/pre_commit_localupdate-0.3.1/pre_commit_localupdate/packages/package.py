# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class PackageBase(ABC):
    """Abstract base class defining the interface for all package types.

    Attributes:
        name: The name of the package (e.g., 'requests').
        raw_spec: The original version specifier string (e.g., '==2.25.1', '^4.17.21', '>=1.0.0', '@1.2.3').
        latest_version: Latest version number without operators (e.g., '2.25.1').

    """

    name: str
    raw_spec: str | None
    latest_version: str | None

    @classmethod
    @abstractmethod
    def from_specification(package, spec_string: str) -> "PackageBase" | None:
        """Parse a package specification string into a Package object."""

    @abstractmethod
    def latest_version_specification(package) -> str | None:
        """Version specification of package pinned to the latest version."""

    def version_specification(package) -> str | None:
        """Version specification of package as originally defined.

        Returns:
            The version specification string.

        """
        if package.raw_spec:
            return f"{package.name}{package.raw_spec}"
        return f"{package.name}[unspecified version]"
