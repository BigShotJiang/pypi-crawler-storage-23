# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
import re
from dataclasses import dataclass
from typing import cast

import requests

from .package import PackageBase

NPM_API_URL = "https://registry.npmjs.org/{package_name}"
REQUEST_TIMEOUT = 10


@dataclass
class NodePackage(PackageBase):
    """Represents a Node.js package."""

    @classmethod
    def from_specification(package, spec: str) -> "NodePackage" | None:
        """Parse a package specification string into a NodePackage object.

        Handles formats like 'react@4.17.21', 'react@>=18.0.0', '@scope/name@^1.2.3', or just 'react'.

        Args:
            spec: The package specification string.

        Returns:
            A NodePackage instance if parsing succeeds, otherwise None.

        """
        clean_spec = spec.strip().strip('"').strip("'")

        if not clean_spec:
            return None

        parts = clean_spec.split("@")

        name = clean_spec
        raw_spec = None

        # Look for version from the end (handles scoped packages correctly).
        for i in range(len(parts) - 1, 0, -1):
            if re.match(r"^(\d+|[<>=~^])", parts[i]):
                name = "@".join(parts[:i])
                raw_spec = "@" + "@".join(parts[i:])
                break

        latest_version = package._get_latest_version(name)

        return package(
            name=name,
            raw_spec=raw_spec,
            latest_version=latest_version,
        )

    @staticmethod
    def _get_latest_version(package_name: str) -> str | None:
        """Fetch the latest version of a package from the npm registry.

        Returns:
            The latest version string if found, otherwise None.

        """
        try:
            url = NPM_API_URL.format(package_name=package_name)
            response = requests.get(url, timeout=REQUEST_TIMEOUT)
            response.raise_for_status()
            data = response.json()

            version = data.get("dist-tags", {}).get("latest")

            if version and isinstance(version, str):
                return cast("str", version)

            return None
        except requests.exceptions.RequestException as exc:
            logging.warning(
                "Could not fetch latest version for %s: %s", package_name, exc
            )
            return None
        except (KeyError, ValueError) as exc:
            logging.warning("Could not parse response for %s: %s", package_name, exc)
            return None

    def latest_version_specification(package) -> str | None:
        """Version specification of package pinned to the latest version.

        Returns:
            The latest version specification string if found, otherwise None.

        """
        if not package.latest_version:
            return None

        return f"{package.name}@{package.latest_version}"
