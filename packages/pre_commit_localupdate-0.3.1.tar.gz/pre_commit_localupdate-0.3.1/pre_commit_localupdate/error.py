# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later


class PreCommitLocalUpdateError(Exception):
    """Exceptions for errors encountered during the pre-commit local update process."""
