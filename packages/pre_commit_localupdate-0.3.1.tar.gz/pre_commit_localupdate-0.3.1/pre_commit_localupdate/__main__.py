# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

"""Module to update additional_dependencies in .pre-commit-config.yaml.

This script reads the .pre-commit-config.yaml file, identifies hooks defined
under 'repo: local' and updates the packages listed in 'additional_dependencies'
to their latest versions.

"""

import logging
import sys
from pathlib import Path

from pre_commit_localupdate.cli import parse_args
from pre_commit_localupdate.error import PreCommitLocalUpdateError
from pre_commit_localupdate.logs import setup_logging
from pre_commit_localupdate.pre_commit_config import update_additional_dependencies


def main() -> None:
    """Main entry point for the script."""
    args = parse_args()
    setup_logging(debug=args.debug)

    try:
        if update_additional_dependencies(Path(args.config), dry_run=args.dry_run):
            if args.dry_run:
                sys.exit(1)
            logging.info("Done.")
        else:
            logging.info(
                "Additional dependencies of local hooks are already up to date.",
            )
    except PreCommitLocalUpdateError as exc:
        logging.exception(exc)
        sys.exit(2)


if __name__ == "__main__":
    main()
