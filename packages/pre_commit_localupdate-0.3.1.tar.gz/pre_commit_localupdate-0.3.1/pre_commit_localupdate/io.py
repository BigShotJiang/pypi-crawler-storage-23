# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import logging
from pathlib import Path

from pre_commit_localupdate.error import PreCommitLocalUpdateError


def load_config_file(file_path: Path) -> tuple[list[str], str]:
    """Reads pre-commit configuration file and returns its header lines and content."""
    logging.debug("Reading configuration file: %s", file_path)

    raw_lines: list[str] = []
    header_lines: list[str] = []
    content_start_index: int = 0

    try:
        with file_path.open("r", encoding="utf-8") as f:
            raw_lines = f.readlines()
    except FileNotFoundError as exc:
        error = f"File not found: {file_path}"
        raise PreCommitLocalUpdateError(error) from exc
    except OSError as exc:
        error = f"IOError while reading file {file_path}"
        raise PreCommitLocalUpdateError(error) from exc

    logging.debug("Parsing file header...")
    content_start_index = 0
    for i, line in enumerate(raw_lines):
        stripped: str = line.strip()
        if stripped == "---":
            logging.debug("YAML marker found.")
            content_start_index = i + 1
            break
        if stripped and not stripped.startswith("#"):
            content_start_index = i
            break

    header_lines = raw_lines[:content_start_index]
    content: str = "".join(raw_lines[content_start_index:])

    return header_lines, content
