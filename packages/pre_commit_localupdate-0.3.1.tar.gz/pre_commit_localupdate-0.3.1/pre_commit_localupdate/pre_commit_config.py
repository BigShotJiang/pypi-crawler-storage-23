# SPDX-FileCopyrightText: 2026 M. Farzalipour Tabriz, Max Planck Institute for Physics
# SPDX-License-Identifier: LGPL-3.0-or-later

import io
import logging
import os
import re
import tempfile
from pathlib import Path

import ruamel.yaml

from pre_commit_localupdate.error import PreCommitLocalUpdateError
from pre_commit_localupdate.io import load_config_file
from pre_commit_localupdate.packages import SUPPORTED_PACKAGES


def update_additional_dependencies(file_path: Path, *, dry_run: bool = False) -> bool:
    """Reads the pre-commit configuration file, identifies outdated packages
    in local hooks, and updates them directly in the file.

    Preserves structure, quote styles, the document start marker (---),
    and comments preceding it.

    Args:
        file_path: Path to the pre-commit configuration file.
        dry_run: Do not update the pre-commit configuration file.

    Returns:
        True if the file needed updating, False otherwise.

    """
    header_lines, yaml_content = load_config_file(file_path)

    logging.debug("Parsing YAML content...")

    yaml = ruamel.yaml.YAML()
    yaml.preserve_quotes = True
    yaml.indent(mapping=2, sequence=4, offset=2)
    yaml.default_flow_style = False
    yaml.width = None
    yaml.explicit_start = False
    yaml.allow_unicode = True

    try:
        config = yaml.load(yaml_content)
    except ruamel.yaml.error.YAMLError as exc:
        raise PreCommitLocalUpdateError("Failed to parse YAML content.") from exc

    if config is None:
        raise PreCommitLocalUpdateError(
            "Configuration file is empty or could not be parsed.",
        )

    update_required = False

    if "repos" in config:
        logging.debug("Scanning repositories for local hooks")
        for repo in config.get("repos", []):
            if repo.get("repo") != "local":
                continue

            hooks = repo.get("hooks", [])
            for hook in hooks:
                hook_id = hook.get("id")
                logging.debug("Processing hook with ID: %s", hook_id)

                if hook.get("language") not in SUPPORTED_PACKAGES:
                    continue

                deps_list = hook.get("additional_dependencies")

                if not deps_list:
                    continue

                package_type = SUPPORTED_PACKAGES[hook.get("language")]

                for i, dep_spec in enumerate(deps_list):
                    dep_str = str(dep_spec)

                    if hasattr(deps_list, "ca") and deps_list.ca.items:
                        comment_data = deps_list.ca.items.get(i)
                        if comment_data:
                            if re.match(
                                r"^#\s*freeze(\s|$)", comment_data[0].value.lower()
                            ):
                                logging.debug("Skipping frozen dependency: %s", dep_str)
                                continue

                    logging.debug("Checking dependency: %s", dep_str)
                    package = package_type.from_specification(dep_str)
                    if not package:
                        continue

                    if not package.latest_version_specification():
                        continue

                    if (
                        package.latest_version_specification()
                        != package.version_specification()
                    ):
                        logging.info(
                            "%s needs updating to %s",
                            package.version_specification(),
                            package.latest_version_specification(),
                        )
                        hook["additional_dependencies"][
                            i
                        ] = package.latest_version_specification()

                        update_required = True
                    else:
                        logging.debug(
                            "%s is already correctly defined and up to date (%s).",
                            package.name,
                            package.version_specification(),
                        )
    else:
        raise PreCommitLocalUpdateError("Failed to parse pre-commit hooks!")

    if update_required:
        if dry_run:
            return True

        logging.debug("Writing modifications to disk...")
        stream = io.StringIO()
        yaml.dump(config, stream)
        modified_body = stream.getvalue()
        final_content = "".join(header_lines) + modified_body

        try:
            with tempfile.NamedTemporaryFile(
                mode="w",
                encoding="utf-8",
                dir=file_path.parent,
                delete=False,
            ) as tmp_file:
                tmp_file.write(final_content)
                os.fsync(tmp_file.fileno())
                temp_file_path = tmp_file.name

            os.replace(temp_file_path, file_path)
            logging.info("Successfully updated %s", file_path)
            return True

        except OSError as exc:
            if "temp_file_path" in locals() and os.path.exists(temp_file_path):
                os.unlink(temp_file_path)
            raise PreCommitLocalUpdateError(
                f"IOError while writing to file {file_path}"
            ) from exc

    return False
