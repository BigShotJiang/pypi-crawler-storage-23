"""Tests for autoskope_client."""
