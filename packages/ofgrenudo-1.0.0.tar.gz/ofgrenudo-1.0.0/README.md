# Hello World!!

hello my name is Joshua! Professionally I am a systems analyst / developer at [Kalamazoo Valley Community College](https://kvcc.edu).
I deal with a number of programming languages, and build / deliver solutions for end users across the company with a focus on portable and secure systems and programs using a combination of dockerization and system hardening.

I currently am attending [Western Michigan University](https://wmich.edu/), and am senior expected to graduate in April of 2026 with a [Bachelor of Buisness in Computer Information Systems](https://catalog.wmich.edu/preview_program.php?catoid=47&poid=15532&returnto=2271)!

### Fun facts about me

- Im pretty good at picking locks
- I have a dog
- I love all things horror

### Getting Ahold of Me

```bash
# Install me as a binary
uvx ofgrenudo
# Then run ofgrenudo
ofgrenudo
```

### Technical Skills

#### Languages

- English / Spanish
- [Go](https://go.dev/), [Python](https://python.org), [Rust](https://rust-lang.org), [Javascript](https://nodejs.org/en), [PHP](https://www.php.net/)

#### Databases + Tools

- Oracle, [Postgres](https://www.postgresql.org/), [MySQL](https://www.mysql.com/), MSSQL, [Docker](www.docker.com), [Nagios](https://www.nagios.org/), [Airflow](https://airflow.apache.org/)

#### Certifications

- [AWS Certified Cloud Practicioner](https://aws.amazon.com/certification/certified-cloud-practitioner/)
- [AWS Solution Architect Associate](https://aws.amazon.com/certification/certified-solutions-architect-associate/)
- [Crestron Certified Technician](https://www.crestron.com/Training-Events/Training)
