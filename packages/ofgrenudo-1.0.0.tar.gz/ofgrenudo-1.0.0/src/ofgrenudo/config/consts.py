DISCORD = "@grenudo"
WEBSITE = "https://unorthodoxdev.net"

BASHRC = "/.bashrc"
BASHRC_BACK = "/.bashrc.back"
ZSHRC = "/.zshrc"
ZSHRC_BACK = "/.zshrc.back"
