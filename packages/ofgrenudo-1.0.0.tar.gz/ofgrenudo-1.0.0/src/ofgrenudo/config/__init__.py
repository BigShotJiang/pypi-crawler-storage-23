from .alias import COMMANDS_ALIAS as COMMANDS_ALIAS
from .alias import LS_ALIAS as LS_ALIAS
from .consts import BASHRC as BASHRC
from .consts import BASHRC_BACK as BASHRC_BACK
from .consts import DISCORD as DISCORD
from .consts import WEBSITE as WEBSITE
from .consts import ZSHRC as ZSHRC
from .consts import ZSHRC_BACK as ZSHRC_BACK
