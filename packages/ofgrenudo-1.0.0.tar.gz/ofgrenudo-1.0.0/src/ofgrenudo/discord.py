from ofgrenudo.config import DISCORD


def display_discord():
    print(f"Discord: {DISCORD}")
