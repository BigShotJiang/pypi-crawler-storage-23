# VideoSDK CometAPI Plugin

Agent Framework plugin for real-time LLM, STT, and TTS services from CometAPI, allowing you to access multiple services using a single API key.

## Installation

```bash
pip install videosdk-plugins-cometapi
```