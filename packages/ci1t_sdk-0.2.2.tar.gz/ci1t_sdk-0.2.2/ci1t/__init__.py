"""CI-1T Python SDK -- stability monitoring for any numeric signal.

    pip install ci1t

Quick start::

    import ci1t

    # Evaluate scores
    client = ci1t.Client()
    result = client.evaluate([0.8, 0.85, 0.79])
    print(result.episodes[0].status)  # "Stable"

    # Monitor a fleet
    with ci1t.Monitor("my-fleet", nodes=["gpt-4o", "claude"]) as mon:
        mon.push({"gpt-4o": 0.92, "claude": 0.87})
        mon.push({"gpt-4o": 0.89, "claude": 0.85})
        mon.push({"gpt-4o": 0.91, "claude": 0.86})

    # Watch a function
    @ci1t.watch("my-model")
    def predict(text):
        return model.predict(text)
"""

__version__ = "0.2.2"

from .client import Client
from .monitor import Monitor, watch
from .types import (
    AL_LABELS,
    CI_DRIFT,
    CI_FLIP,
    CI_STABLE,
    Episode,
    EvaluateResult,
    FleetEvaluateResult,
    FleetNode,
    FleetSnapshot,
    RoundResult,
    SessionInfo,
    to_q16,
)

__all__ = [
    "__version__",
    # Core classes
    "Client",
    "Monitor",
    "watch",
    # Response types
    "Episode",
    "EvaluateResult",
    "FleetEvaluateResult",
    "FleetNode",
    "FleetSnapshot",
    "RoundResult",
    "SessionInfo",
    # Utilities
    "to_q16",
    # Constants
    "AL_LABELS",
    "CI_STABLE",
    "CI_DRIFT",
    "CI_FLIP",
]
