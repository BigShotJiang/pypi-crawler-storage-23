# moco-py

Python client library for the [MOCO ERP API](https://www.mocoapp.com).

## Installation

```bash
pip install moco-py
```

## Quick Start

```python
from moco_py import Moco

client = Moco(domain="yourcompany", api_key="your-api-key")
```
