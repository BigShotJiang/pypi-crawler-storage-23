ffsim
=====

.. automodule:: ffsim
   :members:
   :show-inheritance:
