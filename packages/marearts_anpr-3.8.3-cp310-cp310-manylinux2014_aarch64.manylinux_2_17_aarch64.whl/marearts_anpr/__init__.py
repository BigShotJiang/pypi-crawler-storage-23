"""MareArts ANPR - License Plate Detection and Recognition"""

from ._version import __version__
from .region_aliases import (
    normalize_region_alias,
    to_api_region,
    to_internal_region,
)

from .marearts_anpr import (
    marearts_anpr_from_pil,
    marearts_anpr_from_image_file, 
    marearts_anpr_from_cv2
)

from .marearts_anpr_d import ma_anpr_detector
from .marearts_anpr_d_v14 import ma_anpr_detector_v14
from .marearts_anpr_r_v14 import ma_anpr_ocr_v14 as _ma_anpr_ocr_v14
from .marearts_anpr_r_v15 import ma_anpr_ocr_v15 as _ma_anpr_ocr_v15
from .marearts_anpr_r_wrapper import ma_anpr_ocr as _ma_anpr_ocr  # Unified wrapper (v14/v15)
from .marearts_anpr_p import validate_user_key, validate_user_key_with_signature, download_anpr_ocr_v14_model, download_anpr_ocr_v15_model


def ma_anpr_ocr_v14(model_name, region, *args, **kwargs):
    """Create V14 OCR with robust region alias normalization."""
    return _ma_anpr_ocr_v14(model_name, to_internal_region(region), *args, **kwargs)


def ma_anpr_ocr_v15(model_name, region, *args, **kwargs):
    """Create V15 OCR with robust region alias normalization."""
    return _ma_anpr_ocr_v15(model_name, to_internal_region(region), *args, **kwargs)


def ma_anpr_ocr(model_name, region, *args, **kwargs):
    """Create unified OCR (v14/v15) with robust region alias normalization."""
    return _ma_anpr_ocr(model_name, to_internal_region(region), *args, **kwargs)

__all__ = [
    "__version__",
    "marearts_anpr_from_pil",
    "marearts_anpr_from_image_file",
    "marearts_anpr_from_cv2",
    "ma_anpr_detector",
    "ma_anpr_detector_v14",
    "ma_anpr_ocr",
    "ma_anpr_ocr_v14",
    "ma_anpr_ocr_v15",
    "normalize_region_alias",
    "to_internal_region",
    "to_api_region",
    "validate_user_key",
    "validate_user_key_with_signature",
    "download_anpr_ocr_v14_model",
    "download_anpr_ocr_v15_model"
]
