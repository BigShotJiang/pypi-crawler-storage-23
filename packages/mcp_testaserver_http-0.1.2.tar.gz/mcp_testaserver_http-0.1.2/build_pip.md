python3 -m pip install --upgrade build
python3 -m pip install --upgrade twine

#Subida a test
python3 -m build
python3 -m twine upload --repository testpypi dist/*

#Subida a produccion
python3 -m build
python3 -m twine upload dist/*