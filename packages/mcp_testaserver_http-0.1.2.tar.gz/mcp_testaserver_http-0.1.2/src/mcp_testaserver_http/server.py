"""
Servidor MCP local (transporte stdio) que obtiene y ejecuta tools
desde un servidor HTTP externo.

Flujo:
  1. Al iniciar, consulta GET /tools para obtener la lista de tools.
  2. Registra cada tool en el servidor MCP dinámicamente.
  3. Cuando Claude invoca una tool, hace POST /tools/{name} con los args.
  4. Devuelve el resultado a Claude.

Uso:
  python mcp_server.py
  (el cliente MCP se comunica por stdin/stdout)
"""

import asyncio
import json
import sys
import httpx
import os
from dotenv import load_dotenv
from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp import types

# Cargar variables de entorno desde el archivo .env
load_dotenv(override=True)

# ---------------------------------------------------------------------------
# Configuración
# ---------------------------------------------------------------------------

# Configuración obtenida de variables de entorno (con valores por defecto por seguridad)
HTTP_SERVER_BASE_URL = os.getenv("HTTP_SERVER_BASE_URL", "http://127.0.0.1:8000")
TOKEN_COMPANY = os.getenv("TOKEN_COMPANY", "")

if TOKEN_COMPANY:
    HTTP_HEADERS = {
        "API-TOKEN": TOKEN_COMPANY
    }

else:
    API_KEY = os.getenv("API_KEY", "")
    APLICACION = os.getenv("APLICACION", "")
    HTTP_HEADERS = {
        "API-KEY": API_KEY,
        "APLICACION": APLICACION
    }

# ---------------------------------------------------------------------------
# Helpers HTTP
# ---------------------------------------------------------------------------

async def fetch_tools(client: httpx.AsyncClient) -> list[dict]:
    """Obtiene la lista de tools desde el servidor HTTP."""
    if TOKEN_COMPANY:
        response = await client.get(f"{HTTP_SERVER_BASE_URL}/tools")
        response.raise_for_status()
        try:
            return response.json()["data"]["tools"]
        except Exception as e:
            return response.text
    else:
        response = await client.get(f"{HTTP_SERVER_BASE_URL}/api/v3/mcp/tools")
        response.raise_for_status()

        return response.json()["tools"]


async def call_tool(client: httpx.AsyncClient, name: str, args: dict) -> dict:
    """Ejecuta una tool en el servidor HTTP y devuelve el resultado."""
    if TOKEN_COMPANY:
        args['tool_name'] = name
        response = await client.post(
            f"{HTTP_SERVER_BASE_URL}/tools",
            json=args,
        )
        response.raise_for_status()
        return response.json()["data"]["result"]
    else:
        response = await client.post(
            f"{HTTP_SERVER_BASE_URL}/tools/{name}",
            json=args,
        )
        response.raise_for_status()

        return response.json()["result"]


# ---------------------------------------------------------------------------
# Servidor MCP
# ---------------------------------------------------------------------------

async def main():
    server = Server("http-bridge-mcp")

    # Usamos un cliente HTTP persistente durante toda la vida del servidor
    async with httpx.AsyncClient(timeout=30.0, verify=False, headers=HTTP_HEADERS) as http_client:
        # --- Carga dinámica de tools desde el HTTP server ---
        try:
            remote_tools = await fetch_tools(http_client)
        except Exception as e:
            print(f"[MCP] Error al conectar con el servidor HTTP: {e}", file=sys.stderr)
            sys.exit(1)

        print(
            f"[MCP] {len(remote_tools)} tools cargadas desde {HTTP_SERVER_BASE_URL}",
            file=sys.stderr,
        )

        # --- Handler: listar tools ---
        @server.list_tools()
        async def handle_list_tools() -> list[types.Tool]:
            """Convierte la definición HTTP en objetos Tool de MCP."""
            return [
                types.Tool(
                    name=t["name"],
                    description=t["description"],
                    inputSchema=t["inputSchema"],
                )
                for t in remote_tools
            ]

        # --- Handler: ejecutar una tool ---
        @server.call_tool()
        async def handle_call_tool(
            name: str, arguments: dict
        ) -> list[types.TextContent]:
            """Delega la ejecución al servidor HTTP."""
            # Verificar que la tool existe
            known_names = {t["name"] for t in remote_tools}
            if name not in known_names:
                raise ValueError(f"Tool desconocida: '{name}'")

            try:
                result = await call_tool(http_client, name, arguments)
            except httpx.HTTPStatusError as e:
                error_detail = e.response.json().get("detail", str(e))
                raise RuntimeError(f"Error del servidor HTTP: {error_detail}")

            return [
                types.TextContent(
                    type="text",
                    text=json.dumps(result, ensure_ascii=False, indent=2),
                )
            ]

        # --- Arrancar el servidor MCP en stdio ---
        print("[MCP] Servidor iniciado. Esperando conexión del cliente...", file=sys.stderr)
        async with stdio_server() as (read_stream, write_stream):
            await server.run(
                read_stream,
                write_stream,
                server.create_initialization_options(),
            )


def run():
    """Entry point for the console script."""
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass

if __name__ == "__main__":
    run()

