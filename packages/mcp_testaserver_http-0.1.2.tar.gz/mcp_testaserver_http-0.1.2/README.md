# MCP ↔ HTTP Bridge

Servidor MCP local (stdio) que expone dinámicamente las tools de un servidor HTTP externo.

```
Cliente MCP (Claude Code / CLI)
        ↕  stdio
  mcp_server.py   ← servidor MCP local
        ↕  HTTP
  http_server.py  ← tu backend con las tools
```

---

## Requisitos

```bash
pip install mcp httpx fastapi uvicorn
```

---

## Arrancar

### 1. Servidor HTTP (en una terminal)

```bash
python http_server.py
# → http://127.0.0.1:8000
```

Puedes verificar las tools disponibles en:
```
GET http://127.0.0.1:8000/tools
```

### 2. Servidor MCP (lo gestiona el cliente)

El servidor MCP se lanza automáticamente por el cliente MCP vía stdio.  
Configúralo en `~/.claude.json` (Claude Code):

```json
{
  "mcpServers": {
    "http-bridge": {
      "command": "python",
      "args": ["/ruta/absoluta/a/mcp_server.py"]
    }
  }
}
```

---

## Añadir tus propias tools

Solo tienes que modificar `http_server.py`:

1. Añade un dict a la lista `TOOLS` con `name`, `description` e `inputSchema`.
2. Añade una función `run_mi_tool(args)` con la lógica.
3. Registra la función en `TOOL_HANDLERS`.

El servidor MCP las detectará automáticamente sin cambios.

```python
# Ejemplo en http_server.py

TOOLS.append({
    "name": "reverse_text",
    "description": "Invierte un texto.",
    "inputSchema": {
        "type": "object",
        "properties": {
            "text": {"type": "string"}
        },
        "required": ["text"]
    }
})

def run_reverse_text(args):
    return {"result": args["text"][::-1]}

TOOL_HANDLERS["reverse_text"] = run_reverse_text
```

---

## Contrato HTTP

| Método | Ruta              | Descripción                                |
|--------|-------------------|--------------------------------------------|
| GET    | `/tools`          | Lista todas las tools disponibles          |
| POST   | `/tools/{name}`   | Ejecuta la tool `name` con el body JSON    |

**Respuesta de `/tools`:**
```json
{
  "tools": [
    {
      "name": "calculator",
      "description": "...",
      "inputSchema": { ... }
    }
  ]
}
```

**Respuesta de `/tools/{name}`:**
```json
{ "result": { ... } }
```

---

## Estructura de archivos

```
.
├── http_server.py   # Backend HTTP con las tools
├── mcp_server.py    # Servidor MCP local (stdio)
└── README.md
```

# Para inspeccionar el servidor mcp
npx @modelcontextprotocol/inspector python C:\\Users\\acamp\\Documents\\SynologyDrive\\mcp-http-server\\mcp_server.py
npx @modelcontextprotocol/inspector python /home/chrzrd/SynologyDrive/mcp-testaserver-http/mcp_server.py