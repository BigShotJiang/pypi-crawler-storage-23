"""
Servidor HTTP (FastAPI) que expone tools para ser consumidas por el servidor MCP.

Contrato esperado:
  GET  /tools        → lista de tools disponibles (nombre, descripción, inputSchema)
  POST /tools/{name} → ejecuta una tool con el body JSON como argumentos
"""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Any
import math

app = FastAPI(title="HTTP Tool Server")


# ---------------------------------------------------------------------------
# Definición de tools
# Cada tool tiene: name, description, inputSchema (JSON Schema)
# ---------------------------------------------------------------------------

TOOLS = [
    {
        "name": "calculator",
        "description": "Realiza operaciones matemáticas básicas (suma, resta, multiplicación, división).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "operation": {
                    "type": "string",
                    "enum": ["add", "subtract", "multiply", "divide"],
                    "description": "Operación a realizar.",
                },
                "a": {"type": "number", "description": "Primer operando."},
                "b": {"type": "number", "description": "Segundo operando."},
            },
            "required": ["operation", "a", "b"],
        },
    },
    {
        "name": "get_weather",
        "description": "Devuelve el clima simulado para una ciudad.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "city": {"type": "string", "description": "Nombre de la ciudad."},
            },
            "required": ["city"],
        },
    },
    {
        "name": "text_stats",
        "description": "Cuenta palabras, caracteres y oraciones de un texto.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "text": {"type": "string", "description": "Texto a analizar."},
            },
            "required": ["text"],
        },
    },
]


# ---------------------------------------------------------------------------
# Lógica de ejecución de cada tool
# ---------------------------------------------------------------------------

def run_calculator(args: dict) -> dict:
    a, b = args["a"], args["b"]
    op = args["operation"]
    if op == "add":
        result = a + b
    elif op == "subtract":
        result = a - b
    elif op == "multiply":
        result = a * b
    elif op == "divide":
        if b == 0:
            raise ValueError("División por cero.")
        result = a / b
    else:
        raise ValueError(f"Operación desconocida: {op}")
    return {"result": result}


def run_get_weather(args: dict) -> dict:
    # Datos simulados; aquí conectarías una API real
    city = args["city"].lower()
    fake_db = {
        "madrid": {"temp_c": 18, "condition": "Soleado", "humidity": 40},
        "buenos aires": {"temp_c": 25, "condition": "Parcialmente nublado", "humidity": 65},
        "ciudad de méxico": {"temp_c": 22, "condition": "Lluvioso", "humidity": 80},
    }
    data = fake_db.get(city, {"temp_c": 20, "condition": "Despejado", "humidity": 50})
    return {"city": args["city"], **data}


def run_text_stats(args: dict) -> dict:
    text = args["text"]
    words = len(text.split())
    chars = len(text)
    sentences = text.count(".") + text.count("!") + text.count("?")
    return {"words": words, "characters": chars, "sentences": max(sentences, 1)}


TOOL_HANDLERS = {
    "calculator": run_calculator,
    "get_weather": run_get_weather,
    "text_stats": run_text_stats,
}


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------

@app.get("/tools")
def list_tools():
    """Devuelve la lista de tools disponibles."""
    return {"tools": TOOLS}


@app.post("/tools/{tool_name}")
def execute_tool(tool_name: str, args: dict[str, Any]):
    """Ejecuta una tool por nombre con los argumentos dados."""
    handler = TOOL_HANDLERS.get(tool_name)
    if not handler:
        raise HTTPException(status_code=404, detail=f"Tool '{tool_name}' no encontrada.")
    try:
        result = handler(args)
        return {"result": result}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error interno: {e}")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8000)
