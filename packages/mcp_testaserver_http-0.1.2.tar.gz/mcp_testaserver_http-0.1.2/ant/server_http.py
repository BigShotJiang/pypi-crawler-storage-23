import asyncio
from mcp.server import Server
from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.routing import Route
import uvicorn
from starlette.requests import Request
from starlette.middleware.base import BaseHTTPMiddleware
import time

# Initialize standard MCP server
server = Server("Local HTTP MCP Server")

@server.list_tools()
async def handle_list_tools():
    return [
        {
            "name": "hello_mcp",
            "description": "A simple tool to verify the connection.",
            "inputSchema": {
                "type": "object",
                "properties": {}
            }
        }
    ]

@server.call_tool()
async def handle_call_tool(name, arguments):
    if name == "hello_mcp":
        return [
            {
                "type": "text",
                "text": "Hello from the local MCP HTTP server on port 8000!"
            }
        ]
    raise ValueError(f"Unknown tool: {name}")

sse = SseServerTransport("/messages")

async def handle_sse(request):
    async with sse.connect_sse(request.scope, request.receive, request._send) as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())

async def handle_messages(request):
    await sse.handle_post_message(request.scope, request.receive, request._send)


async def handle_messages2(request):
    await sse.handle_post_message('request.scope', 'request.receive', 'request._send')


class RequestLoggerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        print(f"Incoming request: {request.method} {request.url.path}")
        start_time = time.time()
        response = await call_next(request)
        process_time = time.time() - start_time
        print(f"Request {request.method} {request.url.path} completed in {process_time:.4f}s with status {response.status_code}")
        return response

app = Starlette(
    debug=True,
    routes=[
        Route("/sse", endpoint=handle_sse),
        Route("/messages", endpoint=handle_messages, methods=["POST"]),
        Route("/", endpoint=handle_messages2, methods=["POST"]),

    ],
)
app.add_middleware(RequestLoggerMiddleware)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8000)




