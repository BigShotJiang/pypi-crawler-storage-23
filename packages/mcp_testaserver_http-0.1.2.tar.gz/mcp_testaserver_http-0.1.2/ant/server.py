from mcp.server.fastmcp import FastMCP
import uvicorn

# Initialize FastMCP server
mcp = FastMCP("MCP HTTP Test Server")

@mcp.tool()
def echo_message(message: str) -> str:
    """
    Echoes back the message provided.
    
    Args:
        message: The message to echo.
    """
    return f"Echo: OK"

@mcp.tool()
def get_system_status() -> str:
    """
    Returns the current status of the MCP server.
    """
    return "The MCP server is running and healthy on HTTP/SSE."

if __name__ == "__main__":
    # FastMCP handles SSE transport internally when transport="sse" is specified.
    # It will start a server (typically using uvicorn) automatically.
    mcp.run(transport="sse")
