from __future__ import annotations

import argparse
import json
import os
from dataclasses import asdict
from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from .client import BrunataClient
from .errors import BrunataError
from .models import ReadingKind


def _env(name: str, default: str | None = None) -> str | None:
    v = os.environ.get(name)
    return v if v not in (None, "") else default


def _load_config() -> tuple[str, str, str, str]:
    # Avoid python-dotenv's stack-frame based auto-discovery (can fail in some environments).
    load_dotenv(dotenv_path=Path.cwd() / ".env", override=False)
    base_url = _env("BRUNATA_BASE_URL", "https://nutzerportal.brunata-muenchen.de")
    username = _env("BRUNATA_USERNAME")
    password = _env("BRUNATA_PASSWORD")
    sap_client = _env("BRUNATA_SAP_CLIENT", "201") or "201"
    if not username or not password:
        raise SystemExit("Missing BRUNATA_USERNAME/BRUNATA_PASSWORD in environment or .env")
    return base_url, username, password, sap_client


def _write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _sanitize_for_disk(text: str) -> str:
    # Best-effort redaction to avoid leaking secrets in dumps.
    redactions = [
        _env("BRUNATA_USERNAME"),
        _env("BRUNATA_PASSWORD"),
    ]
    out = text
    for r in redactions:
        if r:
            out = out.replace(r, "***REDACTED***")
    return out


async def _cmd_login(_: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        await c.login()
        info = c.last_login_attempt
        if info:
            print(json.dumps(asdict(info), indent=2))
        else:
            print("Login succeeded.")
    return 0


async def _cmd_dump_pages(args: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    out_dir = Path(args.output_dir) if args.output_dir else None

    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        await c.login()
        account = await c.get_account()
        dates = await c.get_dashboard_dates()

        payload = {"account": account, "dashboard_dates": dates}
        print(json.dumps(payload, indent=2))
        if out_dir:
            _write_text(
                out_dir / "account.json",
                _sanitize_for_disk(json.dumps(account, indent=2)),
            )
            _write_text(
                out_dir / "dashboard_dates.json",
                _sanitize_for_disk(json.dumps(dates, indent=2)),
            )
    return 0


async def _cmd_readings(args: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    kind = ReadingKind(args.kind)
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        readings = await c.get_readings(kind)
        payload: list[dict[str, Any]] = [r.model_dump(mode="json") for r in readings]
        print(json.dumps(payload, indent=2))
    return 0


async def _cmd_readings_all(args: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    kind = ReadingKind(args.kind)
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        series = await c.get_monthly_consumptions(kind)
        payload: dict[str, list[dict[str, Any]]] = {
            ct: [r.model_dump(mode="json") for r in readings] for ct, readings in series.items()
        }
        print(json.dumps(payload, indent=2))
    return 0


async def _cmd_meter(_: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        readings = await c.get_meter_readings()
        payload: dict[str, dict[str, Any]] = {
            ct: r.model_dump(mode="json") for ct, r in readings.items()
        }
        print(json.dumps(payload, indent=2))
    return 0


async def _cmd_current(args: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    kind = ReadingKind(args.kind)
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        cur = await c.get_current_consumption(kind)
        print(json.dumps(cur.model_dump(mode="json"), indent=2))
    return 0


async def _cmd_comparison(_: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        data = await c.get_consumption_comparison()
        payload: dict[str, dict[str, Any]] = {
            ct: r.model_dump(mode="json") for ct, r in data.items()
        }
        print(json.dumps(payload, indent=2))
    return 0


async def _cmd_forecast(_: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        data = await c.get_consumption_forecast()
        payload: dict[str, dict[str, Any]] = {
            ct: r.model_dump(mode="json") for ct, r in data.items()
        }
        print(json.dumps(payload, indent=2))
    return 0


async def _cmd_rooms(_: argparse.Namespace) -> int:
    base_url, username, password, sap_client = _load_config()
    async with BrunataClient(
        base_url=base_url, username=username, password=password, sap_client=sap_client
    ) as c:
        data = await c.get_room_consumption()
        payload: dict[str, list[dict[str, Any]]] = {
            ct: [r.model_dump(mode="json") for r in rooms] for ct, rooms in data.items()
        }
        print(json.dumps(payload, indent=2))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="brunata")
    sub = p.add_subparsers(dest="cmd", required=True)

    p_login = sub.add_parser("login", help="Attempt login and print basic diagnostics.")
    p_login.set_defaults(func=_cmd_login)

    p_dump = sub.add_parser("dump-pages", help="Login, then dump key OData responses.")
    p_dump.add_argument("--output-dir", type=str, default=None)
    p_dump.set_defaults(func=_cmd_dump_pages)

    p_readings = sub.add_parser("readings", help="Best-effort reading extraction.")
    p_readings.add_argument("--kind", choices=[k.value for k in ReadingKind], required=True)
    p_readings.set_defaults(func=_cmd_readings)

    p_readings_all = sub.add_parser(
        "readings-all", help="Fetch monthly series for all cost types (HZ../WW..)."
    )
    p_readings_all.add_argument("--kind", choices=[k.value for k in ReadingKind], required=True)
    p_readings_all.set_defaults(func=_cmd_readings_all)

    p_meter = sub.add_parser("meter", help="Fetch Zählerstand (cumulative meter readings).")
    p_meter.set_defaults(func=_cmd_meter)

    p_current = sub.add_parser("current", help="Fetch dashboard 'aktueller Verbrauch' (kWh).")
    p_current.add_argument("--kind", choices=[k.value for k in ReadingKind], required=True)
    p_current.set_defaults(func=_cmd_current)

    p_comparison = sub.add_parser(
        "comparison", help="Fetch building/national consumption comparison (kWh/m²)."
    )
    p_comparison.set_defaults(func=_cmd_comparison)

    p_forecast = sub.add_parser(
        "forecast", help="Fetch forecast and year-over-year comparison."
    )
    p_forecast.set_defaults(func=_cmd_forecast)

    p_rooms = sub.add_parser("rooms", help="Fetch room-level consumption breakdown.")
    p_rooms.set_defaults(func=_cmd_rooms)

    return p


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        import asyncio

        raise SystemExit(asyncio.run(args.func(args)))
    except BrunataError as e:
        raise SystemExit(f"Error: {e}") from e

