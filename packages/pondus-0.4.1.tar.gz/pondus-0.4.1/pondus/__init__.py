"""pondus is a Rust CLI. Install via: cargo install pondus

See https://crates.io/crates/pondus
"""
