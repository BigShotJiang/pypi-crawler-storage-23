# OpenAB — Open Agent Bridge
__version__ = "0.1.5"
