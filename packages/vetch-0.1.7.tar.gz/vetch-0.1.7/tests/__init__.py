"""Vetch SDK test suite."""
