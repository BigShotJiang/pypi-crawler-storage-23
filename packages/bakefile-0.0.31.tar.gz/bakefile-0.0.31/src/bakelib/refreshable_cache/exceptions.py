class RefreshNeededError(Exception):
    """Raised when a cached value needs to be refreshed."""
