from bake.cli.bake.main import main

__all__ = ["main"]
