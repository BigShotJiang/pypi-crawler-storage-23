from dataclasses import dataclass
from uuid import uuid4

@dataclass(frozen=True)
class VoronoiEdge:
    edgeId: uuid4
    
    vertex0Id: uuid4
    vertex1Id: uuid4

    # The length of the edge - distance between its two vertices.
    edgeLength: float

    def sameVertices(self, other):
        return (self.vertex0Id == other.vertex0Id and self.vertex1Id == other.vertex1Id) or (self.vertex0Id == other.vertex1Id and self.vertex1Id == other.vertex0Id)

    def __repr__(self) -> str:
        return f'{{"vertex0Id": "{str(self.vertex0Id)}", "vertex1Id": "{str(self.vertex1Id)}", "edgeLength": {str(self.edgeLength)}}}'
    
    def __eq__(self, other):
        return self.edgeLength == other.edgeLength and self.sameVertices(other)