from dataclasses import dataclass
from uuid import uuid4

from ..edges.VoronoiEdge import VoronoiEdge

@dataclass(frozen=True)
class VoronoiRegion:
    siteId: uuid4
    
    edges: tuple[VoronoiEdge]
    edgesToNeighbors: dict[uuid4, uuid4]

    def neighbors(self) -> tuple[uuid4]:
        return tuple(self.edgesToNeighbors.values())
    
    def __repr__(self) -> str:
        edgeIds = ",".join(tuple(f"\"{str(edge.edgeId)}\"" for edge in self.edges))
        return f'{{"siteId": "{str(self.siteId)}", "edges": [{edgeIds}]}}'