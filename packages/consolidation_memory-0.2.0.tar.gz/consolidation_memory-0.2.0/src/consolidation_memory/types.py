"""Result types for consolidation-memory operations."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class ContentType(str, Enum):
    """Valid episode content types."""
    EXCHANGE = "exchange"
    FACT = "fact"
    SOLUTION = "solution"
    PREFERENCE = "preference"


@dataclass
class StoreResult:
    """Result of a memory store operation."""

    status: str  # "stored" | "duplicate_detected"
    id: str | None = None
    content_type: str | None = None
    tags: list[str] = field(default_factory=list)
    existing_id: str | None = None
    similarity: float | None = None
    message: str | None = None


@dataclass
class RecallResult:
    """Result of a memory recall operation."""

    episodes: list[dict] = field(default_factory=list)
    knowledge: list[dict] = field(default_factory=list)
    total_episodes: int = 0
    total_knowledge_topics: int = 0
    message: str | None = None
    warnings: list[str] = field(default_factory=list)


@dataclass
class ForgetResult:
    """Result of a memory forget operation."""

    status: str  # "forgotten" | "not_found"
    id: str = ""


@dataclass
class StatusResult:
    """Result of a memory status query."""

    episodic_buffer: dict = field(default_factory=dict)
    knowledge_base: dict = field(default_factory=dict)
    last_consolidation: dict | None = None
    embedding_backend: str = ""
    embedding_model: str = ""
    faiss_index_size: int = 0
    faiss_tombstones: int = 0
    db_size_mb: float = 0.0
    version: str = ""
    health: dict = field(default_factory=dict)
    consolidation_metrics: list[dict] = field(default_factory=list)
    consolidation_quality: dict = field(default_factory=dict)


@dataclass
class ExportResult:
    """Result of a memory export operation."""

    status: str  # "exported"
    path: str = ""
    episodes: int = 0
    knowledge_topics: int = 0


@dataclass
class CorrectResult:
    """Result of a knowledge correction operation."""

    status: str  # "corrected" | "not_found" | "error"
    filename: str | None = None
    title: str | None = None
    message: str | None = None


@dataclass
class SearchResult:
    """Result of a keyword/metadata search operation."""

    episodes: list[dict] = field(default_factory=list)
    total_matches: int = 0
    query: str | None = None
    message: str | None = None


@dataclass
class BatchStoreResult:
    """Result of a batch memory store operation."""

    status: str  # "stored"
    stored: int = 0
    duplicates: int = 0
    results: list[dict] = field(default_factory=list)
