"""Generate the RDF ontology and the SHACL schema corresponding to the meta-model."""
