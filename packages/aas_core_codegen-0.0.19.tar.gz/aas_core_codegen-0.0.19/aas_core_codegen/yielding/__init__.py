"""Translate control flows to co-routines where they are not natively supported."""
