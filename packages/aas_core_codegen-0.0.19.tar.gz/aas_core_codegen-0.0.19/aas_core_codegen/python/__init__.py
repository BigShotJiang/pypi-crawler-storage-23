"""Generate Python code based on the intermediate meta-model."""
