"""Generate Java code based on the intermediate meta-model."""
