"""Generate Java data structures to represent an AAS."""

from aas_core_codegen.java.structure import _generate

verify = _generate.verify
generate = _generate.generate
