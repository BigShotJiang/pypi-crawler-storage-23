"""Generate Java code for de/serialization of enumerations."""
from aas_core_codegen.java.stringification import _generate

generate = _generate.generate
