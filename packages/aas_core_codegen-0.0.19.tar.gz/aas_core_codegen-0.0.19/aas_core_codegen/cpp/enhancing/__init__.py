"""Generate C++ code for enhancing model classes."""
from aas_core_codegen.cpp.enhancing import _generate

generate_header = _generate.generate_header
