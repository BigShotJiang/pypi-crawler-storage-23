"""Generate XML Schema Definition (XSD) corresponding to the meta-model."""
