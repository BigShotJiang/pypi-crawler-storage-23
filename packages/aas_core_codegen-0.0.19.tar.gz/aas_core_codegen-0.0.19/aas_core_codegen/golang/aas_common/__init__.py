"""Generate Golang code for common functions."""
from aas_core_codegen.golang.aas_common import _generate

generate = _generate.generate
