"""Generate Golang code based on the intermediate meta-model."""
