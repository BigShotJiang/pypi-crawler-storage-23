"""Generate Golang code for enhancing model classes."""
from aas_core_codegen.golang.enhancing import _generate

generate = _generate.generate
