"""Generate ProtoBuf files based on the intermediate meta-model."""
