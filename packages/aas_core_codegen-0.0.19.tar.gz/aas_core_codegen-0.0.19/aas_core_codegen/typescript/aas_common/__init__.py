"""Generate TypeScript code for common functions."""
from aas_core_codegen.typescript.aas_common import _generate

generate = _generate.generate
