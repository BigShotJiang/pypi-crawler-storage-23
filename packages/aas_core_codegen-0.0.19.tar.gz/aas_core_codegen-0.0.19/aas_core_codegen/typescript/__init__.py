"""Generate TypeScript code based on the intermediate meta-model."""
