"""Generate TypeScript constants corresponding to the constants of the meta-model."""

from aas_core_codegen.typescript.constants import _generate

generate = _generate.generate
