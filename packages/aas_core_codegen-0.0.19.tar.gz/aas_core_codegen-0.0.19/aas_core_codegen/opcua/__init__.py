"""Generate the OPC UA Schema node set corresponding to the meta-model."""
