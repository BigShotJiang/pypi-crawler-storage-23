# pwrforge
pwrforge project was written by PWR team and is continuation of Spyrosoft Solutions S.A. scargo project. Find more information at [tft.pwr.edu.pl](https://tft.pwr.edu.pl/).
<table align="center">
  <tr>
    <td align="center">
      <img src="docs/source/_static/tft-logo.png" alt="tft" width="200"/>
    </td>
    <td align="center">
      <img src="docs/source/_static/w12-logo.png" alt="w12" width="105"/>
    </td>
  </tr>
  <tr>
    <td colspan="2" align="center">
      <img src="docs/source/_static/pwr_logo_color.png" alt="pwr" width="330"/>
    </td>
  </tr>
</table>

# Overview
This is the documentation for pwrforge - a Python-based C/C++ package and software development life cycle manager inspired by RUST cargo idea.

pwrforge can:

- Create a new project (binary or library) for embedded systems and x86
- Build the project
- Run static code analyzers
- Fix chosen problem automatically based on the checker analysis
- Run unit tests
- Generate documentation from the source code
- Work with the predefined docker environment depending on the chosen architecture
- Generate mocks and test skeletetons

# Installation
## Installing pwrforge on Ubuntu 24.04+ (PEP 668-compliant systems)

Ubuntu 24.04 and newer follow PEP 668, which restricts the use of pip in the system Python environment to prevent accidental damage to system-managed packages.

To safely install pwrforge, use a virtual environment:

```
python3.12 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install pwrforge
```

This ensures isolated and conflict-free usage of pwrforge without requiring elevated privileges or --break-system-packages.

## Install on ubuntu <=22.04, windows or macos
pwrforge is available on [pypi](https://pypi.org/project/pwrforge/), so you can install it with pip:

```pip install pwrforge```

If system does not find 'pwrforge' command after installing, add the installation directory to your env paths. On Ubuntu you can find installation directory by running:

```$ pip show "pwrforge"```

Then add to PATH e.g.:

```$ export PATH=~/.local/bin:${PATH}```

# Working with pwrforge
![pwrforge flow animation](docs/source/_static/pwrforge_flow_docker.svg)

# Project dependencies
## Working with docker (recommended)
- docker with docker-compose - https://docs.docker.com/engine/install/ubuntu/
- pip
- python3 - `sudo apt install python3.12-venv python3.12-distutils -y`

# Work environment
You can always change work environment between docker or native after project is created.
Just edit the pwrforge.toml file ([project] -> build-env = "docker" or build-env = "native").
For it may be needed dependencies manually which are included in `.devcontainer/Dockerfile`

Its recommended to work in virtual environment (venv) or conda environment e.g.:
- pip install virtualenv
- virtualenv -p /usr/bin/python3.12 venv
- source venv/bin/activate


## Working in docker
1) If you create a new project, run `docker compose run pwrforge-dev` to run project development image depending on chosen architecture. All dependencies should be already there.
Run pwrforge commands as you would do natively.

2) If you create a project with --docker flag (`pwrforge new <my_proj> --docker ...`) or with any docker flag, by default each pwrforge command will be triggered in docker.

## Working natively
1) Create a project with --no-docker flag (`pwrforge new <my_proj> --no-docker ...`).

## Create the requirements for docker env
From version 2.3.2 the pwrforge is install in docker but overload by docker compose volume data, to get present version from your native env.
During deployment the requirements file is created using following command

 - `pip-compile --all-extras --output-file=ci/requirements.txt pyproject.toml`
 - `pip-compile --output-file=pwrforge/file_generators/templates/docker/requirements.txt.j2 pyproject.toml`

to have all newest dependencies. This solutions allow as to have pwrforge install in docker for ci/cd and be able to use newest features without official releases.  

## Testing custom pwrforge generated project locally
You can make changes in pwrforge and install it locally using ```pip install .``` command when you are in the main project folder.
To test the custom pwrforge version and have this custom pwrforge available also inside the docker (crucial for testing), in created project update  docker-compose.yaml:

    volumes:

      - ..:/workspace
      - /dev:/dev
      - ~/.local/lib/python3.12/site-packages/pwrforge:/usr/local/lib/python3.12/dist-packages/pwrforge

Where ```~/.local/lib/python3.12/site-packages/pwrforge``` is a path to pwrforge on your local machine. It the following path is not working, find installation dir using ```pip show pwrforge```.

To keep this setup between ```pwrforge update``` commands, in pwrforge.toml file update also ```update-exclude``` as in following example:

    update-exclude = [".devcontainer/docker-compose.yaml"]

pip install --upgrade build
python -m build --wheel

# Known Issues

## MacOs with ARM processors
- On macOS devices with ARM processors (such as M1 and M3), USB device passthrough to Docker containers is not supported. While most development tasks can be performed within the Docker container, actions that involve direct interaction with USB devices, such as flashing firmware or monitoring hardware, must be executed natively on the host system.

## Windows

- On Windows devices, USB device passthrough is not supported in Docker containers when using Docker Desktop. To work around this limitation, you can use WSL2 (Windows Subsystem for Linux) or run a virtual machine with a Linux distribution like Ubuntu 22.04 to enable USB device access.

# Potential issues

pip install -e ".[dev]"

## Docker permissions on Ubuntu

When using the `docker-compose` command, you may encounter permission errors due to insufficient permissions for accessing the Docker daemon socket. To resolve this issue, ensure that your user has the necessary permissions by adding your user to the `docker` group or granting appropriate access rights to the Docker daemon socket.
To add your user to the `docker` group, run the following command:
- `newgroup docker`
- `sudo usermod -aG docker $USER`
- `sudo systemctl restart docker`

# Contributing

See contributing guide on https://pwr.github.io/pwrforge/contributing.html

