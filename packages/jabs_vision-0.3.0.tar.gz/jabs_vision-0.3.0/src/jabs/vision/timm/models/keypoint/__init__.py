"""Keypoint models for Jabs Vision."""
