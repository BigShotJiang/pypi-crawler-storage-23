"""Instance registry for managing multiple coding agent processes.

Each instance represents an agent process running in a specific git worktree.
The registry provides thread-safe access and callback-based notifications for
output, progress, status changes, and task completion.

State is persisted to <state_dir>/realtime-instances.json so instances (with their
session IDs and worktree paths) survive across voice coding sessions.
"""

from __future__ import annotations

import json
import logging
import threading
import uuid
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_data_dir

STATE_PATH = _default_data_dir() / "realtime-instances.json"


def configure_paths(data_dir: Path) -> None:
    """Set the instance state file path based on the configured data directory."""
    global STATE_PATH
    STATE_PATH = data_dir / "realtime-instances.json"


class InstanceStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    WAITING_INPUT = "waiting_input"
    ERROR = "error"


class InstanceType(Enum):
    CODE = "code"
    SESSION = "session"


@dataclass
class AgentInstance:
    instance_id: str
    branch: str
    worktree_path: str
    agent_type: str = "claude"
    instance_type: InstanceType = InstanceType.CODE
    display_name: str = ""
    session_id: str = ""
    status: InstanceStatus = InstanceStatus.IDLE
    output_buffer: str = ""
    first_call: bool = True
    last_activity: str = ""
    # Pending interactive tool data (AskUserQuestion / EnterPlanMode)
    pending_question: dict[str, Any] | None = None
    # asyncio.Future for waiting on user's answer (set by can_use_tool callback)
    pending_answer: Any = None
    # Background thread's event loop (for cross-thread future resolution)
    _bg_loop: Any = None
    # asyncio.Task running the SDK query (for cancellation)
    _bg_task: Any = None
    # UI widget refs — set by screen.py after panel creation
    header_widget: Any = None
    output_widget: Any = None

    @property
    def display_key(self) -> str:
        """Human-facing identifier: display_name for sessions, branch for code."""
        if self.instance_type == InstanceType.SESSION and self.display_name:
            return self.display_name
        return self.branch


class InstanceRegistry:
    """Thread-safe registry of Claude instances indexed by id and branch."""

    def __init__(self, user_email: str | None = None, user_jwt: str | None = None) -> None:
        self._instances: dict[str, AgentInstance] = {}
        self._branch_index: dict[str, str] = {}
        self._lock = threading.Lock()
        self._save_timer: threading.Timer | None = None
        self._save_dirty = False
        self._user_email = user_email
        self.user_jwt = user_jwt
        self._transcript_buffer: list[dict[str, str]] = []
        # Repo root path — used as cwd for session instances
        self.repo_root: str | None = None

        # Callbacks — set by session/screen
        self.on_output: Callable[[str, str], None] | None = None
        self.on_task_complete: Callable[[str, str], None] | None = None
        self.on_progress: Callable[[str, str], None] | None = None
        self.on_status_change: Callable[[str, InstanceStatus], None] | None = None
        self.on_question: Callable[[str, dict], None] | None = None
        # UI view callbacks (diff, fullscreen, remove)
        self.on_ui_command: Callable[[str, str, Any], None] | None = None
        # Fired when instances are created or removed (for refreshing instructions)
        self.on_instance_change: Callable[[], None] | None = None
        # Tracks which instance_id is currently fullscreened (set by screen)
        self.fullscreen_id: str | None = None

    def create_instance(self, branch: str, worktree_path: str, agent_type: str = "claude") -> AgentInstance:
        with self._lock:
            if branch in self._branch_index:
                return self._instances[self._branch_index[branch]]
            instance = AgentInstance(
                instance_id=uuid.uuid4().hex[:8],
                branch=branch,
                worktree_path=worktree_path,
                agent_type=agent_type,
                instance_type=InstanceType.CODE,
            )
            self._instances[instance.instance_id] = instance
            self._branch_index[branch] = instance.instance_id
        self._save_state()
        # Fire status change so the UI can create a panel immediately
        if self.on_status_change:
            self.on_status_change(instance.instance_id, instance.status)
        if self.on_instance_change:
            self.on_instance_change()
        # Show file tree immediately when panel appears
        from voice_vibecoder.tools.file_tree import start_file_tree_updates
        start_file_tree_updates(instance.instance_id, worktree_path, self)
        return instance

    def create_session(self, name: str, agent_type: str = "claude") -> AgentInstance:
        """Create a branchless session instance, deduplicating by display_name."""
        existing = self.get_session_by_name(name)
        if existing:
            return existing
        with self._lock:
            # Re-check under lock to prevent race between concurrent creates
            branch_key = f"_session_{name}"
            if branch_key in self._branch_index:
                return self._instances[self._branch_index[branch_key]]
            instance = AgentInstance(
                instance_id=uuid.uuid4().hex[:8],
                branch=branch_key,
                worktree_path="",
                agent_type=agent_type,
                instance_type=InstanceType.SESSION,
                display_name=name,
            )
            self._instances[instance.instance_id] = instance
            self._branch_index[branch_key] = instance.instance_id
        self._save_state()
        if self.on_status_change:
            self.on_status_change(instance.instance_id, instance.status)
        if self.on_instance_change:
            self.on_instance_change()
        return instance

    def get_session_by_name(self, name: str) -> AgentInstance | None:
        """Fuzzy-match against SESSION instances' display_name and session key.

        Matches against both the display_name and the original session key
        (stored in branch as ``_session_{key}``), so lookups work even after
        the display_name is updated to a human-friendly label.
        """
        name_lower = name.lower().strip()
        with self._lock:
            sessions = [
                inst for inst in self._instances.values()
                if inst.instance_type == InstanceType.SESSION
            ]

        def _session_key(inst: AgentInstance) -> str:
            return inst.branch.removeprefix("_session_").lower()

        # Exact match on display_name or session key
        for inst in sessions:
            if inst.display_name.lower() == name_lower or _session_key(inst) == name_lower:
                return inst
        # Substring match on display_name or session key
        partial = [
            inst for inst in sessions
            if name_lower in inst.display_name.lower() or name_lower in _session_key(inst)
        ]
        if len(partial) == 1:
            return partial[0]
        if partial:
            return min(partial, key=lambda i: len(i.display_name))
        # Reverse substring (session name or key in query)
        partial = [
            inst for inst in sessions
            if inst.display_name.lower() in name_lower or _session_key(inst) in name_lower
        ]
        if len(partial) == 1:
            return partial[0]
        if partial:
            return min(partial, key=lambda i: len(i.display_name))
        return None

    def get_all_sessions(self) -> list[AgentInstance]:
        """Return all SESSION type instances."""
        with self._lock:
            return [i for i in self._instances.values() if i.instance_type == InstanceType.SESSION]

    def get_all_code_instances(self) -> list[AgentInstance]:
        """Return all CODE type instances."""
        with self._lock:
            return [i for i in self._instances.values() if i.instance_type == InstanceType.CODE]

    def get_by_branch(self, branch: str) -> AgentInstance | None:
        with self._lock:
            iid = self._branch_index.get(branch)
            return self._instances.get(iid) if iid else None

    def get_by_id(self, instance_id: str) -> AgentInstance | None:
        with self._lock:
            return self._instances.get(instance_id)

    def get_all(self) -> list[AgentInstance]:
        with self._lock:
            return list(self._instances.values())

    def get_default(self) -> AgentInstance | None:
        with self._lock:
            if not self._instances:
                return None
            return next(iter(self._instances.values()))

    def remove_instance(self, instance_id: str) -> None:
        with self._lock:
            inst = self._instances.pop(instance_id, None)
            if inst:
                self._branch_index.pop(inst.branch, None)
                is_session = inst.instance_type == InstanceType.SESSION
        # Stop file tree updates for code instances only
        if not is_session:
            from voice_vibecoder.tools.file_tree import stop_file_tree_updates
            stop_file_tree_updates(instance_id)
        self._save_state()
        if self.on_instance_change:
            self.on_instance_change()

    def update_status(self, instance_id: str, status: InstanceStatus) -> None:
        with self._lock:
            inst = self._instances.get(instance_id)
            if inst:
                inst.status = status
        if self.on_status_change:
            self.on_status_change(instance_id, status)

    def has_running_instance(self, branch: str) -> bool:
        with self._lock:
            iid = self._branch_index.get(branch)
            if not iid:
                return False
            inst = self._instances.get(iid)
            return inst is not None and inst.status == InstanceStatus.RUNNING

    @property
    def count(self) -> int:
        with self._lock:
            return len(self._instances)

    def add_transcript(self, role: str, text: str) -> None:
        """Add a transcript entry (voice conversation)."""
        with self._lock:
            self._transcript_buffer.append({"role": role, "text": text})
            # Keep last 100 transcript entries
            if len(self._transcript_buffer) > 100:
                self._transcript_buffer = self._transcript_buffer[-100:]
            logger.info(f"[TRANSCRIPT] Added {role} transcript, total now: {len(self._transcript_buffer)}")
        self._save_state()

    def get_transcripts(self) -> list[dict[str, str]]:
        """Get all transcript entries."""
        with self._lock:
            return list(self._transcript_buffer)

    # -- Persistence --

    def _get_state_path(self) -> Path:
        """Get the state file path for this user (or global if no user)."""
        if self._user_email:
            # Sanitize email for filename (replace @ and . with -)
            safe_email = self._user_email.replace("@", "-").replace(".", "-")
            return STATE_PATH.parent / f"realtime-instances-{safe_email}.json"
        return STATE_PATH

    def _save_state(self) -> None:
        """Schedule a debounced write of instance state (coalesces rapid calls)."""
        self._save_dirty = True
        if self._save_timer is not None:
            self._save_timer.cancel()
        self._save_timer = threading.Timer(0.5, self._flush_state)
        self._save_timer.daemon = True
        self._save_timer.start()

    def _save_state_now(self) -> None:
        """Immediately write state (use for session_id persistence)."""
        if self._save_timer is not None:
            self._save_timer.cancel()
            self._save_timer = None
        self._save_dirty = True
        self._flush_state()

    def _flush_state(self) -> None:
        """Actually write instance state to disk."""
        if not self._save_dirty:
            return
        self._save_dirty = False
        self._save_timer = None
        try:
            with self._lock:
                instances_data = [
                    {
                        "instance_id": inst.instance_id,
                        "branch": inst.branch,
                        "worktree_path": inst.worktree_path,
                        "agent_type": inst.agent_type,
                        "instance_type": inst.instance_type.value,
                        "display_name": inst.display_name,
                        "session_id": inst.session_id,
                        "output_buffer": inst.output_buffer[-5000:] if inst.output_buffer else "",
                    }
                    for inst in self._instances.values()
                ]
                data = {
                    "instances": instances_data,
                    "transcripts": self._transcript_buffer[-100:],  # Keep last 100
                }
            state_path = self._get_state_path()
            state_path.parent.mkdir(parents=True, exist_ok=True)
            tmp = state_path.with_suffix(".tmp")
            tmp.write_text(json.dumps(data, indent=2))
            tmp.replace(state_path)
        except Exception as e:
            logger.warning("Failed to save instance state: %s", e)

    def load_state(self) -> list[AgentInstance]:
        """Load previously saved instances from disk.

        Returns the loaded instances (already registered). Validates that
        worktree paths still exist on disk before restoring.
        """
        state_path = self._get_state_path()
        if not state_path.exists():
            return []
        try:
            raw_data = json.loads(state_path.read_text())
        except (json.JSONDecodeError, OSError) as e:
            logger.warning("Failed to load instance state: %s", e)
            return []

        # Handle both old format (list) and new format (dict)
        if isinstance(raw_data, list):
            instances_data = raw_data
            transcripts_data = []
        else:
            instances_data = raw_data.get("instances", [])
            transcripts_data = raw_data.get("transcripts", [])

        loaded = []
        with self._lock:
            # Load transcripts
            self._transcript_buffer = transcripts_data
            logger.info(f"[LOAD_STATE] Loaded {len(transcripts_data)} transcripts from state file")

            # Load instances
            for entry in instances_data:
                branch = entry.get("branch", "")
                worktree_path = entry.get("worktree_path", "")
                agent_type = entry.get("agent_type", "claude")
                session_id = entry.get("session_id", "")
                instance_id = entry.get("instance_id", uuid.uuid4().hex[:8])
                output_buffer = entry.get("output_buffer", "")
                # Backward compat: old state files default to CODE
                instance_type_str = entry.get("instance_type", "code")
                try:
                    instance_type = InstanceType(instance_type_str)
                except ValueError:
                    instance_type = InstanceType.CODE
                display_name = entry.get("display_name", "")
                is_session = instance_type == InstanceType.SESSION

                if not branch:
                    continue
                # CODE instances require a worktree_path
                if not is_session and not worktree_path:
                    continue
                # Skip if already registered (e.g. current branch added at startup)
                if branch in self._branch_index:
                    # Update session_id so we can resume the old session
                    existing = self._instances[self._branch_index[branch]]
                    if session_id:
                        existing.session_id = session_id
                        existing.first_call = False
                    if output_buffer:
                        existing.output_buffer = output_buffer
                    loaded.append(existing)
                    continue
                # Verify worktree still exists (skip for session instances)
                if not is_session and not Path(worktree_path).exists():
                    logger.info("Skipping saved instance '%s': path gone", branch)
                    continue

                instance = AgentInstance(
                    instance_id=instance_id,
                    branch=branch,
                    worktree_path=worktree_path,
                    agent_type=agent_type,
                    instance_type=instance_type,
                    display_name=display_name,
                    session_id=session_id,
                    first_call=not bool(session_id),
                    output_buffer=output_buffer,
                )
                self._instances[instance.instance_id] = instance
                self._branch_index[branch] = instance.instance_id
                loaded.append(instance)

        # Start file tree updates for restored code instances
        from voice_vibecoder.tools.file_tree import start_file_tree_updates
        for inst in loaded:
            if inst.instance_type == InstanceType.SESSION:
                continue
            start_file_tree_updates(inst.instance_id, inst.worktree_path, self)

        return loaded
