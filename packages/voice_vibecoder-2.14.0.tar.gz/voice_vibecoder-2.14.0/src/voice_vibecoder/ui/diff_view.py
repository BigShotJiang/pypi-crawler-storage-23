"""Git diff view widget for voice coding grid panels.

Renders a GitHub-style split view: changed file list on the left,
colorized diff content on the right. Designed to replace the agent
output RichLog inside a grid panel when the user asks to see changes.
"""

import subprocess
from dataclasses import dataclass

from textual.containers import Horizontal
from textual.widgets import RichLog, Static


@dataclass
class DiffFile:
    status: str  # M, A, D, R, C, etc.
    path: str


STATUS_LABELS = {
    "M": ("[yellow]M[/yellow]", "modified"),
    "A": ("[green]A[/green]", "added"),
    "D": ("[red]D[/red]", "deleted"),
    "R": ("[cyan]R[/cyan]", "renamed"),
    "C": ("[cyan]C[/cyan]", "copied"),
}


def _merge_base(worktree_path: str) -> str:
    """Get the merge-base commit between main and HEAD."""
    result = subprocess.run(
        ["git", "merge-base", "main", "HEAD"],
        cwd=worktree_path,
        capture_output=True,
        text=True,
        timeout=10,
    )
    return result.stdout.strip() if result.returncode == 0 else "main"


def _untracked_files(worktree_path: str) -> list[str]:
    """Get list of untracked files (not ignored)."""
    try:
        result = subprocess.run(
            ["git", "ls-files", "--others", "--exclude-standard"],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        return [f for f in result.stdout.strip().splitlines() if f.strip()]
    except Exception:
        return []


def _untracked_diff(worktree_path: str, files: list[str]) -> str:
    """Generate diff-style output for untracked (new) files."""
    parts = []
    for path in files:
        try:
            result = subprocess.run(
                ["git", "diff", "--no-index", "--no-color", "--", "/dev/null", path],
                cwd=worktree_path,
                capture_output=True,
                text=True,
                timeout=10,
            )
            # --no-index exits 1 when files differ, which is expected
            if result.stdout:
                parts.append(result.stdout)
        except Exception:
            continue
    return "\n".join(parts)


def get_diff_files(worktree_path: str) -> list[DiffFile]:
    """Get list of changed files vs main, including untracked files."""
    try:
        base = _merge_base(worktree_path)
        result = subprocess.run(
            ["git", "diff", "--name-status", base],
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return []
        files = []
        seen = set()
        for line in result.stdout.strip().splitlines():
            if not line.strip():
                continue
            parts = line.split("\t", 1)
            if len(parts) == 2:
                files.append(DiffFile(status=parts[0][0], path=parts[1]))
                seen.add(parts[1])
        # Include untracked files as "new"
        for path in _untracked_files(worktree_path):
            if path not in seen:
                files.append(DiffFile(status="A", path=path))
        return files
    except Exception:
        return []


def get_diff_content(worktree_path: str, file_path: str | None = None) -> str:
    """Get diff content vs main, including untracked files.

    If file_path is given, only return the diff for that specific file.
    """
    try:
        base = _merge_base(worktree_path)
        cmd = ["git", "diff", base, "--no-color"]
        if file_path:
            cmd += ["--", file_path]
        result = subprocess.run(
            cmd,
            cwd=worktree_path,
            capture_output=True,
            text=True,
            timeout=30,
        )
        tracked_diff = result.stdout if result.returncode == 0 else ""
        # Append untracked file diffs
        untracked = _untracked_files(worktree_path)
        if file_path:
            untracked = [f for f in untracked if f == file_path]
        if untracked:
            untracked_part = _untracked_diff(worktree_path, untracked)
            if untracked_part:
                tracked_diff = tracked_diff + "\n" + untracked_part if tracked_diff else untracked_part
        return tracked_diff
    except Exception:
        return ""


def format_file_list(files: list[DiffFile]) -> str:
    """Format file list as a tree with folder structure."""
    if not files:
        return "[dim]No changes[/dim]"

    # Build tree: {folder: [(status, filename)]}
    tree: dict[str, list[tuple[str, str]]] = {}
    for f in files:
        if "/" in f.path:
            folder, name = f.path.rsplit("/", 1)
        else:
            folder, name = "", f.path
        tree.setdefault(folder, []).append((f.status, name))

    # Sort folders, render tree
    lines = []
    for folder in sorted(tree.keys()):
        if folder:
            lines.append(f" [bold dim]{folder}/[/bold dim]")
        for status, name in sorted(tree[folder], key=lambda x: x[1]):
            label, _ = STATUS_LABELS.get(status, (f"[dim]{status}[/dim]", "unknown"))
            indent = "   " if folder else " "
            lines.append(f"{indent}{label} {name}")
    return "\n".join(lines)


def format_diff_content(raw_diff: str) -> list[str]:
    """Convert raw diff into Rich-markup lines."""
    if not raw_diff.strip():
        return ["[dim]No changes to show.[/dim]"]
    lines = []
    for line in raw_diff.splitlines():
        if line.startswith("diff --git"):
            # File header
            parts = line.split(" b/", 1)
            fname = parts[1] if len(parts) == 2 else line
            lines.append(f"\n[bold underline]{fname}[/bold underline]")
        elif line.startswith("index ") or line.startswith("---") or line.startswith("+++"):
            continue  # skip noise
        elif line.startswith("@@"):
            # Hunk header
            lines.append(f"[cyan]{_escape(line)}[/cyan]")
        elif line.startswith("+"):
            lines.append(f"[green]{_escape(line)}[/green]")
        elif line.startswith("-"):
            lines.append(f"[red]{_escape(line)}[/red]")
        else:
            lines.append(f"[dim]{_escape(line)}[/dim]")
    return lines


def _escape(text: str) -> str:
    """Escape Rich markup characters in diff content."""
    return text.replace("[", "\\[")


DIFF_VIEW_CSS = """
.diff-container {
    layout: horizontal;
    height: 1fr;
}

.diff-file-list {
    width: 24;
    border-right: solid $panel;
    padding: 0;
    overflow-y: auto;
}

.diff-content {
    width: 1fr;
    padding: 0 1;
}
"""


def create_diff_view(
    instance_id: str, files: list[DiffFile], diff_lines: list[str],
) -> tuple[Horizontal, RichLog]:
    """Create a diff view widget to mount inside a grid panel.

    Returns (container, diff_log) so the caller can write lines to the
    RichLog directly without a DOM query (avoids Textual mount timing issues).
    """
    file_list_text = format_file_list(files)
    file_list = Static(
        file_list_text,
        classes="diff-file-list",
        id=f"diff-files-{instance_id}",
    )
    diff_log = RichLog(
        highlight=False,
        markup=True,
        classes="diff-content",
        id=f"diff-log-{instance_id}",
    )

    container = Horizontal(
        file_list,
        diff_log,
        classes="diff-container",
        id=f"diff-view-{instance_id}",
    )
    return container, diff_log
