"""Voice provider protocol and event types.

Defines a provider-agnostic interface for real-time voice conversation.
Implementations handle the specifics of a particular API (OpenAI Realtime,
Gemini Live, etc.) while the session layer works with these abstract events.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, AsyncIterator, Protocol


@dataclass
class VADSettings:
    """OpenAI/Azure voice activity detection configuration."""
    threshold: float = 0.8
    silence_duration_ms: int = 700
    prefix_padding_ms: int = 300


@dataclass
class GeminiVADSettings:
    """Gemini voice activity detection configuration."""
    start_sensitivity: str = "HIGH"  # "HIGH" or "LOW"
    end_sensitivity: str = "LOW"     # "HIGH" or "LOW"
    silence_duration_ms: int = 700
    prefix_padding_ms: int = 100


# -- Events emitted by a VoiceProvider --


@dataclass
class AudioDelta:
    """Chunk of audio to play back."""
    delta: str  # base64-encoded PCM16


@dataclass
class TranscriptDelta:
    """Incremental assistant transcript."""
    delta: str


@dataclass
class TranscriptDone:
    """Final assistant transcript."""
    transcript: str


@dataclass
class UserTranscript:
    """Completed user speech transcription."""
    transcript: str


@dataclass
class SpeechStarted:
    """User started speaking (VAD detected)."""


@dataclass
class SpeechStopped:
    """User stopped speaking."""


@dataclass
class AudioCommitted:
    """Audio buffer was committed (PTT or VAD)."""


@dataclass
class ResponseCreated:
    """Provider started generating a response."""


@dataclass
class FunctionCall:
    """Provider wants to call a tool."""
    call_id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class ResponseDone:
    """Provider finished its response turn."""


@dataclass
class VoiceError:
    """Non-fatal error from the provider."""
    message: str
    is_ignorable: bool = False


VoiceEvent = (
    AudioDelta | TranscriptDelta | TranscriptDone | UserTranscript
    | SpeechStarted | SpeechStopped | AudioCommitted | ResponseCreated
    | FunctionCall | ResponseDone | VoiceError
)


class VoiceProvider(Protocol):
    """Interface for a real-time voice conversation provider."""

    async def connect(self) -> None: ...
    async def disconnect(self) -> None: ...
    async def configure(
        self,
        instructions: str,
        voice: str,
        tools: list[dict],
        vad: VADSettings | GeminiVADSettings | None,
    ) -> None: ...
    async def send_audio(self, base64_chunk: str) -> None: ...
    async def commit_audio(self) -> None: ...
    async def cancel_response(self) -> None: ...
    async def request_response(self) -> None: ...
    async def inject_message(self, text: str) -> None: ...
    async def send_tool_result(self, call_id: str, output: str) -> None: ...
    async def update_session(self, instructions: str) -> None: ...
    def listen(self) -> AsyncIterator[VoiceEvent]: ...
    async def test_connection(self) -> bytes:
        """Connect, verify credentials with a short audio greeting, return PCM16 audio. Raises on failure."""
        ...
    async def test_voice(self, voice: str) -> bytes:
        """Connect, send a short prompt with the given voice, return PCM16 audio. Raises on failure."""
        ...


def create_provider(settings) -> VoiceProvider:
    """Create the appropriate VoiceProvider based on settings.provider."""
    if settings.provider == "gemini":
        from voice_vibecoder.voice_providers.gemini import GeminiLiveVoiceProvider
        return GeminiLiveVoiceProvider(
            ws_url=settings.ws_url,
            model=settings.gemini.model,
        )
    from voice_vibecoder.voice_providers.openai import OpenAIVoiceProvider
    return OpenAIVoiceProvider(
        ws_url=settings.ws_url,
        ws_headers=settings.ws_headers,
    )
