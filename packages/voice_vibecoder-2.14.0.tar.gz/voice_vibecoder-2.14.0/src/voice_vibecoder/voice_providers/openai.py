"""OpenAI Realtime API voice provider.

Implements the VoiceProvider protocol using the OpenAI Realtime WebSocket API.
Supports both direct OpenAI and Azure OpenAI endpoints.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
from typing import Any, AsyncIterator

import websockets

from voice_vibecoder.voice_providers import (
    AudioCommitted,
    AudioDelta,
    FunctionCall,
    ResponseCreated,
    ResponseDone,
    SpeechStarted,
    SpeechStopped,
    TranscriptDelta,
    TranscriptDone,
    UserTranscript,
    VADSettings,
    VoiceError,
    VoiceEvent,
)

logger = logging.getLogger(__name__)


class OpenAIVoiceProvider:
    """VoiceProvider implementation for the OpenAI Realtime API."""

    def __init__(
        self,
        ws_url: str,
        ws_headers: dict[str, str],
        transcription_model: str = "gpt-4o-mini-transcribe",
    ) -> None:
        self._ws_url = ws_url
        self._ws_headers = ws_headers
        self._transcription_model = transcription_model
        self._ws: Any = None

    async def connect(self) -> None:
        self._ws = await websockets.connect(
            self._ws_url, additional_headers=self._ws_headers
        )

    async def disconnect(self) -> None:
        if self._ws:
            try:
                await self._ws.close()
            except Exception:
                pass
            self._ws = None

    async def configure(
        self,
        instructions: str,
        voice: str,
        tools: list[dict],
        vad: VADSettings | None,
    ) -> None:
        if not self._ws:
            return

        session_config: dict[str, Any] = {
            "type": "session.update",
            "session": {
                "modalities": ["text", "audio"],
                "instructions": instructions,
                "voice": voice,
                "input_audio_format": "pcm16",
                "output_audio_format": "pcm16",
                "input_audio_transcription": {"model": self._transcription_model},
                "tools": tools,
            },
        }

        if vad is None:
            session_config["session"]["turn_detection"] = None
        else:
            session_config["session"]["turn_detection"] = {
                "type": "server_vad",
                "threshold": vad.threshold,
                "prefix_padding_ms": vad.prefix_padding_ms,
                "silence_duration_ms": vad.silence_duration_ms,
                "create_response": True,
            }

        await self._ws.send(json.dumps(session_config))

    async def send_audio(self, base64_chunk: str) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({
                "type": "input_audio_buffer.append",
                "audio": base64_chunk,
            }))
        except Exception:
            pass

    async def commit_audio(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "input_audio_buffer.commit"}))
            await self._ws.send(json.dumps({"type": "response.create"}))
        except Exception:
            pass

    async def cancel_response(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "response.cancel"}))
        except Exception:
            pass

    async def request_response(self) -> None:
        if not self._ws:
            return
        try:
            await self._ws.send(json.dumps({"type": "response.create"}))
        except Exception:
            pass

    async def inject_message(self, text: str) -> None:
        if not self._ws:
            return
        item_msg = {
            "type": "conversation.item.create",
            "item": {
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": text}],
            },
        }
        await self._ws.send(json.dumps(item_msg))
        await self._ws.send(json.dumps({"type": "response.create"}))

    async def update_session(self, instructions: str) -> None:
        if not self._ws:
            return
        msg = {
            "type": "session.update",
            "session": {"instructions": instructions},
        }
        await self._ws.send(json.dumps(msg))

    async def send_tool_result(self, call_id: str, output: str) -> None:
        if not self._ws:
            return
        item_msg = {
            "type": "conversation.item.create",
            "item": {
                "type": "function_call_output",
                "call_id": call_id,
                "output": output,
            },
        }
        await self._ws.send(json.dumps(item_msg))
        await self._ws.send(json.dumps({"type": "response.create"}))

    async def listen(self) -> AsyncIterator[VoiceEvent]:
        if not self._ws:
            return
        async for raw in self._ws:
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            event = self._map_event(msg)
            if event is not None:
                yield event

    async def test_connection(self) -> bytes:
        """Connect, verify credentials with a short audio greeting, return PCM16 audio."""
        return await self.test_voice("ash")

    async def test_voice(self, voice: str) -> bytes:
        """Connect, send a short prompt with the given voice, return PCM16 audio bytes."""
        ws = await websockets.connect(
            self._ws_url, additional_headers=self._ws_headers
        )
        try:
            # Wait for session.created
            raw = await asyncio.wait_for(ws.recv(), timeout=10)
            msg = json.loads(raw)
            if msg.get("type") != "session.created":
                raise RuntimeError(f"Unexpected response: {msg.get('type', '?')}")

            # Configure session with the selected voice
            await ws.send(json.dumps({
                "type": "session.update",
                "session": {
                    "modalities": ["text", "audio"],
                    "voice": voice,
                    "instructions": "Always speak English. Say a short greeting in 5 words or less.",
                    "input_audio_format": "pcm16",
                    "output_audio_format": "pcm16",
                    "turn_detection": None,
                },
            }))

            # Send a message and request a response
            await ws.send(json.dumps({
                "type": "conversation.item.create",
                "item": {
                    "type": "message",
                    "role": "user",
                    "content": [{"type": "input_text", "text": "Say hello!"}],
                },
            }))
            await ws.send(json.dumps({"type": "response.create"}))

            # Collect audio chunks until response.done
            audio_chunks: list[bytes] = []
            deadline = asyncio.get_event_loop().time() + 15
            while asyncio.get_event_loop().time() < deadline:
                raw = await asyncio.wait_for(ws.recv(), timeout=15)
                msg = json.loads(raw)
                if msg.get("type") == "response.audio.delta":
                    audio_chunks.append(base64.b64decode(msg["delta"]))
                elif msg.get("type") == "response.done":
                    break
                elif msg.get("type") == "error":
                    err = msg.get("error", {}).get("message", str(msg))
                    raise RuntimeError(err)

            if not audio_chunks:
                raise RuntimeError("No audio received from provider")

            return b"".join(audio_chunks)
        finally:
            await ws.close()

    def _map_event(self, msg: dict) -> VoiceEvent | None:
        msg_type = msg.get("type", "")

        if msg_type == "response.audio.delta":
            return AudioDelta(delta=msg.get("delta", ""))

        elif msg_type == "response.audio_transcript.delta":
            return TranscriptDelta(delta=msg.get("delta", ""))

        elif msg_type == "response.audio_transcript.done":
            return TranscriptDone(transcript=msg.get("transcript", ""))

        elif msg_type == "conversation.item.input_audio_transcription.completed":
            return UserTranscript(transcript=msg.get("transcript", "").strip())

        elif msg_type == "input_audio_buffer.speech_started":
            return SpeechStarted()

        elif msg_type == "input_audio_buffer.speech_stopped":
            return SpeechStopped()

        elif msg_type == "input_audio_buffer.committed":
            return AudioCommitted()

        elif msg_type == "response.created":
            return ResponseCreated()

        elif msg_type == "response.function_call_arguments.done":
            args_str = msg.get("arguments", "{}")
            try:
                arguments = json.loads(args_str)
            except json.JSONDecodeError:
                arguments = {}
            return FunctionCall(
                call_id=msg.get("call_id", ""),
                name=msg.get("name", ""),
                arguments=arguments,
            )

        elif msg_type == "response.done":
            return ResponseDone()

        elif msg_type == "error":
            error = msg.get("error", {})
            error_msg = error.get("message", str(error))
            is_ignorable = "cancel" in error_msg.lower()
            return VoiceError(message=error_msg, is_ignorable=is_ignorable)

        return None
