"""Tests for fresh."""

from typer.testing import CliRunner

runner = CliRunner()
