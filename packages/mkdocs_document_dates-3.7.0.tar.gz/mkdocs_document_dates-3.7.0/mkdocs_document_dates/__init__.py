"""MkDocs Document Dates Plugin."""
