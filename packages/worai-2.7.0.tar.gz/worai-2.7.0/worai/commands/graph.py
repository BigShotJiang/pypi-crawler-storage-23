"""CLI wrapper for graph workflows."""

from __future__ import annotations

from pathlib import Path

import typer

from worai.config import resolve_config_path
from worai.core.graph import (
    GraphSyncCreateOptions,
    GraphSyncOptions,
    run_graph_sync,
    run_graph_sync_create,
)
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True)
sync_app = typer.Typer(add_completion=False, no_args_is_help=True)


@sync_app.command(
    "run",
    no_args_is_help=True,
    help="Run graph sync for a configured profile.",
)
def run(
    ctx: typer.Context,
    profile: str = typer.Option(..., "--profile", help="Profile name in worai.toml."),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Write generated callback graphs to output/debug_cloud/<profile>/.",
    ),
) -> None:
    try:
        config_path = (ctx.obj or {}).get("config_path") if ctx else None
        run_graph_sync(
            GraphSyncOptions(
                profile=profile,
                config_path=config_path or resolve_config_path(None),
                debug=debug,
            )
        )
    except ValueError as exc:
        raise UsageError(str(exc)) from exc


@sync_app.command(
    "create",
    no_args_is_help=True,
    help="Create a graph sync project from a Copier template.",
)
def create(
    destination: Path | None = typer.Argument(
        None,
        metavar="DESTINATION",
        help="Output directory where the graph sync project will be created.",
    ),
    template: str = typer.Option(
        "gh:wordlift/graph-sync-template",
        "--template",
        help="Copier template source (Git URL, gh: shortcut, or local path).",
    ),
    defaults: bool = typer.Option(
        False,
        "--defaults",
        help="Use Copier default answers.",
    ),
    data_file: Path | None = typer.Option(
        None,
        "--data-file",
        help="Path to a Copier data file with pre-filled answers.",
    ),
    vcs_ref: str | None = typer.Option(
        None,
        "--vcs-ref",
        help="Template VCS ref (tag, branch, or commit).",
    ),
    non_interactive: bool = typer.Option(
        False,
        "--non-interactive",
        help="Disable prompts and fail if required answers are missing.",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="Allow writing into existing destinations.",
    ),
) -> None:
    if destination is None:
        if non_interactive:
            raise UsageError("Destination path is required when using --non-interactive.")
        destination = Path(typer.prompt("Destination directory"))

    run_graph_sync_create(
        GraphSyncCreateOptions(
            destination=destination,
            template=template,
            defaults=defaults,
            data_file=data_file,
            vcs_ref=vcs_ref,
            non_interactive=non_interactive,
            force=force,
        )
    )


app.add_typer(sync_app, name="sync", help="Run graph sync workflows.")
