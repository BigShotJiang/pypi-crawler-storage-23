# json_to_many/utils/constants.py
DEFAULT_ENCODING = "utf-8"
SUPPORTED_FORMATS = ["markdown", "xml", "csv"]
