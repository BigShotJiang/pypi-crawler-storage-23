DIGITS = [
    [
        " ▄▄ ",
        "█  █",
        "▀▄▄▀",
    ],
    [
        "▄▄ ",
        " █ ",
        "▄█▄",
    ],
    [
        "▄▄▄ ",
        " ▄▄▀",
        "█▄▄▄",
    ],
    [
        "▄▄▄ ",
        " ▄▄▀",
        "▄▄▄▀",
    ],
    [
        "▄ ▄ ",
        "█ █ ",
        "▀▀█▀",
    ],
    [
        "▄▄▄▄",
        "█▄▄ ",
        "▄▄▄▀",
    ],
    [
        " ▄▄ ",
        "█▄▄ ",
        "▀▄▄▀",
    ],
    [
        "▄▄▄▄",
        "  ▄▀",
        " █  ",
    ],
    [
        " ▄▄ ",
        "▀▄▄▀",
        "▀▄▄▀",
    ],
    [
        " ▄▄ ",
        "▀▄▄█",
        " ▄▄▀",
    ],
]

MIN = [
    "▄   ▄ ▄ ▄   ▄",
    "█▀▄▀█ █ █▀▄ █",
    "█   █ █ █  ▀█",
]

ARRIVED = [
    " ▄▄  ▄▄▄  ▄▄▄  ▄ ▄   ▄ ▄▄▄ ▄▄▄ ",
    "█▄▄█ █▄▄▀ █▄▄▀ █ ▀▄ ▄▀ █▄▄ █  █",
    "█  █ █ ▀▄ █ ▀▄ █  ▀▄▀  █▄▄ █▄▄▀",
]

SPACE = [
    " ",
    " ",
    " ",
]


def format_minutes(minutes: int):
    minutes = abs(minutes)
    digits = [DIGITS[int(n)] for n in str(minutes)] + [SPACE, MIN]
    output = ""

    for row in range(3):
        for digit in digits:
            output += digit[row] + " "
        output += "\n"

    return output


def format_arrived():
    return "\n".join(ARRIVED)
