from zet import main

main()
