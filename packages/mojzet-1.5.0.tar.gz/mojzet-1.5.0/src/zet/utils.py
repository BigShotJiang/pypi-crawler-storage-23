from itertools import islice, tee
from typing import Callable, Iterable, TypeVar

T = TypeVar("T")


def iterate_pairs(iterable: Iterable[T]) -> Iterable[tuple[T, T]]:
    """Iterate over pairs of items in a list."""
    items, nexts = tee(iterable, 2)
    nexts = islice(nexts, 1, None)
    return zip(items, nexts)


def find(iterable: Iterable[T], condition: Callable[[T], bool]) -> T | None:
    for item in iterable:
        if condition(item):
            return item
