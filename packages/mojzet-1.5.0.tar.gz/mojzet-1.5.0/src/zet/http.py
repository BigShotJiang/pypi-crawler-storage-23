import asyncio
import aiohttp
from contextlib import asynccontextmanager
import logging
from types import SimpleNamespace

logger = logging.getLogger(__name__)


@asynccontextmanager
async def make_session():
    headers = {
        "appuid": "ZET.Mobile",
        "x-tenant": "KingICT_ZET_Public",
        "User-Agent": "okhttp/4.9.2",
    }

    async with aiohttp.ClientSession(
        base_url="https://api.zet.hr",
        connector=aiohttp.TCPConnector(ssl=False),  # Don't validate ssl
        headers=headers,
        trace_configs=[logger_trace_config()],
    ) as session:
        yield session


def logger_trace_config() -> aiohttp.TraceConfig:
    async def on_request_start(
        _: aiohttp.ClientSession,
        context: SimpleNamespace,
        params: aiohttp.TraceRequestStartParams,
    ):
        context.start = asyncio.get_event_loop().time()
        logger.debug(f"--> {params.method} {params.url}")

    async def on_request_end(
        _: aiohttp.ClientSession,
        context: SimpleNamespace,
        params: aiohttp.TraceRequestEndParams,
    ):
        elapsed = round(100 * (asyncio.get_event_loop().time() - context.start))
        logger.debug(f"<-- {params.method} {params.url} HTTP {params.response.status} {elapsed}ms")

    trace_config = aiohttp.TraceConfig()
    trace_config.on_request_start.append(on_request_start)
    trace_config.on_request_end.append(on_request_end)
    return trace_config
