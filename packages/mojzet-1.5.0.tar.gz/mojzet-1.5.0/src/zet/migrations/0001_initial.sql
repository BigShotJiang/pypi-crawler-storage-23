CREATE TABLE migrations(
    name TEXT NOT NULL UNIQUE,
    applied_at TEXT NOT NULL
);

CREATE TABLE meta(
    map_lines_imported_at TEXT
);

INSERT INTO meta VALUES (null);

CREATE TABLE map_lines(
    lat1 REAL NOT NULL,
    lon1 REAL NOT NULL,
    lat2 REAL NOT NULL,
    lon2 REAL NOT NULL
);
