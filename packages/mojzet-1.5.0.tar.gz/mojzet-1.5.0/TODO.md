Some ideas for the future
=========================

### Map

- append A/B direction of travel to vehicle labels so it's clear which way they're moving
- draw stations
