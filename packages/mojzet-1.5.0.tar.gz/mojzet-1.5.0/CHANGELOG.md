# Zet Changelog

## 1.5.0 (2026-02-28)

* TUI: add option for watching trip progress (on the Stops tab, select a trip in the right pane and and press w)

## 1.4.1 (2025-11-23)

* add missing dependency on gtfs-realtime parser

## 1.4.0 (2025-11-22)

* tui: add map pane
* tui: add splash screen

## 1.3.0 (2025-11-11)

* Add `zet tui` terminal user interface

## 1.2.0 (2025-10-06)

* Add `--json` option to all commands for outputting JSON data
* Add `stops --name` option for filtering stops by name

## 1.1.0 (2025-07-12)

* Add `trip-stops` command
* Add `trips --route` option
* Add `route-trips --direction` option
* Handle HTTP errors

## 1.0.0 (2025-07-10)

* Initial release
