from __future__ import annotations

import re
from dataclasses import dataclass
from functools import wraps
from json import JSONDecodeError
from typing import Any, Callable, Dict, List, Optional, Union

from ddtrace import tracer
from marshmallow import Schema, ValidationError

from dh_potluck.messaging import Message
from dh_potluck.messaging.batching_consumer import BatchingMessageConsumer
from dh_potluck.messaging.typings import BatchingMessagesHandler, MessageFilterFunction, SchemasDict


@dataclass(frozen=True)
class ValidatedMessage:
    message: Message
    message_type: str
    payload: Any = None
    error: Union[ValidationError, JSONDecodeError, None] = None


class NoBatchingHandlerException(Exception):
    def __init__(self, topic, available_handlers):
        self.topic = topic
        self.message = (
            f'No batching handler for: {topic=}. Available handlers: {available_handlers}'
        )
        super().__init__(self.message)


class BatchingMessageConsumerApp:
    _consumer: BatchingMessageConsumer
    _handlers: Dict[str, BatchingMessagesHandler]
    _regex_handlers: Dict[re.Pattern[str], BatchingMessagesHandler]

    def __init__(
        self,
        batching_consumer: BatchingMessageConsumer,
    ):
        """
        :param batching_consumer: The underlying batching consumer
        """
        self._consumer = batching_consumer
        self._handlers = {}
        self._regex_handlers = {}

    def register(
        self,
        topic: str,
        message_filter: Optional[MessageFilterFunction] = None,
        batch_size: Optional[int] = None,
        release_after: Optional[float] = None,
    ) -> Callable[[BatchingMessagesHandler], BatchingMessagesHandler]:
        """
        Decorator to register a handler for a topic.

        :param str topic: Kafka topic to associate this handler with
        :param MessageFilterFunction message_filter: Filter function to pre-filter messages
        :param int batch_size: Per-topic batch size (optional). If provided, release_after must
            also be provided. This enables deterministic batch sizes for this topic.
        :param float release_after: Per-topic release timeout in milliseconds (optional).
            If provided, batch_size must also be provided.
        """

        def decorator_register_message_handler(func: BatchingMessagesHandler):
            self.register_handler(
                topic,
                func,
                message_filter=message_filter,
                batch_size=batch_size,
                release_after=release_after,
            )
            return func

        return decorator_register_message_handler

    def register_handler(
        self,
        topic: str,
        handler: BatchingMessagesHandler,
        message_filter: Optional[MessageFilterFunction] = None,
        batch_size: Optional[int] = None,
        release_after: Optional[float] = None,
    ) -> None:
        """
        Register a handler for a topic.

        :param str topic: Kafka topic to associate this handler with
        :param BatchingMessagesHandler handler: The handler function
        :param MessageFilterFunction message_filter: Filter function to pre-filter messages
        :param int batch_size: Per-topic batch size (optional). If provided, release_after must
            also be provided. This enables deterministic batch sizes for this topic.
        :param float release_after: Per-topic release timeout in milliseconds (optional).
            If provided, batch_size must also be provided.
        """
        # Validate batch config parameters
        if (batch_size is not None) != (release_after is not None):
            raise ValueError(
                'Both batch_size and release_after must be provided together, or neither.'
            )

        # Register message filter if provided
        if message_filter is not None:
            self._consumer.add_message_filter(topic, message_filter)

        # Register per-topic batch config if provided
        if batch_size is not None and release_after is not None:
            self._consumer.add_batch_config(topic, batch_size, release_after)

        # regexes must start with ^ for kafka to pick up on them
        if topic.startswith('^'):
            self._regex_handlers[re.compile(topic)] = handler
        else:
            self._handlers[topic] = handler

    def run(self) -> None:
        """
        Start consuming messages.
        """
        topics = [topic for topic in self._handlers]
        topic_regexes = [regex.pattern for regex in self._regex_handlers]
        self._consumer.subscribe(set(topics + topic_regexes))
        for batch in self._consumer.get_batches():
            self._handle_batch(batch)

    def _handle_batch(self, batch: List[Message]) -> None:
        batches_by_topic: Dict[str, List[Message]] = {}
        for message in batch:
            batches_by_topic.setdefault(message.topic(), []).append(message)

        messages_to_commit = []
        for topic, messages in batches_by_topic.items():
            should_commit = self._handle_one_topic_batch(topic, messages)
            if not self._consumer.auto_commit and should_commit:
                messages_to_commit.extend(messages)
        if messages_to_commit:
            self._consumer.commit(messages=messages_to_commit)

    def _handle_one_topic_batch(
        self,
        topic: str,
        messages: List[Message],
    ) -> bool:
        with tracer.trace('kafka.batch_consume', resource=topic) as span:
            handler = self._get_handler(topic)
            span.set_tag('batch_size', str(len(messages)))
            should_commit = handler(topic, messages)
            return should_commit is not False

    def _get_handler(self, topic: str) -> BatchingMessagesHandler:
        handler = self._handlers.get(topic)

        if not handler:
            for topic_regex, _handler in self._regex_handlers.items():
                if topic_regex.match(topic):
                    handler = _handler
                    break

        if not handler:
            raise NoBatchingHandlerException(topic, list(self._handlers))
        return handler


def validate_schema_per_message(schema: Schema):
    def _wrapper(handler: Callable[[str, List[ValidatedMessage]], Optional[bool]]):
        @wraps(handler)
        def wrapper(topic: str, messages: List[Message]) -> Optional[bool]:
            validated = [
                ValidatedMessage(
                    message=message,
                    message_type=message.value()['message_type'],
                    payload=schema.loads(message.value()['payload']),
                )
                for message in messages
            ]
            return handler(topic, validated)

        return wrapper

    return _wrapper


def _get_schema(schemas: SchemasDict, topic: str, message_type: str) -> Optional[Schema]:
    return schemas.get((topic, message_type)) or schemas.get(message_type)


def validate_schemas_per_message(schemas: SchemasDict):
    def _wrapper(handler: Callable[[str, List[ValidatedMessage]], Optional[bool]]):
        @wraps(handler)
        def wrapper(topic: str, messages: List[Message]) -> Optional[bool]:
            validated = []
            for message in messages:
                message_type = message.value()['message_type']
                schema = _get_schema(schemas, topic, message_type)
                if not schema:
                    raise ValidationError(f'No schema for message_type {message_type}')
                validated.append(
                    ValidatedMessage(
                        message=message,
                        message_type=message_type,
                        payload=schema.loads(message.value()['payload']),
                    )
                )
            return handler(topic, validated)

        return wrapper

    return _wrapper


def validate_schema_per_message_and_ignore_errors(schema: Schema):
    def _wrapper(handler: Callable[[str, List[ValidatedMessage]], Optional[bool]]):
        @wraps(handler)
        def wrapper(topic: str, messages: List[Message]) -> Optional[bool]:
            validated = []
            for message in messages:
                message_type = message.value()['message_type']
                try:
                    payload = schema.loads(message.value()['payload'])
                    validated.append(
                        ValidatedMessage(
                            message=message,
                            message_type=message_type,
                            payload=payload,
                        )
                    )
                except (ValidationError, JSONDecodeError) as e:
                    validated.append(
                        ValidatedMessage(
                            message=message,
                            message_type=message_type,
                            error=e,
                        )
                    )
            return handler(topic, validated)

        return wrapper

    return _wrapper


def validate_schemas_per_message_and_ignore_errors(schemas: SchemasDict):
    def _wrapper(handler: Callable[[str, List[ValidatedMessage]], Optional[bool]]):
        @wraps(handler)
        def wrapper(topic: str, messages: List[Message]) -> Optional[bool]:
            validated = []
            for message in messages:
                message_type = message.value()['message_type']
                schema = _get_schema(schemas, topic, message_type)
                try:
                    if not schema:
                        raise ValidationError(f'No schema for message_type {message_type}')
                    validated.append(
                        ValidatedMessage(
                            message=message,
                            message_type=message_type,
                            payload=schema.loads(message.value()['payload']),
                        )
                    )
                except (ValidationError, JSONDecodeError) as e:
                    validated.append(
                        ValidatedMessage(
                            message=message,
                            message_type=message_type,
                            error=e,
                        )
                    )
            return handler(topic, validated)

        return wrapper

    return _wrapper
