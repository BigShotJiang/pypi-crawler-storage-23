from __future__ import annotations

from dataclasses import dataclass

from comate_agent_sdk.mcp.manager import McpManager
from comate_agent_sdk.mcp.types import McpServerConfig


@dataclass(frozen=True)
class McpServerHealth:
    alias: str
    server_type: str
    endpoint: str
    connected: bool
    reason: str | None
    tool_count: int


def _server_type(cfg: McpServerConfig) -> str:
    raw = cfg.get("type")  # type: ignore[attr-defined]
    if raw is None:
        return "stdio"
    return str(raw).strip().lower() or "stdio"


def _server_endpoint(cfg: McpServerConfig) -> str:
    stype = _server_type(cfg)
    if stype in {"http", "sse"}:
        return str(cfg.get("url", "")).strip()  # type: ignore[attr-defined]

    command = str(cfg.get("command", "")).strip()  # type: ignore[attr-defined]
    args_raw = cfg.get("args") or []  # type: ignore[attr-defined]
    args = [str(item) for item in args_raw] if isinstance(args_raw, list) else []
    return " ".join([command, *args]).strip()


async def collect_mcp_server_health(
    *,
    servers: dict[str, McpServerConfig],
    connect_timeout_s: float = 10.0,
    call_timeout_s: float = 60.0,
) -> list[McpServerHealth]:
    if not servers:
        return []

    manager = McpManager(
        servers,
        connect_timeout_s=connect_timeout_s,
        call_timeout_s=call_timeout_s,
    )
    tool_count_by_alias: dict[str, int] = {}
    failed_reason_by_alias: dict[str, str] = {}
    fatal_reason: str | None = None

    try:
        await manager.start()
        for info in manager.tool_infos:
            tool_count_by_alias[info.server_alias] = (
                tool_count_by_alias.get(info.server_alias, 0) + 1
            )
        for alias, reason in manager.failed_servers:
            failed_reason_by_alias[alias] = reason
    except Exception as exc:
        fatal_reason = f"{type(exc).__name__}: {exc}"
    finally:
        try:
            await manager.aclose()
        except Exception:
            pass

    results: list[McpServerHealth] = []
    for alias, cfg in servers.items():
        stype = _server_type(cfg)
        endpoint = _server_endpoint(cfg)

        reason: str | None
        if fatal_reason is not None:
            reason = fatal_reason
            connected = False
            tool_count = 0
        elif alias in failed_reason_by_alias:
            reason = failed_reason_by_alias[alias]
            connected = False
            tool_count = 0
        else:
            connected = True
            reason = None
            tool_count = int(tool_count_by_alias.get(alias, 0))

        results.append(
            McpServerHealth(
                alias=alias,
                server_type=stype,
                endpoint=endpoint,
                connected=connected,
                reason=reason,
                tool_count=tool_count,
            )
        )
    return results
