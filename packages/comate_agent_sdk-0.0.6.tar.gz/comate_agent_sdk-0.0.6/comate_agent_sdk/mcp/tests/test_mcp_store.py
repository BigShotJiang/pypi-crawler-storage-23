from __future__ import annotations

import json
from pathlib import Path

import pytest

from comate_agent_sdk.mcp.store import (
    McpConfigError,
    load_effective_servers,
    load_mcp_servers_from_path,
    write_mcp_servers_to_path,
)


def test_load_mcp_servers_from_path_returns_empty_when_file_missing(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    assert load_mcp_servers_from_path(path) == {}


def test_load_mcp_servers_requires_mcpservers_top_level(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"servers": {"a": {"command": "npx"}}}), encoding="utf-8")

    with pytest.raises(McpConfigError, match="旧格式 'servers'"):
        load_mcp_servers_from_path(path)


def test_load_mcp_servers_rejects_missing_top_level(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"foo": "bar"}), encoding="utf-8")

    with pytest.raises(McpConfigError, match="缺少 'mcpServers'"):
        load_mcp_servers_from_path(path)


def test_load_effective_servers_project_overrides_user(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    home = tmp_path / "home"
    project_root = tmp_path / "project"
    user_file = home / ".agent" / ".mcp.json"
    project_file = project_root / ".agent" / ".mcp.json"
    user_file.parent.mkdir(parents=True, exist_ok=True)
    project_file.parent.mkdir(parents=True, exist_ok=True)

    user_file.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"type": "http", "url": "https://user.example.com/mcp"},
                    "user-only": {"command": "npx", "args": ["-y", "user-mcp"]},
                }
            }
        ),
        encoding="utf-8",
    )
    project_file.write_text(
        json.dumps(
            {
                "mcpServers": {
                    "github": {"type": "http", "url": "https://project.example.com/mcp"},
                    "project-only": {"command": "npx", "args": ["-y", "project-mcp"]},
                }
            }
        ),
        encoding="utf-8",
    )

    monkeypatch.setattr(Path, "home", lambda: home)
    merged = load_effective_servers(project_root=project_root)

    assert merged["github"]["url"] == "https://project.example.com/mcp"  # type: ignore[index]
    assert "user-only" in merged
    assert "project-only" in merged


def test_write_mcp_servers_to_path_round_trip(tmp_path: Path) -> None:
    path = tmp_path / ".agent" / ".mcp.json"
    servers = {
        "context7": {
            "type": "http",
            "url": "https://mcp.context7.com/mcp",
            "headers": {"CONTEXT7_API_KEY": "ctx7-test"},
        }
    }
    write_mcp_servers_to_path(path=path, servers=servers)

    raw = json.loads(path.read_text(encoding="utf-8"))
    assert sorted(raw.keys()) == ["mcpServers"]
    assert raw["mcpServers"]["context7"]["url"] == "https://mcp.context7.com/mcp"

    loaded = load_mcp_servers_from_path(path)
    assert loaded["context7"]["url"] == "https://mcp.context7.com/mcp"  # type: ignore[index]
