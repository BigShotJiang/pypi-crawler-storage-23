"""测试 ExitPlanMode 工具。"""

from __future__ import annotations

import asyncio
import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.system_tools.tools import ExitPlanMode
from comate_agent_sdk.tools.system_context import bind_system_tool_context


class TestExitPlanMode(unittest.TestCase):
    def test_exit_plan_mode_reads_active_plan_file_and_returns_approval_payload(self) -> None:
        async def _run() -> None:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                plan_path = root / "plan.md"
                plan_path.write_text("# Plan\n\n- step 1", encoding="utf-8")
                with bind_system_tool_context(
                    project_root=root,
                    active_plan_path=plan_path,
                ):
                    result = await ExitPlanMode.execute(
                        summary="ready for approval",
                        execution_prompt="execute now",
                    )

                payload = json.loads(result)
                self.assertTrue(payload["ok"])
                data = payload["data"]
                self.assertEqual(data["status"], "waiting_for_plan_approval")
                self.assertEqual(data["summary"], "ready for approval")
                self.assertEqual(data["execution_prompt"], "execute now")
                self.assertEqual(data["plan_path"], str(plan_path))

                artifact_path = Path(data["plan_path"])
                self.assertTrue(artifact_path.exists())
                content = artifact_path.read_text(encoding="utf-8")
                self.assertIn("# Plan", content)

        asyncio.run(_run())

    def test_exit_plan_mode_rejects_plan_markdown_argument(self) -> None:
        async def _run() -> None:
            with tempfile.TemporaryDirectory() as td:
                root = Path(td).resolve()
                plan_path = root / "plan.md"
                plan_path.write_text("# Plan\n\n- step 1", encoding="utf-8")
                with bind_system_tool_context(
                    project_root=root,
                    active_plan_path=plan_path,
                ):
                    result = await ExitPlanMode.execute(
                        plan_markdown="# Other plan",
                        summary="ready for approval",
                    )

            payload = json.loads(result)
            self.assertFalse(payload["ok"])
            self.assertEqual(payload["error"]["code"], "INVALID_ARGUMENT")

        asyncio.run(_run())
