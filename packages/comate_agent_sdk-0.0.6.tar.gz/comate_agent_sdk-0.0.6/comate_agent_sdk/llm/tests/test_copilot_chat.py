import unittest
from unittest.mock import AsyncMock

import httpx

from comate_agent_sdk.llm.copilot.chat import ChatCopilot
from comate_agent_sdk.llm.messages import UserMessage


def _resp(
    *,
    status_code: int,
    method: str = "GET",
    url: str = "https://example.com",
    json_body: dict | None = None,
    headers: dict[str, str] | None = None,
    text: str | None = None,
) -> httpx.Response:
    request = httpx.Request(method, url)
    if json_body is not None:
        return httpx.Response(
            status_code=status_code,
            json=json_body,
            headers=headers,
            request=request,
        )
    return httpx.Response(
        status_code=status_code,
        content=(text or "").encode("utf-8"),
        headers=headers,
        request=request,
    )


class TestChatCopilot(unittest.IsolatedAsyncioTestCase):
    def _build_llm(self) -> ChatCopilot:
        return ChatCopilot(
            model="gpt-5-mini",
            api_key="gh_test_token",
            base_url="https://api.githubcopilot.com",
            github_api_url="https://api.github.com",
        )

    async def test_exchange_bearer_uses_opencode_user_agent(self) -> None:
        llm = self._build_llm()
        mock_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )
        llm._http_get = mock_get  # type: ignore[method-assign]

        token = await llm.exchange_bearer()

        self.assertEqual(token, "bearer_1")
        call_kwargs = mock_get.call_args.kwargs
        headers = call_kwargs["headers"]
        self.assertEqual(headers["Authorization"], "Token gh_test_token")
        self.assertEqual(headers["User-Agent"], "OpenCode/1.0")
        self.assertEqual(headers["Accept"], "application/json")

    async def test_ainvoke_chat_headers_do_not_set_user_agent(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        mock_post = AsyncMock(
            return_value=_resp(
                status_code=200,
                method="POST",
                url="https://api.githubcopilot.com/chat/completions",
                json_body={
                    "choices": [
                        {
                            "message": {"content": "ok"},
                            "finish_reason": "stop",
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 10,
                        "completion_tokens": 3,
                        "total_tokens": 13,
                    },
                },
            )
        )
        llm._http_post = mock_post  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="hello")])

        self.assertEqual(result.content, "ok")
        chat_headers = mock_post.call_args.kwargs["headers"]
        self.assertEqual(chat_headers["Authorization"], "Bearer bearer_1")
        self.assertEqual(chat_headers["Editor-Version"], "OpenCode/1.0")
        self.assertEqual(chat_headers["Editor-Plugin-Version"], "OpenCode/1.0")
        self.assertEqual(chat_headers["Copilot-Integration-Id"], "vscode-chat")
        self.assertNotIn("User-Agent", chat_headers)

    async def test_ainvoke_refreshes_bearer_after_401(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            side_effect=[
                _resp(
                    status_code=200,
                    json_body={"token": "bearer_old", "expires_at": 9_999_999_999},
                ),
                _resp(
                    status_code=200,
                    json_body={"token": "bearer_new", "expires_at": 9_999_999_999},
                ),
            ]
        )  # type: ignore[method-assign]
        mock_post = AsyncMock(
            side_effect=[
                _resp(status_code=401, method="POST", text="unauthorized"),
                _resp(
                    status_code=200,
                    method="POST",
                    json_body={
                        "choices": [
                            {"message": {"content": "after-refresh"}, "finish_reason": "stop"}
                        ]
                    },
                ),
            ]
        )
        llm._http_post = mock_post  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="refresh me")])

        self.assertEqual(result.content, "after-refresh")
        self.assertEqual(llm._http_get.await_count, 2)
        self.assertEqual(mock_post.await_count, 2)
        second_headers = mock_post.call_args_list[1].kwargs["headers"]
        self.assertEqual(second_headers["Authorization"], "Bearer bearer_new")

    async def test_ainvoke_retries_on_429(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        llm._http_post = AsyncMock(
            side_effect=[
                _resp(
                    status_code=429,
                    method="POST",
                    headers={"Retry-After": "0"},
                    text="rate limit",
                ),
                _resp(
                    status_code=200,
                    method="POST",
                    json_body={
                        "choices": [{"message": {"content": "retry-ok"}, "finish_reason": "stop"}]
                    },
                ),
            ]
        )  # type: ignore[method-assign]
        llm._sleep_backoff = AsyncMock()  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="retry")])

        self.assertEqual(result.content, "retry-ok")
        self.assertEqual(llm._http_post.await_count, 2)  # type: ignore[attr-defined]
        llm._sleep_backoff.assert_awaited_once()  # type: ignore[attr-defined]

    async def test_ainvoke_maps_tool_calls_and_usage(self) -> None:
        llm = self._build_llm()
        llm._http_get = AsyncMock(
            return_value=_resp(
                status_code=200,
                json_body={"token": "bearer_1", "expires_at": 9_999_999_999},
            )
        )  # type: ignore[method-assign]
        llm._http_post = AsyncMock(
            return_value=_resp(
                status_code=200,
                method="POST",
                json_body={
                    "choices": [
                        {
                            "message": {
                                "content": "need tool",
                                "tool_calls": [
                                    {
                                        "id": "call_1",
                                        "type": "function",
                                        "function": {
                                            "name": "read_file",
                                            "arguments": "{\"path\":\"README.md\"}",
                                        },
                                    }
                                ],
                                "reasoning_content": "I should call tool first.",
                            },
                            "finish_reason": "tool_calls",
                        }
                    ],
                    "usage": {
                        "prompt_tokens": 20,
                        "prompt_tokens_details": {"cached_tokens": 5},
                        "completion_tokens": 7,
                        "completion_tokens_details": {"reasoning_tokens": 3},
                        "total_tokens": 27,
                    },
                },
            )
        )  # type: ignore[method-assign]

        result = await llm.ainvoke(messages=[UserMessage(content="read readme")])

        self.assertTrue(result.has_tool_calls)
        self.assertEqual(result.tool_calls[0].function.name, "read_file")
        self.assertEqual(result.thinking, "I should call tool first.")
        assert result.usage is not None
        self.assertEqual(result.usage.prompt_tokens, 20)
        self.assertEqual(result.usage.prompt_cached_tokens, 5)
        self.assertEqual(result.usage.reasoning_tokens, 3)
        self.assertEqual(result.usage.total_tokens, 27)


if __name__ == "__main__":
    unittest.main()
