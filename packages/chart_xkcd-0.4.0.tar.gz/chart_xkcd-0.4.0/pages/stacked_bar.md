::: chart_xkcd.stacked_bar
