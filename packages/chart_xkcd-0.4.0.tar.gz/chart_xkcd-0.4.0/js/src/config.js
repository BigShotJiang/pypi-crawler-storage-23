const config = {
  positionType: {
    upLeft: 1,
    upRight: 2,
    downLeft: 3,
    downRight: 4,
  },
};

export default config;
