"""
Test fixtures for Malloy correctness testing.

This package provides shared fixtures for:
- Dataset loading from malloy-samples
- Database connection management
- Test data validation
"""
