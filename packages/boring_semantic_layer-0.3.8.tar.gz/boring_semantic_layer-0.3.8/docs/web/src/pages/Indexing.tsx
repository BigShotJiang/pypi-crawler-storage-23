import BSLMarkdownPage from './BSLMarkdownPage'

export default function Indexing() {
  return <BSLMarkdownPage pageSlug="indexing" />
}
