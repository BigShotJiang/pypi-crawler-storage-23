import BSLMarkdownPage from './BSLMarkdownPage'

export default function Filtering() {
  return <BSLMarkdownPage pageSlug="filtering" />
}
