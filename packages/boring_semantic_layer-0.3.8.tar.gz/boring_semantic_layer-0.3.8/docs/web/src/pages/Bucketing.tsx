import BSLMarkdownPage from './BSLMarkdownPage'

export default function Bucketing() {
  return <BSLMarkdownPage pageSlug="bucketing" />
}
