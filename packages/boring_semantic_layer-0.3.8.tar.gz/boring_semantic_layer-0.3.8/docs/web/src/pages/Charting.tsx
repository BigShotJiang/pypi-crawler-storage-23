import BSLMarkdownPage from './BSLMarkdownPage'

export default function Charting() {
  return <BSLMarkdownPage pageSlug="charting" />
}
