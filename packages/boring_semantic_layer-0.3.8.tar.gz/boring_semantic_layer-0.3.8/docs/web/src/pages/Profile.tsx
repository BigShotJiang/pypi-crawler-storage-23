import BSLMarkdownPage from './BSLMarkdownPage'

export default function Profile() {
  return <BSLMarkdownPage pageSlug="profile" />
}
