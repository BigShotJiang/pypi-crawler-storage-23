import BSLMarkdownPage from './BSLMarkdownPage'

export default function SemanticTable() {
  return <BSLMarkdownPage pageSlug="semantic-table" />
}
