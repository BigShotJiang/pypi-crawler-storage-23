import BSLMarkdownPage from './BSLMarkdownPage'

export default function QueryAgentChat() {
  return <BSLMarkdownPage pageSlug="query-agent-chat" />
}
