import BSLMarkdownPage from './BSLMarkdownPage'

export default function MCP() {
  return <BSLMarkdownPage pageSlug="mcp" />
}
