Override the default chart backend for this call (`plotext`, `altair`, or `plotly`). Leave `null` to use the backend configured when the agent was created.
