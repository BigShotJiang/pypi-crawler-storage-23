Return data records to LLM (default: true). Set `false` for final display-only queries where you don't need to process the data further. This saves tokens when the chart/table display is sufficient.
