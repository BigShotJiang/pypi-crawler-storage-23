Override the default chart backend for this call (`altair`, `plotly`, or `plotext`). Leave `null` to use the server's default backend (altair).
