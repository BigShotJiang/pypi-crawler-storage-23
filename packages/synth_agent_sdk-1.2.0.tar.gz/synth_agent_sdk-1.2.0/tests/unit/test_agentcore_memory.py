"""Unit tests for synth.deploy.agentcore.memory.

Covers ``AgentCoreMemory`` — construction, AgentCore API delegation,
fallback behaviour, role mapping, and error paths.
"""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from synth.deploy.agentcore.memory import (
    AgentCoreMemory,
    _AGENTCORE_ROLE_TO_SYNTH,
    _SYNTH_ROLE_TO_AGENTCORE,
)
from synth.errors import SynthConfigError
from synth.memory.base import BaseMemory
from synth.types import Message


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _StubMemory(BaseMemory):
    """In-memory stub for testing fallback behaviour."""

    def __init__(self) -> None:
        self.stored: dict[str, list[Message]] = {}

    async def get_messages(self, thread_id: str) -> list[Message]:
        return list(self.stored.get(thread_id, []))

    async def add_messages(
        self, thread_id: str, messages: list[Message],
    ) -> None:
        self.stored.setdefault(thread_id, []).extend(messages)


def _agentcore_env(
    endpoint: str = "https://memory.agentcore.example.com",
    memory_id: str = "mem-test123",
    actor_id: str = "test-actor",
) -> dict[str, str]:
    """Return env vars that make AgentCore memory available."""
    return {
        "AGENTCORE_MEMORY_ENDPOINT": endpoint,
        "AGENTCORE_MEMORY_ID": memory_id,
        "AGENTCORE_ACTOR_ID": actor_id,
    }


# ---------------------------------------------------------------------------
# Role mapping
# ---------------------------------------------------------------------------


class TestRoleMapping:
    """Verify the Synth ↔ AgentCore role translation tables."""

    @pytest.mark.parametrize(
        "synth_role,ac_role",
        [
            ("user", "USER"),
            ("assistant", "ASSISTANT"),
            ("system", "SYSTEM"),
            ("tool", "TOOL"),
        ],
    )
    def test_synth_to_agentcore(
        self, synth_role: str, ac_role: str,
    ) -> None:
        assert _SYNTH_ROLE_TO_AGENTCORE[synth_role] == ac_role

    @pytest.mark.parametrize(
        "ac_role,synth_role",
        [
            ("USER", "user"),
            ("ASSISTANT", "assistant"),
            ("SYSTEM", "system"),
            ("TOOL", "tool"),
        ],
    )
    def test_agentcore_to_synth(
        self, ac_role: str, synth_role: str,
    ) -> None:
        assert _AGENTCORE_ROLE_TO_SYNTH[ac_role] == synth_role

    def test_round_trip(self) -> None:
        for synth_role, ac_role in _SYNTH_ROLE_TO_AGENTCORE.items():
            assert _AGENTCORE_ROLE_TO_SYNTH[ac_role] == synth_role


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


class TestAgentCoreMemoryInit:
    """Tests for ``AgentCoreMemory.__init__``."""

    def test_not_available_without_env(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory()
            assert mem._agentcore_available is False

    def test_available_with_endpoint_and_memory_id(self) -> None:
        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            assert mem._agentcore_available is True

    def test_not_available_with_endpoint_only(self) -> None:
        env = {"AGENTCORE_MEMORY_ENDPOINT": "https://x.example.com"}
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory()
            assert mem._agentcore_available is False

    def test_explicit_memory_id_overrides_env(self) -> None:
        env = {"AGENTCORE_MEMORY_ENDPOINT": "https://x.example.com"}
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory(memory_id="mem-explicit")
            assert mem._agentcore_available is True
            assert mem._memory_id == "mem-explicit"

    def test_actor_id_defaults(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory()
            assert mem._actor_id == "synth-agent"

    def test_actor_id_from_env(self) -> None:
        env = {"AGENTCORE_ACTOR_ID": "my-actor"}
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory()
            assert mem._actor_id == "my-actor"

    def test_actor_id_explicit_overrides_env(self) -> None:
        env = {"AGENTCORE_ACTOR_ID": "env-actor"}
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory(actor_id="explicit-actor")
            assert mem._actor_id == "explicit-actor"

    def test_max_turns_default(self) -> None:
        mem = AgentCoreMemory()
        assert mem._max_turns == 50

    def test_max_turns_custom(self) -> None:
        mem = AgentCoreMemory(max_turns=10)
        assert mem._max_turns == 10

    def test_client_initially_none(self) -> None:
        mem = AgentCoreMemory()
        assert mem._client is None

    def test_fallback_stored(self) -> None:
        fb = _StubMemory()
        mem = AgentCoreMemory(fallback=fb)
        assert mem._fallback is fb


# ---------------------------------------------------------------------------
# _get_client — lazy init
# ---------------------------------------------------------------------------


class TestGetClient:
    """Tests for lazy MemoryClient initialisation."""

    def test_import_error_raises_config_error(self) -> None:
        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            with patch.dict(
                "sys.modules",
                {"bedrock_agentcore": None, "bedrock_agentcore.memory": None},
            ):
                with pytest.raises(
                    SynthConfigError, match="bedrock-agentcore",
                ):
                    mem._get_client()

    def test_client_cached_after_first_call(self) -> None:
        mock_client = MagicMock()
        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            assert mem._get_client() is mock_client


# ---------------------------------------------------------------------------
# Fallback behaviour
# ---------------------------------------------------------------------------


class TestFallbackBehaviour:
    """Tests for fallback to Synth-native memory."""

    @pytest.mark.asyncio
    async def test_get_messages_uses_fallback_when_unavailable(
        self,
    ) -> None:
        fb = _StubMemory()
        fb.stored["t1"] = [{"role": "user", "content": "hi"}]

        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory(fallback=fb)
            msgs = await mem.get_messages("t1")

        assert len(msgs) == 1
        assert msgs[0]["content"] == "hi"

    @pytest.mark.asyncio
    async def test_add_messages_uses_fallback_when_unavailable(
        self,
    ) -> None:
        fb = _StubMemory()

        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory(fallback=fb)
            await mem.add_messages(
                "t1", [{"role": "user", "content": "hello"}],
            )

        assert len(fb.stored["t1"]) == 1

    @pytest.mark.asyncio
    async def test_get_messages_no_fallback_raises(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory()
            with pytest.raises(
                SynthConfigError, match="No memory backend",
            ):
                await mem.get_messages("t1")

    @pytest.mark.asyncio
    async def test_add_messages_no_fallback_raises(self) -> None:
        with patch.dict("os.environ", {}, clear=True):
            mem = AgentCoreMemory()
            with pytest.raises(
                SynthConfigError, match="No memory backend",
            ):
                await mem.add_messages(
                    "t1", [{"role": "user", "content": "x"}],
                )


# ---------------------------------------------------------------------------
# AgentCore API — get_messages
# ---------------------------------------------------------------------------


class TestGetMessagesAgentCore:
    """Tests for ``get_messages`` when AgentCore is available."""

    @pytest.mark.asyncio
    async def test_converts_turns_to_messages(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = [
            [
                {"role": "USER", "content": {"text": "hello"}},
                {"role": "ASSISTANT", "content": {"text": "hi there"}},
            ],
            [
                {"role": "USER", "content": {"text": "bye"}},
                {"role": "ASSISTANT", "content": {"text": "goodbye"}},
            ],
        ]

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("session-1")

        assert len(msgs) == 4
        assert msgs[0] == {"role": "user", "content": "hello"}
        assert msgs[1] == {"role": "assistant", "content": "hi there"}
        assert msgs[2] == {"role": "user", "content": "bye"}
        assert msgs[3] == {"role": "assistant", "content": "goodbye"}

    @pytest.mark.asyncio
    async def test_passes_correct_params_to_client(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = []

        env = _agentcore_env(
            memory_id="mem-xyz", actor_id="actor-abc",
        )
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory(max_turns=25)
            mem._client = mock_client
            await mem.get_messages("sess-99")

        mock_client.get_last_k_turns.assert_called_once_with(
            memory_id="mem-xyz",
            actor_id="actor-abc",
            session_id="sess-99",
            k=25,
        )

    @pytest.mark.asyncio
    async def test_empty_turns_returns_empty_list(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = []

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("empty-session")

        assert msgs == []

    @pytest.mark.asyncio
    async def test_unknown_role_defaults_to_user(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = [
            [{"role": "UNKNOWN_ROLE", "content": {"text": "hmm"}}],
        ]

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("s1")

        assert msgs[0]["role"] == "user"

    @pytest.mark.asyncio
    async def test_api_error_falls_back(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.side_effect = RuntimeError("API down")

        fb = _StubMemory()
        fb.stored["s1"] = [{"role": "user", "content": "fallback msg"}]

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory(fallback=fb)
            mem._client = mock_client
            msgs = await mem.get_messages("s1")

        assert len(msgs) == 1
        assert msgs[0]["content"] == "fallback msg"

    @pytest.mark.asyncio
    async def test_api_error_no_fallback_returns_empty(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.side_effect = RuntimeError("boom")

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("s1")

        assert msgs == []

    @pytest.mark.asyncio
    async def test_tool_role_mapped_correctly(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = [
            [{"role": "TOOL", "content": {"text": "result: 42"}}],
        ]

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("s1")

        assert msgs[0]["role"] == "tool"

    @pytest.mark.asyncio
    async def test_missing_content_text_defaults_empty(self) -> None:
        mock_client = MagicMock()
        mock_client.get_last_k_turns.return_value = [
            [{"role": "USER", "content": {}}],
        ]

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            msgs = await mem.get_messages("s1")

        assert msgs[0]["content"] == ""


# ---------------------------------------------------------------------------
# AgentCore API — add_messages
# ---------------------------------------------------------------------------


class TestAddMessagesAgentCore:
    """Tests for ``add_messages`` when AgentCore is available."""

    @pytest.mark.asyncio
    async def test_creates_event_with_correct_params(self) -> None:
        mock_client = MagicMock()
        mock_client.create_event.return_value = {"eventId": "e1"}

        env = _agentcore_env(
            memory_id="mem-xyz", actor_id="actor-abc",
        )
        with patch.dict("os.environ", env, clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            await mem.add_messages("sess-1", [
                {"role": "user", "content": "question"},
                {"role": "assistant", "content": "answer"},
            ])

        mock_client.create_event.assert_called_once_with(
            memory_id="mem-xyz",
            actor_id="actor-abc",
            session_id="sess-1",
            messages=[("question", "USER"), ("answer", "ASSISTANT")],
        )

    @pytest.mark.asyncio
    async def test_empty_messages_skipped(self) -> None:
        mock_client = MagicMock()

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            await mem.add_messages("s1", [])

        mock_client.create_event.assert_not_called()

    @pytest.mark.asyncio
    async def test_unknown_role_defaults_to_user(self) -> None:
        mock_client = MagicMock()
        mock_client.create_event.return_value = {"eventId": "e1"}

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            await mem.add_messages("s1", [
                {"role": "unknown", "content": "test"},
            ])

        call_args = mock_client.create_event.call_args
        assert call_args.kwargs["messages"] == [("test", "USER")]

    @pytest.mark.asyncio
    async def test_api_error_falls_back(self) -> None:
        mock_client = MagicMock()
        mock_client.create_event.side_effect = RuntimeError("fail")

        fb = _StubMemory()

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory(fallback=fb)
            mem._client = mock_client
            await mem.add_messages("s1", [
                {"role": "user", "content": "saved to fallback"},
            ])

        assert len(fb.stored["s1"]) == 1
        assert fb.stored["s1"][0]["content"] == "saved to fallback"

    @pytest.mark.asyncio
    async def test_api_error_no_fallback_raises(self) -> None:
        mock_client = MagicMock()
        mock_client.create_event.side_effect = RuntimeError("fail")

        with patch.dict("os.environ", _agentcore_env(), clear=True):
            mem = AgentCoreMemory()
            mem._client = mock_client
            with pytest.raises(
                SynthConfigError, match="Failed to store messages",
            ):
                await mem.add_messages("s1", [
                    {"role": "user", "content": "x"},
                ])


# ---------------------------------------------------------------------------
# Adapter auto-wrapping
# ---------------------------------------------------------------------------


class TestAdapterEnsureMemory:
    """Tests for ``AgentCoreAdapter._ensure_memory`` auto-wrapping."""

    def test_agent_without_memory_gets_agentcore_memory(self) -> None:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter

        agent = MagicMock()
        agent.memory = None

        AgentCoreAdapter(agent)

        assert isinstance(agent.memory, AgentCoreMemory)

    def test_agent_with_existing_memory_gets_wrapped(self) -> None:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter

        fb = _StubMemory()
        agent = MagicMock()
        agent.memory = fb

        AgentCoreAdapter(agent)

        assert isinstance(agent.memory, AgentCoreMemory)
        assert agent.memory._fallback is fb

    def test_agent_with_agentcore_memory_not_double_wrapped(self) -> None:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter

        existing = AgentCoreMemory()
        agent = MagicMock()
        agent.memory = existing

        AgentCoreAdapter(agent)

        assert agent.memory is existing

    def test_graph_without_memory_attr_skipped(self) -> None:
        from synth.deploy.agentcore.adapter import AgentCoreAdapter

        class FakeGraph:
            """Graph-like object without memory attribute."""

            pass

        graph = FakeGraph()
        # Should not raise
        AgentCoreAdapter(graph)
        assert not hasattr(graph, "memory")
