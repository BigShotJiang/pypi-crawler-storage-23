"""Unit tests for UI server feature parity fixes.

Covers:
- isinstance-based event detection with actual event instances
- Tool error surfacing in /api/info response
- Streaming yields events incrementally via queue

_Requirements: 4.3, 4.4, 4.5_
"""

from __future__ import annotations

import queue
import threading
from typing import Any
from unittest.mock import MagicMock

import pytest

from synth.types import (
    DoneEvent,
    ErrorEvent,
    RunResult,
    ThinkingEvent,
    TokenEvent,
    TokenUsage,
    ToolCallEvent,
    ToolResultEvent,
)


# ---------------------------------------------------------------------------
# isinstance-based event detection (Requirement 4.5)
# ---------------------------------------------------------------------------


class TestIsinstanceEventDetection:
    """Verify isinstance() correctly identifies each event type.

    The UI server uses isinstance() checks instead of string-based
    type(event).__name__ matching. These tests confirm that real event
    instances are detected correctly.

    **Validates: Requirement 4.5**
    """

    def test_thinking_event_detected_by_isinstance(self) -> None:
        """ThinkingEvent instances pass isinstance(event, ThinkingEvent)."""
        event = ThinkingEvent(text="reasoning step")
        assert isinstance(event, ThinkingEvent)
        assert not isinstance(event, TokenEvent)
        assert not isinstance(event, ToolCallEvent)
        assert not isinstance(event, DoneEvent)

    def test_token_event_detected_by_isinstance(self) -> None:
        """TokenEvent instances pass isinstance(event, TokenEvent)."""
        event = TokenEvent(text="hello")
        assert isinstance(event, TokenEvent)
        assert not isinstance(event, ThinkingEvent)
        assert not isinstance(event, ToolCallEvent)
        assert not isinstance(event, DoneEvent)

    def test_tool_call_event_detected_by_isinstance(self) -> None:
        """ToolCallEvent instances pass isinstance(event, ToolCallEvent)."""
        event = ToolCallEvent(name="search", args={"q": "test"})
        assert isinstance(event, ToolCallEvent)
        assert not isinstance(event, ThinkingEvent)
        assert not isinstance(event, TokenEvent)
        assert not isinstance(event, DoneEvent)

    def test_done_event_detected_by_isinstance(self) -> None:
        """DoneEvent instances pass isinstance(event, DoneEvent)."""
        result = RunResult(
            text="done",
            output=None,
            tokens=TokenUsage(input_tokens=1, output_tokens=1, total_tokens=2),
            cost=0.0,
            latency_ms=10.0,
            trace=None,
        )
        event = DoneEvent(result=result)
        assert isinstance(event, DoneEvent)
        assert not isinstance(event, ThinkingEvent)
        assert not isinstance(event, TokenEvent)
        assert not isinstance(event, ToolCallEvent)

    def test_error_event_not_confused_with_other_types(self) -> None:
        """ErrorEvent is distinct from all other event types."""
        event = ErrorEvent(error=RuntimeError("boom"))
        assert isinstance(event, ErrorEvent)
        assert not isinstance(event, ThinkingEvent)
        assert not isinstance(event, TokenEvent)
        assert not isinstance(event, ToolCallEvent)
        assert not isinstance(event, DoneEvent)

    def test_tool_result_event_not_confused_with_tool_call(self) -> None:
        """ToolResultEvent is distinct from ToolCallEvent."""
        event = ToolResultEvent(name="search", result="found it")
        assert isinstance(event, ToolResultEvent)
        assert not isinstance(event, ToolCallEvent)

    @pytest.mark.parametrize(
        "event_cls,kwargs",
        [
            (ThinkingEvent, {"text": "think"}),
            (TokenEvent, {"text": "tok"}),
            (ToolCallEvent, {"name": "fn", "args": {}}),
        ],
        ids=["thinking", "token", "tool_call"],
    )
    def test_isinstance_matches_server_branching_logic(
        self, event_cls: type, kwargs: dict[str, Any],
    ) -> None:
        """Each event type triggers exactly one isinstance branch.

        This mirrors the if/elif chain in server.py's generate() function.
        """
        event = event_cls(**kwargs)
        branches_hit = sum([
            isinstance(event, ThinkingEvent),
            isinstance(event, TokenEvent),
            isinstance(event, ToolCallEvent),
        ])
        assert branches_hit == 1


# ---------------------------------------------------------------------------
# Tool error surfacing in /api/info (Requirement 4.4)
# ---------------------------------------------------------------------------


class TestToolErrorSurfacing:
    """Verify tool initialization errors appear in the agent status dict.

    The UI server stores tool errors in _agent_status["tool_errors"]
    and exposes them via the /api/info endpoint.

    **Validates: Requirement 4.4**
    """

    def test_agent_status_contains_tool_errors_key(self) -> None:
        """A freshly loaded agent status dict has a tool_errors list."""
        status: dict[str, Any] = {
            "loaded": True,
            "error": None,
            "file": "agent.py",
            "tool_errors": [],
        }
        assert "tool_errors" in status
        assert isinstance(status["tool_errors"], list)

    def test_tool_errors_populated_on_init_failure(self) -> None:
        """When a tool fails to initialize, the error is captured."""
        status: dict[str, Any] = {
            "loaded": True,
            "error": None,
            "file": "agent.py",
            "tool_errors": [],
        }
        # Simulate what _load_agent does when tool.get_schema() fails
        tool_errors: list[str] = []
        mock_tool = MagicMock()
        mock_tool.get_schema.side_effect = TypeError("bad param type")
        try:
            mock_tool.get_schema()
        except Exception as exc:
            tool_errors.append(f"Tool 'broken_tool' failed to initialize: {exc}")

        status["tool_errors"] = tool_errors
        assert len(status["tool_errors"]) == 1
        assert "broken_tool" in status["tool_errors"][0]
        assert "bad param type" in status["tool_errors"][0]

    def test_multiple_tool_errors_all_captured(self) -> None:
        """Multiple tool init failures are all stored."""
        errors = [
            "Tool 'tool_a' failed to initialize: missing param",
            "Tool 'tool_b' failed to initialize: bad return type",
        ]
        status: dict[str, Any] = {
            "loaded": True,
            "error": None,
            "file": "agent.py",
            "tool_errors": errors,
        }
        assert len(status["tool_errors"]) == 2
        assert "tool_a" in status["tool_errors"][0]
        assert "tool_b" in status["tool_errors"][1]

    def test_info_response_includes_tool_errors(self) -> None:
        """The /api/info response dict includes tool_errors from status.

        This mirrors the agent_info() endpoint logic.
        """
        status: dict[str, Any] = {
            "loaded": True,
            "error": None,
            "file": "agent.py",
            "tool_errors": ["Tool 'x' failed to initialize: oops"],
        }
        # Replicate the response construction from agent_info()
        info_response = {
            "model": "test-model",
            "tools": 0,
            "instructions": "",
            "status": status,
            "tool_errors": status.get("tool_errors", []),
        }
        assert info_response["tool_errors"] == [
            "Tool 'x' failed to initialize: oops",
        ]

    def test_info_response_empty_when_no_errors(self) -> None:
        """When no tool errors occur, tool_errors is an empty list."""
        status: dict[str, Any] = {
            "loaded": True,
            "error": None,
            "file": "agent.py",
            "tool_errors": [],
        }
        info_response = {
            "status": status,
            "tool_errors": status.get("tool_errors", []),
        }
        assert info_response["tool_errors"] == []


# ---------------------------------------------------------------------------
# Streaming yields events incrementally (Requirement 4.3)
# ---------------------------------------------------------------------------


class TestStreamingYieldsIncrementally:
    """Verify the queue-based streaming yields events one at a time.

    The server uses a background thread that pushes events into a
    queue.Queue, and the async generator pulls them out individually.
    This tests the queue mechanism directly.

    **Validates: Requirement 4.3**
    """

    def test_queue_receives_events_individually(self) -> None:
        """Each event from the agent stream is put into the queue
        as a separate item, not buffered into a list.
        """
        events = [
            ThinkingEvent(text="hmm"),
            TokenEvent(text="Hello"),
            TokenEvent(text=" world"),
            ToolCallEvent(name="search", args={"q": "test"}),
        ]

        q: queue.Queue[Any] = queue.Queue()

        def _stream_to_queue(q: queue.Queue[Any]) -> None:
            try:
                for event in events:
                    q.put(event)
            finally:
                q.put(None)

        thread = threading.Thread(
            target=_stream_to_queue, args=(q,), daemon=True,
        )
        thread.start()
        thread.join(timeout=5)

        received: list[Any] = []
        while True:
            item = q.get(timeout=2)
            if item is None:
                break
            received.append(item)

        assert len(received) == len(events)
        for original, got in zip(events, received):
            assert got is original

    def test_queue_sentinel_signals_end_of_stream(self) -> None:
        """The None sentinel terminates the consumer loop."""
        q: queue.Queue[Any] = queue.Queue()

        def _stream_to_queue(q: queue.Queue[Any]) -> None:
            q.put(TokenEvent(text="a"))
            q.put(None)

        thread = threading.Thread(
            target=_stream_to_queue, args=(q,), daemon=True,
        )
        thread.start()
        thread.join(timeout=5)

        items = []
        while True:
            item = q.get(timeout=2)
            if item is None:
                break
            items.append(item)

        assert len(items) == 1
        assert isinstance(items[0], TokenEvent)

    def test_queue_propagates_exceptions(self) -> None:
        """If the stream raises, the exception is put on the queue."""
        q: queue.Queue[Any] = queue.Queue()

        def _stream_to_queue(q: queue.Queue[Any]) -> None:
            try:
                q.put(TokenEvent(text="ok"))
                raise RuntimeError("stream broke")
            except Exception as exc:
                q.put(exc)
            finally:
                q.put(None)

        thread = threading.Thread(
            target=_stream_to_queue, args=(q,), daemon=True,
        )
        thread.start()
        thread.join(timeout=5)

        first = q.get(timeout=2)
        assert isinstance(first, TokenEvent)

        second = q.get(timeout=2)
        assert isinstance(second, RuntimeError)
        assert "stream broke" in str(second)

    def test_events_arrive_in_order(self) -> None:
        """Events are received in the same order they were produced."""
        events = [
            ThinkingEvent(text="step 1"),
            ThinkingEvent(text="step 2"),
            TokenEvent(text="A"),
            TokenEvent(text="B"),
            ToolCallEvent(name="tool1", args={}),
        ]

        q: queue.Queue[Any] = queue.Queue()

        def _stream_to_queue(q: queue.Queue[Any]) -> None:
            for event in events:
                q.put(event)
            q.put(None)

        thread = threading.Thread(
            target=_stream_to_queue, args=(q,), daemon=True,
        )
        thread.start()
        thread.join(timeout=5)

        received = []
        while True:
            item = q.get(timeout=2)
            if item is None:
                break
            received.append(item)

        assert received == events

    def test_tool_call_event_yielded_immediately(self) -> None:
        """ToolCallEvent is yielded as soon as it arrives, not buffered.

        This verifies the fix for Requirement 4.3: tool call events
        are available to the consumer before the stream completes.
        """
        q: queue.Queue[Any] = queue.Queue()
        barrier = threading.Event()

        def _stream_to_queue(q: queue.Queue[Any]) -> None:
            q.put(ToolCallEvent(name="search", args={"q": "x"}))
            # Signal that the tool call was put, then wait
            barrier.set()
            # Simulate more work after the tool call
            q.put(TokenEvent(text="result"))
            q.put(None)

        thread = threading.Thread(
            target=_stream_to_queue, args=(q,), daemon=True,
        )
        thread.start()

        # Wait for the producer to put the tool call event
        barrier.wait(timeout=5)

        # The tool call should be available immediately
        item = q.get(timeout=2)
        assert isinstance(item, ToolCallEvent)
        assert item.name == "search"

        # Clean up remaining items
        thread.join(timeout=5)
