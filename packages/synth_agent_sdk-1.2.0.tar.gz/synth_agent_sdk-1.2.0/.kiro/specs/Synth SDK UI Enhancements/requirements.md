# Requirements Document

## Introduction

This document specifies requirements for enhancing the Synth SDK's browser-based testing dashboard UI. The dashboard is a single-page vanilla JS application served by a FastAPI backend (`server.py`) that bridges the browser to the user's Synth agent. The enhancements add four capabilities: a live agent configuration panel for runtime model/instructions/tools changes, a guard visibility panel showing guard evaluation results, streaming performance metrics (TTFT, tokens/sec, duration), and enhanced export functionality for conversations and eval results.

## Glossary

- **Dashboard**: The browser-based testing UI served at `http://localhost:8420`, consisting of HTML, CSS, and vanilla JavaScript files in `synth/cli/_ui_assets/`.
- **Server**: The FastAPI backend (`server.py`) that loads the agent module, exposes API endpoints, and serves the Dashboard.
- **Agent**: An instance of `synth.agent.Agent` loaded from the user's agent Python file (e.g., `agent.py`), exposing `model`, `instructions`, `_registered_tools`, and `guards` attributes.
- **Agent_File**: The user's Python source file that defines and exports an `agent` variable containing an Agent instance.
- **Config_Panel**: A new Dashboard tab that displays and allows editing of the Agent's runtime configuration (model, instructions, tools).
- **Guard**: An instance of a `BaseGuard` subclass (PIIGuard, CostGuard, ToolFilterGuard, CustomGuard) attached to the Agent via the `guards` list.
- **Guard_Result**: A pass/fail outcome from evaluating a Guard's `check()` method, including execution time and any violation message.
- **Telemetry_Panel**: The existing right-sidebar panel in the Dashboard that displays token counts, cost, and latency for the most recent response.
- **TTFT**: Time to First Token — the elapsed time from sending a chat request to receiving the first `TokenEvent` in the SSE stream.
- **Streaming_Metrics**: A set of performance measurements (TTFT, tokens per second, streaming duration) computed from the SSE event stream.
- **SSE**: Server-Sent Events — the streaming protocol used by the `/api/chat/stream` endpoint to deliver incremental response data to the Dashboard.
- **Atomic_Write**: A file write strategy using a temporary file and `os.replace()` to prevent corruption, as implemented in `synth/cli/edit_cmd.py._atomic_write()`.
- **Runtime_Config**: The in-memory state of the Agent's model, instructions, and enabled tools, which may differ from the on-disk Agent_File after runtime edits.

## Requirements

### Requirement 1: Agent Configuration Introspection

**User Story:** As a developer, I want the Server to expose the Agent's current configuration via API endpoints, so that the Config_Panel can display and modify it.

#### Acceptance Criteria

1. WHEN the Dashboard requests the agent configuration, THE Server SHALL return a JSON object containing the current model identifier, full instructions text, and a list of all registered tools with their names, descriptions, and enabled status.
2. WHEN the Dashboard requests the list of available models, THE Server SHALL return a list of model identifiers grouped by provider, sourced from the SDK's provider registry.
3. WHEN the Dashboard requests guard information, THE Server SHALL return a list of configured Guards with each Guard's name and type (e.g., "PIIGuard", "CostGuard", "ToolFilterGuard", "CustomGuard").

### Requirement 2: Runtime Model Swapping

**User Story:** As a developer, I want to change the Agent's model at runtime from the Config_Panel, so that I can test different models without restarting the server.

#### Acceptance Criteria

1. WHEN a user selects a new model in the Config_Panel, THE Server SHALL update the Agent's model attribute and re-resolve the provider in memory.
2. WHEN the model is updated at runtime, THE Server SHALL use the new model for all subsequent chat requests without requiring a server restart.
3. IF the specified model identifier is not recognized by the provider registry, THEN THE Server SHALL return an error response with a descriptive message and leave the current model unchanged.

### Requirement 3: Runtime Instructions Editing

**User Story:** As a developer, I want to edit the Agent's system instructions at runtime from the Config_Panel, so that I can iterate on prompts without restarting.

#### Acceptance Criteria

1. WHEN a user submits updated instructions via the Config_Panel, THE Server SHALL update the Agent's instructions attribute in memory.
2. WHEN instructions are updated at runtime, THE Server SHALL use the new instructions for all subsequent chat requests.

### Requirement 4: Runtime Tool Toggling

**User Story:** As a developer, I want to enable or disable individual tools at runtime from the Config_Panel, so that I can test the Agent's behavior with different tool combinations.

#### Acceptance Criteria

1. WHEN a user disables a tool via the Config_Panel, THE Server SHALL remove that tool from the Agent's active tool set so it is not available during subsequent runs.
2. WHEN a user re-enables a previously disabled tool, THE Server SHALL restore that tool to the Agent's active tool set.
3. THE Server SHALL maintain the full original tool registry so that disabled tools can be re-enabled without reloading the Agent module.

### Requirement 5: Save Configuration to File

**User Story:** As a developer, I want to persist my runtime configuration changes back to the Agent_File on disk, so that changes survive server restarts.

#### Acceptance Criteria

1. WHEN a user triggers "Save to file" from the Config_Panel, THE Server SHALL write the current Runtime_Config (model, instructions, tools list) back to the Agent_File using Atomic_Write.
2. WHEN saving to file, THE Server SHALL use regex-based replacement to patch the `model=`, `instructions=`, and `tools=` arguments in the Agent constructor call, matching the patterns used by `synth edit agent`.
3. IF the Agent_File structure does not match the expected `Agent(model="...", instructions="...", tools=[...])` pattern (e.g., model comes from an environment variable or config file), THEN THE Server SHALL return a warning message describing which fields could not be patched and leave those fields unchanged in the file.
4. WHEN saving to file, THE Server SHALL validate that the model string and instructions string are non-empty before writing.

### Requirement 6: Reset Configuration

**User Story:** As a developer, I want to reset the Agent's runtime configuration to match the on-disk file, so that I can undo runtime changes.

#### Acceptance Criteria

1. WHEN a user triggers "Reset" from the Config_Panel, THE Server SHALL reload the Agent module from the Agent_File and replace the in-memory Agent instance.
2. WHEN the Agent is reset, THE Config_Panel SHALL refresh to display the newly loaded configuration values.

### Requirement 7: Configuration Drift Indicator

**User Story:** As a developer, I want a visual indicator when the runtime configuration differs from the on-disk file, so that I know when I have unsaved changes.

#### Acceptance Criteria

1. WHILE the Runtime_Config differs from the last-loaded on-disk configuration, THE Config_Panel SHALL display a visible change indicator (dot or badge) on the Config tab.
2. WHEN the user saves to file or resets the configuration, THE Config_Panel SHALL remove the change indicator.
3. THE Dashboard SHALL track the original on-disk configuration values at load time and compare them against current Runtime_Config to determine drift status.

### Requirement 8: Guard Evaluation Visibility

**User Story:** As a developer, I want to see guard evaluation results after each chat response, so that I can understand which guards ran and whether they passed or failed.

#### Acceptance Criteria

1. WHEN a chat response completes, THE Server SHALL include guard evaluation results in the response data, containing each Guard's name, pass/fail status, execution time in milliseconds, and any violation message.
2. WHEN guard results are available, THE Telemetry_Panel SHALL display each Guard's name, status (pass/fail), and execution time.
3. WHEN a Guard check fails, THE Telemetry_Panel SHALL display the violation message for that Guard.
4. WHEN streaming via SSE, THE Server SHALL emit a `guard_result` event type containing the guard evaluation results before the final `done` event.

### Requirement 9: Streaming Performance Metrics

**User Story:** As a developer, I want to see streaming performance metrics (TTFT, tokens/sec, duration) in the Telemetry_Panel, so that I can evaluate model responsiveness.

#### Acceptance Criteria

1. WHEN a streaming chat response is in progress, THE Dashboard SHALL compute TTFT as the elapsed time from the request initiation to the receipt of the first `token` SSE event.
2. WHEN a streaming chat response completes, THE Dashboard SHALL compute the output token generation rate as the number of output tokens divided by the streaming duration in seconds.
3. WHEN a streaming chat response completes, THE Dashboard SHALL compute the streaming duration as the elapsed time from the first `token` event to the final `done` event.
4. WHEN streaming metrics are computed, THE Telemetry_Panel SHALL display TTFT, tokens per second, and streaming duration alongside the existing token count, cost, and latency cards.

### Requirement 10: Conversation Export as JSON

**User Story:** As a developer, I want to export a conversation as a JSON file, so that I can archive or share the full conversation with all metadata.

#### Acceptance Criteria

1. WHEN a user triggers JSON export for a conversation, THE Dashboard SHALL generate a JSON file containing all messages with their roles, content, timestamps, and for agent messages: token counts, cost, latency, tool calls, and trace data.
2. WHEN the JSON file is generated, THE Dashboard SHALL trigger a browser download with the filename format `conversation-{id}-{timestamp}.json`.

### Requirement 11: Conversation Export as Markdown

**User Story:** As a developer, I want to export a conversation as a Markdown file, so that I can read and share it in a human-friendly format.

#### Acceptance Criteria

1. WHEN a user triggers Markdown export for a conversation, THE Dashboard SHALL generate a Markdown file containing all messages formatted with role headers, message content, and inline tool call details.
2. WHEN the Markdown file is generated, THE Dashboard SHALL trigger a browser download with the filename format `conversation-{id}-{timestamp}.md`.

### Requirement 12: Eval Results Export as JSON

**User Story:** As a developer, I want to export eval run results as a JSON file, so that I can integrate eval data into CI pipelines or external analysis tools.

#### Acceptance Criteria

1. WHEN a user triggers eval export after running evals, THE Dashboard SHALL generate a JSON file containing all eval run results with case names, inputs, expected outputs, actual outputs, scores, LLM judge results, regression scores, token counts, cost, and pass/fail status.
2. WHEN the eval JSON file is generated, THE Dashboard SHALL trigger a browser download with the filename format `eval-results-{timestamp}.json`.

### Requirement 13: Export Button Placement

**User Story:** As a developer, I want export buttons in contextually appropriate locations, so that I can easily find and use them.

#### Acceptance Criteria

1. THE Dashboard SHALL display JSON and Markdown export buttons in the conversation header area of the Chat tab.
2. THE Dashboard SHALL display a JSON export button in the eval results toolbar of the Evals tab, visible after eval runs complete.

### Requirement 14: AgentCore Deployment Awareness

**User Story:** As a developer with an agent deployed to AgentCore, I want the Dashboard to detect the deployment context and surface AgentCore-specific information, so that I can correlate local testing with deployed behavior.

#### Acceptance Criteria

1. WHEN the Agent is configured with an `agentcore.yaml` file in the same directory as the Agent_File, THE Server SHALL detect the AgentCore deployment context and include deployment metadata (agent name, AWS region, model ID) in the agent info response.
2. WHEN AgentCore deployment metadata is available, THE Config_Panel SHALL display a deployment status section showing the agent name, region, and deployed model ID.
3. WHEN the runtime model differs from the model ID in `agentcore.yaml`, THE Config_Panel SHALL display a warning indicating the local model does not match the deployed configuration.

### Requirement 15: Config Panel UI

**User Story:** As a developer, I want the Config_Panel to match the existing CRT/terminal aesthetic, so that the UI remains visually consistent.

#### Acceptance Criteria

1. THE Config_Panel SHALL use the same green-on-dark CRT terminal theme as the existing Dashboard tabs.
2. THE Config_Panel SHALL display a model selector dropdown grouped by provider, an editable textarea for instructions, and a list of tools with toggle switches.
3. THE Config_Panel SHALL display "Save to file" and "Reset" action buttons.
4. WHEN a runtime configuration change is made, THE Config_Panel SHALL enable the "Save to file" button and display the drift indicator.
