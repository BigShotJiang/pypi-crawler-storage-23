"""``synth doctor`` command — check environment and dependencies."""

from __future__ import annotations

import configparser
import os
import platform
import re
import subprocess
import sys
from pathlib import Path

import click


_PROVIDER_ENV_VARS = {
    "Anthropic": "ANTHROPIC_API_KEY",
    "OpenAI": "OPENAI_API_KEY",
    "Google": "GOOGLE_API_KEY",
}

_OPTIONAL_PACKAGES = {
    "anthropic": "synth[anthropic]",
    "openai": "synth[openai]",
    "google.genai": "synth[google]",
    "boto3": "synth[bedrock]",
}


def run_doctor() -> None:
    """Check environment variables, credentials, and dependency versions."""
    issues = 0
    missing_providers: list[str] = []

    # 1. Python version
    v = sys.version_info
    if v >= (3, 10):
        _ok(f"Python {v.major}.{v.minor}.{v.micro}")
    else:
        _fail(f"Python {v.major}.{v.minor} — requires 3.10+")
        issues += 1

    # 2. Platform and environment checks
    issues += _check_platform()

    # 3. Core dependencies
    for pkg in ("pydantic", "httpx", "click"):
        try:
            import importlib.metadata as _meta
            ver = _meta.version(pkg)
            _ok(f"{pkg} {ver}")
        except _meta.PackageNotFoundError:
            _fail(f"{pkg} not installed. Run: pip install synth-agent-sdk")
            issues += 1

    # 4. Provider env vars
    for name, var in _PROVIDER_ENV_VARS.items():
        if os.environ.get(var):
            _ok(f"{name} ({var} set)")
        else:
            _info(f"{name} ({var} not set)")

    # 5. SYNTH_TRACE_ENDPOINT
    endpoint = os.environ.get("SYNTH_TRACE_ENDPOINT")
    if endpoint:
        if endpoint.startswith("https://"):
            _ok(f"SYNTH_TRACE_ENDPOINT: {endpoint[:40]}...")
        else:
            _fail("SYNTH_TRACE_ENDPOINT should use HTTPS")
            issues += 1
    else:
        _info("SYNTH_TRACE_ENDPOINT not set (traces local only)")

    # 6. Optional provider packages
    for pkg, extra in _OPTIONAL_PACKAGES.items():
        try:
            __import__(pkg)
            _ok(f"{extra} installed")
        except ImportError:
            _info(f"{extra} not installed")
            missing_providers.append(extra)

    # 7. AWS credentials
    has_aws_env = bool(os.environ.get("AWS_ACCESS_KEY_ID"))
    has_aws_file = os.path.exists(
        os.path.join(os.path.expanduser("~"), ".aws", "credentials"),
    )
    if has_aws_env or has_aws_file:
        source = "env vars" if has_aws_env else "~/.aws/credentials"
        _ok(f"AWS credentials found ({source})")
    else:
        _info(
            "AWS credentials not configured. "
            "Run: pip install awscli && aws configure"
        )

    # 8. AgentCore-specific checks (only when agentcore.yaml is present)
    issues += _check_agentcore()

    # Summary
    click.echo("")
    if issues == 0:
        click.echo(click.style("All checks passed.", fg="green"))
    else:
        click.echo(click.style(f"{issues} issue(s) found.", fg="red"))

    # Helpful suggestions for missing providers
    if missing_providers:
        click.echo("")
        click.echo(click.style("Missing provider packages:", fg="yellow"))
        click.echo(f"  Install all: pip install synth-agent-sdk[all]")
        click.echo(f"  Or individually: pip install {' '.join(missing_providers)}")


# ---------------------------------------------------------------------------
# Platform and environment checks
# ---------------------------------------------------------------------------


def _check_platform() -> int:
    """Check platform-specific environment health.

    Returns
    -------
    int
        Number of issues found.
    """
    issues = 0
    is_macos = sys.platform == "darwin"
    arch = platform.machine()

    # Virtual environment check (all platforms)
    in_venv = (
        sys.prefix != sys.base_prefix
        or os.environ.get("VIRTUAL_ENV") is not None
        or os.environ.get("CONDA_DEFAULT_ENV") is not None
    )
    if in_venv:
        venv_type = "conda" if os.environ.get("CONDA_DEFAULT_ENV") else "venv"
        _ok(f"Running inside {venv_type} ({sys.prefix})")
    else:
        if is_macos:
            _fail(
                "Not running in a virtual environment. "
                "On macOS, install into a venv to avoid system Python conflicts: "
                "python3 -m venv .venv && source .venv/bin/activate"
            )
            issues += 1
        else:
            _info(
                "Not running in a virtual environment. "
                "Recommended: python -m venv .venv"
            )

    if not is_macos:
        return issues

    # macOS-specific checks below
    _ok(f"macOS detected ({arch})")

    # Xcode Command Line Tools
    has_xcode_clt = _has_xcode_clt()
    if has_xcode_clt:
        _ok("Xcode Command Line Tools installed")
    else:
        _info(
            "Xcode Command Line Tools not detected. "
            "Required for native extensions (bedrock/agentcore extras). "
            "Run: xcode-select --install"
        )

    # Architecture mismatch (Rosetta Python on Apple Silicon)
    if arch == "arm64" and platform.processor() == "arm":
        # Native arm64 — good
        pass
    elif arch == "arm64":
        # platform.machine() is arm64 but let's check the Python binary
        python_arch = _get_python_arch()
        if python_arch and "x86_64" in python_arch:
            _fail(
                "Python is running under Rosetta (x86_64) on Apple Silicon. "
                "Native arm64 Python is recommended. "
                "If using pyenv: PYTHON_CONFIGURE_OPTS='--enable-framework' "
                "arch -arm64 pyenv install 3.12"
            )
            issues += 1

    # awscrt wheel availability on Apple Silicon
    if arch == "arm64":
        issues += _check_awscrt_apple_silicon()

    return issues


def _has_xcode_clt() -> bool:
    """Check if Xcode Command Line Tools are installed on macOS."""
    try:
        result = subprocess.run(
            ["xcode-select", "-p"],
            capture_output=True,
            timeout=5,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _get_python_arch() -> str | None:
    """Return the architecture string of the running Python binary."""
    try:
        result = subprocess.run(
            ["file", sys.executable],
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout if result.returncode == 0 else None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _check_awscrt_apple_silicon() -> int:
    """Warn if awscrt is needed but not installed on Apple Silicon.

    Returns 1 if a failure is printed, 0 otherwise.
    """
    try:
        import awscrt  # noqa: F401
        _ok("awscrt installed (native wheel)")
        return 0
    except ImportError:
        # Only warn if boto3 is installed (user has bedrock/agentcore extra)
        try:
            import boto3  # noqa: F401
        except ImportError:
            return 0  # No AWS extras installed, nothing to warn about

        _info(
            "awscrt not installed. The bedrock/agentcore extras use "
            "botocore[crt] which requires a compiled wheel. "
            "If installation fails, install without CRT: "
            "pip install botocore boto3 && "
            "pip install synth-agent-sdk[agentcore]"
        )
        return 0


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------


def _ok(msg: str) -> None:
    """Print an OK status line."""
    click.echo(f"  {click.style('[  OK  ]', fg='green')} {msg}")


def _fail(msg: str) -> None:
    """Print a FAIL status line."""
    click.echo(f"  {click.style('[FAIL]', fg='red')}  {msg}")


def _info(msg: str) -> None:
    """Print an info status line."""
    click.echo(f"  {click.style('[INFO]', fg='yellow')}  {msg}")


# ---------------------------------------------------------------------------
# AgentCore-specific checks
# ---------------------------------------------------------------------------

# Regex for valid AWS region strings (e.g. us-east-1, eu-west-2, ap-southeast-1)
_AWS_REGION_RE = re.compile(
    r"^(us|eu|ap|sa|ca|me|af|il|mx|ap-east|us-gov|us-iso|us-isob)"
    r"-[a-z]+-\d+$"
)


def _check_agentcore() -> int:
    """Run AgentCore-specific doctor checks if ``agentcore.yaml`` is present.

    Returns
    -------
    int
        Number of issues found (0 if file absent or all checks pass).
    """
    yaml_path = Path("agentcore.yaml")
    if not yaml_path.exists():
        return 0  # Requirement 6.6 — skip silently

    try:
        import yaml  # type: ignore[import-untyped]
    except ImportError:
        _info("agentcore.yaml found but PyYAML not installed — skipping AgentCore checks")
        return 0

    try:
        with yaml_path.open() as fh:
            config: dict = yaml.safe_load(fh) or {}
    except Exception as exc:  # noqa: BLE001
        _fail(f"agentcore.yaml could not be parsed: {exc}")
        return 1

    click.echo("")
    click.echo(click.style("AgentCore configuration:", fg="cyan"))

    issues = 0

    # -- aws_region ----------------------------------------------------------
    aws_region: str = config.get("aws_region", "")
    if aws_region and _AWS_REGION_RE.match(aws_region):
        _ok(f"aws_region: {aws_region}")
    else:
        _fail(
            f"aws_region '{aws_region}' is not a valid AWS region. "
            "Update agentcore.yaml with a valid region (e.g. us-east-1)."
        )
        issues += 1

    # -- model_id ------------------------------------------------------------
    model_id: str = config.get("model_id", "")
    issues += _check_model_id(model_id, aws_region)

    # -- cris_enabled vs model_id --------------------------------------------
    cris_enabled: bool = bool(config.get("cris_enabled", False))
    issues += _check_cris_consistency(model_id, aws_region, cris_enabled)

    # -- aws_profile (optional) ----------------------------------------------
    aws_profile: str | None = config.get("aws_profile")
    if aws_profile:
        issues += _check_aws_profile(aws_profile)

    return issues


def _check_model_id(model_id: str, aws_region: str) -> int:
    """Validate ``model_id`` against the ModelCatalog for the given region.

    Returns 1 if a failure is printed, 0 otherwise.
    """
    if not model_id:
        _fail("model_id is missing from agentcore.yaml.")
        return 1

    try:
        from synth.deploy.agentcore.model_catalog import ModelCatalog, RegionValidator

        catalog = ModelCatalog()
        validator = RegionValidator(catalog)
        available = validator.models_for_region(aws_region)
        available_ids = {e.model_id for e in available}
        # Also accept CRIS profile IDs stored in agentcore.yaml
        available_cris_ids = {e.cris_profile_id for e in available}

        if model_id in available_ids or model_id in available_cris_ids:
            _ok(f"model_id: {model_id}")
            return 0
        else:
            _fail(
                f"model_id '{model_id}' is not available in region '{aws_region}'. "
                "Run: synth edit agent agent.py to select a valid model."
            )
            return 1
    except Exception as exc:  # noqa: BLE001
        _info(f"Could not validate model_id against catalog: {exc}")
        return 0


def _check_cris_consistency(
    model_id: str, aws_region: str, cris_enabled: bool
) -> int:
    """Check that ``cris_enabled`` matches what the model requires.

    Returns 1 if a failure is printed, 0 otherwise.
    """
    if not model_id or not aws_region:
        return 0

    try:
        from synth.deploy.agentcore.model_catalog import ModelCatalog, RegionValidator

        catalog = ModelCatalog()
        validator = RegionValidator(catalog)
        requires = validator.requires_cris(model_id, aws_region)

        if requires and not cris_enabled:
            _fail(
                f"model_id '{model_id}' requires CRIS in region '{aws_region}' "
                "but cris_enabled is false or absent. "
                "Run: synth edit agent agent.py to correct the model configuration."
            )
            return 1
        return 0
    except Exception:  # noqa: BLE001
        return 0


def _check_aws_profile(profile_name: str) -> int:
    """Verify that ``profile_name`` exists in ``~/.aws/credentials`` or AWS Toolkit.

    Returns 1 if a failure is printed, 0 otherwise.
    """
    # Check ~/.aws/credentials
    credentials_path = Path.home() / ".aws" / "credentials"
    if credentials_path.exists():
        cfg = configparser.ConfigParser()
        cfg.read(credentials_path)
        if profile_name in cfg:
            _ok(f"aws_profile '{profile_name}' found in ~/.aws/credentials")
            return 0

    # Check AWS Toolkit SSO cache (profile names stored in JSON files)
    sso_cache = Path.home() / ".aws" / "sso" / "cache"
    if sso_cache.exists():
        import json

        for cache_file in sso_cache.glob("*.json"):
            try:
                data = json.loads(cache_file.read_text())
                if data.get("profileName") == profile_name:
                    _ok(f"aws_profile '{profile_name}' found in AWS Toolkit store")
                    return 0
            except Exception:  # noqa: BLE001
                continue

    _fail(
        f"aws_profile '{profile_name}' not found in ~/.aws/credentials "
        "or AWS Toolkit store. Run: aws configure --profile {profile_name}"
    )
    return 1
