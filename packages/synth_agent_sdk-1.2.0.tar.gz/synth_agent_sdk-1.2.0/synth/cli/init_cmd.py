"""``synth init`` command — interactive project initializer.

Walks the user through a series of prompts to set up a complete
Synth agent project, similar to ``npm init`` but tailored for
AI agent development.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass, field
from typing import Any

import click


# ------------------------------------------------------------------
# Provider / feature configuration
# ------------------------------------------------------------------

_PROVIDERS = {
    "anthropic": {
        "model": "claude-sonnet-4-5",
        "extra": "anthropic",
        "env_var": "ANTHROPIC_API_KEY",
        "display": "Anthropic (Claude)",
    },
    "openai": {
        "model": "gpt-4o",
        "extra": "openai",
        "env_var": "OPENAI_API_KEY",
        "display": "OpenAI (GPT)",
    },
    "llama": {
        "model": "ollama/llama3.2",
        "extra": "ollama",
        "env_var": "",
        "display": "Llama (via Ollama)",
    },
    "gemini": {
        "model": "gemini/gemini-2.0-flash",
        "extra": "google",
        "env_var": "GOOGLE_API_KEY",
        "display": "Google Gemini",
    },
    "agentcore": {
        "model": "bedrock/us.anthropic.claude-sonnet-4-5-20250929-v1:0",
        "extra": "agentcore",
        "env_var": "",
        "display": "AWS AgentCore (Bedrock)",
    },
}

_PROVIDER_CHOICES = click.Choice(
    list(_PROVIDERS.keys()), case_sensitive=False,
)

_FEATURES = {
    "memory": "Conversation memory",
    "guards": "Input/output guards (PII, cost, custom)",
    "structured": "Structured output (Pydantic models)",
    "eval": "Evaluation suite",
    "deploy": "AgentCore deployment handler",
}


# ------------------------------------------------------------------
# Tool and MCP catalogs
# ------------------------------------------------------------------

_TOOL_CATALOG: list[dict[str, str]] = [
    {
        "key": "web_search",
        "display": "Web search (API-based, requires BRAVE/SERP/TAVILY key)",
        "code": '''\
from synth.tools import web_search
''',
        "import": "web_search",
    },
    {
        "key": "browser_search",
        "display": "Web search (AgentCore Browser, no API key needed)",
        "code": '''\
from synth.deploy.agentcore.browser import BrowserTools

_browser = BrowserTools()

@tool
def browse_web(url: str, instruction: str = "") -> str:
    """Navigate to a URL and extract content from the page."""
    return _browser.navigate(url, instruction)

@tool
def search_web(query: str) -> str:
    """Search the web for information using AgentCore Browser."""
    return _browser.search(query)
''',
        "import": "browse_web, search_web",
    },
    {
        "key": "calculator",
        "display": "Calculator",
        "code": '''\
@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely."""
    import math
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return str(result)
    except Exception as exc:
        return f"Error: {exc}"
''',
        "import": "calculate",
    },
    {
        "key": "file_reader",
        "display": "File reader",
        "code": '''\
@tool
def read_file(path: str) -> str:
    """Read and return the text content of a local file."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()
''',
        "import": "read_file",
    },
    {
        "key": "http_fetch",
        "display": "HTTP fetch",
        "code": '''\
@tool
async def http_fetch(url: str) -> str:
    """Fetch the text content of a URL."""
    import httpx
    async with httpx.AsyncClient() as client:
        resp = await client.get(url, follow_redirects=True, timeout=10.0)
        resp.raise_for_status()
        return resp.text[:4000]
''',
        "import": "http_fetch",
    },
    {
        "key": "datetime",
        "display": "Date/time",
        "code": '''\
@tool
def get_current_datetime() -> str:
    """Return the current UTC date and time in ISO 8601 format."""
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()
''',
        "import": "get_current_datetime",
    },
    {
        "key": "json_query",
        "display": "JSON query (jq-style)",
        "code": '''\
@tool
def json_query(data: str, path: str) -> str:
    """Extract a value from a JSON string using dot-notation path.

    Example: path ``"users.0.name"`` extracts the name of the first user.
    """
    import json
    obj = json.loads(data)
    for key in path.split("."):
        if isinstance(obj, list):
            obj = obj[int(key)]
        else:
            obj = obj[key]
    return json.dumps(obj, indent=2) if isinstance(obj, (dict, list)) else str(obj)
''',
        "import": "json_query",
    },
    {
        "key": "shell_exec",
        "display": "Shell command runner",
        "code": '''\
@tool
def run_shell(command: str, timeout: int = 30) -> str:
    """Run a shell command and return its stdout.

    The command is executed with a timeout to prevent runaway processes.
    """
    import subprocess
    result = subprocess.run(
        command, shell=True, capture_output=True, text=True,
        timeout=timeout,
    )
    output = result.stdout.strip()
    if result.returncode != 0:
        output += f"\\nSTDERR: {result.stderr.strip()}"
    return output
''',
        "import": "run_shell",
    },
    {
        "key": "code_interpreter",
        "display": "Code interpreter (AgentCore sandbox, no local exec)",
        "code": '''\
from synth.deploy.agentcore.code_interpreter import CodeInterpreterTools

_ci = CodeInterpreterTools()

@tool
def execute_python(code: str) -> str:
    """Execute Python code in a secure AgentCore sandbox."""
    return _ci.execute_python(code)
''',
        "import": "execute_python",
    },
    {
        "key": "text_summarizer",
        "display": "Text chunker / summarizer",
        "code": '''\
@tool
def chunk_text(text: str, max_chars: int = 2000) -> list[str]:
    """Split text into chunks of roughly equal size at sentence boundaries."""
    import re
    sentences = re.split(r"(?<=[.!?])\\s+", text)
    chunks: list[str] = []
    current = ""
    for sentence in sentences:
        if len(current) + len(sentence) > max_chars and current:
            chunks.append(current.strip())
            current = ""
        current += sentence + " "
    if current.strip():
        chunks.append(current.strip())
    return chunks
''',
        "import": "chunk_text",
    },
    {
        "key": "csv_reader",
        "display": "CSV reader",
        "code": '''\
@tool
def read_csv(path: str, limit: int = 50) -> list[dict]:
    """Read a CSV file and return rows as a list of dicts.

    Returns at most *limit* rows to keep context manageable.
    """
    import csv
    with open(path, encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        return [row for _, row in zip(range(limit), reader)]
''',
        "import": "read_csv",
    },
    {
        "key": "regex_extract",
        "display": "Regex extractor",
        "code": '''\
@tool
def regex_extract(text: str, pattern: str) -> list[str]:
    """Extract all matches of a regex pattern from the given text."""
    import re
    return re.findall(pattern, text)
''',
        "import": "regex_extract",
    },
    {
        "key": "embeddings",
        "display": "Text embeddings (sentence-transformers)",
        "code": '''\
@tool
def embed_text(text: str) -> list[float]:
    """Generate a vector embedding for the given text.

    Requires: ``pip install sentence-transformers``
    """
    from sentence_transformers import SentenceTransformer
    model = SentenceTransformer("all-MiniLM-L6-v2")
    return model.encode(text).tolist()
''',
        "import": "embed_text",
    },
    {
        "key": "pdf_reader",
        "display": "PDF reader",
        "code": '''\
@tool
def read_pdf(path: str, max_pages: int = 20) -> str:
    """Extract text content from a PDF file.

    Requires: ``pip install pymupdf``
    """
    import fitz  # pymupdf
    doc = fitz.open(path)
    pages = []
    for i, page in enumerate(doc):
        if i >= max_pages:
            break
        pages.append(page.get_text())
    doc.close()
    return "\\n\\n".join(pages)
''',
        "import": "read_pdf",
    },
    {
        "key": "image_describer",
        "display": "Image describer (base64)",
        "code": '''\
@tool
def describe_image(path: str) -> str:
    """Read an image file and return its base64-encoded data URI.

    Useful for passing images to multimodal models.
    """
    import base64
    import mimetypes
    mime, _ = mimetypes.guess_type(path)
    mime = mime or "image/png"
    with open(path, "rb") as fh:
        encoded = base64.b64encode(fh.read()).decode()
    return f"data:{mime};base64,{encoded}"
''',
        "import": "describe_image",
    },
    {
        "key": "key_value_store",
        "display": "Key-value store (in-memory)",
        "code": '''\
_kv_store: dict[str, str] = {}

@tool
def kv_set(key: str, value: str) -> str:
    """Store a value under the given key."""
    _kv_store[key] = value
    return f"Stored '{key}'."

@tool
def kv_get(key: str) -> str:
    """Retrieve the value stored under the given key."""
    return _kv_store.get(key, f"Key '{key}' not found.")
''',
        "import": "kv_set",
    },
    {
        "key": "sql_query",
        "display": "SQLite query runner",
        "code": '''\
@tool
def sql_query(db_path: str, query: str) -> list[dict]:
    """Execute a read-only SQL query against a SQLite database."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    try:
        rows = [dict(r) for r in conn.execute(query).fetchall()]
    finally:
        conn.close()
    return rows
''',
        "import": "sql_query",
    },
    {
        "key": "yaml_parser",
        "display": "YAML reader/writer",
        "code": '''\
@tool
def read_yaml(path: str) -> str:
    """Read a YAML file and return its contents as a JSON string."""
    import json
    import yaml  # requires: pip install pyyaml
    with open(path, encoding="utf-8") as fh:
        data = yaml.safe_load(fh)
    return json.dumps(data, indent=2, default=str)
''',
        "import": "read_yaml",
    },
    {
        "key": "diff_tool",
        "display": "Text diff",
        "code": '''\
@tool
def text_diff(old_text: str, new_text: str) -> str:
    """Return a unified diff between two text strings."""
    import difflib
    diff = difflib.unified_diff(
        old_text.splitlines(keepends=True),
        new_text.splitlines(keepends=True),
        fromfile="old", tofile="new",
    )
    return "".join(diff) or "No differences found."
''',
        "import": "text_diff",
    },
    {
        "key": "html_to_text",
        "display": "HTML to text extractor",
        "code": '''\
@tool
def html_to_text(html: str) -> str:
    """Strip HTML tags and return plain text content."""
    import re
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\\s+", " ", text).strip()
''',
        "import": "html_to_text",
    },
    {
        "key": "env_reader",
        "display": "Environment variable reader",
        "code": '''\
@tool
def get_env(name: str, default: str = "") -> str:
    """Read an environment variable, returning *default* if unset."""
    import os
    return os.environ.get(name, default)
''',
        "import": "get_env",
    },
]

_MCP_CATALOG: list[dict[str, str]] = [
    {
        "key": "filesystem",
        "display": "Filesystem MCP",
        "server_code": '''\
"""Filesystem MCP server — exposes local file operations via MCP."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("filesystem")


@mcp.tool()
def read_file(path: str) -> str:
    """Read the contents of a file at the given path."""
    with open(path, encoding="utf-8") as fh:
        return fh.read()


@mcp.tool()
def list_directory(path: str = ".") -> list[str]:
    """List files and directories at the given path."""
    import os
    return os.listdir(path)


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "github",
        "display": "GitHub MCP",
        "server_code": '''\
"""GitHub MCP server — exposes GitHub API operations via MCP."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("github")


@mcp.tool()
def get_repo(owner: str, repo: str) -> dict:
    """Get information about a GitHub repository."""
    import httpx
    resp = httpx.get(f"https://api.github.com/repos/{owner}/{repo}")
    resp.raise_for_status()
    return resp.json()


@mcp.tool()
def list_issues(owner: str, repo: str, state: str = "open") -> list[dict]:
    """List issues for a GitHub repository."""
    import httpx
    resp = httpx.get(
        f"https://api.github.com/repos/{owner}/{repo}/issues",
        params={"state": state},
    )
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "slack",
        "display": "Slack MCP",
        "server_code": '''\
"""Slack MCP server — exposes Slack messaging operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("slack")

_SLACK_TOKEN = os.environ.get("SLACK_BOT_TOKEN", "")


@mcp.tool()
def send_message(channel: str, text: str) -> dict:
    """Send a message to a Slack channel."""
    import httpx
    resp = httpx.post(
        "https://slack.com/api/chat.postMessage",
        headers={"Authorization": f"Bearer {_SLACK_TOKEN}"},
        json={"channel": channel, "text": text},
    )
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "database",
        "display": "Database MCP",
        "server_code": '''\
"""Database MCP server — exposes SQL query operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("database")

_DB_URL = os.environ.get("DATABASE_URL", "sqlite:///./app.db")


@mcp.tool()
def query(sql: str) -> list[dict]:
    """Execute a read-only SQL query and return the results."""
    import sqlite3
    conn = sqlite3.connect(_DB_URL.replace("sqlite:///", ""))
    conn.row_factory = sqlite3.Row
    cur = conn.execute(sql)
    rows = [dict(row) for row in cur.fetchall()]
    conn.close()
    return rows


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "redis",
        "display": "Redis MCP",
        "server_code": '''\
"""Redis MCP server — exposes key-value and cache operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("redis")

_REDIS_URL = os.environ.get("REDIS_URL", "redis://localhost:6379/0")


def _client():
    """Lazy Redis client."""
    import redis
    return redis.from_url(_REDIS_URL, decode_responses=True)


@mcp.tool()
def redis_get(key: str) -> str:
    """Get the value of a Redis key."""
    val = _client().get(key)
    return val if val is not None else f"Key '{key}' not found."


@mcp.tool()
def redis_set(key: str, value: str, ttl: int = 0) -> str:
    """Set a Redis key to a value with optional TTL in seconds."""
    r = _client()
    r.set(key, value, ex=ttl if ttl > 0 else None)
    return f"OK — stored '{key}'."


@mcp.tool()
def redis_keys(pattern: str = "*") -> list[str]:
    """List Redis keys matching a glob pattern."""
    return _client().keys(pattern)


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "s3",
        "display": "AWS S3 MCP",
        "server_code": '''\
"""AWS S3 MCP server — exposes S3 bucket and object operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("s3")

_BUCKET = os.environ.get("S3_BUCKET", "")


def _s3():
    """Lazy boto3 S3 client."""
    import boto3
    return boto3.client("s3")


@mcp.tool()
def list_objects(prefix: str = "", max_keys: int = 50) -> list[str]:
    """List object keys in the configured S3 bucket."""
    resp = _s3().list_objects_v2(
        Bucket=_BUCKET, Prefix=prefix, MaxKeys=max_keys,
    )
    return [obj["Key"] for obj in resp.get("Contents", [])]


@mcp.tool()
def get_object(key: str) -> str:
    """Download and return the text content of an S3 object."""
    body = _s3().get_object(Bucket=_BUCKET, Key=key)["Body"]
    return body.read().decode("utf-8")


@mcp.tool()
def put_object(key: str, content: str) -> str:
    """Upload text content to an S3 object."""
    _s3().put_object(Bucket=_BUCKET, Key=key, Body=content.encode())
    return f"Uploaded to s3://{_BUCKET}/{key}"


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "email",
        "display": "Email (SMTP) MCP",
        "server_code": '''\
"""Email MCP server — send emails via SMTP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("email")

_SMTP_HOST = os.environ.get("SMTP_HOST", "smtp.gmail.com")
_SMTP_PORT = int(os.environ.get("SMTP_PORT", "587"))
_SMTP_USER = os.environ.get("SMTP_USER", "")
_SMTP_PASS = os.environ.get("SMTP_PASS", "")


@mcp.tool()
def send_email(to: str, subject: str, body: str) -> str:
    """Send a plain-text email via SMTP."""
    import smtplib
    from email.message import EmailMessage
    msg = EmailMessage()
    msg["From"] = _SMTP_USER
    msg["To"] = to
    msg["Subject"] = subject
    msg.set_content(body)
    with smtplib.SMTP(_SMTP_HOST, _SMTP_PORT) as server:
        server.starttls()
        server.login(_SMTP_USER, _SMTP_PASS)
        server.send_message(msg)
    return f"Email sent to {to}."


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "jira",
        "display": "Jira MCP",
        "server_code": '''\
"""Jira MCP server — exposes Jira issue operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("jira")

_JIRA_URL = os.environ.get("JIRA_URL", "")
_JIRA_EMAIL = os.environ.get("JIRA_EMAIL", "")
_JIRA_TOKEN = os.environ.get("JIRA_API_TOKEN", "")


def _headers() -> dict[str, str]:
    """Auth headers for Jira REST API."""
    import base64
    creds = base64.b64encode(
        f"{_JIRA_EMAIL}:{_JIRA_TOKEN}".encode(),
    ).decode()
    return {
        "Authorization": f"Basic {creds}",
        "Content-Type": "application/json",
    }


@mcp.tool()
def get_issue(issue_key: str) -> dict:
    """Get a Jira issue by key (e.g. PROJ-123)."""
    import httpx
    resp = httpx.get(
        f"{_JIRA_URL}/rest/api/3/issue/{issue_key}",
        headers=_headers(),
    )
    resp.raise_for_status()
    return resp.json()


@mcp.tool()
def search_issues(jql: str, max_results: int = 20) -> list[dict]:
    """Search Jira issues using JQL."""
    import httpx
    resp = httpx.get(
        f"{_JIRA_URL}/rest/api/3/search",
        headers=_headers(),
        params={"jql": jql, "maxResults": max_results},
    )
    resp.raise_for_status()
    return resp.json().get("issues", [])


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "web_scraper",
        "display": "Web scraper MCP",
        "server_code": '''\
"""Web scraper MCP server — fetch and extract content from web pages."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("web-scraper")


@mcp.tool()
def fetch_page(url: str, max_chars: int = 5000) -> str:
    """Fetch a web page and return its text content (HTML stripped)."""
    import re
    import httpx
    resp = httpx.get(url, follow_redirects=True, timeout=15.0)
    resp.raise_for_status()
    text = re.sub(r"<script[^>]*>.*?</script>", "", resp.text, flags=re.DOTALL)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
    text = re.sub(r"<[^>]+>", " ", text)
    text = re.sub(r"\\s+", " ", text).strip()
    return text[:max_chars]


@mcp.tool()
def extract_links(url: str) -> list[str]:
    """Extract all hyperlinks from a web page."""
    import re
    import httpx
    resp = httpx.get(url, follow_redirects=True, timeout=15.0)
    resp.raise_for_status()
    return re.findall(r'href=["\\']([^"\\'>]+)', resp.text)


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "docker",
        "display": "Docker MCP",
        "server_code": '''\
"""Docker MCP server — manage containers and images via MCP."""

from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("docker")


def _docker():
    """Lazy Docker client."""
    import docker
    return docker.from_env()


@mcp.tool()
def list_containers(all: bool = False) -> list[dict]:
    """List Docker containers (running by default, all if specified)."""
    containers = _docker().containers.list(all=all)
    return [
        {"id": c.short_id, "name": c.name, "status": c.status, "image": str(c.image.tags)}
        for c in containers
    ]


@mcp.tool()
def list_images() -> list[dict]:
    """List locally available Docker images."""
    images = _docker().images.list()
    return [{"id": i.short_id, "tags": i.tags} for i in images]


@mcp.tool()
def container_logs(container_id: str, tail: int = 100) -> str:
    """Get the last N lines of logs from a container."""
    container = _docker().containers.get(container_id)
    return container.logs(tail=tail).decode("utf-8", errors="replace")


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "postgres",
        "display": "PostgreSQL MCP",
        "server_code": '''\
"""PostgreSQL MCP server — exposes Postgres query operations via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("postgres")

_PG_URL = os.environ.get(
    "POSTGRES_URL", "postgresql://localhost:5432/mydb",
)


def _conn():
    """Create a new psycopg connection."""
    import psycopg
    return psycopg.connect(_PG_URL)


@mcp.tool()
def pg_query(sql: str, params: str = "") -> list[dict]:
    """Execute a read-only SQL query against PostgreSQL.

    Pass params as a JSON array string for parameterized queries.
    """
    import json
    p = json.loads(params) if params else None
    with _conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, p)
            cols = [d[0] for d in cur.description or []]
            return [dict(zip(cols, row)) for row in cur.fetchall()]


@mcp.tool()
def pg_tables() -> list[str]:
    """List all user tables in the public schema."""
    with _conn() as conn:
        with conn.cursor() as cur:
            cur.execute(
                "SELECT tablename FROM pg_tables "
                "WHERE schemaname = 'public' ORDER BY tablename"
            )
            return [row[0] for row in cur.fetchall()]


if __name__ == "__main__":
    mcp.run()
''',
    },
    {
        "key": "notion",
        "display": "Notion MCP",
        "server_code": '''\
"""Notion MCP server — read and search Notion pages via MCP."""

from __future__ import annotations

import os

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("notion")

_NOTION_TOKEN = os.environ.get("NOTION_API_KEY", "")
_BASE = "https://api.notion.com/v1"


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {_NOTION_TOKEN}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }


@mcp.tool()
def search_pages(query: str, max_results: int = 10) -> list[dict]:
    """Search Notion pages by title."""
    import httpx
    resp = httpx.post(
        f"{_BASE}/search",
        headers=_headers(),
        json={"query": query, "page_size": max_results},
    )
    resp.raise_for_status()
    results = resp.json().get("results", [])
    return [
        {
            "id": r["id"],
            "title": r.get("properties", {}).get("title", {}).get("title", [{}])[0].get("plain_text", ""),
            "url": r.get("url", ""),
        }
        for r in results if r["object"] == "page"
    ]


@mcp.tool()
def get_page_content(page_id: str) -> list[dict]:
    """Get the block content of a Notion page."""
    import httpx
    resp = httpx.get(
        f"{_BASE}/blocks/{page_id}/children",
        headers=_headers(),
    )
    resp.raise_for_status()
    return resp.json().get("results", [])


if __name__ == "__main__":
    mcp.run()
''',
    },
]


# ------------------------------------------------------------------
# Wizard result dataclasses
# ------------------------------------------------------------------

@dataclass
class ToolWizardResult:
    """Result from the tool creation wizard.

    Parameters
    ----------
    tools_code:
        Content to write to ``tools.py``.
    agent_imports:
        Import names to add to ``agent.py`` (e.g. ``["web_search", "calculate"]``).
    files_created:
        List of file paths that will be written (relative to project dir).
    env_vars:
        Environment variables collected during the wizard (e.g. API keys).
        Written to ``.env`` in the project directory.
    """

    tools_code: str = ""
    agent_imports: list[str] = field(default_factory=list)
    files_created: list[str] = field(default_factory=list)
    env_vars: dict[str, str] = field(default_factory=dict)


@dataclass
class McpWizardResult:
    """Result from the MCP server creation wizard.

    Parameters
    ----------
    server_dir:
        Directory name for the MCP server (e.g. ``"mcp-server"``).
    server_code:
        Content to write to ``<server_dir>/server.py``.
    agent_mcp_registration:
        Code snippet to append to ``agent.py`` for MCP client registration.
    files_created:
        List of file paths that will be written (relative to project dir).
    """

    server_dir: str = ""
    server_code: str = ""
    agent_mcp_registration: str = ""
    files_created: list[str] = field(default_factory=list)


# ------------------------------------------------------------------
# Multi-agent configuration data models
# ------------------------------------------------------------------


def _sanitize_agent_name(name: str) -> str:
    """Convert a human-friendly agent name to a valid Python identifier.

    Spaces, hyphens, and other non-alphanumeric characters are replaced
    with underscores.  Leading digits get an underscore prefix.  The
    result is always a valid Python identifier suitable for use as a
    variable name and filename stem.

    Parameters
    ----------
    name:
        The raw agent name entered by the user.

    Returns
    -------
    str
        A ``snake_case`` Python-safe identifier.
    """
    safe = re.sub(r"[^a-zA-Z0-9]", "_", name)
    safe = re.sub(r"_+", "_", safe).strip("_")
    if not safe:
        safe = "agent"
    if safe[0].isdigit():
        safe = f"_{safe}"
    return safe.lower()


@dataclass
class AgentConfig:
    """Configuration for a single agent in a multi-agent project."""

    name: str
    description: str
    provider: str
    provider_cfg: dict[str, str]
    model: str
    instructions: str
    tool_result: ToolWizardResult
    mcp_result: McpWizardResult
    is_agentcore: bool = False
    agentcore_state: dict[str, Any] = field(default_factory=dict)
    safe_name: str = ""

    def __post_init__(self) -> None:
        """Derive safe_name from name if not explicitly set."""
        if not self.safe_name:
            self.safe_name = _sanitize_agent_name(self.name)


@dataclass
class PipelineConfig:
    """Pipeline-specific orchestration configuration."""

    agent_order: list[str] = field(default_factory=list)


@dataclass
class EdgeConfig:
    """A single edge in a Graph configuration."""

    source: str
    target: str  # Agent name or "END"
    condition: str | None = None


@dataclass
class GraphConfig:
    """Graph-specific orchestration configuration."""

    entry_node: str = ""
    edges: list[EdgeConfig] = field(default_factory=list)


@dataclass
class AgentTeamConfig:
    """AgentTeam-specific orchestration configuration."""

    strategy: str = "auto"  # "auto" or "parallel"
    orchestrator_model: str = ""


@dataclass
class HumanInLoopConfig:
    """Human-in-the-Loop configuration (extends GraphConfig)."""

    graph: GraphConfig = field(default_factory=GraphConfig)
    pause_nodes: list[str] = field(default_factory=list)
    timeout: float | None = None
    fallback_node: str | None = None


@dataclass
class OrchestrationConfig:
    """Top-level orchestration configuration."""

    pattern: str = ""  # "pipeline", "graph", "agent_team", "human_in_loop"
    pipeline: PipelineConfig | None = None
    graph: GraphConfig | None = None
    agent_team: AgentTeamConfig | None = None
    human_in_loop: HumanInLoopConfig | None = None


@dataclass
class SharedMultiAgentConfig:
    """Shared configuration applied to all agents in a multi-agent project.

    When the user opts to share provider, region, model, or tools across
    all agents, the values are captured here and forwarded to each agent
    during the configuration loop, skipping redundant prompts.
    """

    share_provider: bool = False
    provider: str = ""
    provider_cfg: dict[str, str] = field(default_factory=dict)
    model: str = ""
    is_agentcore: bool = False
    agentcore_state: dict[str, Any] = field(default_factory=dict)

    share_tools: bool = False
    tool_result: ToolWizardResult = field(
        default_factory=ToolWizardResult,
    )
    mcp_result: McpWizardResult = field(
        default_factory=McpWizardResult,
    )


# ------------------------------------------------------------------
# Web search API key prompt
# ------------------------------------------------------------------

_WEB_SEARCH_PROVIDERS: list[dict[str, str]] = [
    {
        "key": "brave",
        "env_var": "BRAVE_API_KEY",
        "display": "Brave Search",
        "url": "https://brave.com/search/api/",
    },
    {
        "key": "serpapi",
        "env_var": "SERPAPI_API_KEY",
        "display": "SerpAPI",
        "url": "https://serpapi.com/",
    },
    {
        "key": "tavily",
        "env_var": "TAVILY_API_KEY",
        "display": "Tavily",
        "url": "https://tavily.com/",
    },
]


def _prompt_web_search_api_key() -> dict[str, str]:
    """Prompt the user to select a web search provider and enter an API key.

    Returns a dict with a single ``{ENV_VAR: key_value}`` entry, or an
    empty dict if the user already has a key configured or chooses to skip.
    """
    # Check if any key is already set
    for prov in _WEB_SEARCH_PROVIDERS:
        if os.environ.get(prov["env_var"]):
            click.echo(click.style(
                f"  ✓ {prov['display']} key detected "
                f"({prov['env_var']})",
                fg="green",
            ))
            return {}

    click.echo("")
    click.echo(click.style(
        "  Web search requires an API key. "
        "Choose a provider:",
        fg="cyan",
    ))
    for idx, prov in enumerate(_WEB_SEARCH_PROVIDERS, start=1):
        click.echo(
            f"    {idx}. {prov['display']:<16s} {prov['url']}"
        )
    click.echo(f"    {len(_WEB_SEARCH_PROVIDERS) + 1}. Skip (set later)")
    click.echo("")

    choice = click.prompt(
        click.style("  Provider", fg="cyan"),
        type=int,
        default=1,
    )

    if choice < 1 or choice > len(_WEB_SEARCH_PROVIDERS):
        click.echo(click.style(
            "  Skipped. Set one of BRAVE_API_KEY, SERPAPI_API_KEY, "
            "or TAVILY_API_KEY before running your agent.",
            dim=True,
        ))
        return {}

    prov = _WEB_SEARCH_PROVIDERS[choice - 1]
    api_key = click.prompt(
        click.style(f"  {prov['display']} API key", fg="cyan"),
        hide_input=True,
    ).strip()

    if not api_key:
        click.echo(click.style(
            f"  Skipped. Set {prov['env_var']} before running.",
            dim=True,
        ))
        return {}

    click.echo(click.style(
        f"  ✓ {prov['env_var']} will be saved to .env",
        fg="green",
    ))
    return {prov["env_var"]: api_key}


# ------------------------------------------------------------------
# Tool wizard
# ------------------------------------------------------------------

def _run_tool_wizard() -> ToolWizardResult:
    """Interactive wizard for adding tools to the project.

    Returns
    -------
    ToolWizardResult
        Populated result if the user chose to add tools; empty result otherwise.
    """
    click.echo("")
    want_tools = click.confirm(
        click.style("  Add tools to your project?", fg="cyan"),
        default=False,
    )
    if not want_tools:
        return ToolWizardResult()

    # Build numbered list: catalog entries + custom scaffolding
    click.echo("")
    click.echo(click.style("  Available tools:", fg="cyan"))
    for idx, entry in enumerate(_TOOL_CATALOG, start=1):
        click.echo(f"    {idx}. {entry['display']}")
    custom_idx = len(_TOOL_CATALOG) + 1
    click.echo(f"    {custom_idx}. Create custom scaffolding")
    click.echo("")

    raw = click.prompt(
        click.style(
            "  Select tools (comma-separated numbers, e.g. 1,3)", fg="cyan"
        ),
        default="",
    ).strip()

    if not raw:
        return ToolWizardResult()

    selected_indices: list[int] = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            val = int(part)
            if 1 <= val <= custom_idx:
                selected_indices.append(val)

    if not selected_indices:
        return ToolWizardResult()

    want_custom = custom_idx in selected_indices
    prebuilt_indices = [i for i in selected_indices if i != custom_idx]

    # Collect code blocks and import names
    code_blocks: list[str] = []
    import_names: list[str] = []

    for idx in prebuilt_indices:
        entry = _TOOL_CATALOG[idx - 1]
        code_blocks.append(entry["code"])
        import_names.append(entry["import"])

    # Prompt for web search API key if web_search was selected
    env_vars: dict[str, str] = {}
    selected_keys = {
        _TOOL_CATALOG[i - 1]["key"] for i in prebuilt_indices
    }
    if "web_search" in selected_keys:
        env_vars = _prompt_web_search_api_key()

    # Custom scaffolding sub-wizard
    if want_custom:
        click.echo("")
        click.echo(click.style(
            "  Custom tool scaffolding (up to 3 tools):", fg="cyan"
        ))
        for slot in range(1, 4):
            tool_name = click.prompt(
                click.style(f"    Tool {slot} name (or Enter to stop)", fg="cyan"),
                default="",
            ).strip()
            if not tool_name:
                break
            tool_desc = click.prompt(
                click.style(f"    Tool {slot} description", fg="cyan"),
                default=f"A custom tool named {tool_name}.",
            ).strip()
            # Sanitise name to a valid Python identifier
            safe_name = tool_name.lower().replace(" ", "_").replace("-", "_")
            stub = (
                f"@tool\n"
                f"def {safe_name}(input: str) -> str:\n"
                f'    """{tool_desc}"""\n'
                f"    # TODO: implement {safe_name}\n"
                f"    raise NotImplementedError\n"
            )
            code_blocks.append(stub)
            import_names.append(safe_name)

    if not code_blocks:
        return ToolWizardResult()

    header = (
        '"""Custom tools for the agent."""\n\n'
        "from __future__ import annotations\n\n"
        "from synth import tool\n\n\n"
    )
    tools_code = header + "\n\n".join(code_blocks)

    return ToolWizardResult(
        tools_code=tools_code,
        agent_imports=import_names,
        files_created=["tools.py"],
        env_vars=env_vars,
    )


# ------------------------------------------------------------------
# MCP wizard
# ------------------------------------------------------------------

def _run_mcp_wizard() -> McpWizardResult:
    """Interactive wizard for adding an MCP server to the project.

    Returns
    -------
    McpWizardResult
        Populated result if the user chose to add an MCP server; empty otherwise.
    """
    click.echo("")
    want_mcp = click.confirm(
        click.style("  Add an MCP server to your project?", fg="cyan"),
        default=False,
    )
    if not want_mcp:
        return McpWizardResult()

    # Build numbered list: catalog entries + custom scaffolding
    click.echo("")
    click.echo(click.style("  Available MCP servers:", fg="cyan"))
    for idx, entry in enumerate(_MCP_CATALOG, start=1):
        click.echo(f"    {idx}. {entry['display']}")
    custom_idx = len(_MCP_CATALOG) + 1
    click.echo(f"    {custom_idx}. Create custom scaffolding")
    click.echo("")

    choice_raw = click.prompt(
        click.style("  Select MCP server (number)", fg="cyan"),
        type=click.IntRange(1, custom_idx),
        default=1,
    )

    if choice_raw == custom_idx:
        # Custom scaffolding
        server_name = click.prompt(
            click.style("  MCP server name", fg="cyan"),
            default="mcp-server",
        ).strip() or "mcp-server"

        click.echo("")
        click.echo(click.style(
            "  Custom MCP tool scaffolding (up to 3 tools):", fg="cyan"
        ))
        tool_stubs: list[str] = []
        for slot in range(1, 4):
            tool_name = click.prompt(
                click.style(f"    MCP tool {slot} name (or Enter to stop)", fg="cyan"),
                default="",
            ).strip()
            if not tool_name:
                break
            tool_desc = click.prompt(
                click.style(f"    MCP tool {slot} description", fg="cyan"),
                default=f"A custom MCP tool named {tool_name}.",
            ).strip()
            safe_name = tool_name.lower().replace(" ", "_").replace("-", "_")
            stub = (
                f"@mcp.tool()\n"
                f"def {safe_name}(input: str) -> str:\n"
                f'    """{tool_desc}"""\n'
                f"    # TODO: implement {safe_name}\n"
                f"    raise NotImplementedError\n"
            )
            tool_stubs.append(stub)

        if not tool_stubs:
            tool_stubs = [
                "@mcp.tool()\ndef example_tool(input: str) -> str:\n"
                '    """An example MCP tool stub."""\n'
                "    raise NotImplementedError\n"
            ]

        server_code = (
            f'"""Custom MCP server: {server_name}."""\n\n'
            "from __future__ import annotations\n\n"
            "from mcp.server.fastmcp import FastMCP\n\n"
            f'mcp = FastMCP("{server_name}")\n\n\n'
            + "\n\n".join(tool_stubs)
            + "\n\nif __name__ == \"__main__\":\n    mcp.run()\n"
        )
    else:
        catalog_entry = _MCP_CATALOG[choice_raw - 1]
        server_name = catalog_entry["key"]
        server_code = catalog_entry["server_code"]

    registration = (
        f"\n\n# MCP server registration\n"
        f"# Uncomment and configure to connect to the {server_name} MCP server:\n"
        f"# from synth.tools.mcp import MCPClient\n"
        f"# mcp_client = MCPClient(\"{server_name}/server.py\")\n"
    )

    return McpWizardResult(
        server_dir=server_name,
        server_code=server_code,
        agent_mcp_registration=registration,
        files_created=[f"{server_name}/server.py"],
    )

# ------------------------------------------------------------------
# Model selection helper
# ------------------------------------------------------------------

def _run_model_selection(
    provider: str,
    cfg: dict[str, str],
    agentcore_state: dict[str, Any] | None = None,
) -> str:
    """Select the model ID for the given provider.

    For AgentCore, prompts for a target AWS region, displays available
    models filtered by that region via ``RegionValidator``, and returns
    the ``bedrock/``-prefixed effective model ID.  Region and CRIS data
    are written into *agentcore_state* so the caller can forward them.

    For every other provider the default model from *cfg* is returned
    directly without additional prompting.

    Parameters
    ----------
    provider : str
        Provider key (e.g. ``"agentcore"``, ``"anthropic"``).
    cfg : dict[str, str]
        Provider config dict from ``_PROVIDERS``.
    agentcore_state : dict[str, Any] | None
        Mutable dict that receives ``aws_region`` and ``cris_enabled``
        when *provider* is ``"agentcore"``.  Ignored otherwise.

    Returns
    -------
    str
        The selected model ID string.  For AgentCore this includes the
        ``bedrock/`` prefix.
    """
    if provider != "agentcore":
        return cfg["model"]

    # --- Lazy imports (AgentCore extras) ---
    try:
        from synth.deploy.agentcore.model_catalog import (
            ModelCatalog,
            RegionValidator,
        )
    except ImportError as exc:
        from synth.errors import SynthConfigError

        raise SynthConfigError(
            "AgentCore extras are not installed.",
            component="init",
            suggestion="pip install synth[agentcore]",
        ) from exc

    # --- Region selection ---
    click.echo("")
    aws_region: str = click.prompt(
        click.style("  Target AWS region", fg="cyan"),
        default="us-east-1",
    )

    # --- Model selection ---
    catalog = ModelCatalog()
    validator = RegionValidator(catalog)

    availability_unknown = validator.availability_unknown_for_region(
        aws_region,
    )
    models = validator.models_for_region(aws_region)

    click.echo("")
    if availability_unknown:
        click.echo(
            click.style(
                f"  Warning: regional availability for '{aws_region}' "
                "could not be verified. Showing all models.",
                fg="yellow",
            )
        )

    click.echo(click.style("  Available models:", fg="cyan"))
    for idx, entry in enumerate(models, start=1):
        cris_note = ""
        if validator.requires_cris(entry.model_id, aws_region):
            cris_note = click.style(" [CRIS]", fg="yellow")
        click.echo(f"    {idx}. {entry.display_name}{cris_note}")

    model_choice = click.prompt(
        click.style("  Select model (number)", fg="cyan"),
        type=click.IntRange(1, len(models)),
        default=1,
    )
    selected_entry = models[model_choice - 1]
    cris_enabled = validator.requires_cris(
        selected_entry.model_id, aws_region,
    )
    effective_id = validator.effective_model_id(
        selected_entry.model_id, aws_region,
    )

    # --- Bedrock prefix (no double-prefixing) ---
    if not effective_id.startswith("bedrock/"):
        effective_id = f"bedrock/{effective_id}"

    if cris_enabled:
        click.echo(
            click.style(
                f"  Note: {selected_entry.display_name} is not natively "
                f"available in '{aws_region}'. Cross-Region Inference "
                f"(CRIS) will be used.\n"
                f"  Model ID: {effective_id}",
                fg="yellow",
            )
        )
    else:
        click.echo(
            f"  Model: "
            f"{click.style(selected_entry.display_name, fg='green')} "
            f"({effective_id})"
        )

    # --- Populate agentcore_state for the caller ---
    if agentcore_state is not None:
        agentcore_state["aws_region"] = aws_region
        agentcore_state["cris_enabled"] = cris_enabled

    return effective_id


# ------------------------------------------------------------------
# AWS credential check helper
# ------------------------------------------------------------------


# ------------------------------------------------------------------
# Provider dependency probes — maps each extra to a package that
# must be importable for the provider to work.
# ------------------------------------------------------------------

_EXTRA_PROBE_PACKAGES: dict[str, list[str]] = {
    "anthropic": ["anthropic"],
    "openai": ["openai"],
    "ollama": ["ollama"],
    "google": ["google.genai"],
    "agentcore": ["boto3", "botocore", "awscrt", "bedrock_agentcore", "bedrock_agentcore_starter_toolkit"],
    "bedrock": ["boto3", "botocore", "awscrt"],
}

# For AWS providers, recommend the unified "aws" extra
_AWS_EXTRAS = {"agentcore", "bedrock"}


def _check_provider_deps(provider: str, cfg: dict[str, str]) -> None:
    """Check that the provider's dependencies are installed.

    If any required package is missing, offers to install them
    automatically via ``pip install synth-agent-sdk[<extra>]``.
    Aborts the init flow if the user declines and deps are missing.

    Parameters
    ----------
    provider:
        The provider key (e.g. ``"agentcore"``, ``"anthropic"``).
    cfg:
        Provider config dict from ``_PROVIDERS``.
    """
    extra = cfg.get("extra", provider)
    probes = _EXTRA_PROBE_PACKAGES.get(extra, [])
    if not probes:
        return

    missing: list[str] = []
    for pkg in probes:
        try:
            __import__(pkg)
        except ImportError:
            missing.append(pkg)

    if not missing:
        return

    # Determine the right install extra name
    install_extra = "aws" if extra in _AWS_EXTRAS else extra
    install_cmd = f"pip install synth-agent-sdk[{install_extra}]"

    click.echo("")
    click.echo(
        click.style(
            f"  Missing dependencies for {cfg.get('display', provider)}: "
            f"{', '.join(missing)}",
            fg="yellow",
        )
    )
    click.echo(
        f"  Install with: {click.style(install_cmd, fg='green')}"
    )

    if click.confirm(
        click.style("  Install now?", fg="cyan"),
        default=True,
    ):
        click.echo(f"  Running: {install_cmd}")
        result = subprocess.run(
            [sys.executable, "-m", "pip", "install",
             f"synth-agent-sdk[{install_extra}]"],
            capture_output=True,
            text=True,
        )
        if result.returncode != 0:
            click.echo(
                click.style(
                    f"  Installation failed. Please run manually:\n"
                    f"    {install_cmd}",
                    fg="red",
                )
            )
            raise SystemExit(1)

        # Verify newly installed packages are importable in this process
        import importlib

        still_missing: list[str] = []
        for pkg in missing:
            try:
                importlib.import_module(pkg)
            except ImportError:
                still_missing.append(pkg)

        if still_missing:
            click.echo(
                click.style(
                    "  Dependencies installed, but a process restart "
                    "is needed for them to take effect.\n"
                    "  Please re-run: synth init",
                    fg="yellow",
                )
            )
            raise SystemExit(0)

        click.echo(
            click.style("  Dependencies installed.", fg="green")
        )
    else:
        click.echo(
            click.style(
                f"  Cannot continue without dependencies.\n"
                f"  Run: {install_cmd}",
                fg="red",
            )
        )
        raise SystemExit(1)


def _prompt_profile_selection(
    resolver: object,
    available: list[str],
    default_profile: str | None = None,
) -> str | None:
    """Show a numbered list of AWS profiles and let the user pick one.

    Parameters
    ----------
    resolver:
        A ``CredentialResolver`` instance for validation.
    available:
        List of profile names to display.
    default_profile:
        Profile to mark as the default selection.  When ``None``, the
        first profile in the list is used.

    Returns
    -------
    str | None
        The chosen profile name, or ``None`` if the user skips.
    """
    for idx, name in enumerate(available, 1):
        marker = " (detected)" if name == default_profile else ""
        click.echo(
            f"    {click.style(str(idx), fg='green')}) {name}"
            f"{click.style(marker, dim=True)}"
        )
    click.echo(
        f"    {click.style(str(len(available) + 1), fg='green')}) "
        f"Enter a different profile name"
    )
    click.echo(
        f"    {click.style(str(len(available) + 2), fg='green')}) "
        f"Skip"
    )
    click.echo("")

    # Determine default choice number
    if default_profile and default_profile in available:
        default_idx = available.index(default_profile) + 1
    else:
        default_idx = 1

    choice = click.prompt(
        click.style("  Select option", fg="cyan"),
        type=int,
        default=default_idx,
    )

    skip_idx = len(available) + 2
    custom_idx = len(available) + 1

    if choice == skip_idx:
        return None
    if choice == custom_idx:
        profile = click.prompt(
            click.style("  Enter AWS profile name", fg="cyan"),
        )
    elif 1 <= choice <= len(available):
        profile = available[choice - 1]
    else:
        click.echo(click.style("  Invalid selection.", fg="yellow"))
        return None

    # Validate the chosen profile
    try:
        named = resolver.resolve_profile(profile)  # type: ignore[attr-defined]
        if named is not None:
            masked = resolver.mask_account_id(  # type: ignore[attr-defined]
                named.account_id,
            )
            click.echo(
                f"  Profile "
                f"{click.style(profile, fg='green')} "
                f"resolved (account: "
                f"{click.style(masked, fg='green')})"
            )
        else:
            click.echo(
                click.style(
                    f"  Warning: could not verify profile "
                    f"'{profile}'. Continuing anyway.",
                    fg="yellow",
                )
            )
    except Exception as exc:  # noqa: BLE001
        err_msg = str(exc)
        if "botocore" in err_msg.lower() and "crt" in err_msg.lower():
            click.echo(
                click.style(
                    f"  Missing dependency: botocore[crt] is required "
                    f"for SSO/login credential providers.\n"
                    f"  Run: pip install \"botocore[crt]\"",
                    fg="red",
                )
            )
            if click.confirm(
                click.style("  Install now?", fg="cyan"),
                default=True,
            ):
                result = subprocess.run(
                    [sys.executable, "-m", "pip", "install",
                     "botocore[crt]"],
                    capture_output=True,
                    text=True,
                )
                if result.returncode == 0:
                    click.echo(
                        click.style(
                            "  botocore[crt] installed. "
                            "Retrying profile validation...",
                            fg="green",
                        )
                    )
                    # Retry validation after install
                    try:
                        named = resolver.resolve_profile(profile)  # type: ignore[attr-defined]
                        if named is not None:
                            masked = resolver.mask_account_id(  # type: ignore[attr-defined]
                                named.account_id,
                            )
                            click.echo(
                                f"  Profile "
                                f"{click.style(profile, fg='green')} "
                                f"resolved (account: "
                                f"{click.style(masked, fg='green')})"
                            )
                    except Exception:  # noqa: BLE001
                        click.echo(
                            click.style(
                                f"  Warning: still could not verify "
                                f"profile '{profile}'. "
                                f"Continuing anyway.",
                                fg="yellow",
                            )
                        )
                else:
                    click.echo(
                        click.style(
                            "  Installation failed. Continuing "
                            "without verification.",
                            fg="yellow",
                        )
                    )
        else:
            click.echo(
                click.style(
                    f"  Warning: could not verify profile "
                    f"'{profile}'. Continuing anyway.",
                    fg="yellow",
                )
            )
    return profile


def _run_credential_check() -> dict[str, Any]:
    """Detect and validate AWS credentials.

    Lazily imports ``CredentialResolver`` from the AgentCore extras and
    attempts automatic credential detection.  When credentials are found
    the user is asked to confirm or supply an alternative profile.  When
    no credentials are detected a warning is printed and the user may
    pick from available profiles or enter one manually.

    Returns
    -------
    dict[str, Any]
        Keys: ``aws_profile`` (``str | None``).
    """
    try:
        from synth.deploy.agentcore.credentials import CredentialResolver
    except ImportError as exc:
        from synth.errors import SynthConfigError

        raise SynthConfigError(
            "AgentCore extras are not installed.",
            component="init",
            suggestion="pip install synth[agentcore]",
        ) from exc

    resolver = CredentialResolver()
    aws_profile: str | None = None
    available = resolver.list_available_profiles()

    # --- Credential detection ---
    click.echo("")
    click.echo(click.style("  AWS Credentials", fg="cyan", bold=True))

    creds = None
    try:
        creds = resolver.resolve()
    except Exception:  # noqa: BLE001
        pass  # handled below

    if creds is not None:
        masked = resolver.mask_account_id(creds.account_id)
        click.echo(
            f"  Found credentials via "
            f"{click.style(creds.source, fg='green')} "
            f"(account: {click.style(masked, fg='green')})"
        )

        # If there are other profiles available, let the user choose
        if len(available) > 1:
            use_found = click.confirm(
                click.style("  Use these credentials?", fg="cyan"),
                default=True,
            )
            if use_found:
                aws_profile = creds.profile_name
            else:
                click.echo("")
                click.echo(
                    click.style("  Available profiles:", fg="cyan"),
                )
                aws_profile = _prompt_profile_selection(
                    resolver,
                    available,
                    default_profile=creds.profile_name,
                )
        else:
            # Only one profile — just confirm
            use_found = click.confirm(
                click.style("  Use these credentials?", fg="cyan"),
                default=True,
            )
            if use_found:
                aws_profile = creds.profile_name
            else:
                aws_profile = click.prompt(
                    click.style("  Enter AWS profile name", fg="cyan"),
                    default="default",
                )
    else:
        if available:
            click.echo(
                click.style(
                    "  No AWS credentials auto-detected, but "
                    "profiles are available:",
                    fg="yellow",
                )
            )
            aws_profile = _prompt_profile_selection(
                resolver, available,
            )
        else:
            click.echo(
                click.style(
                    "  No AWS credentials found.\n"
                    "  Configure them with:\n"
                    "    pip install awscli && aws configure\n"
                    "  Or install the AWS Toolkit VS Code extension.",
                    fg="yellow",
                )
            )
            aws_profile = click.prompt(
                click.style(
                    "  Enter AWS profile name to use "
                    "(or press Enter to skip)",
                    fg="cyan",
                ),
                default="",
            ) or None

    return {"aws_profile": aws_profile}




# ------------------------------------------------------------------
# Main init flow
# ------------------------------------------------------------------


def run_init() -> None:
    """Run the interactive project initializer."""
    click.echo("")
    click.echo(click.style("  SYNTH INIT", fg="green", bold=True))
    click.echo(click.style(
        "  Interactive project setup\n",
        dim=True,
    ))

    # 0. Single vs. multi-agent fork
    mode = click.prompt(
        click.style("  Project type", fg="cyan"),
        type=click.Choice(["single", "multi"], case_sensitive=False),
        default="single",
    )
    if mode.lower() == "multi":
        _run_multi_agent_init()
        return

    # 1. Project name
    name = click.prompt(
        click.style("  Project name", fg="cyan"),
        default=os.path.basename(os.getcwd()),
    )

    # 2. Description
    description = click.prompt(
        click.style("  Description", fg="cyan"),
        default="An AI agent built with SynthAgentSDK",
    )

    # 3. Provider
    click.echo("")
    click.echo(click.style("  Available providers:", fg="cyan"))
    for key, pcfg in _PROVIDERS.items():
        click.echo(
            f"    {click.style(key, fg='green'):<22s} {pcfg['display']}",
        )
    click.echo("")
    provider = click.prompt(
        click.style("  Provider", fg="cyan"),
        type=_PROVIDER_CHOICES,
        default="anthropic",
    )
    cfg = dict(_PROVIDERS[provider.lower()])
    is_agentcore = provider.lower() == "agentcore"

    # 3b. Check provider dependencies are installed
    _check_provider_deps(provider.lower(), cfg)

    # 4. Model selection (all providers)
    agentcore_state: dict[str, Any] = {}
    model_id = _run_model_selection(
        provider.lower(),
        cfg,
        agentcore_state if is_agentcore else None,
    )
    cfg["model"] = model_id

    # 5. Agent instructions
    click.echo("")
    instructions = click.prompt(
        click.style("  Agent instructions", fg="cyan"),
        default="You are a helpful assistant.",
    )

    # 6. Tool wizard
    tool_result = _run_tool_wizard()

    # 7. MCP wizard
    mcp_result = _run_mcp_wizard()

    # 8. Feature selection
    click.echo("")
    click.echo(click.style("  Select features:", fg="cyan"))
    selected_features: list[str] = []
    for key, desc in _FEATURES.items():
        if key == "deploy" and not is_agentcore:
            continue
        if click.confirm(
            f"    {click.style(desc, dim=True)}",
            default=False,
        ):
            selected_features.append(key)

    # 9. Credential check (AgentCore only)
    cred_result: dict[str, Any] = {}
    if is_agentcore:
        cred_result = _run_credential_check()

    # 10. Summary + confirm
    click.echo("")
    click.echo(click.style("  Summary:", fg="green", bold=True))
    click.echo(f"    Name:         {name}")
    click.echo(f"    Provider:     {cfg['display']}")
    click.echo(f"    Model:        {cfg['model']}")
    click.echo(f"    Features:     {', '.join(selected_features) or 'none'}")
    click.echo(f"    Instructions: {instructions[:50]}...")

    # Files to be created
    files_to_create = ["agent.py", "README.md", "synth.toml"]
    if is_agentcore:
        files_to_create += ["agentcore.yaml", ".env.template"]
    if "tools" in selected_features and not tool_result.files_created:
        files_to_create.append("tools.py")
    files_to_create.extend(tool_result.files_created)
    files_to_create.extend(mcp_result.files_created)
    if tool_result.env_vars:
        files_to_create.append(".env")
    if "eval" in selected_features:
        files_to_create.append("eval_dataset.json")
    click.echo(f"    Files:        {', '.join(files_to_create)}")
    click.echo("")

    if not click.confirm(
        click.style("  Create project?", fg="cyan"),
        default=True,
    ):
        click.echo("  Cancelled.")
        return

    # Assemble agentcore_setup dict for AgentCore projects
    agentcore_setup: dict[str, Any] | None = None
    if is_agentcore:
        agentcore_setup = {
            "aws_region": agentcore_state.get("aws_region", "us-east-1"),
            "model_id": model_id,
            "cris_enabled": agentcore_state.get("cris_enabled", False),
            "aws_profile": cred_result.get("aws_profile"),
        }

    # 11. Generate
    _generate_project(
        name=name,
        description=description,
        provider=provider.lower(),
        cfg=cfg,
        features=selected_features,
        instructions=instructions,
        agentcore_setup=agentcore_setup,
        tool_result=tool_result,
        mcp_result=mcp_result,
    )

    # 12. Deploy prompt (AgentCore only)
    if is_agentcore:
        click.echo("")
        if click.confirm(
            click.style("  Deploy now?", fg="cyan"),
            default=False,
        ):
            from synth.cli.deploy_cmd import run_deploy

            run_deploy(
                target="agentcore",
                dry_run=False,
                file=os.path.join(name, "agent.py"),
            )
        else:
            click.echo(
                click.style(
                    "  You can deploy later with: "
                    "synth deploy --target agentcore agent.py",
                    dim=True,
                ),
            )

    # 13. Testing mode — UI or CLI
    _prompt_testing_mode(name, "agent.py")


# ------------------------------------------------------------------
# Project generation
# ------------------------------------------------------------------

def _generate_project(
    name: str,
    description: str,
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
    agentcore_setup: dict[str, Any] | None = None,
    tool_result: ToolWizardResult | None = None,
    mcp_result: McpWizardResult | None = None,
) -> None:
    """Generate the project directory and files."""
    if os.path.exists(name):
        click.echo(
            click.style(f"  Directory '{name}' already exists.", fg="red"),
        )
        raise SystemExit(1)

    os.makedirs(name)

    # Resolve wizard results
    tool_res = tool_result or ToolWizardResult()
    mcp_res = mcp_result or McpWizardResult()

    # Build agent.py — pass wizard results so imports/tools list is correct
    agent_code = _build_agent_code(
        provider, cfg, features, instructions,
        tool_imports=tool_res.agent_imports,
        mcp_registration=mcp_res.agent_mcp_registration,
    )
    _write(os.path.join(name, "agent.py"), agent_code)

    # Tools file — from wizard if provided, else legacy feature flag
    if tool_res.tools_code:
        _write(os.path.join(name, "tools.py"), tool_res.tools_code)
    elif "tools" in features:
        _write(os.path.join(name, "tools.py"), _TOOLS_CODE)

    # .env file — write collected API keys from tool wizard
    if tool_res.env_vars:
        env_lines = ["# API keys collected during synth init\n"]
        for key, val in tool_res.env_vars.items():
            env_lines.append(f"{key}={val}\n")
        env_path = os.path.join(name, ".env")
        _write(env_path, "".join(env_lines))

    # MCP server directory
    if mcp_res.server_dir and mcp_res.server_code:
        server_dir = os.path.join(name, mcp_res.server_dir)
        os.makedirs(server_dir, exist_ok=True)
        _write(os.path.join(server_dir, "server.py"), mcp_res.server_code)

    # Eval dataset (all providers)
    if "eval" in features:
        _write(
            os.path.join(name, "eval_dataset.json"),
            _EVAL_DATASET,
        )

    # AgentCore eval config (agentcore provider only)
    if provider == "agentcore" and "eval" in features:
        eval_config_content = _build_eval_config(name)
        _write(
            os.path.join(name, "eval_config.json"),
            eval_config_content,
        )
        # Validate evaluator ARNs and emit warnings
        parsed = json.loads(eval_config_content)
        arns = [e["arn"] for e in parsed.get("evaluators", [])]
        for warning in _validate_evaluator_arns(arns):
            click.echo(click.style(f"  Warning: {warning}", fg="yellow"))

    # agentcore.yaml + .env.template for agentcore
    if provider == "agentcore":
        _write(os.path.join(name, ".env.template"), _ENV_TEMPLATE)
        _write(
            os.path.join(name, "agentcore.yaml"),
            _build_agentcore_yaml(name, agentcore_setup or {}, features),
        )

    # README
    _write(
        os.path.join(name, "README.md"),
        _build_readme(name, description, cfg, features),
    )

    # synth.toml config
    _write(
        os.path.join(name, "synth.toml"),
        _build_config(cfg, features),
    )

    # Success
    click.echo("")
    click.echo(click.style("  Project created!", fg="green", bold=True))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for f in os.listdir(name):
        click.echo(f"    {f}")
    click.echo("")
    click.echo("  Next steps:")
    click.echo(f"    {click.style('>', dim=True)} cd {name}")
    click.echo(
        f"    {click.style('>', dim=True)} "
        f"pip install synth-agent-sdk[{cfg['extra']}]",
    )
    if cfg["env_var"]:
        click.echo(
            f"    {click.style('>', dim=True)} "
            f'export {cfg["env_var"]}="your-key"',
        )
    click.echo(
        f'    {click.style(">", dim=True)} '
        f'synth  # interactive shell, then: dev agent.py',
    )
    click.echo("")


# ------------------------------------------------------------------
# Code generation helpers
# ------------------------------------------------------------------

def _build_agent_code(
    provider: str,
    cfg: dict[str, str],
    features: list[str],
    instructions: str,
    tool_imports: list[str] | None = None,
    mcp_registration: str | None = None,
) -> str:
    """Build the agent.py source code.

    Parameters
    ----------
    provider:
        Provider key (e.g. ``"anthropic"``).
    cfg:
        Provider config dict.
    features:
        Selected feature keys.
    instructions:
        Agent instruction string.
    tool_imports:
        Tool function names from the Tool Wizard to import from ``tools.py``.
    mcp_registration:
        MCP registration comment block to append (from MCP Wizard).
    """
    tool_imports = tool_imports or []

    imports = ['from synth import Agent']
    if "tools" in features or tool_imports:
        imports[0] += ', tool'
    if "tools" in features and not tool_imports:
        imports.append('from tools import search, calculate')
    elif tool_imports:
        imports.append(f'from tools import {", ".join(tool_imports)}')
    if "memory" in features:
        imports.append('from synth import Memory')
    if "guards" in features:
        imports.append('from synth import Guard')
    if "structured" in features:
        imports.append('from pydantic import BaseModel')
    if "deploy" in features:
        imports.append(
            'from synth.deploy.agentcore import agentcore_handler',
        )

    lines = [
        f'"""{cfg["display"]} agent built with SynthAgentSDK."""',
        '',
        'from __future__ import annotations',
        '',
    ]
    lines.extend(imports)
    lines.append('')

    # Structured output model
    if "structured" in features:
        lines.extend([
            '',
            'class Response(BaseModel):',
            '    """Structured response from the agent."""',
            '    answer: str',
            '    confidence: float',
            '',
        ])

    # Agent construction
    all_tool_names: list[str] = []
    if "tools" in features and not tool_imports:
        all_tool_names = ['search', 'calculate']
    elif tool_imports:
        all_tool_names = list(tool_imports)

    # Escape the instructions for safe embedding in Python source.
    # repr() produces a valid Python string literal that handles
    # all edge cases: quotes, backslashes, unicode, newlines.
    safe_instructions = repr(instructions)

    lines.append('')
    lines.append('agent = Agent(')
    lines.append(f'    model="{cfg["model"]}",')
    lines.append(f'    instructions={safe_instructions},')
    if all_tool_names:
        lines.append(f'    tools=[{", ".join(all_tool_names)}],')
    if "memory" in features:
        lines.append('    memory=Memory.thread(),')
    if "guards" in features:
        lines.append('    guards=[Guard.no_pii_output()],')
    if "structured" in features:
        lines.append('    output_schema=Response,')
    lines.append(')')

    # AgentCore handler
    if "deploy" in features:
        lines.extend([
            '',
            '# AgentCore entry point - creates a BedrockAgentCoreApp instance',
            'app = agentcore_handler(agent)',
        ])

    # AgentCore Evaluations comment
    if provider == "agentcore" and "eval" in features:
        lines.extend([
            '',
            '# AgentCore Evaluations is configured for this agent.',
            '# See eval_config.json for evaluator settings',
            '# (sampling rate, built-in evaluators).',
            '# Run `synth dev agent.py` to view evaluation results',
            '# in the AgentCore observability tab.',
        ])

    # MCP registration comment block
    if mcp_registration:
        lines.append(mcp_registration.rstrip())

    # Main block
    lines.extend([
        '',
        '',
        'if __name__ == "__main__":',
        '    result = agent.run("Hello! What can you do?")',
        '    print(result.text)',
    ])

    return '\n'.join(lines) + '\n'


_TOOLS_CODE = '''"""Custom tools for the agent."""

from __future__ import annotations

from synth import tool


@tool
def search(query: str, limit: int = 5) -> str:
    """Search the web for information matching the query."""
    from synth.tools.web_search import web_search as _ws
    return _ws(query, limit)


@tool
def calculate(expression: str) -> str:
    """Evaluate a mathematical expression safely."""
    import math
    allowed = {k: v for k, v in math.__dict__.items() if not k.startswith("_")}
    try:
        result = eval(expression, {"__builtins__": {}}, allowed)  # noqa: S307
        return str(result)
    except Exception as e:
        return f"Error: {e}"
'''

_EVAL_DATASET = '''[
    {
        "input": "What is 2 + 2?",
        "expected": "4"
    },
    {
        "input": "Say hello",
        "expected": "Hello"
    }
]
'''

_ENV_TEMPLATE = '''# AWS Configuration
AWS_DEFAULT_REGION=us-east-1
# AWS_ACCESS_KEY_ID=your-access-key
# AWS_SECRET_ACCESS_KEY=your-secret-key
SYNTH_NO_BANNER=0
'''


def _build_readme(
    name: str,
    description: str,
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the README.md content."""
    lines = [
        f'# {name}',
        '',
        description,
        '',
        '## Setup',
        '',
        '```bash',
        f'pip install synth-agent-sdk[{cfg["extra"]}]',
    ]
    if cfg["env_var"]:
        lines.append(f'export {cfg["env_var"]}="your-key-here"')
    lines.extend([
        '```',
        '',
        '## Run',
        '',
        '```bash',
        'synth              # interactive shell',
        'synth dev agent.py',
        'synth run agent.py "Hello"',
        '```',
    ])
    if "eval" in features:
        lines.extend([
            '',
            '## Evaluate',
            '',
            '```bash',
            'synth eval agent.py --dataset eval_dataset.json',
            '```',
        ])
    if "deploy" in features:
        lines.extend([
            '',
            '## Deploy',
            '',
            '```bash',
            'synth deploy --target agentcore agent.py',
            '```',
        ])
    lines.append('')
    return '\n'.join(lines)


def _build_config(
    cfg: dict[str, str],
    features: list[str],
) -> str:
    """Build the synth.toml config file."""
    lines = [
        '# Synth SDK project configuration',
        '',
        '[agent]',
        f'model = "{cfg["model"]}"',
        '',
        '[dev]',
        'hot_reload = true',
        'stream = true',
        '',
    ]
    if "eval" in features:
        lines.extend([
            '[eval]',
            'dataset = "eval_dataset.json"',
            'threshold = 0.5',
            '',
        ])
    return '\n'.join(lines)


def _build_eval_config(
    agent_name: str,
    sampling_rate: float = 1.0,
) -> str:
    """Build eval_config.json with default AgentCore Evaluations settings.

    Parameters
    ----------
    agent_name:
        The project/agent name for the config name field.
    sampling_rate:
        Sampling rate for online evaluation (0.01 to 1.0).

    Returns
    -------
    str
        JSON string for eval_config.json.
    """
    config = {
        "config_name": f"{agent_name}-online-eval",
        "sampling_rate": sampling_rate,
        "evaluators": [
            {
                "id": "Builtin.Helpfulness",
                "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Helpfulness",
                "level": "TRACE",
            },
            {
                "id": "Builtin.Correctness",
                "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.Correctness",
                "level": "TRACE",
            },
            {
                "id": "Builtin.GoalSuccessRate",
                "arn": "arn:aws:bedrock-agentcore:::evaluator/Builtin.GoalSuccessRate",
                "level": "SESSION",
            },
        ],
    }
    return json.dumps(config, indent=2)


_EVALUATOR_ARN_PATTERN = re.compile(
    r"^arn:aws:bedrock-agentcore:::evaluator/Builtin\..+$"
)


def _validate_evaluator_arns(arns: list[str]) -> list[str]:
    """Validate evaluator ARNs match the expected Builtin pattern.

    Parameters
    ----------
    arns:
        List of evaluator ARN strings.

    Returns
    -------
    list[str]
        List of warning messages for invalid ARNs (empty if all valid).
    """
    warnings: list[str] = []
    for arn in arns:
        if not _EVALUATOR_ARN_PATTERN.match(arn):
            warnings.append(
                f"Evaluator ARN may be invalid: {arn} "
                f"(expected pattern: arn:aws:bedrock-agentcore:::evaluator/Builtin.*)"
            )
    return warnings



def _build_agentcore_yaml(
    name: str,
    setup: dict[str, Any],
    features: list[str] | None = None,
) -> str:
    """Build the agentcore.yaml content with region/model/CRIS fields.

    Parameters
    ----------
    name:
        The project/agent name.
    setup:
        Dict assembled in ``run_init()`` containing ``aws_region``,
        ``model_id``, ``cris_enabled``, ``aws_profile``.
    features:
        Optional list of enabled feature names. When ``"eval"`` is
        present, an ``evaluations:`` section and evaluation IAM
        permissions are appended to the output.

    Returns
    -------
    str
        YAML content for ``agentcore.yaml``.
    """
    aws_region = setup.get("aws_region", "us-east-1")
    model_id = setup.get("model_id", "us.anthropic.claude-sonnet-4-5-20250929-v1:0")
    cris_enabled = setup.get("cris_enabled", False)
    aws_profile = setup.get("aws_profile")

    lines = [
        "# AgentCore Deployment Configuration",
        "#",
        "# This file is used by: synth deploy --target agentcore",
        "#",
        "# Agent Metadata",
        f"agent_name: {name}",
        'agent_description: "AI agent deployed to AWS AgentCore"',
        "",
        "# AWS Configuration",
        f"aws_region: {aws_region}",
        f"model_id: {model_id}",
        f"cris_enabled: {'true' if cris_enabled else 'false'}",
    ]

    if aws_profile:
        lines.append(f"aws_profile: {aws_profile}")

    # --- IAM Permissions ---------------------------------------------------
    permission_lines = [
        "",
        "# IAM Permissions (least-privilege)",
        "permissions:",
        '  - "bedrock:InvokeModel"',
        '  - "bedrock:InvokeModelWithResponseStream"',
        '  - "bedrock-agentcore:*"',
        '  - "ssm:GetParameter"',
        '  - "secretsmanager:GetSecretValue"',
    ]

    enabled = features or []
    if "eval" in enabled:
        permission_lines.extend([
            '  - "bedrock-agentcore:CreateEvaluationConfig"',
            '  - "bedrock-agentcore:RunEvaluation"',
            '  - "bedrock-agentcore:GetEvaluationResults"',
            '  - "logs:CreateLogGroup"',
            '  - "logs:PutLogEvents"',
        ])

    lines.extend(permission_lines)

    lines.extend([
        "",
        "# Runtime Configuration",
        "runtime:",
        "  memory_mb: 512",
        "  timeout_seconds: 300",
        "",
        "# Environment Variables (non-sensitive only)",
        "# Add non-secret config here — these are passed to the container via",
        "# 'agentcore launch --env KEY=VALUE' during deployment.",
        "# DO NOT put API keys or secrets here. Store secrets in AWS Secrets",
        "# Manager or SSM Parameter Store and fetch them at agent startup.",
        "environment:",
        '  SYNTH_NO_BANNER: "1"',
        "",
    ])

    # --- Evaluations Section -----------------------------------------------
    if "eval" in enabled:
        config_name = f"{name}-online-eval"
        lines.extend([
            "# Evaluations Configuration",
            "evaluations:",
            f"  config_name: {config_name}",
            "  sampling_rate: 1.0",
            "  evaluators:",
            '    - "Builtin.Helpfulness"',
            '    - "Builtin.Correctness"',
            '    - "Builtin.GoalSuccessRate"',
            "",
        ])

    return "\n".join(lines)




def _write(path: str, content: str) -> None:
    """Write content to a file."""
    with open(path, "w", encoding="utf-8") as f:
        f.write(content)


# ------------------------------------------------------------------
# Testing mode: UI or CLI after project generation
# ------------------------------------------------------------------


def _is_ui_server_running(port: int = 8420) -> bool:
    """Check whether a process is already listening on *port*."""
    import socket

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", port)) == 0


def _scaffold_global_ui(
    agent_file: str = "agent.py",
) -> str:
    """Create or update the global UI directory at the workspace root.

    Parameters
    ----------
    agent_file:
        Path to the agent file relative to the workspace root
        (e.g. ``"Trav/agent.py"``).

    Returns
    -------
    str
        Path to the UI ``server.py`` file (always ``ui/server.py``).
    """
    from synth.cli._ui_templates import (
        UI_CSS,
        UI_HTML,
        UI_JS,
        UI_README,
        UI_SERVER,
    )

    ui_dir = os.path.join(".", "ui")
    os.makedirs(ui_dir, exist_ok=True)
    static_dir = os.path.join(ui_dir, "static")
    os.makedirs(static_dir, exist_ok=True)

    # Patch AGENT_FILE to point at the agent relative to the
    # workspace root.  Always use forward slashes to avoid
    # backslash escape issues on Windows (e.g. \a, \t).
    agent_file_posix = agent_file.replace("\\", "/")
    server_code = UI_SERVER.replace(
        'AGENT_FILE = "../agent.py"',
        f'AGENT_FILE = "{agent_file_posix}"',
    )
    _write(os.path.join(ui_dir, "server.py"), server_code)
    _write(os.path.join(static_dir, "index.html"), UI_HTML)
    _write(os.path.join(static_dir, "style.css"), UI_CSS)
    _write(os.path.join(static_dir, "app.js"), UI_JS)
    _write(
        os.path.join(ui_dir, "README.md"),
        UI_README.format(name="synth-ui"),
    )

    return os.path.join("ui", "server.py")


def _is_in_venv() -> bool:
    """Return True if running inside a virtual environment."""
    return (
        sys.prefix != sys.base_prefix
        or os.environ.get("VIRTUAL_ENV") is not None
        or os.environ.get("CONDA_DEFAULT_ENV") is not None
    )


def _prompt_testing_mode(
    project_dir: str,
    agent_file: str = "agent.py",
) -> None:
    """Ask the user how they want to test and launch accordingly.

    The UI is scaffolded once at the workspace root (``./ui/``).
    Subsequent agent inits reuse the existing UI — if the server
    is already running, the user is simply given the URL.

    Parameters
    ----------
    project_dir:
        Path to the generated project directory.
    agent_file:
        The agent file name (relative to project_dir).
    """
    click.echo("")
    click.echo(click.style("  How would you like to test?", fg="cyan"))
    click.echo(
        f"    {click.style('ui', fg='green'):<22s} "
        "Launch the browser-based testing dashboard",
    )
    click.echo(
        f"    {click.style('cli', fg='green'):<22s} "
        "Open the interactive CLI shell",
    )
    click.echo("")

    test_mode = click.prompt(
        click.style("  Testing mode", fg="cyan"),
        type=click.Choice(["ui", "cli"], case_sensitive=False),
        default="cli",
    )

    ui_url = "http://localhost:8420"
    server_path = os.path.join("ui", "server.py")
    agent_path = os.path.join(project_dir, agent_file)

    if test_mode.lower() == "ui":
        # Check if the global UI is already running
        if _is_ui_server_running():
            click.echo("")
            click.echo(click.style(
                "  UI server is already running.",
                fg="green",
            ))
            click.echo(
                f"    {click.style('>', dim=True)} "
                f"Open {ui_url}",
            )
            click.echo(click.style(
                "  To point it at this agent, update "
                "AGENT_FILE in ui/server.py or use the "
                "UI config panel.",
                dim=True,
            ))
            return

        # Check UI dependencies before scaffolding
        _ui_deps_ok = True
        for _pkg in ("uvicorn", "fastapi"):
            try:
                __import__(_pkg)
            except ImportError:
                _ui_deps_ok = False
                break

        if not _ui_deps_ok:
            click.echo("")
            click.echo(click.style(
                "  Installing UI dependencies "
                "(uvicorn, fastapi)...",
                dim=True,
            ))
            subprocess.run(
                [sys.executable, "-m", "pip", "install",
                 "--quiet",
                 "uvicorn>=0.30", "fastapi>=0.115"],
            )
            click.echo("")

        # Scaffold the global UI (or update it for this agent)
        _scaffold_global_ui(agent_path)

        ui_exists_msg = (
            "  UI updated!" if os.path.isdir("ui")
            else "  UI scaffolded!"
        )
        click.echo("")
        click.echo(click.style(ui_exists_msg, fg="green"))
        click.echo(
            f"    {click.style('>', dim=True)} "
            f"pip install uvicorn fastapi",
        )
        click.echo(
            f"    {click.style('>', dim=True)} "
            f"python {server_path}",
        )
        click.echo(
            f"    {click.style('>', dim=True)} "
            f"Open {ui_url}",
        )
        click.echo("")

        # Try to launch the dev server
        if click.confirm(
            click.style(
                "  Start the UI server now?", fg="cyan",
            ),
            default=True,
        ):
            click.echo(click.style(
                f"\n  Starting UI server at {ui_url} ...\n",
                fg="green",
            ))
            try:
                sub_env = os.environ.copy()
                sub_env["SYNTH_AGENT_FILE"] = agent_path
                subprocess.run(
                    [sys.executable, server_path],
                    env=sub_env,
                )
            except KeyboardInterrupt:
                click.echo(click.style(
                    "\n  Server stopped.", dim=True,
                ))
    else:
        # Launch the CLI dev REPL
        click.echo("")
        click.echo(click.style(
            "  Launching interactive CLI...\n",
            fg="green",
        ))
        try:
            from synth.cli.dev import run_dev
            run_dev(agent_path)
        except KeyboardInterrupt:
            click.echo(click.style(
                "\n  Session ended.", dim=True,
            ))
        except Exception as exc:
            click.echo(click.style(
                f"  Could not start dev session: {exc}",
                fg="yellow",
            ))
            click.echo(click.style(
                f"  You can start it manually with: "
                f"synth dev {agent_path}",
                dim=True,
            ))


# ------------------------------------------------------------------
# Multi-agent init flow
# ------------------------------------------------------------------

# Orchestration pattern descriptions shown during selection
_ORCHESTRATION_PATTERNS: dict[str, dict[str, str]] = {
    "pipeline": {
        "display": "Pipeline",
        "description": (
            "Linear sequential chaining \u2014 each agent receives the "
            "previous agent's output as input. Use for step-by-step "
            "processing workflows."
        ),
    },
    "graph": {
        "display": "Graph",
        "description": (
            "Directed graph with conditional edges, branching, and "
            "loops. Use for complex workflows with decision points."
        ),
    },
    "agent_team": {
        "display": "AgentTeam",
        "description": (
            "Multi-agent coordination \u2014 an orchestrator routes "
            "tasks to specialized agents. Supports auto (orchestrator "
            "decides) and parallel (all agents run concurrently) "
            "strategies."
        ),
    },
    "human_in_loop": {
        "display": "Human-in-the-Loop",
        "description": (
            "Graph with human review checkpoints \u2014 pauses "
            "execution at specified nodes for human input before "
            "continuing. Adds pause/resume capability to a Graph "
            "workflow."
        ),
    },
}

_ORCHESTRATION_CHOICES = click.Choice(
    list(_ORCHESTRATION_PATTERNS.keys()), case_sensitive=False,
)


def _configure_agent(
    index: int,
    existing_names: list[str],
    shared: SharedMultiAgentConfig | None = None,
) -> AgentConfig:
    """Configure a single agent interactively.

    Parameters
    ----------
    index:
        The 1-based agent number (for display).
    existing_names:
        Names already taken by previously configured agents.
    shared:
        Optional shared configuration.  When provided, provider,
        model, region, tools, and MCP settings are inherited from
        the shared config instead of prompting the user again.

    Returns
    -------
    AgentConfig
        The completed agent configuration.
    """
    click.echo("")
    click.echo(click.style(
        f"  --- Agent {index} ---", fg="green", bold=True,
    ))

    # Name (unique, non-empty)
    while True:
        agent_name = click.prompt(
            click.style("  Agent name", fg="cyan"),
            default=f"agent_{index}",
        ).strip()
        if not agent_name:
            click.echo(click.style(
                "    Name cannot be empty.", fg="red",
            ))
            continue
        if agent_name in existing_names:
            click.echo(click.style(
                f"    Name '{agent_name}' is already taken.", fg="red",
            ))
            continue
        # Warn if the safe name collides with an existing safe name
        safe = _sanitize_agent_name(agent_name)
        existing_safe = [
            _sanitize_agent_name(n) for n in existing_names
        ]
        if safe in existing_safe:
            click.echo(click.style(
                f"    Name '{agent_name}' conflicts with an "
                f"existing agent (both map to '{safe}').",
                fg="red",
            ))
            continue
        break

    # Description
    agent_desc = click.prompt(
        click.style("  Agent description", fg="cyan"),
        default=f"Agent {index} in the multi-agent project",
    )

    # --- Provider / model (shared or per-agent) ---
    if shared and shared.share_provider:
        provider = shared.provider
        cfg = dict(shared.provider_cfg)
        model_id = shared.model
        is_agentcore = shared.is_agentcore
        agentcore_state = dict(shared.agentcore_state)
        click.echo(click.style(
            f"    Provider: {cfg['display']}  "
            f"Model: {model_id}",
            dim=True,
        ))
    else:
        click.echo("")
        click.echo(click.style(
            "  Available providers:", fg="cyan",
        ))
        for key, pcfg in _PROVIDERS.items():
            click.echo(
                f"    {click.style(key, fg='green'):<22s} "
                f"{pcfg['display']}",
            )
        click.echo("")
        provider = click.prompt(
            click.style("  Provider", fg="cyan"),
            type=_PROVIDER_CHOICES,
            default="anthropic",
        )
        cfg = dict(_PROVIDERS[provider.lower()])
        is_agentcore = provider.lower() == "agentcore"

        _check_provider_deps(provider.lower(), cfg)

        agentcore_state: dict[str, Any] = {}
        model_id = _run_model_selection(
            provider.lower(),
            cfg,
            agentcore_state if is_agentcore else None,
        )
        cfg["model"] = model_id

    # Instructions
    click.echo("")
    instructions = click.prompt(
        click.style("  Agent instructions", fg="cyan"),
        default="You are a helpful assistant.",
    )

    # --- Tools / MCP (shared or per-agent) ---
    if shared and shared.share_tools:
        tool_result = shared.tool_result
        mcp_result = shared.mcp_result
        if tool_result.agent_imports:
            click.echo(click.style(
                f"    Tools: {', '.join(tool_result.agent_imports)}",
                dim=True,
            ))
    else:
        tool_result = _run_tool_wizard()
        mcp_result = _run_mcp_wizard()

    return AgentConfig(
        name=agent_name,
        description=agent_desc,
        provider=provider.lower(),
        provider_cfg=cfg,
        model=model_id,
        instructions=instructions,
        tool_result=tool_result,
        mcp_result=mcp_result,
        is_agentcore=is_agentcore,
        agentcore_state=agentcore_state,
    )


def _select_orchestration(
    agents: list[AgentConfig],
    shared: SharedMultiAgentConfig | None = None,
) -> OrchestrationConfig:
    """Select and configure an orchestration pattern.

    Parameters
    ----------
    agents:
        The list of configured agents.
    shared:
        Optional shared configuration for reuse in orchestrator
        model selection.

    Returns
    -------
    OrchestrationConfig
        The selected pattern and its configuration.
    """
    click.echo("")
    click.echo(click.style(
        "  Select orchestration pattern:", fg="cyan", bold=True,
    ))
    click.echo("")
    for key, info in _ORCHESTRATION_PATTERNS.items():
        click.echo(
            f"    {click.style(key, fg='green'):<22s} "
            f"{info['display']}",
        )
        click.echo(
            f"    {'':22s} {click.style(info['description'], dim=True)}",
        )
        click.echo("")

    pattern = click.prompt(
        click.style("  Orchestration pattern", fg="cyan"),
        type=_ORCHESTRATION_CHOICES,
        default="pipeline",
    ).lower()

    if pattern == "pipeline":
        pcfg = _configure_pipeline(agents)
        return OrchestrationConfig(pattern=pattern, pipeline=pcfg)
    elif pattern == "graph":
        gcfg = _configure_graph(agents)
        return OrchestrationConfig(pattern=pattern, graph=gcfg)
    elif pattern == "agent_team":
        tcfg = _configure_agent_team(agents, shared)
        return OrchestrationConfig(pattern=pattern, agent_team=tcfg)
    else:  # human_in_loop
        hcfg = _configure_human_in_loop(agents)
        return OrchestrationConfig(pattern=pattern, human_in_loop=hcfg)


def _configure_pipeline(
    agents: list[AgentConfig],
) -> PipelineConfig:
    """Configure Pipeline orchestration — agent execution order."""
    agent_names = [a.name for a in agents]
    click.echo("")
    click.echo(click.style("  Pipeline configuration", fg="cyan"))
    click.echo(f"    Default order: {' -> '.join(agent_names)}")
    click.echo("")

    keep_default = click.confirm(
        click.style("  Use default order?", fg="cyan"),
        default=True,
    )
    if keep_default:
        return PipelineConfig(agent_order=list(agent_names))

    # Custom ordering
    click.echo("")
    click.echo(click.style("  Available agents:", fg="cyan"))
    for i, name in enumerate(agent_names, 1):
        click.echo(f"    {i}. {name}")
    click.echo("")
    click.echo(click.style(
        "  Enter agent names in execution order "
        "(comma-separated):",
        fg="cyan",
    ))
    raw = click.prompt("  Order", default=",".join(agent_names))
    ordered = [n.strip() for n in raw.split(",") if n.strip()]

    # Validate all names exist
    valid = [n for n in ordered if n in agent_names]
    if not valid:
        click.echo(click.style(
            "    No valid agent names provided. Using default order.",
            fg="yellow",
        ))
        valid = list(agent_names)

    return PipelineConfig(agent_order=valid)


def _configure_graph(
    agents: list[AgentConfig],
) -> GraphConfig:
    """Configure Graph orchestration — entry node, edges, conditions."""
    agent_names = [a.name for a in agents]
    click.echo("")
    click.echo(click.style("  Graph configuration", fg="cyan"))
    click.echo("")

    # Entry node
    click.echo(click.style("  Available nodes:", fg="cyan"))
    for i, name in enumerate(agent_names, 1):
        click.echo(f"    {i}. {name}")
    click.echo("")

    entry = click.prompt(
        click.style("  Entry node", fg="cyan"),
        type=click.Choice(agent_names, case_sensitive=False),
        default=agent_names[0],
    )

    # Edges
    click.echo("")
    click.echo(click.style(
        "  Define edges (source -> target). "
        "Use 'END' as target to terminate.",
        fg="cyan",
    ))
    valid_targets = agent_names + ["END"]
    edges: list[EdgeConfig] = []

    while True:
        click.echo("")
        source = click.prompt(
            click.style("  Edge source (or 'done' to finish)", fg="cyan"),
            default="done",
        ).strip()
        if source.lower() == "done":
            break
        if source not in agent_names:
            click.echo(click.style(
                f"    '{source}' is not a valid node.", fg="red",
            ))
            continue

        target = click.prompt(
            click.style("  Edge target", fg="cyan"),
            type=click.Choice(valid_targets, case_sensitive=False),
        )

        condition = click.prompt(
            click.style(
                "  Condition description (or Enter for unconditional)",
                fg="cyan",
            ),
            default="",
        ).strip() or None

        edges.append(EdgeConfig(
            source=source,
            target=target,
            condition=condition,
        ))
        click.echo(click.style(
            f"    Added: {source} -> {target}"
            + (f" [when: {condition}]" if condition else ""),
            dim=True,
        ))

    # If no edges defined, create a simple chain as default
    if not edges:
        click.echo(click.style(
            "    No edges defined. Creating a default chain.",
            fg="yellow",
        ))
        for i in range(len(agent_names) - 1):
            edges.append(EdgeConfig(
                source=agent_names[i],
                target=agent_names[i + 1],
            ))
        edges.append(EdgeConfig(
            source=agent_names[-1],
            target="END",
        ))

    return GraphConfig(entry_node=entry, edges=edges)


def _configure_agent_team(
    agents: list[AgentConfig],
    shared: SharedMultiAgentConfig | None = None,
) -> AgentTeamConfig:
    """Configure AgentTeam orchestration — strategy and orchestrator."""
    click.echo("")
    click.echo(click.style("  AgentTeam configuration", fg="cyan"))
    click.echo("")
    click.echo(click.style("  Strategies:", fg="cyan"))
    click.echo(
        f"    {click.style('auto', fg='green'):<22s} "
        "The orchestrator decides which agent to route tasks to "
        "based on task content and agent descriptions.",
    )
    click.echo(
        f"    {click.style('parallel', fg='green'):<22s} "
        "All agents receive the task concurrently and results "
        "are aggregated.",
    )
    click.echo("")

    strategy = click.prompt(
        click.style("  Strategy", fg="cyan"),
        type=click.Choice(["auto", "parallel"], case_sensitive=False),
        default="auto",
    )

    # Orchestrator model — reuse shared config if available
    if shared and shared.share_provider and shared.model:
        click.echo("")
        click.echo(click.style("  Orchestrator model:", fg="cyan"))
        click.echo(click.style(
            f"    Shared: {shared.provider_cfg.get('display', '')} "
            f"/ {shared.model}",
            dim=True,
        ))
        use_shared = click.confirm(
            click.style(
                "  Use the same model for the orchestrator?",
                fg="cyan",
            ),
            default=True,
        )
        if use_shared:
            return AgentTeamConfig(
                strategy=strategy.lower(),
                orchestrator_model=shared.model,
            )

    # Full provider/model selection for orchestrator
    click.echo("")
    click.echo(click.style("  Orchestrator model:", fg="cyan"))
    click.echo(click.style(
        "    The orchestrator coordinates the team. "
        "Select a provider and model for it.",
        dim=True,
    ))
    click.echo("")
    for key, pcfg in _PROVIDERS.items():
        click.echo(
            f"    {click.style(key, fg='green'):<22s} "
            f"{pcfg['display']}",
        )
    click.echo("")

    orch_provider = click.prompt(
        click.style("  Orchestrator provider", fg="cyan"),
        type=_PROVIDER_CHOICES,
        default="anthropic",
    )
    orch_cfg = dict(_PROVIDERS[orch_provider.lower()])
    orch_model = _run_model_selection(orch_provider.lower(), orch_cfg)

    return AgentTeamConfig(
        strategy=strategy.lower(),
        orchestrator_model=orch_model,
    )


def _configure_human_in_loop(
    agents: list[AgentConfig],
) -> HumanInLoopConfig:
    """Configure Human-in-the-Loop — graph + pause nodes."""
    click.echo("")
    click.echo(click.style(
        "  Human-in-the-Loop configuration", fg="cyan",
    ))
    click.echo(click.style(
        "    First, configure the underlying graph topology.",
        dim=True,
    ))

    # Step 1: Graph configuration
    graph_cfg = _configure_graph(agents)

    # Step 2: Pause nodes
    agent_names = [a.name for a in agents]
    click.echo("")
    click.echo(click.style(
        "  Select pause points (nodes where execution pauses "
        "for human review):",
        fg="cyan",
    ))
    for i, name in enumerate(agent_names, 1):
        click.echo(f"    {i}. {name}")
    click.echo("")

    raw = click.prompt(
        click.style(
            "  Pause nodes (comma-separated names)", fg="cyan",
        ),
        default=agent_names[0],
    )
    pause_nodes = [
        n.strip() for n in raw.split(",")
        if n.strip() in agent_names
    ]
    if not pause_nodes:
        pause_nodes = [agent_names[0]]
        click.echo(click.style(
            f"    Defaulting to: {pause_nodes[0]}", fg="yellow",
        ))

    # Step 3: Timeout
    click.echo("")
    timeout_raw = click.prompt(
        click.style(
            "  Timeout in seconds (0 for no timeout)", fg="cyan",
        ),
        type=int,
        default=0,
    )
    timeout = float(timeout_raw) if timeout_raw > 0 else None

    # Step 4: Fallback node
    fallback_node: str | None = None
    if timeout is not None:
        click.echo("")
        fallback_raw = click.prompt(
            click.style(
                "  Fallback node on timeout "
                "(or Enter to abort on timeout)",
                fg="cyan",
            ),
            default="",
        ).strip()
        if fallback_raw and fallback_raw in agent_names:
            fallback_node = fallback_raw

    return HumanInLoopConfig(
        graph=graph_cfg,
        pause_nodes=pause_nodes,
        timeout=timeout,
        fallback_node=fallback_node,
    )


def _collect_shared_config() -> SharedMultiAgentConfig:
    """Prompt the user for shared multi-agent configuration.

    Asks whether provider/model/region and tools should be shared
    across all agents.  If yes, collects those values once upfront.

    Returns
    -------
    SharedMultiAgentConfig
        The shared configuration (may have both flags ``False`` if the
        user wants per-agent customisation).
    """
    shared = SharedMultiAgentConfig()

    click.echo("")
    click.echo(click.style(
        "  Shared configuration", fg="cyan", bold=True,
    ))
    click.echo(click.style(
        "    Speed up setup by sharing settings across all agents.",
        dim=True,
    ))
    click.echo("")

    # --- Shared provider / model / region ---
    shared.share_provider = click.confirm(
        click.style(
            "  Use the same provider and model for all agents?",
            fg="cyan",
        ),
        default=True,
    )
    if shared.share_provider:
        click.echo("")
        click.echo(click.style(
            "  Available providers:", fg="cyan",
        ))
        for key, pcfg in _PROVIDERS.items():
            click.echo(
                f"    {click.style(key, fg='green'):<22s} "
                f"{pcfg['display']}",
            )
        click.echo("")
        provider = click.prompt(
            click.style("  Provider", fg="cyan"),
            type=_PROVIDER_CHOICES,
            default="anthropic",
        )
        cfg = dict(_PROVIDERS[provider.lower()])
        shared.is_agentcore = provider.lower() == "agentcore"

        _check_provider_deps(provider.lower(), cfg)

        agentcore_state: dict[str, Any] = {}
        model_id = _run_model_selection(
            provider.lower(),
            cfg,
            agentcore_state if shared.is_agentcore else None,
        )
        cfg["model"] = model_id

        shared.provider = provider.lower()
        shared.provider_cfg = cfg
        shared.model = model_id
        shared.agentcore_state = agentcore_state

    # --- Shared tools ---
    click.echo("")
    shared.share_tools = click.confirm(
        click.style(
            "  Use the same tools for all agents?",
            fg="cyan",
        ),
        default=True,
    )
    if shared.share_tools:
        shared.tool_result = _run_tool_wizard()
        shared.mcp_result = _run_mcp_wizard()

    return shared


def _run_multi_agent_init() -> None:
    """Run the multi-agent interactive project initializer."""
    # 1. Project identity
    name = click.prompt(
        click.style("  Project name", fg="cyan"),
        default=os.path.basename(os.getcwd()),
    )
    description = click.prompt(
        click.style("  Description", fg="cyan"),
        default="A multi-agent project built with SynthAgentSDK",
    )

    # 2. Agent count
    click.echo("")
    num_agents = click.prompt(
        click.style("  Number of agents", fg="cyan"),
        type=click.IntRange(2, 20),
        default=2,
    )

    # 3. Shared configuration (provider, model, tools)
    shared = _collect_shared_config()

    # 4. Agent configuration loop
    agents: list[AgentConfig] = []
    for i in range(1, num_agents + 1):
        existing_names = [a.name for a in agents]
        agent_cfg = _configure_agent(i, existing_names, shared)
        agents.append(agent_cfg)

    # 5. Orchestration selection + configuration
    orchestration = _select_orchestration(agents, shared)

    # 6. Feature selection
    click.echo("")
    click.echo(click.style("  Select features:", fg="cyan"))
    any_agentcore = any(a.is_agentcore for a in agents)
    selected_features: list[str] = []
    for key, desc in _FEATURES.items():
        if key == "deploy" and not any_agentcore:
            continue
        if click.confirm(
            f"    {click.style(desc, dim=True)}",
            default=False,
        ):
            selected_features.append(key)

    # 7. Credential check (if any agent uses AgentCore)
    cred_result: dict[str, Any] = {}
    if any_agentcore:
        cred_result = _run_credential_check()

    # 8. Summary + confirm
    click.echo("")
    click.echo(click.style("  Summary:", fg="green", bold=True))
    click.echo(f"    Project:        {name}")
    click.echo(f"    Agents:         {len(agents)}")
    for a in agents:
        click.echo(
            f"      - {a.name} ({a.provider_cfg['display']}, "
            f"{a.model})",
        )
    orch_display = _ORCHESTRATION_PATTERNS[orchestration.pattern]
    click.echo(
        f"    Orchestration:  {orch_display['display']}",
    )
    click.echo(
        f"    Features:       "
        f"{', '.join(selected_features) or 'none'}",
    )
    click.echo("")

    if not click.confirm(
        click.style("  Create project?", fg="cyan"),
        default=True,
    ):
        click.echo("  Cancelled.")
        return

    # 9. Project generation
    _generate_multi_agent_project(
        name=name,
        description=description,
        agents=agents,
        orchestration=orchestration,
        features=selected_features,
        agentcore_creds=cred_result if any_agentcore else None,
    )

    # 10. Deploy prompt (if any agent uses AgentCore)
    if any_agentcore:
        click.echo("")
        if click.confirm(
            click.style("  Deploy now?", fg="cyan"),
            default=False,
        ):
            from synth.cli.deploy_cmd import run_deploy

            for a in agents:
                if a.is_agentcore:
                    run_deploy(
                        target="agentcore",
                        dry_run=False,
                        file=os.path.join(
                            name, f"agent_{a.safe_name}.py",
                        ),
                    )
        else:
            click.echo(click.style(
                "  You can deploy each agent later with: "
                "synth deploy --target agentcore <agent_file>",
                dim=True,
            ))

    # 11. Testing mode — UI or CLI
    _prompt_testing_mode(name, "main.py")


# ------------------------------------------------------------------
# Multi-agent project generation
# ------------------------------------------------------------------


def _generate_multi_agent_project(
    name: str,
    description: str,
    agents: list[AgentConfig],
    orchestration: OrchestrationConfig,
    features: list[str],
    agentcore_creds: dict[str, Any] | None = None,
) -> None:
    """Generate a multi-agent project directory with all files.

    Parameters
    ----------
    name:
        Project directory name.
    description:
        Project description.
    agents:
        List of configured agents.
    orchestration:
        Selected orchestration pattern and configuration.
    features:
        Selected feature keys.
    agentcore_creds:
        Credential info if any agent uses AgentCore.
    """
    if os.path.exists(name):
        click.echo(click.style(
            f"  Directory '{name}' already exists.", fg="red",
        ))
        raise SystemExit(1)

    os.makedirs(name)

    # Generate individual agent files
    for agent in agents:
        agent_code = _build_multi_agent_code(agent, features)
        _write(
            os.path.join(name, f"agent_{agent.safe_name}.py"),
            agent_code,
        )

        # Tool files per agent
        if agent.tool_result.tools_code:
            _write(
                os.path.join(
                    name, f"tools_{agent.safe_name}.py",
                ),
                agent.tool_result.tools_code,
            )

        # MCP server directories per agent
        if (agent.mcp_result.server_dir
                and agent.mcp_result.server_code):
            server_dir = os.path.join(
                name, agent.mcp_result.server_dir,
            )
            os.makedirs(server_dir, exist_ok=True)
            _write(
                os.path.join(server_dir, "server.py"),
                agent.mcp_result.server_code,
            )

    # Generate main.py orchestration file
    main_code = _build_orchestration_code(
        agents, orchestration, features,
    )
    _write(os.path.join(name, "main.py"), main_code)

    # .env file — collect API keys from all agents' tool wizards
    all_env_vars: dict[str, str] = {}
    for agent in agents:
        all_env_vars.update(agent.tool_result.env_vars)
    if all_env_vars:
        env_lines = ["# API keys collected during synth init\n"]
        for key, val in all_env_vars.items():
            env_lines.append(f"{key}={val}\n")
        _write(os.path.join(name, ".env"), "".join(env_lines))

    # Eval dataset (all providers)
    if "eval" in features:
        _write(
            os.path.join(name, "eval_dataset.json"),
            _EVAL_DATASET,
        )

    # AgentCore files (if any agent uses it)
    any_agentcore = any(a.is_agentcore for a in agents)
    if any_agentcore:
        _write(os.path.join(name, ".env.template"), _ENV_TEMPLATE)

        # AgentCore eval config
        if "eval" in features:
            eval_config_content = _build_eval_config(name)
            _write(
                os.path.join(name, "eval_config.json"),
                eval_config_content,
            )
            # Validate evaluator ARNs and emit warnings
            parsed = json.loads(eval_config_content)
            arns = [e["arn"] for e in parsed.get("evaluators", [])]
            for warning in _validate_evaluator_arns(arns):
                click.echo(
                    click.style(f"  Warning: {warning}", fg="yellow"),
                )

        # Use the first AgentCore agent's state for the yaml
        ac_agent = next(a for a in agents if a.is_agentcore)
        setup = {
            "aws_region": ac_agent.agentcore_state.get(
                "aws_region", "us-east-1",
            ),
            "model_id": ac_agent.model,
            "cris_enabled": ac_agent.agentcore_state.get(
                "cris_enabled", False,
            ),
            "aws_profile": (
                agentcore_creds.get("aws_profile")
                if agentcore_creds else None
            ),
        }
        _write(
            os.path.join(name, "agentcore.yaml"),
            _build_agentcore_yaml(name, setup, features),
        )

    # README
    _write(
        os.path.join(name, "README.md"),
        _build_multi_agent_readme(
            name, description, agents, orchestration, features,
        ),
    )

    # synth.toml — use first agent's config as primary
    first_cfg = agents[0].provider_cfg
    _write(
        os.path.join(name, "synth.toml"),
        _build_config(first_cfg, features),
    )

    # Success
    click.echo("")
    click.echo(click.style(
        "  Project created!", fg="green", bold=True,
    ))
    click.echo("")
    click.echo(f"  {click.style(name + '/', fg='cyan')}")
    for f in sorted(os.listdir(name)):
        click.echo(f"    {f}")
    click.echo("")

    # Collect unique extras needed
    extras = sorted({a.provider_cfg["extra"] for a in agents})
    click.echo("  Next steps:")
    click.echo(
        f"    {click.style('>', dim=True)} cd {name}",
    )
    for extra in extras:
        click.echo(
            f"    {click.style('>', dim=True)} "
            f"pip install synth-agent-sdk[{extra}]",
        )
    env_vars = sorted({
        a.provider_cfg["env_var"]
        for a in agents if a.provider_cfg["env_var"]
    })
    for ev in env_vars:
        click.echo(
            f"    {click.style('>', dim=True)} "
            f'export {ev}="your-key"',
        )
    click.echo(
        f"    {click.style('>', dim=True)} python main.py",
    )
    click.echo("")


# ------------------------------------------------------------------
# Multi-agent code generation helpers
# ------------------------------------------------------------------


def _build_multi_agent_code(
    agent: AgentConfig,
    features: list[str],
) -> str:
    """Build the Python source for a single agent file.

    Parameters
    ----------
    agent:
        The agent configuration.
    features:
        Selected project-level feature keys.

    Returns
    -------
    str
        Python source code for the agent file.
    """
    tool_imports = agent.tool_result.agent_imports or []
    mcp_reg = agent.mcp_result.agent_mcp_registration

    imports = ["from synth import Agent"]
    if tool_imports:
        imports[0] += ", tool"
        imports.append(
            f"from tools_{agent.safe_name} import "
            f"{', '.join(tool_imports)}",
        )
    if "memory" in features:
        imports.append("from synth import Memory")
    if "guards" in features:
        imports.append("from synth import Guard")
    if "structured" in features:
        imports.append("from pydantic import BaseModel")
    if "deploy" in features and agent.is_agentcore:
        imports.append(
            "from synth.deploy.agentcore import agentcore_handler",
        )

    lines = [
        f'"""{agent.provider_cfg["display"]} agent: '
        f'{agent.name}."""',
        "",
        "from __future__ import annotations",
        "",
    ]
    lines.extend(imports)
    lines.append("")

    if "structured" in features:
        lines.extend([
            "",
            "class Response(BaseModel):",
            '    """Structured response from the agent."""',
            "    answer: str",
            "    confidence: float",
            "",
        ])

    safe_instructions = repr(agent.instructions)

    lines.append("")
    lines.append(f"{agent.safe_name} = Agent(")
    lines.append(f'    model="{agent.model}",')
    lines.append(f'    instructions={safe_instructions},')
    if tool_imports:
        lines.append(
            f"    tools=[{', '.join(tool_imports)}],",
        )
    if "memory" in features:
        lines.append("    memory=Memory.thread(),")
    if "guards" in features:
        lines.append("    guards=[Guard.no_pii_output()],")
    if "structured" in features:
        lines.append("    output_schema=Response,")
    lines.append(")")

    if "deploy" in features and agent.is_agentcore:
        lines.extend([
            "",
            "# AgentCore entry point",
            f"app = agentcore_handler({agent.safe_name})",
        ])

    if mcp_reg:
        lines.append(mcp_reg.rstrip())

    lines.extend([
        "",
        "",
        'if __name__ == "__main__":',
        f'    result = {agent.safe_name}.run('
        f'"Hello! What can you do?")',
        f"    print(result.text)",
    ])

    return "\n".join(lines) + "\n"


def _build_orchestration_code(
    agents: list[AgentConfig],
    orchestration: OrchestrationConfig,
    features: list[str],
) -> str:
    """Build the main.py orchestration source code.

    Parameters
    ----------
    agents:
        List of configured agents.
    orchestration:
        The orchestration configuration.
    features:
        Selected feature keys.

    Returns
    -------
    str
        Python source code for main.py.
    """
    pattern = orchestration.pattern
    if pattern == "pipeline":
        return _build_pipeline_code(
            agents, orchestration.pipeline or PipelineConfig(),
        )
    elif pattern == "graph":
        return _build_graph_code(
            agents, orchestration.graph or GraphConfig(),
        )
    elif pattern == "agent_team":
        return _build_team_code(
            agents, orchestration.agent_team or AgentTeamConfig(),
        )
    else:  # human_in_loop
        return _build_human_in_loop_code(
            agents,
            orchestration.human_in_loop or HumanInLoopConfig(),
        )


def _build_pipeline_code(
    agents: list[AgentConfig],
    config: PipelineConfig,
) -> str:
    """Generate Pipeline orchestration code."""
    agent_imports = "\n".join(
        f"from agent_{a.safe_name} import {a.safe_name}"
        for a in agents
    )
    # Map display names to safe names for ordering
    name_to_safe = {a.name: a.safe_name for a in agents}
    order = config.agent_order or [a.name for a in agents]
    agent_list = ", ".join(
        name_to_safe.get(n, n) for n in order
    )

    return (
        '"""Multi-agent pipeline orchestration."""\n'
        "\n"
        "from __future__ import annotations\n"
        "\n"
        "from synth import Pipeline\n"
        "\n"
        f"{agent_imports}\n"
        "\n"
        "\n"
        f"pipeline = Pipeline([{agent_list}])\n"
        "\n"
        "\n"
        'if __name__ == "__main__":\n'
        '    result = pipeline.run("Start the workflow.")\n'
        "    print(result.text)\n"
    )


def _build_graph_code(
    agents: list[AgentConfig],
    config: GraphConfig,
) -> str:
    """Generate Graph orchestration code."""
    agent_imports = "\n".join(
        f"from agent_{a.safe_name} import {a.safe_name}"
        for a in agents
    )
    # Map display names to safe names for edge/entry references
    name_to_safe = {a.name: a.safe_name for a in agents}

    lines = [
        '"""Multi-agent graph orchestration."""',
        "",
        "from __future__ import annotations",
        "",
        "from synth import Graph, node",
        "",
        agent_imports,
        "",
        "",
        "graph = Graph()",
        "",
    ]

    # Node wrappers — each agent becomes a graph node
    for a in agents:
        lines.extend([
            "",
            f"@node(graph)",
            f"def {a.safe_name}_node(state):",
            f'    """Run the {a.name} agent."""',
            f'    result = {a.safe_name}.run('
            f'state.get("input", ""))',
            f'    state["{a.safe_name}_output"] = result.text',
            f"    return state",
        ])

    # Edges
    lines.append("")
    entry_raw = config.entry_node or agents[0].name
    entry_safe = name_to_safe.get(entry_raw, entry_raw)
    lines.append(f'graph.set_entry("{entry_safe}_node")')
    lines.append("")

    for edge in config.edges:
        src_safe = name_to_safe.get(edge.source, edge.source)
        src = f'"{src_safe}_node"'
        if edge.target == "END":
            tgt = "Graph.END"
        else:
            tgt_safe = name_to_safe.get(
                edge.target, edge.target,
            )
            tgt = f'"{tgt_safe}_node"'
        if edge.condition:
            lines.append(
                f"graph.add_edge({src}, {tgt})  "
                f"# {edge.condition}",
            )
        else:
            lines.append(f"graph.add_edge({src}, {tgt})")

    lines.extend([
        "",
        "",
        'if __name__ == "__main__":',
        '    result = graph.run({"input": '
        '"Start the workflow."})',
        "    print(result)",
    ])

    return "\n".join(lines) + "\n"


def _build_team_code(
    agents: list[AgentConfig],
    config: AgentTeamConfig,
) -> str:
    """Generate AgentTeam orchestration code."""
    agent_imports = "\n".join(
        f"from agent_{a.safe_name} import {a.safe_name}"
        for a in agents
    )
    agent_list = ", ".join(a.safe_name for a in agents)

    return (
        '"""Multi-agent team orchestration."""\n'
        "\n"
        "from __future__ import annotations\n"
        "\n"
        "from synth.orchestration.team import AgentTeam\n"
        "\n"
        f"{agent_imports}\n"
        "\n"
        "\n"
        "team = AgentTeam(\n"
        f'    orchestrator="{config.orchestrator_model}",\n'
        f"    agents=[{agent_list}],\n"
        f'    strategy="{config.strategy}",\n'
        ")\n"
        "\n"
        "\n"
        'if __name__ == "__main__":\n'
        '    result = team.run("Start the workflow.")\n'
        "    print(result.answer)\n"
    )


def _build_human_in_loop_code(
    agents: list[AgentConfig],
    config: HumanInLoopConfig,
) -> str:
    """Generate Human-in-the-Loop Graph orchestration code."""
    # Build the base graph code first
    graph_code = _build_graph_code(agents, config.graph)

    # Map display names to safe names for pause/fallback nodes
    name_to_safe = {a.name: a.safe_name for a in agents}

    # Insert the human-in-the-loop configuration before the
    # if __name__ block
    pause_list = ", ".join(
        f'"{name_to_safe.get(n, n)}_node"'
        for n in config.pause_nodes
    )
    hitl_args = f"pause_at=[{pause_list}]"
    if config.timeout is not None:
        hitl_args += f", timeout={config.timeout}"
    if config.fallback_node:
        fb_safe = name_to_safe.get(
            config.fallback_node, config.fallback_node,
        )
        hitl_args += f', fallback="{fb_safe}_node"'

    hitl_block = (
        "\n"
        f"graph.with_human_in_the_loop({hitl_args})\n"
    )

    # Insert before the if __name__ block
    marker = '\n\nif __name__ == "__main__":'
    if marker in graph_code:
        graph_code = graph_code.replace(
            marker,
            hitl_block + marker,
        )
    else:
        graph_code += hitl_block

    return graph_code


def _build_multi_agent_readme(
    name: str,
    description: str,
    agents: list[AgentConfig],
    orchestration: OrchestrationConfig,
    features: list[str],
) -> str:
    """Build the README.md for a multi-agent project.

    Parameters
    ----------
    name:
        Project name.
    description:
        Project description.
    agents:
        List of configured agents.
    orchestration:
        Orchestration configuration.
    features:
        Selected feature keys.

    Returns
    -------
    str
        Markdown content for README.md.
    """
    orch_info = _ORCHESTRATION_PATTERNS[orchestration.pattern]
    extras = sorted({a.provider_cfg["extra"] for a in agents})

    lines = [
        f"# {name}",
        "",
        description,
        "",
        "## Agents",
        "",
    ]
    for a in agents:
        lines.append(
            f"- **{a.name}** ({a.provider_cfg['display']}): "
            f"{a.description}",
        )
    lines.extend([
        "",
        "## Orchestration",
        "",
        f"Pattern: **{orch_info['display']}**",
        "",
        orch_info["description"],
        "",
        "## Setup",
        "",
        "```bash",
    ])
    for extra in extras:
        lines.append(f"pip install synth-agent-sdk[{extra}]")
    env_vars = sorted({
        a.provider_cfg["env_var"]
        for a in agents if a.provider_cfg["env_var"]
    })
    for ev in env_vars:
        lines.append(f'export {ev}="your-key-here"')
    lines.extend([
        "```",
        "",
        "## Run",
        "",
        "```bash",
        "python main.py",
        "```",
    ])
    if "eval" in features:
        lines.extend([
            "",
            "## Evaluate",
            "",
            "```bash",
            "synth eval main.py --dataset eval_dataset.json",
            "```",
        ])
    if "deploy" in features:
        lines.extend([
            "",
            "## Deploy",
            "",
            "```bash",
        ])
        for a in agents:
            if a.is_agentcore:
                lines.append(
                    f"synth deploy --target agentcore "
                    f"agent_{a.safe_name}.py",
                )
        lines.append("```")
    lines.append("")
    return "\n".join(lines)
