"""``synth run`` command — execute an agent with a prompt."""

from __future__ import annotations

import importlib.util
import sys

import click

from synth.errors import SynthError


def run_agent(file: str, prompt: str) -> None:
    """Load an agent from *file*, execute with *prompt*, print result."""
    try:
        agent = _load_agent(file)
        result = agent.run(prompt)

        # Print result text to stdout (pipeable)
        click.echo(result.text)

        # Print trace summary to stderr
        click.echo(
            f"\n--- Trace: {result.tokens.total_tokens} tokens | "
            f"${result.cost:.4f} | {result.latency_ms:.0f}ms ---",
            err=True,
        )
    except SynthError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        click.echo(click.style(f"Suggestion: {exc.suggestion}", fg="yellow"), err=True)
        sys.exit(1)
    except Exception as exc:
        click.echo(click.style(f"Unexpected error: {exc}", fg="red"), err=True)
        click.echo("Run 'synth doctor' to check your environment.", err=True)
        sys.exit(1)



def _load_agent(file: str):
    """Import a Python file and return the ``agent`` variable.

    Prepends the agent file's parent directory to ``sys.path``
    so sibling imports resolve correctly.
    """
    from pathlib import Path

    path = Path(file)
    if not path.exists():
        click.echo(
            click.style(f"Cannot load '{file}': file not found.", fg="red"),
            err=True,
        )
        sys.exit(1)

    spec = importlib.util.spec_from_file_location("_agent_module", file)
    if spec is None or spec.loader is None:
        click.echo(click.style(f"Cannot load '{file}'.", fg="red"), err=True)
        sys.exit(1)

    module = importlib.util.module_from_spec(spec)

    # Add the agent file's directory to sys.path so local imports
    # (e.g. "from tools import ...") resolve correctly.
    agent_dir = str(Path(file).resolve().parent)
    if agent_dir not in sys.path:
        sys.path.insert(0, agent_dir)

    spec.loader.exec_module(module)

    if hasattr(module, "agent"):
        return module.agent

    # Multi-agent projects name the variable after the agent
    # (e.g. molly_miles = Agent(...)). Fall back to finding the
    # first Agent instance in the module.
    from synth.agent import Agent

    for attr_name in dir(module):
        obj = getattr(module, attr_name, None)
        if isinstance(obj, Agent):
            return obj

    click.echo(
        click.style(
            f"File '{file}' must define an 'agent' variable "
            f"(or an Agent instance).",
            fg="red",
        ),
        err=True,
    )
    sys.exit(1)


