"""Redis-backed checkpoint store.

Uses Redis hashes with transactions for atomic checkpoint persistence.
Requires the ``redis`` package (``pip install synth-agent-sdk[redis]``).

.. note::

   Unencrypted Redis connections are not recommended for production.
   Use TLS-enabled Redis endpoints for sensitive checkpoint data.
"""

from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from synth.checkpointing.base import BaseCheckpointStore
from synth.errors import SynthConfigError
from synth.types import Checkpoint


class RedisCheckpointStore(BaseCheckpointStore):
    """Redis-backed checkpoint store using hashes and transactions.

    Parameters
    ----------
    url:
        Redis connection URL (e.g. ``"redis://localhost:6379"``).
        TLS URLs (``rediss://``) are recommended for production.
    """

    def __init__(self, url: str) -> None:
        try:
            import redis.asyncio as aioredis
        except ImportError as exc:
            raise SynthConfigError(
                message=(
                    "Redis package is not installed. "
                    "Run: pip install redis"
                ),
                component="RedisCheckpointStore",
                suggestion="pip install redis",
            ) from exc

        self._client = aioredis.from_url(url)

    # ------------------------------------------------------------------
    # BaseCheckpointStore interface
    # ------------------------------------------------------------------

    async def save(self, checkpoint: Checkpoint) -> None:
        """Persist *checkpoint* to Redis using a hash with transaction."""
        key = f"synth:checkpoint:{checkpoint.run_id}"
        data = json.dumps({
            "run_id": checkpoint.run_id,
            "state": checkpoint.state,
            "step": checkpoint.step,
            "node_name": checkpoint.node_name,
            "timestamp": checkpoint.timestamp.isoformat(),
        }, default=str)

        # Use a pipeline (transaction) for atomicity
        async with self._client.pipeline(transaction=True) as pipe:
            pipe.hset(key, "latest", data)
            pipe.hset(key, f"step_{checkpoint.step}", data)
            await pipe.execute()

    async def load(self, run_id: str) -> Checkpoint | None:
        """Load the most recent checkpoint for *run_id* from Redis."""
        key = f"synth:checkpoint:{run_id}"
        raw = await self._client.hget(key, "latest")
        if raw is None:
            return None

        data = json.loads(raw)
        return Checkpoint(
            run_id=data["run_id"],
            state=data["state"],
            step=data["step"],
            node_name=data["node_name"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
        )

    async def delete(self, run_id: str) -> None:
        """Delete all checkpoints for *run_id* from Redis."""
        key = f"synth:checkpoint:{run_id}"
        await self._client.delete(key)
