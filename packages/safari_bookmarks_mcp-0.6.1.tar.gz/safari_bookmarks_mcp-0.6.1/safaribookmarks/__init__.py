from .safaribookmarks import SafariBookmarkItem, SafariBookmarks

open = SafariBookmarks.open

__all__ = ["SafariBookmarkItem", "SafariBookmarks", "open"]
