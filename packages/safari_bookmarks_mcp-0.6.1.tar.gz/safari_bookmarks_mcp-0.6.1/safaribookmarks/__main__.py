from .cli.main import main

main()
