from uv2compdb._version import __version__
from uv2compdb.cli import main

__all__ = ["__version__", "main"]
