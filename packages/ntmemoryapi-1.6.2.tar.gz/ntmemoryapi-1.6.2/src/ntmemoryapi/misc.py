# +-------------------------------------+
# |         ~ Author : Xenely ~         |
# +=====================================+
# | GitHub: https://github.com/Xenely14 |
# | Discord: xenely                     |
# +-------------------------------------+

import ctypes
import typing

# ==-------------------------------------------------------------------== #
# DLL functions                                                           #
# ==-------------------------------------------------------------------== #

# DLL libraries loading
_kernel32 = ctypes.windll.kernel32

# DLL libraries functions loading
_LoadLibraryA = _kernel32.LoadLibraryA
_GetProcAddress = _kernel32.GetProcAddress
_VirtualFree = _kernel32.VirtualFree
_VirtualAlloc = _kernel32.VirtualAlloc
_VirtualProtect = _kernel32.VirtualProtect

# Define of DLL libraries functions return type
_LoadLibraryA.restype = ctypes.c_void_p
_GetProcAddress.restype = ctypes.c_void_p
_VirtualFree.restype = ctypes.c_long
_VirtualAlloc.restype = ctypes.c_void_p
_VirtualProtect.restype = ctypes.c_long

# Define of DLL libraries functions argument types
_LoadLibraryA .argtypes = [ctypes.c_char_p]
_GetProcAddress.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
_VirtualFree.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong]
_VirtualAlloc.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong, ctypes.c_ulong]
_VirtualProtect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, ctypes.c_ulong, ctypes.POINTER(ctypes.c_ulong)]


# ==-------------------------------------------------------------------== #
# Classes                                                                 #
# ==-------------------------------------------------------------------== #
class DirectSyscallWrapper:
    """Class to create syscall wrappers to make syscall calls """

    # Table containing all syscall wrappers allocations
    registred_syscalls_table = dict()

    def __init__(self) -> None:
        """Creates wrapper instance to wrap syscalls."""

        # Create list of wrapped syscalls allocations and save it into syscall table to free memory on instance delete
        self.registred_syscalls_table[id(self)] = dict()

    def __del__(self) -> None:

        # Get all wrapper allocations addresses and deallocate them
        for address in self.registred_syscalls_table[id(self)].copy().values():
            _VirtualFree(address, 0, 0x8000)

        # Clean up syscall table
        del self.registred_syscalls_table[id(self)]

    def wrap(self, function_name: str, *, result_type: typing.Any, arguments_types: list[typing.Any], search_module: bytes = b"ntdll.dll") -> ctypes.WINFUNCTYPE:
        """Retrieves syscall ID by function name, wraps it into raw function buffer and casts to `WINFUNCTYPE` to make stealthy-callable."""

        # If syscall wrap already exists
        if (syscall_wrap := self.registred_syscalls_table[id(self)].get(function_name)) is not None:
            return syscall_wrap

        # Module loading
        if not (module_handle := _LoadLibraryA(search_module)):
            raise Exception("Unable to load module `%s`" % search_module.decode())

        # Retrieve function pointer
        if not (serach_function := _GetProcAddress(module_handle, function_name.encode())):
            raise Exception("Function `%s` not found" % function_name)

        # Syscall id
        syscall_id = None

        # Retrieve syscall ID from function pointer
        for index in range(0x16 + 1):

            # If syscall ID found
            if ctypes.cast(serach_function + index, ctypes.POINTER(ctypes.c_ubyte)).contents.value == 0xB8:

                syscall_id = ctypes.cast(serach_function + index + 1, ctypes.POINTER(ctypes.c_ushort)).contents.value
                break

        # If syscall ID not found
        if syscall_id is None:
            raise Exception("Syscall ID for function `%s` not found" % function_name)

        # Convert syscall ID to hex-bytes list
        syscall_id_bytes = [hex(item)[2:] if len(hex(item)[2:]) == 2 else "0" + hex(item)[2:] for item in bytes(ctypes.c_ushort(syscall_id))]

        # Create bytes buffer with syscall ID inlined
        # NOTE: `ntdll.dll` functions begins the same way, so it's just replica to behave the same.
        #
        # mov r10, rcx
        # mov eax, <syscall id>,
        # syscall
        # ret
        shellcode = bytes.fromhex("""
            4C 8B D1
            B8 %s %s 00 00
            0F 05
            C3
        """ % tuple([*syscall_id_bytes]))

        # Allocate buffer for function machine code
        if not (shellcode_buffer := _VirtualAlloc(0, len(shellcode), 0x1000 | 0x2000, 0x04)):
            raise Exception("Unable to alloate memory for shellcode")

        # Save allocated buffer into wrapped syscalls table
        self.registred_syscalls_table[id(self)][function_name] = shellcode_buffer

        # Copy shellcode into function machine code buffer
        ctypes.memmove(shellcode_buffer, ctypes.create_string_buffer(shellcode, len(shellcode)), len(shellcode))

        # Update of function machine code buffer memory protection to make it executable
        ctypes.windll.kernel32.VirtualProtect(shellcode_buffer, len(shellcode), 0x20, ctypes.byref(ctypes.c_ulong()))

        # Return wrapped syscall function
        return ctypes.cast(shellcode_buffer, ctypes.WINFUNCTYPE(result_type, *arguments_types))

    def clean_up(self, function_name: str) -> None:
        """Cleans up syscall wrapper, deallocates it's shellcode buffer."""

        # If function found
        if (address := self.registred_syscalls_table[id(self)].get(function_name)) is not None:

            # Deallocate syscall byffer
            _VirtualFree(address)

            # Clean up syscall table
            del self.registred_syscalls_table[id(self)][function_name]
