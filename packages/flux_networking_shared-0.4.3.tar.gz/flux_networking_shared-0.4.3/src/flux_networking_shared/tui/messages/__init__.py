"""Network TUI messages."""

from dataclasses import dataclass

from textual.message import Message


@dataclass
class FocusTabsRequested(Message):
    """Request focus on tabs container."""


@dataclass
class InterfaceSelected(Message):
    """An interface was selected for configuration."""

    interface_name: str


@dataclass
class ConnectivityUpdate(Message):
    """Network connectivity status update."""

    gateway: str
    reachable: bool
    latency_ms: float | None


@dataclass
class UPnPMappingChanged(Message):
    """UPnP port mapping was added or removed."""

    port: int
    action: str  # "added" or "removed"


__all__ = [
    "FocusTabsRequested",
    "InterfaceSelected",
    "ConnectivityUpdate",
    "UPnPMappingChanged",
]
