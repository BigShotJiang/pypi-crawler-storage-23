"""
命令行入口：

- sdev shell "cmd"：在串口设备上执行单条命令并回显输出。
"""

from __future__ import annotations

import argparse
import os
import sys

from .class_wrapper import Demoboard


def _get_default_port() -> str:
    return os.environ.get("SDEV_PORT", "/dev/ttyUSB0")


def _get_default_baudrate() -> int:
    try:
        return int(os.environ.get("SDEV_BAUDRATE", "115200"))
    except ValueError:
        return 115200


def cmd_shell(args: argparse.Namespace) -> int:
    port = args.port or _get_default_port()
    baudrate = args.baudrate or _get_default_baudrate()
    with Demoboard(port, baudrate, check_alive=not args.no_check_alive) as board:
        try:
            board.shell(args.command, prompt_flag=args.flag, timeout=args.timeout)
        except TimeoutError as e:
            print(e, file=sys.stderr)
            return 1
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(
        prog="sdev",
        description="串口开发板控制器：在串口设备上执行命令。",
    )
    parser.add_argument(
        "-p",
        "--port",
        default=None,
        help="串口路径（默认: SDEV_PORT 或 /dev/ttyUSB0）",
    )
    parser.add_argument(
        "-b",
        "--baudrate",
        type=int,
        default=None,
        help="波特率（默认: SDEV_BAUDRATE 或 115200）",
    )
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # sdev shell "cmd"
    shell_parser = subparsers.add_parser("shell", help="在板子上执行单条命令并回显输出")
    shell_parser.add_argument(
        "command",
        help='要执行的命令，如: ls 或 "lsmod | grep nnp"',
    )
    shell_parser.add_argument(
        "--flag",
        default=" #",
        help="提示符结束标志（默认: %(default)r）",
    )
    shell_parser.add_argument(
        "--timeout",
        type=float,
        default=None,
        help="等待命令输出的超时秒数",
    )
    shell_parser.add_argument(
        "--no-check-alive",
        action="store_true",
        help="connect 后不执行 check_alive",
    )
    shell_parser.set_defaults(func=cmd_shell)

    parsed = parser.parse_args()
    return parsed.func(parsed)


if __name__ == "__main__":
    sys.exit(main())
