"""
Relay 相关高层功能占位。

后续可在此添加继电器专用的串口操作方式。
"""

from __future__ import annotations


def not_implemented(*args, **kwargs):  # noqa: D401, ANN001, ANN002, ANN003
    """占位函数，后续实现继电器控制逻辑。"""
    raise NotImplementedError("Relay 功能尚未实现")


__all__ = ["not_implemented"]

