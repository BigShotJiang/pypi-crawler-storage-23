"""
Relay 顶层导出（占位）。
"""

from .functional import not_implemented

__all__ = ["not_implemented"]

