"""
Demoboard 相关的高层功能：

- shell(): clear + send + scan + display，执行一条命令并按提示符结束；
- check_alive(): 通过 Ctrl-C / uboot / reboot / 提示符 等 flag 检查板子是否存活。

注意：这里假设底层设备实现了 SerialDevice 接口：
- clear()
- send(cmd: str)
- scan(end_flag: Optional[str], timeout: Optional[float], replace_with_acc: bool)
- display(lines, flag: Optional[str], flag_type: Optional[str])
"""

from __future__ import annotations

import time
from itertools import chain
from typing import Generator, Iterable, List, Optional, Union
from loguru import logger

from ..core import CTRL_C, SerialDevice


def _scan_and_display(
    device: SerialDevice,
    end_flag: str,
    flag_type: str,
    timeout: Optional[float],
    replace_with_acc: bool,
) -> Generator[str, None, None]:
    """内部小工具：封装一段 scan + display，返回的是 scan 的原始行。"""
    lines = device.scan(end_flag=end_flag, timeout=timeout, replace_with_acc=replace_with_acc)
    for line in device.display(lines, flag=end_flag, flag_type=flag_type):  # pragma: no branch
        yield line


def shell(
    device: SerialDevice,
    cmd: str,
    prompt_flag: str = " #",
    timeout: Optional[float] = None,
    stream: bool = False,
    clear: bool = True,
) -> Union[List[str], Generator[str, None, None]]:
    """
    在 demoboard 上执行一条命令：
    - clear: 清理残留输出，避免错位；
    - send: 发送命令；
    - 第一阶段：scan(cmd) + display(prompt 高亮)，直到命令回显完整出现；
    - 第二阶段：scan(prompt_flag) + display(end_flag 高亮)，直到提示符行出现。

    返回的是 scan 的原始行（设备输出的原始内容），不是 display 的显示结果：
    - stream=False：返回这些原始行的 list（两阶段全部合并）；
    - stream=True：返回 yielding 原始行的 generator，不预先把结果拉成 list。
    """
    if clear:
        device.clear()

    # 第一段：把「命令本身的回显」当作 prompt 高亮
    part1 = []
    if cmd is not None:
        # 营造类似 Python 交互式的结构：空一行，另起一行打印 > 符号
        device._ensure_newline()
        device._write_raw(f"\n\033[33m>\033[0m ")  # 黄色的 > 符号
        device.send(cmd)
        part1 = _scan_and_display(
            device,
            end_flag=cmd,
            flag_type="prompt",
            timeout=timeout,
            replace_with_acc=True,
        )

    # 第二段：直到提示符
    part2 = _scan_and_display(
        device,
        end_flag=prompt_flag,
        flag_type="end_flag",
        timeout=timeout,
        replace_with_acc=False,
    )
    merged = (line for line in chain(part1, part2))

    if stream:
        # 按要求返回「原始 generator」
        return merged
    return list(merged)

def check_alive(
    device: SerialDevice,
    uboot_flag: str = "uboot#",
    prompt_flag: str = " #",
    timeout: float = 2.0,
) -> None:
    """
    检查 demoboard 是否「醒着」且有 shell 提示符。

    语义（鲁棒性逻辑）：
    1. 乐观探测 (Fast Path)：如果已经在提示符状态或串口静默，直接探测以节省时间。
    2. 标准流程：检查 timeout 内是否有输出；如果有，循环等待直到没有输出；
    3. 输入 CTRL-C 并检查输出：
       - 如果包含 uboot_flag，输入 'reboot' 并递归调用 check_alive；
       - 否则，检查是否包含 prompt_flag。如果不包含，提示并抛出错误；
    4. 如果一切正常，视为 check 成功。
    """

    # 1. 乐观探测 (Fast Path)
    try:
        # 极短采样 (0.3s)
        sample = list(shell(device, None, prompt_flag=None, timeout=0.3, clear=False))
        sample_out = "".join(sample)

        # 场景 A: 已经在提示符处
        if prompt_flag in sample_out:
            if uboot_flag in sample_out:
                device.warning(f"Found uboot flag '{uboot_flag}', sending 'reboot' and re-checking...")
                device.send("reboot")
                return check_alive(device, uboot_flag, prompt_flag, timeout)
            return

        # 场景 B: 串口当前没动静，尝试主动探测
        if not sample_out:
            device.send(CTRL_C)
            # 探测回显 (0.5s)
            probe = list(shell(device, None, prompt_flag=None, timeout=0.5, clear=False))
            probe_out = "".join(probe)
            if prompt_flag in probe_out:
                if uboot_flag in probe_out:
                    device.warning(f"Found uboot flag '{uboot_flag}', sending 'reboot' and re-checking...")
                    device.send("reboot")
                    return check_alive(device, uboot_flag, prompt_flag, timeout)
                return
    except Exception as e:
        logger.debug(f"Optimistic probe encountered error: {e}")

    # 2. 标准流程：检查并等待输出停止
    while True:
        try:
            # shell(device, None, ...) 不发送命令，仅执行 scan(None) 直到 silence timeout。
            lines = list(shell(device, None, prompt_flag=None, timeout=timeout, clear=False))
            if not lines:
                break
            device.warning("Detecting serial output, waiting for it to stop...")
        except (TimeoutError, Exception) as e:
            logger.debug(f"Stop-output loop encountered error: {e}")
            break

    # 3. 发送 CTRL-C 并获取输出
    device.send(CTRL_C)
    lines = list(shell(device, None, prompt_flag=None, timeout=timeout, clear=False))
    output = "".join(lines)

    # 4. 如果输出包含 uboot_flag，输入 reboot 并返回递归的 check_alive
    if uboot_flag in output:
        device.warning(f"Found uboot flag '{uboot_flag}', sending 'reboot' and re-checking...")
        device.send("reboot")
        return check_alive(device, uboot_flag, prompt_flag, timeout)

    # 5. 检查 prompt_flag
    if prompt_flag not in output:
        msg = f"Prompt flag '{prompt_flag}' not found in output. Serial port might not be connected or device is unresponsive. Please check."
        device.error(msg)
        raise RuntimeError(msg)

    # 6. 成功
    device.success("Check alive passed.")


if __name__ == "__main__":
    # 简单测试：demoboard shell 功能
    import os

    port = os.environ.get("SDEV_PORT", "/dev/ttyUSB0")
    with SerialDevice(port) as board:
        check_alive(board)
        shell(board, "cat /proc/meminfo")

