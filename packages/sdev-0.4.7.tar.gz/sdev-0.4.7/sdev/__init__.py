"""
SDEV - 串口控制器工具包

- SerialDevice：底层串口基础类（连接、后台异步读、send/scan/display/clear）；
- Demoboard / Relay：面向对象封装；
- sdev() 工厂方法：快速构建设备实例；
- sdev.demoboard：Demoboard 相关函数式 API（shell, check_alive）。
"""

from __future__ import annotations

from typing import Literal

from .core import SerialDevice
from .class_wrapper import Demoboard, Relay

__version__ = "0.4.7"
__author__ = "klrc"
__email__ = "1440698245@qq.com"


def sdev(
    port: str,
    baudrate: int = 115200,
    *,
    device_type: Literal["demoboard", "relay"] = "demoboard",
    **kwargs,
):
    """
    构造一个设备实例。

    默认返回 Demoboard，后续可根据需要扩展其它类型。
    """
    if device_type == "demoboard":
        return Demoboard(port, baudrate, **kwargs)
    if device_type == "relay":
        return Relay(port, baudrate, **kwargs)
    raise ValueError(f"unsupported device_type: {device_type!r}")


__all__ = ["SerialDevice", "Demoboard", "Relay", "sdev"]
