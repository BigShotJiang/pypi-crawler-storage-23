"""Utility modules for Snaffler Linux"""
