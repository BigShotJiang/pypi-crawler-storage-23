# SPDX-License-Identifier: MIT
# Copyright (c) 2025 OmniNode Team
"""Infisical handler configuration models.

.. versionadded:: 0.9.0
    Initial implementation for OMN-2286.
"""

from omnibase_infra.handlers.models.infisical.model_infisical_handler_config import (
    ModelInfisicalHandlerConfig,
)

__all__: list[str] = ["ModelInfisicalHandlerConfig"]
