"""Axon — Graph-powered code intelligence engine."""

__version__ = "0.2.1"
