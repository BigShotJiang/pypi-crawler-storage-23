from blends.models import (
    NId,
)
from blends.stack.node_helpers import (
    root_node_attributes,
)
from blends.stack.policies.registry import (
    get_export_policy,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def bound_identifier_symbol(args: SyntaxGraphArgs, *, var_id: NId) -> str | None:
    var_node = args.ast_graph.nodes.get(var_id, {})
    if var_node.get("label_type") != "identifier":
        return None
    symbol = node_to_str(args.ast_graph, var_id)
    return symbol if symbol else None


def get_next_binding_precedence(args: SyntaxGraphArgs) -> int:
    scope_stack = args.metadata.get("scope_stack", [])
    if not scope_stack:
        return 0
    return 1


def is_definition_exported(args: SyntaxGraphArgs) -> bool:
    policy = get_export_policy(args.language)
    scope_stack = args.metadata.get("scope_stack", [])
    parent_scope = scope_stack[-1] if scope_stack else None
    return policy.is_definition_exported(args.syntax_graph, args.n_id, parent_scope)


def get_next_synthetic_node_id(args: SyntaxGraphArgs) -> NId:
    current_id = args.metadata.get("next_synthetic_id")
    if current_id is None:
        msg = "next_synthetic_id not initialized in metadata"
        raise ValueError(msg)
    args.metadata["next_synthetic_id"] = current_id + 1
    return str(current_id)


def get_or_create_root_nid(args: SyntaxGraphArgs) -> NId:
    existing = args.metadata.get("root_nid")
    if existing is not None:
        return existing
    root_nid = get_next_synthetic_node_id(args)
    args.syntax_graph.add_node(root_nid, **root_node_attributes())
    args.metadata["root_nid"] = root_nid
    return root_nid
