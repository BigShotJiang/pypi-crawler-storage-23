from __future__ import annotations

from typing import TYPE_CHECKING

from blends.stack.policies.base import ExportPolicy
from blends.stack.scope_types import ScopeType

if TYPE_CHECKING:
    from blends.models import Graph, NId


class JavaExportPolicy(ExportPolicy):
    def is_scope_exported(
        self,
        graph: Graph,
        node_id: NId,
        scope_type: str | None,
    ) -> bool:
        if scope_type == ScopeType.FILE.value:
            return True
        if scope_type == ScopeType.CLASS.value:
            return self.get_visibility_modifier(graph, node_id) == "public"
        return False

    def is_definition_exported(
        self,
        graph: Graph,
        node_id: NId,
        parent_scope_id: NId | None,
    ) -> bool:
        visibility = self.get_visibility_modifier(graph, node_id)
        if visibility != "public":
            return False
        if parent_scope_id is None:
            return True
        parent_is_exported = graph.nodes[parent_scope_id].get("stack_graph_is_exported", False)
        return bool(parent_is_exported)
