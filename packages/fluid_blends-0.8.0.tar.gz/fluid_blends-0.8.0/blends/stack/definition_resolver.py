from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from blends.stack.forward_stitcher import ForwardStitcherConfig

if TYPE_CHECKING:
    from blends.models import Graph, NId
from blends.stack.partial_path import (
    PartialPathDatabase,
    PartialPathFileRecord,
    PartialPathIndexRequest,
    PartialPathLimits,
    index_partial_paths_for_file,
)
from blends.stack.single_file_resolver import (
    SingleFileResolutionRequest,
    resolve_definitions_single_file,
)
from blends.stack.view import StackGraphView

_FILE_HANDLE: int = 1
_MAX_INDEX_WORK: int = 50_000
_MAX_QUERY_PHASES: int = 100
_MAX_QUERY_WORK: int = 10_000


@dataclass(frozen=True, slots=True)
class DefinitionResolver:
    view: StackGraphView
    record: PartialPathFileRecord | None

    @classmethod
    def from_syntax_graph(cls, graph: Graph, file_path: str) -> DefinitionResolver:
        view = StackGraphView.from_syntax_graph(graph, path=file_path)
        database = PartialPathDatabase()
        index_partial_paths_for_file(
            graph,
            request=PartialPathIndexRequest(
                file_path=file_path,
                file_handle=_FILE_HANDLE,
                limits=PartialPathLimits(max_work_per_phase=_MAX_INDEX_WORK),
            ),
            database=database,
        )
        return cls(view=view, record=database.get_file(_FILE_HANDLE))

    def resolve(self, ref_n_id: NId) -> NId | None:
        if self.record is None:
            return None

        ref_index = self.view.nid_to_index.get(ref_n_id)
        if ref_index is None:
            return None

        if not self.view.node_is_reference[ref_index]:
            return None

        raw = resolve_definitions_single_file(
            self.view,
            request=SingleFileResolutionRequest(
                file_handle=_FILE_HANDLE,
                record=self.record,
                ref_node_index=ref_index,
                config=ForwardStitcherConfig(
                    max_phases=_MAX_QUERY_PHASES,
                    max_work_per_phase=_MAX_QUERY_WORK,
                ),
            ),
        )

        definition_indices = raw if isinstance(raw, list) else raw[0]
        if not definition_indices:
            return None

        return self.view.index_to_nid[definition_indices[0]]
