from setuptools import setup

with open("README_vachana_g2p.md","r",encoding="utf-8") as f:
    description = f.read()

setup(
    name='vachana-g2p',
    version='0.0.1',
    packages=["vachana_g2p"],
    package_data={
        'vachana_g2p': ['data/*'],
    },
    include_package_data=True,
    install_requires=[
        "pythainlp",
    ],
    description="Vachana G2P: ระบบแปลงข้อความภาษาไทยเป็นเสียงอ่านสากล (Thai to IPA)",
    long_description=description,
    long_description_content_type="text/markdown",
)

# python setup_vachana_g2p.py sdist bdist_wheel
# $env:TWINE_USERNAME="__token__"
# $env:TWINE_PASSWORD="pypi-AgEIcHlwaS5vcmcCJDI4Nzk2NGIwLWU1ZjUtNDcwNC1iNmY3LWE0OWE2MTQ2ODBmZAACKlszLCI3OWExYTdmYS1lOTI5LTQzMzAtYjYxNS02ZDY4MzE0ODdhYTYiXQAABiAyRh7gfiM0c-X92kJO-olO6iBDIeRgDP7PQ0fK_7wZrA"
# twine upload dist/*