"""recursive-pietro: SHAP-based recursive feature elimination with early stopping."""

from recursive_pietro._elimination import ShapFeatureElimination

__all__ = ["ShapFeatureElimination"]
__version__ = "0.1.0"
