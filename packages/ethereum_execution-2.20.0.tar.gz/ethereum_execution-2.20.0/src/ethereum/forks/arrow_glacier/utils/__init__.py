"""
Utility functions unique to this particular fork.
"""
