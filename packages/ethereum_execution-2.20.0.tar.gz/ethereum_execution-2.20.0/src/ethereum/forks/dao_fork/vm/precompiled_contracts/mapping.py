"""
Precompiled Contract Addresses.

.. contents:: Table of Contents
    :backlinks: none
    :local:

Introduction
------------

Mapping of precompiled contracts to their implementations.
"""

from typing import Callable, Dict

from ...fork_types import Address
from . import (
    ECRECOVER_ADDRESS,
    IDENTITY_ADDRESS,
    RIPEMD160_ADDRESS,
    SHA256_ADDRESS,
)
from .ecrecover import ecrecover
from .identity import identity
from .ripemd160 import ripemd160
from .sha256 import sha256

PRE_COMPILED_CONTRACTS: Dict[Address, Callable] = {
    ECRECOVER_ADDRESS: ecrecover,
    SHA256_ADDRESS: sha256,
    RIPEMD160_ADDRESS: ripemd160,
    IDENTITY_ADDRESS: identity,
}
