"""
Cryptographic primitives used in Ethereum.
"""
