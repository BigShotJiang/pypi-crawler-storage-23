from __future__ import absolute_import, division, print_function

__version__ = "0.5.2"
dependencies = ["apscheduler==3.11.0",
                "pyserial==3.5"]
