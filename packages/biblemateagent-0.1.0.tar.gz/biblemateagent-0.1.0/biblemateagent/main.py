import asyncio, argparse
from biblemateagent.agent import ai_agent_headless

parser = argparse.ArgumentParser(description = f"""BibleMate AI Agent""")
parser.add_argument("default", nargs="*", default=None, help="user query")
parser.add_argument("-l", "--language", action="store", dest="language", help="language option; `eng` by defatul; set this option to `tc` or `sc` to override")
parser.add_argument("-t", "--token", action="store", dest="token", help=f"custom token to get acccess to custom data")
parser.add_argument("-u", "--url", action="store", dest="url", help=f"custom token to get acccess to custom data")
args = parser.parse_args()

async def main_async():
    print("Starting BibleMate AI Agent...")
    await ai_agent_headless(q=" ".join(args.default))
    print("Finished")

def main():
    asyncio.run(main_async())

if __name__ == "__main__":
    main()
