# Search Gallery SHACL Review

- Generated: 2026-02-26 13:06:50Z
- Changed SHACL pages: 34
- Broadly changed pages (>=80 diff lines): 5
- Fixture pages in manifest: 38

## Broadly Changed Pages

| Page | Diff (+/-) | Sample Conformance (old -> new) | Status |
|---|---:|---:|---|
| book | +60 / -711 | 1/6 -> 1/6 | neutral |
| local-business | +1 / -358 | 4/4 -> 4/4 | neutral |
| shipping-policy | +75 / -108 | 1/2 -> 1/2 | neutral |
| vacation-rental | +1 / -157 | 1/2 -> 1/2 | neutral |
| return-policy | +132 / -3 | 3/3 -> 3/3 | neutral |

## All Changed Pages

| Page | Diff (+/-) | Has Fixtures | Sample Conformance (old -> new) | Status |
|---|---:|---|---:|---|
| book | +60 / -711 | yes | 1/6 -> 1/6 | neutral |
| local-business | +1 / -358 | yes | 4/4 -> 4/4 | neutral |
| shipping-policy | +75 / -108 | yes | 1/2 -> 1/2 | neutral |
| vacation-rental | +1 / -157 | yes | 1/2 -> 1/2 | neutral |
| return-policy | +132 / -3 | yes | 3/3 -> 3/3 | neutral |
| job-posting | +1 / -56 | yes | 3/4 -> 3/4 | neutral |
| image-license-metadata | +3 / -40 | yes | 1/4 -> 4/4 | improved |
| education-qa | +1 / -13 | yes | 1/2 -> 2/2 | improved |
| merchant-listing | +9 / -1 | yes | 2/13 -> 2/13 | neutral |
| course | +4 / -4 | yes | 2/3 -> 2/3 | neutral |
| paywalled-content | +1 / -7 | yes | 2/2 -> 2/2 | neutral |
| recipe | +4 / -4 | yes | 2/3 -> 2/3 | neutral |
| article | +1 / -1 | yes | 2/2 -> 2/2 | neutral |
| breadcrumb | +1 / -1 | yes | 2/4 -> 2/4 | neutral |
| carousel | +1 / -1 | yes | 4/6 -> 4/6 | neutral |
| carousels-beta | +1 / -1 | yes | 6/6 -> 6/6 | neutral |
| dataset | +1 / -1 | yes | 1/3 -> 1/3 | neutral |
| discussion-forum | +1 / -1 | yes | 2/4 -> 2/4 | neutral |
| employer-rating | +1 / -1 | yes | 1/3 -> 1/3 | neutral |
| event | +1 / -1 | yes | 4/9 -> 4/9 | neutral |
| factcheck | +1 / -1 | yes | 3/3 -> 3/3 | neutral |
| faqpage | +1 / -1 | yes | 2/2 -> 2/2 | neutral |
| loyalty-program | +1 / -1 | yes | 2/2 -> 2/2 | neutral |
| math-solvers | +1 / -1 | yes | 1/3 -> 1/3 | neutral |
| movie | +1 / -1 | yes | 3/3 -> 3/3 | neutral |
| organization | +1 / -1 | yes | 3/3 -> 3/3 | neutral |
| product-snippet | +1 / -1 | yes | 5/6 -> 5/6 | neutral |
| product-variants | +1 / -1 | yes | 7/7 -> 7/7 | neutral |
| profile-page | +1 / -1 | yes | 3/3 -> 3/3 | neutral |
| qapage | +1 / -1 | yes | 1/2 -> 1/2 | neutral |
| review-snippet | +1 / -1 | yes | 5/7 -> 5/7 | neutral |
| software-app | +1 / -1 | yes | 1/2 -> 1/2 | neutral |
| speakable | +1 / -1 | yes | 2/2 -> 2/2 | neutral |
| video | +1 / -1 | yes | 3/8 -> 3/8 | neutral |
