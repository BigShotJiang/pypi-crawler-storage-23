#!/usr/bin/env python3
"""
Demo: Supply Chain Network Optimization

A realistic supply chain problem with:
- Multiple warehouses
- Multiple products
- Demand satisfaction
- Capacity constraints
- Transportation costs
"""

import numpy as np
import gurobipy as gp
from gurobipy import GRB

from src.agent.general import GurobiAgent, AgentConfig


def create_supply_chain_model(
    n_warehouses: int = 15,
    n_customers: int = 200,
    n_products: int = 50,
) -> gp.Model:
    """Create a multi-product supply chain optimization model."""

    print(f"Creating supply chain model...")
    print(f"  Warehouses: {n_warehouses}")
    print(f"  Customers: {n_customers}")
    print(f"  Products: {n_products}")

    np.random.seed(42)

    # Costs
    transport_cost = np.random.uniform(1, 20, (n_warehouses, n_customers))
    holding_cost = np.random.uniform(0.5, 5, (n_warehouses, n_products))

    # Capacities and demands
    warehouse_capacity = np.random.randint(500, 2000, n_warehouses)
    product_volume = np.random.uniform(0.5, 3, n_products)
    demand = np.random.randint(5, 30, (n_customers, n_products))

    # Initial inventory
    initial_inventory = np.random.randint(50, 200, (n_warehouses, n_products))

    model = gp.Model("supply_chain")

    # Variables: ship[w,c,p] = units of product p shipped from warehouse w to customer c
    ship = {}
    for w in range(n_warehouses):
        for c in range(n_customers):
            for p in range(n_products):
                ship[w, c, p] = model.addVar(
                    lb=0,
                    ub=demand[c, p],  # Can't ship more than demanded
                    name=f"ship_{w}_{c}_{p}"
                )

    # Variables: inventory[w,p] = final inventory at warehouse
    inventory = {}
    for w in range(n_warehouses):
        for p in range(n_products):
            inventory[w, p] = model.addVar(lb=0, name=f"inv_{w}_{p}")

    # Demand satisfaction: each customer gets what they need
    for c in range(n_customers):
        for p in range(n_products):
            model.addConstr(
                gp.quicksum(ship[w, c, p] for w in range(n_warehouses)) >= demand[c, p],
                name=f"demand_{c}_{p}"
            )

    # Inventory balance: initial - shipped = final
    for w in range(n_warehouses):
        for p in range(n_products):
            model.addConstr(
                inventory[w, p] == initial_inventory[w, p] -
                gp.quicksum(ship[w, c, p] for c in range(n_customers)),
                name=f"balance_{w}_{p}"
            )

    # Warehouse capacity (volume-based)
    for w in range(n_warehouses):
        model.addConstr(
            gp.quicksum(inventory[w, p] * product_volume[p] for p in range(n_products))
            <= warehouse_capacity[w],
            name=f"capacity_{w}"
        )

    # Objective: minimize transport + holding costs
    model.setObjective(
        gp.quicksum(
            transport_cost[w, c] * ship[w, c, p]
            for w in range(n_warehouses)
            for c in range(n_customers)
            for p in range(n_products)
        ) +
        gp.quicksum(
            holding_cost[w, p] * inventory[w, p]
            for w in range(n_warehouses)
            for p in range(n_products)
        ),
        GRB.MINIMIZE
    )

    model.update()
    print(f"  Variables: {model.NumVars:,}")
    print(f"  Constraints: {model.NumConstrs:,}")

    return model


# === MAIN ===

print("=" * 60)
print("SUPPLY CHAIN OPTIMIZATION DEMO")
print("=" * 60)
print()

# Create model
model = create_supply_chain_model(
    n_warehouses=15,
    n_customers=200,
    n_products=50,
)

print()

# Run agent
config = AgentConfig(
    max_improvements_to_test=10,
    full_test_time_limit=60.0,
    verbose=True,
)

agent = GurobiAgent(config=config)
result = agent.improve(model)

# Summary
print()
print("=" * 60)
print("FINAL RESULT")
print("=" * 60)
print(f"Best: {result.best_improvement} ({result.best_speedup:+.1f}%)")
print(f"Baseline: {result.baseline_runtime:.3f}s")
if result.best_params:
    print(f"Params to use: {result.best_params}")
