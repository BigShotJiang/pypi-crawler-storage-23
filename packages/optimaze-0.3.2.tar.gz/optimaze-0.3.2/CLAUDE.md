# Optimaze Agent - Development Guidelines

## Project Context

Optimaze is an AI-powered Gurobi optimization agent that helps users improve their solver performance. The product must be **100% EULA compliant** - meaning:

1. **No gurobipy on the server** - Gurobi's license prohibits redistribution and service bureau use
2. **Customer runs Gurobi locally** with their own license
3. **Cloud only analyzes logs and commits code** - never runs the solver

## Critical Lesson Learned: Preserve ALL Intelligence When Refactoring

### What Happened

When refactoring the agent from a gurobipy-dependent architecture to an EULA-compliant cloud service, I initially **lost critical intelligence**:

1. **Incomplete prompt porting**: The original `LLMAdvisor` had a 786-line system prompt with detailed examples for 7 improvement categories. I initially wrote a simplified 50-line prompt that lacked the depth.

2. **Missing RuleBasedDecision rules**: The original system had 13 specific rules mapping bottlenecks to fixes:
   - `coeff_range > 1e6` → big_m, rescale, constraint_tightening
   - `node_count > 10,000` → symmetry_breaking, valid_inequalities, branching_priorities
   - `mip_gap > 10%` → constraint_tightening, valid_inequalities, warm_starting
   - etc.

   I initially only included 7 high-level mappings, losing precision.

3. **Missing analyzers**: The original had 8 specialized analyzers (CoeffRangeAnalyzer, NodeCountAnalyzer, etc.) that parsed specific metrics from logs. I initially had a simplified `_interpret_log_metrics()` that missed some metrics.

4. **System prompt not passed to Claude**: The API call initially didn't include the `system=system_prompt` parameter, so all that intelligence wasn't being used.

### Why This Happened

1. **Rushed refactoring**: When removing gurobipy dependencies, I focused on "making it work" rather than "making it equivalent"
2. **Not reading all source files**: I should have systematically compared every component
3. **Assuming Claude would figure it out**: The prompt needs to be explicit about decision rules

### The Right Approach

When refactoring to stay within license constraints:

1. **Audit every component** of the original system before starting
2. **Create a checklist** of all functionality that must be preserved
3. **Port intelligence, not just structure** - the rules, examples, and decision logic are the product
4. **Test equivalence** - run both systems on the same input and compare outputs
5. **Never assume** - if the original had a specific rule, there was a reason for it

## Architecture Guidelines

### What Uses Gurobipy (MUST run on customer's machine)

- Loading/running optimization models
- Reading model structure (variables, constraints)
- Setting solver parameters
- Executing `model.optimize()`
- Capturing solver logs

### What Doesn't Need Gurobipy (CAN run on cloud)

- Parsing Gurobi log files (regex)
- Analyzing model code (AST/string matching)
- Generating code improvements (Claude)
- GitHub operations (clone, commit, PR)
- Decision logic (which improvement to try)

### The New Architecture

```
Customer Machine (has Gurobi license):
  └── optimaze CLI
      ├── Runs their model script
      ├── Captures solver logs
      └── Sends logs + code to cloud

Cloud API (NO gurobipy):
  ├── Parses logs for metrics
  ├── Analyzes code with Claude
  ├── Applies RuleBasedDecision rules
  ├── Generates code improvements
  └── Commits to GitHub
```

## Intelligence Checklist

When modifying the Claude prompt or analysis code, ensure these are preserved:

### Improvement Categories (7)
- [ ] Big-M Tightening
- [ ] Symmetry Breaking
- [ ] Valid Inequalities
- [ ] Branching Priorities
- [ ] Warm Starting
- [ ] Lazy Constraints
- [ ] Solver Parameters

### Bottleneck Rules (13)
- [ ] coeff_range > 1e6 → big_m, rescale, constraint_tightening
- [ ] coeff_range 1e4-1e6 → rescale, constraint_tightening
- [ ] variable_count > 10,000 → new_variables
- [ ] constraint_count > 5,000 → benders, lazy_constraints
- [ ] node_count > 10,000 → symmetry_breaking, valid_inequalities, branching_priorities
- [ ] node_count 1,000-10,000 → branching_priorities, valid_inequalities
- [ ] node_count < 100 but runtime > 10s → new_variables, rescale (root LP bottleneck)
- [ ] mip_gap > 10% → constraint_tightening, valid_inequalities, warm_starting
- [ ] mip_gap 5-10% → constraint_tightening, warm_starting
- [ ] has_symmetry → symmetry_breaking, branching_priorities
- [ ] binary_ratio > 50% → symmetry_breaking
- [ ] density > 0.2 → new_variables, lazy_constraints
- [ ] density 0.1-0.2 → lazy_constraints

### Log Metrics to Parse
- [ ] Node count
- [ ] MIP gap
- [ ] Runtime
- [ ] Model size (vars, constraints)
- [ ] Binary variable count
- [ ] Coefficient range
- [ ] Matrix density (nonzeros)
- [ ] Presolve statistics

## Quality vs. Compliance

The challenge is maintaining **maximum product quality** while staying **100% within license terms**. This is not a trade-off - we must achieve BOTH:

1. **Quality comes from intelligence** - the rules, examples, and decision logic
2. **Compliance comes from architecture** - where code runs and what it imports

The original system's intelligence was encoded in:
- `LLMAdvisor` system prompt (786 lines)
- `RuleBasedDecision` rules (13 rules)
- `ImprovementCatalog` (20+ improvements)
- `ImprovementMatcher` (15+ matching rules)

ALL of this intelligence can be preserved in the cloud - it's just text and logic. The only thing that must move to the customer's machine is the actual Gurobi execution.

## Never Do This Again

- [ ] Never claim a refactor is "complete" without auditing every source file
- [ ] Never port just the structure - port the intelligence
- [ ] Never assume Claude will "figure out" what was in the original rules
- [ ] Never sacrifice quality for expediency - take the time to do it right
- [ ] Never forget that the RULES ARE THE PRODUCT, not the code structure
