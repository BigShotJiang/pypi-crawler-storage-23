#!/usr/bin/env python3
"""
Simple demo of the General Gurobi Improvement Agent.

Usage:
    python demo.py
"""

import numpy as np
import gurobipy as gp
from gurobipy import GRB

from src.agent.general import GurobiAgent


def create_sample_model():
    """Create a sample optimization model."""
    print("Creating sample model...")

    # Simple facility location problem
    n_facilities = 20
    n_customers = 100

    np.random.seed(42)

    # Random costs
    fixed_costs = np.random.randint(100, 500, n_facilities)
    transport_costs = np.random.randint(1, 50, (n_facilities, n_customers))

    model = gp.Model("facility_location")

    # Binary: is facility i open?
    y = [model.addVar(vtype=GRB.BINARY, name=f"open_{i}") for i in range(n_facilities)]

    # Binary: does facility i serve customer j?
    x = {}
    for i in range(n_facilities):
        for j in range(n_customers):
            x[i, j] = model.addVar(vtype=GRB.BINARY, name=f"serve_{i}_{j}")

    # Each customer must be served by exactly one facility
    for j in range(n_customers):
        model.addConstr(
            gp.quicksum(x[i, j] for i in range(n_facilities)) == 1,
            name=f"demand_{j}"
        )

    # Can only serve from open facilities
    for i in range(n_facilities):
        for j in range(n_customers):
            model.addConstr(x[i, j] <= y[i], name=f"link_{i}_{j}")

    # Minimize total cost
    model.setObjective(
        gp.quicksum(fixed_costs[i] * y[i] for i in range(n_facilities)) +
        gp.quicksum(transport_costs[i, j] * x[i, j]
                    for i in range(n_facilities) for j in range(n_customers)),
        GRB.MINIMIZE
    )

    model.update()
    return model


if __name__ == "__main__":
    # === MAIN DEMO ===

    # Create a model (or load from file: model = gp.read("model.mps"))
    model = create_sample_model()

    # Create agent and improve
    agent = GurobiAgent()
    result = agent.improve(model)

    # Print result
    print(f"\nBest: {result.best_improvement} ({result.best_speedup:+.1f}%)")

