"""
Gurobi Agent API - Session-based optimization service.

NO GUROBIPY HERE - we only analyze logs and commit code to repos.
Customer runs Gurobi locally with their own license.

Endpoints:
    POST /sessions - Create optimization session, create branch
    POST /sessions/{id}/logs - Submit logs, get next action
    POST /sessions/{id}/complete - Finalize session
    GET /health - Health check
"""

import difflib
import json
import os
import re
import uuid
from datetime import datetime
from typing import Optional

import anthropic
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from github import Github
from pydantic import BaseModel

try:
    from supabase import Client, create_client
except ImportError:
    Client = None  # type: ignore[assignment,misc]
    create_client = None  # type: ignore[assignment]

from server.api.agent.general.analysis import (
    AnalysisResult,
    CoeffRangeAnalyzer,
    ConstraintCountAnalyzer,
    DensityAnalyzer,
    MIPGapAnalyzer,
    NodeCountAnalyzer,
    SlowRootLPAnalyzer,
    SymmetryAnalyzer,
    VariableCountAnalyzer,
)
from server.api.agent.general.types import ProblemProfile

app = FastAPI(
    title="Optimizer Agent API",
    description="AI-powered optimization - analyzes logs, commits improvements",
    version="2.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# Configuration
# ============================================================================

# GitHub App credentials (set via environment variables)
GITHUB_APP_ID = os.environ.get("GITHUB_APP_ID")
GITHUB_PRIVATE_KEY = os.environ.get("GITHUB_PRIVATE_KEY", "").replace("\\n", "\n")

# Supabase (server-side debug logging)
SUPABASE_URL = os.environ.get("SUPABASE_URL")
SUPABASE_KEY = os.environ.get("SUPABASE_SERVICE_KEY")


def _supabase():
    """Return a Supabase client if configured, else None."""
    if create_client and SUPABASE_URL and SUPABASE_KEY:
        return create_client(SUPABASE_URL, SUPABASE_KEY)
    return None


# Simple in-memory license validation (replace with Supabase later)
VALID_KEYS = {
    "test-key-123": {"customer": "Test User", "tier": "pro"},
    "demo-key": {"customer": "Demo", "tier": "free"},
}

# In-memory session storage (replace with Redis/DB later)
SESSIONS: dict[str, dict] = {}


# ============================================================================
# Models
# ============================================================================


class CreateSessionRequest(BaseModel):
    repo_url: str  # e.g., "https://github.com/acme/their-model"
    entry_file: str  # e.g., "model.py"
    log_file: str = "gurobi.log"  # Where Gurobi writes logs


class CreateSessionResponse(BaseModel):
    session_id: str
    branch: str
    working_repo_url: str  # Repo where the branch lives (may be a fork)
    status: str
    pr_url: Optional[str] = None  # PR on the original repo


class SubmitLogsRequest(BaseModel):
    logs: str  # Gurobi log file contents
    runtime: float  # Solve time in seconds
    iteration: int = 0
    status: str = "success"       # "success" | "error" | "timeout"
    error: Optional[str] = None   # stderr snippet when status != "success"


class SubmitLogsResponse(BaseModel):
    action: str  # "pull", "done", or "retry"
    branch: Optional[str] = None
    commit: Optional[str] = None
    message: Optional[str] = None
    improvement: Optional[str] = None  # Description/reasoning for the change


class CompleteSessionRequest(BaseModel):
    results: list[dict]  # List of {commit, runtime} from each iteration


class CompleteSessionResponse(BaseModel):
    best_commit: Optional[str] = None
    baseline_runtime: float
    best_runtime: float
    speedup: float
    recommendations: list[str]
    pr_url: Optional[str] = None


# ============================================================================
# Helper Functions
# ============================================================================


def validate_license(key: str) -> bool:
    """Validate a license key."""
    return key in VALID_KEYS


def _github_instance() -> Github:
    """Return an authenticated Github instance."""
    token = os.environ.get("GITHUB_TOKEN")
    if not token:
        raise HTTPException(500, "GitHub token not configured")
    return Github(token)


def get_github_client(repo_url: str):
    """Get authenticated GitHub client for a repo."""
    g = _github_instance()
    parts = repo_url.rstrip("/").split("/")
    repo_name = f"{parts[-2]}/{parts[-1]}"
    return g.get_repo(repo_name)


# ============================================================================
# Analysis and Decision Pipeline
# ============================================================================

_ANALYZERS: list = [
    CoeffRangeAnalyzer(),
    VariableCountAnalyzer(),
    ConstraintCountAnalyzer(),
    NodeCountAnalyzer(),
    MIPGapAnalyzer(),
    SymmetryAnalyzer(),
    SlowRootLPAnalyzer(),
    DensityAnalyzer(),
]


def parse_log_to_profile(logs: str) -> ProblemProfile:
    """
    Parse a Gurobi log into a ProblemProfile with all log-extractable fields.
    Fields not available from the log remain at their dataclass defaults.
    """
    profile = ProblemProfile()

    # Node count
    nodes_match = re.search(r"Explored (\d+) nodes", logs)
    if nodes_match:
        profile.log_nodes = int(nodes_match.group(1))

    # MIP gap
    gap_match = re.search(r"gap ([\d.]+)%", logs)
    if gap_match:
        profile.log_gap = float(gap_match.group(1))

    # Runtime
    runtime_match = re.search(r"in ([\d.]+) seconds", logs)
    if runtime_match:
        profile.log_runtime = float(runtime_match.group(1))

    # Model size
    vars_match = re.search(r"(\d+) columns", logs)
    if vars_match:
        profile.n_vars = int(vars_match.group(1))

    constrs_match = re.search(r"(\d+) rows", logs)
    if constrs_match:
        profile.n_constrs = int(constrs_match.group(1))

    binary_match = re.search(r"(\d+) binaries", logs)
    if binary_match:
        profile.n_binary = int(binary_match.group(1))
        profile.n_continuous = max(0, profile.n_vars - profile.n_binary)

    # Nonzeros → density and average fill
    nonzeros_match = re.search(r"(\d+) nonzeros", logs)
    if nonzeros_match:
        profile.n_nonzeros = int(nonzeros_match.group(1))
        if profile.n_vars > 0 and profile.n_constrs > 0:
            profile.density = profile.n_nonzeros / (profile.n_vars * profile.n_constrs)
            profile.avg_vars_per_constr = profile.n_nonzeros / profile.n_constrs
            profile.avg_constrs_per_var = profile.n_nonzeros / profile.n_vars

    # Coefficient range — matches both "Matrix range [...]" (stats section)
    # and "coefficient range [...]" (Gurobi warning message)
    coef_match = re.search(
        r"(?:matrix|coefficient) range\s+\[([\d.e+-]+),\s*([\d.e+-]+)\]",
        logs,
        re.IGNORECASE,
    )
    if coef_match:
        try:
            profile.coef_min = float(coef_match.group(1))
            profile.coef_max = float(coef_match.group(2))
            profile.coef_range_ratio = profile.coef_max / max(profile.coef_min, 1e-10)
        except (ValueError, ZeroDivisionError):
            pass

    # Presolve stats
    presolve_match = re.search(r"Presolve removed (\d+) rows and (\d+) columns", logs)
    if presolve_match:
        profile.log_presolve_removed_rows = int(presolve_match.group(1))
        profile.log_presolve_removed_cols = int(presolve_match.group(2))

    # Symmetry: heuristic from Gurobi log messages
    if re.search(r"\bsymmetry\b", logs, re.IGNORECASE):
        profile.has_symmetry = True

    return profile


def run_analysis_pipeline(logs: str) -> list[AnalysisResult]:
    """
    Run all 8 analyzers on log data and return their results.
    Solver-agnostic: operates purely on log metrics (nodes, gap, density, etc.).
    """
    profile = parse_log_to_profile(logs)
    return [analyzer.analyze(logs, profile) for analyzer in _ANALYZERS]


def _interpret_log_metrics(logs: str) -> str:
    """
    Run analyzers on the log and format their findings as bottleneck context for Claude.
    """
    insights = []
    for result in run_analysis_pipeline(logs):
        if result.is_problem:
            insights.append(result.context)

    if not insights:
        insights.append(
            "No obvious bottlenecks detected from log — model may already be well-formulated. "
            "Focus on the most impactful structural changes if any are apparent from the code."
        )

    return "\n".join(f"- {i}" for i in insights)


def analyze_logs_with_claude(
    logs: str, iteration: int, history: list[dict], model_code: str = ""
) -> dict:
    """
    Use Claude to analyze Gurobi logs AND model code to suggest intelligent improvements.
    This replicates the original agent's intelligence without running gurobipy.

    Port of the full LLMAdvisor system prompt and intelligence.
    """
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return analyze_logs_fallback(iteration)

    client = anthropic.Anthropic(api_key=api_key)

    # Build history context
    history_text = ""
    if history:
        history_text = "\n\n## PREVIOUS ATTEMPTS (don't repeat these):\n"
        for h in history:
            status = "KEPT" if h.get("speedup", 0) > 0 else "reverted"
            history_text += f"- {h.get('fix_name', 'unknown')}: {h.get('speedup', 0):+.1f}% ({status})\n"

    # Truncate logs and code to fit context
    logs_truncated = logs[:12000] if len(logs) > 12000 else logs
    code_truncated = model_code[:8000] if len(model_code) > 8000 else model_code

    # Parse log metrics for profile interpretation
    bottleneck_analysis = _interpret_log_metrics(logs_truncated)

    # Full LLMAdvisor-equivalent system prompt
    system_prompt = """\
You are an expert Operations Research engineer specializing in Gurobi optimization.
Your task is to analyze Gurobi model source code and suggest formulation-level code improvements that will reduce solve time while preserving solution correctness.

# Improvement Categories with Examples

## 1. Big-M Tightening
Replace overly large M values with problem-specific tight bounds.

BAD:
```python
model.addConstr(x[i] <= 100000 * y[i])  # M = 100000 is way too large
```
GOOD:
```python
model.addConstr(x[i] <= demand[i] * y[i])  # M = demand[i] is the tightest valid bound
```
Why: Tight big-M values dramatically strengthen the LP relaxation. Loose big-M creates a huge gap between the LP bound and the integer optimum, causing excessive branching.

## 2. Symmetry Breaking
Add ordering constraints on interchangeable (symmetric) variables.

BAD:
```python
# Facilities f1, f2, f3 are identical — solver wastes time exploring permutations
y = model.addVars(n_facilities, vtype=GRB.BINARY, name="open")
```
GOOD:
```python
y = model.addVars(n_facilities, vtype=GRB.BINARY, name="open")
# Break symmetry: if facilities are identical, force lexicographic ordering
for i in range(n_facilities - 1):
    model.addConstr(y[i] >= y[i+1], name=f"sym_break_{i}")
```
Why: Symmetric variables cause the B&B tree to have many equivalent nodes. Ordering constraints prune symmetric subtrees without cutting off any optimal solution.

## 3. Valid Inequalities
Add constraints that tighten the LP relaxation without cutting off integer solutions.

Example — cover inequality for knapsack:
```python
# If items {1,2,3} together exceed capacity, at most 2 can be selected
model.addConstr(x[1] + x[2] + x[3] <= 2, name="cover_cut")
```

Example — clique constraint from conflict structure:
```python
# If jobs i,j,k conflict (can't run simultaneously), add clique cut
model.addConstr(y[i] + y[j] + y[k] <= 1, name="clique_cut")
```
Why: Valid inequalities tighten the LP relaxation, reducing the gap and the B&B tree size.

## 4. Branching Priorities
Tell Gurobi to branch on the most important variables first.

```python
# Set high priority on facility opening decisions (drive the structure)
for i in range(n_facilities):
    y[i].BranchPriority = 10
# Assignment variables get default priority (0)
```
Why: Good branching order can cut node count by 50%+ by resolving key decisions early.

## 5. Warm Starting
Provide a feasible starting solution from a greedy heuristic.

```python
# Greedy: open the cheapest facilities until demand is met
opened = greedy_solution(costs, demands)
for i in range(n_facilities):
    y[i].Start = 1.0 if i in opened else 0.0
```
Why: A good MIP start gives Gurobi an upper bound immediately, enabling aggressive pruning.

## 6. Lazy Constraints
Convert rarely-binding constraints to lazy constraints.

```python
# Subtour elimination constraints: most won't be active in optimal solution
model.addConstr(gp.quicksum(x[i,j] for i,j in edges_in_S) <= len(S) - 1,
                name=f"subtour_{S}", lazy=1)
```
Why: Lazy constraints are only checked when an integer solution is found, reducing LP size.

## 7. Solver Parameters
Tune Gurobi parameters based on problem characteristics.

```python
# For models with many binary variables and high node count
model.setParam('MIPFocus', 1)  # Focus on feasibility
model.setParam('Cuts', 2)      # Aggressive cuts
model.setParam('Heuristics', 0.2)  # More heuristic effort
model.setParam('Symmetry', 2)  # Aggressive symmetry detection
```

# Bottleneck → Action Mapping (Rule-Based Decision Engine)

Use these rules IN ORDER to select the best fix. Higher severity problems get priority:

## Coefficient Range (HIGHEST PRIORITY)
- coeff_range > 1e6: big-M tightening, rescale, constraint tightening
- coeff_range 1e4-1e6: rescale, constraint tightening

## Model Scale
- variable_count > 10,000: new variable formulations
- constraint_count > 5,000: Benders decomposition, lazy constraints

## Branch-and-Bound Performance
- node_count > 10,000: symmetry breaking, valid inequalities, branching priorities, solver params
- node_count 1,000-10,000: branching priorities, valid inequalities, solver params
- node_count < 100 but runtime > 10s: root LP is bottleneck → rescale, new variables, solver params

## MIP Gap
- mip_gap > 10%: constraint tightening, valid inequalities, warm starting
- mip_gap 5-10%: constraint tightening, warm starting

## Symmetry
- Detected symmetry groups: symmetry breaking, branching priorities
- High binary ratio (>50%) without detected symmetry: try symmetry breaking

## Matrix Density
- density > 0.2: new variable formulations, lazy constraints
- density 0.1-0.2: lazy constraints

## Solver Parameters (always available as fallback)
- MIPFocus: 0=balanced, 1=feasibility, 2=optimality, 3=bound
- Presolve: 0=off, 1=conservative, 2=aggressive
- Cuts: 0=off, 1=auto, 2=aggressive
- Heuristics: 0.0-1.0 (fraction of time on heuristics)
- Symmetry: 0=off, 1=auto, 2=aggressive
- Method: 0=primal, 1=dual, 2=barrier
- Threads: 0=auto, 1-N for specific count

# General Guidelines
- Suggest ONLY changes that preserve the mathematical correctness of the model
- Each suggestion must be precise code that can be inserted before model.optimize()
- Prefer small, targeted changes over large rewrites
- Focus on changes with the highest expected speedup based on the bottleneck analysis
- If the model is already well-formulated, say done
"""

    prompt = f"""## MODEL CODE:
```python
{code_truncated if code_truncated else "(not available - analyze log only)"}
```

## GUROBI SOLVER LOG:
```
{logs_truncated}
```

## BOTTLENECK ANALYSIS:
{bottleneck_analysis}
{history_text}

## YOUR TASK:
Analyze the model and log above. Suggest ONE improvement that addresses the biggest bottleneck.

IMPORTANT: Be AGGRESSIVE, not conservative!
- Iteration 0: Add model.setParam('LogFile', 'gurobi.log') with MIPFocus
- Iterations 1-2: Try CODE TRANSFORMATIONS first (symmetry breaking, valid inequalities, branching priorities) - these give the biggest speedups!
- Iterations 3+: Try solver parameters if transformations didn't help

The original system achieved 85% speedups by trying bold transformations. Simple parameter tuning rarely exceeds 10%.

RULES:
- {"First iteration: add LogFile and one parameter" if iteration == 0 else f"Iteration {iteration}: PREFER code transformations over parameters. Try symmetry_breaking, valid_inequalities, or branching_priorities!"}
- Don't repeat previous attempts (check history)
- For code transformations, generate complete Python code to insert before optimize()
- Be bold - we will REVERT if it doesn't help

## RESPONSE FORMAT (JSON only, no markdown fences):
If you have an improvement:
{{"code": "model.setParam('X', Y)", "message": "Short commit message", "category": "parameter|transformation", "explanation": "1-2 sentence explanation of WHY this helps (shown in PR)"}}

If no more improvements will help:
{{"done": true, "message": "Model appears well-optimized"}}
"""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=2000,
            system=system_prompt,
            messages=[{"role": "user", "content": prompt}],
        )

        text = response.content[0].text.strip()

        # Extract JSON from response
        if "```json" in text:
            text = text.split("```json")[1].split("```")[0]
        elif "```" in text:
            text = text.split("```")[1].split("```")[0]

        result = json.loads(text)

        if result.get("done"):
            return None

        return {
            "type": result.get("category", "parameter"),
            "code": result.get("code", ""),
            "message": result.get("message", "AI-suggested improvement"),
            "explanation": result.get("explanation", ""),
        }

    except Exception as e:
        import traceback

        print(f"Claude API error: {e}")
        print(f"Traceback: {traceback.format_exc()}")
        print(f"Falling back to simple heuristics for iteration {iteration}")
        return analyze_logs_fallback(iteration)


def analyze_logs_fallback(iteration: int) -> dict:
    """Fallback to simple heuristics if Claude API fails."""
    improvements = [
        {
            "code": "model.setParam('LogFile', 'gurobi.log')\n    model.setParam('MIPFocus', 1)",
            "message": "Enable logging and MIPFocus=1",
        },
        {
            "code": "model.setParam('Presolve', 2)",
            "message": "Enable aggressive presolve",
        },
        {
            "code": "model.setParam('Cuts', 2)",
            "message": "Enable aggressive cuts",
        },
        {
            "code": "model.setParam('Heuristics', 0.1)",
            "message": "Increase heuristic effort",
        },
    ]

    if iteration < len(improvements):
        return {"type": "parameter", **improvements[iteration]}
    return None


def analyze_logs(
    logs: str, iteration: int, history: list[dict] = None, model_code: str = ""
) -> dict:
    """Main entry point for log analysis."""
    return analyze_logs_with_claude(logs, iteration, history or [], model_code)


# ============================================================================
# New: AST-based Scanner (from llm_advisor.py / scanner.py)
# ============================================================================


def scan_code_for_call_site(source_code: str, filename: str = "model.py") -> dict:
    """
    Extract call site info via AST (no gurobipy needed).
    Finds model variable names, optimize() locations, and indentation.
    """
    import ast

    tree = ast.parse(source_code, filename=filename)

    # Find gurobipy imports
    aliases = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for a in node.names:
                if a.name == "gurobipy":
                    aliases.append(
                        {"style": "import_as", "alias": a.asname or "gurobipy"}
                    )
        elif isinstance(node, ast.ImportFrom) and node.module == "gurobipy":
            names = [a.name for a in node.names]
            aliases.append(
                {"style": "from_import", "alias": node.names[0].name, "names": names}
            )

    # Find Model() assignments
    model_vars = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign) and isinstance(node.value, ast.Call):
            call = node.value
            if isinstance(call.func, ast.Attribute) and call.func.attr == "Model":
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        model_vars.append(target.id)
            elif isinstance(call.func, ast.Name) and call.func.id == "Model":
                for target in node.targets:
                    if isinstance(target, ast.Name):
                        model_vars.append(target.id)

    # Find optimize() calls
    call_sites = []
    lines = source_code.splitlines()
    for node in ast.walk(tree):
        if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call):
            call = node.value
            if isinstance(call.func, ast.Attribute) and call.func.attr == "optimize":
                if isinstance(call.func.value, ast.Name):
                    var_name = call.func.value.id
                    if var_name in model_vars or not model_vars:
                        line_text = (
                            lines[node.lineno - 1] if node.lineno <= len(lines) else ""
                        )
                        indent = line_text[: len(line_text) - len(line_text.lstrip())]
                        call_sites.append(
                            {
                                "model_var": var_name,
                                "line": node.lineno,
                                "indent": indent,
                            }
                        )

    return {
        "gurobi_alias": aliases[0]["alias"] if aliases else "gp",
        "import_style": aliases[0]["style"] if aliases else "import_as",
        "model_var": model_vars[0] if model_vars else "model",
        "call_sites": call_sites,
    }


# ============================================================================
# New: Tool Schema (from llm_advisor.py:161-250)
# ============================================================================

SUGGEST_IMPROVEMENT_TOOL = {
    "name": "suggest_improvement",
    "description": "Suggest a code improvement with precise old_code/new_code anchors",
    "input_schema": {
        "type": "object",
        "properties": {
            "name": {
                "type": "string",
                "description": "Short identifier for this improvement e.g., 'symmetry_break_facilities'",
            },
            "changes": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "old_code": {
                            "type": "string",
                            "description": "EXACT substring from the source to find and replace",
                        },
                        "new_code": {
                            "type": "string",
                            "description": "Replacement code",
                        },
                    },
                    "required": ["old_code", "new_code"],
                },
                "description": "List of code changes to apply",
            },
            "reasoning": {
                "type": "string",
                "description": "Why this change improves solver performance",
            },
            "preserves_semantics": {
                "type": "boolean",
                "description": "True if the change preserves mathematical correctness",
            },
        },
        "required": ["name", "changes", "reasoning", "preserves_semantics"],
    },
}

IMPROVEMENT_SYSTEM_PROMPT = """\
You are an expert optimization engineer. Your task is to suggest code improvements \
that reduce solver runtime while preserving mathematical correctness.

You work solver-agnostically: look at the model code and the detected bottlenecks, \
then suggest the most impactful change based on what you actually see in the code.

Common improvement types to consider:
- Tighten large coefficient values (big-M) with problem-specific bounds
- Add symmetry-breaking constraints for interchangeable variables
- Add valid inequalities that strengthen the LP relaxation
- Set branching hints on key structural variables
- Provide a warm-start (initial feasible solution)
- Mark rarely-active constraints as lazy
- Reformulate variables or constraints to reduce density
- Tune solver parameters based on the detected problem structure

CRITICAL RULES FOR old_code ANCHORS:
- old_code must be an EXACT substring from the provided source (copy-paste, preserve indentation)
- Include enough surrounding context to make the anchor unique
- preserves_semantics must be true — never change the mathematical meaning
- If no further improvement is worth making, do NOT call the tool

CRITICAL: Avoid common runtime errors when modifying Gurobi models:
- Variable indexing must match exactly (e.g., t[i,k] not t[i])
- Never reference variables, sets, or dicts not already in the code
- Preserve existing loop structure and index sets
- When tightening Big-M, derive bounds from data already defined in the code
- If a previous attempt CRASHED, read the error and avoid the same mistake\
"""


# ============================================================================
# New: Validation (from llm_advisor.py:534-563)
# ============================================================================


def validate_improvement(improvement: dict, source_code: str) -> tuple[bool, str]:
    """
    Validate anchors exist and modified code parses.
    Returns (is_valid, error_message).
    """
    import ast

    changes = improvement.get("changes", [])
    if not changes:
        return False, "No changes in suggestion"

    working_copy = source_code
    for i, change in enumerate(changes):
        old_code = change.get("old_code", "")
        new_code = change.get("new_code", "")

        if not old_code:
            return False, f"Change #{i+1} has empty old_code"

        if old_code not in working_copy:
            # Try to find similar code for helpful error message
            snippet = old_code[:60].replace("\n", "\\n")
            return False, f"Anchor #{i+1} not found in source: '{snippet}...'"

        working_copy = working_copy.replace(old_code, new_code, 1)

    try:
        ast.parse(working_copy)
    except SyntaxError as e:
        return False, f"Syntax error after applying changes: {e.msg} (line {e.lineno})"

    return True, ""


def apply_code_changes(source_code: str, changes: list[dict]) -> str:
    """
    Apply a list of old_code -> new_code changes to source.
    IMPORTANT: Preserves indentation by detecting the indent of old_code
    and applying it to ALL lines of new_code.
    """
    result = source_code
    for change in changes:
        old_code = change.get("old_code", "")
        new_code = change.get("new_code", "")

        if not old_code or old_code not in result:
            continue

        # Find the indentation of the line containing old_code
        idx = result.find(old_code)
        line_start = result.rfind("\n", 0, idx) + 1  # Start of the line
        leading_text = result[line_start:idx]

        # Detect indentation (spaces/tabs before old_code on this line)
        indent = ""
        if leading_text.strip() == "":
            # old_code starts at beginning of line (after whitespace)
            indent = leading_text
        else:
            # old_code is in middle of line - find line's base indent
            full_line_start = (
                result.rfind("\n", 0, line_start) + 1 if line_start > 0 else 0
            )
            full_line = result[full_line_start : line_start + len(leading_text)]
            indent = full_line[: len(full_line) - len(full_line.lstrip())]

        # Apply indentation to ALL lines of new_code (except first line keeps old_code's position)
        new_code_lines = new_code.split("\n")
        if len(new_code_lines) > 1:
            # First line replaces old_code in-place
            # Subsequent lines need the detected indentation
            indented_lines = [new_code_lines[0]]
            for line in new_code_lines[1:]:
                if line.strip():  # Non-empty line
                    indented_lines.append(indent + line)
                else:
                    indented_lines.append(line)  # Keep empty lines as-is
            new_code = "\n".join(indented_lines)

        result = result.replace(old_code, new_code, 1)

    return result


# ============================================================================
# New: Retry Logic (from llm_advisor.py:565-642)
# ============================================================================


def retry_with_feedback(
    client,
    failed_improvement: dict,
    error: str,
    source_code: str,
    system_prompt: str,
    focus_category: str,
    debug_trace: dict | None = None,
) -> dict | None:
    """Retry failed suggestion with targeted error feedback."""

    old_code_snippet = "N/A"
    if failed_improvement.get("changes"):
        old_code_snippet = failed_improvement["changes"][0].get("old_code", "N/A")

    error_prompt = f"""Your previous suggestion failed validation.

Error: {error}

Your old_code was:
```
{old_code_snippet}
```

Here is the ACTUAL source code. Find an EXACT substring to use as old_code:
```python
{source_code}
```

Fix the old_code anchor to be an exact substring of the source.
Use the suggest_improvement tool to resubmit your {focus_category} improvement.
"""

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            system=system_prompt,
            tools=[SUGGEST_IMPROVEMENT_TOOL],
            messages=[{"role": "user", "content": error_prompt}],
        )

        # Parse and validate retry
        for block in response.content:
            if block.type == "tool_use" and block.name == "suggest_improvement":
                retry_improvement = block.input
                valid, new_error = validate_improvement(retry_improvement, source_code)
                if debug_trace is not None:
                    debug_trace["retry_tool_call"] = retry_improvement
                if valid:
                    return retry_improvement
                else:
                    print(f"Retry also failed validation: {new_error}")

        return None
    except Exception as e:
        print(f"Retry with feedback failed: {e}")
        return None


def smart_truncate_code(source: str, call_site_info: dict, max_chars: int = 20000) -> str:
    """
    Truncate source code for Claude, prioritizing the model-building section.

    Strategy:
    1. If source fits within max_chars, return it as-is.
    2. Find key landmarks: gurobipy import, Model() creation, optimize() call.
    3. Extract the model-building section (import to optimize).
    4. If still too long, skip docstrings and data-loading functions at the top.
    """
    if len(source) <= max_chars:
        return source

    lines = source.splitlines()

    # Find key landmarks
    model_start = None
    optimize_end = None
    gurobipy_line = None

    for i, line in enumerate(lines):
        stripped = line.strip()
        # Find first gurobipy reference
        if gurobipy_line is None and ('gurobipy' in stripped or 'import gurobipy' in stripped):
            gurobipy_line = i
        # Find first Model() creation
        if model_start is None and ('Model(' in stripped or '.Model(' in stripped):
            model_start = i
        # Find optimize() call (take the last one if multiple)
        if '.optimize(' in stripped or '.optimize()' in stripped:
            optimize_end = i

    # Also check call_site_info for optimize() line
    call_sites = call_site_info.get("call_sites", [])
    if call_sites:
        # call_sites[].line is 1-indexed
        last_call_line = max(cs.get("line", 0) for cs in call_sites)
        if last_call_line > 0:
            optimize_end = max(optimize_end or 0, last_call_line - 1)  # convert to 0-indexed

    # Determine the section to keep
    # Start from gurobipy import or Model() creation, whichever comes first
    section_start = None
    if gurobipy_line is not None:
        section_start = max(0, gurobipy_line - 2)  # a few lines of context before
    if model_start is not None:
        if section_start is None:
            section_start = max(0, model_start - 5)
        else:
            section_start = min(section_start, max(0, model_start - 5))

    if section_start is None:
        section_start = 0

    # End at optimize() + some context for post-solve code
    if optimize_end is not None:
        section_end = min(len(lines), optimize_end + 10)
    else:
        section_end = len(lines)

    # Extract the model section
    model_section = '\n'.join(lines[section_start:section_end])

    if len(model_section) <= max_chars:
        # If there's room, prepend the file header (imports, etc.)
        header = '\n'.join(lines[:section_start])
        if len(header) + len(model_section) + 20 <= max_chars:
            return header + '\n\n' + model_section
        # Add a note about truncation
        return f"# ... (lines 1-{section_start} truncated: data loading / utilities) ...\n\n" + model_section

    # Model section itself is too long — trim from the start, keeping constraints + optimize
    # Find constraint-adding code (addConstr, addConstrs, setObjective, etc.)
    constraint_start = None
    for i in range(section_start, section_end):
        stripped = lines[i].strip()
        if any(kw in stripped for kw in ['addConstr', 'addConstrs', 'setObjective', 'addVar', 'addVars', 'addMVar']):
            if constraint_start is None:
                constraint_start = max(section_start, i - 5)
            break

    if constraint_start is not None and constraint_start > section_start:
        trimmed = '\n'.join(lines[constraint_start:section_end])
        if len(trimmed) <= max_chars:
            return f"# ... (lines 1-{constraint_start} truncated: imports / data loading) ...\n\n" + trimmed

    # Last resort: take the last max_chars characters (which includes optimize())
    result = '\n'.join(lines[section_start:section_end])
    if len(result) > max_chars:
        result = f"# ... (truncated to last {max_chars} chars, including model + optimize) ...\n\n" + result[-max_chars:]

    return result


def suggest_next_improvement(
    logs: str,
    model_code: str,
    analysis_results: list[AnalysisResult],
    call_site_info: dict,
    history: list[dict],
    baseline_runtime: float | None = None,
    debug_trace: dict | None = None,
) -> dict | None:
    """
    Ask Claude to suggest the next best code improvement.

    Solver-agnostic: Claude sees the model code and analyzer findings, then decides
    what change to make without being constrained to predefined solver-specific categories.

    Returns None if Claude decides no further improvement is worth making.
    """
    if debug_trace is None:
        debug_trace = {}

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return None

    client = anthropic.Anthropic(api_key=api_key)

    # Format detected problems, sorted by severity
    problems = sorted(
        (r for r in analysis_results if r.is_problem),
        key=lambda r: -r.severity,
    )
    if problems:
        analysis_text = "\n".join(
            f"- [{r.analyzer_name}, severity={r.severity:.1f}] {r.context}"
            for r in problems
        )
    else:
        analysis_text = (
            "- No specific bottlenecks detected from solver log metrics. However, analyze the MODEL CODE "
            "for formulation-level opportunities: Big-M constants that can be tightened, symmetric variables "
            "that need symmetry-breaking constraints, missing valid inequalities, branching priorities, "
            "warm starting, or lazy constraints."
        )

    # Capture bottleneck text for debug logging
    debug_trace["bottleneck_text"] = analysis_text

    # Format attempt history for Claude
    non_baseline = [h for h in history if h.get("status") != "baseline"]
    history_text = ""
    if non_baseline:
        history_text = "\n\n## PREVIOUS ATTEMPTS (do not repeat these):\n"
        for h in non_baseline:
            if h.get("status") == "CRASHED":
                error_info = h.get("explanation", "unknown error")
                history_text += f"- `{h.get('fix_name', 'unknown')}`: CRASHED (runtime error: {error_info})\n"
            elif h.get("status") == "KEPT":
                history_text += f"- `{h.get('fix_name', 'unknown')}`: {h.get('speedup', 0):+.1f}% (KEPT)\n"
            else:
                history_text += f"- `{h.get('fix_name', 'unknown')}`: {h.get('speedup', 0):+.1f}% (reverted, no improvement)\n"

    model_var = call_site_info.get("model_var", "model")

    # Smart truncation: prioritize model-building code over data loading
    truncated_code = smart_truncate_code(model_code, call_site_info, max_chars=20000)

    # Build runtime context
    runtime_text = ""
    if baseline_runtime is not None:
        runtime_text = f"\n## RUNTIME: {baseline_runtime:.1f}s\nThis model takes {baseline_runtime:.0f} seconds to solve — there is significant room for improvement.\n"

    # Determine task instruction based on iteration
    is_first_improvement = not non_baseline
    if is_first_improvement:
        if baseline_runtime:
            task_instruction = (
                f"Suggest ONE code change that addresses the most impactful bottleneck. "
                f"This model takes {baseline_runtime:.0f}s to solve — there is always room to improve. "
                f"You MUST call the suggest_improvement tool with your best improvement."
            )
        else:
            task_instruction = (
                "Suggest ONE code change that addresses the most impactful bottleneck. "
                "You MUST call the suggest_improvement tool with your best improvement."
            )
    else:
        task_instruction = (
            "Suggest ONE code change that addresses the most impactful remaining bottleneck. "
            "If no further improvement is worth trying, do NOT call the tool."
        )

    user_prompt = f"""## MODEL CODE:
```python
{truncated_code}
```
{runtime_text}
## DETECTED BOTTLENECKS (from log analysis):
{analysis_text}{history_text}

## SOLVER LOG:
```
{logs[:8000]}
```

## TASK:
{task_instruction}
Use model variable `{model_var}` (copy-paste from the code — don't assume "model").
The `old_code` must be an EXACT substring from the source above (preserve indentation)."""

    debug_trace["claude_user_prompt"] = user_prompt

    try:
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4000,
            system=IMPROVEMENT_SYSTEM_PROMPT,
            tools=[SUGGEST_IMPROVEMENT_TOOL],
            messages=[{"role": "user", "content": user_prompt}],
        )

        # Capture raw response
        debug_trace["claude_response_raw"] = "".join(
            block.text if block.type == "text" else json.dumps(block.input)
            for block in response.content
        )

        for block in response.content:
            if block.type == "tool_use" and block.name == "suggest_improvement":
                improvement = block.input
                debug_trace["claude_tool_call"] = improvement
                valid, error = validate_improvement(improvement, model_code)
                debug_trace["validation_valid"] = valid
                debug_trace["validation_error"] = error if not valid else None
                if valid:
                    return improvement

                print(f"Suggestion failed validation: {error}")
                debug_trace["retry_occurred"] = True
                retry = retry_with_feedback(
                    client,
                    improvement,
                    error,
                    model_code,
                    IMPROVEMENT_SYSTEM_PROMPT,
                    improvement.get("name", "improvement"),
                    debug_trace=debug_trace,
                )
                return retry  # None if retry also failed

        # Claude didn't call the tool — no more improvements to make
        print("[suggest_next_improvement] No tool call — done")
        return None

    except Exception as e:
        print(f"Error in suggest_next_improvement: {e}")
        return None


# ============================================================================
# New: Commit Revert Function (Step 9)
# ============================================================================


def commit_revert(
    repo, branch: str, entry_file: str, original_code: str, fix_name: str
) -> str:
    """Revert to previous code and commit."""
    file_content = repo.get_contents(entry_file, ref=branch)

    result = repo.update_file(
        entry_file,
        f"Revert: {fix_name} (no improvement)",
        original_code,
        file_content.sha,
        branch=branch,
    )

    return result["commit"].sha


def commit_improvement(repo, branch: str, entry_file: str, improvement: dict) -> str:
    """
    Commit an improvement to the repo.
    Returns the commit SHA.
    """
    # Get current file content
    try:
        file_content = repo.get_contents(entry_file, ref=branch)
        current_content = file_content.decoded_content.decode("utf-8")
    except Exception as e:
        raise HTTPException(500, f"Could not read {entry_file}: {e}")

    # Find where to insert the parameter
    # Look for model.optimize() and insert before it
    lines = current_content.split("\n")
    new_lines = []
    inserted = False

    for line in lines:
        if not inserted and "optimize()" in line.lower():
            # Insert parameter setting before optimize()
            indent = len(line) - len(line.lstrip())
            new_lines.append(" " * indent + f"# Gurobi Agent: {improvement['message']}")
            # Handle multi-line code: indent EVERY line
            code_lines = improvement["code"].split("\n")
            for code_line in code_lines:
                new_lines.append(" " * indent + code_line)
            inserted = True
        new_lines.append(line)

    if not inserted:
        # Fallback: add at the top after imports
        for i, line in enumerate(lines):
            if line.startswith("import") or line.startswith("from"):
                continue
            if line.strip() == "":
                continue
            # Insert here - handle multi-line code
            code_lines = improvement["code"].split("\n")
            new_lines = (
                lines[:i]
                + [f"# Gurobi Agent: {improvement['message']}"]
                + code_lines
                + [""]
                + lines[i:]
            )
            break

    new_content = "\n".join(new_lines) if inserted else "\n".join(new_lines)

    # Commit the change
    commit_message = f"Gurobi Agent: {improvement['message']}"
    result = repo.update_file(
        entry_file, commit_message, new_content, file_content.sha, branch=branch
    )

    return result["commit"].sha


# ============================================================================
# Endpoints
# ============================================================================


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "ok", "version": "2.1.0", "gurobipy": False}


@app.get("/debug/claude")
async def debug_claude():
    """Test if Claude API is working."""
    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return {"status": "error", "message": "ANTHROPIC_API_KEY not set"}

    try:
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=100,
            messages=[
                {
                    "role": "user",
                    "content": "Say 'Claude is working!' in exactly those words.",
                }
            ],
        )
        return {
            "status": "ok",
            "claude_response": response.content[0].text,
            "api_key_prefix": api_key[:20] + "...",
        }
    except Exception as e:
        return {"status": "error", "message": str(e)}


@app.post("/sessions", response_model=CreateSessionResponse)
async def create_session(
    request: CreateSessionRequest,
    license_key: str = Header(..., alias="X-License-Key"),
):
    """
    Create a new optimization session.
    Clones the repo and creates a branch for improvements.
    """
    if not validate_license(license_key):
        raise HTTPException(401, "Invalid license key")

    # Generate session ID
    session_id = f"sess_{uuid.uuid4().hex[:12]}"
    branch = f"agent/optimize-{session_id}"

    try:
        _github_instance()  # Validate GitHub token is configured
        working_repo = get_github_client(request.repo_url)

        # If the provided repo is a fork, create the PR on the parent (original) repo
        # so it's visible to the original owner. Otherwise, PR stays on the same repo.
        if working_repo.fork and working_repo.parent:
            original_repo = working_repo.parent
            pr_head = f"{working_repo.owner.login}:{branch}"
        else:
            original_repo = working_repo
            pr_head = branch

        original_default_branch = original_repo.default_branch

        # Create the branch on the working repo (where we have write access)
        source = working_repo.get_branch(working_repo.default_branch)
        working_repo.create_git_ref(f"refs/heads/{branch}", source.commit.sha)
        print(f"[Session {session_id}] Branch created on {working_repo.full_name}")

        # Make an initial commit so GitHub allows PR creation
        working_repo.create_file(
            ".optimaze",
            f"Optimaze: Start optimization session {session_id}",
            f"session: {session_id}\nstarted: {datetime.utcnow().isoformat()}\nfile: {request.entry_file}\n",
            branch=branch,
        )

        # Create PR on the original repo (visible to the owner)
        pr = original_repo.create_pull(
            title=f"Optimaze: optimizing {request.entry_file}",
            body=f"🤖 Optimaze is analyzing and improving `{request.entry_file}`.\n\nImprovement commits will appear here as the agent runs.\n\n_This PR will be updated with final results when the session completes._",
            head=pr_head,
            base=original_default_branch,
        )
        pr_url = pr.html_url
        pr_number = pr.number
        print(f"[Session {session_id}] PR created: {pr_url}")

        working_repo_url = working_repo.html_url

        # Store session state
        SESSIONS[session_id] = {
            "repo_url": request.repo_url,           # original repo URL (for PR)
            "working_repo_url": working_repo_url,   # where branch lives (may be fork)
            "pr_head": pr_head,
            "entry_file": request.entry_file,
            "log_file": request.log_file,
            "branch": branch,
            "created_at": datetime.utcnow().isoformat(),
            "iterations": [],
            "baseline_runtime": None,
            "pr_number": pr_number,
            "call_site": None,
            "best_runtime": None,
            "last_code": None,
            "last_fix_name": None,
            "crash_retries": 0,
        }

        # Log session to Supabase
        try:
            sb = _supabase()
            if sb:
                sb.table("sessions").insert({
                    "id": session_id,
                    "repo_url": request.repo_url,
                    "entry_file": request.entry_file,
                    "branch": branch,
                    "pr_url": pr_url,
                    "license_key": license_key,
                    "created_at": datetime.utcnow().isoformat(),
                }).execute()
        except Exception as e:
            print(f"[Debug log] Supabase session insert failed (non-fatal): {e}")

        return CreateSessionResponse(
            session_id=session_id,
            branch=branch,
            working_repo_url=working_repo_url,
            status="created",
            pr_url=pr_url,
        )

    except Exception as e:
        raise HTTPException(500, f"Failed to create session: {e}")


@app.post("/sessions/{session_id}/logs", response_model=SubmitLogsResponse)
async def submit_logs(
    session_id: str,
    request: SubmitLogsRequest,
    license_key: str = Header(..., alias="X-License-Key"),
):
    """
    Submit solver logs from a run. Analyzes logs, commits next improvement, returns action.

    Flow:
    - Iteration 0: record baseline, scan code, fall through to suggest first improvement
    - Iteration N: check if last fix helped (keep or revert), then suggest next
    - Claude decides what to change based on analyzer findings and history (solver-agnostic)
    - Returns "done" when Claude declines to suggest further improvements
    """
    if not validate_license(license_key):
        raise HTTPException(401, "Invalid license key")

    if session_id not in SESSIONS:
        raise HTTPException(404, "Session not found")

    session = SESSIONS[session_id]
    iteration = request.iteration

    try:
        # Read/write code on the working repo (original or fork)
        repo = get_github_client(session["working_repo_url"])
        file_content = repo.get_contents(session["entry_file"], ref=session["branch"])
        model_code = file_content.decoded_content.decode("utf-8")
    except Exception as e:
        raise HTTPException(500, f"Could not read model code: {e}")

    # ========================================================================
    # Iteration 0: Baseline setup
    # ========================================================================
    if iteration == 0:
        session["baseline_runtime"] = request.runtime
        session["best_runtime"] = request.runtime
        session["last_code"] = model_code

        try:
            session["call_site"] = scan_code_for_call_site(
                model_code, session["entry_file"]
            )
        except Exception as e:
            print(f"Code scanning failed, using defaults: {e}")
            session["call_site"] = {
                "model_var": "model",
                "gurobi_alias": "gp",
                "call_sites": [],
            }

        session["iterations"].append(
            {
                "iteration": 0,
                "runtime": request.runtime,
                "speedup": 0.0,
                "status": "baseline",
                "fix_name": "baseline",
                "explanation": "Initial baseline run",
            }
        )

        print(f"[Session {session_id}] Baseline: {request.runtime:.3f}s")

    # ========================================================================
    # Iteration > 0: Evaluate whether the last committed fix helped
    # ========================================================================
    else:
        last_fix_name = session.get("last_fix_name", "unknown")

        # ── Crash recovery: the CLI reported a runtime error ──────────
        if request.status == "error":
            session["crash_retries"] = session.get("crash_retries", 0) + 1
            error_snippet = (request.error or "unknown error")[:500]

            session["iterations"].append(
                {
                    "iteration": iteration,
                    "runtime": request.runtime,
                    "speedup": 0.0,
                    "status": "CRASHED",
                    "fix_name": last_fix_name,
                    "explanation": f"Runtime error: {error_snippet}",
                }
            )
            print(
                f"[Session {session_id}] Iteration {iteration}: CRASHED {last_fix_name} "
                f"(attempt {session['crash_retries']}): {error_snippet[:120]}"
            )

            # Revert to last known-good code
            if session.get("last_code"):
                try:
                    commit_revert(
                        repo,
                        session["branch"],
                        session["entry_file"],
                        session["last_code"],
                        last_fix_name,
                    )
                    file_content = repo.get_contents(
                        session["entry_file"], ref=session["branch"]
                    )
                    model_code = file_content.decoded_content.decode("utf-8")
                except Exception as e:
                    print(f"Failed to revert after crash: {e}")

            # Hard stop after 3 consecutive crashes
            if session["crash_retries"] >= 3:
                print(f"[Session {session_id}] Too many crashes, stopping")
                return SubmitLogsResponse(
                    action="done",
                    message=f"Stopped after {session['crash_retries']} consecutive runtime errors",
                )

            # Otherwise fall through to suggest a different improvement

        elif request.runtime < session["best_runtime"]:
            # Fix improved things — keep it
            session["crash_retries"] = 0
            speedup = (
                (session["baseline_runtime"] - request.runtime)
                / session["baseline_runtime"]
            ) * 100
            session["best_runtime"] = request.runtime
            session["last_code"] = model_code

            session["iterations"].append(
                {
                    "iteration": iteration,
                    "runtime": request.runtime,
                    "speedup": speedup,
                    "status": "KEPT",
                    "fix_name": last_fix_name,
                    "explanation": f"Improved from {session['baseline_runtime']:.3f}s to {request.runtime:.3f}s",
                }
            )
            print(
                f"[Session {session_id}] Iteration {iteration}: KEPT {last_fix_name} ({speedup:+.1f}%)"
            )

        else:
            # Fix did not help — revert to last good code
            session["crash_retries"] = 0
            speedup = (
                (session["baseline_runtime"] - request.runtime)
                / session["baseline_runtime"]
            ) * 100

            session["iterations"].append(
                {
                    "iteration": iteration,
                    "runtime": request.runtime,
                    "speedup": speedup,
                    "status": "reverted",
                    "fix_name": last_fix_name,
                    "explanation": f"No improvement ({request.runtime:.3f}s vs best {session['best_runtime']:.3f}s)",
                }
            )
            print(
                f"[Session {session_id}] Iteration {iteration}: REVERTED {last_fix_name}"
            )

            if session.get("last_code"):
                try:
                    commit_revert(
                        repo,
                        session["branch"],
                        session["entry_file"],
                        session["last_code"],
                        last_fix_name,
                    )
                    file_content = repo.get_contents(
                        session["entry_file"], ref=session["branch"]
                    )
                    model_code = file_content.decoded_content.decode("utf-8")
                except Exception as e:
                    print(f"Failed to revert: {e}")

    # ========================================================================
    # Run analyzers, then ask Claude for the next improvement
    # ========================================================================
    analysis_results = run_analysis_pipeline(request.logs)
    problems = [r.analyzer_name for r in analysis_results if r.is_problem]
    print(f"[Session {session_id}] Analysis: {problems}")

    # Build debug trace for Supabase logging
    parsed_profile = parse_log_to_profile(request.logs)
    debug_trace: dict = {
        "analyzer_results": [
            {
                "name": r.analyzer_name,
                "is_problem": r.is_problem,
                "severity": r.severity,
                "context": r.context,
                "details": r.details,
            }
            for r in analysis_results
        ],
        "parsed_profile": {
            "n_vars": parsed_profile.n_vars,
            "n_constrs": parsed_profile.n_constrs,
            "n_binary": parsed_profile.n_binary,
            "log_nodes": parsed_profile.log_nodes,
            "log_gap": parsed_profile.log_gap,
            "log_runtime": parsed_profile.log_runtime,
            "density": parsed_profile.density,
            "coef_range_ratio": parsed_profile.coef_range_ratio,
            "has_symmetry": parsed_profile.has_symmetry,
        },
        "retry_occurred": False,
    }

    call_site = session.get("call_site", {"model_var": "model", "gurobi_alias": "gp"})
    improvement = suggest_next_improvement(
        request.logs, model_code, analysis_results, call_site, session["iterations"],
        baseline_runtime=session.get("baseline_runtime"),
        debug_trace=debug_trace,
    )

    # Determine status for this iteration's log
    if iteration == 0:
        decision_status = "baseline"
        speedup_value = 0.0
    else:
        last_iter = session["iterations"][-1] if session["iterations"] else {}
        decision_status = last_iter.get("status", "unknown")
        speedup_value = last_iter.get("speedup", 0.0)

    fix_name = improvement.get("name", "improvement") if improvement else None

    if not improvement:
        best_speedup = (
            (session["baseline_runtime"] - session["best_runtime"])
            / session["baseline_runtime"]
            * 100
            if session.get("baseline_runtime")
            else 0.0
        )

        # Log iteration to Supabase (no improvement suggested)
        try:
            sb = _supabase()
            if sb:
                sb.table("iteration_logs").insert({
                    "session_id": session_id,
                    "iteration": iteration,
                    "runtime": request.runtime,
                    "speedup": speedup_value,
                    "status": decision_status,
                    "fix_name": None,
                    "analyzer_results": debug_trace.get("analyzer_results"),
                    "parsed_profile": debug_trace.get("parsed_profile"),
                    "bottleneck_text": debug_trace.get("bottleneck_text"),
                    "claude_user_prompt": debug_trace.get("claude_user_prompt"),
                    "claude_response_raw": debug_trace.get("claude_response_raw"),
                    "claude_tool_call": debug_trace.get("claude_tool_call"),
                    "validation_valid": debug_trace.get("validation_valid"),
                    "validation_error": debug_trace.get("validation_error"),
                    "retry_occurred": debug_trace.get("retry_occurred", False),
                    "retry_tool_call": debug_trace.get("retry_tool_call"),
                    "code_diff": None,
                }).execute()
        except Exception as e:
            print(f"[Debug log] Supabase iteration insert failed (non-fatal): {e}")

        return SubmitLogsResponse(
            action="done",
            message=f"No further improvements identified. Best speedup: {best_speedup:.1f}%",
        )

    # Apply and commit the improvement
    try:
        new_content = apply_code_changes(model_code, improvement.get("changes", []))
        file_content = repo.get_contents(session["entry_file"], ref=session["branch"])

        fix_name = improvement.get("name", "improvement")
        result = repo.update_file(
            session["entry_file"],
            f"Try: {fix_name}",
            new_content,
            file_content.sha,
            branch=session["branch"],
        )
        commit_sha = result["commit"].sha
        session["last_fix_name"] = fix_name

        # Compute code diff for debug logging
        old_lines = model_code.splitlines(keepends=True)
        new_lines = new_content.splitlines(keepends=True)
        code_diff = "".join(difflib.unified_diff(old_lines, new_lines, fromfile="before", tofile="after"))

        # Log iteration to Supabase
        try:
            sb = _supabase()
            if sb:
                sb.table("iteration_logs").insert({
                    "session_id": session_id,
                    "iteration": iteration,
                    "runtime": request.runtime,
                    "speedup": speedup_value,
                    "status": decision_status,
                    "fix_name": fix_name,
                    "analyzer_results": debug_trace.get("analyzer_results"),
                    "parsed_profile": debug_trace.get("parsed_profile"),
                    "bottleneck_text": debug_trace.get("bottleneck_text"),
                    "claude_user_prompt": debug_trace.get("claude_user_prompt"),
                    "claude_response_raw": debug_trace.get("claude_response_raw"),
                    "claude_tool_call": debug_trace.get("claude_tool_call"),
                    "validation_valid": debug_trace.get("validation_valid"),
                    "validation_error": debug_trace.get("validation_error"),
                    "retry_occurred": debug_trace.get("retry_occurred", False),
                    "retry_tool_call": debug_trace.get("retry_tool_call"),
                    "code_diff": code_diff,
                }).execute()
        except Exception as e:
            print(f"[Debug log] Supabase iteration insert failed (non-fatal): {e}")

        return SubmitLogsResponse(
            action="pull",
            branch=session["branch"],
            commit=commit_sha,
            message=fix_name,
            improvement=improvement.get("reasoning", ""),
        )

    except Exception as e:
        print(f"Failed to commit improvement: {e}")
        return SubmitLogsResponse(
            action="done",
            message=f"Failed to apply improvement: {e}",
        )


@app.post("/sessions/{session_id}/complete", response_model=CompleteSessionResponse)
async def complete_session(
    session_id: str,
    request: CompleteSessionRequest,
    license_key: str = Header(..., alias="X-License-Key"),
):
    """
    Complete an optimization session.
    Creates a PR and returns the results.
    """
    if not validate_license(license_key):
        raise HTTPException(401, "Invalid license key")

    if session_id not in SESSIONS:
        raise HTTPException(404, "Session not found")

    session = SESSIONS[session_id]

    # Find best result
    baseline_runtime = session["baseline_runtime"] or request.results[0]["runtime"]
    best_result = min(request.results, key=lambda x: x["runtime"])
    best_runtime = best_result["runtime"]

    speedup = ((baseline_runtime - best_runtime) / baseline_runtime) * 100

    # Build PR description with results table and explanations
    iterations = session.get("iterations", [])

    pr_body = f"""## Gurobi Solver Optimization

This PR adds optimized Gurobi solver parameters and formulation improvements to enhance solve performance.
Changes were selected by analyzing the solver log and model code, then testing improvements via automated benchmarking.

### `{session['entry_file']}` — Fix Attempts

**Baseline:** {baseline_runtime:.3f}s

| Fix | Runtime | Speedup | Result |
|-----|---------|---------|--------|
"""

    for it in iterations:
        fix_name = it.get("fix_name", "unknown")
        runtime = it.get("runtime", 0)
        spd = it.get("speedup", 0)
        status = it.get("status", "")

        if status == "baseline":
            pr_body += f"| baseline | {runtime:.3f}s | — | — |\n"
        else:
            # Add KEPT/reverted markers like original
            if status == "KEPT":
                fix_label = f"**{fix_name}** ✓"
            else:
                fix_label = f"~~{fix_name}~~"
            sign = "+" if spd > 0 else ""
            pr_body += (
                f"| {fix_label} | {runtime:.3f}s | {sign}{spd:.1f}% | {status} |\n"
            )

    # Add explanations section for kept improvements
    kept_improvements = [
        it for it in iterations if it.get("status") == "KEPT" and it.get("explanation")
    ]
    if kept_improvements:
        pr_body += "\n### Why These Changes Help\n\n"
        for it in kept_improvements:
            pr_body += f"**{it['fix_name']}**\n"
            pr_body += f"> {it['explanation']}\n\n"

    pr_body += f"""
### Summary

- **Baseline:** {baseline_runtime:.3f}s
- **Best runtime:** {best_runtime:.3f}s
- **Total speedup:** +{speedup:.1f}%
- **Improvements applied:** {len(kept_improvements)}

---
*Generated by [Optimaze](https://optimaze.ai) — AI-powered Gurobi optimization*
"""

    # Update PR with final results
    pr_url = None
    pr_number = session.get("pr_number")
    try:
        repo = get_github_client(session["repo_url"])
        if pr_number:
            pr = repo.get_pull(pr_number)
            pr_title = (
                f"Optimaze: +{speedup:.1f}% solver speedup on {session['entry_file']}"
                if speedup > 0
                else f"Optimaze: solver analysis of {session['entry_file']} (no net improvement)"
            )
            pr.edit(title=pr_title, body=pr_body)
            pr_url = pr.html_url
            print(f"[Session {session_id}] PR updated: {pr_url}")
        else:
            print(f"[Session {session_id}] No PR number in session, skipping PR update")
    except Exception as e:
        print(f"[Session {session_id}] PR update failed: {e}")

    recommendations = []
    if pr_url:
        recommendations.append(f"Review and merge PR: {pr_url}")
    elif speedup > 0:
        recommendations.append(
            f"Merge branch {session['branch']} for {speedup:.1f}% speedup"
        )
    else:
        recommendations.append(
            "No improvements found - model may already be well-tuned"
        )

    # Update session in Supabase with final results
    try:
        sb = _supabase()
        if sb:
            sb.table("sessions").update({
                "baseline_runtime": baseline_runtime,
                "best_runtime": best_runtime,
                "final_speedup": speedup,
                "total_iterations": len(iterations),
                "completed_at": datetime.utcnow().isoformat(),
            }).eq("id", session_id).execute()
    except Exception as e:
        print(f"[Debug log] Supabase session update failed (non-fatal): {e}")

    # Clean up session
    del SESSIONS[session_id]

    return CompleteSessionResponse(
        best_commit=best_result.get("commit"),
        baseline_runtime=baseline_runtime,
        best_runtime=best_runtime,
        speedup=speedup,
        recommendations=recommendations,
        pr_url=pr_url,
    )


@app.get("/sessions/{session_id}")
async def get_session(
    session_id: str,
    license_key: str = Header(..., alias="X-License-Key"),
):
    """Get session status."""
    if not validate_license(license_key):
        raise HTTPException(401, "Invalid license key")

    if session_id not in SESSIONS:
        raise HTTPException(404, "Session not found")

    return SESSIONS[session_id]


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
