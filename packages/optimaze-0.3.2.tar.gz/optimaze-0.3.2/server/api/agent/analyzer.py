"""
SolverAnalyzer: LLM-powered analysis of optimization results.

Uses Claude to interpret solver output and suggest fixes.
"""

from dataclasses import dataclass
from typing import Optional

from server.api.agent.solver import SolverResult


@dataclass
class SuggestedFix:
    """A suggested fix for an optimization issue."""

    parameter: str
    current_value: any
    suggested_value: any
    rationale: str
    confidence: float  # 0-1
    requires_approval: bool = False


@dataclass
class Analysis:
    """Analysis of a solver result."""

    status: str  # optimal, infeasible, timeout, error
    summary: str
    root_cause: Optional[str] = None
    suggested_fixes: list[SuggestedFix] = None
    confidence: float = 0.0

    def __post_init__(self):
        if self.suggested_fixes is None:
            self.suggested_fixes = []


class SolverAnalyzer:
    """
    Analyzes solver results and suggests fixes.

    For PoC, this uses rule-based analysis. In production,
    integrate Claude API for more sophisticated analysis.
    """

    def __init__(self, use_llm: bool = False, api_key: Optional[str] = None):
        self.use_llm = use_llm
        self.api_key = api_key

    def analyze(self, result: SolverResult) -> Analysis:
        """
        Analyze solver result and suggest fixes.

        Args:
            result: SolverResult from solver wrapper

        Returns:
            Analysis with diagnosis and suggested fixes
        """
        if result.status == "OPTIMAL":
            return self._analyze_optimal(result)
        elif result.status == "INFEASIBLE":
            return self._analyze_infeasible(result)
        elif result.status == "TIME_LIMIT":
            return self._analyze_timeout(result)
        else:
            return self._analyze_error(result)

    def _analyze_optimal(self, result: SolverResult) -> Analysis:
        """Analyze optimal solution."""
        summary_lines = ["Optimization successful."]

        if result.solution:
            sol = result.solution

            # Check solution quality
            if "budget" in sol:
                change = sol["budget"].get("change", 0)
                if abs(change) < 1000:
                    summary_lines.append("Budget is approximately neutral.")
                elif change > 0:
                    summary_lines.append(f"Budget decreases by €{change:,.0f} (less tax collected).")
                else:
                    summary_lines.append(f"Budget increases by €{-change:,.0f} (more tax collected).")

            if "brackets" in sol:
                n_active = sum(sol["brackets"].get("active", []))
                summary_lines.append(f"Solution uses {n_active} active brackets.")

        return Analysis(
            status="optimal",
            summary="\n".join(summary_lines),
            confidence=1.0,
        )

    def _analyze_infeasible(self, result: SolverResult) -> Analysis:
        """Analyze infeasible result and suggest fixes."""
        fixes = []
        root_cause = "Unknown - constraints cannot be satisfied simultaneously."

        if result.iis_constraints:
            # Analyze IIS to identify root cause
            iis = result.iis_constraints

            # Check for budget constraint conflicts
            budget_in_iis = any("budget" in c.lower() for c in iis)
            marginal_in_iis = any("marginal" in c.lower() for c in iis)
            income_drop_in_iis = any("income_drop" in c.lower() for c in iis)

            if budget_in_iis and marginal_in_iis:
                root_cause = (
                    "Budget constraint conflicts with marginal pressure limits. "
                    "To stay revenue-neutral while capping marginal rates, "
                    "the model needs more flexibility."
                )
                fixes.append(
                    SuggestedFix(
                        parameter="max_marginal_rate",
                        current_value=0.55,  # Placeholder
                        suggested_value=0.60,
                        rationale="Relax marginal rate cap by 5% to allow feasible solution",
                        confidence=0.7,
                    )
                )
                fixes.append(
                    SuggestedFix(
                        parameter="budget_tolerance",
                        current_value=0,
                        suggested_value=1e7,
                        rationale="Allow €10M budget flexibility",
                        confidence=0.6,
                    )
                )

            elif budget_in_iis and income_drop_in_iis:
                root_cause = (
                    "Budget constraint conflicts with income protection. "
                    "Cannot maintain revenue while protecting all incomes."
                )
                fixes.append(
                    SuggestedFix(
                        parameter="max_relative_income_drop",
                        current_value=0.05,
                        suggested_value=0.08,
                        rationale="Allow up to 8% income drop instead of 5%",
                        confidence=0.6,
                    )
                )

            elif marginal_in_iis and income_drop_in_iis:
                root_cause = (
                    "Marginal rate limits conflict with income protection. "
                    "Progressive rates needed to protect low incomes exceed marginal cap."
                )
                fixes.append(
                    SuggestedFix(
                        parameter="max_marginal_rate",
                        current_value=0.55,
                        suggested_value=0.60,
                        rationale="Increase marginal cap to allow progressive protection",
                        confidence=0.7,
                    )
                )

            elif len(iis) > 100:
                root_cause = (
                    "Large number of individual constraints in conflict. "
                    "Likely systematic issue with income protection constraints."
                )
                fixes.append(
                    SuggestedFix(
                        parameter="max_relative_income_drop",
                        current_value=0.05,
                        suggested_value=0.10,
                        rationale="Relax income protection to find feasible region",
                        confidence=0.5,
                    )
                )

        summary = f"Model is infeasible. {len(result.iis_constraints or [])} constraints in IIS."

        return Analysis(
            status="infeasible",
            summary=summary,
            root_cause=root_cause,
            suggested_fixes=fixes,
            confidence=0.6 if fixes else 0.3,
        )

    def _analyze_timeout(self, result: SolverResult) -> Analysis:
        """Analyze timeout result."""
        fixes = [
            SuggestedFix(
                parameter="time_limit",
                current_value=3600,
                suggested_value=7200,
                rationale="Increase time limit to 2 hours",
                confidence=0.5,
            ),
            SuggestedFix(
                parameter="mip_gap",
                current_value=0.01,
                suggested_value=0.02,
                rationale="Accept 2% gap instead of 1%",
                confidence=0.6,
            ),
        ]

        return Analysis(
            status="timeout",
            summary=f"Optimization timed out after {result.runtime_seconds:.0f}s",
            root_cause="Model complexity exceeds time limit",
            suggested_fixes=fixes,
            confidence=0.5,
        )

    def _analyze_error(self, result: SolverResult) -> Analysis:
        """Analyze error result."""
        return Analysis(
            status="error",
            summary=f"Solver error: {result.status}",
            root_cause="Check Gurobi license and model formulation",
            confidence=0.3,
        )

    def format_analysis_for_log(self, analysis: Analysis) -> str:
        """Format analysis for logging."""
        lines = [
            "=== Analysis ===",
            f"Status: {analysis.status}",
            f"Summary: {analysis.summary}",
        ]

        if analysis.root_cause:
            lines.append(f"Root Cause: {analysis.root_cause}")

        if analysis.suggested_fixes:
            lines.append("\nSuggested Fixes:")
            for i, fix in enumerate(analysis.suggested_fixes, 1):
                lines.append(
                    f"  {i}. {fix.parameter}: {fix.current_value} -> {fix.suggested_value}"
                )
                lines.append(f"     Rationale: {fix.rationale}")
                lines.append(f"     Confidence: {fix.confidence:.0%}")

        return "\n".join(lines)
