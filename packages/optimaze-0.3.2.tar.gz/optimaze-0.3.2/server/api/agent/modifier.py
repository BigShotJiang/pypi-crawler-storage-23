"""
ModelModifier: Applies suggested fixes to optimization configuration.

Takes suggestions from the analyzer and modifies the config for re-solving.
"""

import copy
from dataclasses import dataclass
from typing import Optional

from src.data.schemas import OptimizationConfig

from server.api.agent.analyzer import Analysis, SuggestedFix


@dataclass
class AppliedFix:
    """Record of an applied fix."""

    parameter: str
    old_value: any
    new_value: any
    rationale: str
    iteration: int


class ModelModifier:
    """
    Applies fixes to optimization configuration.

    Tracks all modifications for audit trail.
    """

    def __init__(self):
        self.applied_fixes: list[AppliedFix] = []
        self.iteration = 0

    def apply_fix(
        self,
        config: OptimizationConfig,
        fix: SuggestedFix,
    ) -> OptimizationConfig:
        """
        Apply a single fix to the configuration.

        Args:
            config: Current optimization config
            fix: Suggested fix to apply

        Returns:
            New config with fix applied
        """
        new_config = copy.deepcopy(config)

        # Map parameter names to config attributes
        param_map = {
            "max_marginal_rate": "max_marginal_rate",
            "max_relative_income_drop": "max_relative_income_drop",
            "min_budget_change": "min_budget_change",
            "max_budget_change": "max_budget_change",
            "time_limit": "time_limit",
            "mip_gap": "mip_gap",
            "budget_tolerance": None,  # Special handling
        }

        param = fix.parameter
        attr = param_map.get(param)

        if attr and hasattr(new_config, attr):
            old_value = getattr(new_config, attr)
            setattr(new_config, attr, fix.suggested_value)

            # Record fix
            self.applied_fixes.append(
                AppliedFix(
                    parameter=param,
                    old_value=old_value,
                    new_value=fix.suggested_value,
                    rationale=fix.rationale,
                    iteration=self.iteration,
                )
            )

        elif param == "budget_tolerance":
            # Special: adjust both min and max budget
            tolerance = fix.suggested_value
            old_min = new_config.min_budget_change
            old_max = new_config.max_budget_change

            new_config.min_budget_change = -abs(tolerance)
            new_config.max_budget_change = abs(tolerance)

            self.applied_fixes.append(
                AppliedFix(
                    parameter="budget_tolerance",
                    old_value=f"[{old_min}, {old_max}]",
                    new_value=f"[{-abs(tolerance)}, {abs(tolerance)}]",
                    rationale=fix.rationale,
                    iteration=self.iteration,
                )
            )

        return new_config

    def apply_best_fix(
        self,
        config: OptimizationConfig,
        analysis: Analysis,
    ) -> tuple[OptimizationConfig, Optional[SuggestedFix]]:
        """
        Apply the highest-confidence fix from the analysis.

        Args:
            config: Current optimization config
            analysis: Analysis with suggested fixes

        Returns:
            (new_config, applied_fix) tuple
        """
        if not analysis.suggested_fixes:
            return config, None

        # Sort by confidence and pick best
        fixes = sorted(analysis.suggested_fixes, key=lambda f: f.confidence, reverse=True)
        best_fix = fixes[0]

        new_config = self.apply_fix(config, best_fix)
        return new_config, best_fix

    def apply_all_fixes(
        self,
        config: OptimizationConfig,
        analysis: Analysis,
    ) -> OptimizationConfig:
        """
        Apply all suggested fixes from the analysis.

        Args:
            config: Current optimization config
            analysis: Analysis with suggested fixes

        Returns:
            New config with all fixes applied
        """
        new_config = config
        for fix in analysis.suggested_fixes:
            new_config = self.apply_fix(new_config, fix)
        return new_config

    def increment_iteration(self):
        """Move to next iteration."""
        self.iteration += 1

    def get_modification_log(self) -> str:
        """Get human-readable log of all modifications."""
        if not self.applied_fixes:
            return "No modifications applied."

        lines = ["=== Modification Log ==="]
        for fix in self.applied_fixes:
            lines.append(
                f"[Iteration {fix.iteration}] {fix.parameter}: "
                f"{fix.old_value} -> {fix.new_value}"
            )
            lines.append(f"  Reason: {fix.rationale}")

        return "\n".join(lines)

    def get_modification_dict(self) -> list[dict]:
        """Get modifications as list of dicts for JSON."""
        return [
            {
                "iteration": f.iteration,
                "parameter": f.parameter,
                "old_value": str(f.old_value),
                "new_value": str(f.new_value),
                "rationale": f.rationale,
            }
            for f in self.applied_fixes
        ]
