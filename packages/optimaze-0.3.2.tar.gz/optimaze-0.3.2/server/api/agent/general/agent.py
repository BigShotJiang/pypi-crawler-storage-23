"""
GurobiAgent: Main orchestrator for automatic Gurobi model improvement.

Usage:
    agent = GurobiAgent()
    result = agent.improve(model)  # or agent.improve("model.mps")
"""

import io
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Union

import gurobipy as gp
from gurobipy import GRB

from server.api.agent.general.catalog import ImprovementCatalog
from server.api.agent.general.matcher import ImprovementMatcher
from server.api.agent.general.profiler import ModelProfiler
from server.api.agent.general.types import (
    AgentResult,
    BenchmarkResult,
    Improvement,
    ImprovementCategory,
    ProblemProfile,
)


@dataclass
class AgentConfig:
    """Configuration for the GurobiAgent."""

    # Testing strategy
    max_improvements_to_test: int = 10
    smoke_test_time_limit: float = 10.0  # seconds
    full_test_time_limit: float = 60.0  # seconds
    min_confidence: float = 0.3

    # Smoke test settings
    use_smoke_tests: bool = True
    smoke_test_threshold: float = 5.0  # % speedup needed to proceed

    # Early stopping
    early_stop_speedup: float = 50.0  # Stop if we find this much speedup

    # Output
    verbose: bool = True
    generate_report: bool = True


class GurobiAgent:
    """
    General-purpose Gurobi formulation improvement agent.

    This agent:
    1. Profiles the model to understand its structure
    2. Matches the profile to likely improvements
    3. Tests improvements using smoke tests + full benchmarks
    4. Returns the best improvement found
    """

    def __init__(self, config: Optional[AgentConfig] = None):
        self.config = config or AgentConfig()
        self.profiler = ModelProfiler(verbose=self.config.verbose)
        self.catalog = ImprovementCatalog()
        self.matcher = ImprovementMatcher(self.catalog, verbose=self.config.verbose)

    def log(self, msg: str):
        if self.config.verbose:
            print(f"[GurobiAgent] {msg}")

    def improve(
        self,
        model_or_path: Union[gp.Model, str, Path],
    ) -> AgentResult:
        """
        Improve a Gurobi model's solve time.

        Args:
            model_or_path: gp.Model object or path to .mps/.lp file

        Returns:
            AgentResult with best improvement and all results
        """
        self.log("=" * 60)
        self.log("GENERAL GUROBI IMPROVEMENT AGENT")
        self.log("=" * 60)

        # Step 1: Load model
        model = self._load_model(model_or_path)
        self.log(f"\nModel: {model.ModelName or 'unnamed'}")

        # Step 2: Run baseline and profile
        self.log("\n[STEP 1] Running baseline with profiling...")
        baseline_result, baseline_log, profile = self._run_baseline(model)

        self.log(f"         Baseline: {baseline_result.runtime_seconds:.3f}s, {baseline_result.nodes_explored} nodes")
        self.log(f"         Type: {profile.problem_type.name}")
        self.log(f"         Structures: {[s.name for s in profile.detected_structures]}")

        # Step 3: Match improvements
        self.log("\n[STEP 2] Selecting improvements to test...")
        matches = self.matcher.get_top_improvements(
            profile,
            n=self.config.max_improvements_to_test,
            min_confidence=self.config.min_confidence,
        )

        self.log(f"         Selected {len(matches)} improvements to test:")
        for imp, conf, reason in matches[:5]:
            self.log(f"           - {imp.name} ({conf:.0%}): {reason}")

        # Step 4: Test improvements
        self.log("\n[STEP 3] Testing improvements...")
        results, skipped = self._test_improvements(model, baseline_result, matches)

        # Step 5: Build result
        result = AgentResult(
            baseline_runtime=baseline_result.runtime_seconds,
            baseline_nodes=baseline_result.nodes_explored,
            baseline_status=baseline_result.status,
            profile=profile,
            improvements_tested=results,
            improvements_skipped=skipped,
        )

        # Find best
        winners = [r for r in results if r.is_winner]
        if winners:
            best = max(winners, key=lambda r: r.speedup_pct)
            result.best_improvement = best.improvement_name
            result.best_speedup = best.speedup_pct

            # Get params for best improvement
            for imp, _, _ in matches:
                if imp.name == best.improvement_name:
                    result.best_params = imp.gurobi_params
                    break

        # Generate recommendations
        result.recommendations = self._generate_recommendations(result, profile)

        # Print summary
        self._print_summary(result)

        return result

    def _load_model(self, model_or_path: Union[gp.Model, str, Path]) -> gp.Model:
        """Load model from path if needed."""
        if isinstance(model_or_path, (str, Path)):
            self.log(f"Loading model from {model_or_path}")
            return gp.read(str(model_or_path))
        return model_or_path.copy()  # Always work on a copy

    def _run_baseline(
        self,
        model: gp.Model,
    ) -> tuple[BenchmarkResult, str, ProblemProfile]:
        """Run baseline solve and create profile."""
        model_copy = model.copy()
        model_copy.Params.TimeLimit = self.config.full_test_time_limit
        model_copy.Params.OutputFlag = 1

        # Capture log
        old_stdout = sys.stdout
        sys.stdout = captured = io.StringIO()

        try:
            start = time.time()
            model_copy.optimize()
            runtime = time.time() - start
        finally:
            sys.stdout = old_stdout
            log_output = captured.getvalue()

        result = BenchmarkResult(
            improvement_name="baseline",
            runtime_seconds=runtime,
            nodes_explored=int(model_copy.NodeCount) if hasattr(model_copy, 'NodeCount') else 0,
            status="OPTIMAL" if model_copy.Status == GRB.OPTIMAL else str(model_copy.Status),
            objective_value=model_copy.ObjVal if model_copy.Status == GRB.OPTIMAL else None,
        )

        # Create profile with log
        profile = self.profiler.profile(model, gurobi_log=log_output)

        return result, log_output, profile

    def _test_improvements(
        self,
        model: gp.Model,
        baseline: BenchmarkResult,
        matches: list[tuple[Improvement, float, str]],
    ) -> tuple[list[BenchmarkResult], list[str]]:
        """Test all selected improvements."""
        results = []
        skipped = []

        for i, (imp, confidence, reason) in enumerate(matches):
            self.log(f"\n         [{i+1}/{len(matches)}] Testing {imp.name}...")

            # Smoke test first if enabled
            if self.config.use_smoke_tests and imp.category == ImprovementCategory.SOLVER_PARAM:
                smoke_speedup = self._run_smoke_test(model, imp, baseline)
                if smoke_speedup < self.config.smoke_test_threshold:
                    self.log(f"              Smoke test: {smoke_speedup:+.1f}% - skipping full test")
                    skipped.append(f"{imp.name} (smoke: {smoke_speedup:+.1f}%)")
                    continue
                self.log(f"              Smoke test: {smoke_speedup:+.1f}% - proceeding to full test")

            # Full benchmark
            result = self._run_benchmark(model, imp, baseline)
            results.append(result)

            status = "✅" if result.is_winner else "❌"
            self.log(f"              {status} {result.runtime_seconds:.3f}s ({result.speedup_pct:+.1f}%)")

            # Early stopping
            if result.speedup_pct >= self.config.early_stop_speedup:
                self.log(f"\n         🎉 Early stop: Found {result.speedup_pct:.1f}% speedup!")
                break

        return results, skipped

    def _run_smoke_test(
        self,
        model: gp.Model,
        imp: Improvement,
        baseline: BenchmarkResult,
    ) -> float:
        """Run a quick smoke test with shorter time limit."""
        model_copy = model.copy()
        model_copy.Params.OutputFlag = 0
        model_copy.Params.TimeLimit = self.config.smoke_test_time_limit

        # Apply improvement
        for param, value in imp.gurobi_params.items():
            setattr(model_copy.Params, param, value)

        start = time.time()
        model_copy.optimize()
        runtime = time.time() - start

        # Compare to baseline (scaled by time limit ratio)
        scale = self.config.smoke_test_time_limit / self.config.full_test_time_limit
        baseline_scaled = baseline.runtime_seconds * scale

        if baseline_scaled > 0:
            speedup = (baseline_scaled - runtime) / baseline_scaled * 100
        else:
            speedup = 0.0

        return speedup

    def _run_benchmark(
        self,
        model: gp.Model,
        imp: Improvement,
        baseline: BenchmarkResult,
    ) -> BenchmarkResult:
        """Run a full benchmark for an improvement."""
        model_copy = model.copy()
        model_copy.Params.OutputFlag = 0
        model_copy.Params.TimeLimit = self.config.full_test_time_limit

        # Apply improvement
        if imp.gurobi_params:
            for param, value in imp.gurobi_params.items():
                setattr(model_copy.Params, param, value)

        if imp.apply_fn:
            model_copy = imp.apply_fn(model_copy)

        start = time.time()
        model_copy.optimize()
        runtime = time.time() - start

        # Calculate speedup
        if baseline.runtime_seconds > 0:
            speedup = (baseline.runtime_seconds - runtime) / baseline.runtime_seconds * 100
        else:
            speedup = 0.0

        return BenchmarkResult(
            improvement_name=imp.name,
            runtime_seconds=runtime,
            nodes_explored=int(model_copy.NodeCount) if hasattr(model_copy, 'NodeCount') else 0,
            status="OPTIMAL" if model_copy.Status == GRB.OPTIMAL else str(model_copy.Status),
            objective_value=model_copy.ObjVal if model_copy.Status == GRB.OPTIMAL else None,
            speedup_pct=speedup,
            is_winner=speedup > 0,
        )

    def _generate_recommendations(
        self,
        result: AgentResult,
        profile: ProblemProfile,
    ) -> list[str]:
        """Generate actionable recommendations."""
        recs = []

        if result.best_speedup > 10:
            recs.append(
                f"Apply {result.best_improvement} for {result.best_speedup:.1f}% speedup"
            )
            if result.best_params:
                params_str = ", ".join(f"{k}={v}" for k, v in result.best_params.items())
                recs.append(f"Gurobi params: {params_str}")

        # Structure-specific recommendations
        if profile.has_symmetry:
            recs.append("Consider adding problem-specific symmetry breaking constraints")

        if profile.coef_range_ratio > 1e6:
            recs.append("Large coefficient range detected - review big-M values")

        if profile.is_block_diagonal:
            recs.append(f"Model has {profile.n_components} independent components - consider decomposition")

        return recs

    def _print_summary(self, result: AgentResult):
        """Print final summary."""
        self.log("\n" + "=" * 60)
        self.log("RESULTS SUMMARY")
        self.log("=" * 60)

        self.log(f"\nBaseline: {result.baseline_runtime:.3f}s")
        self.log(f"Tested: {len(result.improvements_tested)} improvements")
        self.log(f"Skipped: {len(result.improvements_skipped)} improvements")

        if result.improvements_tested:
            self.log("\nResults:")
            self.log("-" * 50)
            for r in sorted(result.improvements_tested, key=lambda x: -x.speedup_pct):
                status = "✅" if r.is_winner else "❌"
                self.log(f"  {status} {r.improvement_name:<25} {r.runtime_seconds:.3f}s ({r.speedup_pct:+.1f}%)")

        if result.best_improvement:
            self.log(f"\n🏆 BEST: {result.best_improvement} ({result.best_speedup:+.1f}%)")
            if result.best_params:
                self.log(f"   Params: {result.best_params}")
        else:
            self.log("\nNo improvements found - model is already well-tuned!")

        if result.recommendations:
            self.log("\nRecommendations:")
            for rec in result.recommendations:
                self.log(f"  • {rec}")
