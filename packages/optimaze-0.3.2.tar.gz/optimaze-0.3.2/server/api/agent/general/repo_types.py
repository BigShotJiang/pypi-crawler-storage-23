"""
Data types for the repo-based Gurobi improvement agent.

These extend the core types in types.py with repo-specific concepts:
scanning, code modification, sandboxed execution, and PR creation.
"""

from dataclasses import dataclass, field
from typing import Optional

from server.api.agent.general.types import BenchmarkResult, ProblemProfile


@dataclass
class GurobiCallSite:
    """A location in source code where model.optimize() is called."""

    file_path: str
    model_var_name: str  # e.g. "model", "m", "prob"
    optimize_line: int  # Line number of .optimize() call
    indent: str  # Indentation at the optimize() line
    gurobi_alias: str  # e.g. "gp" from "import gurobipy as gp"
    import_style: str  # "import gurobipy as X" or "from gurobipy import ..."


@dataclass
class RepoScanResult:
    """Result of scanning a repository for Gurobi usage."""

    gurobi_files: list[str] = field(default_factory=list)
    call_sites: list[GurobiCallSite] = field(default_factory=list)
    entry_points: list[str] = field(default_factory=list)  # Files with __main__
    dependency_files: list[str] = field(default_factory=list)  # requirements.txt etc.


@dataclass
class LLMCodeChange:
    """A single code replacement suggested by the LLM advisor."""

    old_code: str       # Exact string to find (for str.replace)
    new_code: str       # Replacement
    description: str = ""


@dataclass
class LLMCodeImprovement:
    """A formulation-level improvement suggested by the LLM advisor."""

    name: str                          # e.g. "symmetry_breaking"
    category: str                      # e.g. "cutting_planes", "warm_start"
    description: str
    reasoning: str                     # LLM's analysis
    changes: list[LLMCodeChange] = field(default_factory=list)
    risk_level: str = "medium"
    expected_impact: str = ""
    preserves_semantics: bool = True
    benchmark: Optional[BenchmarkResult] = None


@dataclass
class CodeModification:
    """Tracks a source code modification for revert."""

    file_path: str
    original_content: str
    modified_content: str
    params_inserted: dict = field(default_factory=dict)
    description: str = ""


@dataclass
class SandboxRunResult:
    """Result from running a script in the sandbox."""

    returncode: int
    stdout: str
    stderr: str
    runtime: Optional[float] = None
    solver_status: Optional[str] = None
    obj_value: Optional[float] = None
    node_count: Optional[int] = None
    gurobi_log: str = ""  # Captured Gurobi solver log


@dataclass
class CallSiteResult:
    """Full improvement result for one call site."""

    call_site: GurobiCallSite
    entry_point: str
    baseline: Optional[SandboxRunResult] = None
    profile: Optional[ProblemProfile] = None
    gurobi_log: str = ""  # Baseline Gurobi log for profiling
    benchmarks: list[BenchmarkResult] = field(default_factory=list)
    best_improvement: Optional[str] = None
    best_speedup: float = 0.0
    best_params: dict = field(default_factory=dict)
    # LLM advisor results
    llm_improvements: list[LLMCodeImprovement] = field(default_factory=list)
    llm_benchmarks: list[BenchmarkResult] = field(default_factory=list)
    best_llm_improvement: Optional[LLMCodeImprovement] = None


@dataclass
class RepoAgentResult:
    """Final result from the repo agent."""

    github_url: str
    clone_dir: str = ""
    call_site_results: list[CallSiteResult] = field(default_factory=list)
    pr_url: Optional[str] = None
    overall_speedup: float = 0.0
    success: bool = False
    error: Optional[str] = None


@dataclass
class RepoAgentConfig:
    """Configuration for the repo agent."""

    # Directories
    clone_dir: str = ""  # Auto-generated if empty
    work_dir: str = ""  # Temp dir for artifacts

    # Git/PR settings
    branch_prefix: str = "gurobi-agent"
    create_pr: bool = True
    base_branch: str = "main"

    # Testing strategy (inherited from AgentConfig pattern)
    max_improvements_to_test: int = 8
    smoke_test_time_limit: float = 10.0
    full_test_time_limit: float = 60.0
    min_confidence: float = 0.3

    # Sandbox
    setup_timeout: float = 300.0  # 5 min for pip install
    script_timeout: float = 120.0  # 2 min per run

    # LLM advisor
    llm_enabled: bool = True
    llm_api_key: str = ""        # Falls back to ANTHROPIC_API_KEY
    llm_model: str = "claude-sonnet-4-20250514"

    # Entry point override
    entry_point: str = ""  # If set, use this file instead of auto-detecting

    # Iterative improvement loop
    max_iterations: int = 3  # max improvement iterations per call site

    # Output
    verbose: bool = True
