"""
ImprovementMatcher: Maps problem profiles to likely improvements.

Uses hardcoded rules based on optimization research and best practices.
"""

from dataclasses import dataclass
from typing import Callable

from server.api.agent.general.catalog import ImprovementCatalog
from server.api.agent.general.types import (
    Improvement,
    ProblemProfile,
    ProblemStructure,
    ProblemType,
)


@dataclass
class MatchRule:
    """A rule that maps problem characteristics to improvements."""
    name: str
    condition: Callable[[ProblemProfile], bool]
    improvements: list[str]  # Names of improvements to try
    confidence_boost: float = 0.0  # Add to base confidence
    reason: str = ""


class ImprovementMatcher:
    """
    Matches problem profiles to likely improvements.

    Uses a rule-based system to select improvements most likely to help
    based on detected problem characteristics.
    """

    def __init__(self, catalog: ImprovementCatalog, verbose: bool = False):
        self.catalog = catalog
        self.verbose = verbose
        self.rules = self._build_rules()

    def log(self, msg: str):
        if self.verbose:
            print(f"[Matcher] {msg}")

    def _build_rules(self) -> list[MatchRule]:
        """Build the matching rules."""
        return [
            # === Problem Type Rules ===

            MatchRule(
                name="pure_lp_barrier",
                condition=lambda p: p.problem_type == ProblemType.LP and p.n_vars > 1000,
                improvements=["Method_barrier"],
                confidence_boost=0.2,
                reason="Large LP problems often benefit from barrier method",
            ),

            MatchRule(
                name="milp_aggressive_cuts",
                condition=lambda p: p.problem_type == ProblemType.MILP and p.n_binary > 100,
                improvements=["Cuts_aggressive", "Presolve_aggressive"],
                confidence_boost=0.15,
                reason="MILPs with many binary vars benefit from cuts",
            ),

            # === Node Count Rules ===

            MatchRule(
                name="high_nodes_mipfocus",
                condition=lambda p: p.log_nodes > 1000,
                improvements=["MIPFocus_optimality", "MIPFocus_bound"],
                confidence_boost=0.2,
                reason="High node count suggests focus on optimality/bounds",
            ),

            MatchRule(
                name="low_nodes_quick_solve",
                condition=lambda p: p.log_nodes < 10 and p.log_runtime > 5,
                improvements=["Method_barrier", "Presolve_aggressive"],
                confidence_boost=0.15,
                reason="Few nodes but slow = LP is bottleneck",
            ),

            # === Size Rules ===

            MatchRule(
                name="large_model_presolve",
                condition=lambda p: p.n_constrs > 5000,
                improvements=["Presolve_aggressive"],
                confidence_boost=0.2,
                reason="Large models benefit from aggressive presolve",
            ),

            MatchRule(
                name="dense_model_barrier",
                condition=lambda p: p.density > 0.1,
                improvements=["Method_barrier"],
                confidence_boost=0.15,
                reason="Dense models often faster with barrier",
            ),

            MatchRule(
                name="sparse_model_simplex",
                condition=lambda p: p.density < 0.01 and p.n_vars > 1000,
                improvements=["Method_dual"],
                confidence_boost=0.1,
                reason="Sparse models often faster with simplex",
            ),

            # === Coefficient Range Rules ===

            MatchRule(
                name="big_m_detected",
                condition=lambda p: p.coef_range_ratio > 1e6,
                improvements=["Presolve_aggressive"],  # Let presolve handle it
                confidence_boost=0.1,
                reason="Large coefficient range suggests big-M - presolve helps",
            ),

            # === Structure-Specific Rules ===

            MatchRule(
                name="network_structure",
                condition=lambda p: ProblemStructure.NETWORK in p.detected_structures,
                improvements=["Method_primal", "Presolve_off"],  # Network simplex is default
                confidence_boost=0.2,
                reason="Network structure - primal simplex often best",
            ),

            MatchRule(
                name="set_cover_structure",
                condition=lambda p: ProblemStructure.SET_COVER in p.detected_structures,
                improvements=["Cuts_aggressive", "Heuristics_aggressive"],
                confidence_boost=0.2,
                reason="Set cover benefits from cuts and heuristics",
            ),

            MatchRule(
                name="knapsack_structure",
                condition=lambda p: ProblemStructure.KNAPSACK in p.detected_structures,
                improvements=["Cuts_aggressive"],  # Cover cuts
                confidence_boost=0.15,
                reason="Knapsack constraints benefit from cover cuts",
            ),

            # === Symmetry Rules ===

            MatchRule(
                name="symmetry_detected",
                condition=lambda p: p.has_symmetry and p.symmetry_groups > 2,
                improvements=["Symmetry_aggressive", "add_symmetry_breaking"],
                confidence_boost=0.25,
                reason="Symmetry detected - breaking can dramatically speed up",
            ),

            # === Block Diagonal Rules ===

            MatchRule(
                name="block_diagonal",
                condition=lambda p: p.is_block_diagonal and p.n_components > 3,
                improvements=["Threads_max"],  # Parallel solve blocks
                confidence_boost=0.1,
                reason="Block diagonal structure can be parallelized",
            ),

            # === Heuristics Rules ===

            MatchRule(
                name="need_feasible_fast",
                condition=lambda p: p.n_binary > 500 and p.log_nodes > 100,
                improvements=["MIPFocus_feasibility", "Heuristics_aggressive"],
                confidence_boost=0.15,
                reason="Large MIP - focus on feasibility first",
            ),

            # === Fallback Rules ===

            MatchRule(
                name="general_milp_defaults",
                condition=lambda p: p.problem_type == ProblemType.MILP,
                improvements=["Presolve_aggressive", "Cuts_aggressive"],
                confidence_boost=0.05,
                reason="General good practices for MILP",
            ),
        ]

    def match(self, profile: ProblemProfile) -> list[tuple[Improvement, float, str]]:
        """
        Match a problem profile to recommended improvements.

        Returns:
            List of (improvement, adjusted_confidence, reason) tuples,
            sorted by confidence descending.
        """
        # Get all applicable improvements
        applicable = self.catalog.filter_for_profile(profile)

        # Build improvement scores
        scores: dict[str, tuple[float, list[str]]] = {}  # name -> (score, reasons)

        for imp in applicable:
            scores[imp.name] = (imp.confidence, [])

        # Apply matching rules
        for rule in self.rules:
            if rule.condition(profile):
                self.log(f"Rule matched: {rule.name} - {rule.reason}")
                for imp_name in rule.improvements:
                    if imp_name in scores:
                        current_score, reasons = scores[imp_name]
                        new_score = min(0.95, current_score + rule.confidence_boost)
                        reasons.append(rule.reason)
                        scores[imp_name] = (new_score, reasons)

        # Build result list
        results = []
        for imp in applicable:
            score, reasons = scores[imp.name]
            reason = reasons[0] if reasons else "General improvement"
            results.append((imp, score, reason))

        # Sort by score descending
        results.sort(key=lambda x: -x[1])

        return results

    def get_top_improvements(
        self,
        profile: ProblemProfile,
        n: int = 5,
        min_confidence: float = 0.3,
    ) -> list[tuple[Improvement, float, str]]:
        """
        Get top N improvements for a profile.

        Args:
            profile: The problem profile
            n: Maximum number to return
            min_confidence: Minimum confidence threshold

        Returns:
            Top improvements with confidence and reason
        """
        all_matches = self.match(profile)
        filtered = [(imp, conf, reason) for imp, conf, reason in all_matches if conf >= min_confidence]
        return filtered[:n]

    def explain_matches(self, profile: ProblemProfile) -> str:
        """Generate human-readable explanation of why improvements were selected."""
        lines = ["## Improvement Selection Rationale", ""]

        # Show matched rules
        lines.append("### Rules Matched:")
        any_matched = False
        for rule in self.rules:
            if rule.condition(profile):
                any_matched = True
                lines.append(f"- **{rule.name}**: {rule.reason}")
                lines.append(f"  - Improvements: {', '.join(rule.improvements)}")

        if not any_matched:
            lines.append("- No specific rules matched - using default improvements")

        # Show top recommendations
        lines.append("")
        lines.append("### Top Recommendations:")
        for imp, conf, reason in self.get_top_improvements(profile, n=5):
            lines.append(f"- **{imp.name}** (confidence: {conf:.0%})")
            lines.append(f"  - {reason}")

        return "\n".join(lines)
