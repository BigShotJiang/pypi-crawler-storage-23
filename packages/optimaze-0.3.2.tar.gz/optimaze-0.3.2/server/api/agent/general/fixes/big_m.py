"""Fix: Big-M tightening via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class BigMFix(LLMBasedFix):
    """Tightens Big-M constraints. Targets models with large coefficient ranges."""

    name: ClassVar[str] = "big_m"
    focus_category: ClassVar[str] = "big_m_improvement"
