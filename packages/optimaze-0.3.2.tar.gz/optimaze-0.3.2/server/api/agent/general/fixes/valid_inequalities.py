"""Fix: valid inequalities (cuts) to tighten the LP relaxation via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class ValidInequalitiesFix(LLMBasedFix):
    """Adds valid inequalities (cover cuts, clique cuts, etc.) to tighten the LP relaxation."""

    name: ClassVar[str] = "valid_inequalities"
    focus_category: ClassVar[str] = "valid_inequalities"
