"""Fix: warm start from a greedy heuristic solution via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class WarmStartingFix(LLMBasedFix):
    """
    Adds a greedy heuristic to generate a feasible MIP start.

    Providing Gurobi with an initial incumbent immediately tightens the
    upper bound and enables aggressive pruning of the B&B tree.
    """

    name: ClassVar[str] = "warm_starting"
    focus_category: ClassVar[str] = "warm_starting"
