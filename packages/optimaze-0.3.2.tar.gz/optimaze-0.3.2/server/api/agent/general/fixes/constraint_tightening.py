"""Fix: constraint and bound tightening via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class ConstraintTighteningFix(LLMBasedFix):
    """
    Tightens constraint right-hand sides and variable bounds using
    problem-specific knowledge.

    Targets models with large MIP gaps where the LP relaxation is loose
    due to weak bounds rather than Big-M specifically.
    """

    name: ClassVar[str] = "constraint_tightening"
    focus_category: ClassVar[str] = "constraint_tightening"
