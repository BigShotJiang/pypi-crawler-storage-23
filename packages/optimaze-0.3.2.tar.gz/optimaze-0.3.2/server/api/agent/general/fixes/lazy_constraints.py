"""Fix: convert rarely-active constraints to lazy constraints via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class LazyConstraintsFix(LLMBasedFix):
    """
    Marks rarely-binding constraints as lazy (checked only at integer solutions).

    Reduces LP size at each B&B node, speeding up models with many constraints
    that are almost never tight (e.g. subtour elimination, big-M linking constraints).
    """

    name: ClassVar[str] = "lazy_constraints"
    focus_category: ClassVar[str] = "lazy_constraints"
