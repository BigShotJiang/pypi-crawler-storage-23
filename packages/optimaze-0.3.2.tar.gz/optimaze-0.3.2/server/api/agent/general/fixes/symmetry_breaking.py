"""Fix: symmetry-breaking constraints via LLM."""

from typing import ClassVar

from server.api.agent.general.fixes.base import LLMBasedFix


class SymmetryBreakingFix(LLMBasedFix):
    """Adds ordering / symmetry-breaking constraints for interchangeable variables."""

    name: ClassVar[str] = "symmetry_breaking"
    focus_category: ClassVar[str] = "symmetry_breaking"
