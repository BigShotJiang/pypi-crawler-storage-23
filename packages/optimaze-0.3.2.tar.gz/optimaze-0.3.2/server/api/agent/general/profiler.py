"""
ModelProfiler: Analyzes Gurobi model structure to guide improvement selection.

Uses hybrid approach:
1. Fast heuristics for initial classification
2. Deeper analysis only when heuristics are confident
"""

import re
from pathlib import Path
from typing import Optional, Union

import gurobipy as gp
import numpy as np
from gurobipy import GRB

from server.api.agent.general.types import (
    ProblemProfile,
    ProblemStructure,
    ProblemType,
)


class ModelProfiler:
    """Analyzes Gurobi models to create a comprehensive profile."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def log(self, msg: str):
        if self.verbose:
            print(f"[Profiler] {msg}")

    def profile(
        self,
        model_or_path: Union[gp.Model, str, Path],
        gurobi_log: Optional[str] = None,
    ) -> ProblemProfile:
        """
        Create a comprehensive profile of a Gurobi model.

        Args:
            model_or_path: Either a gp.Model object or path to .mps/.lp file
            gurobi_log: Optional Gurobi log output for additional metrics

        Returns:
            ProblemProfile with all detected characteristics
        """
        # Load model if path provided
        if isinstance(model_or_path, (str, Path)):
            self.log(f"Loading model from {model_or_path}")
            model = gp.read(str(model_or_path))
        else:
            model = model_or_path

        profile = ProblemProfile()

        # Basic stats
        self._extract_basic_stats(model, profile)

        # Variable analysis
        self._analyze_variables(model, profile)

        # Constraint analysis
        self._analyze_constraints(model, profile)

        # Objective analysis
        self._analyze_objective(model, profile)

        # Coefficient analysis
        self._analyze_coefficients(model, profile)

        # Determine problem type
        self._determine_problem_type(profile)

        # Structure detection (hybrid: fast heuristics)
        self._detect_structures_heuristic(model, profile)

        # Symmetry detection (if binary vars present)
        if profile.n_binary > 0:
            self._detect_symmetry(model, profile)

        # Constraint graph analysis
        self._analyze_constraint_graph(model, profile)

        # Parse log if provided
        if gurobi_log:
            self._parse_log(gurobi_log, profile)

        return profile

    def _extract_basic_stats(self, model: gp.Model, profile: ProblemProfile):
        """Extract basic model statistics."""
        profile.n_vars = model.NumVars
        profile.n_constrs = model.NumConstrs
        profile.n_nonzeros = model.NumNZs

        if profile.n_vars > 0 and profile.n_constrs > 0:
            profile.density = profile.n_nonzeros / (profile.n_vars * profile.n_constrs)
            profile.avg_vars_per_constr = profile.n_nonzeros / profile.n_constrs
            profile.avg_constrs_per_var = profile.n_nonzeros / profile.n_vars

        self.log(f"Basic: {profile.n_vars} vars, {profile.n_constrs} constrs, {profile.n_nonzeros} nzs")

    def _analyze_variables(self, model: gp.Model, profile: ProblemProfile):
        """Analyze variable types."""
        profile.n_binary = model.NumBinVars
        profile.n_integer = model.NumIntVars - model.NumBinVars  # NumIntVars includes binary
        profile.n_continuous = model.NumVars - model.NumIntVars

        # Count semi-continuous (need to iterate)
        n_semicont = 0
        for var in model.getVars():
            if var.VType == GRB.SEMICONT or var.VType == GRB.SEMIINT:
                n_semicont += 1
        profile.n_semicont = n_semicont

        self.log(f"Vars: {profile.n_continuous} cont, {profile.n_binary} bin, {profile.n_integer} int")

    def _analyze_constraints(self, model: gp.Model, profile: ProblemProfile):
        """Analyze constraint types."""
        profile.n_linear = model.NumConstrs
        profile.n_quadratic = model.NumQConstrs
        profile.n_sos = model.NumSOS
        profile.n_general = model.NumGenConstrs

        # Count indicator constraints (subset of general)
        n_indicator = 0
        for gc in model.getGenConstrs():
            if gc.GenConstrType == GRB.GENCONSTR_INDICATOR:
                n_indicator += 1
        profile.n_indicator = n_indicator

        self.log(f"Constrs: {profile.n_linear} lin, {profile.n_quadratic} quad, {profile.n_indicator} indicator")

    def _analyze_objective(self, model: gp.Model, profile: ProblemProfile):
        """Analyze objective function."""
        profile.obj_sense = "minimize" if model.ModelSense == GRB.MINIMIZE else "maximize"
        profile.obj_is_linear = model.NumQCNZs == 0 and not hasattr(model, 'getObjective') or \
                                 not hasattr(model.getObjective(), 'size')

        # Check for quadratic objective
        try:
            obj = model.getObjective()
            if hasattr(obj, 'size') and obj.size() > 0:
                profile.obj_is_quadratic = True
                profile.obj_is_linear = False
        except Exception:
            pass

    def _analyze_coefficients(self, model: gp.Model, profile: ProblemProfile):
        """Analyze coefficient ranges."""
        coefs = []
        rhs_vals = []

        # Get constraint matrix coefficients
        for constr in model.getConstrs():
            row = model.getRow(constr)
            for i in range(row.size()):
                coef = abs(row.getCoeff(i))
                if coef > 1e-10:
                    coefs.append(coef)
            rhs_vals.append(abs(constr.RHS))

        if coefs:
            profile.coef_min = min(coefs)
            profile.coef_max = max(coefs)
            profile.coef_range_ratio = profile.coef_max / max(profile.coef_min, 1e-10)

        if rhs_vals:
            profile.rhs_min = min(rhs_vals)
            profile.rhs_max = max(rhs_vals)

        self.log(f"Coef range: [{profile.coef_min:.2e}, {profile.coef_max:.2e}], ratio={profile.coef_range_ratio:.1e}")

    def _determine_problem_type(self, profile: ProblemProfile):
        """Determine high-level problem type."""
        has_integer = profile.n_binary > 0 or profile.n_integer > 0
        has_quadratic = profile.n_quadratic > 0 or profile.obj_is_quadratic

        if has_integer and has_quadratic:
            profile.problem_type = ProblemType.MIQCP
        elif has_integer:
            profile.problem_type = ProblemType.MILP
        elif has_quadratic:
            profile.problem_type = ProblemType.QP
        else:
            profile.problem_type = ProblemType.LP

        self.log(f"Problem type: {profile.problem_type.name}")

    def _detect_structures_heuristic(self, model: gp.Model, profile: ProblemProfile):
        """Fast heuristic detection of special structures."""
        structures = []

        # Network detection: all coefficients are -1, 0, or 1
        if self._is_network_like(model, profile):
            structures.append(ProblemStructure.NETWORK)
            self.log("Detected: NETWORK structure")

        # Knapsack detection: single constraint with all positive coefficients
        if self._has_knapsack_constraints(model, profile):
            structures.append(ProblemStructure.KNAPSACK)
            self.log("Detected: KNAPSACK constraints")

        # Set cover detection: binary vars, 0/1 coefficients, >= constraints
        if self._is_set_cover_like(model, profile):
            structures.append(ProblemStructure.SET_COVER)
            self.log("Detected: SET_COVER structure")

        # Assignment detection: binary vars, special structure
        if self._is_assignment_like(model, profile):
            structures.append(ProblemStructure.ASSIGNMENT)
            self.log("Detected: ASSIGNMENT structure")

        if not structures:
            structures.append(ProblemStructure.GENERAL)

        profile.detected_structures = structures

    def _is_network_like(self, model: gp.Model, profile: ProblemProfile) -> bool:
        """Check if model has network flow structure (coefficients in {-1, 0, 1})."""
        if profile.n_constrs == 0:
            return False

        sample_size = min(100, profile.n_constrs)
        constrs = model.getConstrs()[:sample_size]

        network_count = 0
        for constr in constrs:
            row = model.getRow(constr)
            is_network = True
            for i in range(row.size()):
                coef = row.getCoeff(i)
                if abs(coef) not in [0, 1] and abs(abs(coef) - 1) > 1e-6:
                    is_network = False
                    break
            if is_network:
                network_count += 1

        return network_count / sample_size > 0.8

    def _has_knapsack_constraints(self, model: gp.Model, profile: ProblemProfile) -> bool:
        """Check for knapsack-style constraints."""
        if profile.n_binary == 0:
            return False

        sample_size = min(50, profile.n_constrs)
        constrs = model.getConstrs()[:sample_size]

        knapsack_count = 0
        for constr in constrs:
            if constr.Sense != GRB.LESS_EQUAL:
                continue
            row = model.getRow(constr)
            all_positive = True
            all_binary = True
            for i in range(row.size()):
                if row.getCoeff(i) < 0:
                    all_positive = False
                    break
                var = row.getVar(i)
                if var.VType != GRB.BINARY:
                    all_binary = False
            if all_positive and all_binary and row.size() > 2:
                knapsack_count += 1

        return knapsack_count > sample_size * 0.3

    def _is_set_cover_like(self, model: gp.Model, profile: ProblemProfile) -> bool:
        """Check for set cover structure."""
        if profile.n_binary == 0:
            return False

        binary_ratio = profile.n_binary / profile.n_vars
        if binary_ratio < 0.8:
            return False

        # Check if most coefficients are 0 or 1
        sample_size = min(50, profile.n_constrs)
        constrs = model.getConstrs()[:sample_size]

        set_cover_count = 0
        for constr in constrs:
            row = model.getRow(constr)
            is_01 = True
            for i in range(row.size()):
                coef = row.getCoeff(i)
                if abs(coef) > 1e-6 and abs(coef - 1) > 1e-6:
                    is_01 = False
                    break
            if is_01:
                set_cover_count += 1

        return set_cover_count / sample_size > 0.7

    def _is_assignment_like(self, model: gp.Model, profile: ProblemProfile) -> bool:
        """Check for assignment problem structure."""
        if profile.n_binary == 0:
            return False

        # Assignment: n^2 binary vars, 2n equality constraints
        n_sqrt = int(np.sqrt(profile.n_binary))
        if abs(n_sqrt * n_sqrt - profile.n_binary) > n_sqrt:
            return False

        # Check constraint count roughly matches 2n
        expected_constrs = 2 * n_sqrt
        if abs(profile.n_constrs - expected_constrs) > expected_constrs * 0.2:
            return False

        return True

    def _detect_symmetry(self, model: gp.Model, profile: ProblemProfile):
        """Detect symmetry in binary variables (heuristic)."""
        if profile.n_binary < 10:
            profile.has_symmetry = False
            return

        # Heuristic: check if binary vars have similar bounds and appear in similar constraints
        vars_list = [v for v in model.getVars() if v.VType == GRB.BINARY]

        # Group by (lb, ub, obj_coef)
        groups = {}
        for var in vars_list[:min(500, len(vars_list))]:
            key = (round(var.LB, 2), round(var.UB, 2), round(var.Obj, 4))
            groups[key] = groups.get(key, 0) + 1

        # If many vars have identical properties, likely symmetry
        max_group = max(groups.values()) if groups else 0
        if max_group > profile.n_binary * 0.3 and max_group > 10:
            profile.has_symmetry = True
            profile.symmetry_groups = len([g for g in groups.values() if g > 5])
            self.log(f"Symmetry detected: {profile.symmetry_groups} groups")

    def _analyze_constraint_graph(self, model: gp.Model, profile: ProblemProfile):
        """Analyze constraint graph for decomposition opportunities."""
        if profile.n_vars > 10000 or profile.n_constrs > 5000:
            # Skip for large models - too expensive
            self.log("Skipping graph analysis (model too large)")
            return

        # Build variable-constraint adjacency
        var_to_constrs: dict[int, set[int]] = {i: set() for i in range(profile.n_vars)}

        for c_idx, constr in enumerate(model.getConstrs()):
            row = model.getRow(constr)
            for i in range(row.size()):
                var = row.getVar(i)
                var_to_constrs[var.index].add(c_idx)

        # Find connected components using union-find (iterative to avoid recursion)
        parent = list(range(profile.n_constrs))

        def find(x):
            # Iterative path compression
            root = x
            while parent[root] != root:
                root = parent[root]
            # Path compression
            while parent[x] != root:
                next_x = parent[x]
                parent[x] = root
                x = next_x
            return root

        def union(x, y):
            px, py = find(x), find(y)
            if px != py:
                parent[px] = py

        # Connect constraints that share variables
        for var_constrs in var_to_constrs.values():
            constrs_list = list(var_constrs)
            for i in range(1, len(constrs_list)):
                union(constrs_list[0], constrs_list[i])

        # Count components
        components = {}
        for i in range(profile.n_constrs):
            root = find(i)
            components[root] = components.get(root, 0) + 1

        profile.n_components = len(components)
        if components:
            largest = max(components.values())
            profile.largest_component_pct = largest / profile.n_constrs
            profile.is_block_diagonal = profile.n_components > 1 and profile.largest_component_pct < 0.9

        if profile.is_block_diagonal:
            self.log(f"Block diagonal: {profile.n_components} components")

    def _parse_log(self, log: str, profile: ProblemProfile):
        """Parse Gurobi log for additional metrics."""
        # Nodes
        nodes_match = re.search(r"Explored (\d+) nodes", log)
        if nodes_match:
            profile.log_nodes = int(nodes_match.group(1))

        # Runtime
        runtime_match = re.search(r"in ([\d.]+) seconds", log)
        if runtime_match:
            profile.log_runtime = float(runtime_match.group(1))

        # Gap
        gap_match = re.search(r"gap ([\d.]+)%", log)
        if gap_match:
            profile.log_gap = float(gap_match.group(1))

        # Presolve
        presolve_match = re.search(r"Presolve removed (\d+) rows and (\d+) columns", log)
        if presolve_match:
            profile.log_presolve_removed_rows = int(presolve_match.group(1))
            profile.log_presolve_removed_cols = int(presolve_match.group(2))
