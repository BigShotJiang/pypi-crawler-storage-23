"""
RepoScanner: Scans a repository to find Gurobi model code.

Uses Python's ast module to reliably find:
- gurobipy imports and aliases
- Model variable assignments
- optimize() call sites
- Entry points (files with __main__ blocks)
"""

import ast
import os
from pathlib import Path

from server.api.agent.general.repo_types import GurobiCallSite, RepoScanResult


class RepoScanner:
    """Scans a Python repository for Gurobi model usage."""

    def __init__(self, verbose: bool = False):
        self.verbose = verbose

    def log(self, msg: str):
        if self.verbose:
            print(f"[Scanner] {msg}")

    def scan(self, repo_dir: str) -> RepoScanResult:
        """
        Scan a repository for Gurobi usage.

        Args:
            repo_dir: Path to the cloned repository root.

        Returns:
            RepoScanResult with all discovered call sites and metadata.
        """
        result = RepoScanResult()

        # Find dependency files
        for name in ("requirements.txt", "pyproject.toml", "setup.py", "setup.cfg"):
            path = os.path.join(repo_dir, name)
            if os.path.isfile(path):
                result.dependency_files.append(path)

        # Walk all .py files
        py_files = self._find_python_files(repo_dir)
        self.log(f"Found {len(py_files)} Python files")

        for py_file in py_files:
            try:
                source = Path(py_file).read_text(encoding="utf-8", errors="replace")
                tree = ast.parse(source, filename=py_file)
            except SyntaxError:
                self.log(f"  Skipping {py_file} (syntax error)")
                continue

            file_info = self._analyze_file(py_file, source, tree)

            if file_info["has_gurobi"]:
                result.gurobi_files.append(py_file)
                result.call_sites.extend(file_info["call_sites"])

            if file_info["has_main"]:
                result.entry_points.append(py_file)

        # Rank call sites: prefer entry points with __main__
        result.call_sites = self._rank_call_sites(result.call_sites, result.entry_points, repo_dir)

        self.log(f"Gurobi files: {len(result.gurobi_files)}")
        self.log(f"Call sites: {len(result.call_sites)}")
        self.log(f"Entry points: {len(result.entry_points)}")

        return result

    def _find_python_files(self, repo_dir: str) -> list[str]:
        """Find all .py files, excluding venvs and hidden dirs."""
        py_files = []
        skip_dirs = {
            ".git", ".venv", "venv", "env", "__pycache__",
            "node_modules", ".tox", ".eggs", "build", "dist",
        }

        for root, dirs, files in os.walk(repo_dir):
            # Skip hidden and virtual environment directories
            dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".")]

            for f in files:
                if f.endswith(".py"):
                    py_files.append(os.path.join(root, f))

        return py_files

    def _analyze_file(self, file_path: str, source: str, tree: ast.Module) -> dict:
        """Analyze a single Python file for Gurobi usage."""
        info = {
            "has_gurobi": False,
            "has_main": False,
            "call_sites": [],
        }

        # Step 1: Find gurobipy imports and track aliases
        aliases = self._find_gurobi_imports(tree)
        if not aliases:
            # Check for __main__ even without gurobi
            info["has_main"] = self._has_main_block(tree)
            return info

        info["has_gurobi"] = True
        info["has_main"] = self._has_main_block(tree)

        # Step 2: Find Model() assignments
        model_vars = self._find_model_vars(tree, aliases)

        # Step 3: Find optimize() calls
        source_lines = source.splitlines()
        for model_var in model_vars:
            optimize_calls = self._find_optimize_calls(tree, model_var)
            for line_no in optimize_calls:
                if 0 < line_no <= len(source_lines):
                    line_text = source_lines[line_no - 1]
                    indent = line_text[: len(line_text) - len(line_text.lstrip())]
                else:
                    indent = "    "

                # Determine import style for this alias
                import_style, alias = self._get_import_info(aliases)

                call_site = GurobiCallSite(
                    file_path=file_path,
                    model_var_name=model_var,
                    optimize_line=line_no,
                    indent=indent,
                    gurobi_alias=alias,
                    import_style=import_style,
                )
                info["call_sites"].append(call_site)

        return info

    def _find_gurobi_imports(self, tree: ast.Module) -> list[dict]:
        """
        Find all gurobipy import statements.

        Returns list of dicts with:
          - style: "import_as" or "from_import"
          - alias: the alias used (e.g. "gp", "gurobipy", "Model")
          - names: list of imported names (for from-imports)
        """
        aliases = []

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for a in node.names:
                    if a.name == "gurobipy":
                        alias = a.asname or "gurobipy"
                        aliases.append({
                            "style": "import_as",
                            "alias": alias,
                            "names": [],
                        })

            elif isinstance(node, ast.ImportFrom):
                if node.module == "gurobipy":
                    names = [a.name for a in node.names]
                    alias = node.names[0].asname or node.names[0].name if node.names else "gurobipy"
                    aliases.append({
                        "style": "from_import",
                        "alias": alias,
                        "names": names,
                    })

        return aliases

    def _node_to_dotted_name(self, node: ast.expr) -> str | None:
        """Convert an AST node to a dotted name string, e.g. ast.Attribute -> 'self.model'."""
        if isinstance(node, ast.Name):
            return node.id
        if isinstance(node, ast.Attribute):
            parent = self._node_to_dotted_name(node.value)
            if parent:
                return f"{parent}.{node.attr}"
        return None

    def _find_model_vars(self, tree: ast.Module, aliases: list[dict]) -> list[str]:
        """Find variable names assigned to gp.Model() or Model() calls."""
        model_vars = []

        # Build patterns to match
        # e.g. gp.Model(), gurobipy.Model(), Model()
        model_call_patterns = set()
        for alias_info in aliases:
            if alias_info["style"] == "import_as":
                model_call_patterns.add((alias_info["alias"], "Model"))
            elif alias_info["style"] == "from_import":
                if "Model" in alias_info["names"]:
                    model_call_patterns.add((None, "Model"))

        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            if not isinstance(node.value, ast.Call):
                continue

            call = node.value
            matched = False

            # Check gp.Model(...)
            if isinstance(call.func, ast.Attribute):
                if isinstance(call.func.value, ast.Name):
                    for mod, attr in model_call_patterns:
                        if mod and call.func.value.id == mod and call.func.attr == attr:
                            matched = True
                            break

            # Check Model(...)
            elif isinstance(call.func, ast.Name):
                for mod, attr in model_call_patterns:
                    if mod is None and call.func.id == attr:
                        matched = True
                        break

            if matched:
                for target in node.targets:
                    name = self._node_to_dotted_name(target)
                    if name and name not in model_vars:
                        model_vars.append(name)

        # Also track reassignments: self.model = model, m2 = model, etc.
        if model_vars:
            known = set(model_vars)
            for node in ast.walk(tree):
                if not isinstance(node, ast.Assign):
                    continue
                # RHS must be a known model variable (simple name or dotted)
                rhs_name = self._node_to_dotted_name(node.value)
                if rhs_name not in known:
                    continue
                for target in node.targets:
                    lhs_name = self._node_to_dotted_name(target)
                    if lhs_name and lhs_name not in known:
                        model_vars.append(lhs_name)
                        known.add(lhs_name)

        # Also look for gp.read() assignments
        for alias_info in aliases:
            if alias_info["style"] == "import_as":
                for node in ast.walk(tree):
                    if not isinstance(node, ast.Assign):
                        continue
                    if not isinstance(node.value, ast.Call):
                        continue
                    call = node.value
                    if (isinstance(call.func, ast.Attribute)
                            and isinstance(call.func.value, ast.Name)
                            and call.func.value.id == alias_info["alias"]
                            and call.func.attr == "read"):
                        for target in node.targets:
                            name = self._node_to_dotted_name(target)
                            if name and name not in model_vars:
                                model_vars.append(name)

        return model_vars

    def _find_optimize_calls(self, tree: ast.Module, model_var: str) -> list[int]:
        """Find line numbers of model_var.optimize() calls."""
        lines = []

        for node in ast.walk(tree):
            if not isinstance(node, ast.Expr):
                continue
            if not isinstance(node.value, ast.Call):
                continue

            call = node.value
            if (isinstance(call.func, ast.Attribute)
                    and call.func.attr == "optimize"
                    and self._node_to_dotted_name(call.func.value) == model_var):
                lines.append(node.lineno)

        return lines

    def _has_main_block(self, tree: ast.Module) -> bool:
        """Check if file has an if __name__ == '__main__' block."""
        for node in ast.walk(tree):
            if isinstance(node, ast.If):
                # Check for: if __name__ == "__main__"
                test = node.test
                if isinstance(test, ast.Compare):
                    if (isinstance(test.left, ast.Name)
                            and test.left.id == "__name__"
                            and len(test.ops) == 1
                            and isinstance(test.ops[0], ast.Eq)
                            and len(test.comparators) == 1
                            and isinstance(test.comparators[0], ast.Constant)
                            and test.comparators[0].value == "__main__"):
                        return True
        return False

    def _get_import_info(self, aliases: list[dict]) -> tuple[str, str]:
        """Get the primary import style and alias."""
        # Prefer "import gurobipy as X" style
        for a in aliases:
            if a["style"] == "import_as":
                return a["style"], a["alias"]
        # Fall back to from-import
        for a in aliases:
            if a["style"] == "from_import":
                return a["style"], a["alias"]
        return "import_as", "gurobipy"

    def _rank_call_sites(
        self,
        call_sites: list[GurobiCallSite],
        entry_points: list[str],
        repo_dir: str,
    ) -> list[GurobiCallSite]:
        """
        Rank call sites by likelihood of being the main optimization script.

        Prefer:
        1. Files with __main__ that also have optimize() calls
        2. Files in root, scripts/, examples/
        3. Files with shorter paths (less deeply nested)
        """
        entry_set = set(entry_points)

        def score(cs: GurobiCallSite) -> tuple:
            rel_path = os.path.relpath(cs.file_path, repo_dir).replace("\\", "/")
            is_entry = cs.file_path in entry_set
            is_root = "/" not in rel_path.lstrip("./")
            is_preferred_dir = any(
                rel_path.startswith(d)
                for d in ("scripts/", "examples/", "bin/", "benchmarks/")
            )
            depth = rel_path.count("/")

            # Higher score = better (sorted descending)
            return (
                is_entry,          # Prefer entry points
                is_root,           # Prefer root-level files
                is_preferred_dir,  # Prefer standard dirs
                -depth,            # Prefer shallower paths
            )

        return sorted(call_sites, key=score, reverse=True)
