"""Analyzer: detects when the root LP solve is the runtime bottleneck."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class SlowRootLPAnalyzer(BaseAnalyzer):
    """
    Detects cases where the root LP (not B&B) dominates solve time.

    Characterised by long runtime combined with a low node count.
    Reformulation, presolve hints, or variable elimination may help.
    """

    name: ClassVar[str] = "slow_root_lp"

    # Minimum runtime (seconds) to flag
    runtime_threshold: ClassVar[float] = 10.0
    # Maximum node count to still consider root LP the bottleneck
    node_threshold: ClassVar[int] = 100

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        runtime = profile.log_runtime
        nodes = profile.log_nodes

        is_problem = runtime > self.runtime_threshold and nodes <= self.node_threshold

        if runtime > 60.0 and nodes <= self.node_threshold:
            context = (
                f"Very slow root LP ({runtime:.1f}s, only {nodes} B&B nodes) — "
                f"variable reformulation or presolve hints are critical"
            )
            severity = 1.0
        elif runtime > 30.0 and nodes <= self.node_threshold:
            context = (
                f"Slow root LP ({runtime:.1f}s, {nodes} nodes) — "
                f"reformulation or presolve improvements strongly recommended"
            )
            severity = 0.7
        elif is_problem:
            context = (
                f"Root LP may be a bottleneck ({runtime:.1f}s, {nodes} nodes) — "
                f"consider variable elimination or presolve hints"
            )
            severity = 0.4
        else:
            context = (
                f"Root LP time ({runtime:.1f}s) appears normal relative to node count ({nodes})"
            )
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={"runtime": runtime, "nodes": nodes},
        )
