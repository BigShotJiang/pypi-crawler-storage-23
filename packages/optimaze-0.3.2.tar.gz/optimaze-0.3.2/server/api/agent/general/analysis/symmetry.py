"""Analyzer: detects symmetry and high binary variable ratios."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class SymmetryAnalyzer(BaseAnalyzer):
    """
    Detects symmetry and high binary variable ratios that suggest symmetry-breaking
    constraints could reduce the B&B tree.

    Triggered by explicit symmetry detection in the profile OR a high ratio of
    binary variables (many interchangeable decision variables).
    """

    name: ClassVar[str] = "symmetry"

    # Minimum binary variables before ratio check matters
    min_binary: ClassVar[int] = 10
    # Binary ratio threshold for implicit symmetry hint
    binary_ratio_threshold: ClassVar[float] = 0.5

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        has_symmetry = profile.has_symmetry
        groups = profile.symmetry_groups
        n_binary = profile.n_binary
        binary_ratio = n_binary / profile.n_vars if profile.n_vars > 0 else 0.0
        high_binary_ratio = (
            binary_ratio >= self.binary_ratio_threshold
            and n_binary >= self.min_binary
        )

        is_problem = has_symmetry or high_binary_ratio

        if has_symmetry and groups > 0:
            context = (
                f"Symmetry detected ({groups} group(s)) — "
                f"ordering constraints or branching priorities should reduce B&B tree"
            )
            severity = 0.8
        elif high_binary_ratio:
            context = (
                f"High binary variable ratio ({binary_ratio:.0%}, {n_binary} binary vars) "
                f"— check for interchangeable variables where symmetry breaking could help"
            )
            severity = 0.5
        else:
            context = (
                f"No significant symmetry detected "
                f"({n_binary} binary vars, ratio {binary_ratio:.0%})"
            )
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={
                "has_symmetry": has_symmetry,
                "symmetry_groups": groups,
                "n_binary": n_binary,
                "binary_ratio": binary_ratio,
            },
        )
