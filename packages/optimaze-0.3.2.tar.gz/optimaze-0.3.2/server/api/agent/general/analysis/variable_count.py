"""Analyzer: detects models with high variable counts."""

from typing import ClassVar

from server.api.agent.general.analysis.base import AnalysisResult, BaseAnalyzer
from server.api.agent.general.types import ProblemProfile


class VariableCountAnalyzer(BaseAnalyzer):
    """
    Detects models with a large number of variables.

    Very large variable counts may benefit from variable reformulation,
    aggregation, or decomposition approaches.
    """

    name: ClassVar[str] = "variable_count"

    # Configurable threshold
    threshold: ClassVar[int] = 10_000

    def analyze(self, log: str, profile: ProblemProfile) -> AnalysisResult:
        count = profile.n_vars
        n_binary = profile.n_binary
        n_continuous = profile.n_continuous

        is_problem = count > self.threshold

        if count > 100_000:
            context = (
                f"Very large variable count ({count:,}: {n_binary} binary, "
                f"{n_continuous} continuous) — variable reformulation or aggregation recommended"
            )
            severity = 1.0
        elif count > 10_000:
            context = (
                f"Large variable count ({count:,}: {n_binary} binary, "
                f"{n_continuous} continuous) — consider reformulation"
            )
            severity = 0.6
        else:
            context = f"Variable count ({count:,}) within normal range"
            severity = 0.0

        return AnalysisResult(
            analyzer_name=self.name,
            is_problem=is_problem,
            context=context,
            severity=severity,
            details={
                "count": count,
                "n_binary": n_binary,
                "n_continuous": n_continuous,
            },
        )
