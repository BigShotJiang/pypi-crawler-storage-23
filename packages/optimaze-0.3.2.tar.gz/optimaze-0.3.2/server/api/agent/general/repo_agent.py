"""
RepoAgent: Main orchestrator for GitHub repo-based Gurobi improvement.

Flow:
  GitHub URL → Clone → Scan for gurobipy code → Setup sandbox →
  Run baseline (with Gurobi log capture) → Export .mps → Profile model →
  Parse logs for bottleneck-guided matching → Match improvements →
  Test each (modify source → run → revert) → Apply best → PR
"""

import os
import subprocess
import tempfile
from datetime import datetime

from server.api.agent.general.analysis import (
    BaseAnalyzer,
    CoeffRangeAnalyzer,
    ConstraintCountAnalyzer,
    DensityAnalyzer,
    MIPGapAnalyzer,
    NodeCountAnalyzer,
    SlowRootLPAnalyzer,
    SymmetryAnalyzer,
    VariableCountAnalyzer,
)
from server.api.agent.general.catalog import ImprovementCatalog
from server.api.agent.general.code_modifier import CodeModifier
from server.api.agent.general.decision import RuleBasedDecision
from server.api.agent.general.fixes import (
    BaseFix,
    BendersDecompositionFix,
    BigMFix,
    BranchingPrioritiesFix,
    ConstraintTighteningFix,
    LazyConstraintsFix,
    NewVariablesFix,
    RescaleFix,
    SolverParamFix,
    SymmetryBreakingFix,
    ValidInequalitiesFix,
    WarmStartingFix,
)
from server.api.agent.general.llm_advisor import LLMAdvisor, LLMAdvisorConfig
from server.api.agent.general.matcher import ImprovementMatcher
from server.api.agent.general.profiler import ModelProfiler
from server.api.agent.general.repo_pr_creator import RepoPRCreator
from server.api.agent.general.repo_types import (
    CallSiteResult,
    RepoAgentConfig,
    RepoAgentResult,
    SandboxRunResult,
)
from server.api.agent.general.sandbox import SandboxRunner
from server.api.agent.general.scanner import RepoScanner
from server.api.agent.general.types import BenchmarkResult


class RepoAgent:
    """
    Improves Gurobi solve performance in a GitHub repository.

    Clones the repo, finds optimize() calls, profiles the model,
    tests parameter improvements, and creates a PR with the best ones.
    """

    def __init__(self, config: RepoAgentConfig | None = None):
        self.config = config or RepoAgentConfig()
        self.scanner = RepoScanner(verbose=self.config.verbose)
        self.modifier = CodeModifier(verbose=self.config.verbose)
        self.profiler = ModelProfiler(verbose=self.config.verbose)
        self.catalog = ImprovementCatalog()
        self.matcher = ImprovementMatcher(self.catalog, verbose=self.config.verbose)

        # LLM advisor (graceful degradation if unavailable)
        self.llm_advisor = None
        if self.config.llm_enabled:
            api_key = self.config.llm_api_key or os.environ.get("ANTHROPIC_API_KEY", "")
            if api_key:
                self.llm_advisor = LLMAdvisor(
                    config=LLMAdvisorConfig(
                        api_key=api_key,
                        model=self.config.llm_model,
                    ),
                    verbose=self.config.verbose,
                )
                self.log("LLM advisor enabled")
            else:
                self.log("LLM advisor disabled (no API key)")

    def log(self, msg: str):
        if self.config.verbose:
            print(f"[RepoAgent] {msg}")

    def improve(self, github_url: str) -> RepoAgentResult:
        """
        Improve Gurobi performance in a GitHub repository.

        Args:
            github_url: GitHub repository URL (e.g. https://github.com/user/repo)

        Returns:
            RepoAgentResult with call site results and PR URL.
        """
        result = RepoAgentResult(github_url=github_url)

        self.log("=" * 60)
        self.log("REPO-BASED GUROBI IMPROVEMENT AGENT")
        self.log("=" * 60)
        self.log(f"Target: {github_url}")

        try:
            # Step 1: Clone
            clone_dir = self._clone_repo(github_url)
            result.clone_dir = clone_dir

            # Step 2: Scan
            self.log("\n[STEP 2] Scanning repository for Gurobi code...")
            scan_result = self.scanner.scan(clone_dir)

            if not scan_result.call_sites:
                result.error = "No Gurobi optimize() calls found in repository"
                self.log(f"  ERROR: {result.error}")
                return result

            self.log(f"  Found {len(scan_result.call_sites)} call site(s)")
            for cs in scan_result.call_sites:
                rel = os.path.relpath(cs.file_path, clone_dir)
                self.log(
                    f"    - {rel}:{cs.optimize_line} ({cs.model_var_name}.optimize())"
                )

            # Step 3: Setup sandbox
            self.log("\n[STEP 3] Setting up sandbox environment...")
            sandbox = SandboxRunner(
                repo_dir=clone_dir,
                verbose=self.config.verbose,
            )
            if not sandbox.setup(timeout=self.config.setup_timeout):
                result.error = "Failed to set up sandbox environment"
                self.log(f"  ERROR: {result.error}")
                return result

            # Step 4: Create branch + draft PR immediately (before any fixes)
            pr_creator = None
            if self.config.create_pr:
                self.log("\n[STEP 4] Creating branch and draft PR...")
                timestamp = datetime.now().strftime("%Y%m%d-%H%M")
                branch_name = f"{self.config.branch_prefix}/optimize-{timestamp}"
                pr_creator = RepoPRCreator(
                    repo_dir=clone_dir,
                    verbose=self.config.verbose,
                )
                pr_url = pr_creator.create_draft_pr(branch_name, self.config.base_branch)
                if pr_url:
                    result.pr_url = pr_url
                    self.log(f"  Draft PR created: {pr_url}")
                else:
                    self.log("  Draft PR creation failed, continuing without PR")
                    pr_creator = None

            # Step 5: Process each call site
            self.log(
                f"\n[STEP 5] Processing {len(scan_result.call_sites)} call site(s)..."
            )

            for i, call_site in enumerate(scan_result.call_sites):
                rel = os.path.relpath(call_site.file_path, clone_dir)
                self.log(
                    f"\n  --- Call site {i+1}: {rel}:{call_site.optimize_line} ---"
                )

                # Find the entry point for this call site
                if self.config.entry_point:
                    ep = self.config.entry_point
                    # Resolve relative to clone dir if not absolute
                    if not os.path.isabs(ep):
                        ep = os.path.join(clone_dir, ep)
                    entry_point = ep
                    self.log(f"  Using provided entry point: {entry_point}")
                else:
                    entry_point = self._find_entry_point(
                        call_site, scan_result.entry_points
                    )
                if not entry_point:
                    self.log("  No entry point found, skipping")
                    continue

                cs_result = self._process_call_site(
                    call_site, entry_point, sandbox, clone_dir, pr_creator=pr_creator
                )
                result.call_site_results.append(cs_result)

            # Step 6: Calculate overall speedup
            speedups = [
                cs.best_speedup
                for cs in result.call_site_results
                if cs.best_speedup > 0
            ]
            if speedups:
                result.overall_speedup = max(speedups)

            # Step 7: Finalize PR (update title/body, mark ready)
            if pr_creator:
                self.log("\n[STEP 7] Finalizing PR...")
                pr_creator.finalize_pr(result)

            result.success = True

        except Exception as e:
            result.error = str(e)
            self.log(f"\nERROR: {e}")
            import traceback

            traceback.print_exc()

        self._print_summary(result)
        return result

    def _clone_repo(self, github_url: str) -> str:
        """Clone the repository and return the clone directory."""
        self.log("\n[STEP 1] Cloning repository...")

        if self.config.clone_dir:
            clone_dir = self.config.clone_dir
        else:
            clone_dir = tempfile.mkdtemp(prefix="gurobi_agent_")

        # Try gh clone first, fall back to git clone
        repo_name = github_url.rstrip("/").split("/")[-1].replace(".git", "")
        target_dir = os.path.join(clone_dir, repo_name)

        if os.path.isdir(target_dir):
            self.log(f"  Using existing clone at {target_dir}")
            return target_dir

        # Try git clone
        proc = subprocess.run(
            ["git", "clone", "--depth", "1", github_url, target_dir],
            capture_output=True,
            text=True,
            timeout=120,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"Failed to clone {github_url}: {proc.stderr}")

        self.log(f"  Cloned to {target_dir}")
        return target_dir

    def _find_entry_point(
        self,
        call_site,
        entry_points: list[str],
    ) -> str | None:
        """
        Find the entry point script that exercises a call site.

        Preference order:
        1. run.py in the same directory (often handles data generation)
        2. The call site file itself if it has __main__
        3. First entry point from scanner
        4. The call site file as last resort
        """
        call_site_dir = os.path.dirname(call_site.file_path)

        # Prefer run.py in the same directory (handles data generation)
        run_py = os.path.join(call_site_dir, "run.py")
        if os.path.isfile(run_py):
            self.log("  Found run.py in same directory, using as entry point")
            return run_py

        # Direct match: file has __main__
        if call_site.file_path in entry_points:
            return call_site.file_path

        # Heuristic: return the first entry point (already ranked by scanner)
        if entry_points:
            return entry_points[0]

        # Last resort: try the file itself
        return call_site.file_path

    def _process_call_site(
        self,
        call_site,
        entry_point: str,
        sandbox: SandboxRunner,
        clone_dir: str,
        pr_creator=None,
    ) -> CallSiteResult:
        """
        Process a single call site using an iterative analysis → decide → fix loop.

        Each iteration:
          1. Analyze the current log + profile for problems
          2. Use rule-based decision to select ordered fixes
          3. Try each fix; keep it if it improves, revert if not
          4. Repeat until no improvement or max_iterations reached

        If pr_creator is provided, each fix attempt (kept or reverted) is committed
        and pushed so the trial-and-error process is visible on the live PR branch.
        """
        cs_result = CallSiteResult(
            call_site=call_site,
            entry_point=entry_point,
        )

        # --- Baseline run with profiling hooks ---
        self.log("  [4a] Running baseline with profiling hooks...")
        hook_mod = self.modifier.apply_combined_hook(call_site)
        try:
            baseline_run = sandbox.run_script(
                entry_point,
                timeout=self.config.script_timeout,
            )
        finally:
            self.modifier.revert(hook_mod)

        if baseline_run.returncode != 0 and baseline_run.runtime is None:
            self.log(f"  Baseline failed: {baseline_run.stderr[:500]}")
            return cs_result

        cs_result.baseline = baseline_run
        cs_result.gurobi_log = baseline_run.gurobi_log

        if baseline_run.gurobi_log:
            log_preview = baseline_run.gurobi_log[:200].replace("\n", " | ")
            self.log(
                f"  Gurobi log captured ({len(baseline_run.gurobi_log)} chars): "
                f"{log_preview}..."
            )
        else:
            self.log("  No Gurobi log captured")

        self.log(
            f"  Baseline: {baseline_run.runtime:.3f}s, "
            f"status={baseline_run.solver_status}, "
            f"nodes={baseline_run.node_count}"
        )

        # --- Profile model ---
        self.log("  [4b] Profiling model...")
        mps_path = sandbox.get_mps_path()
        if not mps_path:
            self.log("  No MPS file exported, skipping profiling")
            return cs_result

        try:
            profile = self.profiler.profile(
                mps_path,
                gurobi_log=baseline_run.gurobi_log,
            )
            cs_result.profile = profile
            self.log(
                f"  Profile: {profile.problem_type.name}, "
                f"{profile.n_vars} vars, {profile.n_constrs} constrs"
            )
            if profile.detected_structures:
                self.log(f"  Structures: {[s.name for s in profile.detected_structures]}")
            if profile.log_nodes > 0:
                self.log(
                    f"  Log metrics: {profile.log_nodes} nodes, "
                    f"{profile.log_runtime:.1f}s, gap={profile.log_gap:.1f}%"
                )
        except Exception as e:
            self.log(f"  Profiling failed: {e}")
            return cs_result

        # --- Iterative improvement loop ---
        fix_registry = self._build_fix_registry()
        decision = RuleBasedDecision()
        analyzers = self._build_analyzers()
        current_run = baseline_run
        max_iter = self.config.max_iterations
        rel_path = os.path.relpath(call_site.file_path, clone_dir)

        for iteration in range(max_iter):
            self.log(f"  [Iteration {iteration + 1}/{max_iter}] Analyzing log...")

            # Step 1: Analyze
            analysis_results = [a.analyze(current_run.gurobi_log, profile) for a in analyzers]
            problems = [r for r in analysis_results if r.is_problem]
            if problems:
                self.log(f"  Problems detected: {[r.analyzer_name for r in problems]}")
                for r in problems:
                    self.log(f"    [{r.analyzer_name}] {r.context}")
            else:
                self.log("  No problems detected, trying solver_params as fallback...")
                fix_names = ["solver_params"]
                # Only try once, then stop
                if iteration > 0:
                    self.log("  Already tried fallback, stopping.")
                    break

            # Step 2: Decide
            if problems:
                fix_names = decision.decide(analysis_results)
            self.log(f"  Fixes to try (in order): {fix_names}")

            found_improvement = False

            # Step 3: Apply fixes one at a time
            for fix_name in fix_names:
                fix = fix_registry.get(fix_name)
                if fix is None:
                    continue

                self.log(f"    Trying fix: {fix_name}")
                fix_result = fix.apply(
                    call_site, analysis_results, self.llm_advisor, profile
                )

                if not fix_result.success:
                    self.log(
                        f"    Fix '{fix_name}' could not be applied: {fix_result.description}"
                    )
                    continue

                # Commit the applied change so it's visible on the live PR branch
                if pr_creator:
                    pr_creator.commit_and_push(
                        [rel_path],
                        f"Try: {fix_result.fix_name}\n\n{fix_result.description}",
                    )

                # Apply timing hook on top of the fix (searches for optimize() by
                # pattern so it works even if the fix shifted line numbers)
                timing_mod = self.modifier.apply_timing_hook_to_current(call_site)
                try:
                    run_result = sandbox.run_script(
                        entry_point,
                        timeout=self.config.script_timeout,
                    )
                finally:
                    # Revert timing hook, leaving the fix in place
                    if timing_mod:
                        self.modifier.revert(timing_mod)

                speedup = self._compute_speedup(current_run, run_result)

                bench = BenchmarkResult(
                    improvement_name=fix_result.fix_name,
                    runtime_seconds=run_result.runtime or 0.0,
                    nodes_explored=run_result.node_count or 0,
                    status=run_result.solver_status or "UNKNOWN",
                    objective_value=run_result.obj_value,
                    speedup_pct=speedup,
                    is_winner=speedup > 0,
                )
                cs_result.benchmarks.append(bench)

                if speedup > 0:
                    self.log(
                        f"    Fix '{fix_name}' improved by {speedup:+.1f}% — keeping"
                    )
                    current_run = run_result
                    # Refresh profile with updated log
                    try:
                        updated_mps = sandbox.get_mps_path()
                        if updated_mps:
                            profile = self.profiler.profile(
                                updated_mps,
                                gurobi_log=current_run.gurobi_log,
                            )
                    except Exception:
                        pass  # keep previous profile if refresh fails

                    if speedup > cs_result.best_speedup:
                        cs_result.best_improvement = fix_result.fix_name
                        cs_result.best_speedup = speedup

                    found_improvement = True
                    # Continue to try more fixes additively this iteration
                else:
                    self.log(
                        f"    Fix '{fix_name}' did not improve ({speedup:+.1f}%) — reverting"
                    )
                    if fix_result.modification:
                        self.modifier.revert(fix_result.modification)
                    # Commit the revert so it's visible on the live PR branch
                    if pr_creator:
                        pr_creator.commit_and_push(
                            [rel_path],
                            f"Revert: {fix_result.fix_name} ({speedup:+.1f}% — no improvement)",
                        )

            if not found_improvement:
                self.log("  No fixes improved performance, stopping.")
                break

        if cs_result.best_improvement:
            self.log(
                f"  Best overall: {cs_result.best_improvement} "
                f"({cs_result.best_speedup:+.1f}%)"
            )
        else:
            self.log("  No improvements found for this call site")

        return cs_result

    def _build_analyzers(self) -> list[BaseAnalyzer]:
        """Build the list of analyzers to run each iteration."""
        return [
            CoeffRangeAnalyzer(),
            VariableCountAnalyzer(),
            ConstraintCountAnalyzer(),
            NodeCountAnalyzer(),
            MIPGapAnalyzer(),
            SymmetryAnalyzer(),
            SlowRootLPAnalyzer(),
            DensityAnalyzer(),
        ]

    def _build_fix_registry(self) -> dict[str, BaseFix]:
        """Build the fix registry, reusing catalog and matcher from self."""
        return {
            "big_m": BigMFix(),
            "rescale": RescaleFix(),
            "benders": BendersDecompositionFix(),
            "new_variables": NewVariablesFix(),
            "solver_params": SolverParamFix(self.catalog, self.matcher),
            "symmetry_breaking": SymmetryBreakingFix(),
            "valid_inequalities": ValidInequalitiesFix(),
            "branching_priorities": BranchingPrioritiesFix(),
            "warm_starting": WarmStartingFix(),
            "lazy_constraints": LazyConstraintsFix(),
            "constraint_tightening": ConstraintTighteningFix(),
        }

    def _compute_speedup(
        self,
        baseline: SandboxRunResult,
        run_result: SandboxRunResult,
    ) -> float:
        """Compute percentage speedup of run_result vs baseline. Positive = faster."""
        if baseline.runtime is not None and run_result.runtime is not None and baseline.runtime > 0:
            return (baseline.runtime - run_result.runtime) / baseline.runtime * 100
        return 0.0

    def _test_improvement(
        self,
        call_site,
        entry_point: str,
        sandbox: SandboxRunner,
        baseline: SandboxRunResult,
        improvement,
    ) -> BenchmarkResult:
        """Test a single improvement: modify source, run, revert."""
        # Apply params + timing hook
        param_mod = self.modifier.apply_params(call_site, improvement.gurobi_params)

        # We need to recalculate the optimize line since params were inserted
        # The timing hook needs to go on the new optimize line position
        # Simpler: revert params, apply timing hook on original, then apply params before that
        self.modifier.revert(param_mod)

        # Apply timing hook first (on original source)
        timing_mod = self.modifier.apply_timing_hook(call_site)

        # Now apply params on top (before the hook block)
        # The hook replaced the optimize line, so we need to insert params
        # before the hook block. The hook starts at the original optimize line.
        param_mod = self.modifier.apply_params(call_site, improvement.gurobi_params)

        try:
            run_result = sandbox.run_script(
                entry_point,
                timeout=self.config.script_timeout,
            )
        finally:
            # Revert both modifications (param_mod was applied last, revert first)
            # But both modified the same file. param_mod's original_content is
            # the timing_mod's modified content. We need to revert to the very original.
            # The timing_mod has the true original.
            self.modifier.revert(timing_mod)

        # Build benchmark result
        if run_result.runtime is not None and baseline.runtime is not None:
            speedup = (baseline.runtime - run_result.runtime) / baseline.runtime * 100
        else:
            speedup = 0.0

        return BenchmarkResult(
            improvement_name=improvement.name,
            runtime_seconds=run_result.runtime or 0.0,
            nodes_explored=run_result.node_count or 0,
            status=run_result.solver_status or "UNKNOWN",
            objective_value=run_result.obj_value,
            speedup_pct=speedup,
            is_winner=speedup > 0,
        )

    def _test_llm_improvement(
        self,
        call_site,
        entry_point: str,
        sandbox: SandboxRunner,
        baseline: SandboxRunResult,
        llm_improvement,
    ) -> BenchmarkResult:
        """Test an LLM code improvement: apply changes + timing hook, run, revert."""
        # Apply LLM changes + timing hook in one step
        combined_mod = self.llm_advisor.apply_improvement_with_timing_hook(
            llm_improvement, call_site, self.modifier
        )

        try:
            run_result = sandbox.run_script(
                entry_point,
                timeout=self.config.script_timeout,
            )
        finally:
            # Revert to true original (before LLM changes)
            self.modifier.revert(combined_mod)

        # Calculate speedup
        if run_result.runtime is not None and baseline.runtime is not None:
            speedup = (baseline.runtime - run_result.runtime) / baseline.runtime * 100
        else:
            speedup = 0.0

        # Verify objective value if the improvement claims to preserve semantics
        is_winner = speedup > 0
        if is_winner and llm_improvement.preserves_semantics:
            if (
                baseline.obj_value is not None
                and run_result.obj_value is not None
                and baseline.obj_value != 0
            ):
                obj_diff_pct = (
                    abs(
                        (run_result.obj_value - baseline.obj_value) / baseline.obj_value
                    )
                    * 100
                )
                if obj_diff_pct > 0.01:
                    self.log(
                        f"      Objective mismatch: {obj_diff_pct:.4f}% "
                        f"(baseline={baseline.obj_value}, got={run_result.obj_value})"
                    )
                    is_winner = False

        return BenchmarkResult(
            improvement_name=llm_improvement.name,
            runtime_seconds=run_result.runtime or 0.0,
            nodes_explored=run_result.node_count or 0,
            status=run_result.solver_status or "UNKNOWN",
            objective_value=run_result.obj_value,
            speedup_pct=speedup,
            is_winner=is_winner,
        )

    def _print_summary(self, result: RepoAgentResult):
        """Print final summary."""
        self.log("\n" + "=" * 60)
        self.log("RESULTS SUMMARY")
        self.log("=" * 60)

        if result.error:
            self.log(f"\nError: {result.error}")
            return

        for i, cs in enumerate(result.call_site_results):
            rel = os.path.relpath(cs.call_site.file_path, result.clone_dir)
            self.log(f"\nCall site {i+1}: {rel}:{cs.call_site.optimize_line}")

            if cs.baseline:
                self.log(f"  Baseline: {cs.baseline.runtime:.3f}s")

            if cs.benchmarks:
                self.log(f"  Tested {len(cs.benchmarks)} fix(es):")
                for b in sorted(cs.benchmarks, key=lambda x: -x.speedup_pct):
                    marker = ">>>" if b.improvement_name == cs.best_improvement else "   "
                    self.log(
                        f"  {marker} {b.improvement_name:<30} "
                        f"{b.runtime_seconds:.3f}s ({b.speedup_pct:+.1f}%)"
                    )

            if cs.best_improvement:
                self.log(f"  BEST: {cs.best_improvement} ({cs.best_speedup:+.1f}%)")

        if result.pr_url:
            self.log(f"\nPR: {result.pr_url}")

        self.log(f"\nOverall speedup: {result.overall_speedup:+.1f}%")
        self.log(f"Success: {result.success}")
