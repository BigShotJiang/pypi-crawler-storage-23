"""
RepoPRCreator: Creates pull requests on target repositories with Gurobi improvements.

Live PR flow:
  1. create_draft_pr()  — branch + empty commit + push + draft PR (immediately)
  2. commit_and_push()  — called after each fix attempt (kept or reverted)
  3. finalize_pr()      — updates title/body with benchmark table, marks PR ready

Legacy flow (create_pr) retained for backward compatibility.
"""

import os
import subprocess
from datetime import datetime

from server.api.agent.general.repo_types import RepoAgentResult


class RepoPRCreator:
    """Creates PRs with Gurobi parameter improvements on target repos."""

    def __init__(self, repo_dir: str, verbose: bool = False):
        self.repo_dir = repo_dir
        self.verbose = verbose
        self._branch_name: str = ""  # set by create_draft_pr, used by commit_and_push

    def log(self, msg: str):
        if self.verbose:
            print(f"[PRCreator] {msg}")

    def _run_git(self, *args) -> tuple[int, str, str]:
        """Run a git command in the repo directory."""
        result = subprocess.run(
            ["git", *args],
            cwd=self.repo_dir,
            capture_output=True,
            text=True,
        )
        return result.returncode, result.stdout.strip(), result.stderr.strip()

    def _run_gh(self, *args) -> tuple[int, str, str]:
        """Run a gh CLI command in the repo directory."""
        try:
            result = subprocess.run(
                ["gh", *args],
                cwd=self.repo_dir,
                capture_output=True,
                text=True,
            )
            return result.returncode, result.stdout.strip(), result.stderr.strip()
        except FileNotFoundError:
            return 1, "", "GitHub CLI (gh) is not installed. Install from https://cli.github.com/"

    def check_prerequisites(self) -> tuple[bool, str]:
        """Check that git and gh are available."""
        ret, _, err = self._run_git("status")
        if ret != 0:
            return False, f"Not a git repo or git unavailable: {err}"

        ret, _, err = self._run_gh("auth", "status")
        if ret != 0:
            return False, f"GitHub CLI not authenticated: {err}"

        return True, "OK"

    # ------------------------------------------------------------------
    # Live PR flow (new)
    # ------------------------------------------------------------------

    def create_draft_pr(
        self,
        branch_name: str,
        base_branch: str = "main",
    ) -> str | None:
        """
        Create the PR branch and a draft PR immediately, before any fixes are tried.

        Steps:
          git checkout -b {branch_name}
          git commit --allow-empty -m "GurobiAgent: analysis in progress"
          git push -u origin {branch_name}
          gh pr create --draft ...

        Returns:
            PR URL if successful, None otherwise.
        """
        ok, msg = self.check_prerequisites()
        if not ok:
            self.log(f"Prerequisites failed: {msg}")
            return None

        # 1. Create branch
        ret, _, err = self._run_git("checkout", "-b", branch_name)
        if ret != 0:
            self.log(f"Failed to create branch: {err}")
            return None

        # 2. Empty commit so we can push
        ret, _, err = self._run_git(
            "commit", "--allow-empty", "-m", "GurobiAgent: analysis in progress"
        )
        if ret != 0:
            self.log(f"Failed to create empty commit: {err}")
            return None

        # 3. Push branch
        ret, _, err = self._run_git("push", "-u", "origin", branch_name)
        if ret != 0:
            self.log(f"Failed to push branch: {err}")
            return None

        self._branch_name = branch_name

        # 4. Create draft PR
        body = (
            "GurobiAgent is analyzing this repository and testing optimization improvements.\n\n"
            "Fix attempts will appear as commits on this branch as the agent runs.\n\n"
            "_This PR will be updated with full benchmark results when analysis is complete._"
        )
        ret, out, err = self._run_gh(
            "pr", "create",
            "--draft",
            "--title", "GurobiAgent: optimization in progress",
            "--body", body,
            "--base", base_branch,
            "--head", branch_name,
        )
        if ret != 0:
            self.log(f"Failed to create draft PR: {err}")
            return None

        pr_url = out.strip()
        self.log(f"Draft PR created: {pr_url}")
        return pr_url

    def commit_and_push(
        self,
        rel_files: list[str],
        message: str,
    ) -> bool:
        """
        Stage the given relative file paths, commit, and push.

        Non-fatal: logs failures and returns False without raising.
        Returns True if successful (or nothing to commit), False on error.
        """
        short_msg = message.splitlines()[0][:70]
        self.log(f"Committing: {short_msg}")
        try:
            # Normalize to forward slashes so git handles them correctly on Windows
            files = [f.replace("\\", "/") for f in rel_files]

            # Stage files
            for f in files:
                ret, _, err = self._run_git("add", f)
                if ret != 0:
                    self.log(f"Failed to stage {f}: {err}")
                    return False

            # Show git status so we can see what's staged vs unstaged
            _, status_out, _ = self._run_git("status", "--short")
            self.log(f"git status: {status_out!r}")

            # Check if anything is staged (rc=0 → nothing staged)
            ret, _, _ = self._run_git("diff", "--cached", "--quiet")
            if ret == 0:
                self.log("Nothing staged, skipping commit")
                return True

            # Commit
            ret, _, err = self._run_git("commit", "-m", message)
            if ret != 0:
                self.log(f"Failed to commit: {err}")
                return False

            # Push — use explicit remote + branch so it works from shallow clones
            # even if the tracking config isn't read correctly in a subprocess
            if self._branch_name:
                ret, _, err = self._run_git("push", "origin", self._branch_name)
            else:
                ret, _, err = self._run_git("push")
            if ret != 0:
                self.log(f"Failed to push: {err}")
                return False

            self.log(f"Pushed: {short_msg}")
            return True
        except Exception as e:
            self.log(f"commit_and_push error: {e}")
            return False

    def finalize_pr(self, result: RepoAgentResult) -> None:
        """
        Update the draft PR with final benchmark results and mark it ready.

        Calls gh pr edit to update title/body, then gh pr ready to un-draft.
        """
        title = self._build_pr_title(result)
        body = self._build_pr_body(result)

        ret, _, err = self._run_gh(
            "pr", "edit",
            "--title", title,
            "--body", body,
        )
        if ret != 0:
            self.log(f"Failed to update PR title/body: {err}")
            return

        ret, _, err = self._run_gh("pr", "ready")
        if ret != 0:
            self.log(f"Failed to mark PR ready: {err}")
            return

        self.log("PR finalized and marked ready")

    # ------------------------------------------------------------------
    # Legacy flow (kept for backward compatibility)
    # ------------------------------------------------------------------

    def create_pr(
        self,
        result: RepoAgentResult,
        branch_prefix: str = "gurobi-agent",
        base_branch: str = "main",
    ) -> str | None:
        """
        Create a PR with the Gurobi parameter improvements (legacy, end-of-run flow).

        The modified .py files should already be in place (applied by RepoAgent).

        Args:
            result: The RepoAgentResult with benchmark data.
            branch_prefix: Prefix for the branch name.
            base_branch: Target branch for the PR.

        Returns:
            PR URL if successful, None otherwise.
        """
        ok, msg = self.check_prerequisites()
        if not ok:
            self.log(f"Prerequisites failed: {msg}")
            return None

        timestamp = datetime.now().strftime("%Y%m%d-%H%M")
        branch_name = f"{branch_prefix}/optimize-{timestamp}"

        # 1. Create branch
        ret, _, err = self._run_git("checkout", "-b", branch_name)
        if ret != 0:
            self.log(f"Failed to create branch: {err}")
            return None

        # 2. Stage modified files
        modified_files = set()
        for cs in result.call_site_results:
            if cs.best_improvement:
                rel = os.path.relpath(cs.call_site.file_path, self.repo_dir)
                modified_files.add(rel)

        if not modified_files:
            self.log("No files to commit")
            return None

        for f in modified_files:
            ret, _, err = self._run_git("add", f)
            if ret != 0:
                self.log(f"Failed to stage {f}: {err}")
                return None

        # 3. Commit
        commit_msg = self._build_commit_message(result)
        ret, _, err = self._run_git("commit", "-m", commit_msg)
        if ret != 0:
            self.log(f"Failed to commit: {err}")
            return None

        # 4. Push
        ret, _, err = self._run_git("push", "-u", "origin", branch_name)
        if ret != 0:
            self.log(f"Failed to push: {err}")
            return None

        # 5. Create PR
        title = self._build_pr_title(result)
        body = self._build_pr_body(result)

        ret, out, err = self._run_gh(
            "pr", "create",
            "--title", title,
            "--body", body,
            "--base", base_branch,
        )
        if ret != 0:
            self.log(f"Failed to create PR: {err}")
            return None

        return out  # PR URL

    # ------------------------------------------------------------------
    # PR content builders
    # ------------------------------------------------------------------

    def _build_pr_title(self, result: RepoAgentResult) -> str:
        """Build a concise PR title."""
        if result.overall_speedup > 0:
            return f"Optimize Gurobi solver ({result.overall_speedup:+.1f}%)"
        return "GurobiAgent: no improvements found"

    def _build_pr_body(self, result: RepoAgentResult) -> str:
        """Build a rich PR body with per-fix attempt history."""
        lines = []
        lines.append("## Gurobi Solver Optimization")
        lines.append("")
        lines.append(
            "This PR adds optimized Gurobi solver parameters to improve solve performance. "
            "Parameters were selected by profiling the model structure and testing "
            "improvements via automated benchmarking."
        )
        lines.append("")

        for cs in result.call_site_results:
            rel = os.path.relpath(cs.call_site.file_path, self.repo_dir)
            lines.append(f"### `{rel}` — Fix Attempts")
            lines.append("")

            if cs.baseline:
                lines.append(
                    f"**Baseline:** {cs.baseline.runtime:.3f}s "
                    f"(status: {cs.baseline.solver_status}, "
                    f"nodes: {cs.baseline.node_count})"
                )
            if cs.profile:
                p = cs.profile
                lines.append(
                    f"**Model:** {p.problem_type.name} | "
                    f"{p.n_vars} vars | {p.n_constrs} constrs | "
                    f"{p.n_binary} binary"
                )
            lines.append("")

            if cs.benchmarks:
                lines.append("| Fix | Runtime | Speedup | Result |")
                lines.append("|-----|---------|---------|--------|")
                for b in cs.benchmarks:
                    if b.is_winner:
                        fix_label = f"{b.improvement_name} **KEPT**"
                    else:
                        fix_label = f"{b.improvement_name} ~~reverted~~"
                    lines.append(
                        f"| {fix_label} | {b.runtime_seconds:.3f}s | "
                        f"{b.speedup_pct:+.1f}% | {b.status} |"
                    )
            else:
                lines.append("_No fixes attempted._")

            lines.append("")

        lines.append("---")
        lines.append("*Generated by [GurobiAgent](https://github.com/anthropics/gurobi-agent)*")

        return "\n".join(lines)

    def _build_commit_message(self, result: RepoAgentResult) -> str:
        """Build a descriptive commit message (used by legacy create_pr)."""
        parts = ["Optimize Gurobi solver parameters\n"]

        for cs in result.call_site_results:
            if cs.best_improvement:
                rel = os.path.relpath(cs.call_site.file_path, self.repo_dir)
                parts.append(
                    f"- {rel}: {cs.best_improvement} ({cs.best_speedup:+.1f}% speedup)"
                )
                if cs.best_params:
                    for k, v in cs.best_params.items():
                        parts.append(f"  {k}={v}")

        parts.append("\nGenerated by GurobiAgent")
        return "\n".join(parts)
