"""
General-purpose Gurobi Formulation Improvement Agent.

This agent works with ANY Gurobi model to automatically find
formulation improvements that speed up solve time.

Usage (in-process):
    from server.api.agent.general import GurobiAgent
    agent = GurobiAgent()
    result = agent.improve(model)  # or agent.improve("model.mps")

Usage (repo-based):
    from server.api.agent.general import RepoAgent, RepoAgentConfig
    agent = RepoAgent(RepoAgentConfig(create_pr=True))
    result = agent.improve("https://github.com/user/repo")
"""

# Gurobipy-dependent exports — only available when gurobipy is installed
try:
    from server.api.agent.general.agent import AgentConfig, GurobiAgent
    from server.api.agent.general.catalog import Improvement, ImprovementCatalog
    from server.api.agent.general.matcher import ImprovementMatcher
    from server.api.agent.general.profiler import ModelProfiler, ProblemProfile
    from server.api.agent.general.repo_agent import RepoAgent
    from server.api.agent.general.repo_types import RepoAgentConfig

    __all__ = [
        "GurobiAgent",
        "AgentConfig",
        "ModelProfiler",
        "ProblemProfile",
        "ImprovementCatalog",
        "Improvement",
        "ImprovementMatcher",
        "RepoAgent",
        "RepoAgentConfig",
    ]
except ImportError:
    # gurobipy not installed (e.g. cloud server) — submodules still importable directly
    __all__ = []
