"""Optimaze - AI-powered optimization model tuning."""

__version__ = "0.3.2"
