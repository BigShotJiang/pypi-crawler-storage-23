# How The Optimization Industry Works

## Traditional Workflow

### Step 1: Build Model (days/weeks)
OR Engineer writes optimization model
- Define variables, constraints, objective
- Usually in Python (gurobipy) or AMPL/GAMS

### Step 2: Run Solver (seconds to hours)
```
model.optimize()
```
- Gurobi/CPLEX solves the problem
- Takes 30 seconds... or 6 hours

### Step 3: Too Slow? Manual Tuning (hours/days)
Engineer tries to speed it up:

| Trial | What They Try | Result |
|-------|---------------|--------|
| 1 | "Maybe MIPFocus=2?" | Still slow |
| 2 | "Try more cuts?" | Worse |
| 3 | "Tighten bounds?" | Slightly better |
| 4 | "Reformulate constraint X?" | Better! |
| ... | ... | ... |
| 15 | Finally acceptable | Done |

Each trial = 30 min to hours of waiting

---

## The Pain Points

| Problem | Impact |
|---------|--------|
| **Trial and error** | Engineers spend days guessing what helps |
| **No systematic approach** | "Let me try random things" |
| **Expertise required** | Need PhD-level OR knowledge |
| **Slow feedback loops** | Each test takes 30+ minutes |
| **Knowledge silos** | "John knows how to tune this, but he left" |

---

# What Our Agent Does

## The New Workflow

### Step 1: Build Model
OR Engineer writes optimization model (same as before)

### Step 2: Run Agent (minutes)
```
agent.improve(model)

[Profile]  Analyzing structure... network, 50K vars
[Match]    Selecting improvements... 5 candidates
[Smoke]    Quick tests... 3 look promising
[Bench]    Full benchmark... disaggregation +24%

→ "Use Presolve=2, found 24% speedup"
```

### Step 3: Apply Recommendation (seconds)
```python
model.Params.Presolve = 2
model.optimize()  # 24% faster
```

---

# How Our Agent Works (Technical)

## Layer 1: Model Profiling

What the profiler extracts:
```
n_vars: 50000
n_binary: 2000
n_constraints: 10000
density: 0.02 (sparse)
coef_range: 1e6 (big-M detected)
structure: network
has_symmetry: true
```

**Why it matters:** Different problems need different tuning. Network problems ≠ knapsack problems.

## Layer 2: Rule-Based Matching

Rules map profile → improvements:

| If... | Then try... |
|-------|-------------|
| nodes > 1000 | tighter_bounds, more_cuts |
| constraints > 5000 | Presolve=2 |
| structure == network | Method=primal |
| has_symmetry | Symmetry=2, symmetry breaking |

**Why it matters:** We don't test everything blindly. We test what's likely to help.

## Layer 3: Smoke Tests

Quick test with small time limit:
- Run each improvement for 5 seconds
- If already worse than baseline → skip
- Only keep promising candidates

**Why it matters:** Filters out bad options without wasting time.

## Layer 4: Full Benchmarking

Serious test on promising candidates:
- Run full benchmark
- Measure actual speedup percentage
- Return best result with exact numbers

**Why it matters:** Every recommendation is backed by real measured speedup.

---

# What Makes Us Different

| Traditional | Our Agent |
|-------------|-----------|
| Human guesses | Systematic testing |
| 1 thing at a time | Parallel smoke tests |
| No structure analysis | Detects network, symmetry, etc. |
| Trial and error | Rule-based candidate selection |
| "Try this" | "This gives 24% speedup (verified)" |
| Takes days | Takes minutes |

---

# The 30-Second Pitch

> "OR engineers spend days tuning Gurobi models by trial and error.
>
> Our agent analyzes your model structure, tests the right improvements automatically, and tells you exactly what settings give the best speedup.
>
> Every recommendation is benchmarked - no guessing."
