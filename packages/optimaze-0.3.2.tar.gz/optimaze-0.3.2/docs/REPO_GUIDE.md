# Repository Compatibility Guide

How to make any Gurobi repository work with the optimization agent.

## Quick Check: Will My Repo Work?

Run this checklist:

- [ ] Has a `requirements.txt` with `gurobipy`
- [ ] Has a Python file with `import gurobipy` (any alias works)
- [ ] Has `model = gp.Model(...)` **inline in a file** (not hidden in a function)
- [ ] Has `model.optimize()` call
- [ ] Has `if __name__ == "__main__":` block
- [ ] Model runs and completes in < 5 minutes

If all boxes checked, just run:
```bash
./optimize https://github.com/your/repo
```

---

## Repository Structure Requirements

### Minimal Working Example

```
my-optimization-repo/
├── requirements.txt      # REQUIRED: must have gurobipy
├── solve.py              # Main script (any name works)
├── data.json             # Optional: data files
└── README.md             # Optional
```

### solve.py - What the Scanner Looks For

```python
#!/usr/bin/env python3
import gurobipy as gp  # ✅ Scanner detects this import

def main():
    # ✅ Scanner finds this Model() assignment
    model = gp.Model("MyModel")

    # Build your model...
    x = model.addVar(vtype=gp.GRB.BINARY, name="x")
    model.setObjective(x, gp.GRB.MAXIMIZE)

    # ✅ Scanner finds this optimize() call
    model.optimize()

    print(f"Objective: {model.ObjVal}")

# ✅ Scanner detects this entry point
if __name__ == "__main__":
    main()
```

### requirements.txt

```
gurobipy>=11.0.0
numpy>=1.24.0
# Add any other dependencies your model needs
```

---

## Scanner Detection Rules

The agent uses AST parsing to find:

### 1. Gurobi Imports (any of these work)
```python
import gurobipy as gp          # ✅ Preferred
import gurobipy                # ✅ Works
from gurobipy import Model     # ✅ Works
from gurobipy import *         # ⚠️ Works but not recommended
```

### 2. Model Creation (MUST be a direct assignment)
```python
# ✅ WORKS - Direct assignment
model = gp.Model("name")

# ✅ WORKS - Attribute assignment
self.model = gp.Model("name")

# ❌ FAILS - Hidden in function return
model = create_model()  # Scanner can't trace this!

# ❌ FAILS - Model from external file
model = gp.read("model.mps")  # Reading .mps files works though
```

### 3. Optimize Call
```python
model.optimize()      # ✅ Direct call
self.model.optimize() # ✅ Attribute call
m.optimize()          # ✅ Any variable name
```

### 4. Entry Point
```python
if __name__ == "__main__":  # ✅ Required for auto-detection
    main()
```

---

## Common Issues and Fixes

### Issue 1: "No call sites found"

**Symptom:** Scanner reports 0 call sites

**Cause:** Model is created in a factory function

```python
# ❌ BAD - Model hidden in function
def create_model():
    model = gp.Model()
    return model

model = create_model()  # Scanner can't trace this
```

**Fix:** Move Model() creation to main script

```python
# ✅ GOOD - Model created directly
model = gp.Model()
build_constraints(model)  # Pass model to helper
model.optimize()
```

### Issue 2: "No entry points found"

**Symptom:** Script works but agent can't run it

**Cause:** Missing `if __name__ == "__main__":`

**Fix:** Add entry point block

```python
def main():
    # your code
    pass

if __name__ == "__main__":
    main()
```

### Issue 3: "Timeout during baseline"

**Symptom:** Agent times out before getting results

**Cause:** Model takes too long to solve

**Fix:** Use `--timeout` flag with higher value

```bash
./optimize https://github.com/user/repo --timeout 600
```

Or make your test problem smaller for faster iteration.

### Issue 4: "Model infeasible" or wrong results

**Symptom:** Baseline fails or gives unexpected results

**Cause:** Missing data files or wrong paths

**Fix:** Use relative paths and include all data files

```python
# ✅ GOOD - Relative to script
import os
data_path = os.path.join(os.path.dirname(__file__), "data.json")
```

### Issue 5: Agent doesn't detect improvements

**Symptom:** Agent runs but finds 0% improvement

**Cause:** Model already solves very fast (< 100ms)

**Fix:** Make the problem harder:
- Add more variables/constraints
- Larger data
- Tighter tolerances

---

## Adapting Existing Repositories

### Step-by-Step Conversion

**Original structure:**
```
my-project/
├── src/
│   ├── model.py          # Model definition
│   ├── solver.py         # Solve logic
│   └── utils.py
├── data/
│   └── input.json
└── main.py               # Entry point
```

**Conversion steps:**

#### 1. Create a standalone solve.py

```python
#!/usr/bin/env python3
"""
Standalone solver for optimization agent.
"""
import json
import os
import gurobipy as gp

def main():
    # Load data
    data_path = os.path.join(os.path.dirname(__file__), "data", "input.json")
    with open(data_path) as f:
        data = json.load(f)

    # Create model DIRECTLY (not via function call)
    model = gp.Model("MyProblem")

    # Build model using your existing logic
    # ... copy/adapt from src/model.py ...

    # Solve
    model.optimize()

    # Print result
    if model.Status == 2:
        print(f"Optimal: {model.ObjVal}")
    else:
        print(f"Status: {model.Status}")

if __name__ == "__main__":
    main()
```

#### 2. Update requirements.txt

Make sure it's at repo root:
```
gurobipy>=11.0.0
# ... other deps
```

#### 3. Test locally first

```bash
cd my-project
python solve.py  # Should complete without errors
```

#### 4. Push and run agent

```bash
git add -A && git commit -m "Add standalone solver for optimization agent"
git push

./optimize https://github.com/user/my-project
```

---

## Command Reference

### Basic Usage

```bash
# Optimize and create PR
./optimize https://github.com/user/repo

# Optimize without PR (just print results)
./optimize https://github.com/user/repo --no-pr

# Specify entry point manually
./optimize https://github.com/user/repo --entry-point solve.py

# Increase timeout for large models
./optimize https://github.com/user/repo --timeout 600

# All options
./optimize https://github.com/user/repo \
    --entry-point solve.py \
    --timeout 600 \
    --max-improvements 10 \
    --no-pr
```

### Options

| Flag | Default | Description |
|------|---------|-------------|
| `--entry-point` | auto | Path to solver script (relative to repo root) |
| `--timeout` | 120 | Max seconds per model run |
| `--max-improvements` | 8 | Max improvements to test per iteration |
| `--no-pr` | false | Don't create GitHub PR |
| `--quiet` | false | Reduce output verbosity |

---

## Example: Converting a Real Repository

### Before: Complex Multi-file Structure

```
facility-location/
├── src/
│   ├── __init__.py
│   ├── model_builder.py    # def build_model() -> Model
│   ├── data_loader.py      # def load_data() -> dict
│   └── solver.py           # def solve(model) -> Solution
├── data/
│   └── facilities.csv
├── main.py
└── requirements.txt
```

**main.py (original):**
```python
from src.model_builder import build_model
from src.data_loader import load_data
from src.solver import solve

data = load_data("data/facilities.csv")
model = build_model(data)  # ❌ Scanner can't trace this!
solution = solve(model)
```

### After: Agent-Compatible Structure

**solve.py (new file):**
```python
#!/usr/bin/env python3
"""Standalone solver for optimization agent."""
import os
import csv
import gurobipy as gp

def main():
    # Inline data loading
    data_path = os.path.join(os.path.dirname(__file__), "data", "facilities.csv")
    with open(data_path) as f:
        facilities = list(csv.DictReader(f))

    # ✅ Model created DIRECTLY
    model = gp.Model("FacilityLocation")

    # Build model (adapted from src/model_builder.py)
    n = len(facilities)
    x = model.addVars(n, vtype=gp.GRB.BINARY, name="x")
    # ... rest of model building ...

    # ✅ Direct optimize call
    model.optimize()

    print(f"Objective: {model.ObjVal}")

if __name__ == "__main__":
    main()
```

Now the agent can trace: `import gurobipy` → `model = gp.Model()` → `model.optimize()` → `__main__`

---

## Troubleshooting Checklist

If the agent isn't working:

1. **Check scanner output:**
   ```
   [Scanner] Found 2 Python files
   [Scanner] Gurobi files: 1
   [Scanner] Call sites: 1      # Should be >= 1
   [Scanner] Entry points: 2    # Should be >= 1
   ```

2. **Verify model creation is visible:**
   ```bash
   grep -n "gp.Model\|Model(" solve.py
   # Should show line with model = gp.Model(...)
   ```

3. **Check entry point:**
   ```bash
   grep -n "__main__" solve.py
   # Should show if __name__ == "__main__":
   ```

4. **Test locally:**
   ```bash
   cd /path/to/cloned/repo
   pip install -r requirements.txt
   python solve.py
   # Should complete without errors
   ```

5. **Check Gurobi license:**
   ```bash
   python -c "import gurobipy; m = gurobipy.Model(); print('OK')"
   ```

---

## FAQ

**Q: Can I use a Jupyter notebook?**
A: No, convert to a .py script first.

**Q: Does it work with PuLP/OR-Tools/CVXPY?**
A: No, only Gurobi (gurobipy) is supported.

**Q: Can I test on a private repo?**
A: Yes, as long as `gh auth` has access.

**Q: What if my model takes 30+ minutes?**
A: The agent tests improvements with your full model. Long solve times mean slow iteration. Consider creating a smaller test case.

**Q: Will it break my model?**
A: No, changes are made on a branch and submitted as a PR. Your main branch is unchanged until you merge.
