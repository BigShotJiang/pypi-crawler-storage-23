# Демо

Скриншоты из примера Django-проекта в `examples/sample/`.

## Список команд

Главная страница показывает все обнаруженные management-команды, сгруппированные по приложениям:

![Список команд](_content/command-list.png)

## Формы команд

Каждая команда получает динамически сгенерированную форму на основе её аргументов argparse.

### Текстовые аргументы

Строковые поля ввода, позиционные аргументы и поля с несколькими значениями (`nargs`):

```python
def add_arguments(self, parser):
    parser.add_argument('name', type=str, help='Your name (positional, required)')
    parser.add_argument('--greeting', type=str, default='Hello', help='Greeting phrase')
    parser.add_argument('--title', type=str, help='Optional title (e.g. Mr, Ms)')
    parser.add_argument('--tags', nargs='+', type=str, help='One or more tags')
    parser.add_argument('--extras', nargs='*', type=str, help='Zero or more extra values')
```

![Форма с текстовыми аргументами](_content/command-form-text.png)

### Аргументы с выбором

Выпадающие списки, сгенерированные из параметра `choices`:

```python
def add_arguments(self, parser):
    parser.add_argument('environment', type=str,
                        choices=['dev', 'staging', 'production'],
                        help='Target environment (positional choice)')
    parser.add_argument('--log-level', type=str,
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='INFO', help='Logging level')
    parser.add_argument('--format', type=str,
                        choices=['json', 'csv', 'xml', 'yaml'],
                        default='json', help='Output format')
    parser.add_argument('--priority', type=int,
                        choices=[1, 2, 3, 4, 5],
                        default=3, help='Task priority (1=highest, 5=lowest)')
```

![Форма с выбором](_content/command-form-choices.png)

### Булевы флаги

Чекбоксы для аргументов вида `--flag` / `--no-flag`:

```python
def add_arguments(self, parser):
    parser.add_argument('--dry-run', action='store_true',
                        help='Simulate without making changes')
    parser.add_argument('--verbose', action='store_true',
                        help='Enable verbose output')
    parser.add_argument('--no-color-output', action='store_true',
                        help='Disable colored output')
    parser.add_argument('--no-backup', action='store_true',
                        help='Skip backup creation')
    parser.add_argument('--confirmed', action='store_true',
                        help='Skip confirmation prompt')
```

![Форма с булевыми аргументами](_content/command-form-boolean.png)

### Path / Загрузка файлов

Виджеты загрузки файлов для аргументов типа `Path` — загрузите файл:

```python
from pathlib import Path

def add_arguments(self, parser):
    parser.add_argument('input_file', type=Path,
                        help='Input file to process (positional, required)')
    parser.add_argument('--output-file', type=Path,
                        help='Optional output file path')
    parser.add_argument('--config', type=Path,
                        help='Optional configuration file')
```

![Форма с Path-аргументами](_content/command-form-path.png)

Или переключитесь в текстовый режим для ввода пути строкой:

![Текстовый режим Path](_content/command-form-path-text.png)

## Результаты выполнения

После отправки формы отображается вывод stdout/stderr.

### Результат текстовой команды

![Результат команды](_content/command-result.png)

### Результат загрузки файла

Результат обработки загруженного файла:

![Результат загрузки файла](_content/command-result-file.png)

## Интеграция с админкой

Команды отображаются в списке приложений Django-админки наряду с другими зарегистрированными приложениями:

![Список приложений админки](_content/admin-app-list.png)
