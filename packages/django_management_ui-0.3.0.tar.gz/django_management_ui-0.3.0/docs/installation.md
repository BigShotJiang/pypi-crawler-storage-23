# Installation

## Install the package

```bash
pip install django-management-ui
```

## Add to INSTALLED_APPS

```python
INSTALLED_APPS = [
    ...
    "management_ui",
]
```

## Add URL configuration

```python
# urls.py
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", include("management_ui.urls")),
    path("admin/", admin.site.urls),
]
```

!!! important
    The `management_ui.urls` include must come **before** `admin.site.urls` so its URL patterns take priority.

That's it. Navigate to `/admin/commands/` to see all available commands.
