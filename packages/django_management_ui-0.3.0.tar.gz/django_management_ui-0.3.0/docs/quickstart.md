# Quick Start

After [installation](installation.md), visit `/admin/commands/` as a superuser.

## What you'll see

1. **Command list** — all registered management commands grouped by app
2. **Command form** — click any command to see a dynamically generated form with all its arguments
3. **Execution result** — submit the form to run the command and see stdout/stderr output

## Example

Suppose you have a management command `clearsessions`. In the admin panel:

1. Find `clearsessions` in the command list
2. Click it — the form shows no arguments (this command takes none)
3. Click "Execute" — you see the output and execution time

For commands with arguments, the form renders appropriate widgets automatically:

- Boolean flags → checkboxes
- Choices → dropdowns
- Numbers → number inputs
- `Path` arguments → file upload or text path input

## Access control

Only superusers can access the commands interface. Regular staff users will get a 403 response.
