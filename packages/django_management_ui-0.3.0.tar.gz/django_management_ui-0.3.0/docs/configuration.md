# Configuration

All settings are optional. The app works out of the box with sensible defaults.

## Allowed commands

Control which commands are visible in the UI. Only commands in this allowlist will be shown and executable.

```python
# settings.py (production)
MANAGEMENT_UI = {
    "COMMANDS": ["migrate", "collectstatic", "clearsessions"],
}
```

Default: no filter (all commands visible). If `COMMANDS` key is absent, all commands are allowed.

This is an allowlist approach — only explicitly listed commands are accessible. For development environments, omit the `COMMANDS` key to allow all commands.

## Execution timeout

Limit how long a command can run before being terminated.

```python
# settings.py
ADMIN_COMMANDS_TIMEOUT = 60  # seconds
```

Default: `30` seconds. Set to `0` or `None` to disable timeout (not recommended).

The command runs in a separate thread via `ThreadPoolExecutor`. If it exceeds the timeout, the UI returns an error with any partial output captured so far.

## Output truncation

Limit the size of captured stdout/stderr to prevent the browser from choking on huge outputs.

```python
# settings.py
ADMIN_COMMANDS_OUTPUT_HEAD_LINES = 200   # keep first N lines
ADMIN_COMMANDS_OUTPUT_TAIL_LINES = 200   # keep last N lines
```

Default: `500` for both head and tail.

When output exceeds `head + tail` lines, the middle is replaced with a truncation notice showing total line count.

## All settings at a glance

| Setting | Default | Description |
|---|---|---|
| `MANAGEMENT_UI["COMMANDS"]` | no filter | Allowlist of command names (omit for all) |
| `ADMIN_COMMANDS_TIMEOUT` | `30` | Max execution time in seconds (0 = no limit) |
| `ADMIN_COMMANDS_OUTPUT_HEAD_LINES` | `500` | Lines to keep from beginning of output |
| `ADMIN_COMMANDS_OUTPUT_TAIL_LINES` | `500` | Lines to keep from end of output |
