# Установка

## Установите пакет

```bash
pip install django-management-ui
```

## Добавьте в INSTALLED_APPS

```python
INSTALLED_APPS = [
    ...
    "management_ui",
]
```

## Настройте URL-маршруты

```python
# urls.py
from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path("admin/", include("management_ui.urls")),
    path("admin/", admin.site.urls),
]
```

!!! important
    Подключение `management_ui.urls` должно быть **перед** `admin.site.urls`, чтобы его URL-паттерны имели приоритет.

Готово. Перейдите на `/admin/commands/`, чтобы увидеть все доступные команды.
