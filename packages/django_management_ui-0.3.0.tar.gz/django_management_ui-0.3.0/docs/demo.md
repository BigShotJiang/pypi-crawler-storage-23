# Demo

Screenshots from the example Django project included in `examples/sample/`.

## Command List

The main page shows all discovered management commands grouped by app:

![Command list](_content/command-list.png)

## Command Forms

Each command gets a dynamically generated form based on its argparse arguments.

### Text Arguments

String inputs, positional args, and multi-value fields (`nargs`):

```python
def add_arguments(self, parser):
    parser.add_argument('name', type=str, help='Your name (positional, required)')
    parser.add_argument('--greeting', type=str, default='Hello', help='Greeting phrase')
    parser.add_argument('--title', type=str, help='Optional title (e.g. Mr, Ms)')
    parser.add_argument('--tags', nargs='+', type=str, help='One or more tags')
    parser.add_argument('--extras', nargs='*', type=str, help='Zero or more extra values')
```

![Text args form](_content/command-form-text.png)

### Choice Arguments

Dropdowns generated from `choices` parameter:

```python
def add_arguments(self, parser):
    parser.add_argument('environment', type=str,
                        choices=['dev', 'staging', 'production'],
                        help='Target environment (positional choice)')
    parser.add_argument('--log-level', type=str,
                        choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'],
                        default='INFO', help='Logging level')
    parser.add_argument('--format', type=str,
                        choices=['json', 'csv', 'xml', 'yaml'],
                        default='json', help='Output format')
    parser.add_argument('--priority', type=int,
                        choices=[1, 2, 3, 4, 5],
                        default=3, help='Task priority (1=highest, 5=lowest)')
```

![Choice args form](_content/command-form-choices.png)

### Boolean Flags

Checkboxes for `--flag` / `--no-flag` style arguments:

```python
def add_arguments(self, parser):
    parser.add_argument('--dry-run', action='store_true',
                        help='Simulate without making changes')
    parser.add_argument('--verbose', action='store_true',
                        help='Enable verbose output')
    parser.add_argument('--no-color-output', action='store_true',
                        help='Disable colored output')
    parser.add_argument('--no-backup', action='store_true',
                        help='Skip backup creation')
    parser.add_argument('--confirmed', action='store_true',
                        help='Skip confirmation prompt')
```

![Boolean args form](_content/command-form-boolean.png)

### Path / File Upload

File upload widgets for `Path`-type arguments — upload a file:

```python
from pathlib import Path

def add_arguments(self, parser):
    parser.add_argument('input_file', type=Path,
                        help='Input file to process (positional, required)')
    parser.add_argument('--output-file', type=Path,
                        help='Optional output file path')
    parser.add_argument('--config', type=Path,
                        help='Optional configuration file')
```

![Path args form](_content/command-form-path.png)

Or switch to text input mode to enter a path as a string:

![Path args text mode](_content/command-form-path-text.png)

## Execution Results

After submitting a form, stdout/stderr output is displayed.

### Text command result

![Command result](_content/command-result.png)

### File upload result

Result of processing an uploaded file:

![File upload result](_content/command-result-file.png)

## Admin Integration

Commands appear in the Django admin app list alongside other registered apps:

![Admin app list](_content/admin-app-list.png)
