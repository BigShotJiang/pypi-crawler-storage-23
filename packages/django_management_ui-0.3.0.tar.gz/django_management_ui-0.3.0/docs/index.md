# django-management-ui

Run any Django management command from the admin panel. No models, no migrations — just install and go.

The app introspects argparse definitions of your commands and dynamically builds forms with appropriate widgets: text inputs, checkboxes, dropdowns, number fields, file uploads for `Path` arguments.

## Features

- Automatic discovery of all registered management commands
- Dynamic form generation from argparse argument types
- File upload with temp file lifecycle for `Path` arguments
- Grouped display: command-specific args + collapsible BaseCommand options
- Output capture (stdout/stderr) with execution time
- Superuser-only access
- Appears on the Django Admin index page in the app list as "Commands" section

## Requirements

- Python >= 3.11
- Django >= 4.2

## License

MIT
