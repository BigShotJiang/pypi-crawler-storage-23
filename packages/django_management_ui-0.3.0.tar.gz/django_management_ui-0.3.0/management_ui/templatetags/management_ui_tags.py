"""Custom template filters for management_ui app."""
from django import template

register = template.Library()


@register.filter
def get_item(obj, key):
    """
    Access form field by name: {{ form|get_item:field_name }}

    Args:
        obj: Dict-like object (e.g., Django form)
        key: Key to access

    Returns:
        Value at key, or None if not found
    """
    try:
        return obj[key]
    except (KeyError, TypeError):
        return None
