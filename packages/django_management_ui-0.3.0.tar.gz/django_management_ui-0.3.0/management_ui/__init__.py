"""
Django Management UI - Reusable app for running management commands from Django Admin.
"""

__version__ = "0.1.0"
