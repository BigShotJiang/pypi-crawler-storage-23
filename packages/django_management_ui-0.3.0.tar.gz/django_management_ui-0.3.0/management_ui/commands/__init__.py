"""
Management commands introspection and execution module.

Public API:
- Introspection: discover_commands, introspect_command
- Form generation: build_command_form
- Execution: execute_command
- Views: CommandListView, CommandFormView, superuser_required
- Data classes: CommandInfo, CommandSchema, ArgumentInfo, CommandResult
"""

from .conf import get_allowed_commands, is_command_allowed
from .executor import CommandResult, execute_command
from .forms import build_command_form
from .introspection import (
    ArgumentInfo,
    CommandSchema,
    CommandInfo,
    discover_commands,
    introspect_command,
)
from .views import CommandFormView, CommandListView, superuser_required

__all__ = [
    # Data classes
    'ArgumentInfo',
    'CommandSchema',
    'CommandInfo',
    'CommandResult',
    # Functions
    'get_allowed_commands',
    'is_command_allowed',
    'discover_commands',
    'introspect_command',
    'build_command_form',
    'execute_command',
    # Views
    'CommandListView',
    'CommandFormView',
    'superuser_required',
]
