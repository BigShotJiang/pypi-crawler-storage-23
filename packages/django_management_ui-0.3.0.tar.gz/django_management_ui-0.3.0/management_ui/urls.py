"""
URL patterns for Admin Extension.

Include these URLs in your project's urls.py:
    path("admin/", include("management_ui.urls")),
"""

from django.urls import path

from .commands import CommandFormView, CommandListView

app_name = "management_ui"

urlpatterns = [
    path("commands/", CommandListView.as_view(), name="command_list"),
    path("commands/<str:command_name>/", CommandFormView.as_view(), name="command_form"),
]
