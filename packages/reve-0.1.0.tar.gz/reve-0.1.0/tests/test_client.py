"""Tests for reve._client module."""

import os
import pytest
import responses

from reve._client import ReveClient
from reve.exceptions import (
    ReveAPIError,
    ReveAuthenticationError,
    ReveBudgetExhaustedError,
    ReveRateLimitError,
    ReveValidationError,
)


class TestReveClientInit:
    def test_explicit_params(self):
        client = ReveClient(
            api_token="tok123",
            api_url="https://custom.api.com",
            proxy_authorization="proxy-val",
        )
        assert client.api_token == "tok123"
        assert client.api_url == "https://custom.api.com"
        assert client.proxy_authorization == "proxy-val"

    def test_env_vars(self, monkeypatch):
        monkeypatch.setenv("REVE_API_TOKEN", "env-tok")
        monkeypatch.setenv("REVE_MONOLITH_LOCATION", "https://env.api.com")
        monkeypatch.setenv("REVE_PROXY_AUTHORIZATION", "env-proxy")
        client = ReveClient()
        assert client.api_token == "env-tok"
        assert client.api_url == "https://env.api.com"
        assert client.proxy_authorization == "env-proxy"

    def test_defaults(self, monkeypatch):
        monkeypatch.delenv("REVE_API_TOKEN", raising=False)
        monkeypatch.delenv("REVE_MONOLITH_LOCATION", raising=False)
        monkeypatch.delenv("REVE_PROXY_AUTHORIZATION", raising=False)
        client = ReveClient()
        assert client.api_token is None
        assert client.api_url == "https://api.reve.com"
        assert client.proxy_authorization is None

    def test_trailing_slash_stripped(self):
        client = ReveClient(api_url="https://api.reve.com/")
        assert client.api_url == "https://api.reve.com"


class TestReveClientHeaders:
    def test_headers_with_auth(self):
        client = ReveClient(api_token="tok123")
        headers = client._headers()
        assert headers["Authorization"] == "Bearer tok123"
        assert headers["Accept"] == "application/json"

    def test_headers_with_proxy(self):
        client = ReveClient(api_token="tok", proxy_authorization="proxy-val")
        headers = client._headers()
        assert headers["proxy-authorization"] == "proxy-val"

    def test_headers_custom_accept(self):
        client = ReveClient(api_token="tok")
        headers = client._headers(accept="image/jpeg")
        assert headers["Accept"] == "image/jpeg"


class TestReveClientPost:
    @responses.activate
    def test_post_json(self):
        responses.add(
            responses.POST,
            "https://api.reve.com/v1/image/rating/",
            json={"ok": True},
            status=200,
        )
        client = ReveClient(api_token="tok")
        result = client.post("/v1/image/rating/", {"request_id": "r1", "rating": 80})
        assert result == {"ok": True}

    @responses.activate
    def test_post_image(self):
        responses.add(
            responses.POST,
            "https://api.reve.com/v1/image/create/",
            body=b"\xff\xd8\xff\xe0fake-jpeg",
            status=200,
            headers={"x-reve-request-id": "req-1"},
        )
        client = ReveClient(api_token="tok")
        raw, headers = client.post("/v1/image/create/", {"prompt": "test"}, accept="image/jpeg")
        assert raw == b"\xff\xd8\xff\xe0fake-jpeg"
        assert headers["x-reve-request-id"] == "req-1"


class TestReveClientErrors:
    @responses.activate
    def test_401_raises_auth_error(self):
        responses.add(responses.POST, "https://api.reve.com/v1/test/", json={"message": "bad token"}, status=401)
        client = ReveClient(api_token="bad")
        with pytest.raises(ReveAuthenticationError):
            client.post("/v1/test/", {})

    @responses.activate
    def test_402_raises_budget_error(self):
        responses.add(responses.POST, "https://api.reve.com/v1/test/", json={"message": "no credits"}, status=402)
        client = ReveClient(api_token="tok")
        with pytest.raises(ReveBudgetExhaustedError):
            client.post("/v1/test/", {})

    @responses.activate
    def test_429_raises_rate_limit(self):
        responses.add(
            responses.POST, "https://api.reve.com/v1/test/",
            json={"message": "slow down"}, status=429,
            headers={"Retry-After": "30"},
        )
        client = ReveClient(api_token="tok")
        with pytest.raises(ReveRateLimitError) as exc_info:
            client.post("/v1/test/", {})
        assert exc_info.value.retry_after == 30.0

    @responses.activate
    def test_400_raises_validation_error(self):
        responses.add(responses.POST, "https://api.reve.com/v1/test/", json={"message": "bad input"}, status=400)
        client = ReveClient(api_token="tok")
        with pytest.raises(ReveValidationError):
            client.post("/v1/test/", {})

    @responses.activate
    def test_500_raises_api_error(self):
        responses.add(responses.POST, "https://api.reve.com/v1/test/", json={"message": "oops"}, status=500)
        client = ReveClient(api_token="tok")
        with pytest.raises(ReveAPIError) as exc_info:
            client.post("/v1/test/", {})
        assert exc_info.value.status_code == 500

