"""Tests for reve.v1.image module."""

import io
import json

import pytest
import responses
from PIL import Image

from reve.v1.image import create, remix, edit, get_balance, list_effects, _encode_image
from reve._response import ImageResponse
from reve.exceptions import ReveContentViolationError


def _make_jpeg_bytes(width=100, height=100):
    """Create minimal JPEG bytes for testing."""
    img = Image.new("RGB", (width, height), color="blue")
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    return buf.getvalue()


_FAKE_JPEG = _make_jpeg_bytes()
_BASE_URL = "https://api.reve.com"
_IMAGE_HEADERS = {
    "x-reve-request-id": "req-test",
    "x-reve-credits-used": "10",
    "x-reve-credits-remaining": "90",
    "x-reve-version": "v2.0",
    "x-reve-content-violation": "false",
}


class TestEncodeImage:
    def test_encode_bytes(self):
        result = _encode_image(b"hello")
        import base64
        assert base64.b64decode(result) == b"hello"

    def test_encode_pil_image(self):
        img = Image.new("RGB", (10, 10), color="green")
        result = _encode_image(img)
        import base64
        decoded = base64.b64decode(result)
        # Should be valid JPEG bytes
        assert decoded[:2] == b"\xff\xd8"

    def test_encode_file_path(self, tmp_path):
        p = tmp_path / "test.jpg"
        p.write_bytes(b"fake-image-data")
        result = _encode_image(str(p))
        import base64
        assert base64.b64decode(result) == b"fake-image-data"

    def test_encode_invalid_type(self):
        with pytest.raises(TypeError):
            _encode_image(12345)


class TestCreate:
    @responses.activate
    def test_create_basic(self):
        responses.add(
            responses.POST,
            _BASE_URL + "/v1/image/create/",
            body=_FAKE_JPEG,
            status=200,
            headers=_IMAGE_HEADERS,
        )
        result = create(prompt="A sunset", api_token="tok")
        assert isinstance(result, ImageResponse)
        assert result.request_id == "req-test"
        assert result.credits_used == 10

        body = json.loads(responses.calls[0].request.body)
        assert body["prompt"] == "A sunset"

    @responses.activate
    def test_create_with_options(self):
        responses.add(
            responses.POST, _BASE_URL + "/v1/image/create/",
            body=_FAKE_JPEG, status=200, headers=_IMAGE_HEADERS,
        )
        result = create(
            prompt="A dragon",
            aspect_ratio="16:9",
            version="latest",
            postprocessing=[{"process": "upscale", "upscale_factor": 2}],
            api_token="tok",
        )
        body = json.loads(responses.calls[0].request.body)
        assert body["aspect_ratio"] == "16:9"
        assert body["postprocessing"] == [{"process": "upscale", "upscale_factor": 2}]


class TestRemix:
    @responses.activate
    def test_remix_with_bytes(self):
        responses.add(
            responses.POST, _BASE_URL + "/v1/image/remix/",
            body=_FAKE_JPEG, status=200, headers=_IMAGE_HEADERS,
        )
        result = remix(
            prompt="A person in a forest",
            reference_images=[b"fake-img"],
            api_token="tok",
        )
        assert isinstance(result, ImageResponse)
        body = json.loads(responses.calls[0].request.body)
        assert "reference_images" in body
        assert len(body["reference_images"]) == 1


class TestEdit:
    @responses.activate
    def test_edit_with_bytes(self):
        responses.add(
            responses.POST, _BASE_URL + "/v1/image/edit/",
            body=_FAKE_JPEG, status=200, headers=_IMAGE_HEADERS,
        )
        result = edit(
            edit_instruction="Make sky dramatic",
            reference_image=b"fake-img",
            api_token="tok",
        )
        assert isinstance(result, ImageResponse)
        body = json.loads(responses.calls[0].request.body)
        assert body["edit_instruction"] == "Make sky dramatic"
        assert "reference_image" in body



class TestGetBalance:
    @responses.activate
    def test_get_balance(self):
        responses.add(
            responses.GET, _BASE_URL + "/api/misc/balance/",
            json={"budget_id": "b1", "new_balance": 500}, status=200,
        )
        result = get_balance(api_token="tok")
        assert result["budget_id"] == "b1"
        assert result["new_balance"] == 500


class TestListEffects:
    @responses.activate
    def test_list_effects(self):
        effects_data = [
            {"name": "sepia", "description": "Sepia tone", "source": "preset", "category": "color"},
        ]
        responses.add(
            responses.GET, _BASE_URL + "/v1/image/effect/",
            json={"effects": effects_data}, status=200,
        )
        result = list_effects(api_token="tok")
        assert len(result) == 1
        assert result[0]["name"] == "sepia"

    @responses.activate
    def test_list_effects_with_source(self):
        responses.add(
            responses.GET, _BASE_URL + "/v1/image/effect/",
            json={"effects": []}, status=200,
        )
        result = list_effects(source="project", api_token="tok")
        assert result == []
        assert "source=project" in responses.calls[0].request.url


class TestContentViolation:
    @responses.activate
    def test_content_violation_raises(self):
        violation_headers = dict(_IMAGE_HEADERS)
        violation_headers["x-reve-content-violation"] = "true"
        responses.add(
            responses.POST, _BASE_URL + "/v1/image/create/",
            body=_FAKE_JPEG, status=200, headers=violation_headers,
        )
        with pytest.raises(ReveContentViolationError):
            create(prompt="bad content", api_token="tok")

