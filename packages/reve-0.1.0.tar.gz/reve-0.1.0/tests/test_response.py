"""Tests for reve._response module."""

import io
from PIL import Image
from pydantic import BaseModel

from reve._response import ImageResponse


def _make_jpeg_bytes(width=100, height=100):
    """Create minimal JPEG bytes for testing."""
    img = Image.new("RGB", (width, height), color="red")
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    return buf.getvalue()


def test_image_response_basic():
    data = _make_jpeg_bytes(200, 150)
    resp = ImageResponse.from_raw(
        image_bytes=data,
        request_id="req-123",
        credits_used="5",
        credits_remaining="95",
        version="v2.1",
        content_violation=False,
    )
    assert resp.image.size == (200, 150)
    assert resp.request_id == "req-123"
    assert resp.credits_used == 5
    assert resp.credits_remaining == 95
    assert resp.version == "v2.1"
    assert resp.content_violation is False


def test_image_response_none_credits():
    data = _make_jpeg_bytes()
    resp = ImageResponse.from_raw(image_bytes=data)
    assert resp.credits_used is None
    assert resp.credits_remaining is None
    assert resp.request_id is None
    assert resp.version is None
    assert resp.content_violation is False


def test_image_response_repr():
    data = _make_jpeg_bytes(320, 240)
    resp = ImageResponse.from_raw(image_bytes=data, request_id="req-abc")
    r = repr(resp)
    assert "req-abc" in r
    assert "320x240" in r


def test_image_response_save(tmp_path):
    data = _make_jpeg_bytes(50, 50)
    resp = ImageResponse.from_raw(image_bytes=data, request_id="req-save")
    out_path = tmp_path / "output.jpg"
    resp.save(str(out_path))
    assert out_path.exists()
    saved = Image.open(str(out_path))
    assert saved.size == (50, 50)



def test_image_response_is_pydantic_model():
    assert issubclass(ImageResponse, BaseModel)


def test_image_response_coerces_string_credits():
    data = _make_jpeg_bytes()
    resp = ImageResponse.from_raw(
        image_bytes=data,
        credits_used="42",
        credits_remaining="58",
    )
    assert resp.credits_used == 42
    assert resp.credits_remaining == 58
    assert isinstance(resp.credits_used, int)
    assert isinstance(resp.credits_remaining, int)
