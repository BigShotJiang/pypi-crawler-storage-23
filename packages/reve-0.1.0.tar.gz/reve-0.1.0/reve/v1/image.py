"""Reve v1 image API functions.

Provides high-level functions for image generation, remixing, editing,
balance checking, and effect listing.
"""

import base64
import io
from typing import Any, Dict, List, Optional, Sequence, Union

from PIL import Image

from .._client import ReveClient
from .._response import ImageResponse
from ..exceptions import ReveContentViolationError


#: Types accepted as image inputs for remix/edit.
ImageInput = Union[str, bytes, Image.Image]


def _encode_image(img: ImageInput) -> str:
    """Convert an image input to a base64-encoded string.

    Args:
        img: An image as a file path (str), raw bytes, or PIL Image.

    Returns:
        Base64-encoded string of the image data.

    Raises:
        TypeError: If ``img`` is not a supported type.
    """
    if isinstance(img, str):
        with open(img, "rb") as f:
            data = f.read()
    elif isinstance(img, bytes):
        data = img
    elif isinstance(img, Image.Image):
        buf = io.BytesIO()
        img.save(buf, format="JPEG")
        data = buf.getvalue()
    else:
        raise TypeError(
            "Image must be a file path (str), bytes, or PIL.Image; got {}".format(
                type(img).__name__
            )
        )
    return base64.b64encode(data).decode("ascii")


def _make_client(
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> ReveClient:
    """Create a ReveClient from explicit args or environment."""
    return ReveClient(
        api_token=api_token,
        api_url=api_url,
        proxy_authorization=proxy_authorization,
        verify=verify,
    )


def _parse_image_response(raw_bytes: bytes, headers: Any) -> ImageResponse:
    """Parse raw image bytes and response headers into an ImageResponse.

    Args:
        raw_bytes: Raw image bytes from the API response.
        headers: Response headers containing metadata.

    Returns:
        An ImageResponse wrapping the decoded image and metadata.

    Raises:
        ReveContentViolationError: If the response indicates a content violation.
    """
    content_violation = headers.get("x-reve-content-violation", "").lower() in (
        "true", "1", "yes",
    )
    if content_violation:
        raise ReveContentViolationError(
            message="Content violation detected in response"
        )

    return ImageResponse.from_raw(
        image_bytes=raw_bytes,
        request_id=headers.get("x-reve-request-id"),
        credits_used=headers.get("x-reve-credits-used"),
        credits_remaining=headers.get("x-reve-credits-remaining"),
        version=headers.get("x-reve-version"),
        content_violation=content_violation,
    )


_EXCLUDE_KEYS = frozenset(("api_token", "api_url", "proxy_authorization", "verify", "client"))


def _build_body(params: Dict[str, Any], exclude: frozenset = _EXCLUDE_KEYS) -> Dict[str, Any]:
    """Build a JSON body dict, excluding client-config keys and None values."""
    return {k: v for k, v in params.items() if k not in exclude and v is not None}


def create(
    prompt: str,
    *,
    aspect_ratio: Optional[str] = None,
    version: Optional[str] = None,
    test_time_scaling: Optional[int] = None,
    postprocessing: Optional[List[Dict[str, Any]]] = None,
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> ImageResponse:
    """Generate an image from a text prompt.

    Args:
        prompt: Text description of the image to generate.
        aspect_ratio: Aspect ratio string. One of ``"16:9"``, ``"3:2"``,
            ``"4:3"``, ``"1:1"``, ``"3:4"``, ``"2:3"``, ``"9:16"``, or
            ``"auto"`` (default ``"auto"``).
        version: Model version identifier or ``"latest"`` (default).
        test_time_scaling: Quality scaling factor from 1 to 5. Higher values
            produce better quality but consume more credits.
        postprocessing: List of postprocessing operation dicts built with
            helpers from :mod:`reve.v1.postprocessing`.
        api_token: Override the API token for this request. Falls back to
            the ``REVE_API_TOKEN`` environment variable.
        api_url: Override the base API URL. Falls back to
            ``REVE_MONOLITH_LOCATION`` or ``https://api.reve.com``.
        proxy_authorization: Override the proxy-authorization header value.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development).

    Returns:
        An :class:`~reve._response.ImageResponse` containing the generated
        PIL Image and response metadata (request_id, credits_used, etc.).

    Raises:
        ReveAuthenticationError: If the API token is invalid (HTTP 401).
        ReveBudgetExhaustedError: If the credit budget is exhausted (HTTP 402).
        ReveRateLimitError: If the rate limit is exceeded (HTTP 429).
        ReveValidationError: If the request parameters are invalid (HTTP 400).
        ReveContentViolationError: If the generated content violates policies.
        ReveAPIError: For other API errors.
    """
    client = _make_client(api_token, api_url, proxy_authorization, verify=verify)
    body = _build_body(locals())
    raw_bytes, headers = client.post("/v1/image/create/", body, accept="image/jpeg")
    return _parse_image_response(raw_bytes, headers)


def remix(
    prompt: str,
    reference_images: Sequence[ImageInput],
    *,
    aspect_ratio: Optional[str] = None,
    version: Optional[str] = None,
    test_time_scaling: Optional[int] = None,
    postprocessing: Optional[List[Dict[str, Any]]] = None,
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> ImageResponse:
    """Generate a new image by remixing reference images with a text prompt.

    Reference images can be referred to in the prompt using ``<ref>0</ref>``,
    ``<ref>1</ref>``, etc.

    Args:
        prompt: Text prompt describing the desired output. Use
            ``<ref>N</ref>`` tags to reference images by index.
        reference_images: Sequence of reference images. Each element can be
            a file path (str), raw bytes, or a PIL Image.
        aspect_ratio: Aspect ratio string (see :func:`create`).
        version: Model version identifier or ``"latest"``.
        test_time_scaling: Quality scaling factor (1–5).
        postprocessing: List of postprocessing operation dicts.
        api_token: Override API token for this request.
        api_url: Override base API URL.
        proxy_authorization: Override proxy-authorization header value.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development).

    Returns:
        An :class:`~reve._response.ImageResponse` containing the generated
        PIL Image and response metadata.

    Raises:
        ReveAuthenticationError: If the API token is invalid (HTTP 401).
        ReveBudgetExhaustedError: If the credit budget is exhausted (HTTP 402).
        ReveRateLimitError: If the rate limit is exceeded (HTTP 429).
        ReveValidationError: If the request parameters are invalid (HTTP 400).
        ReveContentViolationError: If the generated content violates policies.
        ReveAPIError: For other API errors.
        TypeError: If a reference image has an unsupported type.
    """
    client = _make_client(api_token, api_url, proxy_authorization, verify=verify)
    body = _build_body(locals())
    # Encode reference images to base64
    body["reference_images"] = [_encode_image(img) for img in reference_images]
    raw_bytes, headers = client.post("/v1/image/remix/", body, accept="image/jpeg")
    return _parse_image_response(raw_bytes, headers)


def edit(
    edit_instruction: str,
    reference_image: ImageInput,
    *,
    aspect_ratio: Optional[str] = None,
    version: Optional[str] = None,
    test_time_scaling: Optional[int] = None,
    postprocessing: Optional[List[Dict[str, Any]]] = None,
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> ImageResponse:
    """Edit an existing image using a natural-language instruction.

    Args:
        edit_instruction: A description of the edit to apply
            (e.g. ``"Make the sky more dramatic"``).
        reference_image: The source image to edit. Can be a file path (str),
            raw bytes, or a PIL Image.
        aspect_ratio: Aspect ratio string (see :func:`create`).
        version: Model version identifier or ``"latest"``.
        test_time_scaling: Quality scaling factor (1–5).
        postprocessing: List of postprocessing operation dicts.
        api_token: Override API token for this request.
        api_url: Override base API URL.
        proxy_authorization: Override proxy-authorization header value.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development).

    Returns:
        An :class:`~reve._response.ImageResponse` containing the edited
        PIL Image and response metadata.

    Raises:
        ReveAuthenticationError: If the API token is invalid (HTTP 401).
        ReveBudgetExhaustedError: If the credit budget is exhausted (HTTP 402).
        ReveRateLimitError: If the rate limit is exceeded (HTTP 429).
        ReveValidationError: If the request parameters are invalid (HTTP 400).
        ReveContentViolationError: If the edited content violates policies.
        ReveAPIError: For other API errors.
        TypeError: If the reference image has an unsupported type.
    """
    client = _make_client(api_token, api_url, proxy_authorization, verify=verify)
    body = _build_body(locals())
    # Encode reference image to base64
    body["reference_image"] = _encode_image(reference_image)
    raw_bytes, headers = client.post("/v1/image/edit/", body, accept="image/jpeg")
    return _parse_image_response(raw_bytes, headers)


def get_balance(
    *,
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> Dict[str, Any]:
    """Get the current credit balance.

    Args:
        api_token: Override API token for this request.
        api_url: Override base API URL.
        proxy_authorization: Override proxy-authorization header value.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development).

    Returns:
        A dict with ``budget_id`` (str) and ``new_balance`` (number) keys.

    Raises:
        ReveAuthenticationError: If the API token is invalid (HTTP 401).
        ReveAPIError: For other API errors.
    """
    client = _make_client(api_token, api_url, proxy_authorization, verify=verify)
    return client.get("/api/misc/balance/")


def list_effects(
    source: Optional[str] = None,
    *,
    api_token: Optional[str] = None,
    api_url: Optional[str] = None,
    proxy_authorization: Optional[str] = None,
    verify: bool = True,
) -> List[Dict[str, Any]]:
    """List available effects for postprocessing.

    Args:
        source: Filter effects by source. One of ``"all"``, ``"project"``,
            or ``"preset"``. If ``None``, returns all effects.
        api_token: Override API token for this request.
        api_url: Override base API URL.
        proxy_authorization: Override proxy-authorization header value.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development).

    Returns:
        A list of dicts, each with ``name``, ``description``, ``source``,
        and ``category`` keys describing an available effect.

    Raises:
        ReveAuthenticationError: If the API token is invalid (HTTP 401).
        ReveAPIError: For other API errors.
    """
    client = _make_client(api_token, api_url, proxy_authorization, verify=verify)
    params: Optional[Dict[str, str]] = None
    if source is not None:
        params = {"source": source}
    resp = client.get("/v1/image/effect/", params=params)
    return resp.get("effects", [])

