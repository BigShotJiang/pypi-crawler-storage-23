"""Response classes for the Reve Python SDK."""

import io
from typing import Optional

from PIL import Image as PILImage
from pydantic import BaseModel, Field, ConfigDict


class ImageResponse(BaseModel):
    """Response from an image generation API call.

    Contains the generated image as a PIL Image object along with
    metadata about the request.

    Attributes:
        image: PIL.Image.Image object containing the generated image.
        request_id: Unique identifier for the API request.
        credits_used: Number of API credits consumed by this request.
        credits_remaining: Number of API credits remaining in the budget.
        version: Model version used for generation.
        content_violation: Whether a content policy violation was detected.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    image: PILImage.Image
    request_id: Optional[str] = None
    credits_used: Optional[int] = None
    credits_remaining: Optional[int] = None
    version: Optional[str] = None
    content_violation: bool = False

    @classmethod
    def from_raw(
        cls,
        image_bytes: bytes,
        request_id: Optional[str] = None,
        credits_used: Optional[str] = None,
        credits_remaining: Optional[str] = None,
        version: Optional[str] = None,
        content_violation: bool = False,
    ) -> "ImageResponse":
        """Create an ImageResponse from raw image bytes and header values.

        Args:
            image_bytes: Raw image file bytes (JPEG, PNG, etc.).
            request_id: Value from x-reve-request-id header.
            credits_used: Value from x-reve-credits-used header (string).
            credits_remaining: Value from x-reve-credits-remaining header (string).
            version: Value from x-reve-version header.
            content_violation: Whether content violation was flagged.

        Returns:
            ImageResponse with parsed image and metadata.
        """
        img = PILImage.open(io.BytesIO(image_bytes))
        return cls(
            image=img,
            request_id=request_id,
            credits_used=int(credits_used) if credits_used is not None else None,
            credits_remaining=int(credits_remaining) if credits_remaining is not None else None,
            version=version,
            content_violation=content_violation,
        )

    def save(self, *args, **kwargs):
        """Save the image to a file. Delegates to PIL.Image.save().

        Args:
            *args: Positional arguments passed to PIL.Image.save().
            **kwargs: Keyword arguments passed to PIL.Image.save().
        """
        return self.image.save(*args, **kwargs)

    def __repr__(self) -> str:
        w, h = self.image.size
        return "<ImageResponse request_id={!r} size={}x{}>".format(
            self.request_id, w, h
        )

