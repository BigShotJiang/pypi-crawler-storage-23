"""Exception classes for the Reve Python SDK."""

from typing import Optional, Union


class ReveAPIError(Exception):
    """Base exception for all Reve API errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code that triggered the error, if any.
        error_code: Machine-readable error code from the API, if any.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
    ) -> None:
        self.message = message
        self.status_code = status_code
        self.error_code = error_code
        super().__init__(self.message)

    def __str__(self) -> str:
        parts = []
        if self.status_code is not None:
            parts.append("status={}".format(self.status_code))
        if self.error_code is not None:
            parts.append("error_code={}".format(self.error_code))
        parts.append(self.message)
        return " ".join(parts)


class ReveAuthenticationError(ReveAPIError):
    """Raised when authentication fails (HTTP 401).

    This typically means the API token is missing, expired, or invalid.
    """

    def __init__(
        self,
        message: str = "Authentication failed",
        error_code: Optional[str] = None,
    ) -> None:
        super().__init__(message, status_code=401, error_code=error_code)


class ReveBudgetExhaustedError(ReveAPIError):
    """Raised when the credit budget is exhausted (HTTP 402).

    Check your balance with :func:`reve.v1.image.get_balance` and
    top up credits to continue.
    """

    def __init__(
        self,
        message: str = "Budget exhausted",
        error_code: Optional[str] = None,
    ) -> None:
        super().__init__(message, status_code=402, error_code=error_code)


class ReveRateLimitError(ReveAPIError):
    """Raised when the rate limit is exceeded (HTTP 429).

    Attributes:
        retry_after: Seconds to wait before retrying, if provided by the API.
    """

    def __init__(
        self,
        message: str = "Rate limit exceeded",
        retry_after: Optional[Union[float, str]] = None,
        error_code: Optional[str] = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(message, status_code=429, error_code=error_code)

    def __str__(self) -> str:
        base = super().__str__()
        if self.retry_after is not None:
            return "{} (retry_after={})".format(base, self.retry_after)
        return base


class ReveContentViolationError(ReveAPIError):
    """Raised when the content violates safety policies.

    This can occur either on input (prompt/images) or on the generated output.
    """

    def __init__(
        self,
        message: str = "Content violation detected",
        status_code: Optional[int] = None,
        error_code: Optional[str] = None,
    ) -> None:
        super().__init__(message, status_code=status_code, error_code=error_code)


class ReveValidationError(ReveAPIError):
    """Raised when the request fails validation (HTTP 400).

    Check the ``message`` attribute for details on which parameter was invalid.
    """

    def __init__(
        self,
        message: str = "Validation error",
        error_code: Optional[str] = None,
    ) -> None:
        super().__init__(message, status_code=400, error_code=error_code)

