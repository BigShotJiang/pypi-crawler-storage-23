"""HTTP client for the Reve API."""

import os
from typing import Any, Dict, Optional, Tuple, Union

import requests as _requests

from .exceptions import (
    ReveAPIError,
    ReveAuthenticationError,
    ReveBudgetExhaustedError,
    ReveContentViolationError,
    ReveRateLimitError,
    ReveValidationError,
)


_DEFAULT_API_URL = "https://api.reve.com"


class ReveClient:
    """Low-level HTTP client for the Reve API.

    Handles authentication, base URL resolution, and error mapping.

    Args:
        api_token: Bearer token. Falls back to the ``REVE_API_TOKEN``
            environment variable if not provided.
        api_url: Base API URL. Falls back to ``REVE_MONOLITH_LOCATION``
            env var, then defaults to ``https://api.reve.com``.
        proxy_authorization: Optional proxy-authorization header value
            (e.g. for Google IAP). Falls back to
            ``REVE_PROXY_AUTHORIZATION`` env var.
        verify: SSL certificate verification. Pass ``False`` to disable
            SSL verification (e.g. for local development). Defaults to
            ``True``.
    """

    def __init__(
        self,
        api_token: Optional[str] = None,
        api_url: Optional[str] = None,
        proxy_authorization: Optional[str] = None,
        verify: bool = True,
    ) -> None:
        self.api_token: Optional[str] = api_token or os.environ.get("REVE_API_TOKEN")
        self.api_url: str = (
            api_url
            or os.environ.get("REVE_MONOLITH_LOCATION")
            or _DEFAULT_API_URL
        )
        # Strip trailing slash from base URL to avoid double slashes
        self.api_url = self.api_url.rstrip("/")
        self.proxy_authorization: Optional[str] = (
            proxy_authorization
            or os.environ.get("REVE_PROXY_AUTHORIZATION")
        )
        self.verify: bool = verify

    def _headers(self, accept: str = "application/json") -> Dict[str, str]:
        """Build request headers including auth and accept type.

        Args:
            accept: Value for the Accept header.

        Returns:
            Dict of HTTP headers.
        """
        headers: Dict[str, str] = {"Accept": accept}
        if self.api_token:
            headers["Authorization"] = "Bearer {}".format(self.api_token)
        if self.proxy_authorization:
            headers["proxy-authorization"] = self.proxy_authorization
        return headers

    def _handle_error(self, response: _requests.Response) -> None:
        """Raise an appropriate exception for error responses.

        Args:
            response: The HTTP response with a 4xx/5xx status code.

        Raises:
            ReveValidationError: For HTTP 400.
            ReveAuthenticationError: For HTTP 401.
            ReveBudgetExhaustedError: For HTTP 402.
            ReveRateLimitError: For HTTP 429.
            ReveAPIError: For all other error status codes.
        """
        status = response.status_code
        try:
            body = response.json()
        except ValueError:
            body = {}

        message = body.get("message") or body.get("error") or response.text
        error_code = body.get("error_code")

        if status == 400:
            raise ReveValidationError(message=message, error_code=error_code)
        if status == 401:
            raise ReveAuthenticationError(message=message, error_code=error_code)
        if status == 402:
            raise ReveBudgetExhaustedError(message=message, error_code=error_code)
        if status == 429:
            retry_after: Optional[Union[float, str]] = response.headers.get("Retry-After")
            if retry_after is not None:
                try:
                    retry_after = float(retry_after)
                except (ValueError, TypeError):
                    pass
            raise ReveRateLimitError(
                message=message, retry_after=retry_after, error_code=error_code
            )
        raise ReveAPIError(
            message=message, status_code=status, error_code=error_code
        )

    def post(
        self,
        path: str,
        data: Dict[str, Any],
        accept: str = "application/json",
    ) -> Union[Dict[str, Any], Tuple[bytes, Any]]:
        """Send a POST request to the Reve API.

        Args:
            path: API path (e.g. ``"/v1/image/create/"``).
            data: JSON-serializable request body.
            accept: Accept header value. Use ``"image/jpeg"`` for image
                endpoints.

        Returns:
            Parsed JSON dict if *accept* is ``"application/json"``, otherwise
            a tuple of ``(raw_bytes, response_headers)``.

        Raises:
            ReveAPIError: If the server returns an error status code.
        """
        url = self.api_url + path
        headers = self._headers(accept=accept)
        headers["Content-Type"] = "application/json"

        resp = _requests.post(url, json=data, headers=headers, verify=self.verify)

        if resp.status_code >= 400:
            self._handle_error(resp)

        if accept == "application/json":
            return resp.json()

        # For image responses, return bytes + headers for metadata extraction
        return resp.content, resp.headers

    def get(
        self,
        path: str,
        params: Optional[Dict[str, str]] = None,
    ) -> Any:
        """Send a GET request to the Reve API.

        Args:
            path: API path (e.g. ``"/v1/image/balance/"``).
            params: Optional query parameters dict.

        Returns:
            Parsed JSON response.

        Raises:
            ReveAPIError: If the server returns an error status code.
        """
        url = self.api_url + path
        headers = self._headers(accept="application/json")

        resp = _requests.get(url, params=params, headers=headers, verify=self.verify)

        if resp.status_code >= 400:
            self._handle_error(resp)

        return resp.json()

