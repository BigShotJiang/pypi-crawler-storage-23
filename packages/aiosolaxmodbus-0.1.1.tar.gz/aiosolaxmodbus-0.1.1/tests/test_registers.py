"""Tests for register map definitions and model detection."""

from aiosolaxmodbus.registers import (
    DataType,
    RegisterType,
    X1_HYBRID_G4_HOLDING_REGISTERS,
    X1_HYBRID_G4_INPUT_REGISTERS,
    detect_model,
)


def test_input_registers_sorted_by_address():
    """Input registers should be in ascending address order."""
    addresses = [r.address for r in X1_HYBRID_G4_INPUT_REGISTERS]
    assert addresses == sorted(addresses)


def test_holding_registers_sorted_by_address():
    """Holding registers should be in ascending address order."""
    addresses = [r.address for r in X1_HYBRID_G4_HOLDING_REGISTERS]
    assert addresses == sorted(addresses)


def test_all_input_registers_are_input_type():
    for reg in X1_HYBRID_G4_INPUT_REGISTERS:
        assert reg.register_type == RegisterType.INPUT


def test_all_holding_registers_are_holding_type():
    for reg in X1_HYBRID_G4_HOLDING_REGISTERS:
        assert reg.register_type == RegisterType.HOLDING


def test_no_duplicate_keys():
    all_keys = [r.key for r in X1_HYBRID_G4_INPUT_REGISTERS]
    all_keys += [r.key for r in X1_HYBRID_G4_HOLDING_REGISTERS]
    assert len(all_keys) == len(set(all_keys))


def test_u32_registers_have_count_2():
    for regs in (X1_HYBRID_G4_INPUT_REGISTERS, X1_HYBRID_G4_HOLDING_REGISTERS):
        for reg in regs:
            if reg.data_type == DataType.U32:
                assert reg.register_count == 2, f"{reg.key} U32 should span 2 registers"


def test_string_register_count():
    for reg in X1_HYBRID_G4_HOLDING_REGISTERS:
        if reg.data_type == DataType.STRING:
            assert reg.count == 7, f"Serial number should be 7 registers"
            assert reg.register_count == 7


def test_detect_model_x1_hybrid_gen4():
    model = detect_model("H4372AI4633110")
    assert model is not None
    assert model.name == "X1-Hybrid Gen4"


def test_detect_model_case_insensitive():
    model = detect_model("h4372ai4633110")
    assert model is not None
    assert model.name == "X1-Hybrid Gen4"


def test_detect_model_unknown():
    model = detect_model("Z9999UNKNOWN")
    assert model is None


def test_writable_registers_only_in_holding():
    for reg in X1_HYBRID_G4_INPUT_REGISTERS:
        assert not reg.writable, f"Input register {reg.key} should not be writable"


def test_expected_writable_count():
    writable = [r for r in X1_HYBRID_G4_HOLDING_REGISTERS if r.writable]
    assert len(writable) == 5  # run_mode, charge_current, discharge_current, export_limit, min_soc
