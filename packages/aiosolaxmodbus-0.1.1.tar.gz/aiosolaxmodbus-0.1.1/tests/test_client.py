"""Tests for the SolaX Modbus client."""

from __future__ import annotations

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from aiosolaxmodbus.client import SolaxModbusClient, _group_contiguous, _parse_value
from aiosolaxmodbus.exceptions import (
    SolaxModbusConnectionError,
    SolaxModbusReadError,
    SolaxModbusUnsupportedModelError,
    SolaxModbusWriteError,
)
from aiosolaxmodbus.models import RunMode
from aiosolaxmodbus.registers import (
    DataType,
    RegisterDefinition,
    RegisterType,
    X1_HYBRID_G4_INPUT_REGISTERS,
)
from tests.conftest import mock_read_result, mock_write_result


# ── parse_value tests ──────────────────────────────────────────────────


def test_parse_u16():
    reg = RegisterDefinition("test", "Test", RegisterType.INPUT, 0, DataType.U16, 0.1, "V")
    assert _parse_value([2422], reg) == 242.2


def test_parse_s16_positive():
    reg = RegisterDefinition("test", "Test", RegisterType.INPUT, 0, DataType.S16, 0.1, "A")
    assert _parse_value([50], reg) == 5.0


def test_parse_s16_negative():
    reg = RegisterDefinition("test", "Test", RegisterType.INPUT, 0, DataType.S16, 1.0, "W")
    # 65436 = 0xFF9C = -100 as signed 16-bit
    assert _parse_value([65436], reg) == -100.0


def test_parse_u32():
    reg = RegisterDefinition("test", "Test", RegisterType.INPUT, 0, DataType.U32, 0.1, "kWh")
    # (0 << 16) | 52340 = 52340 * 0.1 = 5234.0
    assert _parse_value([0, 52340], reg) == 5234.0


def test_parse_string():
    reg = RegisterDefinition("test", "Test", RegisterType.HOLDING, 0, DataType.STRING, count=7)
    # "H4372AI4633110"
    regs = [0x4834, 0x3337, 0x3241, 0x4934, 0x3633, 0x3331, 0x3130]
    assert _parse_value(regs, reg) == "H4372AI4633110"


# ── group_contiguous tests ─────────────────────────────────────────────


def test_group_contiguous_single():
    defs = (
        RegisterDefinition("a", "A", RegisterType.INPUT, 0, DataType.U16),
        RegisterDefinition("b", "B", RegisterType.INPUT, 1, DataType.U16),
    )
    groups = _group_contiguous(defs)
    assert len(groups) == 1
    assert groups[0][0] == 0  # start
    assert groups[0][1] == 2  # count


def test_group_contiguous_gap():
    defs = (
        RegisterDefinition("a", "A", RegisterType.INPUT, 0, DataType.U16),
        RegisterDefinition("b", "B", RegisterType.INPUT, 20, DataType.U16),
    )
    groups = _group_contiguous(defs)
    assert len(groups) == 2


def test_group_contiguous_small_gap_merged():
    defs = (
        RegisterDefinition("a", "A", RegisterType.INPUT, 0, DataType.U16),
        RegisterDefinition("b", "B", RegisterType.INPUT, 8, DataType.U16),
    )
    groups = _group_contiguous(defs)
    # Gap of 8 <= 10, should merge
    assert len(groups) == 1
    assert groups[0][1] == 9  # registers 0-8 inclusive


def test_group_contiguous_x1_hybrid():
    groups = _group_contiguous(X1_HYBRID_G4_INPUT_REGISTERS)
    # Should produce a small number of groups, not one per register
    assert len(groups) < len(X1_HYBRID_G4_INPUT_REGISTERS)


# ── Client connection tests ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_connect_success(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    assert client.connected


@pytest.mark.asyncio
async def test_connect_failure(mock_pymodbus):
    mock_pymodbus.connect = AsyncMock(return_value=False)
    client = SolaxModbusClient("192.168.1.106")
    with pytest.raises(SolaxModbusConnectionError):
        await client.connect()


@pytest.mark.asyncio
async def test_disconnect(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    await client.disconnect()
    assert not client.connected


@pytest.mark.asyncio
async def test_context_manager(mock_pymodbus):
    async with SolaxModbusClient("192.168.1.106") as client:
        assert client.connected
    assert not client.connected


# ── Client read_info tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_info(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    info = await client.read_info()

    assert info.serial_number == "H4372AI4633110"
    assert info.firmware_main == 0x0103
    assert info.firmware_sub == 0x0012
    assert info.model == "X1-Hybrid Gen4"


@pytest.mark.asyncio
async def test_read_info_unsupported_model(mock_pymodbus):
    # Return a serial that doesn't match any known prefix
    mock_pymodbus.read_holding_registers = AsyncMock(
        side_effect=lambda addr, count, slave=1: mock_read_result(
            [0x5A39, 0x3939, 0x3955, 0x4E4B, 0x4E4F, 0x574E, 0x0000]
            if addr == 0 else [0, 0]
        )
    )
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    with pytest.raises(SolaxModbusUnsupportedModelError):
        await client.read_info()


# ── Client read_data tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_read_data(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    data = await client.read_data()

    assert data.grid_voltage == 242.2
    assert data.grid_current == 5.0
    assert data.grid_power == 1210.0
    assert data.pv1_power == 1008.0
    assert data.grid_frequency == 49.95
    assert data.inverter_temperature == 35.0
    assert data.run_mode == RunMode.SELF_USE
    assert data.battery_soc == 49
    assert data.total_pv_energy == 5234.0
    assert data.today_pv_energy == 8.2


@pytest.mark.asyncio
async def test_read_data_read_error(mock_pymodbus):
    mock_pymodbus.read_input_registers = AsyncMock(
        return_value=mock_read_result([], error=True)
    )
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    with pytest.raises(SolaxModbusReadError):
        await client.read_data()


# ── Client write tests ─────────────────────────────────────────────────


@pytest.mark.asyncio
async def test_write_run_mode(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    await client.write_run_mode(RunMode.FEEDIN_PRIORITY)
    mock_pymodbus.write_register.assert_called_once_with(
        0x001F, 1
    )


@pytest.mark.asyncio
async def test_write_min_battery_soc(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    await client.write_min_battery_soc(20)
    mock_pymodbus.write_register.assert_called_once_with(
        0x0029, 20
    )


@pytest.mark.asyncio
async def test_write_battery_charge_current(mock_pymodbus):
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    await client.write_battery_charge_max_current(15.0)
    # 15.0 / 0.1 = 150
    mock_pymodbus.write_register.assert_called_once_with(
        0x0024, 150
    )


@pytest.mark.asyncio
async def test_write_error(mock_pymodbus):
    mock_pymodbus.write_register = AsyncMock(
        return_value=mock_write_result(error=True)
    )
    client = SolaxModbusClient("192.168.1.106")
    await client.connect()
    with pytest.raises(SolaxModbusWriteError):
        await client.write_run_mode(RunMode.BACKUP)
