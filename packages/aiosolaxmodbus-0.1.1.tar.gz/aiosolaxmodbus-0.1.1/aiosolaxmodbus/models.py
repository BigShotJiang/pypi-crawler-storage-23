"""Data models for SolaX Modbus inverter data."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum


class RunMode(IntEnum):
    """SolaX inverter run modes."""

    SELF_USE = 0
    FEEDIN_PRIORITY = 1
    BACKUP = 2


@dataclass(frozen=True)
class InverterInfo:
    """Static identification data from holding registers."""

    serial_number: str
    firmware_main: int
    firmware_sub: int
    model: str


@dataclass(frozen=True)
class SolaxInverterData:
    """Complete snapshot of all inverter register values.

    All values are already scaled to their real-world units.
    """

    # Grid
    grid_voltage: float  # V
    grid_current: float  # A
    grid_power: float  # W (negative = export)

    # PV Strings
    pv1_voltage: float  # V
    pv1_current: float  # A
    pv1_power: float  # W
    pv2_voltage: float  # V
    pv2_current: float  # A
    pv2_power: float  # W

    # System
    grid_frequency: float  # Hz
    inverter_temperature: float  # °C
    run_mode: RunMode

    # Battery
    battery_voltage: float  # V
    battery_current: float  # A
    battery_power: float  # W (negative = discharging)
    battery_temperature: float  # °C
    battery_soc: int  # %

    # Totals (lifetime)
    total_pv_energy: float  # kWh
    total_feed_in_energy: float  # kWh
    total_consumption: float  # kWh

    # Today
    today_pv_energy: float  # kWh
    today_battery_charge: float  # kWh
    today_battery_discharge: float  # kWh
    today_feed_in_energy: float  # kWh
    today_consumption: float  # kWh

    # Configuration (from holding registers)
    run_mode_setting: RunMode
    battery_charge_max_current: float  # A
    battery_discharge_max_current: float  # A
    export_limit: int  # W
    min_battery_soc: int  # %
