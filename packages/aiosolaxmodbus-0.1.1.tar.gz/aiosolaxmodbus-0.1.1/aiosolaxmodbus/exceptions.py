"""Exceptions for the SolaX Modbus client."""


class SolaxModbusError(Exception):
    """Base exception for all SolaX Modbus errors."""


class SolaxModbusConnectionError(SolaxModbusError):
    """Raised when unable to connect to the inverter via Modbus TCP."""


class SolaxModbusTimeoutError(SolaxModbusError):
    """Raised when a Modbus TCP operation times out."""


class SolaxModbusReadError(SolaxModbusError):
    """Raised when a register read returns an error response."""


class SolaxModbusWriteError(SolaxModbusError):
    """Raised when a register write returns an error response."""


class SolaxModbusUnsupportedModelError(SolaxModbusError):
    """Raised when the inverter model cannot be detected from its serial number."""
