# tibet-claw — Provenance & Safety Layer for AI Agents

> **OpenClaw gives AI hands. NanoClaw puts it in a box. Tibet-Claw demands a cryptographic fingerprint before it's allowed to move.**

*Audit is not an observation. It is a precondition.*

## The Problem

The Claw ecosystem (OpenClaw, NanoClaw, PicoClaw, ZeroClaw) has exploded — 211K+ GitHub stars, millions of deployments. These frameworks give AI agents real autonomy: shell access, file management, network calls, email, scheduling.

But autonomy without provenance is a liability:

1. **No data provenance** for agent actions — what did the agent actually do?
2. **No audit trail** — who asked it to do that, and why?
3. **Prompt injection vulnerabilities** with no detection or logging
4. **Malicious skills** with unknown provenance can be loaded and executed
5. **No tool access control** audit — agents call whatever they want

512 known vulnerabilities in OpenClaw alone. The adoption is massive, the safety gap is real.

## What tibet-claw Adds

tibet-claw wraps ANY Claw-family agent (or any autonomous agent) with full TIBET provenance.
It does not replace your agent framework — it makes it auditable.

### Architecture

```
[User] --> [Agent (OpenClaw/etc)] --> [tibet-claw wrapper] --> [Tool/Skill]
                                             |
                                        TIBET token:
                                          ERIN: what the agent did
                                          ERAAN: which tool, which skill
                                          EROMHEEN: agent context, model, timestamp
                                          ERACHTER: user intent vs agent action
```

### Features

| Feature | What it does |
|---------|-------------|
| **Action Provenance** | Every agent action (tool call, file access, network request, shell exec) becomes a TIBET token |
| **Tool Call Auditing** | Full input/output recording for every tool invocation |
| **Skill Provenance** | Verify skill source, hash, permissions before execution |
| **Threat Detection** | Detect privilege escalation, data exfiltration, prompt injection, boundary violations |
| **Agent Boundaries** | Enforce what an agent is allowed to do via policy |
| **Trust Scoring** | Dynamic trust score per agent based on action history |

## Installation

```bash
pip install tibet-claw
```

With Rich output support:

```bash
pip install tibet-claw[full]
```

## CLI Usage

```bash
# Concept overview and security context
tibet-claw info

# Full demo: simulates agent session with threats
tibet-claw demo

# Show threat detection rules
tibet-claw threats

# Guard statistics
tibet-claw status
```

## Python API

```python
from tibet_claw import AgentGuard, ActionRecord, SkillProfile

# Create guard for your agent
guard = AgentGuard(platform="openclaw", model="gpt-4")

# Record every agent action
record = guard.record_action(
    agent_id="agent-sales-01",
    action="tool_call",
    tool="search_database",
    input_data={"query": "SELECT * FROM customers"},
    output_data={"rows": 150},
    user_intent="Find customer list",
)
# record.tibet_token_id -> provenance token created

# Verify a skill before loading it
profile = guard.check_skill(
    skill_name="email_sender",
    skill_source="https://github.com/user/skills/email.py",
    skill_hash="a1b2c3d4...",
)
if not profile.verified:
    print(f"BLOCKED: {profile.threat_assessment}")

# Detect threats in recent activity
threats = guard.detect_threats("agent-sales-01")
for t in threats:
    print(f"[{t.severity}] {t.threat_type}: {t.description}")

# Enforce boundaries
allowed = guard.enforce_boundary(
    agent_id="agent-sales-01",
    action="shell_exec",
    policy={"allowed_actions": ["tool_call", "file_access"]},
)
# allowed = False -> shell_exec not in policy

# Full audit trail
trail = guard.audit_trail("agent-sales-01")

# Trust score (starts 0.5, adjusts based on behavior)
score = guard.agent_trust_score("agent-sales-01")
```

## TIBET Token Structure

Every action produces a TIBET token with four layers:

- **ERIN** (what is IN it): The agent action, tool name, input/output hashes
- **ERAAN** (what it connects to): Agent identity (`jis:agent:xxx`), skill source, previous action chain
- **EROMHEEN** (context AROUND it): Agent platform, model, hostname, timestamp
- **ERACHTER** (what is BEHIND it): User intent, agent reasoning, safety assessment

## Threat Detection Rules

| Threat Type | Trigger |
|------------|---------|
| `privilege_escalation` | Shell exec with `sudo`, `rm -rf`, `chmod 777` |
| `data_exfiltration` | Network calls to unknown hosts after file access |
| `boundary_violation` | Agent accessing files outside its allowed boundary |
| `automation_abuse` | Same action repeated rapidly (>10 in 60s) |
| `skill_tampering` | Skill hash changed since first seen |
| `prompt_injection` | Known injection patterns in tool inputs |

## TIBET Ecosystem

tibet-claw is part of the TIBET provenance ecosystem:

- [tibet-core](https://pypi.org/project/tibet-core/) — Core provenance library
- [tibet-soc](https://pypi.org/project/tibet-soc/) — Security Operations Center (correlates tibet-claw events)
- [tibet-audit](https://pypi.org/project/tibet-audit/) — Compliance auditing
- [tibet-db](https://pypi.org/project/tibet-db/) — Immutable database proxy
- [IETF TIBET Draft](https://datatracker.ietf.org/doc/draft-vandemeent-tibet-provenance/) — Standards track

## License

MIT — Humotica / J. van de Meent, 2025
