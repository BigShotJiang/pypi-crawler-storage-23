"""
Agent Guard — the core safety engine.

No action without provenance. No tool call without audit.
No skill without verification. Every threat is detected and logged.

Wraps any Claw-family agent (OpenClaw, NanoClaw, PicoClaw, ZeroClaw)
or any autonomous agent with full TIBET provenance.
"""

import re
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .provenance import ClawProvenance


# ---------------------------------------------------------------------------
# Threat detection patterns
# ---------------------------------------------------------------------------

_PRIVESC_PATTERNS = [
    re.compile(r"\bsudo\b"),
    re.compile(r"\brm\s+-rf\b"),
    re.compile(r"\bchmod\s+777\b"),
    re.compile(r"\bchown\s+root\b"),
    re.compile(r"\bmkfs\b"),
    re.compile(r"\bdd\s+if="),
]

_INJECTION_PATTERNS = [
    re.compile(r"ignore\s+(previous|above)\s+instructions", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+", re.IGNORECASE),
    re.compile(r"system\s*prompt\s*:", re.IGNORECASE),
    re.compile(r"<\s*/?\s*system\s*>", re.IGNORECASE),
    re.compile(r"ADMIN\s*MODE", re.IGNORECASE),
    re.compile(r"\bact\s+as\s+(a\s+)?different", re.IGNORECASE),
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class ActionRecord:
    """
    Record of a single agent action.

    Every tool call, file access, network request, shell execution,
    skill invocation, or inter-agent message is one record.
    """
    id: str
    timestamp: str
    agent_id: str
    action_type: str  # tool_call, skill_exec, file_access, network, message, shell_exec
    tool_name: str
    input_summary: str
    output_summary: str
    user_intent: str
    allowed: bool
    threat_flags: list[str] = field(default_factory=list)
    tibet_token_id: str = ""

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "action_type": self.action_type,
            "tool_name": self.tool_name,
            "input_summary": self.input_summary,
            "output_summary": self.output_summary,
            "user_intent": self.user_intent,
            "allowed": self.allowed,
            "threat_flags": self.threat_flags,
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class SkillProfile:
    """
    Provenance profile for an agent skill.

    Before any skill executes, tibet-claw verifies its source,
    hash, and permissions. Unknown or tampered skills are blocked.
    """
    name: str
    source: str  # url or path
    hash: str
    verified: bool
    trust_score: float  # 0.0 - 1.0
    permissions_required: list[str] = field(default_factory=list)
    threat_assessment: str = ""
    first_seen: str = ""
    tibet_token_id: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "source": self.source,
            "hash": self.hash,
            "verified": self.verified,
            "trust_score": self.trust_score,
            "permissions_required": self.permissions_required,
            "threat_assessment": self.threat_assessment,
            "first_seen": self.first_seen,
            "tibet_token_id": self.tibet_token_id,
        }


@dataclass
class ThreatDetection:
    """
    A detected threat in agent behavior.

    Threats are detected by scanning action history for anomalous
    patterns: privilege escalation, data exfiltration, injection,
    boundary violations, skill tampering, automation abuse.
    """
    id: str
    timestamp: str
    agent_id: str
    threat_type: str  # prompt_injection, privilege_escalation, data_exfiltration,
                      # unauthorized_access, skill_tampering, boundary_violation,
                      # automation_abuse
    severity: str  # critical, high, medium, low
    description: str
    evidence: list[str] = field(default_factory=list)  # list of action IDs
    mitigated: bool = False

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp,
            "agent_id": self.agent_id,
            "threat_type": self.threat_type,
            "severity": self.severity,
            "description": self.description,
            "evidence": self.evidence,
            "mitigated": self.mitigated,
        }


# ---------------------------------------------------------------------------
# Agent Guard
# ---------------------------------------------------------------------------

class AgentGuard:
    """
    Provenance & Safety Layer for AI Agents.

    Wraps any Claw-family agent (OpenClaw, NanoClaw, PicoClaw, ZeroClaw)
    or any autonomous agent with full TIBET provenance.

    Every action is recorded. Every tool call is audited. Every skill
    is provenance-checked. Every threat is detected and logged.

    Usage::

        guard = AgentGuard(platform="openclaw", model="gpt-4")

        record = guard.record_action(
            agent_id="agent-01",
            action="tool_call",
            tool="search_db",
            input_data={"query": "..."},
            output_data={"rows": 42},
            user_intent="Find records",
        )

        threats = guard.detect_threats("agent-01")
    """

    VALID_ACTION_TYPES = {
        "tool_call", "skill_exec", "file_access",
        "network", "message", "shell_exec",
    }

    def __init__(
        self,
        platform: str = "unknown",
        model: str = "unknown",
        actor: str = "tibet-claw",
    ):
        self.provenance = ClawProvenance(
            platform=platform, model=model, actor=actor,
        )

        self._actions: list[ActionRecord] = []
        self._skills: dict[str, SkillProfile] = {}
        self._threats: list[ThreatDetection] = []
        self._trust_scores: dict[str, float] = {}  # agent_id -> score
        self._action_times: dict[str, list[float]] = {}  # agent_id -> timestamps

        self._stats = {
            "actions_recorded": 0,
            "actions_allowed": 0,
            "actions_blocked": 0,
            "skills_checked": 0,
            "skills_verified": 0,
            "skills_rejected": 0,
            "threats_detected": 0,
            "boundary_checks": 0,
            "boundary_violations": 0,
        }

    # ------------------------------------------------------------------
    # record_action
    # ------------------------------------------------------------------

    def record_action(
        self,
        agent_id: str,
        action: str,
        tool: str = "",
        input_data: object = None,
        output_data: object = None,
        user_intent: str = "",
    ) -> ActionRecord:
        """
        Record an agent action with full TIBET provenance.

        Args:
            agent_id: Unique identifier for the agent
            action: Action type (tool_call, skill_exec, file_access, network,
                    message, shell_exec)
            tool: Name of the tool or skill being invoked
            input_data: Input to the action (will be hashed for provenance)
            output_data: Output from the action (will be hashed for provenance)
            user_intent: What the user asked for (for intent-vs-action comparison)

        Returns:
            ActionRecord with TIBET token ID
        """
        now = datetime.now(timezone.utc).isoformat()
        self._stats["actions_recorded"] += 1

        # Detect inline threats
        threat_flags = self._scan_action(action, tool, input_data)

        # Determine if action should be allowed
        allowed = len(threat_flags) == 0
        safety = "nominal" if allowed else f"threats: {', '.join(threat_flags)}"

        # Create TIBET token
        token = self.provenance.create_action_token(
            agent_id=agent_id,
            action=action,
            tool=tool,
            input_data=input_data,
            output_data=output_data,
            user_intent=user_intent,
            allowed=allowed,
            safety_assessment=safety,
        )

        input_summary = _summarize(input_data)
        output_summary = _summarize(output_data)

        record = ActionRecord(
            id=token.token_id,
            timestamp=now,
            agent_id=agent_id,
            action_type=action,
            tool_name=tool,
            input_summary=input_summary,
            output_summary=output_summary,
            user_intent=user_intent,
            allowed=allowed,
            threat_flags=threat_flags,
            tibet_token_id=token.token_id,
        )

        self._actions.append(record)

        # Track action timing for automation abuse detection
        self._action_times.setdefault(agent_id, []).append(time.time())

        # Update trust score
        self._adjust_trust(agent_id, allowed, threat_flags)

        if allowed:
            self._stats["actions_allowed"] += 1
        else:
            self._stats["actions_blocked"] += 1

        return record

    # ------------------------------------------------------------------
    # check_skill
    # ------------------------------------------------------------------

    def check_skill(
        self,
        skill_name: str,
        skill_source: str,
        skill_hash: str,
        permissions_required: list[str] | None = None,
    ) -> SkillProfile:
        """
        Verify a skill's provenance before execution.

        Checks whether the skill source is known, whether its hash
        matches what was seen before, and assigns a trust score.

        Args:
            skill_name: Name of the skill
            skill_source: URL or file path of the skill
            skill_hash: SHA-256 hash of the skill content
            permissions_required: Permissions the skill needs

        Returns:
            SkillProfile with verification result
        """
        now = datetime.now(timezone.utc).isoformat()
        self._stats["skills_checked"] += 1
        perms = permissions_required or []

        # Check if we've seen this skill before
        existing = self._skills.get(skill_name)

        if existing is not None:
            # Skill seen before: verify hash
            if existing.hash != skill_hash:
                # Hash changed -> skill tampering
                threat_assessment = (
                    f"TAMPERED: hash changed from {existing.hash[:12]}... "
                    f"to {skill_hash[:12]}... since first seen {existing.first_seen}"
                )
                verified = False
                trust = 0.0
                self._stats["skills_rejected"] += 1
            else:
                threat_assessment = "Hash matches previous version"
                verified = True
                trust = min(existing.trust_score + 0.05, 1.0)
                self._stats["skills_verified"] += 1
        else:
            # New skill: first-time check
            threat_assessment = "First-time skill, no history. Proceed with caution."
            verified = True
            trust = 0.3  # Low initial trust for new skills
            self._stats["skills_verified"] += 1

        # Create TIBET token
        token = self.provenance.create_skill_token(
            agent_id="system",
            skill_name=skill_name,
            skill_source=skill_source,
            skill_hash=skill_hash,
            verified=verified,
            threat_assessment=threat_assessment,
        )

        profile = SkillProfile(
            name=skill_name,
            source=skill_source,
            hash=skill_hash,
            verified=verified,
            trust_score=trust,
            permissions_required=perms,
            threat_assessment=threat_assessment,
            first_seen=existing.first_seen if existing else now,
            tibet_token_id=token.token_id,
        )

        # Store/update the skill registry
        self._skills[skill_name] = profile
        return profile

    # ------------------------------------------------------------------
    # detect_threats
    # ------------------------------------------------------------------

    def detect_threats(
        self,
        agent_id: str,
        window_seconds: float = 300.0,
    ) -> list[ThreatDetection]:
        """
        Scan recent actions for anomalous behavior patterns.

        Threat rules:
        - Shell exec with sudo/rm -rf/chmod 777 -> privilege_escalation
        - Network calls after file_access -> data_exfiltration
        - Same action repeated rapidly -> automation_abuse
        - Skill hash changed -> skill_tampering
        - Known injection patterns in input -> prompt_injection

        Args:
            agent_id: Agent to scan
            window_seconds: How far back to scan (default 5 minutes)

        Returns:
            List of detected threats
        """
        now_ts = time.time()
        cutoff = now_ts - window_seconds
        now = datetime.now(timezone.utc).isoformat()

        recent = [
            a for a in self._actions
            if a.agent_id == agent_id and self._action_in_window(a, cutoff)
        ]

        detected: list[ThreatDetection] = []

        # --- Rule 1: Privilege escalation ---
        for a in recent:
            if a.action_type == "shell_exec" and a.threat_flags:
                for flag in a.threat_flags:
                    if flag == "privilege_escalation":
                        threat = self._register_threat(
                            agent_id=agent_id,
                            threat_type="privilege_escalation",
                            severity="critical",
                            description=(
                                f"Shell command with dangerous pattern "
                                f"in tool '{a.tool_name}': {a.input_summary}"
                            ),
                            evidence=[a.id],
                            timestamp=now,
                        )
                        detected.append(threat)

        # --- Rule 2: Data exfiltration (network after file_access) ---
        file_accesses = [a for a in recent if a.action_type == "file_access"]
        network_calls = [a for a in recent if a.action_type == "network"]
        if file_accesses and network_calls:
            # Check if a network call happened after a file access
            for net in network_calls:
                for fa in file_accesses:
                    if net.timestamp >= fa.timestamp:
                        threat = self._register_threat(
                            agent_id=agent_id,
                            threat_type="data_exfiltration",
                            severity="high",
                            description=(
                                f"Network call to '{net.tool_name}' after "
                                f"file access '{fa.tool_name}' — potential "
                                f"data exfiltration"
                            ),
                            evidence=[fa.id, net.id],
                            timestamp=now,
                        )
                        detected.append(threat)
                        break
                    break

        # --- Rule 3: Automation abuse (rapid repeated actions) ---
        timestamps = self._action_times.get(agent_id, [])
        recent_ts = [t for t in timestamps if t >= cutoff]
        if len(recent_ts) > 10:
            # Check if > 10 actions in 60 seconds
            sixty_ago = now_ts - 60.0
            burst = [t for t in recent_ts if t >= sixty_ago]
            if len(burst) > 10:
                evidence_ids = [a.id for a in recent[-10:]]
                threat = self._register_threat(
                    agent_id=agent_id,
                    threat_type="automation_abuse",
                    severity="medium",
                    description=(
                        f"Agent performed {len(burst)} actions in <60s "
                        f"(threshold: 10)"
                    ),
                    evidence=evidence_ids,
                    timestamp=now,
                )
                detected.append(threat)

        # --- Rule 4: Prompt injection in inputs ---
        for a in recent:
            if "prompt_injection" in a.threat_flags:
                threat = self._register_threat(
                    agent_id=agent_id,
                    threat_type="prompt_injection",
                    severity="high",
                    description=(
                        f"Prompt injection pattern detected in input to "
                        f"'{a.tool_name}': {a.input_summary[:100]}"
                    ),
                    evidence=[a.id],
                    timestamp=now,
                )
                detected.append(threat)

        # --- Rule 5: Skill tampering ---
        for skill in self._skills.values():
            if not skill.verified and "TAMPERED" in skill.threat_assessment:
                threat = self._register_threat(
                    agent_id=agent_id,
                    threat_type="skill_tampering",
                    severity="critical",
                    description=(
                        f"Skill '{skill.name}' hash changed: "
                        f"{skill.threat_assessment}"
                    ),
                    evidence=[skill.tibet_token_id],
                    timestamp=now,
                )
                detected.append(threat)

        return detected

    # ------------------------------------------------------------------
    # enforce_boundary
    # ------------------------------------------------------------------

    def enforce_boundary(
        self,
        agent_id: str,
        action: str,
        policy: dict,
    ) -> bool:
        """
        Check if an action is within the agent's allowed boundary.

        Policy format::

            {
                "allowed_actions": ["tool_call", "file_access"],
                "allowed_tools": ["search_db", "read_file"],
                "allowed_paths": ["/data/", "/tmp/"],
                "denied_actions": ["shell_exec"],
            }

        Args:
            agent_id: Agent requesting the action
            action: The action type
            policy: Boundary policy dict

        Returns:
            True if allowed, False if boundary violation
        """
        self._stats["boundary_checks"] += 1

        allowed_actions = policy.get("allowed_actions", [])
        denied_actions = policy.get("denied_actions", [])

        # Check denied first (takes priority)
        if action in denied_actions:
            self._stats["boundary_violations"] += 1
            self._register_threat(
                agent_id=agent_id,
                threat_type="boundary_violation",
                severity="high",
                description=(
                    f"Agent '{agent_id}' attempted denied action: {action}"
                ),
                evidence=[],
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            return False

        # Check allowed list (if specified, must be in it)
        if allowed_actions and action not in allowed_actions:
            self._stats["boundary_violations"] += 1
            self._register_threat(
                agent_id=agent_id,
                threat_type="boundary_violation",
                severity="high",
                description=(
                    f"Agent '{agent_id}' attempted action '{action}' "
                    f"outside allowed set: {allowed_actions}"
                ),
                evidence=[],
                timestamp=datetime.now(timezone.utc).isoformat(),
            )
            return False

        return True

    # ------------------------------------------------------------------
    # audit_trail
    # ------------------------------------------------------------------

    def audit_trail(
        self,
        agent_id: str,
        since: str = "",
    ) -> list[dict]:
        """
        Full action history for an agent.

        Args:
            agent_id: Agent to retrieve trail for
            since: ISO 8601 timestamp to filter from (optional)

        Returns:
            List of ActionRecord dicts, oldest first
        """
        records = [a for a in self._actions if a.agent_id == agent_id]

        if since:
            records = [a for a in records if a.timestamp >= since]

        return [a.to_dict() for a in records]

    # ------------------------------------------------------------------
    # agent_trust_score
    # ------------------------------------------------------------------

    def agent_trust_score(self, agent_id: str) -> float:
        """
        Trust score for an agent based on action history.

        Starts at 0.5. Goes up for clean actions, down for violations.
        Range: 0.0 (fully untrusted) to 1.0 (fully trusted).
        """
        return self._trust_scores.get(agent_id, 0.5)

    # ------------------------------------------------------------------
    # stats
    # ------------------------------------------------------------------

    def stats(self) -> dict:
        """Guard dashboard statistics."""
        return {
            "actions_recorded": self._stats["actions_recorded"],
            "actions_allowed": self._stats["actions_allowed"],
            "actions_blocked": self._stats["actions_blocked"],
            "block_rate": (
                round(
                    self._stats["actions_blocked"]
                    / self._stats["actions_recorded"]
                    * 100, 1,
                )
                if self._stats["actions_recorded"] > 0 else 0.0
            ),
            "skills_checked": self._stats["skills_checked"],
            "skills_verified": self._stats["skills_verified"],
            "skills_rejected": self._stats["skills_rejected"],
            "threats_detected": self._stats["threats_detected"],
            "boundary_checks": self._stats["boundary_checks"],
            "boundary_violations": self._stats["boundary_violations"],
            "unique_agents": len(self._trust_scores),
            "tibet_tokens": len(self.provenance.chain()),
        }

    def export_audit(self) -> list[dict]:
        """Export the full TIBET token chain."""
        return self.provenance.chain()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _scan_action(
        self,
        action: str,
        tool: str,
        input_data: object,
    ) -> list[str]:
        """Scan an action for threat patterns before recording."""
        flags: list[str] = []
        text = _to_text(input_data)

        # Privilege escalation in shell commands
        if action == "shell_exec":
            for pattern in _PRIVESC_PATTERNS:
                if pattern.search(text):
                    flags.append("privilege_escalation")
                    break

        # Prompt injection patterns
        for pattern in _INJECTION_PATTERNS:
            if pattern.search(text):
                flags.append("prompt_injection")
                break

        return flags

    def _register_threat(
        self,
        agent_id: str,
        threat_type: str,
        severity: str,
        description: str,
        evidence: list[str],
        timestamp: str,
    ) -> ThreatDetection:
        """Register a detected threat and create TIBET token."""
        self._stats["threats_detected"] += 1

        token = self.provenance.create_threat_token(
            agent_id=agent_id,
            threat_type=threat_type,
            severity=severity,
            description=description,
            evidence=evidence,
        )

        threat = ThreatDetection(
            id=token.token_id,
            timestamp=timestamp,
            agent_id=agent_id,
            threat_type=threat_type,
            severity=severity,
            description=description,
            evidence=evidence,
            mitigated=False,
        )
        self._threats.append(threat)
        return threat

    def _adjust_trust(
        self,
        agent_id: str,
        allowed: bool,
        threat_flags: list[str],
    ) -> None:
        """Adjust trust score for an agent based on action outcome."""
        current = self._trust_scores.get(agent_id, 0.5)

        if allowed and not threat_flags:
            # Clean action: small trust increase
            current = min(current + 0.01, 1.0)
        elif threat_flags:
            # Threats detected: significant trust decrease
            penalty = 0.1 * len(threat_flags)
            current = max(current - penalty, 0.0)

        self._trust_scores[agent_id] = round(current, 4)

    def _action_in_window(
        self,
        action: ActionRecord,
        cutoff_ts: float,
    ) -> bool:
        """Check if an action is within the time window."""
        try:
            action_dt = datetime.fromisoformat(action.timestamp)
            return action_dt.timestamp() >= cutoff_ts
        except (ValueError, TypeError):
            return True  # If we can't parse, include it

    @property
    def threats(self) -> list[ThreatDetection]:
        """All detected threats."""
        return list(self._threats)


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _summarize(data: object, max_len: int = 120) -> str:
    """Create a short text summary of arbitrary data."""
    if data is None:
        return ""
    text = str(data)
    if len(text) > max_len:
        return text[:max_len] + "..."
    return text


def _to_text(data: object) -> str:
    """Convert arbitrary data to searchable text."""
    if data is None:
        return ""
    if isinstance(data, str):
        return data
    if isinstance(data, dict):
        return " ".join(str(v) for v in data.values())
    if isinstance(data, (list, tuple)):
        return " ".join(str(v) for v in data)
    return str(data)
