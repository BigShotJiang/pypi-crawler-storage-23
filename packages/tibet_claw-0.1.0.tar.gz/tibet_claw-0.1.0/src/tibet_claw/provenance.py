"""
TIBET provenance for agent actions.

Every agent action, every tool call, every skill execution
is recorded as a TIBET token. The chain is the safety audit trail.

Token layers:
  ERIN      — what the agent did (action, tool, input/output hashes)
  ERAAN     — what it connects to (agent identity, skill source, chain)
  EROMHEEN  — context around it (platform, model, hostname, timestamp)
  ERACHTER  — what is behind it (user intent, reasoning, safety assessment)
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class ClawToken:
    """
    A TIBET provenance token for an agent action.

    Every action an agent takes — tool call, file access, network request,
    shell execution — produces one token. The chain of tokens is the
    complete audit trail.
    """
    token_id: str
    timestamp: str
    token_type: str  # action, skill_check, threat, boundary
    agent_id: str
    action: str
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": self.token_type,
            "agent_id": self.agent_id,
            "action": self.action,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


def _hash_data(data: object) -> str:
    """Create a SHA-256 hash of arbitrary data for provenance."""
    raw = json.dumps(data, sort_keys=True, default=str)
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


class ClawProvenance:
    """
    TIBET provenance engine for agent actions.

    Maintains a chain of tokens. Each token references its parent,
    forming a tamper-evident audit trail.

    Usage::

        prov = ClawProvenance(platform="openclaw", model="gpt-4")
        token = prov.create_action_token(
            agent_id="agent-01",
            action="tool_call",
            tool="search_db",
            input_data={"query": "..."},
            output_data={"rows": 42},
            user_intent="Find records",
        )
    """

    def __init__(
        self,
        platform: str = "unknown",
        model: str = "unknown",
        actor: str = "tibet-claw",
    ):
        self.platform = platform
        self.model = model
        self.actor = actor
        self.tokens: list[ClawToken] = []
        self._last_id: str | None = None

    def create_action_token(
        self,
        agent_id: str,
        action: str,
        tool: str = "",
        input_data: object = None,
        output_data: object = None,
        user_intent: str = "",
        allowed: bool = True,
        safety_assessment: str = "nominal",
    ) -> ClawToken:
        """Create a TIBET token for an agent action."""
        now = datetime.now(timezone.utc).isoformat()

        input_hash = _hash_data(input_data) if input_data else ""
        output_hash = _hash_data(output_data) if output_data else ""

        erin = {
            "action": action,
            "tool": tool,
            "input_hash": input_hash,
            "output_hash": output_hash,
            "allowed": allowed,
        }
        eraan = {
            "agent_jis": f"jis:agent:{agent_id}",
            "skill_source": tool,
            "previous_action": self._last_id,
        }
        eromheen = {
            "platform": self.platform,
            "model": self.model,
            "hostname": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "user_intent": user_intent,
            "safety_assessment": safety_assessment,
            "decision": "ALLOW" if allowed else "BLOCK",
        }

        token_id = hashlib.sha256(
            f"{agent_id}:{action}:{tool}:{now}".encode()
        ).hexdigest()[:16]
        content = json.dumps({"erin": erin}, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = ClawToken(
            token_id=token_id,
            timestamp=now,
            token_type="action",
            agent_id=agent_id,
            action=action,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def create_skill_token(
        self,
        agent_id: str,
        skill_name: str,
        skill_source: str,
        skill_hash: str,
        verified: bool,
        threat_assessment: str = "",
    ) -> ClawToken:
        """Create a TIBET token for a skill provenance check."""
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "action": "skill_check",
            "skill_name": skill_name,
            "skill_hash": skill_hash,
            "verified": verified,
        }
        eraan = {
            "agent_jis": f"jis:agent:{agent_id}",
            "skill_source": skill_source,
            "previous_action": self._last_id,
        }
        eromheen = {
            "platform": self.platform,
            "model": self.model,
            "hostname": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "purpose": f"Verify skill: {skill_name}",
            "threat_assessment": threat_assessment,
            "decision": "VERIFIED" if verified else "REJECTED",
        }

        token_id = hashlib.sha256(
            f"skill:{skill_name}:{skill_hash}:{now}".encode()
        ).hexdigest()[:16]
        content = json.dumps({"erin": erin}, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = ClawToken(
            token_id=token_id,
            timestamp=now,
            token_type="skill_check",
            agent_id=agent_id,
            action="skill_check",
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def create_threat_token(
        self,
        agent_id: str,
        threat_type: str,
        severity: str,
        description: str,
        evidence: list[str],
    ) -> ClawToken:
        """Create a TIBET token for a detected threat."""
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "action": "threat_detection",
            "threat_type": threat_type,
            "severity": severity,
            "evidence_count": len(evidence),
        }
        eraan = {
            "agent_jis": f"jis:agent:{agent_id}",
            "evidence_ids": evidence,
            "previous_action": self._last_id,
        }
        eromheen = {
            "platform": self.platform,
            "model": self.model,
            "hostname": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "description": description,
            "safety_critical": severity in ("critical", "high"),
            "decision": "ALERT",
        }

        token_id = hashlib.sha256(
            f"threat:{agent_id}:{threat_type}:{now}".encode()
        ).hexdigest()[:16]
        content = json.dumps({"erin": erin}, sort_keys=True)
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = ClawToken(
            token_id=token_id,
            timestamp=now,
            token_type="threat",
            agent_id=agent_id,
            action="threat_detection",
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        """Return the full token chain as dicts."""
        return [t.to_dict() for t in self.tokens]

    def chain_for_agent(self, agent_id: str) -> list[dict]:
        """Return tokens for a specific agent."""
        return [t.to_dict() for t in self.tokens if t.agent_id == agent_id]
