"""
tibet-claw — Provenance & Safety Layer for AI Agents
=====================================================

Every agent action = TIBET token. Every tool call = audited.
Every skill = provenance-checked.

OpenClaw has 211K stars and 512 known vulnerabilities.
CrowdStrike, NCC Group, Kaspersky, Cisco, Malwarebytes all flagged it.
tibet-claw fixes what they found: no provenance, no audit trail,
no tool access control, prompt injection blind spots.

Wraps ANY Claw-family agent (OpenClaw, NanoClaw, PicoClaw, ZeroClaw)
or any autonomous agent with full TIBET provenance.

Usage::

    from tibet_claw import AgentGuard, ActionRecord, SkillProfile

    guard = AgentGuard(platform="openclaw", model="gpt-4")

    record = guard.record_action(
        agent_id="agent-01",
        action="tool_call",
        tool="search_db",
        input_data={"query": "..."},
        output_data={"rows": 42},
        user_intent="Find records",
    )

    threats = guard.detect_threats("agent-01")
    for t in threats:
        print(f"[{t.severity}] {t.threat_type}: {t.description}")

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .guard import AgentGuard, ActionRecord, SkillProfile, ThreatDetection
from .provenance import ClawProvenance

__version__ = "0.1.0"

__all__ = [
    "AgentGuard",
    "ActionRecord",
    "SkillProfile",
    "ThreatDetection",
    "ClawProvenance",
]
