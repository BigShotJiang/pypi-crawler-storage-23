# AgenLang

Shared contract substrate for secure, auditable inter-agent communication (OpenClaw ↔ ZHC ↔ personal agents).

https://github.com/iamsharathbhaskar/AgenLang
