#!/usr/bin/env python3
"""
End-to-end test script for personal email sequences (Gmail / Microsoft Graph).

What it does:
1) Connects to MongoDB (MONGODB_URI env)
2) Resolves organization and user from USER_EMAIL (e.g., nick@autotouch.ai)
3) Chooses a personal provider based on available mail_users (google or microsoft)
4) Creates or reuses a test lead (TEST_RECIPIENT_EMAIL)
5) Inserts a minimal personal sequence with one automated email step
6) Enrolls the lead and immediately sends the first step via orchestrator

Environment variables:
  MONGODB_URI           - MongoDB connection string
  USER_EMAIL            - Sender mailbox user (e.g., nick@autotouch.ai)
  TEST_RECIPIENT_EMAIL  - Lead email to send to (external mailbox you control)
  TEST_SEQUENCE_NAME    - Optional sequence name (default: 'E2E Personal Mail Test')

Usage:
  python scripts/test_sequences_personal_e2e.py
"""

from __future__ import annotations

import asyncio
import os
from datetime import datetime
from typing import Any, Dict, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient


async def _utcnow() -> datetime:
    return datetime.utcnow()


async def _ensure_org_and_user(db, user_email: str) -> tuple[str, str]:
    user = await db.users.find_one({"email": user_email})
    if not user:
        raise RuntimeError(f"User not found: {user_email}")
    org_id = user.get("organization_id")
    if not org_id:
        raise RuntimeError("User missing organization_id")
    return str(org_id), str(user.get("_id"))


async def _find_personal_provider(db, organization_id: str, user_id: str) -> str:
    # Prefer Gmail; fallback to Microsoft
    org_match = [organization_id]
    try:
        org_match.append(ObjectId(organization_id))
    except Exception:
        pass

    gmail = await db.mail_users.find_one(
        {
            "organization_id": {"$in": org_match},
            "$or": [{"user_id": user_id}, {"user_id": str(user_id)}],
            "token_type": "google",
            "oauth_status": "ok",
        }
    )
    if gmail:
        return "gmail"
    ms = await db.mail_users.find_one(
        {
            "organization_id": {"$in": org_match},
            "$or": [{"user_id": user_id}, {"user_id": str(user_id)}],
            "token_type": "microsoft",
            "oauth_status": "ok",
        }
    )
    if ms:
        return "microsoft"
    raise RuntimeError("No connected personal mailbox for user")


async def _ensure_lead(db, organization_id: str, recipient_email: str) -> str:
    lead = await db.leads.find_one({
        "organization_id": organization_id,
        "$or": [
            {"email": recipient_email},
            {"email_addresses.address": recipient_email},
            {"email_addresses.email": recipient_email},
        ],
    })
    if lead:
        return str(lead.get("_id"))
    doc: Dict[str, Any] = {
        "organization_id": organization_id,
        "email": recipient_email,
        "email_addresses": [{"address": recipient_email}],
        "first_name": "E2E",
        "last_name": "Recipient",
        "created_at": await _utcnow(),
        "updated_at": await _utcnow(),
    }
    res = await db.leads.insert_one(doc)
    return str(res.inserted_id)


async def _insert_sequence(db, organization_id: str, user_id: str, name: str) -> str:
    now = await _utcnow()
    seq: Dict[str, Any] = {
        "organization_id": organization_id,
        "user_id": user_id,
        "name": name,
        "description": "E2E personal email test sequence",
        "status": "ACTIVE",
        "schedule": {
            "workingDays": [0, 1, 2, 3, 4, 5, 6],
            "dailyWindowStart": "00:00",
            "dailyWindowEnd": "23:59",
            "timezone": "UTC",
            "skipHolidays": False,
        },
        "emailDelivery": {
            "mode": "personal"
        },
        "steps": [
            {
                "id": "step-1",
                "kind": "EMAIL",
                "emailSendMode": "AUTOMATED",
                "emailIsReply": False,
                "waitDays": 0,
                "waitHours": 0,
                "subjectTemplate": "E2E Check",
                "bodyTemplate": "<p>Hello from Autotouch E2E test.</p>",
            }
        ],
        "exitRules": {"stopOnReply": True, "stopOnBounce": True, "stopOnManualOptOut": True},
        "created_at": now,
        "updated_at": now,
    }
    res = await db.sequences.insert_one(seq)
    return str(res.inserted_id)


async def _enroll_and_send(db, organization_id: str, sequence_id: str, user_id: str, lead_id: str) -> Dict[str, Any]:
    # Import services lazily and ensure PYTHONPATH includes repo root
    import os as _os, sys as _sys
    root = _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__)))
    if root not in _sys.path:
        _sys.path.insert(0, root)

    from apps.api.services.workflow.sequences.sequence_enrollment_service import create_enrollments
    from apps.api.services.workflow.sequences.email.send_orchestrator import send_sequence_email_step

    # Create enrollment (idempotent)
    await create_enrollments(
        db=db,
        organization_id=organization_id,
        user_id=user_id,
        sequence_id=sequence_id,
        lead_ids=[lead_id],
        start_date=None,
        research_context=None,
    )

    # Load fresh sequence/enrollment
    seq = await db.sequences.find_one({"_id": ObjectId(sequence_id), "organization_id": organization_id})
    enr = await db.sequence_enrollments.find_one({
        "organization_id": organization_id,
        "sequence_id": sequence_id,
        "lead_id": lead_id,
    })
    if not seq or not enr:
        raise RuntimeError("Enrollment not found after creation")

    step = (seq.get("steps") or [])[0]
    if not step:
        raise RuntimeError("Sequence has no steps")

    # Send first step (AUTOMATED EMAIL)
    result = await send_sequence_email_step(
        db=db,
        sequence=seq,
        enrollment=enr,
        step=step,
        step_index=0,
        variable_snapshot={},
    )
    return result


async def main() -> None:
    db_uri = os.getenv("MONGODB_URI") or "mongodb://localhost:27017/autotouch"
    user_email = os.getenv("USER_EMAIL", "nick@autotouch.ai")
    recipient_email = os.getenv("TEST_RECIPIENT_EMAIL")
    seq_name = os.getenv("TEST_SEQUENCE_NAME", "E2E Personal Mail Test")

    if not recipient_email:
        raise RuntimeError("TEST_RECIPIENT_EMAIL env must be set")

    client = AsyncIOMotorClient(db_uri)
    db = client.get_default_database()  # honor db name from URI

    org_id, user_id = await _ensure_org_and_user(db, user_email)
    provider = await _find_personal_provider(db, org_id, user_id)
    print(f"Resolved organization_id={org_id} user_id={user_id} provider={provider}")

    lead_id = await _ensure_lead(db, org_id, recipient_email)
    print(f"Using lead_id={lead_id} for {recipient_email}")

    seq_id = await _insert_sequence(db, org_id, user_id, seq_name)
    print(f"Created sequence_id={seq_id}")

    result = await _enroll_and_send(db, org_id, seq_id, user_id, lead_id)
    print("Send result:", result)


if __name__ == "__main__":
    asyncio.run(main())
