#!/usr/bin/env python3
"""
Attach (link) existing CRM leads to a research table by adding the table id to
Lead.research_table_ids[].

This is the lightweight way to make CSV-imported leads show up when filtering
Engage by a research table with source_table_scope=lead.
"""

from __future__ import annotations

import argparse
import os
import sys
from typing import Any, Dict, List, Optional

import certifi
from bson import ObjectId
from pymongo import MongoClient


def _coerce_oid(s: str) -> Optional[ObjectId]:
    try:
        return ObjectId(s)
    except Exception:
        return None


def _mongo_db(uri: str, db_name: str):
    # Atlas requires a CA bundle in some environments.
    return MongoClient(uri, serverSelectionTimeoutMS=20_000, tlsCAFile=certifi.where())[db_name]


def main(argv: Optional[List[str]] = None) -> int:
    p = argparse.ArgumentParser(
        description="Attach CSV-imported leads to a research table via research_table_ids[]",
    )
    p.add_argument("--org-id", required=True, help="Organization UUID (string)")
    p.add_argument("--table-id", required=True, help="Research table _id (ObjectId string)")
    p.add_argument(
        "--source",
        default="csv_import",
        help="Match lead_source/source value (default: csv_import)",
    )
    p.add_argument("--uri", default=os.getenv("MONGODB_URI", ""), help="MongoDB connection string")
    p.add_argument("--db-name", default=os.getenv("MONGODB_DB_NAME", "autotouch"))
    p.add_argument("--dry-run", action="store_true", help="Print what would change without writing")
    p.add_argument("--limit", type=int, default=0, help="Optional limit for update (0 = no limit)")
    args = p.parse_args(argv)

    uri = args.uri.strip() or os.getenv("MONGODB_PROD_CONNECTION_STRING", "").strip()
    if not uri:
        print("Missing MongoDB URI (pass --uri or set MONGODB_URI / MONGODB_PROD_CONNECTION_STRING).", file=sys.stderr)
        return 2

    org_id = args.org_id.strip()
    table_id_str = args.table_id.strip()
    source = args.source.strip()

    db = _mongo_db(uri, args.db_name)

    # Validate table exists and belongs to org (defensive safety check).
    table_oid = _coerce_oid(table_id_str)
    table = db.tables.find_one(
        {"_id": table_oid or table_id_str, "organization_id": org_id},
        {"name": 1, "organization_id": 1, "status": 1},
    )
    if not table:
        print(f"Table not found for org_id={org_id} table_id={table_id_str}", file=sys.stderr)
        return 1
    if table.get("status") in {"deleting", "deleted"}:
        print(f"Refusing to attach to table in status={table.get('status')}", file=sys.stderr)
        return 1

    variants: List[Any] = [table_id_str]
    if table_oid is not None:
        variants.append(table_oid)

    base_org = {"$or": [{"organization_id": org_id}, {"org_id": org_id}]}
    base_source = {"$or": [{"lead_source": source}, {"source": source}]}
    query: Dict[str, Any] = {
        "$and": [
            base_org,
            base_source,
            {"research_table_ids": {"$nin": variants}},
        ]
    }

    total_candidates = db.leads.count_documents({"$and": [base_org, base_source]})
    to_update = db.leads.count_documents(query)

    table_name = table.get("name") or ""
    print(f"Table: {table_id_str} {table_name!r}")
    print(f"Org:   {org_id}")
    print(f"Match: lead_source/source == {source!r}")
    print(f"Leads matching source in org: {total_candidates}")
    print(f"Leads missing table link:     {to_update}")

    if to_update == 0:
        return 0

    sample = list(
        db.leads.find(query, {"_id": 1, "company_domain": 1, "linkedin_url": 1, "lead_source": 1, "created_at": 1})
        .sort("created_at", -1)
        .limit(5)
    )
    if sample:
        print("Sample leads to update (max 5):")
        for d in sample:
            print(f"- {str(d.get('_id'))}\t{d.get('company_domain','')}\t{d.get('linkedin_url','')}")

    if args.dry_run:
        print("Dry run: no writes performed.")
        return 0

    update = {"$addToSet": {"research_table_ids": table_id_str}}
    if args.limit and args.limit > 0:
        # Apply a limit by selecting ids first. (Mongo update_many has no limit.)
        ids = [d["_id"] for d in db.leads.find(query, {"_id": 1}).limit(int(args.limit))]
        res = db.leads.update_many({"_id": {"$in": ids}}, update)
    else:
        res = db.leads.update_many(query, update)

    print(f"Updated: matched={res.matched_count} modified={res.modified_count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

