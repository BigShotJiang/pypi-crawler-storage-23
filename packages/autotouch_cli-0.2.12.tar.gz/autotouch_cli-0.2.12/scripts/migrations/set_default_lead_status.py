"""
Migration script to backfill `lead_status` for a specific organization.

Usage:
    python3 scripts/migrations/set_default_lead_status.py

Environment variables:
    MONGODB_URI - optional override for the Mongo connection string.
    MONGODB_DB_NAME - optional override for the database name (defaults to 'autotouch').
"""

import os
from typing import Any, Dict

import pymongo

DEFAULT_URI = "mongodb+srv://mongo_autotouch:autotouch@cluster1.dlvbh5h.mongodb.net/autotouch"
DEFAULT_DB_NAME = "autotouch"

# Organization to update (from user request / sample payload)
TARGET_ORGANIZATION_ID = "b9cc2f99-dc12-47f6-8e7c-9fbf34c59221"


def main() -> None:
    uri = os.getenv("MONGODB_URI", DEFAULT_URI)
    db_name = os.getenv("MONGODB_DB_NAME", DEFAULT_DB_NAME)

    client = pymongo.MongoClient(uri, serverSelectionTimeoutMS=10_000)
    db = client[db_name]
    leads = db["leads"]

    query: Dict[str, Any] = {
        "organization_id": TARGET_ORGANIZATION_ID,
        "$or": [
            {"lead_status": {"$exists": False}},
            {"lead_status": None},
            {"lead_status": ""},
        ],
    }
    update: Dict[str, Any] = {"$set": {"lead_status": "new"}}

    result = leads.update_many(query, update)
    print(
        f"Matched {result.matched_count} leads, modified {result.modified_count} leads for org {TARGET_ORGANIZATION_ID}.",
    )


if __name__ == "__main__":
    main()
