"""
Sync lead ownership (leads.user_id) with task assignments (task_queue.assigned_to).

Use when tasks are assigned but lead owners are missing or out of sync, so
"My Leads" should reflect the user's active tasks.

Usage:
  python3 scripts/migrations/20260204_sync_lead_owner_from_tasks.py \
    --uri "<mongodb uri>" --db autotouch --apply

Defaults to dry-run; pass --apply to write changes.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple

from bson import ObjectId
from pymongo import MongoClient, UpdateOne


DEFAULT_STATUSES = ("pending", "queued", "created")


def _coerce_oid(value: Any) -> Optional[ObjectId]:
    if isinstance(value, ObjectId):
        return value
    if isinstance(value, str):
        try:
            return ObjectId(value)
        except Exception:
            return None
    return None


def _stringify(value: Any) -> Optional[str]:
    if value is None:
        return None
    if isinstance(value, str):
        val = value.strip()
        return val or None
    if isinstance(value, ObjectId):
        return str(value)
    return str(value).strip() or None


def _build_id_variants(raw_id: Any) -> List[Dict[str, Any]]:
    variants: List[Dict[str, Any]] = []
    if raw_id is None:
        return variants

    if isinstance(raw_id, ObjectId):
        variants.append({"_id": raw_id})
        variants.append({"_id": str(raw_id)})
        return variants

    raw_str = str(raw_id).strip()
    if raw_str:
        variants.append({"_id": raw_str})
        oid = _coerce_oid(raw_str)
        if oid is not None:
            variants.append({"_id": oid})

    return variants


def _build_org_variants(org_id: Any) -> List[Dict[str, Any]]:
    variants: List[Dict[str, Any]] = []
    if org_id is None:
        return variants
    variants.append({"organization_id": org_id})
    variants.append({"org_id": org_id})
    org_oid = _coerce_oid(org_id)
    if org_oid is not None:
        variants.append({"organization_id": org_oid})
        variants.append({"org_id": org_oid})
    return variants


def _normalize_assignees(raw_assignees: Iterable[Any]) -> List[str]:
    out: List[str] = []
    seen = set()
    for raw in raw_assignees:
        val = _stringify(raw)
        if not val or val in seen:
            continue
        seen.add(val)
        out.append(val)
    return out


def run_migration(
    db,
    apply: bool,
    *,
    org_id: Optional[str] = None,
    statuses: Tuple[str, ...] = DEFAULT_STATUSES,
    limit: Optional[int] = None,
    batch_size: int = 500,
    skip_conflicts: bool = False,
) -> Dict[str, Any]:
    match: Dict[str, Any] = {
        "assigned_to": {"$exists": True, "$ne": None, "$ne": ""},
        "lead_id": {"$exists": True, "$ne": None, "$ne": ""},
    }
    if statuses:
        match["task_status"] = {"$in": list(statuses)}
    if org_id:
        match["organization_id"] = org_id

    pipeline: List[Dict[str, Any]] = [
        {"$match": match},
        {"$sort": {"updated_at": -1, "created_at": -1, "_id": -1}},
        {
            "$group": {
                "_id": {"organization_id": "$organization_id", "lead_id": "$lead_id"},
                "assigned_to": {"$first": "$assigned_to"},
                "task_id": {"$first": "$_id"},
                "task_updated_at": {"$first": "$updated_at"},
                "task_status": {"$first": "$task_status"},
                "assignees": {"$addToSet": "$assigned_to"},
            }
        },
    ]
    if limit and limit > 0:
        pipeline.append({"$limit": limit})

    cursor = db.task_queue.aggregate(pipeline, allowDiskUse=True)

    stats = {
        "groups_processed": 0,
        "updates_planned": 0,
        "updates_applied": 0,
        "leads_matched": 0,
        "conflicts": 0,
        "conflicts_skipped": 0,
    }

    pending_ops: List[UpdateOne] = []
    now = datetime.now(timezone.utc)

    def flush_ops() -> None:
        if not pending_ops:
            return
        if apply:
            result = db.leads.bulk_write(pending_ops, ordered=False)
            stats["updates_applied"] += int(result.modified_count or 0)
            stats["leads_matched"] += int(result.matched_count or 0)
        pending_ops.clear()

    for doc in cursor:
        stats["groups_processed"] += 1
        group = doc.get("_id") or {}
        org_value = group.get("organization_id")
        lead_value = group.get("lead_id")
        assigned_to = _stringify(doc.get("assigned_to"))
        if not assigned_to:
            continue

        assignees = _normalize_assignees(doc.get("assignees") or [])
        if len(assignees) > 1:
            stats["conflicts"] += 1
            if skip_conflicts:
                stats["conflicts_skipped"] += 1
                continue

        id_variants = _build_id_variants(lead_value)
        if not id_variants:
            continue

        org_variants = _build_org_variants(org_value)
        if not org_variants:
            # If org missing, skip to avoid accidental cross-org updates.
            continue

        update_filter: Dict[str, Any] = {
            "$and": [
                {"$or": org_variants},
                {"$or": id_variants},
                {
                    "$or": [
                        {"user_id": {"$exists": False}},
                        {"user_id": None},
                        {"user_id": ""},
                        {"user_id": {"$ne": assigned_to}},
                    ]
                },
            ]
        }
        update_doc = {"$set": {"user_id": assigned_to, "updated_at": now}}
        pending_ops.append(UpdateOne(update_filter, update_doc))
        stats["updates_planned"] += 1

        if len(pending_ops) >= batch_size:
            flush_ops()

    flush_ops()

    return stats


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Sync lead.user_id with task_queue.assigned_to (from active tasks)."
    )
    parser.add_argument("--uri", required=True, help="MongoDB connection string")
    parser.add_argument("--db", default="autotouch", help="Database name (default: autotouch)")
    parser.add_argument("--org-id", default=None, help="Restrict to a single organization_id")
    parser.add_argument(
        "--statuses",
        default=",".join(DEFAULT_STATUSES),
        help=f"Comma-separated task_status values to consider (default: {','.join(DEFAULT_STATUSES)})",
    )
    parser.add_argument("--limit", type=int, default=None, help="Limit number of lead groups processed")
    parser.add_argument("--batch-size", type=int, default=500, help="Bulk write batch size")
    parser.add_argument(
        "--skip-conflicts",
        action="store_true",
        help="Skip leads that have tasks assigned to multiple users",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply changes (otherwise dry-run)",
    )
    parser.add_argument(
        "--tls-insecure",
        action="store_true",
        help="Allow invalid TLS certificates (use if local trust store is missing Atlas CA).",
    )
    args = parser.parse_args()

    statuses = tuple([s.strip() for s in args.statuses.split(",") if s.strip()])

    client_kwargs = {}
    if args.tls_insecure:
        client_kwargs["tlsAllowInvalidCertificates"] = True
    client = MongoClient(args.uri, **client_kwargs)
    db = client[args.db]

    stats = run_migration(
        db,
        apply=args.apply,
        org_id=args.org_id,
        statuses=statuses,
        limit=args.limit,
        batch_size=args.batch_size,
        skip_conflicts=args.skip_conflicts,
    )

    print("Lead owner sync summary:")
    for key in (
        "groups_processed",
        "updates_planned",
        "updates_applied",
        "leads_matched",
        "conflicts",
        "conflicts_skipped",
    ):
        print(f"  - {key}: {stats[key]}")

    if not args.apply:
        print("Dry run only. Re-run with --apply to persist changes.")


if __name__ == "__main__":
    main()
