#!/usr/bin/env python3
"""
Cleanup migration to remove old agent_metadata field from cells collection.

This migration removes the deprecated agent_metadata field after successful
migration to the new metadata field structure.

Run with: python migrations/20250608_cleanup_agent_metadata.py
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime


async def cleanup():
    # Connect to MongoDB
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB_NAME', 'smart_table')
    
    client = AsyncIOMotorClient(mongodb_uri)
    db = client[db_name]
    
    print(f"Starting cleanup on database: {db_name}")
    print(f"Timestamp: {datetime.now()}")
    
    # Count cells with agent_metadata field
    cells_with_agent_metadata = await db.cells.count_documents({
        "agent_metadata": {"$exists": True}
    })
    
    print(f"Found {cells_with_agent_metadata} cells with agent_metadata field to clean up")
    
    if cells_with_agent_metadata == 0:
        print("No cells to clean up. Exiting.")
        return
    
    # Verify all cells with agent_metadata also have metadata field
    cells_without_metadata = await db.cells.count_documents({
        "agent_metadata": {"$exists": True},
        "metadata": {"$exists": False}
    })
    
    if cells_without_metadata > 0:
        print(f"WARNING: Found {cells_without_metadata} cells with agent_metadata but no metadata field!")
        print("Please run the migration script first: 20250608_rename_agent_metadata_to_metadata.py")
        return
    
    # Remove agent_metadata field
    print("Removing old agent_metadata field...")
    result = await db.cells.update_many(
        {"agent_metadata": {"$exists": True}},
        {"$unset": {"agent_metadata": ""}}
    )
    
    print(f"Removed agent_metadata field from {result.modified_count} cells")
    
    # Verify cleanup
    remaining = await db.cells.count_documents({
        "agent_metadata": {"$exists": True}
    })
    
    print(f"\nCleanup complete!")
    print(f"Remaining cells with agent_metadata: {remaining}")
    
    # Show updated document structure
    sample = await db.cells.find_one({
        "metadata": {"$exists": True},
        "metadata.type": "agent"
    })
    
    if sample:
        print("\nSample document after cleanup:")
        print(f"  row_id: {sample.get('row_id')}")
        print(f"  column_id: {sample.get('column_id')}")
        print(f"  has metadata: {'metadata' in sample}")
        print(f"  has agent_metadata: {'agent_metadata' in sample}")
        print(f"  metadata.type: {sample.get('metadata', {}).get('type')}")
    
    client.close()


if __name__ == "__main__":
    asyncio.run(cleanup())