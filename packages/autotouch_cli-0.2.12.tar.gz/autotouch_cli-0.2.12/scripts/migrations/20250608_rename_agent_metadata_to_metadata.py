#!/usr/bin/env python3
"""
Migration script to rename agent_metadata field to metadata in cells collection.

This migration:
1. Renames agent_metadata field to metadata
2. Adds a 'type' field set to 'agent' for all existing agent metadata
3. Maintains backwards compatibility during the transition

Run with: python migrations/20250608_rename_agent_metadata_to_metadata.py
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime


async def migrate():
    # Connect to MongoDB
    mongodb_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB_NAME', 'smart_table')
    
    client = AsyncIOMotorClient(mongodb_uri)
    db = client[db_name]
    
    print(f"Starting migration on database: {db_name}")
    print(f"Timestamp: {datetime.now()}")
    
    # Count cells with agent_metadata
    cells_with_agent_metadata = await db.cells.count_documents({
        "agent_metadata": {"$exists": True}
    })
    
    print(f"Found {cells_with_agent_metadata} cells with agent_metadata field")
    
    if cells_with_agent_metadata == 0:
        print("No cells to migrate. Exiting.")
        return
    
    # Perform the migration
    print("Starting migration...")
    
    # Update all documents that have agent_metadata but no metadata field
    result = await db.cells.update_many(
        {
            "agent_metadata": {"$exists": True},
            "metadata": {"$exists": False}
        },
        [
            {
                "$set": {
                    "metadata": {
                        "$mergeObjects": [
                            {"type": "agent"},
                            "$agent_metadata"
                        ]
                    }
                }
            }
        ]
    )
    
    print(f"Migrated {result.modified_count} cells to use metadata field")
    
    # Optional: Remove agent_metadata field after migration
    # Uncomment the following lines if you want to remove the old field
    # print("Removing old agent_metadata field...")
    # result = await db.cells.update_many(
    #     {"agent_metadata": {"$exists": True}},
    #     {"$unset": {"agent_metadata": ""}}
    # )
    # print(f"Removed agent_metadata field from {result.modified_count} cells")
    
    # Verify migration
    cells_with_metadata = await db.cells.count_documents({
        "metadata": {"$exists": True},
        "metadata.type": "agent"
    })
    
    print(f"\nMigration complete!")
    print(f"Total cells with metadata field: {cells_with_metadata}")
    
    # Show a sample migrated document
    sample = await db.cells.find_one({
        "metadata": {"$exists": True},
        "metadata.type": "agent"
    })
    
    if sample:
        print("\nSample migrated document:")
        print(f"  row_id: {sample.get('row_id')}")
        print(f"  column_id: {sample.get('column_id')}")
        print(f"  metadata.type: {sample.get('metadata', {}).get('type')}")
        print(f"  metadata.mode: {sample.get('metadata', {}).get('mode')}")
        if sample.get('metadata', {}).get('summary'):
            print(f"  metadata.summary.total_steps: {sample.get('metadata', {}).get('summary', {}).get('total_steps')}")
    
    client.close()


if __name__ == "__main__":
    asyncio.run(migrate())