#!/usr/bin/env python3
"""
Migration script to rename autotouch.call_logs to call_logs
This removes the 'autotouch' prefix from the collection name.
"""

import asyncio
import sys
import os
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "autotouch")

async def rename_call_logs_collection():
    """Rename autotouch.call_logs to call_logs"""
    
    print("🔄 Renaming autotouch.call_logs to call_logs...")
    
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    try:
        # Check if source collection exists
        collections = await db.list_collection_names()
        source_collection = 'autotouch.call_logs'
        target_collection = 'call_logs'
        
        if source_collection not in collections:
            print(f"❌ Source collection '{source_collection}' not found")
            print(f"Available collections: {collections}")
            return
        
        # Check if target collection already exists
        if target_collection in collections:
            print(f"⚠️  Target collection '{target_collection}' already exists, dropping it first")
            await db.drop_collection(target_collection)
        
        # Count documents in source collection
        source_count = await db[source_collection].count_documents({})
        print(f"📊 Found {source_count} documents in source collection")
        
        if source_count == 0:
            print("⚠️  Source collection is empty, nothing to migrate")
            return
        
        # Copy all documents to new collection
        print("📋 Copying documents to new collection...")
        cursor = db[source_collection].find()
        documents = []
        async for doc in cursor:
            documents.append(doc)
        
        if documents:
            await db[target_collection].insert_many(documents)
            print(f"✅ Copied {len(documents)} documents to {target_collection}")
        
        # Verify the copy
        new_count = await db[target_collection].count_documents({})
        if new_count == source_count:
            print("✅ Document count matches - migration successful")
            
            # Drop the old collection
            print("🗑️  Dropping old collection...")
            await db.drop_collection(source_collection)
            
            print("🎉 Collection rename complete!")
            print(f"   - Old: autotouch.call_logs")
            print(f"   - New: call_logs")
            print(f"   - Documents migrated: {new_count}")
            
        else:
            print(f"❌ Document count mismatch: source={source_count}, new={new_count}")
            print("🔄 Rolling back...")
            await db.drop_collection(target_collection)
            
    except Exception as e:
        print(f"❌ Migration failed: {e}")
        # Clean up on error
        try:
            await db.drop_collection(target_collection)
        except:
            pass
        raise
    finally:
        client.close()

if __name__ == "__main__":
    asyncio.run(rename_call_logs_collection())
