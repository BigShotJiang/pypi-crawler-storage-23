#!/usr/bin/env python3
"""Migration to add position field to existing columns."""

import os
import sys
from pymongo import MongoClient
from datetime import datetime

# Add parent directory to path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def migrate():
    """Add position field to existing columns."""
    # Connect to MongoDB
    client = MongoClient(os.getenv('MONGODB_URI', 'mongodb://localhost:27017'))
    db = client[os.getenv('MONGODB_DB_NAME', 'smart_table')]
    
    print(f"Starting migration: add_column_position at {datetime.now()}")
    
    # Get all tables
    tables = list(db.tables.find())
    print(f"Found {len(tables)} tables to process")
    
    updated_count = 0
    
    for table in tables:
        table_id = str(table['_id'])
        table_name = table.get('name', 'Unknown')
        print(f"\nProcessing table: {table_name} ({table_id})")
        
        # Get all columns for this table
        columns = list(db.columns.find({'table_id': table_id}).sort('_id', 1))
        
        if not columns:
            print(f"  No columns found")
            continue
            
        # Update each column with a position if it doesn't have one
        for index, column in enumerate(columns):
            column_id = column['_id']
            column_label = column.get('label', 'Unknown')
            
            if 'position' not in column:
                position = (index + 1) * 1000.0
                result = db.columns.update_one(
                    {'_id': column_id},
                    {'$set': {'position': position}}
                )
                
                if result.modified_count > 0:
                    print(f"  Updated column '{column_label}' with position {position}")
                    updated_count += 1
                    
                    # Also update in the table's columns array
                    db.tables.update_one(
                        {'_id': table['_id'], 'columns.id': str(column_id)},
                        {'$set': {'columns.$.position': position}}
                    )
            else:
                print(f"  Column '{column_label}' already has position {column['position']}")
    
    print(f"\nMigration completed. Updated {updated_count} columns.")
    client.close()

if __name__ == "__main__":
    migrate()