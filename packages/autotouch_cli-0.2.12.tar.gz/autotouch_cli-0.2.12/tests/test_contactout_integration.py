#!/usr/bin/env python3
"""
Test ContactOut integration with Smart Email Finder
"""

import asyncio
import os
import sys
from pathlib import Path

import aiohttp
from dotenv import load_dotenv

# Load environment variables
ROOT_DIR = Path(__file__).resolve().parents[1]
load_dotenv(ROOT_DIR / ".env")

# Ensure project root is on sys.path so apps.* imports resolve
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

from typing import Optional

from apps.api.services.enrichment.phone.providers.contactout import ContactOutPhoneFinder
from apps.api.services.enrichment.phone.smart_phone_finder import SmartPhoneFinder


def _init_contactout() -> Optional[ContactOutPhoneFinder]:
    try:
        return ContactOutPhoneFinder()
    except Exception as exc:
        print(f"❌ ContactOut provider unavailable: {exc}")
        return None


async def test_contactout_linkedin_integration():
    """Test ContactOut LinkedIn phone enrichment through ContactOut provider"""
    print("🔍 Testing ContactOut LinkedIn Integration")
    print("=" * 60)

    try:
        finder = _init_contactout()
        if not finder:
            return False

        # Test with LinkedIn URL
        linkedin_url = "https://www.linkedin.com/in/williamhgates"

        print(f"Testing LinkedIn URL: {linkedin_url}")
        async with aiohttp.ClientSession() as session:
            result = await finder.find_phone(session, linkedin_url=linkedin_url)

        verified = finder.is_verified_status(result.status or "")
        print(f"Status: {result.status}")
        print(f"Provider: {result.provider}")
        print(f"Credits Used: {result.credits_used}")

        if verified and result.phone:
            print(f"Phone: {result.phone}")
            if result.enrichment_data:
                print("\n📊 Enrichment Data:")
                print(f"  Full Name: {result.enrichment_data.get('full_name')}")
                print(f"  Job Title: {result.enrichment_data.get('job_title')}")
                print(f"  Company: {result.enrichment_data.get('company_name')}")
                print(f"  Location: {result.enrichment_data.get('location')}")

                phones = result.enrichment_data.get("phone_numbers") or []
                if phones:
                    print(f"  Phone Numbers: {phones}")
        else:
            print(f"Error: {result.error}")

        return verified

    except Exception as e:
        print(f"❌ Error during LinkedIn test: {e}")
        return False


async def test_contactout_manual_request():
    """Test orchestrated phone lookup through SmartPhoneFinder"""
    print("\n🔍 Testing SmartPhoneFinder Request")
    print("=" * 60)

    try:
        finder = SmartPhoneFinder()

        result = await finder.find_phone(
            linkedin_url="https://www.linkedin.com/in/williamhgates"
        )

        print(f"Success: {result.get('success')}")
        print(f"Phone: {result.get('phone')}")
        print(f"Provider Chain: {result.get('provider_chain')}")
        print(f"Credits Used: {result.get('credits_used')}")

        return bool(result.get("success"))

    except Exception as e:
        print(f"❌ Error during manual request test: {e}")
        return False


async def test_contactout_name_domain():
    """Test request without LinkedIn URL (expected to fail for ContactOut)"""
    print("\n🔍 Testing Name+Domain Request (Expected to Skip ContactOut)")
    print("=" * 60)

    try:
        finder = _init_contactout()
        if not finder:
            return False

        async with aiohttp.ClientSession() as session:
            result = await finder.find_phone(session, linkedin_url=None)

        print(f"Status: {result.status}")
        print(f"Error: {result.error}")

        return result.status in {"missing_linkedin_url", "invalid_linkedin_url"}

    except Exception as e:
        print(f"❌ Error during name+domain test: {e}")
        return False


async def test_provider_info():
    """Test provider information"""
    print("\n🔍 Testing Provider Information")
    print("=" * 60)

    try:
        finder = _init_contactout()
        if not finder:
            return False

        print(f"Provider: {finder.provider_name}")
        print(f"Cost per search: ${finder.cost_per_search:.2f}")
        print("Supports LinkedIn: True")
        print("Supports Name+Domain: False")

        return True

    except Exception as e:
        print(f"❌ Error during provider info test: {e}")
        return False


async def test_health_check():
    """Test system health check"""
    print("\n🔍 Testing Health Check")
    print("=" * 60)

    try:
        finder = _init_contactout()
        if not finder:
            return False

        print("Status: healthy (provider initialized)")
        return True

    except Exception as e:
        print(f"❌ Error during health check: {e}")
        return False


async def main():
    """Run all tests"""
    print("🚀 ContactOut Smart Email Finder Integration Tests")
    print("=" * 80)

    tests = [
        ("Provider Info", test_provider_info),
        ("Health Check", test_health_check),
        ("LinkedIn Integration", test_contactout_linkedin_integration),
        ("Manual Request", test_contactout_manual_request),
        ("Name+Domain (Skip Test)", test_contactout_name_domain)
    ]

    results = []

    for test_name, test_func in tests:
        print(f"\n📋 Running: {test_name}")
        try:
            success = await test_func()
            results.append((test_name, success))
            status = "✅ PASS" if success else "❌ FAIL"
            print(f"Result: {status}")
        except Exception as e:
            results.append((test_name, False))
            print(f"Result: ❌ FAIL (Exception: {e})")

    # Summary
    print("\n" + "=" * 80)
    print("📊 TEST SUMMARY")
    print("=" * 80)

    passed = sum(1 for _, success in results if success)
    total = len(results)

    for test_name, success in results:
        status = "✅" if success else "❌"
        print(f"{status} {test_name}")

    print(f"\nOverall: {passed}/{total} tests passed ({(passed/total)*100:.1f}%)")

    if passed == total:
        print("🎉 All tests passed! ContactOut integration is working correctly.")
    else:
        print("⚠️ Some tests failed. Check the output above for details.")


if __name__ == "__main__":
    asyncio.run(main())
