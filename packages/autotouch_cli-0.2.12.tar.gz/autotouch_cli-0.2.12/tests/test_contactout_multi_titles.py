#!/usr/bin/env python3
"""ContactOut multi-title search smoke test.

This helper sends a single ContactOut people search request that includes
multiple job titles so we can observe how the API handles the OR-style query.
Run it with:

    python tests/test_contactout_multi_titles.py hubspot.com "VP Marketing" "Head of Demand Generation"

If no CLI arguments are provided the script falls back to environment
variables (``CONTACTOUT_TEST_DOMAIN`` and ``CONTACTOUT_TEST_TITLES``) and then
default sample values.
"""

from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import requests
from dotenv import load_dotenv


PROJECT_ROOT = Path(__file__).resolve().parents[1]
load_dotenv(PROJECT_ROOT / ".env")


def _load_titles_from_env() -> list[str]:
    raw = os.getenv("CONTACTOUT_TEST_TITLES")
    if not raw:
        return []
    return [title.strip() for title in raw.split(",") if title.strip()]


def _prepare_inputs(argv: list[str]) -> tuple[str, list[str]]:
    domain = os.getenv("CONTACTOUT_TEST_DOMAIN", "hubspot.com")
    titles = _load_titles_from_env() or [
        "Chief Marketing Officer",
        "VP Marketing",
        "Head of Demand Generation",
    ]

    if len(argv) > 1:
        domain = argv[1]
    if len(argv) > 2:
        titles = argv[2:]

    return domain, titles


def main(argv: list[str]) -> int:
    api_token = os.getenv("CONTACTOUT_API_KEY")
    if not api_token:
        print("ERROR: CONTACTOUT_API_KEY not set; aborting")
        return 1

    domain, titles = _prepare_inputs(argv)

    if not titles:
        print("ERROR: need at least one job title to run the search")
        return 1

    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "token": api_token,
    }

    payload = {
        "domain": [domain],
        "page": 1,
        "page_size": min(25, max(1, int(os.getenv("CONTACTOUT_TEST_PAGE_SIZE", "10")))),
        "current_titles_only": True,
        "company_filter": "current",
        "reveal_info": False,
        "job_title": titles,
    }

    print("--> ContactOut /people/search payload:")
    print(json.dumps(payload, indent=2))

    response = requests.post(
        "https://api.contactout.com/v1/people/search",
        headers=headers,
        json=payload,
        timeout=45,
    )

    print(f"<-- Status: {response.status_code}")

    try:
        data = response.json()
    except Exception as exc:  # pragma: no cover - manual smoke test
        print(f"ERROR: failed to parse JSON: {exc}")
        print(response.text)
        return 1

    if response.status_code != 200:
        print("ERROR: request failed")
        print(json.dumps(data, indent=2))
        return 1

    profiles = data.get("profiles") or {}
    metadata = data.get("metadata", {})

    print(f"Profiles returned: {len(profiles)}")
    if metadata:
        print("Metadata:")
        print(json.dumps(metadata, indent=2))

    for idx, (profile_url, profile) in enumerate(profiles.items(), start=1):
        full_name = profile.get("full_name") or profile.get("name")
        title = profile.get("title") or profile.get("headline")
        company = (profile.get("company") or {}).get("name")
        print(f"  {idx}. {full_name} - {title} @ {company}")
        print(f"     LinkedIn: {profile_url}")
        if idx >= 5:
            break

    return 0


if __name__ == "__main__":  # pragma: no cover - manual entry point
    sys.exit(main(sys.argv))
