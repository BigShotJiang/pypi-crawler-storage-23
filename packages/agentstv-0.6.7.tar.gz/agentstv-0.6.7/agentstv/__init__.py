"""agentstv: Web-based agent session visualizer for Claude Code."""

__version__ = "0.6.7"
