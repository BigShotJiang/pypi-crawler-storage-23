# Explanation

- **[Statement of need](statement.md)**

## Architecture & design

- **[Container architecture](container-architecture.md)**
- **[Component system](component-system.md)**
