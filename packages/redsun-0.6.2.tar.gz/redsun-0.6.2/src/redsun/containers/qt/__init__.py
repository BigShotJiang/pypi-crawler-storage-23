"""Qt-specific container implementation."""

from __future__ import annotations

from redsun.containers.qt._container import QtAppContainer

__all__ = ["QtAppContainer"]
