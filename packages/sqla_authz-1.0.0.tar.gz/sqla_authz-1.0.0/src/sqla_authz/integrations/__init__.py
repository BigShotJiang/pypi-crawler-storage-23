"""Integrations with web frameworks."""

__all__: list[str] = []
