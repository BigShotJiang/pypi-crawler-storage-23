"""
AiCippy - Enterprise-grade multi-agent CLI system powered by AWS Bedrock.

This package provides a production-ready CLI tool for orchestrating
AI agents with support for:

- Multi-agent task orchestration (up to 10 parallel agents)
- AWS Bedrock integration (Claude Opus 4.5, Sonnet 4.5, Llama 4)
- Cognito authentication with secure token storage
- MCP-style tool connectors for cloud services
- Knowledge base with automated feed crawling
- Real-time WebSocket communication
- Structured logging and observability

Quick Start:
    >>> from aicippy import get_settings, AgentOrchestrator
    >>> settings = get_settings()
    >>> async with AgentOrchestrator() as orchestrator:
    ...     response = await orchestrator.chat("Hello!")

Copyright (c) 2024-2026 AiVibe Software Services Pvt Ltd. All rights reserved.
ISO 27001:2022 Certified | NVIDIA Inception Partner | AWS Activate | Microsoft for Startups

Author: Aravind Jayamohan <aravind@aivibe.in>
"""

from __future__ import annotations

from typing import Final

# Package metadata
__version__: Final[str] = "1.6.20"
__author__: Final[str] = "Aravind Jayamohan"
__email__: Final[str] = "aravind@aivibe.in"
__license__: Final[str] = "Proprietary"
__copyright__: Final[str] = "Copyright (c) 2024-2026 AiVibe Software Services Pvt Ltd"

# Configuration
from aicippy.config import Settings, get_settings

# Exceptions (public API for error handling)
from aicippy.exceptions import (
    AgentError,
    AgentExecutionError,
    AgentQuotaExceededError,
    AgentSpawnError,
    AgentTimeoutError,
    AiCippyError,
    AuthenticationError,
    AuthenticationExpiredError,
    AuthenticationInvalidError,
    AuthenticationRequiredError,
    # Billing Exceptions
    BillingError,
    CommandBlockedError,
    CommandExecutionError,
    ConfigurationError,
    ConnectorError,
    ConnectorTimeoutError,
    ConnectorUnavailableError,
    ContentFilteredError,
    ContextExceededError,
    CredentialStorageError,
    CreditDeductionError,
    CreditsExhaustedError,
    ErrorCode,
    ErrorContext,
    KnowledgeBaseError,
    ModelError,
    ModelInvocationError,
    ModelRateLimitedError,
    PlanExpiredError,
    PlanInactiveError,
    PlanNotFoundError,
    PlanValidationError,
    PlanWrongTierError,
    TokenRefreshError,
    ValidationError,
    WebSocketConnectionError,
    WebSocketDisconnectedError,
    WebSocketError,
    WebSocketMessageError,
)

# Types (public type aliases and protocols)
from aicippy.types import (
    AgentId,
    ConnectionId,
    ConnectionState,
    CorrelationId,
    DocumentId,
    ExecutionMode,
    JsonDict,
    JsonValue,
    Result,
    SessionId,
    TaskId,
    ToolCategory,
)


# Lazy imports for heavy modules
def __getattr__(name: str) -> type:
    """Lazy import for heavy modules to improve startup time."""
    if name == "AgentOrchestrator":
        from aicippy.agents.orchestrator import AgentOrchestrator

        return AgentOrchestrator
    elif name == "CognitoAuth":
        from aicippy.auth.cognito import CognitoAuth

        return CognitoAuth
    elif name == "BaseConnector":
        from aicippy.connectors.base import BaseConnector

        return BaseConnector
    elif name == "ConnectorConfig":
        from aicippy.connectors.base import ConnectorConfig

        return ConnectorConfig
    elif name == "ToolResult":
        from aicippy.connectors.base import ToolResult

        return ToolResult
    elif name == "CircuitBreaker":
        from aicippy.utils.retry import CircuitBreaker

        return CircuitBreaker
    elif name == "CircuitBreakerOpenError":
        from aicippy.utils.retry import CircuitBreakerOpenError

        return CircuitBreakerOpenError
    elif name == "PlanValidator":
        from aicippy.billing.plan_validator import PlanValidator

        return PlanValidator
    elif name == "CreditManager":
        from aicippy.billing.credit_manager import CreditManager

        return CreditManager
    elif name == "PlanInfo":
        from aicippy.billing.models import PlanInfo

        return PlanInfo
    elif name == "PlanStatus":
        from aicippy.billing.models import PlanStatus

        return PlanStatus
    elif name == "CreditTransaction":
        from aicippy.billing.models import CreditTransaction

        return CreditTransaction
    elif name == "PlatformClient":
        from aicippy.platform.client import PlatformClient

        return PlatformClient
    elif name == "AppClient":
        from aicippy.platform.app_client import AppClient

        return AppClient
    elif name == "TenantInfo":
        from aicippy.platform.models import TenantInfo

        return TenantInfo
    elif name == "PlatformSession":
        from aicippy.platform.models import PlatformSession

        return PlatformSession
    elif name == "TenantRole":
        from aicippy.platform.models import TenantRole

        return TenantRole
    elif name == "TenantContext":
        from aicippy.platform.tenant_context import TenantContext

        return TenantContext
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    # Agent Exceptions
    "AgentError",
    "AgentExecutionError",
    "AgentId",
    # Core Classes (lazy loaded)
    "AgentOrchestrator",
    "AgentQuotaExceededError",
    "AgentSpawnError",
    "AgentTimeoutError",
    # Base Exceptions
    "AiCippyError",
    "AppClient",
    # Auth Exceptions
    "AuthenticationError",
    "AuthenticationExpiredError",
    "AuthenticationInvalidError",
    "AuthenticationRequiredError",
    "BaseConnector",
    # Billing Exceptions
    "BillingError",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "CognitoAuth",
    "CommandBlockedError",
    "CommandExecutionError",
    "ConfigurationError",
    "ConnectionId",
    "ConnectionState",
    "ConnectorConfig",
    # Connector Exceptions
    "ConnectorError",
    "ConnectorTimeoutError",
    "ConnectorUnavailableError",
    "ContentFilteredError",
    "ContextExceededError",
    "CorrelationId",
    "CredentialStorageError",
    "CreditDeductionError",
    "CreditManager",
    "CreditTransaction",
    "CreditsExhaustedError",
    "DocumentId",
    "ErrorCode",
    "ErrorContext",
    # Enums
    "ExecutionMode",
    "JsonDict",
    "JsonValue",
    # Knowledge Base Exceptions
    "KnowledgeBaseError",
    # Model Exceptions
    "ModelError",
    "ModelInvocationError",
    "ModelRateLimitedError",
    "PlanExpiredError",
    "PlanInactiveError",
    "PlanInfo",
    "PlanNotFoundError",
    "PlanStatus",
    "PlanValidationError",
    # Billing Classes (lazy loaded)
    "PlanValidator",
    "PlanWrongTierError",
    # Platform Classes (lazy loaded)
    "PlatformClient",
    "PlatformSession",
    "Result",
    # Type Aliases
    "SessionId",
    # Configuration
    "Settings",
    "TaskId",
    "TenantContext",
    "TenantInfo",
    "TenantRole",
    "TokenRefreshError",
    "ToolCategory",
    "ToolResult",
    "ValidationError",
    "WebSocketConnectionError",
    "WebSocketDisconnectedError",
    # WebSocket Exceptions
    "WebSocketError",
    "WebSocketMessageError",
    "__author__",
    "__copyright__",
    "__email__",
    "__license__",
    # Metadata
    "__version__",
    "get_settings",
]
