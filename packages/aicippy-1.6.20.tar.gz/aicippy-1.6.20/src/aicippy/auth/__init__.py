"""
Authentication module for AiCippy.

Provides secure authentication via AWS Cognito with email+password,
email OTP, token management, and OS keychain storage.
"""

from __future__ import annotations

from aicippy.auth.cognito import CognitoAuth
from aicippy.auth.file_storage import FileCredentialStorage
from aicippy.auth.keychain import KeychainStorage
from aicippy.auth.models import AuthResult, TokenInfo

__all__ = [
    "AuthResult",
    "CognitoAuth",
    "FileCredentialStorage",
    "KeychainStorage",
    "TokenInfo",
]
