---
name: Issue
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

- The program crashes?
- The program stopped working?
- Have a feature request?

Please ask on https://tatsumoto.neocities.org/blog/join-our-community.html instead.
It is easier for our members to provide support over in the chats. Thank you!
