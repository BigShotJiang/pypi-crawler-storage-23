"""
Copyright: Ajatt-Tools and contributors; https://github.com/Ajatt-Tools
License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html
"""

import dataclasses

from PyQt6.QtGui import QColor


@dataclasses.dataclass
class ScreenshotPreviewOpts:
    """Configuration options for the rubber band's border and fill colors."""

    border_thickness: int = 2
    # for rubber band
    border_color: QColor = dataclasses.field(default_factory=lambda: QColor(0, 0, 255))
    fill_color: QColor = dataclasses.field(default_factory=lambda: QColor(0, 128, 255, 60))
    # for whole screen
    outline_color: QColor = dataclasses.field(default_factory=lambda: QColor(255, 0, 0))
    fill_brush_color: QColor = dataclasses.field(default_factory=lambda: QColor(127, 127, 127, 85))
