"""
Copyright: Ajatt-Tools and contributors; https://github.com/Ajatt-Tools
License: GNU AGPL, version 3 or later; http://www.gnu.org/licenses/agpl.html
"""

import pathlib

APP_NAME = "Zala"
THIS_DIR = pathlib.Path(__file__).resolve().parent
APP_LOGO_PATH = THIS_DIR / "icons" / "logo.ico"
