"""
TEI Loop Controller.

The main orchestrator that ties everything together:
  Agent -> Trace -> Evaluate -> Classify failures -> Generate fixes -> Re-run

Two modes (as agreed):
  Runtime (default): Per-query, ~8-30 seconds, catches and fixes individual failures.
  Development: Across N queries (~5-30 min), aggregates failure patterns,
               proposes PERMANENT prompt improvements, iterates until convergence.
"""

from __future__ import annotations

import asyncio
import time
from typing import Any, Callable, Optional

from .models import (
    Dimension,
    DimensionScore,
    EvalResult,
    IterationResult,
    RunMode,
    TEIConfig,
    TEIResult,
    Trace,
)
from .adapters.generic import GenericAdapter
from .evaluator import TEIEvaluator
from .improver import TEIImprover, classify_failures, check_convergence
from .llm_provider import (
    BaseLLMProvider,
    build_providers,
    estimate_cost,
    print_model_recommendation,
    resolve_models,
    resolve_provider,
)
from .tracer import run_and_trace
from .prompt_improver import extract_prompts, generate_improved_prompts, create_patched_agent

from .models import Failure, FixStrategyType, Severity


_DIM_TO_STRATEGY = {
    Dimension.TARGET_ALIGNMENT: FixStrategyType.TARGET_REANCHOR,
    Dimension.REASONING_SOUNDNESS: FixStrategyType.REASONING_REGENERATE,
    Dimension.EXECUTION_ACCURACY: FixStrategyType.EXECUTION_CORRECT,
    Dimension.OUTPUT_INTEGRITY: FixStrategyType.OUTPUT_REPAIR,
}


def _identify_improvable_dimensions(eval_result: EvalResult) -> list[Failure]:
    """Even when all dimensions pass, find the weakest ones to improve further.

    Returns Failure objects for any dimension scoring below 0.95,
    sorted by score ascending (weakest first).
    """
    improvable: list[Failure] = []
    for dim, ds in eval_result.dimension_scores.items():
        if ds.score < 0.95:
            gap = 0.95 - ds.score
            if gap >= 0.15:
                severity = Severity.MAJOR
            elif gap >= 0.05:
                severity = Severity.MINOR
            else:
                continue
            improvable.append(Failure(
                dimension=dim,
                severity=severity,
                description=(
                    f"{dim.value} scored {ds.score:.2f} -- below optimal (0.95). "
                    f"{ds.failure_summary or ds.reasoning}"
                ),
                evidence="; ".join(
                    a.explanation for a in ds.assertions
                    if a.verdict.value != "pass"
                )[:1000],
                suggested_strategy=_DIM_TO_STRATEGY.get(
                    dim, FixStrategyType.OUTPUT_REPAIR
                ),
            ))
    improvable.sort(key=lambda f: {Severity.MAJOR: 0, Severity.MINOR: 1}.get(f.severity, 2))
    return improvable



class TEILoop:
    """Main TEI Loop: Target -> Evaluate -> Improve.

    Usage:
        loop = TEILoop(agent=my_function)
        result = await loop.run("user query")
        print(result.summary())
    """

    def __init__(
        self,
        agent: Callable,
        config: Optional[TEIConfig] = None,
        eval_llm: str = "auto",
        improve_llm: str = "auto",
        provider: str = "auto",
        max_retries: int = 3,
        mode: str = "runtime",
        verbose: bool = False,
        show_cost: bool = True,
    ):
        self.config = config or TEIConfig()

        if mode == "development":
            self.config.mode = RunMode.DEVELOPMENT
        if max_retries != 3:
            self.config.max_retries = max_retries
        if verbose:
            self.config.verbose = verbose
        if not show_cost:
            self.config.show_cost_estimate = False

        if provider != "auto":
            self.config.llm.provider = provider
        if eval_llm != "auto":
            self.config.llm.eval_model = eval_llm
        if improve_llm != "auto":
            self.config.llm.improve_model = improve_llm

        self._agent = GenericAdapter(agent)
        self._provider_name: Optional[str] = None
        self._eval_llm: Optional[BaseLLMProvider] = None
        self._improve_llm: Optional[BaseLLMProvider] = None
        self._evaluator: Optional[TEIEvaluator] = None
        self._improver: Optional[TEIImprover] = None
        self._initialized = False

    def _init_providers(self) -> None:
        if self._initialized:
            return
        self._provider_name, self._eval_llm, self._improve_llm = build_providers(
            self.config.llm
        )
        self._evaluator = TEIEvaluator(self.config, self._eval_llm)
        self._improver = TEIImprover(self.config, self._improve_llm)

        if self.config.show_cost_estimate:
            print_model_recommendation(self.config.llm)

        self._initialized = True

    # ----- Runtime mode (per-query, ~8-30 seconds) -----

    async def run(self, query: Any, context: Optional[dict[str, Any]] = None) -> TEIResult:
        """Run the full TEI loop: run agent -> evaluate -> improve PROMPT -> re-run agent.

        This is REAL improvement: TEI modifies the agent's prompts (like GEPA/DSPy),
        not just rewriting the output.
        """
        self._init_providers()
        start = time.time()

        iterations: list[IterationResult] = []
        aggregate_scores: list[float] = []
        best_iteration_idx = 0
        best_score = 0.0

        print("  [1/5] Extracting prompts from agent...", end="", flush=True)
        original_prompts = extract_prompts(self._agent.agent_fn)
        if original_prompts.get("system_prompt"):
            print(f" found")
            print(f"        System: \"{original_prompts['system_prompt'][:80]}...\"")
            if original_prompts.get("user_prompt_template"):
                print(f"        User template: \"{original_prompts['user_prompt_template'][:80]}...\"")
            if original_prompts.get("model"):
                print(f"        Model: {original_prompts['model']}")
        else:
            print(f" no prompts found (will use output enhancement)")

        print("  [2/5] Running agent with original prompts...", end="", flush=True)
        trace = await run_and_trace(self._agent.agent_fn, query, context=context)
        print(f" done ({trace.total_duration_ms/1000:.1f}s)")

        print("  [3/5] Evaluating output (4 dimensions in parallel)...", end="", flush=True)
        eval_result = await self._evaluator.evaluate(trace)
        aggregate_scores.append(eval_result.aggregate_score)
        print(f" done")
        print(f"\n        BEFORE TEI (score: {eval_result.aggregate_score:.2f}):")
        for dim in Dimension:
            ds = eval_result.dimension_scores.get(dim)
            if ds:
                print(f"          {dim.value}: {ds.score:.2f}")

        if eval_result.aggregate_score > best_score:
            best_score = eval_result.aggregate_score
            best_iteration_idx = 0

        failures = classify_failures(eval_result)
        if not failures:
            failures = _identify_improvable_dimensions(eval_result)

        iterations.append(IterationResult(
            iteration=0,
            trace=trace,
            eval_result=eval_result,
            failures=failures,
        ))

        for i in range(1, self.config.max_retries + 1):
            if not failures:
                break
            if eval_result.aggregate_score >= 0.95:
                print(f"\n  Near-optimal ({eval_result.aggregate_score:.2f}), no improvement needed.")
                break

            if original_prompts.get("system_prompt"):
                print(f"\n  [4/5] Generating improved prompts (iteration {i})...", end="", flush=True)
                improved_prompts = await generate_improved_prompts(
                    original_prompts, eval_result, failures, self._improve_llm
                )

                if not improved_prompts or not improved_prompts.get("system_prompt"):
                    print(" failed")
                    break

                print(f" done")
                changes = improved_prompts.get("changes_made", [])
                if changes:
                    print(f"\n        PROMPT CHANGES:")
                    for c in changes[:5]:
                        print(f"          - {c[:100]}")

                print(f"\n  [5/5] Re-running agent with improved prompts...", end="", flush=True)
                patched = create_patched_agent(
                    self._agent.agent_fn, original_prompts, improved_prompts
                )
                improved_trace = await run_and_trace(patched, query, context=context)
                print(f" done ({improved_trace.total_duration_ms/1000:.1f}s)")

            else:
                print(f"\n  [4/5] Improving output directly (iteration {i})...", end="", flush=True)
                enhanced = await self._enhance_output(
                    trace.agent_input, trace.agent_output, failures
                )
                if not enhanced or enhanced == str(trace.agent_output):
                    print(" no change")
                    break
                improved_trace = Trace(
                    agent_input=trace.agent_input,
                    agent_output=enhanced,
                )
                print(f" done")

            print(f"        Re-evaluating...", end="", flush=True)
            eval_result = await self._evaluator.evaluate(improved_trace)
            aggregate_scores.append(eval_result.aggregate_score)
            print(f" done")

            print(f"\n        AFTER TEI (score: {eval_result.aggregate_score:.2f}):")
            for dim in Dimension:
                ds = eval_result.dimension_scores.get(dim)
                if ds:
                    prev = iterations[0].eval_result.dimension_scores.get(dim)
                    prev_score = prev.score if prev else 0
                    delta = ds.score - prev_score
                    d_str = f" ({delta:+.2f})" if delta else ""
                    print(f"          {dim.value}: {ds.score:.2f}{d_str}")

            if eval_result.aggregate_score > best_score:
                best_score = eval_result.aggregate_score
                best_iteration_idx = len(iterations)

            if eval_result.aggregate_score < aggregate_scores[-2] - 0.03:
                print(f"\n  Regression detected, keeping original.")
                break

            failures = classify_failures(eval_result)
            if not failures:
                failures = _identify_improvable_dimensions(eval_result)

            iterations.append(IterationResult(
                iteration=i,
                trace=improved_trace,
                eval_result=eval_result,
                failures=failures,
                improved=True,
            ))

            if check_convergence(aggregate_scores, self.config.convergence_threshold):
                print(f"\n  Scores converged.")
                break

        total_ms = (time.time() - start) * 1000
        total_cost = 0.0
        if self._eval_llm:
            total_cost += self._eval_llm.get_cost(self._provider_name or "openai")
        if self._improve_llm:
            total_cost += self._improve_llm.get_cost(self._provider_name or "openai")

        baseline_score = iterations[0].eval_result.aggregate_score if iterations else 0
        final_score = iterations[best_iteration_idx].eval_result.aggregate_score if iterations else 0

        return TEIResult(
            mode=self.config.mode,
            query=str(query)[:500],
            final_output=iterations[best_iteration_idx].trace.agent_output if iterations else None,
            iterations=iterations,
            baseline_score=baseline_score,
            final_score=final_score,
            improvement_delta=round(final_score - baseline_score, 4),
            total_iterations=len(iterations),
            converged=check_convergence(aggregate_scores, self.config.convergence_threshold)
                if len(aggregate_scores) >= 3 else (
                    iterations[-1].eval_result.all_passed if iterations else False
                ),
            total_duration_ms=total_ms,
            total_cost_usd=total_cost,
        )

    async def _enhance_output(
        self, agent_input: Any, agent_output: Any, failures: list[Failure]
    ) -> Optional[str]:
        """Use the improve LLM to directly enhance the agent's output."""
        failure_details = []
        for f in failures[:3]:
            failure_details.append(
                f"DIMENSION: {f.dimension.value}\n"
                f"ISSUE: {f.description[:500]}\n"
                f"EVIDENCE: {f.evidence[:500]}"
            )

        prompt = (
            "An AI agent analyzed this input and produced the output below. "
            "A structured evaluation found specific quality issues. "
            "Your task: produce an IMPROVED version of the output that fixes "
            "every listed issue while preserving all correct content.\n\n"
            f"=== ORIGINAL INPUT ===\n{str(agent_input)[:3000]}\n\n"
            f"=== AGENT OUTPUT (to improve) ===\n{str(agent_output)[:5000]}\n\n"
            f"=== QUALITY ISSUES TO FIX ===\n"
            + "\n---\n".join(failure_details) + "\n\n"
            "=== INSTRUCTIONS ===\n"
            "1. Fix every issue listed above\n"
            "2. Keep the same structure and format\n"
            "3. Add specific details from the input that were missing\n"
            "4. Remove any unsupported claims or inferences\n"
            "5. Ensure every statement is backed by evidence from the input\n\n"
            "Return ONLY the improved output. No explanations, no preamble."
        )

        try:
            enhanced = await self._improve_llm.generate(
                "You are an expert editor. You fix quality issues in AI-generated content. "
                "You return only the improved text, nothing else.",
                prompt,
            )
            return enhanced.strip() if enhanced else None
        except Exception as e:
            print(f" enhance failed: {e}")
            return None

    # ----- Evaluate-only mode (baseline measurement) -----

    async def evaluate_only(self, query: Any, context: Optional[dict[str, Any]] = None) -> TEIResult:
        """Run the agent once and evaluate without improvement. For baseline measurement."""
        self._init_providers()
        start = time.time()

        trace = await run_and_trace(self._agent.agent_fn, query, context=context)
        eval_result = await self._evaluator.evaluate(trace)

        total_ms = (time.time() - start) * 1000
        cost = self._eval_llm.get_cost(self._provider_name or "openai") if self._eval_llm else 0

        return TEIResult(
            mode=RunMode.RUNTIME,
            query=str(query)[:500],
            final_output=trace.agent_output,
            iterations=[IterationResult(
                iteration=0,
                trace=trace,
                eval_result=eval_result,
                failures=classify_failures(eval_result),
            )],
            baseline_score=eval_result.aggregate_score,
            final_score=eval_result.aggregate_score,
            improvement_delta=0.0,
            total_iterations=1,
            converged=eval_result.all_passed,
            total_duration_ms=total_ms,
            total_cost_usd=cost,
        )

    # ----- Compare mode (before/after in one call) -----

    async def compare(self, query: Any, context: Optional[dict[str, Any]] = None) -> dict[str, TEIResult]:
        """Run baseline (evaluate-only) and full TEI loop, return both for comparison."""
        baseline = await self.evaluate_only(query, context)

        self._eval_llm.total_input_tokens = 0
        self._eval_llm.total_output_tokens = 0
        self._improve_llm.total_input_tokens = 0
        self._improve_llm.total_output_tokens = 0

        improved = await self.run(query, context)

        return {
            "baseline": baseline,
            "improved": improved,
        }

    # ----- Development mode (across many queries, ~5-30 min) -----

    async def develop(
        self,
        queries: list[Any],
        max_iterations: Optional[int] = None,
    ) -> dict[str, Any]:
        """Development mode: iterate across many queries to find patterns and
        propose PERMANENT prompt-level improvements.

        Unlike runtime mode (which fixes individual failures per-query), development
        mode aggregates failure patterns across all queries, generates a consolidated
        prompt improvement, re-runs the entire batch with the improvement applied,
        and iterates until scores converge or max_iterations is reached.

        This is analogous to what GEPA does (run many times, reflect, propose changes,
        re-run) but with TEI's 4-dimension evaluation instead of a single scalar.
        """
        self._init_providers()
        max_iter = max_iterations or self.config.max_dev_iterations
        start = time.time()

        prompt_prefix = ""
        iteration_history: list[dict[str, Any]] = []
        score_history: list[float] = []

        for dev_iter in range(max_iter):
            if self.config.verbose:
                print(f"\n{'='*60}")
                print(f"DEVELOPMENT ITERATION {dev_iter}")
                print(f"{'='*60}")

            batch_results: list[TEIResult] = []
            for q in queries:
                modified_q = prompt_prefix + str(q) if prompt_prefix else q
                trace = await run_and_trace(self._agent.agent_fn, modified_q)
                eval_result = await self._evaluator.evaluate(trace)
                batch_results.append(TEIResult(
                    query=str(q)[:200],
                    final_output=trace.agent_output,
                    iterations=[IterationResult(
                        iteration=0, trace=trace, eval_result=eval_result,
                        failures=classify_failures(eval_result),
                    )],
                    baseline_score=eval_result.aggregate_score,
                    final_score=eval_result.aggregate_score,
                    total_iterations=1,
                ))

            avg_score = sum(r.final_score for r in batch_results) / len(batch_results)
            score_history.append(avg_score)

            dim_failures: dict[str, list[str]] = {d.value: [] for d in Dimension}
            for r in batch_results:
                if r.iterations and r.iterations[0].failures:
                    for f in r.iterations[0].failures:
                        dim_failures[f.dimension.value].append(f.description[:200])

            dim_avgs: dict[str, float] = {}
            for dim in Dimension:
                scores = []
                for r in batch_results:
                    if r.iterations:
                        ds = r.iterations[0].eval_result.dimension_scores.get(dim)
                        if ds:
                            scores.append(ds.score)
                dim_avgs[dim.value] = sum(scores) / len(scores) if scores else 0

            iteration_history.append({
                "iteration": dev_iter,
                "avg_score": round(avg_score, 4),
                "dimension_averages": {k: round(v, 4) for k, v in dim_avgs.items()},
                "failure_counts": {k: len(v) for k, v in dim_failures.items()},
                "prompt_prefix_length": len(prompt_prefix),
            })

            if self.config.verbose:
                print(f"  Avg score: {avg_score:.4f}")
                for dim_name, dim_avg in dim_avgs.items():
                    fails = len(dim_failures.get(dim_name, []))
                    print(f"    {dim_name}: {dim_avg:.2f} ({fails} failures across batch)")

            all_passing = all(
                r.iterations[0].eval_result.all_passed
                for r in batch_results if r.iterations
            )
            if all_passing:
                if self.config.verbose:
                    print(f"  All queries passing at dev iteration {dev_iter}")
                break

            if check_convergence(score_history, self.config.convergence_threshold, window=3):
                if self.config.verbose:
                    print(f"  Converged at dev iteration {dev_iter}")
                break

            active_failures = {
                k: v for k, v in dim_failures.items() if v
            }
            if not active_failures:
                break

            failure_summary_parts = []
            for dim_name, descriptions in active_failures.items():
                sample = descriptions[:5]
                failure_summary_parts.append(
                    f"{dim_name} ({len(descriptions)} failures): "
                    + "; ".join(sample)
                )
            failure_summary = "\n".join(failure_summary_parts)

            reflection_prompt = (
                "You are a TEI development-mode optimizer. Analyze aggregated failure "
                "patterns across multiple agent runs and propose a PERMANENT prompt "
                "improvement that addresses the most common failures.\n\n"
                f"Current average score: {avg_score:.2f}\n"
                f"Batch size: {len(queries)} queries\n\n"
                f"Failure patterns by dimension:\n{failure_summary}\n\n"
                "Generate a concise instruction prefix (under 300 words) that, when "
                "prepended to the agent's input, will address these failure patterns "
                "permanently. Focus on the most impactful improvements first.\n\n"
                "Return JSON:\n"
                '{"prompt_improvement": "the instruction text to prepend", '
                '"rationale": "why this addresses the failure patterns", '
                '"targeted_dimensions": ["list of dimensions this targets"]}'
            )

            try:
                result = await self._improve_llm.generate_json(
                    "You are a TEI prompt optimizer. Return valid JSON only.",
                    reflection_prompt,
                )
                new_prefix = result.get("prompt_improvement", "")
                if new_prefix:
                    prompt_prefix = new_prefix + "\n\n"
                    if self.config.verbose:
                        print(f"  Proposed prompt improvement ({len(new_prefix)} chars)")
                        print(f"  Targets: {result.get('targeted_dimensions', [])}")
                        print(f"  Rationale: {result.get('rationale', '')[:100]}")
                else:
                    break
            except Exception as e:
                if self.config.verbose:
                    print(f"  Reflection failed: {e}")
                break

        total_ms = (time.time() - start) * 1000
        total_cost = 0.0
        if self._eval_llm:
            total_cost += self._eval_llm.get_cost(self._provider_name or "openai")
        if self._improve_llm:
            total_cost += self._improve_llm.get_cost(self._provider_name or "openai")

        first_avg = score_history[0] if score_history else 0
        last_avg = score_history[-1] if score_history else 0

        return {
            "mode": "development",
            "total_queries": len(queries),
            "total_dev_iterations": len(iteration_history),
            "avg_baseline_score": round(first_avg, 4),
            "avg_final_score": round(last_avg, 4),
            "avg_improvement": round(last_avg - first_avg, 4),
            "score_history": [round(s, 4) for s in score_history],
            "iteration_history": iteration_history,
            "final_prompt_prefix": prompt_prefix,
            "total_duration_ms": total_ms,
            "total_cost_usd": total_cost,
        }
