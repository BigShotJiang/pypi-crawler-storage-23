"""Allow running TEI as: python3 -m tei_loop your_agent.py"""
from tei_loop.cli import main
main()
