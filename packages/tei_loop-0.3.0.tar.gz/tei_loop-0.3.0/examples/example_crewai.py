"""
Example: Using TEI with a CrewAI crew.

TEI wraps the crew's kickoff as a callable.
"""
import asyncio
from tei_loop import TEILoop


# Assuming you have a CrewAI crew:
# from my_crew import my_crew
#
# def run_crew(query: str) -> str:
#     result = my_crew.kickoff(inputs={"query": query})
#     return str(result)
#
# async def main():
#     loop = TEILoop(agent=run_crew, verbose=True)
#     result = await loop.run("Research the latest AI trends")
#     print(result.summary())


def mock_crewai_agent(query: str) -> str:
    """Placeholder — replace with your actual CrewAI crew."""
    return f"CrewAI would research: {query}"


async def main():
    loop = TEILoop(agent=mock_crewai_agent, verbose=True)
    result = await loop.evaluate_only("Research competitor pricing strategies")
    print(result.summary())


if __name__ == "__main__":
    asyncio.run(main())
