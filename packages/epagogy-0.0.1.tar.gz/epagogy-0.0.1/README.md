# epagogy

The science of inductive reasoning.

Coming soon. https://epagogy.ai
