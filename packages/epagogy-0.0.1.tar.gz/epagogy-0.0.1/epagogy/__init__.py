"""epagogy — the science of inductive reasoning."""

__version__ = "0.0.1"
