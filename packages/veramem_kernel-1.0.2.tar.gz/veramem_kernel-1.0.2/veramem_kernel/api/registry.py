# veramem_kernel/api/registry.py
"""
Domain registry public API.

Used to enforce closed-world constraints and domain identification.
"""

from ..common.domain_registry import DomainRegistry

__all__ = ["DomainRegistry"]
