# kernel/journals/timeline/__init__.py

from .timeline_head import JournalHead

__all__ = ["JournalHead"]
