"""Diligence namespace."""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..constants import GENE_KEYS_PAGE_SIZE
from ..exceptions import OMTXError
from .base import BaseNamespace


class DiligenceNamespace(BaseNamespace):
    def synthesize_report(
        self,
        *,
        gene_key: str,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not gene_key:
            raise OMTXError("gene_key is required for synthesize_report")
        return self._client._request(
            "POST",
            "/v2/diligence/synthesizeReport",
            json_body={"gene_key": gene_key},
            idempotency_key=idempotency_key,
        )

    def deep_diligence(
        self,
        *,
        query: str,
        preset: Optional[str] = None,
        idempotency_key: Optional[str] = None,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        if not query:
            raise OMTXError("query is required for deep_diligence")

        payload: Dict[str, Any] = {"query": query}
        if preset:
            payload["preset"] = preset
        payload.update(kwargs)

        return self._client._request(
            "POST",
            "/v2/diligence/deep-diligence",
            json_body=payload,
            idempotency_key=idempotency_key,
        )

    def search(
        self,
        *,
        query: str,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not query:
            raise OMTXError("query is required for search")
        return self._client._request(
            "POST",
            "/v2/diligence/search",
            json_body={"query": query},
            idempotency_key=idempotency_key,
        )

    def gather(
        self,
        *,
        query: str,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not query:
            raise OMTXError("query is required for gather")
        return self._client._request(
            "POST",
            "/v2/diligence/gather",
            json_body={"query": query},
            idempotency_key=idempotency_key,
        )

    def crawl(
        self,
        *,
        url: str,
        max_pages: int = 5,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not url:
            raise OMTXError("url is required for crawl")
        if max_pages < 1 or max_pages > 20:
            raise OMTXError("max_pages must be between 1 and 20")

        return self._client._request(
            "POST",
            "/v2/diligence/crawl",
            json_body={"url": url, "max_pages": int(max_pages)},
            idempotency_key=idempotency_key,
        )

    def list_gene_keys(self) -> Dict[str, Any]:
        offset = 0
        all_items: list[Dict[str, Any]] = []
        total_count: Optional[int] = None

        while True:
            page = self._client._request(
                "GET",
                "/v2/diligence/gene-keys",
                params={"min_true": 1, "limit": GENE_KEYS_PAGE_SIZE, "offset": offset},
            )
            items = page.get("items") or []
            all_items.extend(items)
            if total_count is None:
                total_count = page.get("count")

            if len(items) < GENE_KEYS_PAGE_SIZE:
                if total_count is not None and len(all_items) < total_count:
                    offset += GENE_KEYS_PAGE_SIZE
                    continue
                break

            offset += GENE_KEYS_PAGE_SIZE

        return {
            "items": all_items,
            "count": total_count if total_count is not None else len(all_items),
        }
