"""Datasets namespace."""

from __future__ import annotations

from typing import Any, Dict

from .base import BaseNamespace


class DatasetsNamespace(BaseNamespace):
    def catalog(self) -> Dict[str, Any]:
        return self._client._request("GET", "/v2/datasets/catalog")

    def generated_protein_uuids(self) -> list[str]:
        payload = self.catalog()
        values = payload.get("accessible_generated_protein_uuids")
        if isinstance(values, list):
            return [str(v) for v in values if isinstance(v, str) and v.strip()]

        items = (payload.get("data_generated") or {}).get("items") or []
        if not isinstance(items, list):
            return []
        return sorted(
            {
                str(item.get("protein_uuid"))
                for item in items
                if isinstance(item, dict) and item.get("protein_uuid")
            }
        )
