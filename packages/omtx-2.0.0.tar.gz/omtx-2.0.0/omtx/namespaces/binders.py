"""Binders/data-access namespace."""

from __future__ import annotations

from typing import Any, Dict, Optional

from ..exceptions import OMTXError
from .base import BaseNamespace


class BindersNamespace(BaseNamespace):
    def get_shards(
        self,
        *,
        protein_uuid: str,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        if not protein_uuid:
            raise OMTXError("protein_uuid is required")

        payload: Dict[str, Any] = {
            "protein_uuid": protein_uuid,
        }
        return self._client._request(
            "POST",
            "/v2/data-access/shards",
            json_body=payload,
            idempotency_key=idempotency_key,
        )

    def urls(
        self,
        *,
        protein_uuid: str,
        idempotency_key: Optional[str] = None,
    ) -> Dict[str, Any]:
        export = self.get_shards(
            protein_uuid=protein_uuid,
            idempotency_key=idempotency_key,
        )

        binder_urls = export.get("binder_urls")
        if binder_urls is None:
            binder_urls = [
                row.get("url")
                for row in (export.get("binders") or {}).get("urls", [])
                if isinstance(row, dict) and row.get("url")
            ]

        non_binder_urls = export.get("non_binder_urls")
        if non_binder_urls is None:
            non_binder_urls = [
                row.get("url")
                for row in (export.get("non_binders") or {}).get("urls", [])
                if isinstance(row, dict) and row.get("url")
            ]

        return {
            "protein_uuid": export.get("protein_uuid"),
            "dataset_id": export.get("dataset_id"),
            "vintage_id": export.get("vintage_id"),
            "vintage": export.get("vintage"),
            "expires_at": export.get("expires_at"),
            "binder_urls": binder_urls,
            "non_binder_urls": non_binder_urls,
        }

    def get(self, *args: Any, **kwargs: Any) -> Any:
        raise OMTXError(
            "binders.get() was removed from the core SDK in v1. "
            "Use client.load_data(...) or binders.get_shards(...)."
        )

    def iter(self, *args: Any, **kwargs: Any) -> Any:
        raise OMTXError(
            "binders.iter() was removed from the core SDK in v1. "
            "Use binders.get_shards() and stream rows in your application layer."
        )
