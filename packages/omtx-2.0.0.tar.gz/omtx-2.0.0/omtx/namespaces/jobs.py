"""Jobs namespace."""

from __future__ import annotations

import json
import time
from typing import Any, Dict, Optional

from ..contracts import JOB_TERMINAL_FAILURE_STATUSES, JOB_TERMINAL_SUCCESS_STATUSES
from ..exceptions import APIError, OMTXError
from .base import BaseNamespace


class JobTimeoutError(OMTXError):
    """Raised when waiting for a job exceeds the allowed timeout."""


class JobsNamespace(BaseNamespace):
    def history(
        self,
        *,
        endpoint: Optional[str] = None,
        status: Optional[str] = None,
        limit: int = 20,
        cursor: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"limit": limit}
        if endpoint:
            payload["endpoint"] = endpoint
        if status:
            payload["status"] = status
        if cursor:
            payload["cursor"] = cursor
        return self._client._request("GET", "/v2/jobs/history", params=payload)

    def status(self, job_id: str) -> Dict[str, Any]:
        if not job_id:
            raise OMTXError("job_id is required")
        return self._client._request("GET", f"/v2/jobs/{job_id}")

    def result(self, job_id: str) -> Dict[str, Any]:
        return self.status(job_id)

    def wait(
        self,
        job_id: str,
        *,
        result_endpoint: Optional[str] = None,
        poll_interval: float = 5.0,
        timeout: Optional[float] = 3600.0,
    ) -> Dict[str, Any]:
        if not job_id:
            raise OMTXError("job_id is required")

        start = time.monotonic()
        while True:
            status = self.status(job_id)
            state = status.get("status")

            if state in JOB_TERMINAL_SUCCESS_STATUSES:
                if result_endpoint:
                    endpoint = result_endpoint.format(job_id=job_id)
                    return self._client._request("GET", endpoint)
                return status

            if state in JOB_TERMINAL_FAILURE_STATUSES:
                status_code = status.get("status_code") or status.get("response_status") or 500
                detail = status.get("error") or status.get("detail") or status.get("response_payload")
                if isinstance(detail, dict):
                    detail = json.dumps(detail)
                message = detail or f"Job {job_id} finished with status {state}"
                raise APIError(message, status_code=status_code)

            if timeout is not None and (time.monotonic() - start) > timeout:
                raise JobTimeoutError(f"Timed out waiting for job {job_id}")

            time.sleep(poll_interval)
