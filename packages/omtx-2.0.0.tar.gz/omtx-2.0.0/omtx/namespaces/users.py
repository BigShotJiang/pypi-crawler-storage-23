"""Users namespace."""

from __future__ import annotations

from typing import Any, Dict

from .base import BaseNamespace


class UsersNamespace(BaseNamespace):
    def profile(self) -> Dict[str, Any]:
        credits = self._client._request("GET", "/v2/credits")
        return {"available_credits": credits.get("available_credits")}
