"""Namespace base class."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:  # pragma: no cover
    from ..client import OmClient


class BaseNamespace:
    def __init__(self, client: "OmClient"):
        self._client = client
