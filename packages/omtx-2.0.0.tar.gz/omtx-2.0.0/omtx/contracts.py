"""Contract constants shared across SDK namespaces and tests."""

from __future__ import annotations

from typing import Final, Optional

SDK_ENDPOINT_ALIASES: Final[dict[str, str]] = {
    "data-access.shards": "/v2/data-access/shards",
    "/v2/data-access/shards": "/v2/data-access/shards",
    "diligence.synthesizereport": "/v2/diligence/synthesizeReport",
    "/v2/diligence/synthesizereport": "/v2/diligence/synthesizeReport",
    "diligence.deepdiligence": "/v2/diligence/deep-diligence",
    "/v2/diligence/deep-diligence": "/v2/diligence/deep-diligence",
    "diligence.search": "/v2/diligence/search",
    "/v2/diligence/search": "/v2/diligence/search",
    "diligence.gather": "/v2/diligence/gather",
    "/v2/diligence/gather": "/v2/diligence/gather",
    "diligence.crawl": "/v2/diligence/crawl",
    "/v2/diligence/crawl": "/v2/diligence/crawl",
}

SDK_EXPOSED_ENDPOINTS: Final[frozenset[str]] = frozenset(
    {
        "/v2/health",
        "/v2/credits",
        "/v2/jobs/history",
        "/v2/jobs/{job_id}",
        "/v2/datasets/catalog",
        "/v2/data-access/shards",
        "/v2/diligence/synthesizeReport",
        "/v2/diligence/deep-diligence",
        "/v2/diligence/search",
        "/v2/diligence/gather",
        "/v2/diligence/crawl",
        "/v2/diligence/gene-keys",
    }
)

# Gateway route exists but is intentionally not exposed as a separate SDK helper.
SDK_ALIAS_ONLY_ENDPOINTS: Final[frozenset[str]] = frozenset(
    {
        "/v2/diligence/getTargetDiligenceReport",
    }
)

# Gateway route exists but is intentionally excluded from SDK core surface.
SDK_NON_CORE_NOT_EXPOSED_ENDPOINTS: Final[frozenset[str]] = frozenset(
    {
        "/v2/rag/search",
    }
)

JOB_TERMINAL_SUCCESS_STATUSES: Final[frozenset[str]] = frozenset({"succeeded"})
JOB_TERMINAL_FAILURE_STATUSES: Final[frozenset[str]] = frozenset(
    {
        "failed",
        "canceled",
        "cancelled",
        "expired",
    }
)


def normalize_endpoint_alias(endpoint: str) -> Optional[str]:
    """Normalize an endpoint alias to a canonical gateway path."""
    return SDK_ENDPOINT_ALIASES.get(endpoint.lower().strip())
