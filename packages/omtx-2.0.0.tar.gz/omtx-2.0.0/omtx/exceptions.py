"""Simple exception classes for OMTX SDK."""

from __future__ import annotations

from typing import Optional


class OMTXError(Exception):
    """Base exception for all OMTX errors."""


class AuthenticationError(OMTXError):
    """Raised when API key is invalid or missing."""


class InsufficientCreditsError(OMTXError):
    """Raised when the account does not have enough credits."""

    def __init__(
        self,
        message: str,
        required: Optional[int] = None,
        available: Optional[int] = None,
    ):
        super().__init__(message)
        self.required = required
        self.available = available


class APIError(OMTXError):
    """Raised for API errors."""

    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code
