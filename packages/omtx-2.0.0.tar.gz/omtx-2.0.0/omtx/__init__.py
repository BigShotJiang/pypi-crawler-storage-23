"""OMTX Python SDK."""

from typing import Optional

from .client import OmClient, JobTimeoutError
from .constants import DEFAULT_TIMEOUT_SECONDS
from .dataframes import OmDataFrame
from .exceptions import AuthenticationError, InsufficientCreditsError, OMTXError

__version__ = "2.0.0"


def load_data(
    *,
    protein_uuid: str,
    binders: Optional[int] = None,
    non_binders: Optional[int] = None,
    nonbinders: Optional[int] = None,
    idempotency_key: Optional[str] = None,
    api_key: Optional[str] = None,
    base_url: Optional[str] = None,
    timeout: int = DEFAULT_TIMEOUT_SECONDS,
    include_metadata: bool = False,
) -> OmDataFrame | tuple[OmDataFrame, dict]:
    """Convenience helper for one-shot dataset loading via OmClient."""
    with OmClient(api_key=api_key, base_url=base_url, timeout=timeout) as client:
        return client.load_data(
            protein_uuid=protein_uuid,
            binders=binders,
            non_binders=non_binders,
            nonbinders=nonbinders,
            idempotency_key=idempotency_key,
            include_metadata=include_metadata,
        )


__all__ = [
    "AuthenticationError",
    "InsufficientCreditsError",
    "JobTimeoutError",
    "load_data",
    "OmDataFrame",
    "OmClient",
    "OMTXError",
]
