from __future__ import annotations

import os
import warnings
from typing import Any, Dict, Optional
from urllib.parse import urlparse

import requests

from .constants import API_BASE_URL, DEFAULT_TIMEOUT_SECONDS
from .dataframes import OmDataFrame, as_om_dataframe, load_export_dataframe
from .exceptions import OMTXError
from .http import ClientConfig, GatewayHttpClient
from .namespaces import (
    BindersNamespace,
    DatasetsNamespace,
    DiligenceNamespace,
    JobTimeoutError,
    JobsNamespace,
    UsersNamespace,
)


class OmClient:
    """High-level SDK entry point for OM Gateway."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = DEFAULT_TIMEOUT_SECONDS,
        *,
        session: Optional[requests.Session] = None,
    ):
        api_key = api_key or os.getenv("OMTX_API_KEY") or os.getenv("API_KEY")
        if not api_key:
            raise OMTXError("API key is required. Pass api_key or set OMTX_API_KEY/API_KEY.")

        resolved_base_url = base_url or os.getenv("OMTX_BASE_URL") or API_BASE_URL
        normalized_base_url = self._normalize_base_url(resolved_base_url)
        self._warn_if_non_production_base_url(normalized_base_url)

        self.cfg = ClientConfig(base_url=normalized_base_url, api_key=api_key, timeout=timeout)
        self._http = GatewayHttpClient(self.cfg, session=session)

        self.binders = BindersNamespace(self)
        self.datasets = DatasetsNamespace(self)
        self.diligence = DiligenceNamespace(self)
        self.users = UsersNamespace(self)
        self.jobs = JobsNamespace(self)

    def status(self) -> Any:
        return self._request("GET", "/v2/health")

    def load_data(
        self,
        *,
        protein_uuid: str,
        binders: Optional[int] = None,
        non_binders: Optional[int] = None,
        nonbinders: Optional[int] = None,
        idempotency_key: Optional[str] = None,
        include_metadata: bool = False,
    ) -> OmDataFrame | tuple[OmDataFrame, Dict[str, Any]]:
        if non_binders is not None and nonbinders is not None and non_binders != nonbinders:
            raise OMTXError("Pass only one of non_binders or nonbinders.")
        resolved_non_binders = non_binders if non_binders is not None else nonbinders

        export = self.binders.get_shards(
            protein_uuid=protein_uuid,
            idempotency_key=idempotency_key,
        )
        df = load_export_dataframe(
            export,
            binders=binders,
            non_binders=resolved_non_binders,
        )
        om_df = as_om_dataframe(df, metadata={"export": export})
        if include_metadata:
            return om_df, export
        return om_df

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "OmClient":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:  # pragma: no cover
        self.close()

    def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        json_body: Optional[Dict[str, Any]] = None,
        *,
        idempotency_key: Optional[str] = None,
        accept: str = "application/json",
        stream: bool = False,
    ) -> Any:
        return self._http.request(
            method=method,
            path=path,
            params=params,
            json_body=json_body,
            idempotency_key=idempotency_key,
            accept=accept,
            stream=stream,
        )

    @staticmethod
    def _normalize_base_url(value: str) -> str:
        raw = str(value or "").strip()
        parsed = urlparse(raw)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise OMTXError(
                "base_url must be a valid absolute URL with http/https scheme."
            )
        if parsed.path not in {"", "/"} or parsed.query or parsed.fragment:
            raise OMTXError(
                "base_url must not include a path, query, or fragment."
            )
        return raw.rstrip("/")

    @staticmethod
    def _warn_if_non_production_base_url(base_url: str) -> None:
        host = (urlparse(base_url).hostname or "").lower()
        if host != "api.omtx.ai":
            warnings.warn(
                f"Non-production base URL in use: {base_url}",
                UserWarning,
                stacklevel=3,
            )


__all__ = ["OmClient", "JobTimeoutError"]
