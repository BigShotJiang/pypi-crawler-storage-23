"""HTTP transport and auth/idempotency behavior for the SDK."""

from __future__ import annotations

import hashlib
import json
import time
from dataclasses import dataclass
from typing import Any, Optional

import requests

from .exceptions import APIError, AuthenticationError, InsufficientCreditsError, OMTXError


@dataclass
class ClientConfig:
    base_url: str
    api_key: str
    timeout: int


def _canonical_json(value: Any) -> str:
    try:
        return json.dumps(value, separators=(",", ":"), sort_keys=True, ensure_ascii=False)
    except Exception:
        return str(value)


def derive_idempotency_key(
    provided: Optional[str],
    method: str,
    path: str,
    body: Any,
) -> str:
    """Use caller key when valid; otherwise derive a deterministic retry key."""
    if provided and len(provided) >= 8:
        return provided
    issued_at_ms = int(time.time() * 1000)
    payload = f"{issued_at_ms}|{method.upper()}|{path}|{_canonical_json(body)}"
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


class GatewayHttpClient:
    """Internal HTTP client that owns request/response semantics."""

    def __init__(self, cfg: ClientConfig, session: Optional[requests.Session] = None):
        self.cfg = cfg
        self._session = session or requests.Session()

    def close(self) -> None:
        self._session.close()

    def _headers(self, *, idem_key: Optional[str], accept: str) -> dict[str, str]:
        headers = {
            "x-api-key": self.cfg.api_key,
            "accept": accept,
        }
        if idem_key:
            headers["idempotency-key"] = idem_key
            headers["content-type"] = "application/json"
        return headers

    @staticmethod
    def _handle_error(resp: requests.Response, path: str) -> None:
        try:
            payload = resp.json()
        except Exception:
            payload = resp.text or ""

        detail = payload.get("detail") if isinstance(payload, dict) else payload
        status = resp.status_code

        if status == 401:
            raise AuthenticationError(detail or "Unauthorized")
        if status == 402:
            raise InsufficientCreditsError(detail or "Insufficient credits")
        raise APIError(detail or f"HTTP {status} for {path}", status_code=status)

    def request(
        self,
        method: str,
        path: str,
        params: Optional[dict[str, Any]] = None,
        json_body: Optional[dict[str, Any]] = None,
        *,
        idempotency_key: Optional[str] = None,
        accept: str = "application/json",
        stream: bool = False,
    ) -> Any:
        method = method.upper()
        url = f"{self.cfg.base_url}{path}"

        body = json_body
        idem_header = None
        if method != "GET":
            body = json_body or {}
            idem_header = derive_idempotency_key(idempotency_key, method, path, body)

        headers = self._headers(idem_key=idem_header, accept=accept)
        if method != "GET" and "content-type" not in headers:
            headers["content-type"] = "application/json"

        resp = self._session.request(
            method=method,
            url=url,
            params=params,
            json=body if method != "GET" else None,
            headers=headers,
            timeout=self.cfg.timeout,
            stream=stream,
        )

        if resp.status_code >= 400:
            self._handle_error(resp, path)

        if stream:
            return resp

        if not resp.content:
            return {}

        try:
            return resp.json()
        except Exception as exc:
            raise OMTXError(f"Non-JSON response from {path}") from exc
