"""Dataframe helpers for shard exports and visualization."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from .exceptions import OMTXError


def _concat_frames(frame_lib: Any, frames: List[Any]) -> Any:
    concat = getattr(frame_lib, "concat", None)
    if not callable(concat):
        raise OMTXError("Dataframe library does not provide concat(...)")

    attempts = (
        {"how": "vertical_relaxed", "rechunk": True},
        {"how": "diagonal_relaxed", "rechunk": True},
        {"how": "vertical", "rechunk": True},
    )
    last_exc: Exception | None = None
    for kwargs in attempts:
        try:
            return concat(frames, **kwargs)
        except Exception as exc:
            last_exc = exc
            continue

    if last_exc is not None:
        raise OMTXError(f"Failed to concatenate dataframes: {last_exc}") from last_exc
    raise OMTXError("Failed to concatenate dataframes")


class OmDataFrame:
    """Lightweight wrapper around a Polars DataFrame with SDK convenience helpers."""

    def __init__(self, dataframe: Any, *, metadata: Optional[Dict[str, Any]] = None):
        self._df = dataframe
        self.metadata = dict(metadata or {})

    @property
    def df(self) -> Any:
        return self._df

    @property
    def columns(self) -> List[str]:
        columns = getattr(self._df, "columns", None)
        if columns is None:
            return []
        return list(columns)

    @property
    def shape(self) -> Any:
        return getattr(self._df, "shape", ())

    def to_polars(self) -> Any:
        return self._df

    def __len__(self) -> int:
        try:
            return len(self._df)
        except Exception:
            return 0

    def __repr__(self) -> str:
        return f"OmDataFrame({self._df!r})"

    def __getattr__(self, name: str) -> Any:
        return getattr(self._df, name)

    def show(
        self,
        *,
        top_n: int = 24,
        smiles_col: str = "product",
        score_col: str = "om_score",
        cols: int = 6,
        size: tuple[int, int] = (250, 200),
    ) -> Any:
        """Render top molecules in a grid (RDKit) or return a summary table fallback."""
        if top_n <= 0:
            raise OMTXError("top_n must be > 0")

        df = self._df
        is_polars_df = hasattr(df, "select") and hasattr(df, "head")
        if not is_polars_df:
            raise OMTXError(
                "show() requires a Polars DataFrame-backed OmDataFrame."
            )

        columns = set(self.columns)
        if smiles_col not in columns:
            raise OMTXError(
                f"Column '{smiles_col}' not found. Available columns: {sorted(columns)}"
            )
        include_score = score_col in columns

        preview: Any
        preview_rows: List[Dict[str, Any]]
        ordered = df
        if include_score and hasattr(df, "sort"):
            try:
                ordered = df.sort(score_col, descending=True, nulls_last=True)
            except TypeError:
                ordered = df.sort(score_col, descending=True)

        selected_cols = [smiles_col]
        if include_score:
            selected_cols.append(score_col)
        preview = ordered.select(selected_cols).head(top_n)
        preview_rows = preview.to_dicts()

        try:
            from rdkit import Chem
            from rdkit.Chem import Draw
        except ImportError:
            # Fallback for environments without RDKit rendering.
            return preview

        mols: list[Any] = []
        legends: list[str] = []
        skipped = 0
        for row in preview_rows:
            smiles = row.get(smiles_col)
            if not smiles:
                skipped += 1
                continue

            mol = Chem.MolFromSmiles(str(smiles))
            if mol is None:
                skipped += 1
                continue

            mols.append(mol)
            if include_score:
                legends.append(f"{row.get(score_col, '')}")
            else:
                legends.append("")

        if not mols:
            raise OMTXError("No valid SMILES were available for rendering.")

        image = Draw.MolsToGridImage(
            mols,
            molsPerRow=max(1, int(cols)),
            subImgSize=size,
            legends=legends,
        )

        try:
            from IPython.display import display

            display(image)
        except Exception:
            pass

        if skipped:
            self.metadata["show_skipped_smiles"] = skipped

        return image


def as_om_dataframe(
    dataframe: Any,
    *,
    metadata: Optional[Dict[str, Any]] = None,
) -> OmDataFrame:
    if isinstance(dataframe, OmDataFrame):
        if metadata:
            dataframe.metadata.update(metadata)
        return dataframe
    return OmDataFrame(dataframe, metadata=metadata)


def _read_shards(
    frame_lib: Any,
    urls: List[str],
    max_rows: Optional[int],
):
    frames: list[Any] = []
    remaining = max_rows

    for url in urls:
        if remaining is not None and remaining <= 0:
            break

        df = frame_lib.read_parquet(url)
        row_count = _row_count(df)
        if remaining is not None and row_count > remaining:
            df = df.head(remaining)
            row_count = _row_count(df)

        frames.append(df)
        if remaining is not None:
            remaining -= row_count

    if not frames:
        return _empty_dataframe(frame_lib)

    return _concat_frames(frame_lib, frames)


def _row_count(df: Any) -> int:
    height = getattr(df, "height", None)
    if isinstance(height, int):
        return height
    try:
        return len(df)
    except Exception:
        return 0


def _empty_dataframe(frame_lib: Any) -> Any:
    dataframe_ctor = getattr(frame_lib, "DataFrame", None)
    if callable(dataframe_ctor):
        return dataframe_ctor()
    raise OMTXError("Dataframe library does not provide DataFrame constructor")


def _extract_url_list(export: Dict[str, Any], *, flat_key: str, nested_key: str) -> List[str]:
    direct_urls = export.get(flat_key)
    if isinstance(direct_urls, list):
        return [str(url) for url in direct_urls if isinstance(url, str) and url]

    nested_urls = (export.get(nested_key) or {}).get("urls", [])
    urls: List[str] = []
    if not isinstance(nested_urls, list):
        return urls

    for row in nested_urls:
        if isinstance(row, str) and row:
            urls.append(row)
            continue
        if isinstance(row, dict):
            url = row.get("url")
            if isinstance(url, str) and url:
                urls.append(url)
    return urls


def load_export_dataframe(
    export: Dict[str, Any],
    *,
    binders: Optional[int] = None,
    non_binders: Optional[int] = None,
):
    """Load signed shard URLs into a Polars DataFrame.

    Args:
        export: Response payload returned by `client.binders.get_shards(...)`.
        binders: Number of binder rows to read. If omitted, read all binder rows.
        non_binders: Number of non-binder rows to read. If omitted, defaults to
            10x binder rows (requested or loaded).
    """
    try:
        import polars as frame_lib
    except ImportError as exc:
        raise OMTXError("Polars is required. Install with: pip install omtx") from exc

    if binders is not None and binders < 0:
        raise OMTXError("binders must be >= 0")
    if non_binders is not None and non_binders < 0:
        raise OMTXError("non_binders must be >= 0")

    binder_urls = _extract_url_list(
        export,
        flat_key="binder_urls",
        nested_key="binders",
    )
    non_binder_urls = _extract_url_list(
        export,
        flat_key="non_binder_urls",
        nested_key="non_binders",
    )

    binders_df = _read_shards(frame_lib, binder_urls, binders)

    if non_binders is None:
        target = (int(binders) * 10) if binders is not None else (_row_count(binders_df) * 10)
    else:
        target = non_binders

    non_binders_df = _read_shards(frame_lib, non_binder_urls, target)

    binders_rows = _row_count(binders_df)
    non_binders_rows = _row_count(non_binders_df)
    if binders_rows == 0 and non_binders_rows == 0:
        return _empty_dataframe(frame_lib)
    if binders_rows == 0:
        return non_binders_df
    if non_binders_rows == 0:
        return binders_df

    return _concat_frames(frame_lib, [binders_df, non_binders_df])


__all__ = [
    "OmDataFrame",
    "as_om_dataframe",
]
