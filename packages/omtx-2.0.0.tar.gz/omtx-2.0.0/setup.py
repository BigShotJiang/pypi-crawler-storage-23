"""Legacy setuptools entrypoint.

Canonical package metadata lives in `pyproject.toml`.
"""

from setuptools import setup

if __name__ == "__main__":
    setup()
