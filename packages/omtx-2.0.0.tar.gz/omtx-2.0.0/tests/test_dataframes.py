from __future__ import annotations

from pathlib import Path

import pytest

from omtx.dataframes import load_export_dataframe


def _write_polars_parquet(path: Path, rows: list[dict[str, object]]) -> None:
    pl = pytest.importorskip("polars")
    pl.DataFrame(rows).write_parquet(str(path))


def test_load_export_dataframe_supports_flat_url_aliases(tmp_path: Path):
    binder_path = tmp_path / "binders.parquet"
    non_binder_path = tmp_path / "non_binders.parquet"

    _write_polars_parquet(
        binder_path,
        [
            {"product": "CCO", "om_score": 0.92},
            {"product": "CCN", "om_score": 0.91},
            {"product": "CCC", "om_score": 0.90},
        ],
    )
    _write_polars_parquet(
        non_binder_path,
        [
            {"product": "CO", "om_score": 0.40},
            {"product": "CN", "om_score": 0.39},
            {"product": "CC", "om_score": 0.38},
            {"product": "CS", "om_score": 0.37},
        ],
    )

    export = {
        "binder_urls": [str(binder_path)],
        "non_binder_urls": [str(non_binder_path)],
    }

    df = load_export_dataframe(
        export,
        binders=2,
        non_binders=3,
    )
    assert df.height == 5
    assert set(df.columns) == {"product", "om_score"}


def test_load_export_dataframe_supports_nested_url_shape(tmp_path: Path):
    binder_path = tmp_path / "binders_nested.parquet"
    non_binder_path = tmp_path / "non_binders_nested.parquet"

    _write_polars_parquet(
        binder_path,
        [
            {"product": "CCO", "om_score": 0.92},
            {"product": "CCN", "om_score": 0.91},
        ],
    )
    _write_polars_parquet(
        non_binder_path,
        [
            {"product": "CO", "om_score": 0.40},
            {"product": "CN", "om_score": 0.39},
        ],
    )

    export = {
        "binders": {"urls": [{"file_path": "binders_nested.parquet", "url": str(binder_path)}]},
        "non_binders": {
            "urls": [{"file_path": "non_binders_nested.parquet", "url": str(non_binder_path)}]
        },
    }

    df = load_export_dataframe(
        export,
        binders=1,
        non_binders=1,
    )
    assert df.height == 2


def test_load_export_dataframe_relaxes_mixed_numeric_types(tmp_path: Path):
    binder_path = tmp_path / "binders_mixed_dtype.parquet"
    non_binder_path = tmp_path / "non_binders_mixed_dtype.parquet"

    _write_polars_parquet(
        binder_path,
        [
            {"product": "CCO", "om_score": 1},
            {"product": "CCN", "om_score": 2},
        ],
    )
    _write_polars_parquet(
        non_binder_path,
        [
            {"product": "CO", "om_score": 0.4},
            {"product": "CN", "om_score": 0.3},
        ],
    )

    export = {
        "binder_urls": [str(binder_path)],
        "non_binder_urls": [str(non_binder_path)],
    }

    df = load_export_dataframe(export, binders=2, non_binders=2)
    assert df.height == 4

    pl = pytest.importorskip("polars")
    assert df.schema["om_score"] == pl.Float64
