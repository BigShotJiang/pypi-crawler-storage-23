from __future__ import annotations

from pathlib import Path

from omtx.contracts import (
    JOB_TERMINAL_FAILURE_STATUSES,
    SDK_ALIAS_ONLY_ENDPOINTS,
    SDK_EXPOSED_ENDPOINTS,
    SDK_NON_CORE_NOT_EXPOSED_ENDPOINTS,
)


REPO_ROOT = Path(__file__).resolve().parents[2]


def _read(path: str) -> str:
    return (REPO_ROOT / path).read_text(encoding="utf-8")


def test_sdk_gateway_contract_endpoints_exist_in_gateway_sources():
    gateway_source = "\n".join(
        [
            _read("backend/gateway/app.py"),
            _read("backend/gateway/endpoints/diligence.py"),
            _read("backend/gateway/endpoints/data_access.py"),
            _read("backend/gateway/endpoints/pricing.py"),
        ]
    )

    for endpoint in sorted(SDK_EXPOSED_ENDPOINTS):
        assert endpoint in gateway_source, f"Missing endpoint in gateway sources: {endpoint}"


def test_intentionally_not_exposed_routes_are_documented():
    internal_docs_source = "\n".join(
        [
            _read("docs/architecture/gateway-sdk-compatibility.md"),
            _read("docs/architecture/python-sdk-current-state.md"),
            _read("python-sdk/README.md"),
        ]
    )
    frontend_docs_source = "\n".join(
        [
            _read("frontend/content/docs/api/sdk-overview.yaml"),
            _read("frontend/content/docs/api/sdk-tutorial.yaml"),
        ]
    )

    for endpoint in sorted(SDK_ALIAS_ONLY_ENDPOINTS):
        assert endpoint in internal_docs_source, f"Undocumented alias-only route: {endpoint}"

    for endpoint in sorted(SDK_NON_CORE_NOT_EXPOSED_ENDPOINTS):
        assert endpoint in internal_docs_source, f"Undocumented non-core exclusion: {endpoint}"
        assert endpoint not in frontend_docs_source, (
            f"Non-core endpoint leaked to frontend docs: {endpoint}"
        )


def test_non_core_rag_not_exposed_on_customer_facing_frontend_surfaces():
    pricing_page = _read("frontend/app/(marketing)/pricing/page.tsx")
    pricing_api_route = _read("frontend/app/api/pricing/route.ts")
    frontend_sdk_docs = "\n".join(
        [
            _read("frontend/content/docs/api/sdk-overview.yaml"),
            _read("frontend/content/docs/api/sdk-tutorial.yaml"),
        ]
    )

    assert "/v2/rag/search" not in pricing_page
    assert "/v2/rag/search" not in frontend_sdk_docs
    assert "if (p === '/v2/rag/search') return false;" in pricing_api_route


def test_pricing_helpers_not_exposed_in_sdk_client_surface():
    sdk_client = _read("python-sdk/omtx/client.py")
    sdk_namespaces = _read("python-sdk/omtx/namespaces/__init__.py")
    sdk_docs = "\n".join(
        [
            _read("python-sdk/README.md"),
            _read("frontend/content/docs/api/sdk-overview.yaml"),
            _read("frontend/content/docs/api/sdk-tutorial.yaml"),
        ]
    )

    assert "self.pricing" not in sdk_client
    assert "PricingNamespace" not in sdk_namespaces
    assert "pricing.manifest" not in sdk_docs
    assert "pricing.cost_estimate" not in sdk_docs
    assert "binders.cost_estimate" not in sdk_docs
    assert "self.gateway" not in sdk_client
    assert "GatewayNamespace" not in sdk_namespaces


def test_terminal_status_contract_includes_cancel_aliases():
    assert "canceled" in JOB_TERMINAL_FAILURE_STATUSES
    assert "cancelled" in JOB_TERMINAL_FAILURE_STATUSES


def test_sdk_docs_advertise_active_diligence_helpers():
    sdk_docs = "\n".join(
        [
            _read("frontend/content/docs/api/sdk-overview.yaml"),
            _read("frontend/content/docs/api/sdk-tutorial.yaml"),
        ]
    )
    assert "search" in sdk_docs
    assert "gather" in sdk_docs
    assert "crawl" in sdk_docs


def test_sdk_docs_advertise_status_and_load_data_without_vintage_number():
    sdk_docs = "\n".join(
        [
            _read("python-sdk/README.md"),
            _read("frontend/content/docs/api/sdk-overview.yaml"),
            _read("frontend/content/docs/api/sdk-tutorial.yaml"),
        ]
    )
    assert "client.status()" in sdk_docs
    assert "load_data(" in sdk_docs
    assert ".show(" in sdk_docs
    assert "binders.urls(" in sdk_docs
    assert "client.gateway.status" not in sdk_docs
    assert "load_shards_dataframe" not in sdk_docs
    assert 'format="pandas"' not in sdk_docs
    assert "pip install pandas" not in sdk_docs
    assert "vintage_number" not in sdk_docs


def test_legal_docs_do_not_claim_customer_vintage_number_selection():
    legal_docs = "\n".join(
        [
            _read("frontend/content/docs/legal/faq.yaml"),
            _read("frontend/content/docs/legal/privacy.yaml"),
        ]
    )
    assert "vintage_number" not in legal_docs


def test_first_party_mcp_consumer_matches_status_and_route_contracts():
    mcp_source = _read("backend/mcps/om-mcp/main.py")
    assert "/v2/diligence/search" in mcp_source
    assert "/v2/diligence/gather" in mcp_source
    assert "/v2/diligence/crawl" in mcp_source
    assert "/v2/diligence/deep-diligence" in mcp_source
    assert "canceled" in mcp_source
    assert "cancelled" in mcp_source


def test_changelog_client_rename_timeline_is_consistent():
    changelog = _read("python-sdk/CHANGELOG.md")

    section_2 = changelog.split("## [2.0.0]", maxsplit=1)[1].split(
        "## [1.0.0]", maxsplit=1
    )[0]
    section_1 = changelog.split("## [1.0.0]", maxsplit=1)[1].split(
        "## [0.4.2]", maxsplit=1
    )[0]

    assert "Renamed the SDK entrypoint class from `OMTXClient` to `OmClient`." in section_2
    assert "`OMTXClient` symbol export from `omtx`" in section_2

    # Historical 1.0.0 section should keep historical naming.
    assert "`OMTXClient` to a composition layer" in section_1
    assert "Pinned `OMTXClient` to the production gateway base URL" in section_1
    assert "`OmClient` to a composition layer" not in section_1
    assert "Pinned `OmClient` to the production gateway base URL" not in section_1
