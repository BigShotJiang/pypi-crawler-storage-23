from __future__ import annotations

import json
import os
from unittest.mock import MagicMock, patch

import pytest
import requests
import omtx

from omtx import OmClient, OMTXError
from omtx.client import JobTimeoutError
from omtx.dataframes import OmDataFrame
from omtx.exceptions import APIError


def make_response(status: int, payload: dict | str) -> MagicMock:
    resp = MagicMock(spec=requests.Response)
    resp.status_code = status
    if isinstance(payload, dict):
        resp.json.return_value = payload
        resp.content = json.dumps(payload).encode("utf-8")
        resp.text = json.dumps(payload)
    else:
        resp.json.side_effect = ValueError
        resp.content = payload.encode("utf-8")
        resp.text = payload
    return resp


def test_requires_api_key():
    with patch.dict(os.environ, {}, clear=True):
        with pytest.raises(OMTXError):
            OmClient()


def test_uses_env_api_key():
    with patch.dict(os.environ, {"OMTX_API_KEY": "env-key"}):
        client = OmClient()
        assert client.cfg.api_key == "env-key"
        client.close()


def test_legacy_client_not_exported():
    assert not hasattr(omtx, "OMTXClient")
    assert not hasattr(omtx, "load_shards_dataframe")


@patch("omtx.client.requests.Session.request")
def test_health_status_calls_gateway(mock_request):
    mock_request.return_value = make_response(200, {"status": "ok"})
    client = OmClient(api_key="key")

    result = client.status()
    assert result["status"] == "ok"

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "GET"
    assert kwargs["url"].endswith("/v2/health")


def test_gateway_namespace_not_exposed():
    client = OmClient(api_key="key")
    assert not hasattr(client, "gateway")


@patch("omtx.client.requests.Session.request")
def test_users_credits(mock_request):
    mock_request.return_value = make_response(
        200, {"available_credits": 1234}
    )
    client = OmClient(api_key="key")

    credits = client.users.profile()
    assert credits["available_credits"] == 1234

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "GET"
    assert kwargs["url"].endswith("/v2/credits")


@patch("omtx.client.requests.Session.request")
def test_diligence_list_gene_keys_fetches_all(mock_request):
    mock_request.side_effect = [
        make_response(200, {"items": [{"gene_key": "acad8"}], "count": 2}),
        make_response(200, {"items": [{"gene_key": "tp53"}], "count": 2}),
    ]
    client = OmClient(api_key="key")

    result = client.diligence.list_gene_keys()
    assert result["count"] == 2
    assert [item["gene_key"] for item in result["items"]] == ["acad8", "tp53"]

    first_call = mock_request.call_args_list[0].kwargs
    assert first_call["params"]["limit"] == 200
    assert first_call["params"]["offset"] == 0
    assert len(mock_request.call_args_list) == 2


@patch("omtx.client.requests.Session.request")
def test_get_shards_payload(mock_request):
    mock_request.return_value = make_response(
        200, {"binders": {"urls": []}, "non_binders": {"urls": []}}
    )
    client = OmClient(api_key="key")

    client.binders.get_shards(
        protein_uuid="uuid",
        idempotency_key="abc",
    )

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["json"] == {
        "protein_uuid": "uuid",
    }
    assert kwargs["headers"]["idempotency-key"]
    assert kwargs["url"].endswith("/v2/data-access/shards")


@patch("omtx.client.requests.Session.request")
def test_get_shards_urls_helper_prefers_flat_aliases(mock_request):
    mock_request.return_value = make_response(
        200,
        {
            "protein_uuid": "uuid",
            "dataset_id": "dataset-1",
            "vintage_id": "v1",
            "vintage": "20260201_om1",
            "binder_urls": ["https://example/b1.parquet"],
            "non_binder_urls": ["https://example/n1.parquet"],
            "binders": {"urls": []},
            "non_binders": {"urls": []},
            "expires_at": "2026-02-26T00:00:00Z",
        },
    )
    client = OmClient(api_key="key")

    urls = client.binders.urls(protein_uuid="uuid")
    assert urls["binder_urls"] == ["https://example/b1.parquet"]
    assert urls["non_binder_urls"] == ["https://example/n1.parquet"]


@patch("omtx.client.requests.Session.request")
def test_get_shards_urls_helper_falls_back_to_nested(mock_request):
    mock_request.return_value = make_response(
        200,
        {
            "protein_uuid": "uuid",
            "binders": {
                "urls": [
                    {"file_path": "a.parquet", "url": "https://example/a.parquet"},
                ]
            },
            "non_binders": {
                "urls": [
                    {"file_path": "b.parquet", "url": "https://example/b.parquet"},
                ]
            },
            "expires_at": "2026-02-26T00:00:00Z",
        },
    )
    client = OmClient(api_key="key")

    urls = client.binders.urls(protein_uuid="uuid")
    assert urls["binder_urls"] == ["https://example/a.parquet"]
    assert urls["non_binder_urls"] == ["https://example/b.parquet"]


@patch("omtx.client.requests.Session.request")
def test_datasets_generated_protein_uuids_returns_section(mock_request):
    mock_request.return_value = make_response(
        200,
        {
            "catalog": {"items": [], "count": 0},
            "data_generated": {"items": [], "count": 0},
            "accessible_generated_protein_uuids": ["protein-1", "protein-2"],
            "accessible_dataset_ids": [],
        },
    )
    client = OmClient(api_key="key")

    result = client.datasets.generated_protein_uuids()

    assert result == ["protein-1", "protein-2"]
    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "GET"
    assert kwargs["url"].endswith("/v2/datasets/catalog")


@patch("omtx.client.requests.Session.request")
def test_datasets_generated_protein_uuids_falls_back_to_data_generated(mock_request):
    mock_request.return_value = make_response(
        200,
        {
            "catalog": {"items": [], "count": 0},
            "data_generated": {
                "items": [
                    {"protein_uuid": "protein-z"},
                    {"protein_uuid": "protein-a"},
                    {"protein_uuid": "protein-z"},
                ],
                "count": 3,
            },
            "accessible_dataset_ids": [],
        },
    )
    client = OmClient(api_key="key")

    result = client.datasets.generated_protein_uuids()

    assert result == ["protein-a", "protein-z"]


def test_pricing_namespace_not_exposed():
    client = OmClient(api_key="key")
    assert not hasattr(client, "pricing")


@patch("omtx.client.load_export_dataframe")
@patch("omtx.client.requests.Session.request")
def test_load_data_orchestrates_shard_export_and_dataframe_loader(
    mock_request,
    mock_load_export_dataframe,
):
    export_payload = {
        "binders": {"urls": [{"file_path": "a.parquet", "url": "https://example/a"}]},
        "non_binders": {"urls": []},
    }
    mock_request.return_value = make_response(200, export_payload)
    mock_load_export_dataframe.return_value = "df"
    client = OmClient(api_key="key")

    result = client.load_data(
        protein_uuid="uuid",
        binders=100,
        non_binders=1000,
        idempotency_key="idem-123",
    )

    assert isinstance(result, OmDataFrame)
    assert result.df == "df"
    mock_load_export_dataframe.assert_called_once_with(
        export_payload,
        binders=100,
        non_binders=1000,
    )


@patch("omtx.client.load_export_dataframe")
@patch("omtx.client.requests.Session.request")
def test_load_data_include_metadata_returns_dataframe_and_export(
    mock_request,
    mock_load_export_dataframe,
):
    export_payload = {
        "binders": {"urls": []},
        "non_binders": {"urls": []},
    }
    mock_request.return_value = make_response(200, export_payload)
    mock_load_export_dataframe.return_value = "df"
    client = OmClient(api_key="key")

    result = client.load_data(
        protein_uuid="uuid",
        include_metadata=True,
    )

    df, payload = result
    assert isinstance(df, OmDataFrame)
    assert df.df == "df"
    assert payload == export_payload


@patch("omtx.OmClient")
def test_module_level_load_data_uses_omclient(mock_client_cls):
    mock_client = mock_client_cls.return_value.__enter__.return_value
    mock_client.load_data.return_value = "df"

    result = omtx.load_data(protein_uuid="uuid", binders=10, non_binders=100)

    assert result == "df"
    mock_client.load_data.assert_called_once_with(
        protein_uuid="uuid",
        binders=10,
        non_binders=100,
        nonbinders=None,
        idempotency_key=None,
        include_metadata=False,
    )
    mock_client_cls.assert_called_once_with(
        api_key=None,
        base_url=None,
        timeout=3600,
    )


@patch("omtx.OmClient")
def test_module_level_load_data_supports_nonbinders_alias(mock_client_cls):
    mock_client = mock_client_cls.return_value.__enter__.return_value
    mock_client.load_data.return_value = "df"

    result = omtx.load_data(protein_uuid="uuid", binders=10, nonbinders=250)

    assert result == "df"
    mock_client.load_data.assert_called_once_with(
        protein_uuid="uuid",
        binders=10,
        non_binders=None,
        nonbinders=250,
        idempotency_key=None,
        include_metadata=False,
    )


@patch("omtx.OmClient")
def test_module_level_load_data_supports_base_url_override(mock_client_cls):
    mock_client = mock_client_cls.return_value.__enter__.return_value
    mock_client.load_data.return_value = "df"

    result = omtx.load_data(
        protein_uuid="uuid",
        binders=10,
        non_binders=100,
        base_url="https://develop-api.omtx.ai",
    )

    assert result == "df"
    mock_client_cls.assert_called_once_with(
        api_key=None,
        base_url="https://develop-api.omtx.ai",
        timeout=3600,
    )


@patch("omtx.client.load_export_dataframe")
@patch("omtx.client.requests.Session.request")
def test_load_data_accepts_nonbinders_alias(
    mock_request,
    mock_load_export_dataframe,
):
    export_payload = {
        "binders": {"urls": []},
        "non_binders": {"urls": []},
    }
    mock_request.return_value = make_response(200, export_payload)
    mock_load_export_dataframe.return_value = "df"
    client = OmClient(api_key="key")

    result = client.load_data(
        protein_uuid="uuid",
        binders=100,
        nonbinders=250,
    )

    assert isinstance(result, OmDataFrame)
    assert result.df == "df"
    mock_load_export_dataframe.assert_called_once_with(
        export_payload,
        binders=100,
        non_binders=250,
    )


def test_load_data_rejects_conflicting_nonbinder_arguments():
    client = OmClient(api_key="key")
    with pytest.raises(OMTXError, match="Pass only one of non_binders or nonbinders."):
        client.load_data(
            protein_uuid="uuid",
            non_binders=100,
            nonbinders=200,
        )


def test_om_dataframe_show_validates_smiles_column():
    wrapped = OmDataFrame("not-a-polars-df")
    with pytest.raises(OMTXError, match="requires a Polars DataFrame-backed"):
        wrapped.show()


def test_om_dataframe_show_handles_missing_score_column():
    polars = pytest.importorskip("polars")
    wrapped = OmDataFrame(
        polars.DataFrame(
            {
                "product": ["CCO", "CCN", "CCC"],
            }
        )
    )
    output = wrapped.show(top_n=2, score_col="missing_score")
    assert output is not None


def test_binders_get_removed_with_migration_error():
    client = OmClient(api_key="key")

    with pytest.raises(OMTXError, match="removed from the core SDK"):
        client.binders.get()


@patch("omtx.client.requests.Session.request")
def test_diligence_deep_diligence(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-123"})
    client = OmClient(api_key="key")

    resp = client.diligence.deep_diligence(query="TP53 summary")
    assert resp["job_id"] == "job-123"

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["json"] == {"query": "TP53 summary"}
    assert kwargs["headers"]["idempotency-key"]
    assert kwargs["url"].endswith("/v2/diligence/deep-diligence")


@patch("omtx.client.requests.Session.request")
def test_diligence_deep_diligence_accepts_explicit_idempotency_key(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-123"})
    client = OmClient(api_key="key")

    client.diligence.deep_diligence(
        query="TP53 summary", idempotency_key="idem-explicit-123"
    )

    kwargs = mock_request.call_args.kwargs
    assert kwargs["headers"]["idempotency-key"] == "idem-explicit-123"


@patch("omtx.client.requests.Session.request")
def test_diligence_synthesize_report_accepts_explicit_idempotency_key(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-456"})
    client = OmClient(api_key="key")

    client.diligence.synthesize_report(
        gene_key="acad8", idempotency_key="idem-explicit-456"
    )

    kwargs = mock_request.call_args.kwargs
    assert kwargs["headers"]["idempotency-key"] == "idem-explicit-456"
    assert kwargs["url"].endswith("/v2/diligence/synthesizeReport")


@patch("omtx.client.requests.Session.request")
def test_diligence_search_wrapper(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-s1"})
    client = OmClient(api_key="key")

    resp = client.diligence.search(query="BRAF landscape")
    assert resp["job_id"] == "job-s1"

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["json"] == {"query": "BRAF landscape"}
    assert kwargs["url"].endswith("/v2/diligence/search")


@patch("omtx.client.requests.Session.request")
def test_diligence_gather_wrapper(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-g1"})
    client = OmClient(api_key="key")

    resp = client.diligence.gather(query="BRAF landscape")
    assert resp["job_id"] == "job-g1"

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["json"] == {"query": "BRAF landscape"}
    assert kwargs["url"].endswith("/v2/diligence/gather")


@patch("omtx.client.requests.Session.request")
def test_diligence_crawl_wrapper(mock_request):
    mock_request.return_value = make_response(202, {"job_id": "job-c1"})
    client = OmClient(api_key="key")

    resp = client.diligence.crawl(url="https://example.com", max_pages=7)
    assert resp["job_id"] == "job-c1"

    kwargs = mock_request.call_args.kwargs
    assert kwargs["method"] == "POST"
    assert kwargs["json"] == {"url": "https://example.com", "max_pages": 7}
    assert kwargs["url"].endswith("/v2/diligence/crawl")


def test_default_base_url_is_api_domain():
    with patch.dict(os.environ, {"OMTX_API_KEY": "env-key"}, clear=True):
        client = OmClient()
        assert client.cfg.base_url == "https://api.omtx.ai"
        client.close()


def test_omtx_base_url_env_var_is_used():
    with patch.dict(
        os.environ,
        {"OMTX_API_KEY": "env-key", "OMTX_BASE_URL": "https://example.com"},
        clear=True,
    ):
        with pytest.warns(UserWarning, match="Non-production base URL in use"):
            client = OmClient()
        assert client.cfg.base_url == "https://example.com"
        client.close()


def test_base_url_constructor_override_takes_precedence_over_env():
    with patch.dict(
        os.environ,
        {"OMTX_API_KEY": "env-key", "OMTX_BASE_URL": "https://env.example.com"},
        clear=True,
    ):
        with pytest.warns(UserWarning, match="Non-production base URL in use"):
            client = OmClient(base_url="https://ctor.example.com")
        assert client.cfg.base_url == "https://ctor.example.com"
        client.close()


def test_base_url_constructor_override_is_supported():
    with patch.dict(os.environ, {"OMTX_API_KEY": "env-key"}, clear=True):
        with pytest.warns(UserWarning, match="Non-production base URL in use"):
            client = OmClient(base_url="https://example.com")
        assert client.cfg.base_url == "https://example.com"
        client.close()


@pytest.mark.parametrize(
    ("value", "message"),
    [
        ("not-a-url", "base_url must be a valid absolute URL with http/https scheme."),
        ("https://example.com/v2", "base_url must not include a path, query, or fragment."),
    ],
)
def test_invalid_base_url_raises(value, message):
    with patch.dict(os.environ, {"OMTX_API_KEY": "env-key"}, clear=True):
        with pytest.raises(OMTXError, match=message):
            OmClient(base_url=value)


def test_jobs_wait_success():
    client = OmClient(api_key="key")
    client.jobs.status = MagicMock(
        side_effect=[
            {"job_id": "abc", "status": "queued"},
            {"job_id": "abc", "status": "succeeded"},
        ]
    )
    client._request = MagicMock(return_value={"result": "ok"})

    with patch("omtx.namespaces.jobs.time.sleep", return_value=None):
        result = client.jobs.wait(
            "abc", result_endpoint="/v2/jobs/foo/{job_id}", poll_interval=0.01
        )

    assert result == {"result": "ok"}
    client._request.assert_called_once()


def test_jobs_wait_failure():
    client = OmClient(api_key="key")
    client.jobs.status = MagicMock(
        side_effect=[
            {"job_id": "abc", "status": "failed", "error": "boom", "status_code": 422}
        ]
    )

    with patch("omtx.namespaces.jobs.time.sleep", return_value=None):
        with pytest.raises(APIError) as excinfo:
            client.jobs.wait("abc", poll_interval=0.01, timeout=0.05)

    assert excinfo.value.status_code == 422
    assert "boom" in str(excinfo.value)


def test_jobs_wait_cancelled_alias():
    client = OmClient(api_key="key")
    client.jobs.status = MagicMock(
        side_effect=[
            {"job_id": "abc", "status": "cancelled", "error": "stopped by user"}
        ]
    )

    with patch("omtx.namespaces.jobs.time.sleep", return_value=None):
        with pytest.raises(APIError) as excinfo:
            client.jobs.wait("abc", poll_interval=0.01, timeout=0.05)

    assert excinfo.value.status_code == 500
    assert "stopped by user" in str(excinfo.value)


def test_jobs_wait_timeout():
    client = OmClient(api_key="key")
    client.jobs.status = MagicMock(return_value={"status": "queued"})

    with patch("omtx.namespaces.jobs.time.sleep", return_value=None):
        with pytest.raises(JobTimeoutError):
            client.jobs.wait("abc", poll_interval=0.01, timeout=0.05)
