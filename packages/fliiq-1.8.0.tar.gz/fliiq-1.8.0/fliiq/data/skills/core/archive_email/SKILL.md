---
name: archive_email
description: "Archive an email by IMAP UID (removes from Inbox, keeps in All Mail). Uses OAuth or app password fallback."
---

Archive an email by removing it from Gmail's Inbox while keeping it in All Mail. Uses IMAP UID from `receive_emails`.

Pass the `id` field from a receive_emails result as the `message_id` parameter.
