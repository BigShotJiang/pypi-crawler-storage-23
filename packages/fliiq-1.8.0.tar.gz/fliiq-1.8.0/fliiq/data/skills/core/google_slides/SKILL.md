---
name: google_slides
description: "Manage Google Slides: create presentations, read slides, add slides, insert text, batch update. Supports multiple Google accounts. Requires OAuth via `fliiq google auth`."
---

Use this tool to create and edit Google Slides presentations. Supports reading slide content, adding new slides, inserting text, and batch updates for complex modifications.

## Setup Required
1. Create a Google Cloud project at https://console.cloud.google.com/
2. Enable the Google Slides API
3. Create OAuth 2.0 credentials (Desktop app type), set redirect URI to http://localhost:8080/callback
4. Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET in your .env file
5. Run `fliiq google auth` to authorize each Google account

If you authorized before Slides support was added, run `fliiq google auth` again to grant Slides permissions.

## Available Actions
- create: Create a new blank presentation
- read: Read presentation structure (slides, shapes, text content)
- add_slide: Add a new slide with a specified layout
- insert_text: Insert text into a specific shape on a slide
- batch_update: Apply multiple structured updates

## Slide Layouts
Common predefined layouts for add_slide:
- `BLANK` — empty slide
- `TITLE` — title slide
- `TITLE_AND_BODY` — title with body text area
- `TITLE_AND_TWO_COLUMNS` — title with two columns
- `SECTION_HEADER` — section divider

## Batch Update Requests
The `requests` parameter accepts a list of Slides API request objects:
- `{"createSlide": {"slideLayoutReference": {"predefinedLayout": "BLANK"}}}`
- `{"insertText": {"objectId": "shape_id", "text": "Hello", "insertionIndex": 0}}`
- `{"deleteObject": {"objectId": "slide_or_shape_id"}}`
- `{"updateShapeProperties": {"objectId": "...", "shapeProperties": {...}, "fields": "..."}}`

## Multi-Account
Use the `account_email` parameter to specify which Google account to use. Defaults to the first authorized account.
