"""Tests for the shell skill."""

import os

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill(name: str) -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, name))


async def test_shell_echo():
    skill = _load_skill("shell")
    result = await skill.execute({"command": "echo hello"})
    assert result["stdout"].strip() == "hello"
    assert result["exit_code"] == 0


async def test_shell_stderr():
    skill = _load_skill("shell")
    result = await skill.execute({"command": "echo error >&2"})
    assert "error" in result["stderr"]
    assert result["exit_code"] == 0


async def test_shell_exit_code():
    skill = _load_skill("shell")
    result = await skill.execute({"command": "exit 42"})
    assert result["exit_code"] == 42


async def test_shell_working_directory(tmp_path):
    skill = _load_skill("shell")
    result = await skill.execute({"command": "pwd", "directory": str(tmp_path)})
    assert str(tmp_path) in result["stdout"]


async def test_shell_timeout():
    skill = _load_skill("shell")
    result = await skill.execute({"command": "sleep 10", "timeout": 1})
    assert result["exit_code"] == -1
    assert "timed out" in result["stderr"]


async def test_shell_multiline_output():
    skill = _load_skill("shell")
    result = await skill.execute({"command": "echo 'line1\nline2\nline3'"})
    assert "line1" in result["stdout"]
    assert "line3" in result["stdout"]
