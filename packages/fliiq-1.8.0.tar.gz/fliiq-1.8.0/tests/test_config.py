"""Tests for fliiq.runtime.config — centralized path resolution."""

from pathlib import Path

import pytest

from fliiq.runtime.config import (
    global_fliiq_dir,
    local_fliiq_dir,
    resolve_env_file,
    resolve_fliiq_dir,
)


def test_global_fliiq_dir_returns_home():
    result = global_fliiq_dir()
    assert result == Path.home() / ".fliiq"


def test_local_fliiq_dir_found(tmp_path, monkeypatch):
    (tmp_path / ".fliiq").mkdir()
    monkeypatch.chdir(tmp_path)
    assert local_fliiq_dir() == tmp_path / ".fliiq"


def test_local_fliiq_dir_walks_up(tmp_path, monkeypatch):
    (tmp_path / ".fliiq").mkdir()
    child = tmp_path / "sub" / "deep"
    child.mkdir(parents=True)
    monkeypatch.chdir(child)
    assert local_fliiq_dir() == tmp_path / ".fliiq"


def test_local_fliiq_dir_returns_none(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    assert local_fliiq_dir() is None


def test_resolve_fliiq_dir_prefers_local(tmp_path, monkeypatch):
    (tmp_path / ".fliiq").mkdir()
    monkeypatch.chdir(tmp_path)
    # Even if global exists, local wins
    assert resolve_fliiq_dir() == tmp_path / ".fliiq"


def test_resolve_fliiq_dir_falls_back_to_global(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fake_global = tmp_path / "fake_home" / ".fliiq"
    fake_global.mkdir(parents=True)
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", fake_global)
    assert resolve_fliiq_dir() == fake_global


def test_resolve_fliiq_dir_raises_when_neither(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", tmp_path / "nonexistent")
    with pytest.raises(FileNotFoundError, match="fliiq init"):
        resolve_fliiq_dir()


def test_resolve_fliiq_dir_require_local_raises(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fake_global = tmp_path / "fake_home" / ".fliiq"
    fake_global.mkdir(parents=True)
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", fake_global)
    # Global exists but require_local=True
    with pytest.raises(FileNotFoundError, match="--project"):
        resolve_fliiq_dir(require_local=True)


def test_resolve_env_file_prefers_local(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    (tmp_path / ".env").write_text("LOCAL=1")
    fake_global = tmp_path / "fake_home" / ".fliiq"
    fake_global.mkdir(parents=True)
    (fake_global / ".env").write_text("GLOBAL=1")
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", fake_global)
    assert resolve_env_file() == tmp_path / ".env"


def test_resolve_env_file_falls_back_to_global(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fake_global = tmp_path / "fake_home" / ".fliiq"
    fake_global.mkdir(parents=True)
    (fake_global / ".env").write_text("GLOBAL=1")
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", fake_global)
    assert resolve_env_file() == fake_global / ".env"


def test_resolve_env_file_returns_none(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr("fliiq.runtime.config.GLOBAL_DIR", tmp_path / "nonexistent")
    assert resolve_env_file() is None
