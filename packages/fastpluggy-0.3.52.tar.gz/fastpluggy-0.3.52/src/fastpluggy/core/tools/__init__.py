from datetime import date, datetime
from typing import get_origin, get_args, Union
from types import UnionType
import sys

def convert_param_type(param_type, value):
    # Handle Union types (like Optional[int] or int | None)
    origin = get_origin(param_type)
    if origin is Union or origin is UnionType:
        # Get all non-None types in the Union
        args = [arg for arg in get_args(param_type) if arg is not type(None)]
        if args:
            # Use the first type for conversion (as a best effort)
            param_type = args[0]

    if param_type == 'int' or param_type == int:
        return int(value)
    elif param_type == 'float' or param_type == float:
        return float(value)
    elif param_type == 'bool' or param_type == bool:
        if type(value) is bool:
            return bool(value)
        return str(value).lower() in ('true', '1', 'y')
    elif param_type == date:
        if isinstance(value, date):
            return value
        return date.fromisoformat(value)
    elif param_type == datetime:
        if isinstance(value, datetime):
            return value
        return datetime.fromisoformat(value)
    else:
        return value  # Default is string
