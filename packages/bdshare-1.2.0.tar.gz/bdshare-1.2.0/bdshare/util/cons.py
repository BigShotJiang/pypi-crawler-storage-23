TOKEN_F_P = 'tk.csv'
TOKEN_ERR_MSG = 'Please set the token voucher code of bdshare. If not, please visit https://bdshare.xyz to register and apply.'

SESSION_F_P = 'sn.csv'
SESSION_ERR_MSG = 'Session could not intiated'
