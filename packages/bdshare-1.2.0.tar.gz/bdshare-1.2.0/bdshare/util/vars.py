# -*- coding:utf-8 -*-

DSE_URL = "https://dsebd.org/"
DSE_ALT_URL = "https://dsebd.com.bd/"

DSE_LSP_URL = "latest_share_price_scroll_l.php"
DSE_DEA_URL = "day_end_archive.php"
DSE_AGM_URL = "Company_AGM.htm"
DSE_LPE_URL = "latest_PE.php"
DSE_NEWS_URL = "old_news.php"
DSE_CLOSE_PRICE_URL = "dse_close_price_archive.php"
DSE_COMPANY_LIST_URL = "company_listing.php"
DSE_COMPANY_INFO_URL = "displayCompany.php"

DSE_MARKET_INFO_URL = "recent_market_information.php"
DSE_MARKET_INFO_MORE_URL = "recent_market_information_more.php"
DSE_MARKET_DEPTH_URL = "ajax/load-instrument.php"
DSE_MARKET_DEPTH_REFERER_URL = "mkt_depth_3.php"

DSEX_INDEX_VALUE = "dseX_share.php"

DSE_SECTOR_PERF_URL = "sector_performance.php"
DSE_TOP_GAINERS_URL = "top_gainers.php"

