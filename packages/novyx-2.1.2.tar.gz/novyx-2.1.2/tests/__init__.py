"""Tests for Novyx SDK."""
