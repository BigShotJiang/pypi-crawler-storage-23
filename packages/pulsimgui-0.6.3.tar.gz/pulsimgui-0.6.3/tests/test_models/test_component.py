"""Tests for Component model."""

from pulsimgui.models.component import (
    CONNECTION_DOMAIN_ANY,
    CURRENT_PROBE_OUTPUT_PIN_NAME,
    Component,
    ComponentType,
    Pin,
    THERMAL_PORT_PARAMETER,
    THERMAL_PORT_PIN_NAME,
    VOLTAGE_PROBE_OUTPUT_PIN_NAME,
    can_connect_measurement_pins,
    pin_connection_domain,
    set_scope_channel_count,
    set_thermal_port_enabled,
)


class TestPin:
    def test_create_pin(self):
        pin = Pin(index=0, name="A", x=10.0, y=20.0)
        assert pin.index == 0
        assert pin.name == "A"
        assert pin.x == 10.0
        assert pin.y == 20.0

    def test_pin_serialization(self):
        pin = Pin(index=1, name="B", x=-5.0, y=15.0)
        data = pin.to_dict()
        assert data["index"] == 1
        assert data["name"] == "B"

        restored = Pin.from_dict(data)
        assert restored.index == pin.index
        assert restored.name == pin.name
        assert restored.x == pin.x
        assert restored.y == pin.y


class TestComponent:
    def test_create_resistor(self):
        comp = Component(type=ComponentType.RESISTOR, name="R1")
        assert comp.type == ComponentType.RESISTOR
        assert comp.name == "R1"
        assert len(comp.pins) == 2
        assert "resistance" in comp.parameters

    def test_create_mosfet(self):
        comp = Component(type=ComponentType.MOSFET_N, name="M1")
        assert comp.type == ComponentType.MOSFET_N
        assert len(comp.pins) == 3
        assert "vth" in comp.parameters

    def test_default_parameters(self):
        resistor = Component(type=ComponentType.RESISTOR)
        assert resistor.parameters["resistance"] == 1000.0

        cap = Component(type=ComponentType.CAPACITOR)
        assert cap.parameters["capacitance"] == 1e-6

    def test_pin_position_no_rotation(self):
        comp = Component(type=ComponentType.RESISTOR, x=100, y=200)
        x, y = comp.get_pin_position(0)
        assert x == 100 + comp.pins[0].x
        assert y == 200 + comp.pins[0].y

    def test_pin_position_with_rotation(self):
        comp = Component(type=ComponentType.RESISTOR, x=0, y=0, rotation=90)
        # 90-degree rotation maps local (x, y) -> (-y, x).
        pin = comp.pins[0]
        expected_x = -pin.y
        expected_y = pin.x
        x, y = comp.get_pin_position(0)
        assert abs(x - expected_x) < 0.001
        assert abs(y - expected_y) < 0.001

    def test_serialization(self):
        comp = Component(
            type=ComponentType.CAPACITOR,
            name="C1",
            x=50,
            y=100,
            rotation=180,
        )
        comp.parameters["capacitance"] = 10e-6

        data = comp.to_dict()
        assert data["type"] == "CAPACITOR"
        assert data["name"] == "C1"
        assert data["x"] == 50
        assert data["rotation"] == 180

        restored = Component.from_dict(data)
        assert restored.type == comp.type
        assert restored.name == comp.name
        assert restored.x == comp.x
        assert restored.rotation == comp.rotation
        assert restored.parameters["capacitance"] == 10e-6

    def test_uuid_preserved(self):
        comp = Component(type=ComponentType.RESISTOR)
        original_id = comp.id
        data = comp.to_dict()
        restored = Component.from_dict(data)
        assert restored.id == original_id

    def test_control_blocks_have_defaults(self):
        pi = Component(type=ComponentType.PI_CONTROLLER)
        assert len(pi.pins) == 2
        assert "kp" in pi.parameters and "ki" in pi.parameters

        pid = Component(type=ComponentType.PID_CONTROLLER)
        assert "kd" in pid.parameters

        math_block = Component(type=ComponentType.MATH_BLOCK)
        assert math_block.parameters["operation"] == "sum"

        pwm = Component(type=ComponentType.PWM_GENERATOR)
        assert len(pwm.pins) == 2
        assert pwm.parameters["frequency"] == 10000.0

        gain = Component(type=ComponentType.GAIN)
        assert len(gain.pins) == 2
        assert gain.parameters["gain"] == 1.0

        summing = Component(type=ComponentType.SUM)
        assert len(summing.pins) == 3
        assert summing.parameters["input_count"] == 2

        subtractor = Component(type=ComponentType.SUBTRACTOR)
        assert len(subtractor.pins) == 3
        assert subtractor.parameters["signs"] == ["+", "-"]

        # PWM exposes DUTY_IN for closed-loop signal control.
        assert pwm.pins[0].name == "OUT"
        assert pwm.pins[1].name == "DUTY_IN"

    def test_thermal_port_default_is_disabled(self):
        resistor = Component(type=ComponentType.RESISTOR)
        assert resistor.parameters[THERMAL_PORT_PARAMETER] is False
        assert all(pin.name != THERMAL_PORT_PIN_NAME for pin in resistor.pins)

    def test_thermal_port_toggle_updates_pin_layout(self):
        resistor = Component(type=ComponentType.RESISTOR)
        assert len(resistor.pins) == 2

        set_thermal_port_enabled(resistor, True)
        assert resistor.parameters[THERMAL_PORT_PARAMETER] is True
        assert len(resistor.pins) == 3
        assert resistor.pins[-1].name == THERMAL_PORT_PIN_NAME

        set_thermal_port_enabled(resistor, False)
        assert resistor.parameters[THERMAL_PORT_PARAMETER] is False
        assert len(resistor.pins) == 2
        assert all(pin.name != THERMAL_PORT_PIN_NAME for pin in resistor.pins)

    def test_thermal_port_not_exposed_for_unsupported_components(self):
        pi = Component(type=ComponentType.PI_CONTROLLER)
        assert THERMAL_PORT_PARAMETER not in pi.parameters

    def test_legacy_mosfet_with_thermal_enabled_backfills_required_params(self):
        legacy = Component.from_dict(
            {
                "id": "6a7f6ecf-1f5c-4a17-89a1-53b8d57d1401",
                "type": "MOSFET_N",
                "name": "M1",
                "x": 0.0,
                "y": 0.0,
                "rotation": 0,
                "mirrored_h": False,
                "mirrored_v": False,
                "parameters": {
                    "vth": 2.0,
                    "kp": 0.1,
                    "thermal_enabled": True,
                },
                "pins": [],
            }
        )

        assert legacy.parameters["thermal_enabled"] is True
        assert legacy.parameters["thermal_rth"] > 0.0
        assert legacy.parameters["thermal_cth"] >= 0.0
        assert "thermal_temp_init" in legacy.parameters
        assert "thermal_temp_ref" in legacy.parameters
        assert "thermal_alpha" in legacy.parameters

    def test_legacy_mosfet_with_thermal_port_enabled_backfills_required_params(self):
        legacy = Component.from_dict(
            {
                "id": "3d2fd604-df76-4dd1-bc78-f0ac63ee4934",
                "type": "MOSFET_N",
                "name": "M1",
                "x": 0.0,
                "y": 0.0,
                "rotation": 0,
                "mirrored_h": False,
                "mirrored_v": False,
                "parameters": {
                    "vth": 2.0,
                    "kp": 0.1,
                    THERMAL_PORT_PARAMETER: True,
                },
                "pins": [],
            }
        )

        assert legacy.parameters[THERMAL_PORT_PARAMETER] is True
        assert legacy.parameters["thermal_enabled"] is True
        assert legacy.parameters["thermal_rth"] > 0.0
        assert legacy.parameters["thermal_cth"] >= 0.0

    def test_legacy_component_with_serialized_th_pin_keeps_thermal_port_enabled(self):
        legacy = Component.from_dict(
            {
                "id": "12a177d5-c6d2-4f54-9f31-fb5f0cc874cf",
                "type": "RESISTOR",
                "name": "R1",
                "x": 0.0,
                "y": 0.0,
                "rotation": 0,
                "mirrored_h": False,
                "mirrored_v": False,
                "parameters": {"resistance": 1000.0},
                "pins": [
                    {"index": 0, "name": "1", "x": -30.0, "y": 0.0},
                    {"index": 1, "name": "2", "x": 30.0, "y": 0.0},
                    {"index": 2, "name": THERMAL_PORT_PIN_NAME, "x": 0.0, "y": 20.0},
                ],
            }
        )

        assert legacy.parameters[THERMAL_PORT_PARAMETER] is True
        assert legacy.pins[-1].name == THERMAL_PORT_PIN_NAME

    def test_voltage_probe_has_scope_output_pin(self):
        probe = Component(type=ComponentType.VOLTAGE_PROBE)
        assert len(probe.pins) == 3
        assert probe.pins[2].name == VOLTAGE_PROBE_OUTPUT_PIN_NAME

    def test_current_probe_has_scope_output_pin(self):
        probe = Component(type=ComponentType.CURRENT_PROBE)
        assert len(probe.pins) == 3
        assert probe.pins[2].name == CURRENT_PROBE_OUTPUT_PIN_NAME

    def test_voltage_probe_gnd_has_single_input_and_scope_output(self):
        probe = Component(type=ComponentType.VOLTAGE_PROBE_GND)
        assert len(probe.pins) == 2
        assert probe.pins[0].name == "IN"
        assert probe.pins[1].name == VOLTAGE_PROBE_OUTPUT_PIN_NAME

    def test_goto_and_from_pins_use_any_domain(self):
        goto = Component(type=ComponentType.GOTO_LABEL, parameters={"net_label": "BUS_A"})
        from_label = Component(type=ComponentType.FROM_LABEL, parameters={"net_label": "BUS_A"})

        assert pin_connection_domain(goto, 0) == CONNECTION_DOMAIN_ANY
        assert pin_connection_domain(from_label, 0) == CONNECTION_DOMAIN_ANY

    def test_scope_connection_rules_for_electrical_probes(self):
        scope = Component(type=ComponentType.ELECTRICAL_SCOPE, name="ES1")
        v_probe = Component(type=ComponentType.VOLTAGE_PROBE, name="VP1")
        resistor = Component(type=ComponentType.RESISTOR, name="R1")

        assert can_connect_measurement_pins(scope, 0, v_probe, 2)
        assert not can_connect_measurement_pins(scope, 0, resistor, 0)

    def test_scope_connection_rules_for_thermal_outputs(self):
        scope = Component(type=ComponentType.THERMAL_SCOPE, name="TS1")
        resistor = Component(type=ComponentType.RESISTOR, name="R1")
        set_thermal_port_enabled(resistor, True)

        assert can_connect_measurement_pins(scope, 0, resistor, 2)
        assert not can_connect_measurement_pins(scope, 0, resistor, 1)

    def test_scope_channel_count_expands_pin_layout(self):
        scope = Component(type=ComponentType.ELECTRICAL_SCOPE, name="ES1")
        assert len(scope.pins) == 2

        set_scope_channel_count(scope, 6)
        assert scope.parameters["channel_count"] == 6
        assert len(scope.pins) == 6
        assert [pin.name for pin in scope.pins] == ["CH1", "CH2", "CH3", "CH4", "CH5", "CH6"]

    def test_scope_channel_count_allows_up_to_sixteen_channels(self):
        scope = Component(type=ComponentType.THERMAL_SCOPE, name="TS1")
        set_scope_channel_count(scope, 16)

        assert scope.parameters["channel_count"] == 16
        assert len(scope.pins) == 16
        assert scope.pins[0].name == "CH1"
        assert scope.pins[-1].name == "CH16"
