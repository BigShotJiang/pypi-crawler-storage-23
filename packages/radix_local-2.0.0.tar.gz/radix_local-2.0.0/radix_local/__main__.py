"""Entry point for ``python -m radix_local``."""

from __future__ import annotations

import os
import sys
import threading
import webbrowser

import uvicorn

from radix_local.config import ensure_local_defaults
from radix_local.app import create_local_app


def main() -> None:
    """Start the Radix Local server and optionally open the dashboard."""
    ensure_local_defaults()
    app = create_local_app()
    port = int(os.environ.get("RADIX_PORT", "8080"))

    def open_browser() -> None:
        import time

        time.sleep(1.5)
        webbrowser.open(f"http://localhost:{port}")

    if "--no-browser" not in sys.argv:
        threading.Thread(target=open_browser, daemon=True).start()

    host = os.environ.get("RADIX_HOST", "127.0.0.1")
    uvicorn.run(app, host=host, port=port, log_level="info")


if __name__ == "__main__":
    main()
