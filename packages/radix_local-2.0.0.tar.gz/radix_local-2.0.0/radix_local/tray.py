"""System tray integration (optional).

Requires the ``tray`` extra: ``pip install radix-local[tray]``.
Falls back gracefully when pystray / Pillow are not installed.
"""

from __future__ import annotations

import logging
import webbrowser
from typing import Optional

logger = logging.getLogger("radix_local.tray")

_tray_available = False
try:
    import pystray  # type: ignore[import-untyped]
    from PIL import Image  # type: ignore[import-untyped]

    _tray_available = True
except ImportError:
    pystray = None  # type: ignore[assignment]
    Image = None  # type: ignore[assignment,misc]


def is_available() -> bool:
    """Return True if the system tray dependencies are installed."""
    return _tray_available


def _create_icon() -> "pystray.Icon":  # type: ignore[name-defined]
    """Build a minimal tray icon."""
    # 16x16 green square as a placeholder icon
    image = Image.new("RGB", (16, 16), color=(0, 200, 100))

    def on_open(icon: object, item: object) -> None:
        webbrowser.open("http://localhost:8080")

    def on_quit(icon: "pystray.Icon", item: object) -> None:  # type: ignore[name-defined]
        icon.stop()

    menu = pystray.Menu(
        pystray.MenuItem("Open Dashboard", on_open, default=True),
        pystray.MenuItem("Quit", on_quit),
    )

    return pystray.Icon("radix-local", image, "Radix Local", menu)


def run_tray() -> Optional["pystray.Icon"]:  # type: ignore[name-defined]
    """Start the system tray icon in the background.

    Returns the Icon instance, or None if dependencies are missing.
    """
    if not _tray_available:
        logger.info("pystray not installed; skipping system tray")
        return None

    icon = _create_icon()
    icon.run_detached()
    logger.info("System tray icon started")
    return icon
