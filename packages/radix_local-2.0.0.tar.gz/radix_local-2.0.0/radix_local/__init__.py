"""Radix Local -- free GPU orchestration for your desktop."""

__version__ = "2.0.0"
