"""Application factory for Radix Local.

Wraps the edge agent's FastAPI app with:
- A local dashboard (static files served at ``/dashboard/``)
- A ``/v1/system`` endpoint exposing desktop environment info
- A root redirect from ``/`` to ``/dashboard/``
"""

from __future__ import annotations

import platform
import shutil
from pathlib import Path

from fastapi import FastAPI
from fastapi.responses import RedirectResponse
from fastapi.staticfiles import StaticFiles


def create_local_app() -> FastAPI:
    """Create the Radix Local app: edge agent + local dashboard."""
    from radix_edge.api.app import create_app

    app = create_app()

    # Mount the local dashboard static files
    static_dir = Path(__file__).parent / "static"
    if static_dir.exists():
        app.mount(
            "/dashboard",
            StaticFiles(directory=str(static_dir), html=True),
            name="dashboard",
        )

    @app.get("/", include_in_schema=False)
    async def root():
        return RedirectResponse(url="/dashboard/")

    @app.get("/v1/system", tags=["system"])
    async def system_info():
        return {
            "platform": platform.system(),
            "python": platform.python_version(),
            "docker_available": shutil.which("docker") is not None,
            "nvidia_smi_available": shutil.which("nvidia-smi") is not None,
            "mode": "local",
            "version": "0.1.0",
        }

    return app
