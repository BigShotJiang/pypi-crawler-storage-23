"""Desktop-friendly defaults for running the edge agent locally.

Call ``ensure_local_defaults()`` **before** the edge agent's ``EdgeConfig``
is first instantiated.  It writes safe environment-variable defaults so the
agent binds to localhost, disables upstream control-plane traffic, and uses
platform-appropriate storage paths.
"""

from __future__ import annotations

import os
import platform


def _data_dir() -> str:
    """Return a platform-aware data directory for Radix Local."""
    system = platform.system()
    if system == "Darwin":
        return os.path.expanduser("~/Library/Application Support/radix")
    elif system == "Windows":
        appdata = os.environ.get("APPDATA", os.path.expanduser("~\\AppData\\Roaming"))
        return os.path.join(appdata, "radix")
    else:
        return os.path.expanduser("~/.local/share/radix")


def ensure_local_defaults() -> None:
    """Set sane environment-variable defaults for desktop use.

    Only sets a variable if it is not already present in the environment, so
    explicit user overrides are always respected.
    """
    defaults = {
        # Security: bind to localhost only
        "RADIX_HOST": "127.0.0.1",
        # No cloud control-plane traffic
        "RADIX_UPSTREAM_ENABLED": "false",
        # Sensible log level
        "RADIX_LOG_LEVEL": "INFO",
        # Platform-aware database path
        "RADIX_DB_PATH": os.path.join(_data_dir(), "edge.db"),
    }

    for key, value in defaults.items():
        os.environ.setdefault(key, value)

    # Ensure data directory exists
    db_path = os.environ.get("RADIX_DB_PATH", "")
    if db_path and db_path != ":memory:":
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
