"""Typer CLI for Radix Local.

Commands
--------
start   Start the local GPU orchestration server.
open    Open the dashboard in your default browser.
doctor  Check prerequisites (Python, Docker, nvidia-smi).
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import webbrowser

import typer
from rich.console import Console
from rich.table import Table

app = typer.Typer(
    name="radix-local",
    help="Radix Local -- free GPU orchestration for your desktop.",
    add_completion=False,
)

console = Console()


@app.command()
def start(
    port: int = typer.Option(8080, "--port", "-p", help="Port to listen on."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Do not open browser on start."),
    no_tray: bool = typer.Option(False, "--no-tray", help="Do not show system tray icon."),
) -> None:
    """Start the Radix Local server."""
    import threading

    import uvicorn

    from radix_local.config import ensure_local_defaults
    from radix_local.app import create_local_app

    os.environ["RADIX_PORT"] = str(port)
    ensure_local_defaults()

    local_app = create_local_app()

    if not no_tray:
        from radix_local.tray import run_tray

        run_tray()

    if not no_browser:
        import time as _time

        def _open() -> None:
            _time.sleep(1.5)
            webbrowser.open(f"http://localhost:{port}")

        threading.Thread(target=_open, daemon=True).start()

    console.print(f"[bold green]Radix Local[/bold green] starting on http://localhost:{port}")
    uvicorn.run(local_app, host="127.0.0.1", port=port, log_level="info")


@app.command(name="open")
def open_dashboard(
    port: int = typer.Option(8080, "--port", "-p", help="Port the server is running on."),
) -> None:
    """Open the Radix Local dashboard in your browser."""
    url = f"http://localhost:{port}"
    console.print(f"Opening {url}")
    webbrowser.open(url)


@app.command()
def doctor() -> None:
    """Check prerequisites for running Radix Local."""
    table = Table(title="Radix Local -- Doctor", show_lines=True)
    table.add_column("Check", style="bold")
    table.add_column("Status")
    table.add_column("Details")

    # Python version
    py_ver = platform.python_version()
    py_ok = sys.version_info >= (3, 10)
    table.add_row(
        "Python >= 3.10",
        "[green]OK[/green]" if py_ok else "[red]FAIL[/red]",
        py_ver,
    )

    # Docker installed
    docker_path = shutil.which("docker")
    table.add_row(
        "Docker installed",
        "[green]OK[/green]" if docker_path else "[red]MISSING[/red]",
        docker_path or "https://docs.docker.com/get-docker/",
    )

    # Docker running
    docker_running = False
    if docker_path:
        try:
            result = subprocess.run(
                ["docker", "info"],
                capture_output=True,
                timeout=10,
            )
            docker_running = result.returncode == 0
        except Exception:
            pass
    table.add_row(
        "Docker daemon running",
        "[green]OK[/green]" if docker_running else "[yellow]NOT RUNNING[/yellow]",
        "Ready" if docker_running else "Start Docker Desktop or dockerd",
    )

    # nvidia-smi
    nvidia_smi = shutil.which("nvidia-smi")
    gpu_info = ""
    if nvidia_smi:
        try:
            result = subprocess.run(
                ["nvidia-smi", "--query-gpu=name", "--format=csv,noheader"],
                capture_output=True,
                text=True,
                timeout=10,
            )
            if result.returncode == 0:
                gpu_info = result.stdout.strip()
        except Exception:
            pass
    table.add_row(
        "NVIDIA GPU (nvidia-smi)",
        "[green]OK[/green]" if nvidia_smi else "[yellow]NOT FOUND[/yellow]",
        gpu_info or ("CPU-only mode" if not nvidia_smi else "nvidia-smi found but query failed"),
    )

    console.print(table)

    all_ok = py_ok and bool(docker_path) and docker_running
    if all_ok:
        console.print("\n[bold green]All checks passed.[/bold green] Run [bold]radix-local start[/bold] to begin.")
    else:
        console.print("\n[yellow]Some checks failed.[/yellow] GPU is optional; Docker is required for job execution.")


if __name__ == "__main__":
    app()
