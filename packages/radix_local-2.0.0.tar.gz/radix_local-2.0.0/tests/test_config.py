"""Tests for Radix Local configuration defaults."""

from __future__ import annotations

import os
import platform
from unittest import mock

import pytest

from radix_local.config import ensure_local_defaults, _data_dir


class TestDataDir:
    """Tests for _data_dir() platform detection."""

    def test_linux_path(self):
        with mock.patch("radix_local.config.platform.system", return_value="Linux"):
            path = _data_dir()
            assert ".local/share/radix" in path

    def test_darwin_path(self):
        with mock.patch("radix_local.config.platform.system", return_value="Darwin"):
            path = _data_dir()
            assert "Library/Application Support/radix" in path

    def test_windows_path(self):
        with mock.patch("radix_local.config.platform.system", return_value="Windows"):
            with mock.patch.dict(os.environ, {"APPDATA": "C:\\Users\\test\\AppData\\Roaming"}):
                path = _data_dir()
                assert "radix" in path


class TestEnsureLocalDefaults:
    """Tests for ensure_local_defaults()."""

    def _clear_radix_env(self):
        """Remove RADIX_ env vars that ensure_local_defaults would set."""
        for key in ("RADIX_HOST", "RADIX_UPSTREAM_ENABLED", "RADIX_LOG_LEVEL", "RADIX_DB_PATH"):
            os.environ.pop(key, None)

    def test_sets_host_to_localhost(self):
        self._clear_radix_env()
        ensure_local_defaults()
        assert os.environ.get("RADIX_HOST") == "127.0.0.1"

    def test_disables_upstream(self):
        self._clear_radix_env()
        ensure_local_defaults()
        assert os.environ.get("RADIX_UPSTREAM_ENABLED") == "false"

    def test_sets_log_level(self):
        self._clear_radix_env()
        ensure_local_defaults()
        assert os.environ.get("RADIX_LOG_LEVEL") == "INFO"

    def test_sets_db_path(self):
        self._clear_radix_env()
        ensure_local_defaults()
        db_path = os.environ.get("RADIX_DB_PATH", "")
        assert "radix" in db_path
        assert db_path.endswith("edge.db")

    def test_respects_existing_env(self):
        """Explicit user overrides must not be clobbered."""
        os.environ["RADIX_HOST"] = "0.0.0.0"
        os.environ["RADIX_UPSTREAM_ENABLED"] = "true"
        ensure_local_defaults()
        assert os.environ.get("RADIX_HOST") == "0.0.0.0"
        assert os.environ.get("RADIX_UPSTREAM_ENABLED") == "true"

    def test_idempotent(self):
        """Calling twice must not change results."""
        self._clear_radix_env()
        ensure_local_defaults()
        host1 = os.environ.get("RADIX_HOST")
        ensure_local_defaults()
        host2 = os.environ.get("RADIX_HOST")
        assert host1 == host2
