"""Tests for the Radix Local application factory."""

from __future__ import annotations

import pytest
import pytest_asyncio
from fastapi import FastAPI
from httpx import ASGITransport, AsyncClient

from radix_local.app import create_local_app


@pytest.fixture
def local_app():
    """Create a Radix Local FastAPI app for testing."""
    return create_local_app()


@pytest_asyncio.fixture
async def client(local_app):
    """Async HTTP client wired to the local app."""
    transport = ASGITransport(app=local_app)
    async with AsyncClient(transport=transport, base_url="http://testserver") as ac:
        yield ac


class TestCreateLocalApp:
    """Tests for the create_local_app() factory."""

    def test_returns_fastapi_instance(self, local_app):
        assert isinstance(local_app, FastAPI)

    def test_app_has_title(self, local_app):
        # The underlying edge app sets a title
        assert local_app.title is not None


class TestSystemEndpoint:
    """Tests for GET /v1/system."""

    @pytest.mark.asyncio
    async def test_system_info_returns_200(self, client):
        resp = await client.get("/v1/system")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_system_info_fields(self, client):
        resp = await client.get("/v1/system")
        data = resp.json()

        assert "platform" in data
        assert "python" in data
        assert "docker_available" in data
        assert "nvidia_smi_available" in data
        assert data["mode"] == "local"
        assert data["version"] == "0.1.0"

    @pytest.mark.asyncio
    async def test_system_docker_is_bool(self, client):
        data = (await client.get("/v1/system")).json()
        assert isinstance(data["docker_available"], bool)
        assert isinstance(data["nvidia_smi_available"], bool)


class TestRootRedirect:
    """Tests for GET / -> /dashboard/."""

    @pytest.mark.asyncio
    async def test_root_redirects_to_dashboard(self, client):
        resp = await client.get("/", follow_redirects=False)
        assert resp.status_code in (301, 302, 307)
        assert "/dashboard/" in resp.headers.get("location", "")


class TestStaticFiles:
    """Tests that the static dashboard is mounted."""

    @pytest.mark.asyncio
    async def test_dashboard_index(self, client):
        resp = await client.get("/dashboard/")
        assert resp.status_code == 200
        assert "Radix Local" in resp.text

    @pytest.mark.asyncio
    async def test_dashboard_css(self, client):
        resp = await client.get("/dashboard/style.css")
        assert resp.status_code == 200
        assert "bg-primary" in resp.text

    @pytest.mark.asyncio
    async def test_dashboard_js(self, client):
        resp = await client.get("/dashboard/app.js")
        assert resp.status_code == 200
        assert "API_BASE" in resp.text


class TestHealthEndpoints:
    """Ensure the inherited edge-agent health endpoints still work."""

    @pytest.mark.asyncio
    async def test_healthz(self, client):
        resp = await client.get("/healthz")
        assert resp.status_code == 200
        assert resp.json()["status"] == "healthy"
