"""
DataJunction MCP (Model Context Protocol) Server

This module provides an MCP server for AI agents to interact with the
DataJunction semantic layer.
"""
