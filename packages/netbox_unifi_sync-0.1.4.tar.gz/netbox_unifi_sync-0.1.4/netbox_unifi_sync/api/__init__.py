"""API module for netbox_unifi_sync."""
