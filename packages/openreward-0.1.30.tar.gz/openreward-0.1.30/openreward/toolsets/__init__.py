"""Pre-built toolsets for common tasks."""

from .excel import ExcelToolset
from .powerpoint import PowerPointToolset
from .word import WordToolset
from .pdf import PDFToolset

__all__ = [
    "ExcelToolset",
    "PowerPointToolset",
    "WordToolset",
    "PDFToolset",
]
