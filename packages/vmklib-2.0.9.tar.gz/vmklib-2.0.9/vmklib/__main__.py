# =====================================
# generator=datazen
# version=3.2.3
# hash=e3b25ef71e1382c4879938c082dd3893
# =====================================
"""
vmklib - Package's default entry-point.
"""

# built-in
import sys

# internal
from vmklib.entry import main

if __name__ == "__main__":
    sys.exit(main(sys.argv))
