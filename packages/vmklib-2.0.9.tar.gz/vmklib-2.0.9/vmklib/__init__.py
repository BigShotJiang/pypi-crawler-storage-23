# =====================================
# generator=datazen
# version=3.2.3
# hash=3e5670dce4e538ba6b03f671d4aad932
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Simplify project workflows by standardizing use of GNU Make."
PKG_NAME = "vmklib"
VERSION = "2.0.9"
