from dataclasses import dataclass, field
from typing import Any, Union, Optional, Dict
import time


@dataclass
class Score:
    """
    Result from scoring a run.
    
    Returned by Scorer.score() method
    """

    # The actual score value
    value: Union[float, int, bool, str]

    # Optional explanation
    reason: Optional[str] = None

    # Aditional context
    metadata: Dict[str, Any] = field(default_factory=dict)

    # When the score was computed
    timestamp: float = field(default_factory=time.time)

