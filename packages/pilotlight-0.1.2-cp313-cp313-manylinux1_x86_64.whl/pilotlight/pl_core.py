import pilotlight.pilotlight as internal

# PL_KEY CONSTANTS
PL_KEY_P=internal.PL_KEY_P


class plIOI:

    def new_frame(**kwargs) -> None:
        return internal.pl_core_plIOI_new_frame(**kwargs)

    def is_key_pressed(key : int, **kwargs) -> None:
        return internal.plIOI_is_key_pressed(key, **kwargs)

class plWindowI:

    def create(**kwargs) -> None:
        return internal.plWindowI_create(**kwargs)

