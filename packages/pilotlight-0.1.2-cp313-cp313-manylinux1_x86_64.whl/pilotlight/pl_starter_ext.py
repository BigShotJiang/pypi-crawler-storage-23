from typing import List, Any, Callable, Union, Tuple
import pilotlight.pilotlight as internal


class plStarterI:

    def begin_frame(**kwargs) -> None:
        return internal.plStarterI_begin_frame(**kwargs)

    def initialize(window : Any, **kwargs) -> None:
        return internal.plStarterI_initialize(window, **kwargs)

    def finalize(**kwargs) -> None:
        return internal.plStarterI_finalize(**kwargs)

    def resize(**kwargs) -> None:
        return internal.plStarterI_resize(**kwargs)

    def end_frame(**kwargs) -> None:
        return internal.plStarterI_end_frame(**kwargs)

    def get_foreground_layer(**kwargs) -> None:
        return internal.plStarterI_get_foreground_layer(**kwargs)

    def get_background_layer(**kwargs) -> None:
        return internal.plStarterI_get_background_layer(**kwargs)

