"""Core functionality for vector database operations."""
