# CryptoSignals MCP Server

<!-- mcp-name: io.github.agenthustler/crypto-signals-mcp -->

[![PyPI](https://img.shields.io/pypi/v/crypto-signals-mcp)](https://pypi.org/project/crypto-signals-mcp/)
[![Awesome MCP Servers](https://img.shields.io/badge/awesome--mcp--servers-listed-blue)](https://github.com/punkpeye/awesome-mcp-servers)

MCP server for real-time crypto volume anomaly detection across 50+ tokens. Detects unusual trading activity, whale movements, and pump signals.

## Features

- **Volume anomaly detection** — Identifies tokens with unusual volume-to-market-cap ratios
- **50+ tokens monitored** — Continuous scanning across major cryptocurrencies
- **Anomaly classification** — Signals rated LOW, MODERATE, HIGH, or CRITICAL
- **High-confidence alerts** — Filter for only the most actionable signals
- **Live data** — Real-time prices, 24h changes, volume, and market cap

## Tools

| Tool | Description |
|------|-------------|
| `scan_all_tokens` | Scan all 50+ tokens for volume anomalies |
| `analyze_token` | Detailed analysis for a specific token (BTC, ETH, SOL, etc.) |
| `get_anomaly_alerts` | High-confidence alerts only (vol_mcap ratio above 5.0) |

## Quick Start

### Install

```bash
pip install crypto-signals-mcp
```

### Run

```bash
uvx crypto-signals-mcp
```

Or with pip:

```bash
fastmcp run server.py
```

### Configure in Claude Desktop

Add to your `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "crypto-signals": {
      "command": "uvx",
      "args": ["crypto-signals-mcp"]
    }
  }
}
```

## Example Usage

Ask your AI assistant:
- "Scan all crypto tokens for volume anomalies"
- "Analyze Bitcoin for unusual trading activity"
- "Show me high-confidence crypto alerts"
- "Which tokens have whale movement signals right now?"

## How It Works

The server connects to CoinGecko's free API and monitors trading volume across 50+ cryptocurrencies. It calculates volume-to-market-cap ratios to identify statistically unusual trading activity — often an early indicator of price movement, whale accumulation, or pump activity.

## Also Available On

- [PyPI](https://pypi.org/project/crypto-signals-mcp/) — `pip install crypto-signals-mcp`
- [Apify Store](https://apify.com/cryptosignals/crypto-signals) — Pay-per-scan serverless Actor
- [MCPize](https://mcpize.com/mcp/crypto-signals) — Hosted MCP gateway
- [Glama.ai](https://glama.ai/mcp/servers/@MarcinDudekDev/crypto-signals-mcp) — MCP directory
- [awesome-mcp-servers](https://github.com/punkpeye/awesome-mcp-servers) — 82K+ stars directory

## License

MIT
