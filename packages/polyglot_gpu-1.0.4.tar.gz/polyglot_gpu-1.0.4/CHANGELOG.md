# Changelog

## 1.0.4 (2026-03-06)

- Starlight handbook (7 pages) with Pagefind search
- Starlight i18n: handbook index translated to 7 languages via polyglot-mcp
- README updated with Production-hardened feature line + Handbook badge
- All translated READMEs retranslated to include v1.0.3 content
- Landing page CTA now links to handbook

## 1.0.3 (2026-03-06)

- httpx connection pooling in OllamaClient (reuse connections instead of per-request)
- Semaphore now supports `async with` context manager pattern
- Semaphore `_active` counter protected by asyncio.Lock
- Cache path traversal check uses `relative_to()` instead of string comparison
- Structured logging replaces `print(stderr)` throughout ollama.py
- Specific exception types instead of bare `except Exception`
- Streaming pull timeout protection via per-chunk read timeout
- Deduplicated OR_PATTERNS (markdown.py now imports from polish.py)
- Test suite expanded from 55 to 100 tests (errors, semaphore, translate, translate_all, ollama)

## 1.0.2 (2026-03-06)

- Renamed PyPI distribution from `py-polyglot` to `polyglot-gpu` (import name `pypolyglot` unchanged)
- CLI entry point renamed to `polyglot-gpu`

## 1.0.1 (2026-03-06)

- Shipcheck compliance: verify script, dependency audit, dependabot
- Landing page via @mcptoolshop/site-theme
- Translated READMEs (7 languages)

## 1.0.0 (2026-03-06)

- Initial release — Python port of polyglot-mcp
- 57 languages via TranslateGemma + Ollama
- Dual-use: Python library (`pip install polyglot-gpu`) + MCP server
- Core translation with chunking, batching, retry, and validation
- Markdown-aware translation preserving code blocks, tables, HTML
- Multi-language orchestrator with concurrent translation
- Segment-level caching with fuzzy matching (translation memory)
- Software glossary for accurate technical translations
- Auto-start Ollama and auto-pull models
- GPU-safe concurrency control via semaphore
