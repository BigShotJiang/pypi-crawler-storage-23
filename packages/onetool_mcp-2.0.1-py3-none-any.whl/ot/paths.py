"""Path resolution for OneTool directories.

OneTool uses an explicit config-file model:
- The "ot dir" is ``config_path.parent`` — all relative paths resolve there.
- There is no global ``~/.onetool/`` directory or environment-variable fallback.
- Pass ``--config <file>`` to every command to specify the config location.

Each .onetool/ directory uses subdirectories to organise files by purpose:
- logs/ — Application log files
- stats/ — Statistics data (stats.jsonl)
- tools/ — Custom tool packs

Directories are created lazily on first use via ``ensure_ot_dir()``.
Templates in ot.config.global_templates are copied to the ot dir on init.
"""

from __future__ import annotations

import os
import sys
from importlib import resources
from pathlib import Path

# Subdirectory names within .onetool/
LOGS_SUBDIR = "logs"
STATS_SUBDIR = "stats"
TOOLS_SUBDIR = "tools"

# Package containing global templates (copied to ot dir on init)
GLOBAL_TEMPLATES_PACKAGE = "ot.config.global_templates"


def _resolve_package_dir(package_name: str, description: str) -> Path:
    """Resolve a package to a filesystem directory path.

    Uses importlib.resources to access package data. Works correctly across:
    - Regular pip/uv install (wheel)
    - Editable install (uv tool install -e .)
    - Development mode

    Args:
        package_name: Dotted package name (e.g., "ot.config.global_templates")
        description: Human-readable description for error messages

    Returns:
        Path to package directory (read-only package data)

    Raises:
        FileNotFoundError: If package is not found or not on filesystem
    """
    try:
        files = resources.files(package_name)
    except (ModuleNotFoundError, TypeError) as e:
        raise FileNotFoundError(
            f"{description} package not found: {package_name}. "
            "Ensure onetool is properly installed."
        ) from e

    # Try multiple approaches to get a filesystem path from the Traversable.
    # importlib.resources returns different types depending on install mode:
    # - Regular install: pathlib.Path-like object
    # - Editable install: MultiplexedPath (internal type)
    # - Zipped package: ZipPath (would need extraction)

    # Approach 1: Direct _path attribute (MultiplexedPath in editable installs)
    if hasattr(files, "_path"):
        path = Path(files._path)
        if path.is_dir():
            return path

    # Approach 2: String conversion (works for regular Path-like objects)
    path_str = str(files)

    # Skip if it looks like a repr() output rather than a path
    if not path_str.startswith(("MultiplexedPath(", "<", "{")):
        path = Path(path_str)
        if path.is_dir():
            return path

    # Approach 3: Extract path from MultiplexedPath repr as last resort
    if path_str.startswith("MultiplexedPath("):
        import re

        match = re.search(r"'([^']+)'", path_str)
        if match:
            path = Path(match.group(1))
            if path.is_dir():
                return path

    # If we get here, the package exists but isn't on a real filesystem
    # (e.g., inside a zipfile). This is not supported.
    raise FileNotFoundError(
        f"{description} directory exists but is not on filesystem: {path_str}. "
        "OneTool requires installation from an unpacked wheel, not a zipfile."
    )


def get_global_templates_dir() -> Path:
    """Get the global templates directory path.

    Global templates are user-facing config files with commented examples,
    copied to the ot dir on init. These provide documentation and examples
    for configuration. Also contains subdirectories like diagram-templates/
    and tool_templates/ for tool-specific resources.

    Returns:
        Path to global templates directory (read-only package data)

    Raises:
        FileNotFoundError: If global templates package is not found or not on filesystem
    """
    return _resolve_package_dir(GLOBAL_TEMPLATES_PACKAGE, "Global templates")


def get_effective_cwd() -> Path:
    """Get the effective working directory.

    Returns OT_CWD if set, else Path.cwd(). This provides a single point
    of control for working directory resolution across all CLIs.

    Returns:
        Resolved Path for working directory
    """
    env_cwd = os.getenv("OT_CWD")
    if env_cwd:
        return Path(env_cwd).resolve()
    return Path.cwd()


def get_template_files() -> list[tuple[Path, str]]:
    """Get list of template files that would be copied to ot dir on init.

    Returns:
        List of (source_path, dest_name) tuples for each template file.
        dest_name has -template suffix stripped (e.g., secrets-template.yaml -> secrets.yaml)
    """
    try:
        templates_dir = get_global_templates_dir()
        result = []
        for config_file in sorted(templates_dir.glob("*.yaml")) + sorted(templates_dir.glob("*.md")):
            dest_name = config_file.name.replace("-template.yaml", ".yaml")
            result.append((config_file, dest_name))
        return result
    except FileNotFoundError:
        return []


def create_backup(file_path: Path) -> Path:
    """Create a numbered backup of a file.

    Creates backups as file.bak, file.bak.1, file.bak.2, etc.

    Args:
        file_path: Path to the file to backup

    Returns:
        Path to the created backup file
    """
    backup_base = file_path.with_suffix(file_path.suffix + ".bak")

    # Find the next available backup number
    if not backup_base.exists():
        backup_path = backup_base
    else:
        n = 1
        while True:
            backup_path = backup_base.with_suffix(f".bak.{n}")
            if not backup_path.exists():
                break
            n += 1

    import shutil

    shutil.copy2(file_path, backup_path)
    return backup_path


def ensure_ot_dir(config_path: Path, quiet: bool = False, force: bool = False) -> Path:
    """Ensure the OneTool directory exists at config_path.parent.

    Creates config_path.parent with subdirectories (logs/, stats/, tools/)
    and copies template config files from global_templates into it.
    Templates are user-facing files with commented examples for customization.

    Args:
        config_path: Path to the onetool.yaml config file (directory is config_path.parent)
        quiet: Suppress creation messages
        force: Overwrite existing files (for reset functionality)

    Returns:
        Path to ot dir (config_path.parent)
    """
    import shutil

    ot_dir = config_path.parent

    # If directory exists and not forcing, return early
    if ot_dir.exists() and not force:
        return ot_dir

    import stat

    # Create directory structure with subdirectories
    ot_dir.mkdir(parents=True, exist_ok=True)
    subdirs = [LOGS_SUBDIR, STATS_SUBDIR, TOOLS_SUBDIR]
    for subdir in subdirs:
        (ot_dir / subdir).mkdir(exist_ok=True)

    # Copy template config files flat into ot dir
    # YAML and Markdown files are copied from global_templates/
    # Files named *-template.yaml are copied without the -template suffix
    copied_items: list[str] = []
    try:
        templates_dir = get_global_templates_dir()
        for config_file in sorted(templates_dir.glob("*.yaml")) + sorted(templates_dir.glob("*.md")):
            # Strip -template suffix if present (e.g., secrets-template.yaml -> secrets.yaml)
            dest_name = config_file.name.replace("-template.yaml", ".yaml")
            dest = ot_dir / dest_name
            # Copy if doesn't exist, or if forcing
            if not dest.exists() or force:
                shutil.copy(config_file, dest)
                # Set secrets.yaml to 0600 (owner read/write only)
                if dest_name == "secrets.yaml":
                    dest.chmod(stat.S_IRUSR | stat.S_IWUSR)
                copied_items.append(dest_name)

        # Copy resource subdirectories (e.g., diagram-templates/)
        for template_subdir in templates_dir.iterdir():
            if template_subdir.is_dir() and not template_subdir.name.startswith("_"):
                if template_subdir.name == "tool_templates":
                    continue
                dest_subdir = ot_dir / template_subdir.name
                if not dest_subdir.exists() or force:
                    if dest_subdir.exists():
                        shutil.rmtree(dest_subdir)
                    shutil.copytree(template_subdir, dest_subdir)
                    copied_items.append(f"{template_subdir.name}/")
    except FileNotFoundError:
        # Global templates not available (dev environment without package install)
        pass

    if not quiet:
        # Use stderr to avoid interfering with MCP stdout
        action = "Resetting" if force else "Creating"
        print(f"{action} {ot_dir}/", file=sys.stderr)
        for subdir in subdirs:
            print(f"  ✓ {subdir}/", file=sys.stderr)
        for item_name in copied_items:
            print(f"  ✓ {item_name}", file=sys.stderr)

    return ot_dir


def get_logs_dir(base_dir: Path) -> Path:
    """Get the logs directory path within an ot dir.

    Args:
        base_dir: Base ot directory (config_path.parent)

    Returns:
        Path to logs/ subdirectory
    """
    return base_dir / LOGS_SUBDIR


def get_stats_dir(base_dir: Path) -> Path:
    """Get the stats directory path within an ot dir.

    Args:
        base_dir: Base ot directory (config_path.parent)

    Returns:
        Path to stats/ subdirectory
    """
    return base_dir / STATS_SUBDIR


def expand_path(path: str) -> Path:
    """Expand ~ in a path.

    Only expands ~ to home directory. Does NOT expand ${VAR} patterns.
    Use ~/path instead of ${HOME}/path.

    Args:
        path: Path string potentially containing ~

    Returns:
        Expanded absolute Path
    """
    return Path(path).expanduser().resolve()


def resolve_cwd_path(path: str) -> Path:
    """Resolve a path relative to the project working directory (OT_CWD).

    Use this for reading/writing files in the user's project.
    This is the internal version for in-process tools - uses OT_CWD env var directly.

    Args:
        path: Path string (relative, absolute, or with ~)

    Returns:
        Resolved absolute Path

    Behaviour:
        - ~ paths: expanded to home directory
        - Absolute paths: returned unchanged
        - Relative paths: resolved relative to get_effective_cwd()

    Example:
        >>> resolve_cwd_path("data/file.txt")
        PosixPath('/project/data/file.txt')
        >>> resolve_cwd_path("/tmp/output.txt")
        PosixPath('/tmp/output.txt')
        >>> resolve_cwd_path("~/output.txt")
        PosixPath('/home/user/output.txt')
    """
    p = Path(path).expanduser()
    if p.is_absolute():
        return p.resolve()
    return (get_effective_cwd() / p).resolve()
