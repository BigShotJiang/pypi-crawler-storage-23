"""OneTool benchmark harness CLI package.

Entry point for the `bench` command used for benchmarking
agent + MCP configurations.
"""
