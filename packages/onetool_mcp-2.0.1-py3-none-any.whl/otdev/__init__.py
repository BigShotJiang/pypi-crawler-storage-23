"""onetool-dev: Developer tools MCP server.

Developer tools MCP server for database operations, code search, web fetching,
package information, documentation search, diagram rendering, and browser automation.
"""

from __future__ import annotations

__version__ = "1.0.0"
__package_name__ = "onetool-dev"

__all__ = ["__package_name__", "__version__"]
