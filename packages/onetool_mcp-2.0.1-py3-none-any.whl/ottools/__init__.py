"""OneTool built-in tools.

Tools are auto-discovered from Python files in this directory.
"""
