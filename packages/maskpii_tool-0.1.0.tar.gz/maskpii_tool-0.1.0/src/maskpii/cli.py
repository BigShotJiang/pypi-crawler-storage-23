
import argparse
from .core import mask_text

def main():
    parser = argparse.ArgumentParser(prog="maskpii", description="Detect and mask PII in text.")
    parser.add_argument("text", help="Text to mask")
    parser.add_argument("--token", default="[REDACTED]", help="Replacement token")
    parser.add_argument("--no-label", action="store_true", help="Disable labels like [REDACTED:EMAIL]")
    parser.add_argument("--mask-addressish", action="store_true", help="Enable address-ish masking (may over-mask)")
    args = parser.parse_args()

    result = mask_text(
        args.text,
        token=args.token,
        mask_addressish=args.mask_addressish,
        label=(not args.no_label),
    )
    print(result)