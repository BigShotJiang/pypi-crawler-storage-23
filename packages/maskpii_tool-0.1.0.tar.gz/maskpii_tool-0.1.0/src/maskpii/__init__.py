from .core import mask_text, mask_dict

__all__ = ["mask_text", "mask_dict"]
__version__ = "0.1.0"

