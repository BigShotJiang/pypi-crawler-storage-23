
import re

EMAIL_RE = re.compile(r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b")

# Phone (simple): +91 optional, separators allowed, 10 digits typical
PHONE_RE = re.compile(r"\b(?:\+?91[\s-]?)?[6-9]\d{9}\b")

# Aadhaar: 12 digits with optional spaces like 1234 5678 9012
AADHAAR_RE = re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")

# PAN: 5 letters + 4 digits + 1 letter
PAN_RE = re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b")

# IPv4
IPV4_RE = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")

# Credit card candidate: 13 to 19 digits with spaces/hyphens allowed
CC_CANDIDATE_RE = re.compile(r"\b(?:\d[ -]*?){13,19}\b")

# Address-ish heuristic (optional, may over-mask)
ADDRESSISH_RE = re.compile(
    r"\b(?:house|flat|plot|road|rd|street|st|lane|ln|near|beside|behind|"
    r"nagar|colony|phase|sector|block|apt|apartment)\b",
    re.IGNORECASE,
)