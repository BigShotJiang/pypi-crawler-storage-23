
# maskpii

Detect and mask PII (email, phone, Aadhaar, PAN, credit card, IPv4) in logs/text.

## Install
```bash
pip install maskpii