
from maskpii import mask_text

def test_email_mask():
    t = "Email me at abc.test@gmail.com"
    out = mask_text(t)
    assert "gmail.com" not in out
    assert "REDACTED" in out

def test_pan_mask():
    t = "PAN is ABCDE1234F"
    out = mask_text(t)
    assert "ABCDE1234F" not in out

def test_aadhaar_mask():
    t = "aadhaar 1234 5678 9012"
    out = mask_text(t)
    assert "1234 5678 9012" not in out

def test_ipv4_mask():
    t = "server 192.168.1.10 down"
    out = mask_text(t)
    assert "192.168.1.10" not in out

def test_phone_mask():
    t = "call 9876543210 now"
    out = mask_text(t)
    assert "9876543210" not in out