from __future__ import annotations

import threading
import time
import uuid
from typing import Dict, List

import requests


class TelemetryBatcher:
    def __init__(self, ingestion_base_url: str, api_key: str, max_batch_size: int, flush_interval_ms: int, timeout_ms: int):
        self._ingestion_base_url = ingestion_base_url.rstrip("/")
        self._api_key = api_key
        self._max_batch_size = max_batch_size
        self._flush_interval = flush_interval_ms / 1000.0
        self._timeout = timeout_ms / 1000.0
        self._queue: List[Dict] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def enqueue(self, event: Dict) -> None:
        with self._lock:
            self._queue.append(event)
            if len(self._queue) >= self._max_batch_size:
                batch = self._drain_locked()
            else:
                batch = []

        if batch:
            self._send(batch)

    def _drain_locked(self) -> List[Dict]:
        batch = self._queue[: self._max_batch_size]
        self._queue = self._queue[self._max_batch_size :]
        return batch

    def _loop(self) -> None:
        while not self._stop.is_set():
            time.sleep(self._flush_interval)
            self.flush()

    def flush(self) -> None:
        with self._lock:
            if not self._queue:
                return
            batch = self._drain_locked()

        self._send(batch)

    def _send(self, batch: List[Dict]) -> None:
        try:
            response = requests.post(
                f"{self._ingestion_base_url}/v1/telemetry/events",
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "X-Idempotency-Key": str(uuid.uuid4()),
                },
                json={"events": batch},
                timeout=self._timeout,
            )
            if response.status_code >= 400:
                with self._lock:
                    self._queue = batch + self._queue
        except Exception:
            with self._lock:
                self._queue = batch + self._queue

    def shutdown(self) -> None:
        self._stop.set()
        self._thread.join(timeout=1.0)
        self.flush()
