from __future__ import annotations

from dataclasses import asdict
from typing import Dict

import requests

from .types import CostOptimizeRequest, CostOptimizeResponse, McpServersResponse, ModelRouteRequest, ModelRouteResponse, RouteRequest


class RouteClient:
    def __init__(self, recommendation_base_url: str, api_key: str, tenant_id: str, timeout_ms: int):
        self._base_url = recommendation_base_url.rstrip("/")
        self._api_key = api_key
        self._tenant_id = tenant_id
        self._timeout = timeout_ms / 1000.0

    def get_routes(self, request: RouteRequest) -> Dict:
        payload = {
            "tenant_id": self._tenant_id,
            "task_category": request.task_category,
            "candidate_tools": request.candidate_tools,
            "action_class": request.action_class,
            "limit": request.limit,
            "context": asdict(request.context) if request.context else {},
        }

        response = requests.post(
            f"{self._base_url}/v1/routes/recommend",
            headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=self._timeout,
        )
        response.raise_for_status()
        return response.json()

    def log_decision(self, event: Dict) -> None:
        response = requests.post(
            f"{self._base_url}/v1/routes/decision-log",
            headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"},
            json={"event": event},
            timeout=self._timeout,
        )
        response.raise_for_status()

    def get_model_routes(self, request: ModelRouteRequest) -> ModelRouteResponse:
        response = requests.post(
            f"{self._base_url}/v1/models/recommend",
            headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"},
            json={
                "task_category": request.task_category,
                "candidate_models": request.candidate_models,
            },
            timeout=self._timeout,
        )
        response.raise_for_status()
        data = response.json()
        from .types import ModelRouteEntry
        models = [ModelRouteEntry(**m) for m in data.get("models", [])]
        return ModelRouteResponse(task_category=data["task_category"], models=models)

    def get_cost_optimized_path(self, request: CostOptimizeRequest) -> CostOptimizeResponse:
        payload: Dict = {
            "task_category": request.task_category,
            "candidate_tools": request.candidate_tools,
            "quality_floor": request.quality_floor,
        }
        if request.budget_tokens is not None:
            payload["budget_tokens"] = request.budget_tokens

        response = requests.post(
            f"{self._base_url}/v1/cost/optimize",
            headers={"Authorization": f"Bearer {self._api_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=self._timeout,
        )
        response.raise_for_status()
        data = response.json()
        from .types import CostOptimizeOptimalPath, CostOptimizePath
        optimal = None
        if data.get("optimal_path"):
            optimal = CostOptimizeOptimalPath(**data["optimal_path"])
        all_paths = [CostOptimizePath(**p) for p in data.get("all_paths", [])]
        return CostOptimizeResponse(
            task_category=data["task_category"],
            quality_floor=data["quality_floor"],
            optimal_path=optimal,
            all_paths=all_paths,
            message=data.get("message"),
        )

    def get_mcp_servers(self, task_category: str | None = None) -> McpServersResponse:
        url = f"{self._base_url}/v1/mcp-servers"
        if task_category:
            url += f"?task_category={task_category}"
        response = requests.get(
            url,
            headers={"Authorization": f"Bearer {self._api_key}"},
            timeout=self._timeout,
        )
        response.raise_for_status()
        data = response.json()
        from .types import McpServerFailureWindow, McpServerIntelligence, McpServerRegion
        servers = []
        for s in data.get("servers", []):
            regions = []
            for r in s.get("regions", []):
                failure_windows = [McpServerFailureWindow(**fw) for fw in r.get("failure_windows", [])]
                regions.append(McpServerRegion(
                    region=r["region"],
                    country_code=r["country_code"],
                    success_rate=r["success_rate"],
                    avg_latency_ms=r["avg_latency_ms"],
                    p95_latency_ms=r["p95_latency_ms"],
                    data_points=r["data_points"],
                    failure_windows=failure_windows,
                ))
            servers.append(McpServerIntelligence(
                server_id=s["server_id"],
                overall_success_rate=s["overall_success_rate"],
                overall_avg_latency_ms=s["overall_avg_latency_ms"],
                overall_p95_latency_ms=s["overall_p95_latency_ms"],
                total_data_points=s["total_data_points"],
                failure_predicted=s["failure_predicted"],
                regions=regions,
            ))
        return McpServersResponse(servers=servers)
