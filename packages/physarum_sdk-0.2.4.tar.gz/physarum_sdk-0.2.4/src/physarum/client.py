from __future__ import annotations

from dataclasses import asdict
from datetime import datetime, timezone
from typing import Dict

from .router import RouteClient
from .telemetry import TelemetryBatcher
from .types import (
    CostOptimizeRequest,
    CostOptimizeResponse,
    McpServersResponse,
    ModelRouteRequest,
    ModelRouteResponse,
    PhysarumConfig,
    RouteRequest,
    ToolCallOutcome,
    WrapToolCallInput,
)


class PhysarumClient:
    def __init__(self, config: PhysarumConfig):
        self._config = config
        self._router = RouteClient(
            recommendation_base_url=config.recommendation_base_url,
            api_key=config.api_key,
            tenant_id=config.tenant_id,
            timeout_ms=config.request_timeout_ms,
        )
        self._batcher = TelemetryBatcher(
            ingestion_base_url=config.ingestion_base_url,
            api_key=config.api_key,
            max_batch_size=config.telemetry_batch_size,
            flush_interval_ms=config.telemetry_flush_interval_ms,
            timeout_ms=config.request_timeout_ms,
        )

    @property
    def tenant_id(self) -> str:
        return self._config.tenant_id

    def get_routes(self, request: RouteRequest) -> Dict:
        return self._router.get_routes(request)

    def _static_priorities(self, task_category: str) -> list[str]:
        task_priorities = self._config.local_static_priorities_by_task_category.get(task_category)
        if task_priorities:
            return task_priorities
        return self._config.local_static_priorities

    def _choose_static_tool(self, request: RouteRequest) -> str | None:
        if not request.candidate_tools:
            return None

        priorities = self._static_priorities(request.task_category)
        if not priorities:
            return request.candidate_tools[0]

        ordered = sorted(
            request.candidate_tools,
            key=lambda tool: priorities.index(tool) if tool in priorities else len(priorities),
        )
        return ordered[0] if ordered else request.candidate_tools[0]

    def _build_static_response(self, request: RouteRequest) -> Dict:
        ordered = request.candidate_tools.copy()
        priorities = self._static_priorities(request.task_category)
        if priorities:
            ordered = sorted(
                request.candidate_tools,
                key=lambda tool: priorities.index(tool) if tool in priorities else len(priorities),
            )

        recommendations = []
        for i, tool in enumerate(ordered):
            recommendations.append(
                {
                    "rank": i + 1,
                    "tool_id": tool,
                    "tool_name": tool,
                    "score": max(0.1, 1.0 - i * 0.1),
                    "confidence": 0.1,
                    "expected_success": 0.5,
                    "expected_latency_ms": 1000,
                    "expected_cost": 0.5,
                    "expected_quality": 0.5,
                    "context_match": "static_baseline",
                    "trend": "stable",
                    "reason_codes": ["recommendation_api_unavailable", "static_baseline_fallback"],
                }
            )

        context = asdict(request.context) if request.context else {}
        context.setdefault("country_code", "unknown")
        context.setdefault("region", "unknown")
        context.setdefault("locale", "unknown")
        context.setdefault("domain", "unknown")
        context.setdefault("model_id", "unknown")
        context.setdefault("time_of_day_utc", "unknown")

        return {
            "task_category": request.task_category,
            "context": context,
            "recommendations": recommendations,
            "network_stats": {
                "data_points_24h": 0,
                "countries_with_data": 0,
                "last_solver_run": datetime.fromtimestamp(0, tz=timezone.utc).isoformat(),
            },
        }

    def select_tool(self, request: RouteRequest) -> Dict:
        api_unavailable = False
        try:
            response = self.get_routes(request)
        except Exception:
            response = self._build_static_response(request)
            api_unavailable = True

        recommendations = response.get("recommendations", [])
        top = recommendations[0] if recommendations else None
        fallback = self._choose_static_tool(request)

        if not top:
            return {
                "mode": self._config.mode,
                "recommended_tool": None,
                "selected_tool": fallback,
                "reason": "recommendation_api_unavailable" if api_unavailable else "no_recommendation",
                "response": response,
            }

        if api_unavailable:
            return {
                "mode": self._config.mode,
                "recommended_tool": top.get("tool_id"),
                "selected_tool": fallback,
                "reason": "recommendation_api_unavailable",
                "response": response,
            }

        if self._config.mode == "SHADOW":
            return {
                "mode": "SHADOW",
                "recommended_tool": top.get("tool_id"),
                "selected_tool": fallback,
                "reason": "shadow_mode",
                "response": response,
            }

        if self._config.mode == "ADVISORY":
            return {
                "mode": "ADVISORY",
                "recommended_tool": top.get("tool_id"),
                "selected_tool": fallback,
                "reason": "advisory_mode",
                "response": response,
            }

        return {
            "mode": "CONTROLLED",
            "recommended_tool": top.get("tool_id"),
            "selected_tool": top.get("tool_id"),
            "reason": "controlled_mode",
            "response": response,
        }

    def track_tool_call(self, event: Dict) -> None:
        self._batcher.enqueue(event)

    def wrap_tool_call(self, input_data: WrapToolCallInput) -> ToolCallOutcome:
        started = datetime.now(tz=timezone.utc)
        try:
            result = input_data.execute()
            latency_ms = int((datetime.now(tz=timezone.utc) - started).total_seconds() * 1000)
            telemetry = {
                "tenant_id": self._config.tenant_id,
                "session_id_hash": input_data.session_id_hash,
                "tool_id": input_data.tool_id,
                "tool_name": input_data.tool_name,
                "task_category": input_data.task_category,
                "action_class": input_data.action_class,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "latency_ms": latency_ms,
                "success": True,
                "token_in": input_data.token_in,
                "token_out": input_data.token_out,
                "workflow_id": input_data.workflow_id,
                "tool_chain_position": input_data.tool_chain_position,
                "preceding_tool_id": input_data.preceding_tool_id,
            }
            if input_data.context:
                telemetry.update(asdict(input_data.context))

            self.track_tool_call(telemetry)
            return ToolCallOutcome(result=result, telemetry=telemetry)
        except Exception as error:
            latency_ms = int((datetime.now(tz=timezone.utc) - started).total_seconds() * 1000)
            telemetry = {
                "tenant_id": self._config.tenant_id,
                "session_id_hash": input_data.session_id_hash,
                "tool_id": input_data.tool_id,
                "tool_name": input_data.tool_name,
                "task_category": input_data.task_category,
                "action_class": input_data.action_class,
                "timestamp": datetime.now(tz=timezone.utc).isoformat(),
                "latency_ms": latency_ms,
                "success": False,
                "error_type": error.__class__.__name__,
                "token_in": input_data.token_in,
                "token_out": input_data.token_out,
                "workflow_id": input_data.workflow_id,
                "tool_chain_position": input_data.tool_chain_position,
                "preceding_tool_id": input_data.preceding_tool_id,
            }
            if input_data.context:
                telemetry.update(asdict(input_data.context))

            self.track_tool_call(telemetry)
            raise

    def get_model_routes(self, request: ModelRouteRequest) -> ModelRouteResponse:
        return self._router.get_model_routes(request)

    def get_cost_optimized_path(self, request: CostOptimizeRequest) -> CostOptimizeResponse:
        return self._router.get_cost_optimized_path(request)

    def get_mcp_servers(self, task_category: str | None = None) -> McpServersResponse:
        return self._router.get_mcp_servers(task_category)

    def log_decision(self, event: Dict) -> None:
        self._router.log_decision(event)

    def shutdown(self) -> None:
        self._batcher.shutdown()
