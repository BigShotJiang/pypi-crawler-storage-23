from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional


@dataclass
class ContextInput:
    country_code: Optional[str] = None
    region: Optional[str] = None
    locale: Optional[str] = None
    domain: Optional[str] = None
    model_id: Optional[str] = None
    time_of_day_utc: Optional[str] = None


@dataclass
class ToolCallTelemetry:
    tenant_id: str
    session_id_hash: str
    tool_id: str
    tool_name: str
    task_category: str
    action_class: str
    timestamp: str
    latency_ms: int
    success: bool
    country_code: Optional[str] = None
    region: Optional[str] = None
    locale: Optional[str] = None
    domain: Optional[str] = None
    model_id: Optional[str] = None
    token_in: Optional[int] = None
    token_out: Optional[int] = None
    quality_score: Optional[float] = None
    error_type: Optional[str] = None
    retry_count: Optional[int] = None
    workflow_id: Optional[str] = None
    tool_chain_position: Optional[int] = None
    preceding_tool_id: Optional[str] = None


@dataclass
class RouteRequest:
    task_category: str
    candidate_tools: List[str]
    action_class: str
    context: Optional[ContextInput] = None
    limit: int = 5


@dataclass
class PhysarumConfig:
    api_key: str
    tenant_id: str
    ingestion_base_url: str
    recommendation_base_url: str
    mode: str = "SHADOW"
    telemetry_batch_size: int = 100
    telemetry_flush_interval_ms: int = 5000
    request_timeout_ms: int = 5000
    local_static_priorities: List[str] = field(default_factory=list)
    local_static_priorities_by_task_category: Dict[str, List[str]] = field(default_factory=dict)


@dataclass
class WrapToolCallInput:
    tool_id: str
    tool_name: str
    task_category: str
    action_class: str
    session_id_hash: str
    execute: Callable[[], Any]
    context: Optional[ContextInput] = None
    token_in: Optional[int] = None
    token_out: Optional[int] = None
    workflow_id: Optional[str] = None
    tool_chain_position: Optional[int] = None
    preceding_tool_id: Optional[str] = None


@dataclass
class ToolCallOutcome:
    result: Any
    telemetry: Dict[str, Any]


@dataclass
class DecisionLogInput:
    event: Dict[str, Any]


@dataclass
class ModelRouteRequest:
    task_category: str
    candidate_models: List[str]


@dataclass
class ModelRouteEntry:
    rank: int
    model_id: str
    success_rate: Optional[float]
    avg_latency_ms: Optional[float]
    avg_quality: Optional[float]
    avg_tokens_per_call: Optional[float]
    efficiency_score: Optional[float]
    data_points: int
    source: str  # "learned" | "no_data"


@dataclass
class ModelRouteResponse:
    task_category: str
    models: List[ModelRouteEntry]


@dataclass
class CostOptimizeRequest:
    task_category: str
    candidate_tools: List[str]
    quality_floor: float = 0.7
    budget_tokens: Optional[int] = None


@dataclass
class CostOptimizePath:
    rank: int
    tool_id: str
    success_rate: float
    avg_tokens_per_call: int
    avg_latency_ms: float
    cost_score: float
    data_points: int


@dataclass
class CostOptimizeOptimalPath:
    tool_id: str
    success_rate: float
    avg_tokens_per_call: int
    avg_latency_ms: float
    token_savings_vs_worst_pct: float


@dataclass
class CostOptimizeResponse:
    task_category: str
    quality_floor: float
    optimal_path: Optional[CostOptimizeOptimalPath]
    all_paths: List[CostOptimizePath]
    message: Optional[str] = None


@dataclass
class McpServerFailureWindow:
    hour_of_day: int
    day_of_week: int
    failure_rate: float


@dataclass
class McpServerRegion:
    region: str
    country_code: str
    success_rate: float
    avg_latency_ms: float
    p95_latency_ms: float
    data_points: int
    failure_windows: List[McpServerFailureWindow]


@dataclass
class McpServerIntelligence:
    server_id: str
    overall_success_rate: float
    overall_avg_latency_ms: float
    overall_p95_latency_ms: float
    total_data_points: int
    failure_predicted: bool
    regions: List[McpServerRegion]


@dataclass
class McpServersResponse:
    servers: List[McpServerIntelligence]
