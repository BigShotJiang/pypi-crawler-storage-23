"""Unit tests for trestle_mcp."""
