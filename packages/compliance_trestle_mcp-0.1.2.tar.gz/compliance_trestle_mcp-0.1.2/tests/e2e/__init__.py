"""E2E tests for trestle_mcp server."""
