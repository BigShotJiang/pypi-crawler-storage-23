#!/usr/bin/env python3
"""Entry point for running trestle_mcp as a module."""

from trestle_mcp.main import main

if __name__ == "__main__":
    main()
