"""Dashboard package for Kyber."""

from kyber.dashboard.server import create_dashboard_app

__all__ = ["create_dashboard_app"]
