class MessageBase:
    def __init__(self, message_id):
        self.message_id: str = message_id
