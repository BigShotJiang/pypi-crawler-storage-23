__all__ = ['MCPBridge', 'MCPProxy', 'MCPHTTPProxy']


def __getattr__(name):
    if name == 'MCPBridge':
        from .bridge import MCPBridge
        return MCPBridge
    if name == 'MCPProxy':
        from .proxy import MCPProxy
        return MCPProxy
    if name == 'MCPHTTPProxy':
        from .http_proxy import MCPHTTPProxy
        return MCPHTTPProxy
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
