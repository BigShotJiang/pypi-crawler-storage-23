"""Avatar Engine test suite."""
