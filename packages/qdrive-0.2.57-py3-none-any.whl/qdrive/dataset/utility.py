import logging

from typing import Union
from uuid import UUID

from qdrive.dataset.dataset import dataset
from qdrive.dataset.files.file_mgr_single import file_mgr_single

from etiket_client.local.database import Session
from etiket_client.remote.errors import CONNECTION_ERRORS
from etiket_client.local.exceptions import DatasetNotFoundException, FileNotFoundException

from etiket_client.local.dao.dataset import dao_dataset, DatasetSearch as DatasetSearchLocal
from etiket_client.remote.endpoints.dataset import dataset_search, DatasetSearch as DatasetSearchRemote

logger = logging.getLogger(__name__)

def get_dataset_by_file_uuid(file_uuid: Union[str, UUID]) -> dataset:
    """Look up the dataset that contains a given file.

    Searches the remote server first; falls back to the local database
    when the remote is unreachable.

    Args:
        file_uuid: UUID of the file to search for.

    Returns:
        The dataset that contains the file.

    Raises:
        ValueError: If *file_uuid* is not a valid UUID or if multiple
            datasets are found (which indicates a data integrity issue).
        DatasetNotFoundException: If no dataset contains the file.
    """
    try:
        # try to convert to uuid, to see if it is a valid uuid (string is base type for the queries)
        file_uuid = str(UUID(str(file_uuid)))
    except Exception:
        raise ValueError(f"File uuid {file_uuid} is not a valid UUID")

    # search remote (if connection)
    dataset_raw = []
    try:
        dataset_raw = dataset_search(DatasetSearchRemote(search_query=file_uuid))
    except CONNECTION_ERRORS as e:
        logger.warning(f"Remote search failed: {e}")
        print("Warning: Only performing local search (remote search failed, no connection to server).")
    
    # search local
    if len(dataset_raw) == 0:
        with Session() as session:
            dataset_raw = dao_dataset.search(DatasetSearchLocal(search_query=file_uuid), session)
    
    if len(dataset_raw) > 1:
        raise ValueError(f"Multiple datasets found for file uuid {file_uuid}, this should not happen. Please report to support@qharbor.nl")
    elif len(dataset_raw) == 1:
        return dataset(dataset_raw[0].uuid)
    else:
        raise DatasetNotFoundException(f"No dataset found containing file uuid {file_uuid}")
    
def get_file_by_file_uuid(file_uuid: Union[str, UUID]) -> file_mgr_single:
    """Retrieve a single file manager by its UUID.

    Finds the parent dataset via :func:`get_dataset_by_file_uuid`, then
    returns the matching file from that dataset.

    Args:
        file_uuid: UUID of the file to retrieve.

    Returns:
        A file manager for the requested file.

    Raises:
        ValueError: If *file_uuid* is not a valid UUID.
        FileNotFoundException: If no file with the given UUID exists.
    """
    try:
        ds = get_dataset_by_file_uuid(file_uuid)
        for filename in ds.files:
            file = ds[filename]
            if UUID(str(file.uuid)) == UUID(str(file_uuid)):
                return file
            
        raise FileNotFoundException(f"No file found with uuid {file_uuid}")
        
    except DatasetNotFoundException:
        raise FileNotFoundException(f"No file found with uuid {file_uuid}")
