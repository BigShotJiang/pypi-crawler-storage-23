from PyQt5.QtCore import QObject, pyqtSlot
from PyQt5.QtGui import QGuiApplication

from etiket_client.python_api.version import get_new_versions, get_latest_release, find_current_versions, allow_beta
from semantic_version import Version

import etiket_client
class update_model(QObject):
    def __init__(self, parent: 'QObject | None' = None):
        super().__init__(parent)
        
        self.current_versions = find_current_versions()
        self.new_versions = get_new_versions()
        self.latest_release = get_latest_release()
    
    @pyqtSlot(result=str)
    def new_version_number(self):
        if len(self.new_versions) == 0: # this should not happen
            return "[current]"
        return self.new_versions[0].version
    
    @pyqtSlot(result=str)
    def update_command(self):
        if allow_beta():
            return "pip install --upgrade qdrive --pre"
        return "pip install --upgrade qdrive"
    
    @pyqtSlot()
    def copy_to_clipboard(self):
        clipboard = QGuiApplication.clipboard()
        if allow_beta():
            clipboard.setText("pip install --upgrade qdrive --pre")
        else:
            clipboard.setText("pip install --upgrade qdrive")
    
    @pyqtSlot(result=str)
    def get_release_notes(self):
        release_notes = ""
        for version in self.new_versions:
            release_notes += f"Version {version.version}:\n{version.version_notes}\n\n"
        return release_notes
    
    @pyqtSlot(result=str)
    def get_compatibility_notes(self):
        compatibility_notes = ""
        # dataQruiser
        compatibility_notes += f"DataQruiser : min ({self.latest_release.min_dataQruiser_version.version})"
        if self.current_versions.dataQruiser_version is None:
            compatibility_notes += " -- not installed\n"
        elif self.latest_release.dataQruiser_version.version == self.current_versions.dataQruiser_version:
            compatibility_notes += f" -- the current version up to date {self.current_versions.dataQruiser_version}\n"
        elif Version(self.latest_release.dataQruiser_version.version) > Version(self.current_versions.dataQruiser_version):
            compatibility_notes += f" -- can be updated from {self.current_versions.dataQruiser_version} to {self.latest_release.dataQruiser_version.version})\n"
        else:
            compatibility_notes += f" -- **needs to be updated!!**)\n"
        
        # etiket
        if self.latest_release.etiket_version.version == self.current_versions.etiket_version:
            compatibility_notes += f"Etiket : min ({self.latest_release.min_etiket_version.version}), back-end is up to date\n"
        elif Version(self.latest_release.min_etiket_version.version) > Version(self.current_versions.etiket_version):
            compatibility_notes += f"Etiket : min ({self.latest_release.min_etiket_version.version}), current version is {self.current_versions.etiket_version}\n"
        else:
            compatibility_notes += f"Etiket : min ({self.latest_release.min_etiket_version.version}), back-end is out of date, please contact support\n"
        
        return compatibility_notes