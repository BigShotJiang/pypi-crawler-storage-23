"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.release.package_cmd import *  # noqa: F401,F403
