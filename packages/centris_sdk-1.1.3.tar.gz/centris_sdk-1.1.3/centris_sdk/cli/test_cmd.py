"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.dev.test_cmd import *  # noqa: F401,F403
