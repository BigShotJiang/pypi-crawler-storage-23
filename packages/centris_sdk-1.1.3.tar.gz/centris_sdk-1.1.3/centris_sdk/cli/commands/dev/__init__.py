"""Development-oriented CLI command registration."""

import click


def register_dev_commands(cli: click.Group) -> None:
    """Register connector development commands."""
    from .init_cmd import init_command
    from .introspect_cmd import introspect_command
    from .refine_cmd import refine_command
    from .serve_cmd import serve_command
    from .skills_cmd import skills_group
    from .test_cmd import test_command
    from .validate_cmd import validate_command

    cli.add_command(init_command, name="init")
    cli.add_command(validate_command, name="validate")
    cli.add_command(test_command, name="test")
    cli.add_command(serve_command, name="serve")
    cli.add_command(refine_command, name="refine")
    cli.add_command(skills_group, name="skills")
    cli.add_command(introspect_command, name="introspect")


__all__ = ["register_dev_commands"]
