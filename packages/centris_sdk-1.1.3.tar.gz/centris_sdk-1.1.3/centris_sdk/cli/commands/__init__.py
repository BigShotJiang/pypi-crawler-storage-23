"""Command registrars for the Centris Python CLI."""

from centris_sdk.cli.commands.agentic import register_agentic_commands
from centris_sdk.cli.commands.catalog import register_catalog_commands
from centris_sdk.cli.commands.dev import register_dev_commands
from centris_sdk.cli.commands.interop import register_interop_commands
from centris_sdk.cli.commands.release import register_release_commands

__all__ = [
    "register_agentic_commands",
    "register_catalog_commands",
    "register_dev_commands",
    "register_interop_commands",
    "register_release_commands",
]
