"""Interoperability command registration."""

import click


def register_interop_commands(cli: click.Group) -> None:
    """Register adapter, manifest, and contract command groups."""
    from .adapter_cmd import adapter_group
    from .contract_cmd import contract_group, partner_group
    from .manifest_cmd import manifest_group

    cli.add_command(adapter_group, name="adapter")
    cli.add_command(manifest_group, name="manifest")
    cli.add_command(partner_group, name="partner")
    cli.add_command(contract_group, name="contract")


__all__ = ["register_interop_commands"]
