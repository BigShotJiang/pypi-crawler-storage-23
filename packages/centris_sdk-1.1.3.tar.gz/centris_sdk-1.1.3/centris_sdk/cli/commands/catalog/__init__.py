"""Catalog, install, and auth command registration."""

import click


def register_catalog_commands(cli: click.Group) -> None:
    """Register discovery, install, update, and auth commands."""
    from .auth import login_command, logout_command, whoami_command
    from .install_cmd import install_command
    from .list_cmd import list_command, search_command
    from .update_cmd import update_command

    cli.add_command(list_command, name="list")
    cli.add_command(search_command, name="search")
    cli.add_command(install_command, name="install")
    cli.add_command(update_command, name="update")
    cli.add_command(login_command, name="login")
    cli.add_command(logout_command, name="logout")
    cli.add_command(whoami_command, name="whoami")


__all__ = ["register_catalog_commands"]
