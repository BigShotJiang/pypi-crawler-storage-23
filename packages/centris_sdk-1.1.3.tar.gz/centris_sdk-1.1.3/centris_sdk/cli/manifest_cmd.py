"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.interop.manifest_cmd import *  # noqa: F401,F403
