"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.agentic.desktop_cmd import *  # noqa: F401,F403
