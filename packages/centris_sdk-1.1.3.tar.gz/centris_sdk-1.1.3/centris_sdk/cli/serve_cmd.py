"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.dev.serve_cmd import *  # noqa: F401,F403
