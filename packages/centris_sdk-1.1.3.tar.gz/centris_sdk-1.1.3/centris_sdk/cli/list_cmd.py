"""Backward-compatible command module shim."""

from centris_sdk.cli.commands.catalog.list_cmd import *  # noqa: F401,F403
