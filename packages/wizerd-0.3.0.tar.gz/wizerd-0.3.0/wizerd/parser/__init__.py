"""Parser package exports."""

from .ddl_parser import DDLParser

__all__ = ["DDLParser"]
