"""Shared color palette definitions for WizERD themes."""

EDGE_COLOR_PALETTE = [
    "#f472b6",  # pink
    "#34d399",  # emerald
    "#fbbf24",  # amber
    "#a78bfa",  # violet
    "#fb923c",  # orange
    "#22d3ee",  # cyan
    "#a3e635",  # lime
    "#e879f9",  # fuchsia
    "#facc15",  # yellow
    "#4ade80",  # green
    "#60a5fa",  # blue
    "#7dd3fc",  # sky
    "#f87171",  # red
    "#818cf8",  # indigo
    "#2dd4bf",  # teal
    "#fb7185",  # rose
    "#c084fc",  # purple
    "#38bdf8",  # light blue
    "#bef264",  # lime light
    "#fdba74",  # peach
    "#c4b5fd",  # violet light
    "#67e8f9",  # aqua
    "#fca5a5",  # salmon
    "#d8b4fe",  # mauve
    "#86efac",  # mint
    "#fde047",  # bright yellow
    "#93c5fd",  # periwinkle
    "#fda4af",  # blush
    "#fdcf72",  # gold
    "#b9f18d",  # pear
    "#f0abfc",  # orchid
    "#7ee8fa",  # electric cyan
    "#fecccc",  # pale pink
    "#e9d5ff",  # lavender
    "#bbf7d0",  # seafoam
    "#fef08a",  # butter
]
