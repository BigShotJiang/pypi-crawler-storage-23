class Climseine :
    def __init__ (self):
        print(f"Hello {type(self).__name__}")
