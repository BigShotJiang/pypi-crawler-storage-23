#!/usr/bin/env python3
import argparse
import os
import sys
from .core import auto_download, print_status, print_credit, C_PRIMARY, C_RESET

def main():
    parser = argparse.ArgumentParser(
        description="DANGER Downloader – Auto‑download videos from TikTok, Instagram, YouTube."
    )
    parser.add_argument('url', help='URL of the video/post/reel/story')
    parser.add_argument('folder', nargs='?', default=None,
                        help='Target folder (default: ./DANGER)')
    args = parser.parse_args()

    # Determine download directory
    if args.folder:
        download_dir = os.path.abspath(args.folder)
    else:
        download_dir = os.path.join(os.getcwd(), 'DANGER')

    # Ensure base directory exists
    os.makedirs(download_dir, exist_ok=True)

    # Small banner / info
    print(f"{C_PRIMARY}╔════════════════════════════════════════════════╗{C_RESET}")
    print(f"{C_PRIMARY}║      🔥 DANGER DOWNLOADER (COMMAND LINE)     ║{C_RESET}")
    print(f"{C_PRIMARY}╚════════════════════════════════════════════════╝{C_RESET}")
    print_credit()
    print(f"📁 Download folder: {download_dir}\n")

    # Run download
    success = auto_download(args.url, download_dir)

    sys.exit(0 if success else 1)

if __name__ == '__main__':
    main()