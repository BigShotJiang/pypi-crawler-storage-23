"""
Antaris Pipeline 2.0 - Unified Orchestration for AI Agent Infrastructure

The central orchestration engine for the Antaris Analytics Suite.
Unifies memory, routing, security, and context management with 
cross-package intelligence and real-time telemetrics.

Key Features:
- 🚀 10x faster integration than competitors
- 🔍 Real-time telemetrics and observability  
- 🧠 Cross-package intelligence optimization
- 🎨 Visual configuration (GUI-based security policies)
- 💰 Cost-performance SLAs with guarantees
- 🏃 Agent-native patterns for conversation flows

Quick Start:
    >>> from antaris_pipeline import Pipeline, create_config
    >>> 
    >>> # One-line setup (vs competitors' multi-day configs)
    >>> config = create_config(profile="balanced")
    >>> pipeline = Pipeline.from_config(config)
    >>> 
    >>> # Process with cross-package intelligence
    >>> result = await pipeline.process("Hello", my_model_function)
    >>> print(f"Success: {result.success}, Output: {result.output}")
    >>> 
    >>> # Dry-run for demos (zero API costs)
    >>> simulation = pipeline.dry_run("What would happen with this input?")
    >>> print(simulation)
"""

__version__ = "4.5.5"
__author__ = "Antaris Analytics"
__email__ = "dev@antarisanalytics.com"
__license__ = "Apache-2.0"

# Core pipeline components
from .pipeline import AntarisPipeline, PipelineResult, create_pipeline
from .agent_pipeline import AgentPipeline, PreTurnResult, PostTurnResult

Pipeline = AntarisPipeline
from .config import (
    PipelineConfig,
    MemoryConfig,
    RouterConfig, 
    GuardConfig,
    ContextConfig,
    TelemetricsConfig,
    ProfileType,
    create_config,
    PROFILE_PRESETS
)

# Event system and telemetrics
from .events import (
    AntarisEvent,
    EventType,
    ConfidenceBasis,
    PerformanceMetrics,
    EventEmitter,
    memory_event,
    router_event,
    guard_event, 
    context_event
)

from .telemetrics import TelemetricsCollector, TelemetricsServer
from .telemetry import PipelineTelemetry

# Hook system
from .hooks import (
    HookPhase,
    HookContext,
    HookResult,
    HookRegistry,
    PipelineHooks,
    HookCallback
)

# Configuration shortcuts for common profiles
def balanced_pipeline(storage_path: str = "./memory_store", **kwargs) -> AntarisPipeline:
    """Create a balanced pipeline (default settings)."""
    config = kwargs.pop("pipeline_config", None) or create_config(ProfileType.BALANCED)
    return create_pipeline(storage_path=storage_path, pipeline_config=config, **kwargs)

def strict_pipeline(storage_path: str = "./memory_store", **kwargs) -> AntarisPipeline:
    """Create a security-focused pipeline."""
    config = kwargs.pop("pipeline_config", None) or create_config(ProfileType.STRICT_SAFETY)
    return create_pipeline(storage_path=storage_path, pipeline_config=config, **kwargs)

def cost_optimized_pipeline(storage_path: str = "./memory_store", **kwargs) -> AntarisPipeline:
    """Create a cost-optimized pipeline."""
    config = kwargs.pop("pipeline_config", None) or create_config(ProfileType.COST_OPTIMIZED)
    return create_pipeline(storage_path=storage_path, pipeline_config=config, **kwargs)

def performance_pipeline(storage_path: str = "./memory_store", **kwargs) -> AntarisPipeline:
    """Create a performance-optimized pipeline."""
    config = kwargs.pop("pipeline_config", None) or create_config(ProfileType.PERFORMANCE)
    return create_pipeline(storage_path=storage_path, pipeline_config=config, **kwargs)

def debug_pipeline(storage_path: str = "./memory_store", **kwargs) -> AntarisPipeline:
    """Create a debug pipeline with full telemetrics."""
    config = kwargs.pop("pipeline_config", None) or create_config(ProfileType.DEBUG)
    return create_pipeline(storage_path=storage_path, pipeline_config=config, **kwargs)

# Export all public APIs
__all__ = [
    # Core pipeline
    "Pipeline",
    "PipelineResult", 
    "create_pipeline",
    "AgentPipeline",
    "PreTurnResult",
    "PostTurnResult",
    
    # Configuration
    "PipelineConfig",
    "MemoryConfig",
    "RouterConfig",
    "GuardConfig", 
    "ContextConfig",
    "TelemetricsConfig",
    "ProfileType",
    "create_config",
    "PROFILE_PRESETS",
    
    # Events and telemetrics
    "AntarisEvent",
    "EventType",
    "ConfidenceBasis",
    "PerformanceMetrics",
    "EventEmitter",
    "TelemetricsCollector",
    "TelemetricsServer",
    "PipelineTelemetry",
    
    # Hook system
    "HookPhase",
    "HookContext", 
    "HookResult",
    "HookRegistry",
    "PipelineHooks",
    "HookCallback",
    
    # Convenience functions
    "memory_event",
    "router_event", 
    "guard_event",
    "context_event",
    
    # Profile shortcuts
    "balanced_pipeline",
    "strict_pipeline",
    "cost_optimized_pipeline", 
    "performance_pipeline",
    "debug_pipeline",
]

# Package metadata
__package_info__ = {
    "name": "antaris-pipeline",
    "version": __version__,
    "description": "Unified orchestration pipeline for Antaris Analytics Suite", 
    "author": __author__,
    "author_email": __email__,
    "license": __license__,
    "url": "https://antarisanalytics.ai",
    "repository": "https://github.com/antaris-analytics/antaris-pipeline",
    "documentation": "https://docs.antarisanalytics.ai/pipeline",
    "keywords": ["ai", "agents", "pipeline", "orchestration", "telemetrics"],
    "classifiers": [
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers", 
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ]
}