"""
PipelineTelemetry — per-run pipeline performance metrics (v4.2.0).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional


@dataclass
class PipelineTelemetry:
    """Per-run pipeline performance metrics.

    Produced automatically by :class:`~antaris_pipeline.AgentPipeline` at the
    end of each pre-turn or post-turn call and stored on
    ``AgentPipeline.last_telemetry``.  A telemetry callback can also be
    registered via ``AgentPipeline.on_telemetry``.

    Attributes:
        run_id:        Unique UUID4 for this pipeline run.
        started_at:    Unix timestamp when the run started (``time.time()``).
        finished_at:   Unix timestamp when the run finished.
        total_ms:      Wall-clock duration in milliseconds.
        stage_timings: Per-stage timings in milliseconds.
                       Keys depend on which stages ran, e.g.:
                       ``{"guard_input": 2.1, "recall": 12.3, "context": 5.0,
                         "routing": 1.5, "guard_output": 1.9, "ingest": 8.4}``
        tokens_used:   Estimated tokens consumed (if available).
        cost_usd:      Estimated cost in USD (if available).
        blocked:       ``True`` if the run was blocked by the guard.
        error:         Error message string if the run raised an exception,
                       ``None`` otherwise.
    """

    run_id: str
    started_at: float
    finished_at: float
    total_ms: float
    stage_timings: dict[str, float] = field(default_factory=dict)
    tokens_used: int = 0
    cost_usd: float = 0.0
    blocked: bool = False
    error: Optional[str] = None

    def slowest_stage(self) -> tuple[str, float]:
        """Return ``(stage_name, ms)`` for the slowest stage.

        Returns:
            A ``(name, ms)`` tuple.  If ``stage_timings`` is empty, returns
            ``("", 0.0)``.
        """
        if not self.stage_timings:
            return ("", 0.0)
        name = max(self.stage_timings, key=self.stage_timings.__getitem__)
        return (name, self.stage_timings[name])

    def summary(self) -> str:
        """One-line human-readable summary.

        Format::

            Pipeline: 145ms total | recall=12ms guard_input=2ms | 342 tokens

        Returns:
            Single-line string.
        """
        stage_parts = " ".join(
            f"{k}={v:.0f}ms"
            for k, v in sorted(self.stage_timings.items())
        )
        parts = [f"Pipeline: {self.total_ms:.0f}ms total"]
        if stage_parts:
            parts.append(stage_parts)
        parts.append(f"{self.tokens_used} tokens")
        return " | ".join(parts)
