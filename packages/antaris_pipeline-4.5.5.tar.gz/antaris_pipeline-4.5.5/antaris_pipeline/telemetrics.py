"""
Telemetrics Collection and Analysis System for Antaris Suite 2.0

Provides real-time observability and cross-package intelligence.
Supports JSONL file output, in-memory buffering, and rich query/analysis.

Sprint 9: Production Telemetrics Platform — enhanced storage, querying,
and reporting capabilities.
"""

import json
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

from .events import AntarisEvent, EventType


# ── Percentile helper ─────────────────────────────────────────────────────────

def _percentile(data: List[float], pct: float) -> float:
    """Compute a percentile from a sorted-or-unsorted list (no numpy needed)."""
    if not data:
        return 0.0
    sorted_data = sorted(data)
    k = (len(sorted_data) - 1) * pct / 100.0
    lo, hi = int(k), min(int(k) + 1, len(sorted_data) - 1)
    return sorted_data[lo] + (sorted_data[hi] - sorted_data[lo]) * (k - lo)


# ── TelemetricsCollector ──────────────────────────────────────────────────────

class TelemetricsCollector:
    """
    Collects and processes telemetrics events from all packages.

    Sprint 9 enhancements:
    - JSONL persistence with real-time appends
    - Bounded in-memory buffer with configurable max size
    - Rich query API: filter by module, event_type, time window
    - Replay events from a JSONL file for post-hoc analysis
    - Performance report with p50/p95/p99 latencies
    - Cost report with per-model breakdown
    - Security report with block rates and risk distribution
    """

    def __init__(
        self,
        session_id: str,
        output_file: Optional[Path] = None,
        output_dir: Optional[Union[str, Path]] = None,
        buffer_size: int = 1000,
        enable_analytics: bool = True,
    ):
        """
        Initialize the telemetrics collector.

        Args:
            session_id:       Unique identifier for this session.
            output_file:      Explicit path for the JSONL output file.
                              Takes precedence over output_dir.
            output_dir:       Directory to store JSONL files; file will be
                              named ``telemetrics_{session_id}.jsonl``.
                              Defaults to ``"telemetrics/"``.
            buffer_size:      Maximum events kept in the in-memory ring buffer.
            enable_analytics: When False, events are not written to disk.
        """
        self.session_id = session_id
        self.buffer_size = buffer_size
        self.enable_analytics = enable_analytics

        # ── Output file resolution ────────────────────────────────────────
        if output_file is not None:
            self.output_file = Path(output_file)
        elif output_dir is not None:
            self.output_file = (
                Path(output_dir) / f"telemetrics_{session_id}.jsonl"
            )
        else:
            self.output_file = Path("telemetrics") / f"telemetrics_{session_id}.jsonl"

        self._ensure_output_file()

        # ── In-memory ring buffer ─────────────────────────────────────────
        self._event_buffer: deque = deque(maxlen=buffer_size)
        self._event_count = 0

        # ── Aggregated counters (not bounded — O(modules)) ────────────────
        self._events_by_module: Dict[str, int] = defaultdict(int)
        self._events_by_type: Dict[str, int] = defaultdict(int)

        # ── Performance tracking ──────────────────────────────────────────
        self._performance_history: List[Dict] = []
        self._latency_by_module: Dict[str, List[float]] = defaultdict(list)
        self._cost_tracking: Dict[str, float] = defaultdict(float)
        self._cost_by_model: Dict[str, float] = defaultdict(float)
        self._tokens_by_module: Dict[str, int] = defaultdict(int)

        # ── Confidence / correlation ──────────────────────────────────────
        self._confidence_trends: Dict[str, List[float]] = defaultdict(list)
        self._correlation_graph: Dict[str, List[str]] = defaultdict(list)

    # ── File management ───────────────────────────────────────────────────

    def _ensure_output_file(self) -> None:
        """Ensure output directory and file exist."""
        try:
            self.output_file.parent.mkdir(parents=True, exist_ok=True)
            if not self.output_file.exists():
                self.output_file.touch()
        except Exception as e:
            print(f"Warning: Could not create telemetrics file {self.output_file}: {e}")

    # ── Core collection ───────────────────────────────────────────────────

    def collect_event(self, event: AntarisEvent) -> None:
        """
        Collect a telemetrics event and update analytics.

        Thread-safe for single-threaded use (GIL-protected deque operations).
        """
        # ── In-memory buffer ──────────────────────────────────────────────
        self._event_buffer.append(event)  # deque(maxlen=N) auto-drops oldest
        self._event_count += 1

        # ── Counters ──────────────────────────────────────────────────────
        self._events_by_module[event.module] += 1
        self._events_by_type[event.event_type.value] += 1

        # ── Performance tracking ──────────────────────────────────────────
        if event.performance:
            perf = event.performance
            if perf.latency_ms is not None:
                self._latency_by_module[event.module].append(perf.latency_ms)
            if perf.cost_usd is not None:
                self._cost_tracking[event.module] += perf.cost_usd
                # Also track cost by model (from payload)
                model_key = event.payload.get("selected_model") or event.payload.get("model")
                if model_key:
                    self._cost_by_model[model_key] += perf.cost_usd
            if perf.tokens_processed is not None:
                self._tokens_by_module[event.module] += perf.tokens_processed

        # ── Confidence tracking ───────────────────────────────────────────
        if event.confidence is not None:
            key = f"{event.module}.{event.event_type.value}"
            self._confidence_trends[key].append(event.confidence)

        # ── Correlation graph ─────────────────────────────────────────────
        for corr_id in event.correlations:
            self._correlation_graph[event.event_id].append(corr_id)

        # ── Persistence ───────────────────────────────────────────────────
        if self.enable_analytics:
            self._write_event_to_file(event)
            self._update_analytics(event)

    def _write_event_to_file(self, event: AntarisEvent) -> None:
        """Append event as a JSON line to the JSONL output file."""
        try:
            with open(self.output_file, "a") as f:
                f.write(event.model_dump_json() + "\n")
        except Exception as e:
            print(f"Warning: Could not write telemetrics event: {e}")

    def _update_analytics(self, event: AntarisEvent) -> None:
        """Update performance history from event."""
        if event.performance:
            self._performance_history.append({
                "timestamp": event.timestamp.isoformat(),
                "module": event.module,
                "event_type": event.event_type.value,
                "performance": event.performance.model_dump(),
                "payload": event.payload,
            })
            if len(self._performance_history) > self.buffer_size:
                self._performance_history = self._performance_history[-self.buffer_size:]

    # ── Summary ───────────────────────────────────────────────────────────

    def get_summary(self) -> Dict[str, Any]:
        """
        Return human-readable telemetrics statistics.

        Returns a dict with:
          session_id, total_events, events_by_module, events_by_type,
          performance (avg_latency_ms, total_cost_usd, total_tokens),
          security (total_scans, blocks, block_rate),
          average_latencies_ms, total_costs_usd, average_confidences,
          buffer_utilization.
        """
        # ── Average latencies ─────────────────────────────────────────────
        avg_latencies: Dict[str, float] = {}
        for module, latencies in self._latency_by_module.items():
            if latencies:
                avg_latencies[module] = round(sum(latencies) / len(latencies), 2)

        # ── Aggregate performance ─────────────────────────────────────────
        all_latencies = [
            lat for lats in self._latency_by_module.values() for lat in lats
        ]
        avg_latency_ms = (
            round(sum(all_latencies) / len(all_latencies), 2)
            if all_latencies else 0.0
        )
        total_cost_usd = round(sum(self._cost_tracking.values()), 6)
        total_tokens = sum(self._tokens_by_module.values())

        # ── Security metrics ──────────────────────────────────────────────
        guard_events = [
            e for e in self._event_buffer if e.module == "guard" or (
                e.event_type.value.startswith("guard.")
            )
        ]
        # Also count guard events emitted by pipeline module
        pipeline_guard_events = [
            e for e in self._event_buffer
            if e.event_type.value in (
                EventType.GUARD_SCAN.value,
                EventType.GUARD_ALLOW.value,
                EventType.GUARD_DENY.value,
            )
        ]
        all_guard_events = list({e.event_id: e for e in guard_events + pipeline_guard_events}.values())
        total_scans = len(all_guard_events)
        blocks = sum(
            1 for e in all_guard_events
            if e.event_type == EventType.GUARD_DENY
            or e.payload.get("allowed") is False
        )
        block_rate = round(blocks / total_scans, 3) if total_scans > 0 else 0.0

        # ── Confidence averages ───────────────────────────────────────────
        avg_confidences: Dict[str, float] = {}
        for key, confs in self._confidence_trends.items():
            if confs:
                avg_confidences[key] = round(sum(confs) / len(confs), 3)

        return {
            "session_id": self.session_id,
            "total_events": self._event_count,
            "events_by_module": dict(self._events_by_module),
            "events_by_type": dict(self._events_by_type),
            "performance": {
                "avg_latency_ms": avg_latency_ms,
                "total_cost_usd": total_cost_usd,
                "total_tokens": total_tokens,
            },
            "security": {
                "total_scans": total_scans,
                "blocks": blocks,
                "block_rate": block_rate,
            },
            # Legacy keys for backward compatibility
            "average_latencies_ms": avg_latencies,
            "total_costs_usd": dict(self._cost_tracking),
            "average_confidences": avg_confidences,
            "correlation_count": len(self._correlation_graph),
            "buffer_utilization": len(self._event_buffer) / self.buffer_size,
        }

    # ── Query ─────────────────────────────────────────────────────────────

    def query_events(
        self,
        module: Optional[str] = None,
        event_type: Optional[str] = None,
        since_seconds: Optional[int] = None,
        limit: int = 100,
    ) -> List[AntarisEvent]:
        """
        Filter events from the in-memory buffer.

        Args:
            module:        Only return events from this module (e.g. ``"guard"``).
            event_type:    Only return events of this type (e.g. ``"guard.deny"``).
            since_seconds: Only return events from the last N seconds.
            limit:         Maximum number of events to return (most recent first).

        Returns:
            List of matching :class:`AntarisEvent` objects.
        """
        cutoff_ts: Optional[float] = None
        if since_seconds is not None:
            cutoff_ts = time.time() - since_seconds

        results: List[AntarisEvent] = []
        for event in reversed(list(self._event_buffer)):
            if module and event.module != module:
                continue
            if event_type and event.event_type.value != event_type:
                continue
            if cutoff_ts is not None:
                event_ts = event.timestamp.timestamp()
                if event_ts < cutoff_ts:
                    continue
            results.append(event)
            if len(results) >= limit:
                break

        return results

    # ── Replay ────────────────────────────────────────────────────────────

    def replay_events(self, jsonl_path: Union[str, Path]) -> List[AntarisEvent]:
        """
        Load and return all events from a JSONL file.

        Useful for post-hoc analysis of past sessions.

        Args:
            jsonl_path: Path to the ``.jsonl`` file to read.

        Returns:
            List of :class:`AntarisEvent` objects in file order.
        """
        path = Path(jsonl_path)
        if not path.exists():
            return []

        events: List[AntarisEvent] = []
        with open(path, "r") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    events.append(AntarisEvent.model_validate_json(line))
                except Exception:
                    # Skip malformed lines
                    continue
        return events

    # ── Performance report ────────────────────────────────────────────────

    def get_performance_report(self) -> Dict[str, Any]:
        """
        Detailed performance breakdown by module and operation.

        Includes p50, p95, p99 latencies for modules with enough data.

        Returns:
            Dict with per-module latency stats and overall totals.
        """
        per_module: Dict[str, Any] = {}
        all_latencies: List[float] = []

        for module, latencies in self._latency_by_module.items():
            if not latencies:
                continue
            all_latencies.extend(latencies)
            stats: Dict[str, Any] = {
                "count": len(latencies),
                "avg_ms": round(sum(latencies) / len(latencies), 2),
                "min_ms": round(min(latencies), 2),
                "max_ms": round(max(latencies), 2),
            }
            if len(latencies) >= 3:
                stats["p50_ms"] = round(_percentile(latencies, 50), 2)
                stats["p95_ms"] = round(_percentile(latencies, 95), 2)
                stats["p99_ms"] = round(_percentile(latencies, 99), 2)
            per_module[module] = stats

        overall: Dict[str, Any] = {}
        if all_latencies:
            overall = {
                "count": len(all_latencies),
                "avg_ms": round(sum(all_latencies) / len(all_latencies), 2),
                "min_ms": round(min(all_latencies), 2),
                "max_ms": round(max(all_latencies), 2),
            }
            if len(all_latencies) >= 3:
                overall["p50_ms"] = round(_percentile(all_latencies, 50), 2)
                overall["p95_ms"] = round(_percentile(all_latencies, 95), 2)
                overall["p99_ms"] = round(_percentile(all_latencies, 99), 2)

        return {
            "per_module": per_module,
            "overall": overall,
            "total_events_with_latency": len(all_latencies),
        }

    # ── Cost report ───────────────────────────────────────────────────────

    def get_cost_report(self) -> Dict[str, Any]:
        """
        Cost breakdown by module and model.

        Returns:
            Dict with total cost, per-module breakdown, and per-model breakdown.
        """
        total_cost = sum(self._cost_tracking.values())

        module_breakdown: Dict[str, Any] = {}
        for module, cost in self._cost_tracking.items():
            module_breakdown[module] = {
                "total_usd": round(cost, 6),
                "percentage": round(cost / total_cost * 100, 1) if total_cost > 0 else 0.0,
            }

        model_breakdown: Dict[str, Any] = {}
        total_model_cost = sum(self._cost_by_model.values())
        for model, cost in self._cost_by_model.items():
            model_breakdown[model] = {
                "total_usd": round(cost, 6),
                "percentage": (
                    round(cost / total_model_cost * 100, 1) if total_model_cost > 0 else 0.0
                ),
            }

        avg_cost_per_event = (
            round(total_cost / self._event_count, 8) if self._event_count > 0 else 0.0
        )

        return {
            "total_cost_usd": round(total_cost, 6),
            "avg_cost_per_event_usd": avg_cost_per_event,
            "by_module": module_breakdown,
            "by_model": model_breakdown,
            # Legacy key
            "cost_by_module": module_breakdown,
        }

    # ── Security report ───────────────────────────────────────────────────

    def get_security_report(self) -> Dict[str, Any]:
        """
        Security event analysis.

        Returns:
            Dict with block rates, top threat patterns, and risk distribution.
        """
        # Gather all guard-related events from the buffer
        guard_events = [
            e for e in self._event_buffer
            if e.event_type.value in (
                EventType.GUARD_SCAN.value,
                EventType.GUARD_ALLOW.value,
                EventType.GUARD_DENY.value,
            )
        ]

        total_scans = len(guard_events)
        blocked = sum(
            1 for e in guard_events
            if e.event_type == EventType.GUARD_DENY or e.payload.get("allowed") is False
        )
        allowed = total_scans - blocked
        block_rate = round(blocked / total_scans, 3) if total_scans > 0 else 0.0

        # Risk score distribution from payloads
        risk_scores: List[float] = []
        for e in guard_events:
            rs = e.payload.get("risk_score")
            if rs is not None:
                risk_scores.append(float(rs))

        risk_distribution = {"low": 0, "medium": 0, "high": 0}
        for rs in risk_scores:
            if rs < 0.4:
                risk_distribution["low"] += 1
            elif rs < 0.7:
                risk_distribution["medium"] += 1
            else:
                risk_distribution["high"] += 1

        # Top threat patterns (from match_count / patterns_matched payload)
        pattern_counts: Dict[str, int] = defaultdict(int)
        for e in guard_events:
            patterns = e.payload.get("patterns_matched", [])
            if isinstance(patterns, list):
                for p in patterns:
                    pattern_counts[str(p)] += 1

        top_patterns = sorted(
            [{"pattern": k, "count": v} for k, v in pattern_counts.items()],
            key=lambda x: x["count"],
            reverse=True,
        )[:10]

        avg_risk = round(sum(risk_scores) / len(risk_scores), 3) if risk_scores else 0.0

        return {
            "total_scans": total_scans,
            "blocked": blocked,
            "allowed": allowed,
            "block_rate": block_rate,
            "avg_risk_score": avg_risk,
            "risk_distribution": risk_distribution,
            "top_patterns": top_patterns,
            "total_security_events": total_scans,
            "blocked_requests": blocked,
            "allowed_requests": allowed,
        }

    # ── Legacy / compatibility methods ────────────────────────────────────

    def get_performance_trends(
        self,
        module: Optional[str] = None,
        minutes: int = 60,
    ) -> List[Dict[str, Any]]:
        """Get performance trends for the last N minutes."""
        cutoff_time = datetime.now(timezone.utc).timestamp() - (minutes * 60)
        trends = []
        for perf in self._performance_history:
            event_time = datetime.fromisoformat(perf["timestamp"]).timestamp()
            if event_time >= cutoff_time:
                if module is None or perf["module"] == module:
                    trends.append(perf)
        return trends

    def get_correlation_analysis(self) -> Dict[str, Any]:
        """Analyse cross-package event correlations."""
        correlation_counts = {
            eid: len(corrs) for eid, corrs in self._correlation_graph.items()
        }
        sorted_correlations = sorted(
            correlation_counts.items(), key=lambda x: x[1], reverse=True
        )
        return {
            "total_correlations": len(self._correlation_graph),
            "most_correlated_events": sorted_correlations[:10],
            "cross_module_patterns": {},
        }

    def get_cost_analysis(self) -> Dict[str, Any]:
        """Analyse cost patterns (legacy alias for get_cost_report)."""
        report = self.get_cost_report()
        return {
            "total_cost_usd": report["total_cost_usd"],
            "cost_by_module": report["by_module"],
            "average_cost_per_event": report["avg_cost_per_event_usd"],
        }

    def get_security_analysis(self) -> Dict[str, Any]:
        """Analyse security events (legacy alias for get_security_report)."""
        return self.get_security_report()

    def export_events(
        self,
        output_path: Path,
        format: str = "jsonl",
        filter_module: Optional[str] = None,
        filter_type: Optional[EventType] = None,
    ) -> int:
        """Export events to file with optional filtering."""
        events_to_export = []
        for event in self._event_buffer:
            if filter_module and event.module != filter_module:
                continue
            if filter_type and event.event_type != filter_type:
                continue
            events_to_export.append(event)

        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        if format == "jsonl":
            with open(output_path, "w") as f:
                for event in events_to_export:
                    f.write(event.model_dump_json() + "\n")
        elif format == "json":
            with open(output_path, "w") as f:
                json.dump(
                    [json.loads(event.model_dump_json()) for event in events_to_export], f, indent=2
                )
        else:
            raise ValueError(f"Unsupported format: {format}")

        return len(events_to_export)

    def reset(self) -> None:
        """Reset all in-memory telemetrics data (does not delete JSONL file)."""
        self._event_buffer.clear()
        self._event_count = 0
        self._events_by_module.clear()
        self._events_by_type.clear()
        self._performance_history.clear()
        self._latency_by_module.clear()
        self._cost_tracking.clear()
        self._cost_by_model.clear()
        self._tokens_by_module.clear()
        self._correlation_graph.clear()
        self._confidence_trends.clear()


# ── TelemetricsServer ──────────────────────────────────────────────────────────

class TelemetricsServer:
    """
    Optional telemetrics server for real-time dashboards.

    Provides HTTP/WebSocket endpoints for dashboard visualisation.
    Requires: ``pip install antaris-pipeline[telemetrics]``
    """

    def __init__(self, collector: TelemetricsCollector, port: int = 8080):
        self.collector = collector
        self.port = port
        self._app = None

    def start(self) -> None:
        """Start the telemetrics server."""
        try:
            import uvicorn
            from fastapi import FastAPI
            from fastapi.responses import HTMLResponse

            self._app = FastAPI(title="Antaris Telemetrics", version="2.0.0")
            self._setup_routes()
            uvicorn.run(self._app, host="0.0.0.0", port=self.port)
        except ImportError:
            print("Telemetrics server requires: pip install antaris-pipeline[telemetrics]")

    def _setup_routes(self) -> None:
        """Setup HTTP routes for telemetrics API."""

        @self._app.get("/")
        async def dashboard():
            return HTMLResponse(self._get_dashboard_html())

        @self._app.get("/api/summary")
        async def summary():
            return self.collector.get_summary()

        @self._app.get("/api/performance")
        async def performance(module: Optional[str] = None, minutes: int = 60):
            return self.collector.get_performance_trends(module, minutes)

        @self._app.get("/api/correlations")
        async def correlations():
            return self.collector.get_correlation_analysis()

        @self._app.get("/api/costs")
        async def costs():
            return self.collector.get_cost_report()

        @self._app.get("/api/security")
        async def security():
            return self.collector.get_security_report()

        @self._app.get("/api/query")
        async def query(
            module: Optional[str] = None,
            event_type: Optional[str] = None,
            since_seconds: Optional[int] = None,
            limit: int = 100,
        ):
            events = self.collector.query_events(
                module=module,
                event_type=event_type,
                since_seconds=since_seconds,
                limit=limit,
            )
            return [json.loads(e.model_dump_json()) for e in events]

    def _get_dashboard_html(self) -> str:
        return """
        <!DOCTYPE html>
        <html>
        <head>
            <title>Antaris Telemetrics</title>
        </head>
        <body>
            <h1>Antaris Analytics Suite - Telemetrics Dashboard</h1>
            <div id="summary"></div>
            <script>
                fetch('/api/summary')
                    .then(r => r.json())
                    .then(data => {
                        document.getElementById('summary').innerHTML =
                            '<pre>' + JSON.stringify(data, null, 2) + '</pre>';
                    });
            </script>
        </body>
        </html>
        """


# Export key classes
__all__ = [
    "TelemetricsCollector",
    "TelemetricsServer",
]
