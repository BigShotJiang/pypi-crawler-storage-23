"""
WorkPilot Runtime — wires together config, providers, tools, agent,
channels, security, graph, gateway, skills, and scheduling.
"""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot import __version__
from workpilot.agent.loop import AgentLoop
from workpilot.agent.tools.filesystem import (
    EditFileTool,
    ListDirTool,
    ReadFileTool,
    SearchFilesTool,
    WriteFileTool,
)
from workpilot.agent.tools.git import GitTool
from workpilot.agent.tools.message import MessageTool
from workpilot.agent.tools.registry import ToolRegistry
from workpilot.agent.tools.shell import ShellTool
from workpilot.agent.tools.web import HttpRequestTool, WebFetchTool, WebSearchTool
from workpilot.bus.queue import MessageBus
from workpilot.channels.cli import CLIChannel
from workpilot.channels.manager import ChannelManager
from workpilot.config.schema import AppConfig
from workpilot.hooks.manager import HookManager
from workpilot.providers.router import get_provider
from workpilot.security.audit import AuditLogger
from workpilot.security.rbac import PolicyEngine
from workpilot.security.sandbox import Sandbox
from workpilot.session.manager import SessionManager
from workpilot.skills.loader import SkillLoader
from workpilot.utils.helpers import get_sessions_dir

if TYPE_CHECKING:
    from workpilot.cron.service import SchedulerService
    from workpilot.gateway.server import GatewayServer
    from workpilot.graph.client import GraphClient
    from workpilot.mcp.client import MCPClient


class Runtime:
    """Main runtime orchestrator — wires all subsystems together."""

    def __init__(self, config: AppConfig, workspace: Path | None = None) -> None:
        self.config = config
        self.workspace = (workspace or Path(config.agents.default.workspace)).resolve()

        # Configure logging
        self._setup_logging()

        # Core subsystems
        self.audit = AuditLogger(config.security.audit)
        self.sandbox = Sandbox(
            self.workspace,
            shell_config=config.tools.shell,
            fs_config=config.tools.filesystem,
        )
        self.bus = MessageBus()
        self.session_manager = SessionManager(get_sessions_dir())
        self.provider = get_provider(config.providers)
        self.tool_registry = ToolRegistry(self.audit)
        self.channel_manager = ChannelManager(self.bus)
        self.hook_manager = HookManager()
        self.policy_engine = PolicyEngine(config.security)
        self.skill_loader = SkillLoader(self.workspace)

        # E-stop
        from workpilot.security.estop import EStop

        self.estop = EStop(events=self.bus.events, audit=self.audit)

        # Security classifier — wired for standard, controlled, AND restricted profiles.
        # For restricted, the classifier returns deny immediately (no LLM call).
        # For open, no classifier is needed (ApprovalGate allows all).
        self._classifier = None
        if (
            config.security.profile.value in ("standard", "controlled", "restricted")
            and self.provider
        ):
            from workpilot.security.classifier import SecurityClassifier

            self._classifier = SecurityClassifier(self.provider, profile=config.security.profile)

        # Approval manager and allowlist for human-in-the-loop approval routing
        from workpilot.security.approval import ApprovalManager

        self.approval_manager = ApprovalManager(config.security.approval)

        self._allowlist = None
        if config.security.allowlist.enabled:
            from workpilot.security.allowlist import AllowlistManager

            allowlist_path = (
                Path(config.security.allowlist.path) if config.security.allowlist.path else None
            )
            self._allowlist = AllowlistManager(allowlist_path)

        # Register built-in hook handlers
        # NOTE: Runtime wiring is tested via integration tests (not unit tests).
        from workpilot.hooks.handlers import register_builtin_handlers

        register_builtin_handlers(
            self.hook_manager,
            estop=self.estop,
            policy_engine=self.policy_engine,
            audit_logger=self.audit,
            classifier=self._classifier,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
            bus=self.bus.events,
            channel_manager=self.channel_manager,
            auto_approve_timeout=config.security.approval.auto_approve_timeout,
        )

        # Wire APPROVAL_RESOLVED events directly to ApprovalManager.resolve().
        # This bypasses the inbound message queue to avoid deadlock — the agent
        # loop blocks in the pre_tool_use hook while waiting for approval.
        from workpilot.bus.events import EventType

        async def _on_approval_resolved(event_type: EventType, payload: dict) -> None:
            action = payload.get("action", "")
            request_id = payload.get("request_id", "")
            resolver = payload.get("resolver", "unknown")
            if not request_id:
                return
            try:
                approved = action in ("approve", "always")
                self.approval_manager.resolve(request_id, approved=approved, resolver=resolver)
                if action == "always" and self._allowlist:
                    req = self.approval_manager.get_request(request_id)
                    if req:
                        self._allowlist.add(
                            req.tool_name, added_by=resolver, note="Added via always"
                        )
            except (KeyError, ValueError) as exc:
                logger.warning("Approval resolve failed: {}", exc)

        self.bus.events.on(EventType.APPROVAL_RESOLVED, _on_approval_resolved)

        # Scheduler (cron + interval + event + heartbeat)
        self.scheduler: SchedulerService | None = None
        if config.cron.enabled:
            from workpilot.cron.service import SchedulerService

            self.scheduler = SchedulerService(
                config.cron,
                self.workspace,
                bus=self.bus,
                active_channels_fn=lambda: list(self.channel_manager._channels.keys()),
            )

        # Optional subsystems (initialized lazily)
        self._graph_client: GraphClient | None = None
        self._gateway: GatewayServer | None = None
        self._mcp_clients: list[MCPClient] = []  # MCPClient instances for graceful shutdown
        self._copilot_service: Any = None  # set in _register_tools() if SDK available

        # Register built-in tools
        self._register_tools()

        # CronTool (agent self-scheduling — dynamically registered when cron.enabled)
        if self.scheduler:
            from workpilot.agent.tools.cron import CronTool

            self.tool_registry.register(CronTool(self.scheduler))

        # Merge built-in + user agents
        from workpilot.agents.builtin import get_builtin_agents, merge_agents

        self._all_agents = merge_agents(get_builtin_agents(), config.agents.agents)

        # Create agent loop for entrypoint
        agent_config = self._all_agents.get("default", config.agents.default)
        if config.entrypoint != "default" and config.entrypoint in self._all_agents:
            agent_config = self._all_agents[config.entrypoint]

        # Add "cron" to agent's tool list when scheduler enabled (copy to avoid mutating shared config)
        if self.scheduler and "cron" not in agent_config.tools:
            agent_config = agent_config.model_copy(update={"tools": [*agent_config.tools, "cron"]})

        # Load skills
        skills = self.skill_loader.load_all()

        self.agent = AgentLoop(
            config=agent_config,
            provider=self.provider,
            tool_registry=self.tool_registry,
            bus=self.bus,
            session_manager=self.session_manager,
            audit=self.audit,
            workspace=self.workspace,
            hooks=self.hook_manager,
            available_agents=self._all_agents,
            skills=skills,
            approval_manager=self.approval_manager,
            allowlist=self._allowlist,
        )

        logger.info(
            f"Runtime initialized: {config.name} v{__version__} "
            f"(profile={config.security.profile.value})"
        )

    def _setup_logging(self) -> None:
        import sys

        logger.remove()
        level = self.config.logging.level.value
        if self.config.logging.format == "json":
            logger.add(sys.stderr, level=level, serialize=True)
        else:
            logger.add(
                sys.stderr,
                level=level,
                format="<green>{time:HH:mm:ss}</green> | <level>{level: <8}</level> | {message}",
            )
        if self.config.logging.file:
            logger.add(self.config.logging.file, level=level, rotation="10 MB")

    def _register_tools(self) -> None:
        """Register all built-in tools."""
        # Core tools
        self.tool_registry.register(ShellTool(self.sandbox))
        self.tool_registry.register(ReadFileTool(self.sandbox))
        self.tool_registry.register(WriteFileTool(self.sandbox))
        self.tool_registry.register(EditFileTool(self.sandbox))
        self.tool_registry.register(ListDirTool(self.sandbox))
        self.tool_registry.register(SearchFilesTool(self.sandbox))
        self.tool_registry.register(GitTool(self.sandbox))
        self.tool_registry.register(HttpRequestTool())
        self.tool_registry.register(WebSearchTool())
        self.tool_registry.register(WebFetchTool())
        self.tool_registry.register(MessageTool(self.bus))

        # Browser tool (if enabled)
        if self.config.tools.browser.enabled:
            from workpilot.agent.tools.browser import BrowserTool

            self.tool_registry.register(BrowserTool(self.config.tools.browser))

        # Spawn tool (sub-agent support)
        from workpilot.agent.tools.spawn import SpawnTool

        self.tool_registry.register(SpawnTool(self._spawn_agent))

        # Copilot delegate tool (if enabled and copilot SDK is installed)
        if getattr(self.config.tools.copilot, "enabled", False):
            try:
                from workpilot.agent.tools.copilot import (
                    CopilotDelegateService,
                    CopilotDelegateTool,
                    CopilotModelsTool,
                    CopilotStatusTool,
                )

                gh_token = self.config.providers.github_copilot.token
                github_token = gh_token.get_secret_value() if gh_token else None
                self._copilot_service = CopilotDelegateService(
                    self.workspace,
                    self.bus,
                    config=self.config.tools.copilot,
                    github_token=github_token,
                )
                self.tool_registry.register(CopilotDelegateTool(self._copilot_service))
                self.tool_registry.register(CopilotStatusTool(self._copilot_service))
                self.tool_registry.register(CopilotModelsTool(self._copilot_service))
                logger.info("CopilotDelegate tools registered (github-copilot-sdk found)")
            except ImportError:
                self._copilot_service = None
                logger.debug("github-copilot-sdk not installed — gh_copilot tool disabled")
        else:
            logger.debug("CopilotDelegate tools disabled by configuration")

        # Graph tools (if enabled)
        if self.config.graph.enabled:
            self._setup_graph_tools()

        # MCP tools (if configured)
        if self.config.tools.mcp_servers:
            asyncio.get_event_loop().create_task(self._setup_mcp_tools())

        logger.debug(f"Registered {len(self.tool_registry.list_tools())} tools")

    def _setup_graph_tools(self) -> None:
        """Initialize Graph client and register Graph tools."""
        try:
            from workpilot.graph.auth import GraphAuth
            from workpilot.graph.client import GraphClient
            from workpilot.graph.tools import create_graph_tools

            auth = GraphAuth(self.config.graph.auth)
            self._graph_client = GraphClient(auth)
            for tool in create_graph_tools(self._graph_client):
                self.tool_registry.register(tool)
            logger.info("Microsoft Graph tools registered")
        except Exception as exc:
            logger.warning(f"Failed to setup Graph tools: {exc}")

    async def _setup_mcp_tools(self) -> None:
        """Connect to MCP servers and register their tools into the ToolRegistry."""
        from workpilot.mcp.adapter import register_mcp_tools
        from workpilot.mcp.client import MCPClient

        for name, server_config in self.config.tools.mcp_servers.items():
            try:
                client = MCPClient(
                    command=server_config.command,
                    args=server_config.args,
                    url=server_config.url,
                    name=name,
                )
                await client.connect()
                registered = await register_mcp_tools(self.tool_registry, client)
                logger.info(f"MCP server '{name}': {len(registered)} tools registered")
                self._mcp_clients.append(client)
            except Exception as exc:
                logger.warning(f"MCP server '{name}' failed: {exc}")

    async def _spawn_agent(
        self,
        agent_name: str,
        prompt: str,
        *,
        _depth: int = 1,
        _parent_session: str = "cli:local",
    ) -> str:
        """Spawn a sub-agent with scoped tools, permissions, and depth tracking."""
        # Look up agent from merged agents (cached on self)
        agent_config = self._all_agents.get(agent_name)
        if not agent_config:
            available = [k for k, v in self._all_agents.items() if not v.metadata.get("internal")]
            return f"Error: unknown agent '{agent_name}'. Available: {', '.join(available)}"

        # Spawn depth enforcement
        parent_config = self._all_agents.get("default", self.config.agents.default)
        max_depth = parent_config.max_spawn_depth
        if _depth > max_depth:
            return (
                f"Spawn depth limit reached (depth {_depth}, max {max_depth}). "
                "Cannot delegate further — handle this task directly."
            )

        # Exclude message + cron always. Exclude spawn at max depth.
        _ALWAYS_EXCLUDED = {"message", "cron"}
        excluded = _ALWAYS_EXCLUDED.copy()
        if _depth >= max_depth:
            excluded.add("spawn")
        scoped_tools = [t for t in agent_config.tools if t not in excluded]

        # Create scoped tool registry. If spawn is allowed (depth < max),
        # register a depth-incremented spawn callback for sub-sub-agents.
        scoped_registry = self.tool_registry.scoped_copy(scoped_tools)
        if "spawn" in scoped_tools and scoped_registry.get("spawn") is not None:
            from workpilot.agent.tools.spawn import SpawnTool

            next_depth = _depth + 1

            async def _child_spawn(name: str, p: str) -> str:
                return await self._spawn_agent(
                    name,
                    p,
                    _depth=next_depth,
                    _parent_session=_parent_session,
                )

            scoped_registry.unregister("spawn")
            scoped_registry.register(SpawnTool(_child_spawn))

        # Fork session for tracking (linked to parent)
        forked_session = self.session_manager.fork(_parent_session)

        sub_agent = AgentLoop(
            config=agent_config,
            provider=self.provider,
            tool_registry=scoped_registry,
            bus=self.bus,
            session_manager=self.session_manager,
            audit=self.audit,
            workspace=self.workspace,
            hooks=self.hook_manager,  # N4: sub-agents receive hooks
            prompt_mode="minimal",
        )
        return await sub_agent.run_once(prompt, session_id=forked_session)

    @property
    def graph_client(self) -> GraphClient | None:
        return self._graph_client

    # ── Run modes ─────────────────────────────────────────────────────────

    async def _start_cloud_if_enabled(self, *, interactive: bool = False) -> None:
        """Auto-connect the cloud channel on startup.

        interactive=False (default, run_chat):
            Silent credentials only. Skips if no cached token so the user
            is not interrupted mid-session. Run `workpilot cloud` once first.

        interactive=True (run_gateway):
            Full login flow — triggers browser/device-code auth when needed,
            matching the behaviour of the explicit `workpilot cloud` command.
        """
        from workpilot.channels.cloud import CloudChannel

        cloud_cfg = self.config.channels.cloud
        if not cloud_cfg.enabled:
            return
        if not cloud_cfg.url or not cloud_cfg.tenant_id or not cloud_cfg.client_id:
            logger.debug("Cloud relay: skipped — url/tenant_id/client_id not configured")
            return
        if self.channel_manager.get("cloud") is not None:
            return  # already registered (e.g. by `workpilot cloud` command)

        ch = CloudChannel(
            self.bus,
            url=cloud_cfg.url,
            tenant_id=cloud_cfg.tenant_id,
            client_id=cloud_cfg.client_id,
            scope=cloud_cfg.scope,
            login_method=cloud_cfg.login_method,
            login_port=cloud_cfg.login_port or self.config.gateway.port,
            allow_from=cloud_cfg.allow_from or None,
            auto_reconnect=cloud_cfg.auto_reconnect,
            reconnect_max=cloud_cfg.reconnect_max,
            bypass_token=cloud_cfg.bypass_token,
        )
        if not interactive and not ch.has_cached_credentials():
            logger.info(
                "Cloud relay: no cached credentials — run `workpilot cloud` once to authenticate"
            )
            return

        ch.set_runtime(self)  # allow admin relay to query Runtime APIs
        self.channel_manager.add(ch)
        try:
            await ch.start()
            logger.info("Cloud channel connected automatically")
        except Exception as exc:
            logger.warning("Cloud auto-connect failed: {}", exc)
            try:
                await ch.stop()
            except Exception:
                pass
            self.channel_manager.remove("cloud")

    async def run_prompt(self, prompt: str, session_id: str | None = None) -> str:
        """Run a single prompt and return the response."""
        return await self.agent.run_once(prompt, session_id)

    async def run_chat(self) -> None:
        """Start interactive CLI chat (Agent Mode)."""
        cli = CLIChannel(self.bus, prompt=self.config.channels.cli.prompt)
        self.channel_manager.add(cli)
        await self._start_cloud_if_enabled()
        await self.channel_manager.start_all()

        # Start agent loop in background
        agent_task = asyncio.create_task(self.agent.start())

        # Start scheduler if enabled
        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        try:
            await cli.run_repl()
        finally:
            if self.scheduler:
                await self.scheduler.stop()
            await self.agent.stop()
            await self.channel_manager.stop_all()
            agent_task.cancel()
            try:
                await agent_task
            except asyncio.CancelledError:
                pass

    async def run_gateway(self) -> None:
        """Start Gateway Mode (multi-channel HTTP server)."""
        from workpilot.channels.web import WebChannel
        from workpilot.gateway.server import GatewayServer

        # Create and register WebChannel with the bus
        web_channel = WebChannel(self.bus)
        self.channel_manager.add(web_channel)
        await web_channel.start()
        await self._start_cloud_if_enabled(interactive=True)

        self._gateway = GatewayServer(self.config.gateway, self)
        self._gateway.set_web_channel(web_channel)

        agent_task = asyncio.create_task(self.agent.start())

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        try:
            await self._gateway.start()
        finally:
            if self.scheduler:
                await self.scheduler.stop()
            await web_channel.stop()
            await self.agent.stop()
            await self.channel_manager.stop_all()
            agent_task.cancel()
            try:
                await agent_task
            except asyncio.CancelledError:
                pass

    async def run_cloud(self) -> None:
        """Cloud relay mode — cloud channel already started by the CLI command.

        Starts the agent loop and keeps the process alive until interrupted.
        The CloudChannel (registered via channel_manager.add before this call)
        handles WebSocket reconnection and message routing autonomously.
        """
        agent_task = asyncio.create_task(self.agent.start(), name="agent-loop")

        if self.scheduler:
            self.scheduler.set_agent_loop(self.agent)
            await self.scheduler.start()

        logger.info("Agent loop running — waiting for messages from Cloud Gateway…")

        try:
            # Block until cancelled (Ctrl+C)
            await asyncio.Event().wait()
        except (asyncio.CancelledError, KeyboardInterrupt):
            pass
        finally:
            if self.scheduler:
                await self.scheduler.stop()
            await self.agent.stop()
            await self.channel_manager.stop_all()
            agent_task.cancel()
            try:
                await agent_task
            except asyncio.CancelledError:
                pass

    async def shutdown(self) -> None:
        """Graceful shutdown of all subsystems."""
        await self.agent.stop()
        await self.channel_manager.stop_all()
        if self._gateway:
            await self._gateway.stop()
        # Disconnect MCP clients — copy and rebind to avoid races with concurrent setup
        clients_to_disconnect = list(self._mcp_clients)
        self._mcp_clients = []
        for client in clients_to_disconnect:
            try:
                await client.disconnect()
            except Exception as exc:
                logger.warning(f"MCP client disconnect error: {exc}")
        if self._copilot_service:
            await self._copilot_service.stop()
        logger.info("WorkPilot runtime shut down")
