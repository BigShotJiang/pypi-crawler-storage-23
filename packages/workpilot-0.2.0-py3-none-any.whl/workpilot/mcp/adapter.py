"""
MCP tool adapter — wraps external MCP tool descriptors as Tool ABC instances.

Each MCPToolAdapter adapts an MCP tool descriptor (from ``MCPClient.list_tools()``)
into a ``Tool`` that can be registered in the agent's ``ToolRegistry`` and used
by the LLM for function calling.

MCP tools are untrusted by default (``approval: "auto"``).
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.agent.tools.registry import PROTECTED_TOOLS, ToolRegistry
from workpilot.mcp.client import MCPClient


class MCPToolAdapter(Tool):
    """Adapts an MCP tool descriptor into the WorkPilot Tool ABC.

    Args:
        descriptor: MCP tool descriptor dict with ``name``, ``description``,
            and ``inputSchema`` keys (as returned by ``MCPClient.list_tools()``).
        mcp_client: The connected ``MCPClient`` used to invoke the tool.
        approval: Approval level for this tool (default ``"auto"``).
    """

    def __init__(
        self,
        descriptor: dict[str, Any],
        mcp_client: MCPClient,
        approval: str = "auto",
    ) -> None:
        self._descriptor = descriptor
        self._mcp_client = mcp_client
        self._tool_name: str = descriptor["name"]
        self._tool_description: str = descriptor.get("description", "")
        self._approval: str = approval
        self._input_schema: dict[str, Any] = descriptor.get(
            "inputSchema",
            {
                "type": "object",
                "properties": {},
            },
        )

    @property
    def name(self) -> str:
        return self._tool_name

    @property
    def description(self) -> str:
        return self._tool_description

    @property
    def parameters(self) -> dict[str, Any]:
        return self._input_schema

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(
            risk_level="medium",
            isolation="process",
            category="mcp",
            approval=self._approval,
            timeout=30,
            streaming=False,
        )

    def validate(self, args: dict[str, Any]) -> list[str]:
        """Basic validation — check required fields from input schema."""
        errors: list[str] = []
        required = self._input_schema.get("required", [])
        for field in required:
            if field not in args:
                errors.append(f"Missing required parameter: {field}")
        return errors

    async def execute(self, **kwargs: Any) -> str:
        """Execute the tool via the MCP client."""
        if not self._mcp_client.is_connected:
            return f"MCP server '{self._mcp_client.name}' is disconnected. Tool unavailable."
        try:
            return await self._mcp_client.call_tool(self._tool_name, kwargs)
        except (ConnectionError, RuntimeError, TimeoutError) as exc:
            logger.warning(f"MCP tool '{self._tool_name}' execution failed: {exc}")
            # Best-effort disconnect so the client doesn't hang
            try:
                await self._mcp_client.disconnect()
            except Exception:
                pass
            return (
                f"MCP tool '{self._tool_name}' failed: {exc}. "
                f"The MCP server '{self._mcp_client.name}' has been disconnected."
            )


async def register_mcp_tools(
    registry: ToolRegistry,
    mcp_client: MCPClient,
    *,
    security_profile: str | None = None,
) -> list[str]:
    """Discover tools from an MCP server and register them in the ToolRegistry.

    Skips tools whose names collide with protected built-in tool names
    (anti-shadowing). Returns the list of successfully registered tool names.

    Args:
        registry: The agent's tool registry.
        mcp_client: A connected ``MCPClient``.
        security_profile: Optional security profile name. If ``"restricted"``,
            all MCP tools require explicit approval (``approval="always"``).

    Returns:
        List of registered tool names.
    """
    approval = "always" if security_profile == "restricted" else "auto"

    try:
        descriptors = await mcp_client.list_tools()
    except Exception as exc:
        logger.warning(f"MCP server '{mcp_client.name}': failed to list tools: {exc}")
        return []

    registered: list[str] = []
    for descriptor in descriptors:
        tool_name = descriptor.get("name", "")
        if not tool_name:
            logger.warning(f"MCP server '{mcp_client.name}': skipping tool with empty name")
            continue

        if tool_name in PROTECTED_TOOLS:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{tool_name}' "
                f"— name conflicts with protected built-in tool"
            )
            continue

        # Warn and skip if a tool with the same name is already registered
        if registry.get(tool_name) is not None:
            logger.warning(
                f"MCP server '{mcp_client.name}': skipping tool '{tool_name}' "
                f"— namespace collision with already-registered tool"
            )
            continue

        adapter = MCPToolAdapter(descriptor, mcp_client, approval=approval)
        try:
            registry.register(adapter)
            registered.append(tool_name)
        except ValueError as exc:
            logger.warning(
                f"MCP server '{mcp_client.name}': failed to register tool '{tool_name}': {exc}"
            )

    logger.info(
        f"MCP server '{mcp_client.name}': registered {len(registered)}/{len(descriptors)} tools"
    )
    return registered
