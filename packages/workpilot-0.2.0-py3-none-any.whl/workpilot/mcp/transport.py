"""
MCP transport layer — abstractions for stdio and HTTP/SSE communication.

Provides pluggable transports for the Model Context Protocol (MCP) using
JSON-RPC 2.0 message framing over stdin/stdout or HTTP.
"""

from __future__ import annotations

import asyncio
import json
from abc import ABC, abstractmethod
from typing import Any

import httpx
from loguru import logger


class MCPTransport(ABC):
    """Abstract transport for MCP JSON-RPC communication."""

    @abstractmethod
    async def start(self) -> None:
        """Open the transport connection."""

    @abstractmethod
    async def send(self, data: dict[str, Any]) -> None:
        """Send a JSON-RPC message."""

    @abstractmethod
    async def receive(self) -> dict[str, Any]:
        """Receive the next JSON-RPC message (blocks until available)."""

    @abstractmethod
    async def close(self) -> None:
        """Close the transport and release resources."""


class StdioTransport(MCPTransport):
    """
    Communicate with an MCP server via subprocess stdin/stdout.

    Each message is a single JSON line terminated by newline.
    """

    def __init__(self, command: str, args: list[str] | None = None) -> None:
        self._command = command
        self._args = args or []
        self._process: asyncio.subprocess.Process | None = None
        self._read_lock = asyncio.Lock()

    async def start(self) -> None:
        """Spawn the subprocess and prepare stdin/stdout streams."""
        logger.debug(f"StdioTransport: spawning {self._command} {self._args}")
        self._process = await asyncio.create_subprocess_exec(
            self._command,
            *self._args,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        logger.info(f"StdioTransport: process started (pid={self._process.pid})")

    async def send(self, data: dict[str, Any]) -> None:
        """Write a JSON-RPC message to the subprocess stdin."""
        if self._process is None or self._process.stdin is None:
            raise RuntimeError("StdioTransport: not connected — call start() first")

        line = json.dumps(data) + "\n"
        self._process.stdin.write(line.encode("utf-8"))
        await self._process.stdin.drain()
        logger.debug(f"StdioTransport: sent message id={data.get('id')}")

    async def receive(self) -> dict[str, Any]:
        """Read the next JSON-RPC message from subprocess stdout."""
        if self._process is None or self._process.stdout is None:
            raise RuntimeError("StdioTransport: not connected — call start() first")

        async with self._read_lock:
            raw = await self._process.stdout.readline()
            if not raw:
                raise ConnectionError("StdioTransport: subprocess stdout closed")

        line = raw.decode("utf-8").strip()
        if not line:
            raise ConnectionError("StdioTransport: received empty line")

        try:
            return json.loads(line)  # type: ignore[no-any-return]
        except json.JSONDecodeError as exc:
            raise ConnectionError(f"StdioTransport: invalid JSON from subprocess: {exc}") from exc

    async def close(self) -> None:
        """Terminate the subprocess gracefully."""
        if self._process is None:
            return

        logger.debug("StdioTransport: closing subprocess")
        if self._process.stdin is not None:
            self._process.stdin.close()

        try:
            await asyncio.wait_for(self._process.wait(), timeout=5.0)
        except TimeoutError:
            logger.warning("StdioTransport: subprocess did not exit, killing")
            self._process.kill()
            await self._process.wait()

        self._process = None
        logger.info("StdioTransport: subprocess closed")

    @property
    def is_running(self) -> bool:
        """Check if the subprocess is still alive."""
        return self._process is not None and self._process.returncode is None


class HttpTransport(MCPTransport):
    """
    Communicate with an MCP server via HTTP POST / Server-Sent Events (SSE).

    - send(): POST JSON-RPC messages to the server endpoint.
    - receive(): Read SSE events from the server's event stream.
    """

    def __init__(self, url: str, *, headers: dict[str, str] | None = None) -> None:
        self._url = url.rstrip("/")
        self._headers = headers or {}
        self._client: httpx.AsyncClient | None = None
        self._sse_response: httpx.Response | None = None
        self._sse_iter: Any = None
        self._message_queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue()
        self._sse_task: asyncio.Task[None] | None = None

    async def start(self) -> None:
        """Initialize the HTTP client and start the SSE listener."""
        logger.debug(f"HttpTransport: connecting to {self._url}")
        self._client = httpx.AsyncClient(
            timeout=60.0,
            headers={
                "Content-Type": "application/json",
                **self._headers,
            },
        )
        # Start SSE listener in background
        self._sse_task = asyncio.create_task(self._listen_sse())
        logger.info(f"HttpTransport: connected to {self._url}")

    async def send(self, data: dict[str, Any]) -> None:
        """POST a JSON-RPC message to the MCP server."""
        if self._client is None:
            raise RuntimeError("HttpTransport: not connected — call start() first")

        logger.debug(f"HttpTransport: sending message id={data.get('id')}")
        response = await self._client.post(self._url, json=data)
        response.raise_for_status()

        # If the server returns a JSON-RPC response directly (non-SSE mode),
        # enqueue it so receive() can pick it up.
        content_type = response.headers.get("content-type", "")
        if "application/json" in content_type:
            try:
                body = response.json()
                if isinstance(body, dict) and "jsonrpc" in body:
                    await self._message_queue.put(body)
            except (json.JSONDecodeError, ValueError):
                pass

    async def receive(self) -> dict[str, Any]:
        """Get the next JSON-RPC message (from SSE stream or direct response)."""
        return await self._message_queue.get()

    async def _listen_sse(self) -> None:
        """Background task that reads Server-Sent Events and enqueues messages."""
        if self._client is None:
            return

        sse_url = self._url.rstrip("/") + "/sse"
        try:
            async with self._client.stream("GET", sse_url) as response:
                self._sse_response = response
                buffer = ""
                async for chunk in response.aiter_text():
                    buffer += chunk
                    while "\n\n" in buffer:
                        event_block, buffer = buffer.split("\n\n", 1)
                        message = self._parse_sse_event(event_block)
                        if message is not None:
                            await self._message_queue.put(message)
        except httpx.HTTPError as exc:
            logger.warning(f"HttpTransport: SSE connection error: {exc}")
        except asyncio.CancelledError:
            logger.debug("HttpTransport: SSE listener cancelled")

    @staticmethod
    def _parse_sse_event(block: str) -> dict[str, Any] | None:
        """Parse a single SSE event block into a JSON-RPC message."""
        data_lines: list[str] = []
        for line in block.split("\n"):
            if line.startswith("data:"):
                data_lines.append(line[5:].strip())
        if not data_lines:
            return None
        raw = "\n".join(data_lines)
        try:
            return json.loads(raw)  # type: ignore[no-any-return]
        except json.JSONDecodeError:
            logger.debug(f"HttpTransport: non-JSON SSE data: {raw[:100]}")
            return None

    async def close(self) -> None:
        """Close the HTTP client and cancel the SSE listener."""
        if self._sse_task is not None:
            self._sse_task.cancel()
            try:
                await self._sse_task
            except asyncio.CancelledError:
                pass
            self._sse_task = None

        if self._client is not None:
            await self._client.aclose()
            self._client = None

        logger.info("HttpTransport: closed")
