"""
MCP server — exposes WorkPilot tools to external MCP clients.

Handles JSON-RPC 2.0 requests for tool discovery and execution,
with support for stdio and HTTP transports.
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Any

from loguru import logger

from workpilot.agent.tools.registry import ToolRegistry


class MCPServer:
    """
    MCP server that exposes a ToolRegistry to external clients.

    Supports:
    - **stdio**: reads JSON-RPC from stdin, writes to stdout
    - **http**: runs an HTTP endpoint accepting JSON-RPC POST requests

    Usage::

        registry = ToolRegistry()
        server = MCPServer(registry)
        await server.start_stdio()   # or
        await server.start_http("0.0.0.0", 8080)
    """

    def __init__(
        self,
        registry: ToolRegistry,
        *,
        server_name: str = "workpilot",
        server_version: str = "0.1.0",
    ) -> None:
        self._registry = registry
        self._server_name = server_name
        self._server_version = server_version

    # ------------------------------------------------------------------
    # JSON-RPC dispatch
    # ------------------------------------------------------------------

    async def handle_request(self, data: dict[str, Any]) -> dict[str, Any]:
        """
        Dispatch a JSON-RPC 2.0 request and return the response.

        Supported methods:
        - ``initialize``: handshake with protocol version and capabilities
        - ``tools/list``: enumerate available tools
        - ``tools/call``: invoke a tool by name
        """
        method = data.get("method", "")
        params = data.get("params", {})
        request_id = data.get("id")

        # Notifications (no id) don't get a response
        if request_id is None:
            logger.debug(f"MCPServer: notification received: {method}")
            return {}

        logger.debug(f"MCPServer: handling {method} (id={request_id})")

        handler = self._METHOD_MAP.get(method)
        if handler is None:
            return self._error_response(request_id, -32601, f"Method not found: {method}")

        try:
            result = await handler(self, params)
            return self._success_response(request_id, result)
        except Exception as exc:
            logger.error(f"MCPServer: error handling {method}: {exc}")
            return self._error_response(request_id, -32603, str(exc))

    # ------------------------------------------------------------------
    # Method handlers
    # ------------------------------------------------------------------

    async def _handle_initialize(self, params: dict[str, Any]) -> dict[str, Any]:
        """Handle the MCP initialize handshake."""
        logger.info(
            f"MCPServer: initialize from {params.get('clientInfo', {}).get('name', 'unknown')}"
        )
        return {
            "protocolVersion": "2024-11-05",
            "capabilities": {
                "tools": {"listChanged": False},
            },
            "serverInfo": {
                "name": self._server_name,
                "version": self._server_version,
            },
        }

    async def _handle_tools_list(self, params: dict[str, Any]) -> dict[str, Any]:
        """Return the list of available tools with JSON Schema descriptions."""
        tools = self._registry.list_tools()
        tool_descriptors: list[dict[str, Any]] = []
        for tool in tools:
            tool_descriptors.append(
                {
                    "name": tool.name,
                    "description": tool.description,
                    "inputSchema": tool.parameters,
                }
            )
        logger.debug(f"MCPServer: listing {len(tool_descriptors)} tools")
        return {"tools": tool_descriptors}

    async def _handle_tools_call(self, params: dict[str, Any]) -> dict[str, Any]:
        """Execute a tool and return the result."""
        name = params.get("name")
        arguments = params.get("arguments", {})

        if not name:
            raise ValueError("Missing required parameter: 'name'")

        tool = self._registry.get(name)
        if tool is None:
            raise ValueError(f"Unknown tool: '{name}'")

        logger.info(f"MCPServer: calling tool '{name}'")
        result = await self._registry.execute(name, arguments, actor="mcp-client")

        return {
            "content": [
                {"type": "text", "text": result},
            ],
        }

    # Method dispatch table
    _METHOD_MAP: dict[str, Any] = {
        "initialize": _handle_initialize,
        "tools/list": _handle_tools_list,
        "tools/call": _handle_tools_call,
    }

    # ------------------------------------------------------------------
    # Response helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _success_response(request_id: int | str, result: Any) -> dict[str, Any]:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "result": result,
        }

    @staticmethod
    def _error_response(
        request_id: int | str | None,
        code: int,
        message: str,
    ) -> dict[str, Any]:
        return {
            "jsonrpc": "2.0",
            "id": request_id,
            "error": {
                "code": code,
                "message": message,
            },
        }

    # ------------------------------------------------------------------
    # Transports
    # ------------------------------------------------------------------

    async def start_stdio(self) -> None:
        """
        Run the MCP server over stdio (stdin/stdout).

        Reads newline-delimited JSON-RPC from stdin and writes responses
        to stdout. Runs until stdin is closed or the process is interrupted.
        """
        logger.info("MCPServer: starting stdio transport")
        reader = asyncio.StreamReader()
        protocol = asyncio.StreamReaderProtocol(reader)

        loop = asyncio.get_event_loop()
        await loop.connect_read_pipe(lambda: protocol, sys.stdin)

        try:
            while True:
                raw = await reader.readline()
                if not raw:
                    break

                line = raw.decode("utf-8").strip()
                if not line:
                    continue

                try:
                    data = json.loads(line)
                except json.JSONDecodeError:
                    logger.warning(f"MCPServer: invalid JSON on stdin: {line[:100]}")
                    continue

                response = await self.handle_request(data)
                if response:
                    out = json.dumps(response) + "\n"
                    sys.stdout.write(out)
                    sys.stdout.flush()
        except asyncio.CancelledError:
            pass

        logger.info("MCPServer: stdio transport stopped")

    async def start_http(self, host: str = "0.0.0.0", port: int = 8080) -> None:
        """
        Run the MCP server as an HTTP endpoint.

        Accepts JSON-RPC POST requests and returns JSON responses.
        Uses a minimal asyncio-based HTTP server (no framework dependency).

        Args:
            host: Bind address.
            port: Bind port.
        """
        logger.info(f"MCPServer: starting HTTP transport on {host}:{port}")

        async def handle_connection(
            reader: asyncio.StreamReader,
            writer: asyncio.StreamWriter,
        ) -> None:
            try:
                # Read HTTP request
                request_line = await reader.readline()
                if not request_line:
                    writer.close()
                    return

                # Read headers
                headers: dict[str, str] = {}
                while True:
                    header_line = await reader.readline()
                    if header_line in (b"\r\n", b"\n", b""):
                        break
                    decoded = header_line.decode("utf-8").strip()
                    if ":" in decoded:
                        key, value = decoded.split(":", 1)
                        headers[key.strip().lower()] = value.strip()

                # Read body
                content_length = int(headers.get("content-length", "0"))
                body = b""
                if content_length > 0:
                    body = await reader.readexactly(content_length)

                # Parse and handle JSON-RPC
                try:
                    data = json.loads(body.decode("utf-8"))
                    response = await self.handle_request(data)
                    response_body = json.dumps(response).encode("utf-8")
                    status = "200 OK"
                except (json.JSONDecodeError, ValueError) as exc:
                    error_resp = self._error_response(None, -32700, f"Parse error: {exc}")
                    response_body = json.dumps(error_resp).encode("utf-8")
                    status = "400 Bad Request"

                # Write HTTP response
                http_response = (
                    f"HTTP/1.1 {status}\r\n"
                    f"Content-Type: application/json\r\n"
                    f"Content-Length: {len(response_body)}\r\n"
                    f"Connection: close\r\n"
                    f"\r\n"
                ).encode() + response_body

                writer.write(http_response)
                await writer.drain()
            except Exception as exc:
                logger.error(f"MCPServer HTTP: connection error: {exc}")
            finally:
                writer.close()

        server = await asyncio.start_server(handle_connection, host, port)

        logger.info(f"MCPServer: HTTP server listening on {host}:{port}")
        try:
            async with server:
                await server.serve_forever()
        except asyncio.CancelledError:
            pass

        logger.info("MCPServer: HTTP transport stopped")
