"""
Shell execution tool — sandboxed command runner with deny-pattern guards,
workspace restriction, output truncation, and timeout enforcement.
"""

from __future__ import annotations

import asyncio
import os
from typing import Any

from workpilot.agent.tools.base import Tool, ToolMetadata
from workpilot.security.sandbox import CommandDeniedError, Sandbox


class ShellTool(Tool):
    """Execute shell commands within the workspace sandbox."""

    def __init__(self, sandbox: Sandbox) -> None:
        self._sandbox = sandbox

    @property
    def metadata(self) -> ToolMetadata:
        return ToolMetadata(risk_level="medium", approval="auto", timeout=600, streaming=True)

    @property
    def name(self) -> str:
        return "shell"

    @property
    def description(self) -> str:
        return (
            "Execute a shell command. Use for git, builds, tests, and system operations. "
            "Commands run inside the workspace directory with timeout enforcement."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute",
                },
            },
            "required": ["command"],
        }

    async def execute(self, **kwargs: Any) -> str:
        command: str = kwargs["command"]

        # Security check
        try:
            self._sandbox.check_command(command)
        except CommandDeniedError as exc:
            return f"BLOCKED: {exc}"

        try:
            proc = await asyncio.create_subprocess_shell(
                command,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                cwd=str(self._sandbox.workspace),
                env={**os.environ},
            )

            # Stream stdout line-by-line when progress callback is available
            if self._progress and proc.stdout:
                stdout_lines: list[str] = []
                try:

                    async def _read_stdout() -> None:
                        assert proc.stdout is not None
                        while True:
                            line = await proc.stdout.readline()
                            if not line:
                                break
                            decoded = line.decode("utf-8", errors="replace")
                            stdout_lines.append(decoded)
                            if self._progress:
                                await self._progress(decoded)

                    async def _read_stderr() -> bytes:
                        assert proc.stderr is not None
                        return await proc.stderr.read()

                    stderr_bytes, _ = await asyncio.wait_for(
                        asyncio.gather(_read_stderr(), _read_stdout()),
                        timeout=self._sandbox.shell_timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {self._sandbox.shell_timeout}s"

                await proc.wait()
                stdout_text = "".join(stdout_lines)
                stderr_text = stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else ""
            else:
                # Non-streaming path (original behavior)
                try:
                    stdout_raw, stderr_raw = await asyncio.wait_for(
                        proc.communicate(),
                        timeout=self._sandbox.shell_timeout,
                    )
                except TimeoutError:
                    proc.kill()
                    await proc.wait()
                    return f"Command timed out after {self._sandbox.shell_timeout}s"
                stdout_text = stdout_raw.decode("utf-8", errors="replace") if stdout_raw else ""
                stderr_text = stderr_raw.decode("utf-8", errors="replace") if stderr_raw else ""

            output_parts: list[str] = []
            if stdout_text:
                output_parts.append(stdout_text)
            if stderr_text:
                output_parts.append(stderr_text)

            output = "\n".join(output_parts).strip() or "(no output)"

            # Truncate
            max_chars = self._sandbox.max_output_chars
            if len(output) > max_chars:
                output = output[:max_chars] + "\n...(truncated)"

            if proc.returncode != 0:
                output = f"Exit code {proc.returncode}\n{output}"

            return output

        except Exception as exc:
            return f"Shell error: {exc}"
