---
name: ado
description: Azure DevOps work item, PR, pipeline and repo operations via az devops CLI
metadata:
  workpilot:
    activation:
      keywords: [ado, azure devops, work item, pipeline, boards, pull request, pr, repos, sprint]
    requires:
      bins: [az]
    always: false
---
## Azure DevOps Operations

Use the `shell` tool with `az devops` CLI commands.

**Before running az devops commands**, verify authentication by running `az account show`. If it fails, prompt the user to run `az login`. Also ensure the devops extension is installed: `az extension add --name azure-devops`.

### Setup (run once per session if needed)
```
az devops configure --defaults organization=https://dev.azure.com/{ORG} project={PROJECT}
```

### Projects
```
az devops project list -o json
az devops project show --project {NAME} -o json
```

### Work Items
```
az boards work-item show --id {ID} -o json
az boards work-item create --type "User Story" --title "..." --assigned-to "user@example.com" -o json
az boards work-item update --id {ID} --state "Active" -o json
az boards query --wiql "SELECT [System.Id],[System.Title],[System.State] FROM WorkItems WHERE [System.AssignedTo] = @Me AND [System.State] <> 'Closed' ORDER BY [System.ChangedDate] DESC" -o json
```

### Pull Requests
```
az repos pr list --status active -o json
az repos pr show --id {ID} -o json
az repos pr create --repository {REPO} --source-branch {SRC} --target-branch main --title "..." -o json
az repos pr set-vote --id {ID} --vote approve -o json
az repos pr update --id {ID} --status completed -o json
az repos pr reviewers add --id {ID} --reviewers "user@example.com" -o json
```

### Pipelines
```
az pipelines list -o json
az pipelines show --id {ID} -o json
az pipelines run --id {ID} --branch main -o json
az pipelines runs list --pipeline-id {ID} -o json
az pipelines runs show --id {RUN_ID} -o json
```

### Repos
```
az repos list -o json
az repos show --repository {NAME} -o json
```

### Boards & Sprints
```
az boards iteration team list-work-items --team {TEAM} --iteration {PATH} -o json
```

### Guidelines
- Always use `-o json` for structured output
- Use `--query` (JMESPath) to filter large results: `--query "[].{id:id, title:fields.\"System.Title\"}"`
- Write operations (create, update, delete) are medium-risk — confirm with user first
- The az devops extension must be installed: `az extension add --name azure-devops`
- WIQL queries use SQL-like syntax specific to Azure DevOps, not standard SQL
