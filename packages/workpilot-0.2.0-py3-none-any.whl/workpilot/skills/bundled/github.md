---
name: github
description: GitHub PR and Issue workflow assistance
metadata:
  workpilot:
    activation:
      keywords: [github, pr, pull request, issue, merge]
    requires:
      bins: [gh]
    always: false
---
## GitHub Workflow

When working with GitHub:
1. Always create feature branches from main
2. Write clear PR descriptions with ## Summary and ## Test Plan sections
3. Link related issues using "Fixes #123" syntax
4. Request reviews from relevant team members
