"""
Skill loader — discovers and loads markdown-based prompt skills.

Skills are .md files with YAML frontmatter.  Three metadata namespaces
are supported for cross-platform portability:

- ``metadata.workpilot`` — WorkPilot native (activation keywords, requires, always)
- ``metadata.nanobot`` — nanobot compat (requires, emoji, install)
- ``metadata.openclaw`` — OpenClaw compat (requires, always, emoji, os, install)

nanobot uses single-line JSON for metadata; OpenClaw uses nested YAML.
Both are parsed correctly by ``yaml.safe_load``.

Sources (load order — later overrides earlier by name):

1. Built-in bundled skills  (workpilot/skills/bundled/*.md)
2. User workspace skills    (.workpilot/skills/*.md  or  skills/*.md)
"""

from __future__ import annotations

import json
import os
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import yaml
from loguru import logger

# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------

SkillMode = Literal["always", "available"]


@dataclass
class Skill:
    """A single loaded skill."""

    name: str
    description: str
    content: str  # the markdown prompt body (after frontmatter)
    mode: SkillMode = "available"
    triggers: list[str] = field(default_factory=list)
    requires_bins: list[str] = field(default_factory=list)
    requires_env: list[str] = field(default_factory=list)
    source_path: str = ""  # relative path for read_file discovery

    # ── helpers ──────────────────────────────────────────────────────────

    def matches(self, text: str) -> bool:
        """Return True if *text* contains any of this skill's trigger keywords."""
        lower = text.lower()
        return any(trigger.lower() in lower for trigger in self.triggers)

    def check_requirements(self) -> list[str]:
        """Return list of missing requirements (bin or env var names)."""
        missing: list[str] = []
        for b in self.requires_bins:
            if shutil.which(b) is None:
                missing.append(b)
        for e in self.requires_env:
            if not os.environ.get(e):
                missing.append(e)
        return missing

    @property
    def available(self) -> bool:
        """True when all requirements are met."""
        return len(self.check_requirements()) == 0


# ---------------------------------------------------------------------------
# Frontmatter parser
# ---------------------------------------------------------------------------

_FRONTMATTER_RE = re.compile(
    r"\A\s*---\s*\n(?P<meta>.*?)\n---\s*\n(?P<body>.*)",
    re.DOTALL,
)


def _resolve_metadata(meta: dict) -> dict:
    """Extract the platform-specific metadata dict from frontmatter.

    Checks namespaces in priority order: workpilot → nanobot → openclaw.
    nanobot stores metadata as a single-line JSON string; handle both
    parsed dict and raw string.
    """
    raw_metadata = meta.get("metadata", {})

    # nanobot sometimes writes metadata as a JSON string
    if isinstance(raw_metadata, str):
        try:
            raw_metadata = json.loads(raw_metadata)
        except (json.JSONDecodeError, TypeError):
            return {}

    if not isinstance(raw_metadata, dict):
        return {}

    # Priority: workpilot > nanobot > openclaw (+ aliases clawdbot, clawdis)
    for ns in ("workpilot", "nanobot", "openclaw", "clawdbot", "clawdis"):
        if ns in raw_metadata and isinstance(raw_metadata[ns], dict):
            return dict(raw_metadata[ns])
    return {}


def _parse_skill_file(path: Path) -> Skill | None:
    """Parse a single .md skill file with YAML frontmatter.

    Supports three metadata namespaces for cross-platform portability:
    ``metadata.workpilot``, ``metadata.nanobot``, ``metadata.openclaw``.
    Also supports legacy flat format (``mode``, ``triggers``).

    Returns ``None`` if the file cannot be parsed.
    """
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as exc:
        logger.warning("Cannot read skill file {}: {}", path, exc)
        return None

    match = _FRONTMATTER_RE.match(raw)
    if not match:
        logger.warning("Skill file {} missing YAML frontmatter — skipped", path)
        return None

    try:
        meta: dict = yaml.safe_load(match.group("meta")) or {}
    except yaml.YAMLError as exc:
        logger.warning("Invalid YAML frontmatter in {}: {}", path, exc)
        return None

    name = meta.get("name", path.stem)
    description = meta.get("description", "")

    # ── Resolve platform metadata (workpilot / nanobot / openclaw) ─────
    ns: dict[str, Any] = _resolve_metadata(meta)
    activation: dict = ns.get("activation", {})
    requires: dict = ns.get("requires", {})

    # Keywords: activation.keywords (WorkPilot extension) → fallback to flat triggers
    triggers_raw = activation.get("keywords") or meta.get("triggers", [])
    if isinstance(triggers_raw, str):
        triggers_raw = [t.strip() for t in triggers_raw.split(",")]
    triggers: list[str] = [str(t) for t in triggers_raw]

    # Mode: ns.always → fallback to flat mode
    ns_always = ns.get("always")
    if ns_always is not None:
        mode: SkillMode = "always" if ns_always else "available"
    else:
        mode = meta.get("mode", "available")
        if mode not in ("always", "available"):
            logger.warning("Skill {} has invalid mode '{}' — defaulting to 'available'", name, mode)
            mode = "available"

    # Requirements: requires.bins / requires.env (normalize scalar → list)
    bins_raw = requires.get("bins") or []
    if isinstance(bins_raw, str):
        bins_raw = [bins_raw]
    requires_bins: list[str] = [str(b) for b in bins_raw]

    env_raw = requires.get("env") or []
    if isinstance(env_raw, str):
        env_raw = [env_raw]
    requires_env: list[str] = [str(e) for e in env_raw]

    body = match.group("body").strip()

    return Skill(
        name=name,
        description=description,
        content=body,
        mode=mode,
        triggers=triggers,
        requires_bins=requires_bins,
        requires_env=requires_env,
    )


# ---------------------------------------------------------------------------
# Loader
# ---------------------------------------------------------------------------


class SkillLoader:
    """Discover and load skills from bundled and workspace directories."""

    def __init__(
        self,
        workspace: Path,
        skills_dir: Path | None = None,
    ) -> None:
        self._workspace = workspace
        self._skills_dir = skills_dir
        self._skills: list[Skill] = []
        self._loaded = False

    # ── public API ───────────────────────────────────────────────────────

    def load_all(self) -> list[Skill]:
        """Load skills from all sources and return the combined list.

        This method is idempotent — calling it multiple times reloads from
        disk each time so config changes are picked up.
        """
        self._skills = []

        # 1. Built-in bundled skills
        bundled_dir = Path(__file__).parent / "bundled"
        self._load_from_dir(bundled_dir, label="bundled")

        # 2. User / workspace skills
        if self._skills_dir is not None:
            self._load_from_dir(self._skills_dir, label="custom")
        else:
            # Convention: look in .workpilot/skills/ first, then skills/
            for candidate in (
                self._workspace / ".workpilot" / "skills",
                self._workspace / "skills",
            ):
                if candidate.is_dir():
                    self._load_from_dir(candidate, label="workspace")

        self._loaded = True
        logger.info("Loaded {} skill(s) total", len(self._skills))
        return list(self._skills)

    def get_always_loaded(self) -> list[Skill]:
        """Return skills whose mode is ``always``."""
        self._ensure_loaded()
        return [s for s in self._skills if s.mode == "always"]

    def get_available(self) -> list[Skill]:
        """Return skills whose mode is ``available`` (on-demand)."""
        self._ensure_loaded()
        return [s for s in self._skills if s.mode == "available"]

    def find_by_trigger(self, text: str) -> list[Skill]:
        """Return all skills whose triggers match *text*."""
        self._ensure_loaded()
        return [s for s in self._skills if s.matches(text)]

    # ── internals ────────────────────────────────────────────────────────

    def _ensure_loaded(self) -> None:
        """Lazy-load skills if :meth:`load_all` has not been called yet."""
        if not self._loaded:
            self.load_all()

    def _load_from_dir(self, directory: Path, *, label: str = "") -> None:
        """Load all ``*.md`` files from *directory*."""
        if not directory.is_dir():
            logger.debug("Skills directory does not exist: {} ({})", directory, label)
            return

        md_files = sorted(directory.glob("*.md"))
        if not md_files:
            logger.debug("No .md skill files in {} ({})", directory, label)
            return

        for path in md_files:
            skill = _parse_skill_file(path)
            if skill is not None:
                # Store relative source path for read_file discovery.
                # Bundled skills outside the workspace get no path (sandbox blocks absolute paths).
                try:
                    skill.source_path = str(path.relative_to(self._workspace))
                except ValueError:
                    skill.source_path = ""
                # Deduplicate by name — later sources override earlier ones
                self._skills = [s for s in self._skills if s.name != skill.name]
                self._skills.append(skill)
                logger.debug("Loaded skill '{}' from {} ({})", skill.name, path.name, label)
