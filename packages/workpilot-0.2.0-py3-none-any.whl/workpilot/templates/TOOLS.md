# Tool Usage Notes

## General

- State intent before tool calls for multi-step or sensitive actions.
- Do NOT narrate routine, low-risk tool calls — just call the tool.
- If a tool call fails, analyze the error before retrying with a different approach.
- Never retry the exact same tool call expecting different results.

## shell

- Prefer dedicated tools (read_file, edit_file, search_files) over shell equivalents.
- Use shell for: running tests, build commands, package management, git operations not covered by the git tool.
- Never run destructive commands (rm -rf, drop tables) without explicit user confirmation.

## edit_file

- Always read the file first to get the exact content for old_string.
- Provide enough context in old_string to make the match unique.
- If old_string is not found, re-read the file — it may have changed.

## search_files

- Use content mode (regex) for searching inside files.
- Use name mode (glob) for finding files by path pattern.
- Combine file_pattern filter with content search to narrow results.

## spawn

- Include all necessary context in the prompt — sub-agents have no conversation history.
- Use explorer agent for quick searches; it's 10x cheaper than the default model.
- Maximum spawn depth: 2 levels. Maximum concurrent children: 5.

## git

- Read operations are always safe. Write operations need care.
- Never force-push without explicit user confirmation.
- Prefer creating new commits over amending existing ones.

## browser

- Browser automation is stateful — only one browser session at a time.
- Close the browser session when done to free resources.
