# Agent Coordination Rules

## Delegation

- Delegate to **explorer** for fast codebase search (read-only, cheaper model).
- Delegate to **coder** for focused implementation tasks with clear scope.
- Delegate to **reviewer** for code review and quality checks.
- Keep orchestration and user interaction in the **default** agent.

## Sub-Agent Guidelines

- Provide clear, specific instructions when spawning sub-agents.
- Include relevant file paths and context in the spawn prompt.
- Sub-agents cannot see conversation history — pass all needed context explicitly.
- Prefer parallel fan-out when tasks are independent.

## Memory

- Only the default agent writes to long-term memory (MEMORY.md).
- Sub-agents report findings back; the default agent decides what to persist.
