"""
Graph capabilities exposed as Agent tools.

``create_graph_tools`` returns a list of ``Tool`` subclasses wired to
a ``GraphClient`` so the agent loop can invoke mail / Teams operations
through the standard tool-call interface.
"""

from __future__ import annotations

import json
from typing import Any

from workpilot.agent.tools.base import Tool
from workpilot.graph.client import GraphClient
from workpilot.graph.mail import MailClient
from workpilot.graph.teams import TeamsGraphClient

# ── Tool implementations ────────────────────────────────────────────────────


class GraphMailListTool(Tool):
    """List emails from a mail folder."""

    def __init__(self, mail: MailClient) -> None:
        self._mail = mail

    @property
    def name(self) -> str:
        return "graph_mail_list"

    @property
    def description(self) -> str:
        return "List emails from a mailbox folder. Returns subject, sender, date, and body preview."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "folder": {
                    "type": "string",
                    "description": "Mail folder name (default: inbox)",
                    "default": "inbox",
                },
                "top": {
                    "type": "integer",
                    "description": "Max messages to return (default: 10)",
                    "default": 10,
                },
                "filter": {
                    "type": "string",
                    "description": "OData $filter expression (optional)",
                },
            },
            "required": [],
        }

    async def execute(self, **kwargs: Any) -> str:
        folder: str = kwargs.get("folder", "inbox")
        top: int = kwargs.get("top", 10)
        filter_str: str | None = kwargs.get("filter")

        messages = await self._mail.list_messages(
            folder=folder,
            top=top,
            filter_str=filter_str,
        )
        return json.dumps(messages, indent=2, default=str)


class GraphMailSendTool(Tool):
    """Send an email via Microsoft Graph."""

    def __init__(self, mail: MailClient) -> None:
        self._mail = mail

    @property
    def name(self) -> str:
        return "graph_mail_send"

    @property
    def description(self) -> str:
        return "Send an email to one or more recipients."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "to": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "List of recipient email addresses",
                },
                "subject": {
                    "type": "string",
                    "description": "Email subject line",
                },
                "body": {
                    "type": "string",
                    "description": "Email body content",
                },
                "cc": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "CC recipients (optional)",
                },
                "content_type": {
                    "type": "string",
                    "enum": ["Text", "HTML"],
                    "description": "Body content type (default: Text)",
                    "default": "Text",
                },
            },
            "required": ["to", "subject", "body"],
        }

    async def execute(self, **kwargs: Any) -> str:
        to: list[str] = kwargs["to"]
        subject: str = kwargs["subject"]
        body: str = kwargs["body"]
        cc: list[str] | None = kwargs.get("cc")
        content_type: str = kwargs.get("content_type", "Text")

        await self._mail.send_mail(
            to=to,
            subject=subject,
            body=body,
            cc=cc,
            content_type=content_type,
        )
        return f"Email sent to {', '.join(to)}"


class GraphMailReplyTool(Tool):
    """Reply to an email via Microsoft Graph."""

    def __init__(self, mail: MailClient) -> None:
        self._mail = mail

    @property
    def name(self) -> str:
        return "graph_mail_reply"

    @property
    def description(self) -> str:
        return "Reply to an existing email message by its ID."

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "message_id": {
                    "type": "string",
                    "description": "The ID of the message to reply to",
                },
                "body": {
                    "type": "string",
                    "description": "Reply body content",
                },
            },
            "required": ["message_id", "body"],
        }

    async def execute(self, **kwargs: Any) -> str:
        message_id: str = kwargs["message_id"]
        body: str = kwargs["body"]

        await self._mail.reply_to(message_id=message_id, body=body)
        return f"Replied to message {message_id}"


class GraphMailSearchTool(Tool):
    """Search emails via Microsoft Graph."""

    def __init__(self, mail: MailClient) -> None:
        self._mail = mail

    @property
    def name(self) -> str:
        return "graph_mail_search"

    @property
    def description(self) -> str:
        return (
            "Search emails using a KQL query. "
            "Example queries: 'subject:invoice', 'from:alice@example.com'."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "KQL search query",
                },
                "top": {
                    "type": "integer",
                    "description": "Max results to return (default: 10)",
                    "default": 10,
                },
            },
            "required": ["query"],
        }

    async def execute(self, **kwargs: Any) -> str:
        query: str = kwargs["query"]
        top: int = kwargs.get("top", 10)

        results = await self._mail.search_messages(query=query, top=top)
        return json.dumps(results, indent=2, default=str)


class GraphTeamsSendTool(Tool):
    """Send a Teams message via Microsoft Graph."""

    def __init__(self, teams: TeamsGraphClient) -> None:
        self._teams = teams

    @property
    def name(self) -> str:
        return "graph_teams_send"

    @property
    def description(self) -> str:
        return (
            "Send a message to a Teams channel or chat. "
            "Provide either (team_id + channel_id) for a channel message, "
            "or chat_id for a direct/group chat message."
        )

    @property
    def parameters(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "team_id": {
                    "type": "string",
                    "description": "Team ID (for channel messages)",
                },
                "channel_id": {
                    "type": "string",
                    "description": "Channel ID (for channel messages)",
                },
                "chat_id": {
                    "type": "string",
                    "description": "Chat ID (for 1:1 or group chat messages)",
                },
                "content": {
                    "type": "string",
                    "description": "Message content (HTML)",
                },
            },
            "required": ["content"],
        }

    async def execute(self, **kwargs: Any) -> str:
        content: str = kwargs["content"]
        team_id: str | None = kwargs.get("team_id")
        channel_id: str | None = kwargs.get("channel_id")
        chat_id: str | None = kwargs.get("chat_id")

        if team_id and channel_id:
            result = await self._teams.send_channel_message(
                team_id=team_id,
                channel_id=channel_id,
                content=content,
            )
            return json.dumps(result, indent=2, default=str)

        if chat_id:
            result = await self._teams.send_chat_message(
                chat_id=chat_id,
                content=content,
            )
            return json.dumps(result, indent=2, default=str)

        return "Error: provide either (team_id + channel_id) or chat_id"


# ── Factory ─────────────────────────────────────────────────────────────────


def create_graph_tools(graph_client: GraphClient) -> list[Tool]:
    """Create all Graph-backed agent tools from a single ``GraphClient``.

    Parameters
    ----------
    graph_client:
        An authenticated ``GraphClient`` instance.

    Returns
    -------
    list[Tool]
        Tool instances ready to be registered with the ``ToolRegistry``.
    """
    mail = MailClient(graph_client)
    teams = TeamsGraphClient(graph_client)

    return [
        GraphMailListTool(mail),
        GraphMailSendTool(mail),
        GraphMailReplyTool(mail),
        GraphMailSearchTool(mail),
        GraphTeamsSendTool(teams),
    ]
