"""
Teams operations via Microsoft Graph — send messages, list teams/channels.

Uses the Graph ``/teams`` and ``/chats`` endpoints (not Bot Framework).
This complements the Bot Framework channel in ``workpilot.channels.teams``
by providing direct Graph API access for proactive messaging and discovery.
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from workpilot.graph.client import GraphClient


class TeamsGraphClient:
    """High-level async wrapper for Graph Teams endpoints."""

    def __init__(self, graph: GraphClient) -> None:
        self._graph = graph

    # ── channel messages ────────────────────────────────────────────────

    async def send_channel_message(
        self,
        team_id: str,
        channel_id: str,
        content: str,
    ) -> dict[str, Any]:
        """Post a message to a Teams channel.

        Parameters
        ----------
        team_id:
            The ID of the team.
        channel_id:
            The ID of the channel within the team.
        content:
            HTML message content.
        """
        endpoint = f"/teams/{team_id}/channels/{channel_id}/messages"
        result = await self._graph.post(
            endpoint,
            {
                "body": {
                    "contentType": "html",
                    "content": content,
                },
            },
        )
        logger.info(
            "Sent channel message to team={} channel={}",
            team_id,
            channel_id,
        )
        return result

    # ── chat messages ───────────────────────────────────────────────────

    async def send_chat_message(
        self,
        chat_id: str,
        content: str,
    ) -> dict[str, Any]:
        """Send a message in a 1:1 or group chat.

        Parameters
        ----------
        chat_id:
            The ID of the chat.
        content:
            HTML message content.
        """
        endpoint = f"/chats/{chat_id}/messages"
        result = await self._graph.post(
            endpoint,
            {
                "body": {
                    "contentType": "html",
                    "content": content,
                },
            },
        )
        logger.info("Sent chat message to chat={}", chat_id)
        return result

    # ── discovery ───────────────────────────────────────────────────────

    async def list_channels(self, team_id: str) -> list[dict[str, Any]]:
        """List all channels in a team.

        Parameters
        ----------
        team_id:
            The ID of the team.
        """
        data = await self._graph.get(f"/teams/{team_id}/channels")
        channels: list[dict[str, Any]] = data.get("value", [])
        logger.debug("Listed {} channels for team {}", len(channels), team_id)
        return channels

    async def list_teams(self) -> list[dict[str, Any]]:
        """List all teams the authenticated user has joined."""
        data = await self._graph.get("/me/joinedTeams")
        teams: list[dict[str, Any]] = data.get("value", [])
        logger.debug("Listed {} joined teams", len(teams))
        return teams
