"""
Mail operations via Microsoft Graph — list, read, send, reply, search.

All methods operate on the authenticated user's mailbox (``/me/...``).
For application-only (client credentials) access that targets a specific
user, construct ``MailClient`` with ``user_id="user@example.com"``.
"""

from __future__ import annotations

from typing import Any

from loguru import logger

from workpilot.graph.client import GraphClient


class MailClient:
    """High-level async wrapper for Graph mail endpoints."""

    def __init__(
        self,
        graph: GraphClient,
        *,
        user_id: str = "me",
    ) -> None:
        self._graph = graph
        self._user = user_id

    # ── list / read ─────────────────────────────────────────────────────

    async def list_messages(
        self,
        folder: str = "inbox",
        top: int = 10,
        filter_str: str | None = None,
    ) -> list[dict[str, Any]]:
        """List messages in a mail folder.

        Parameters
        ----------
        folder:
            Mail folder name (e.g. ``inbox``, ``sentitems``, ``drafts``).
        top:
            Maximum number of messages to return (Graph ``$top``).
        filter_str:
            Optional OData ``$filter`` expression.
        """
        params: dict[str, Any] = {
            "$top": top,
            "$select": "id,subject,from,receivedDateTime,isRead,bodyPreview",
            "$orderby": "receivedDateTime desc",
        }
        if filter_str:
            params["$filter"] = filter_str

        endpoint = f"/users/{self._user}/mailFolders/{folder}/messages"
        data = await self._graph.get(endpoint, params=params)
        messages: list[dict[str, Any]] = data.get("value", [])
        logger.debug("Listed {} messages from {}", len(messages), folder)
        return messages

    async def get_message(self, message_id: str) -> dict[str, Any]:
        """Fetch a single message by ID (includes full body)."""
        endpoint = f"/users/{self._user}/messages/{message_id}"
        return await self._graph.get(endpoint)

    # ── send ────────────────────────────────────────────────────────────

    async def send_mail(
        self,
        to: list[str],
        subject: str,
        body: str,
        cc: list[str] | None = None,
        content_type: str = "Text",
    ) -> None:
        """Compose and send an email.

        Parameters
        ----------
        to:
            List of recipient email addresses.
        subject:
            Email subject line.
        body:
            Email body content.
        cc:
            Optional list of CC email addresses.
        content_type:
            Body content type — ``"Text"`` or ``"HTML"``.
        """
        payload: dict[str, Any] = {
            "message": {
                "subject": subject,
                "body": {
                    "contentType": content_type,
                    "content": body,
                },
                "toRecipients": [{"emailAddress": {"address": addr}} for addr in to],
            },
            "saveToSentItems": True,
        }

        if cc:
            payload["message"]["ccRecipients"] = [
                {"emailAddress": {"address": addr}} for addr in cc
            ]

        endpoint = f"/users/{self._user}/sendMail"
        await self._graph.post(endpoint, payload)
        logger.info("Mail sent to {}", ", ".join(to))

    # ── reply ───────────────────────────────────────────────────────────

    async def reply_to(self, message_id: str, body: str) -> None:
        """Reply to an existing message.

        Parameters
        ----------
        message_id:
            The ID of the message to reply to.
        body:
            Reply body content (plain text).
        """
        endpoint = f"/users/{self._user}/messages/{message_id}/reply"
        await self._graph.post(endpoint, {"comment": body})
        logger.info("Replied to message {}", message_id)

    # ── search ──────────────────────────────────────────────────────────

    async def search_messages(
        self,
        query: str,
        top: int = 10,
    ) -> list[dict[str, Any]]:
        """Search messages using the Graph ``$search`` query parameter.

        Parameters
        ----------
        query:
            KQL search query (e.g. ``"subject:invoice"``).
        top:
            Maximum number of results.
        """
        params: dict[str, Any] = {
            "$search": f'"{query}"',
            "$top": top,
            "$select": "id,subject,from,receivedDateTime,bodyPreview",
        }
        endpoint = f"/users/{self._user}/messages"
        data = await self._graph.get(endpoint, params=params)
        results: list[dict[str, Any]] = data.get("value", [])
        logger.debug("Search '{}' returned {} results", query, len(results))
        return results
