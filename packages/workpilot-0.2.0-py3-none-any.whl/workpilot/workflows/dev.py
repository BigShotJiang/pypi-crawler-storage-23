"""
Development workflow orchestrator — automates the software development lifecycle.

Coordinates PR creation, code review, build monitoring, and work-item tracking
through the tool registry and LLM provider.
"""

from __future__ import annotations

import textwrap
from datetime import UTC, datetime
from typing import Any

from loguru import logger

from workpilot.agent.tools.registry import ToolRegistry
from workpilot.providers.base import LLMProvider
from workpilot.security.audit import AuditLogger


class DevWorkflow:
    """
    Development workflow orchestrator.

    Provides high-level async methods that compose tool calls and LLM
    interactions into end-to-end development processes such as PR lifecycle
    management, code review, build monitoring, and work-item tracking.
    """

    def __init__(
        self,
        *,
        tool_registry: ToolRegistry,
        provider: LLMProvider,
        audit: AuditLogger,
    ) -> None:
        self._tools = tool_registry
        self._provider = provider
        self._audit = audit

    # ------------------------------------------------------------------
    # PR lifecycle
    # ------------------------------------------------------------------

    async def pr_lifecycle(self, spec: dict[str, Any]) -> dict[str, Any]:
        """
        Execute the full pull-request lifecycle.

        Steps:
            1. Analyze requirements from *spec*
            2. Implement changes via tool calls
            3. Run tests
            4. Commit changes
            5. Create the PR
            6. Request review
            7. Notify stakeholders

        Args:
            spec: A dict describing the desired change.  Expected keys::

                - ``title``  — short PR title
                - ``description`` — detailed requirements
                - ``branch`` — target branch name (optional, derived from title)
                - ``reviewers`` — list of reviewer handles (optional)
                - ``labels`` — list of PR labels (optional)
                - ``work_item_id`` — linked ADO/GitHub work-item (optional)

        Returns:
            A status dict with keys ``pr_url``, ``branch``, ``changes_summary``,
            ``test_results``, ``reviewers``, and ``status``.
        """
        logger.info("Starting PR lifecycle for: {}", spec.get("title", "<untitled>"))

        result: dict[str, Any] = {
            "status": "in_progress",
            "pr_url": None,
            "branch": spec.get("branch"),
            "changes_summary": "",
            "test_results": {},
            "reviewers": spec.get("reviewers", []),
        }

        try:
            # Step 1 — analyse requirements
            logger.debug("Step 1/7: analyzing requirements")
            analysis = await self._analyze_requirements(spec)
            result["changes_summary"] = analysis.get("summary", "")

            # Step 2 — implement changes
            logger.debug("Step 2/7: implementing changes")
            implementation = await self._implement_changes(analysis)
            result["files_changed"] = implementation.get("files_changed", [])

            # Step 3 — run tests
            logger.debug("Step 3/7: running tests")
            test_results = await self._run_tests(implementation)
            result["test_results"] = test_results

            if not test_results.get("passed", False):
                result["status"] = "tests_failed"
                logger.warning("Tests failed — aborting PR creation")
                return result

            # Step 4 — commit
            logger.debug("Step 4/7: committing changes")
            commit = await self._commit_changes(spec, implementation)
            result["commit_sha"] = commit.get("sha")

            # Step 5 — create PR
            logger.debug("Step 5/7: creating pull request")
            pr = await self._create_pr(spec, analysis)
            result["pr_url"] = pr.get("url")
            result["branch"] = pr.get("branch", result["branch"])

            # Step 6 — request review
            logger.debug("Step 6/7: requesting review")
            await self._request_review(pr, spec.get("reviewers", []))

            # Step 7 — notify
            logger.debug("Step 7/7: notifying stakeholders")
            await self._notify_stakeholders(spec, result)

            result["status"] = "completed"
            logger.info("PR lifecycle completed: {}", result.get("pr_url"))

        except Exception as exc:
            logger.error("PR lifecycle failed: {}", exc)
            result["status"] = "error"
            result["error"] = str(exc)

        self._audit.log_event(
            action="workflow.pr_lifecycle",
            data={"spec_title": spec.get("title"), "status": result["status"]},
        )
        return result

    # ------------------------------------------------------------------
    # Code review
    # ------------------------------------------------------------------

    async def code_review(self, diff: str, files: list[str]) -> dict[str, Any]:
        """
        Analyse a code diff for security, performance, and quality issues.

        Args:
            diff: The unified diff text to review.
            files: List of file paths included in the change.

        Returns:
            A structured review dict with keys:

            - ``summary`` — one-paragraph overview
            - ``issues`` — list of dicts, each with ``file``, ``line``,
              ``severity`` (critical / high / medium / low / info),
              ``category`` (security / performance / quality / style),
              and ``message``
            - ``approval`` — ``"approve"`` | ``"request_changes"`` | ``"comment"``
        """
        logger.info("Running code review on {} file(s)", len(files))

        prompt = textwrap.dedent(f"""\
            You are a senior code reviewer. Analyze the following diff and file list.
            Identify issues in these categories: security, performance, quality, style.
            Assign severity: critical, high, medium, low, info.

            Files: {", ".join(files)}

            Diff:
            ```
            {diff}
            ```

            Respond with a structured JSON object containing:
            - "summary": one-paragraph overview
            - "issues": list of objects with file, line, severity, category, message
            - "approval": "approve" | "request_changes" | "comment"
        """)

        response = await self._provider.complete(
            model="anthropic/claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            max_tokens=4096,
        )

        review = self._parse_review_response(response.content)

        self._audit.log_event(
            action="workflow.code_review",
            data={
                "files": files,
                "issue_count": len(review.get("issues", [])),
                "approval": review.get("approval"),
            },
        )
        return review

    # ------------------------------------------------------------------
    # Work-item monitoring
    # ------------------------------------------------------------------

    async def monitor_work_items(self, config: dict[str, Any]) -> list[dict[str, Any]]:
        """
        Check for new or updated work items and return actionable items.

        Args:
            config: Configuration dict with keys:

                - ``source`` — ``"ado"`` | ``"github"``
                - ``project`` — project or repo identifier
                - ``query`` — optional custom query / filter
                - ``assigned_to`` — filter by assignee (optional)

        Returns:
            A list of action-item dicts, each with ``id``, ``title``,
            ``type`` (bug / task / feature), ``priority``, ``action``
            (implement / review / investigate), and ``url``.
        """
        source = config.get("source", "ado")
        logger.info("Monitoring work items from {} source", source)

        action_items: list[dict[str, Any]] = []

        try:
            if source == "ado":
                action_items = await self._fetch_ado_work_items(config)
            elif source == "github":
                action_items = await self._fetch_github_issues(config)
            else:
                logger.warning("Unknown work-item source: {}", source)

        except Exception as exc:
            logger.error("Work-item monitoring failed: {}", exc)

        self._audit.log_event(
            action="workflow.monitor_work_items",
            data={"source": source, "items_found": len(action_items)},
        )
        return action_items

    # ------------------------------------------------------------------
    # Build checking
    # ------------------------------------------------------------------

    async def check_build(self, pipeline_url: str) -> dict[str, Any]:
        """
        Check the status of a CI/CD build pipeline.

        Args:
            pipeline_url: URL of the build pipeline run.

        Returns:
            A dict with keys ``status`` (``"succeeded"`` | ``"failed"`` |
            ``"running"`` | ``"queued"`` | ``"unknown"``), ``url``,
            ``duration_seconds``, ``failures`` (list of failure details),
            and ``artifacts`` (list of published artifacts).
        """
        logger.info("Checking build status: {}", pipeline_url)

        result: dict[str, Any] = {
            "status": "unknown",
            "url": pipeline_url,
            "duration_seconds": None,
            "failures": [],
            "artifacts": [],
        }

        try:
            http_tool = self._tools.get("http")
            if http_tool is None:
                logger.warning("HTTP tool not available — cannot check build")
                return result

            raw = await self._tools.execute(
                "http",
                {"method": "GET", "url": pipeline_url},
                actor="workflow.check_build",
            )

            parsed = self._parse_build_response(raw)
            result.update(parsed)

        except Exception as exc:
            logger.error("Build check failed: {}", exc)
            result["error"] = str(exc)

        self._audit.log_event(
            action="workflow.check_build",
            data={"url": pipeline_url, "status": result["status"]},
        )
        return result

    # ------------------------------------------------------------------
    # Change report generation
    # ------------------------------------------------------------------

    def generate_change_report(self, changes: dict[str, Any], bilingual: bool = True) -> str:
        """
        Generate a structured change report from a changes dict.

        Args:
            changes: Dict with keys such as ``commits`` (list),
                ``files_changed`` (list), ``pr_url``, ``summary``,
                ``author``, ``date``.
            bilingual: If True, produce both Chinese (CN) and English (EN)
                sections in the report.

        Returns:
            A formatted Markdown string.
        """
        logger.debug("Generating change report (bilingual={})", bilingual)

        now = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
        commits = changes.get("commits", [])
        files = changes.get("files_changed", [])
        summary = changes.get("summary", "No summary provided.")
        pr_url = changes.get("pr_url", "N/A")
        author = changes.get("author", "Unknown")

        sections: list[str] = []

        if bilingual:
            # --- Chinese section ---
            sections.append("# 变更报告")
            sections.append(f"**日期:** {now}")
            sections.append(f"**作者:** {author}")
            sections.append(f"**PR 链接:** {pr_url}")
            sections.append(f"\n## 概要\n{summary}")
            if commits:
                sections.append("## 提交记录")
                for c in commits:
                    sha = c.get("sha", "?")[:8]
                    msg = c.get("message", "")
                    sections.append(f"- `{sha}` — {msg}")
            if files:
                sections.append("## 变更文件")
                for f in files:
                    sections.append(f"- `{f}`")
            sections.append("\n---\n")

        # --- English section ---
        sections.append("# Change Report")
        sections.append(f"**Date:** {now}")
        sections.append(f"**Author:** {author}")
        sections.append(f"**PR Link:** {pr_url}")
        sections.append(f"\n## Summary\n{summary}")
        if commits:
            sections.append("## Commits")
            for c in commits:
                sha = c.get("sha", "?")[:8]
                msg = c.get("message", "")
                sections.append(f"- `{sha}` — {msg}")
        if files:
            sections.append("## Files Changed")
            for f in files:
                sections.append(f"- `{f}`")

        report = "\n".join(sections)
        self._audit.log_event(
            action="workflow.generate_change_report",
            data={"bilingual": bilingual, "commit_count": len(commits)},
        )
        return report

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    async def _analyze_requirements(self, spec: dict[str, Any]) -> dict[str, Any]:
        """Use the LLM to break down requirements into an implementation plan."""
        prompt = textwrap.dedent(f"""\
            Analyze the following change request and produce an implementation plan.
            Title: {spec.get("title", "")}
            Description: {spec.get("description", "")}

            Respond with JSON: {{
                "summary": "...",
                "steps": ["step1", "step2", ...],
                "files_to_modify": ["path1", ...],
                "risks": ["risk1", ...]
            }}
        """)
        response = await self._provider.complete(
            model="anthropic/claude-sonnet-4-20250514",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.3,
        )
        return self._try_parse_json(response.content, fallback={"summary": response.content})  # type: ignore[no-any-return]

    async def _implement_changes(self, analysis: dict[str, Any]) -> dict[str, Any]:
        """Execute tool calls to implement the planned changes."""
        files_changed: list[str] = []
        for file_path in analysis.get("files_to_modify", []):
            try:
                await self._tools.execute(
                    "file",
                    {"action": "read", "path": file_path},
                    actor="workflow.implement",
                )
                files_changed.append(file_path)
            except Exception as exc:
                logger.warning("Could not process {}: {}", file_path, exc)
        return {"files_changed": files_changed, "analysis": analysis}

    async def _run_tests(self, implementation: dict[str, Any]) -> dict[str, Any]:
        """Run the project test suite."""
        try:
            output = await self._tools.execute(
                "shell",
                {"command": "pytest tests/ -v --tb=short"},
                actor="workflow.test",
            )
            passed = "failed" not in output.lower() or "0 failed" in output.lower()
            return {"passed": passed, "output": output}
        except Exception as exc:
            logger.error("Test execution failed: {}", exc)
            return {"passed": False, "output": str(exc)}

    async def _commit_changes(
        self,
        spec: dict[str, Any],
        implementation: dict[str, Any],
    ) -> dict[str, Any]:
        """Stage and commit the implemented changes."""
        title = spec.get("title", "automated change")
        try:
            await self._tools.execute(
                "git",
                {"action": "add", "args": ["."]},
                actor="workflow.commit",
            )
            output = await self._tools.execute(
                "git",
                {"action": "commit", "args": ["-m", title]},
                actor="workflow.commit",
            )
            return {"sha": output.strip().split()[-1] if output else None}
        except Exception as exc:
            logger.error("Commit failed: {}", exc)
            return {"sha": None, "error": str(exc)}

    async def _create_pr(
        self,
        spec: dict[str, Any],
        analysis: dict[str, Any],
    ) -> dict[str, Any]:
        """Create a pull request via the appropriate channel tool."""
        title = spec.get("title", "Automated PR")
        body = analysis.get("summary", "")
        branch = spec.get("branch", "auto/change")

        try:
            output = await self._tools.execute(
                "shell",
                {
                    "command": (
                        f'gh pr create --title "{title}" --body "{body}" --head "{branch}"'
                    ),
                },
                actor="workflow.create_pr",
            )
            url = output.strip() if output else None
            return {"url": url, "branch": branch}
        except Exception as exc:
            logger.error("PR creation failed: {}", exc)
            return {"url": None, "branch": branch, "error": str(exc)}

    async def _request_review(
        self,
        pr: dict[str, Any],
        reviewers: list[str],
    ) -> None:
        """Add reviewers to the PR."""
        if not reviewers or not pr.get("url"):
            return
        reviewer_csv = ",".join(reviewers)
        try:
            await self._tools.execute(
                "shell",
                {"command": f"gh pr edit {pr['url']} --add-reviewer {reviewer_csv}"},
                actor="workflow.request_review",
            )
        except Exception as exc:
            logger.warning("Failed to add reviewers: {}", exc)

    async def _notify_stakeholders(
        self,
        spec: dict[str, Any],
        result: dict[str, Any],
    ) -> None:
        """Send notifications about the completed PR."""
        logger.info(
            "PR lifecycle notification — status={}, url={}",
            result.get("status"),
            result.get("pr_url"),
        )

    async def _fetch_ado_work_items(self, config: dict[str, Any]) -> list[dict[str, Any]]:
        """Fetch work items from Azure DevOps."""
        project = config.get("project", "")
        try:
            raw = await self._tools.execute(
                "http",
                {
                    "method": "GET",
                    "url": (f"https://dev.azure.com/{project}/_apis/wit/wiql?api-version=7.0"),
                },
                actor="workflow.monitor_ado",
            )
            return self._parse_ado_items(raw)
        except Exception as exc:
            logger.error("ADO work-item fetch failed: {}", exc)
            return []

    async def _fetch_github_issues(self, config: dict[str, Any]) -> list[dict[str, Any]]:
        """Fetch issues from GitHub."""
        project = config.get("project", "")
        try:
            raw = await self._tools.execute(
                "http",
                {
                    "method": "GET",
                    "url": f"https://api.github.com/repos/{project}/issues",
                },
                actor="workflow.monitor_github",
            )
            return self._parse_github_issues(raw)
        except Exception as exc:
            logger.error("GitHub issue fetch failed: {}", exc)
            return []

    # ------------------------------------------------------------------
    # Parsing helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_review_response(content: str) -> dict[str, Any]:
        """Parse the LLM review response into a structured dict."""
        parsed = DevWorkflow._try_parse_json(content, fallback=None)
        if parsed and isinstance(parsed, dict):
            return {
                "summary": parsed.get("summary", content),
                "issues": parsed.get("issues", []),
                "approval": parsed.get("approval", "comment"),
            }
        return {"summary": content, "issues": [], "approval": "comment"}

    @staticmethod
    def _parse_build_response(raw: str) -> dict[str, Any]:
        """Parse build API response into a normalized status dict."""
        parsed = DevWorkflow._try_parse_json(raw, fallback=None)
        if not parsed or not isinstance(parsed, dict):
            return {"status": "unknown"}
        return {
            "status": parsed.get("status", parsed.get("result", "unknown")),
            "duration_seconds": parsed.get("duration", None),
            "failures": parsed.get("failures", []),
            "artifacts": parsed.get("artifacts", []),
        }

    @staticmethod
    def _parse_ado_items(raw: str) -> list[dict[str, Any]]:
        """Parse ADO work-item API response."""
        import json

        try:
            data = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
        items: list[dict[str, Any]] = []
        for wi in data.get("workItems", []):
            items.append(
                {
                    "id": wi.get("id"),
                    "title": wi.get("fields", {}).get("System.Title", ""),
                    "type": wi.get("fields", {}).get("System.WorkItemType", "task"),
                    "priority": wi.get("fields", {}).get("Microsoft.VSTS.Common.Priority", 3),
                    "action": "investigate",
                    "url": wi.get("url", ""),
                }
            )
        return items

    @staticmethod
    def _parse_github_issues(raw: str) -> list[dict[str, Any]]:
        """Parse GitHub issues API response."""
        import json

        try:
            issues = json.loads(raw)
        except (json.JSONDecodeError, TypeError):
            return []
        if not isinstance(issues, list):
            return []
        items: list[dict[str, Any]] = []
        for issue in issues:
            labels = [lbl.get("name", "") for lbl in issue.get("labels", [])]
            action = "implement"
            if "bug" in labels:
                action = "investigate"
            elif "review" in labels:
                action = "review"
            items.append(
                {
                    "id": issue.get("number"),
                    "title": issue.get("title", ""),
                    "type": "bug" if "bug" in labels else "task",
                    "priority": 2 if "bug" in labels else 3,
                    "action": action,
                    "url": issue.get("html_url", ""),
                }
            )
        return items

    @staticmethod
    def _try_parse_json(text: str, fallback: Any = None) -> Any:
        """Attempt to parse JSON from text, possibly wrapped in markdown fences."""
        import json

        cleaned = text.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            # Remove opening fence (with optional language tag) and closing fence
            if lines[0].startswith("```"):
                lines = lines[1:]
            if lines and lines[-1].strip() == "```":
                lines = lines[:-1]
            cleaned = "\n".join(lines).strip()
        try:
            return json.loads(cleaned)
        except (json.JSONDecodeError, TypeError):
            return fallback if fallback is not None else {"raw": text}
