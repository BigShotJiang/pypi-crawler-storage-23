"""Common utilities."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse, urlunparse


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def get_data_dir() -> Path:
    """Default data directory: ~/.workpilot/"""
    return ensure_dir(Path.home() / ".workpilot")


def get_sessions_dir() -> Path:
    return ensure_dir(get_data_dir() / "sessions")


def get_memory_dir() -> Path:
    return ensure_dir(get_data_dir() / "memory")


def get_skills_dir() -> Path:
    return ensure_dir(get_data_dir() / "skills")


def get_logs_dir() -> Path:
    return ensure_dir(get_data_dir() / "logs")


def get_workspace_dir() -> Path:
    """Default workspace directory: ~/.workpilot/workspace/"""
    return ensure_dir(get_data_dir() / "workspace")


def webchat_url_from_connect(connect_url: str) -> str:
    """Derive the web-chat URL from a WorkPilot cloud connect URL.

    wss://host/connect  →  https://host/chat
    ws://host/connect   →  http://host/chat

    Raises ValueError for unexpected schemes so callers can handle
    misconfiguration rather than silently propagating an invalid URL.
    """
    parsed = urlparse(connect_url)
    scheme_map = {"wss": "https", "ws": "http"}
    if parsed.scheme not in scheme_map:
        raise ValueError(
            f"webchat_url_from_connect: expected ws:// or wss:// URL, got {connect_url!r}"
        )
    http_scheme = scheme_map[parsed.scheme]
    path = re.sub(r"/connect$", "/chat", parsed.path) if parsed.path else "/chat"
    return urlunparse((http_scheme, parsed.netloc, path, "", "", ""))
