"""
GitHub channel — PR/issue comment interactions via REST API.
"""

from __future__ import annotations

from typing import Any

import httpx
from loguru import logger

from workpilot.bus.queue import MessageBus
from workpilot.channels.base import BaseChannel


class GitHubChannel(BaseChannel):
    """GitHub PR/issue interactions."""

    def __init__(
        self,
        bus: MessageBus,
        *,
        token: str,
        base_url: str = "https://api.github.com",
        allow_from: list[str] | None = None,
    ) -> None:
        super().__init__(bus, allow_from)
        self._token = token
        self._base_url = base_url.rstrip("/")

    @property
    def name(self) -> str:
        return "github"

    async def start(self) -> None:
        logger.info("GitHub channel started")

    async def stop(self) -> None:
        pass

    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Post a comment to a GitHub issue/PR.
        channel_id format: owner/repo#number
        """
        owner = kwargs.get("owner", "")
        repo = kwargs.get("repo", "")
        number = kwargs.get("issue_number", 0)

        if not all([owner, repo, number]):
            # Try to parse from channel_id
            if "#" in channel_id:
                repo_part, num_part = channel_id.rsplit("#", 1)
                if "/" in repo_part:
                    owner, repo = repo_part.split("/", 1)
                    number = int(num_part)

        url = f"{self._base_url}/repos/{owner}/{repo}/issues/{number}/comments"
        async with httpx.AsyncClient() as client:
            resp = await client.post(
                url,
                json={"body": content},
                headers={
                    "Authorization": f"Bearer {self._token}",
                    "Accept": "application/vnd.github.v3+json",
                },
            )
            if not resp.is_success:
                logger.error(f"GitHub comment failed: {resp.status_code} {resp.text}")

    async def process_webhook(self, event: str, payload: dict[str, Any]) -> None:
        """Process a GitHub webhook event."""
        if event not in ("issue_comment", "pull_request_review_comment"):
            return
        if payload.get("action") != "created":
            return

        comment = payload.get("comment", {})
        issue = payload.get("issue") or payload.get("pull_request") or {}
        repo = payload.get("repository", {})
        sender = payload.get("sender", {})

        owner = repo.get("owner", {}).get("login", "")
        repo_name = repo.get("name", "")

        await self._handle_message(
            channel_id=f"{owner}/{repo_name}#{issue.get('number', '')}",
            sender_id=sender.get("login", ""),
            sender_name=sender.get("login", ""),
            content=comment.get("body", ""),
            thread_id=str(issue.get("number", "")),
            metadata={
                "event": event,
                "owner": owner,
                "repo": repo_name,
                "issue_number": issue.get("number"),
            },
        )
