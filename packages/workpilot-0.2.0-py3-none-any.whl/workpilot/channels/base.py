"""
Base channel — abstract interface with allowlist-based access control.

Every channel enforces an allow-list before publishing to the bus.
Empty allow_from = allow all (enterprise deployments should always set this).
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from loguru import logger

from workpilot.bus.events import InboundMessage
from workpilot.bus.queue import MessageBus


class BaseChannel(ABC):
    """Abstract base for all communication channels."""

    def __init__(self, bus: MessageBus, allow_from: list[str] | None = None) -> None:
        self._bus = bus
        self._allow_from = set(allow_from) if allow_from else set()

    @property
    @abstractmethod
    def name(self) -> str:
        """Channel identifier."""

    @abstractmethod
    async def start(self) -> None:
        """Connect and begin receiving messages."""

    @abstractmethod
    async def stop(self) -> None:
        """Disconnect and clean up."""

    @abstractmethod
    async def send(self, channel_id: str, content: str, **kwargs: Any) -> None:
        """Send a message to a specific channel destination."""

    async def send_typing(self, channel_id: str, **kwargs: Any) -> None:  # noqa: B027
        """Send a typing indicator to the channel. No-op by default.

        Subclasses (Teams, Cloud) override to show a typing indicator
        while the agent is processing a request.
        """

    def is_allowed(self, sender_id: str) -> bool:
        """Check if the sender is in the allow list."""
        if not self._allow_from:
            return True  # Empty list = allow all
        return sender_id in self._allow_from

    async def _handle_message(
        self,
        *,
        channel_id: str,
        sender_id: str,
        sender_name: str,
        content: str,
        thread_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Shared message handler — checks allowlist then publishes to bus."""
        if not self.is_allowed(sender_id):
            logger.warning(f"Message blocked from {sender_id} on {self.name} (not in allow_from)")
            return

        msg = InboundMessage(
            channel=self.name,
            channel_id=channel_id,
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            thread_id=thread_id,
            metadata=metadata or {},
        )
        await self._bus.publish_inbound(msg)
