"""
Input/output sanitizer — cleans untrusted content to prevent
prompt injection, log injection, and data exfiltration.
"""

from __future__ import annotations

import re

# Patterns that may indicate prompt injection attempts
_INJECTION_PATTERNS = [
    re.compile(r"<\|im_start\|>", re.IGNORECASE),
    re.compile(r"<\|im_end\|>", re.IGNORECASE),
    re.compile(r"\bsystem\s*:", re.IGNORECASE),
    re.compile(r"ignore\s+(all\s+)?previous\s+instructions", re.IGNORECASE),
    re.compile(r"you\s+are\s+now\s+(?:a|in)\s+\w+\s+mode", re.IGNORECASE),
]

# Characters that could cause log injection
_LOG_UNSAFE = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


class Sanitizer:
    """Sanitize inputs and outputs for enterprise safety."""

    @staticmethod
    def check_prompt_injection(text: str) -> list[str]:
        """
        Return list of matched injection pattern descriptions.
        Does NOT block — lets the caller decide policy.
        """
        findings: list[str] = []
        for pattern in _INJECTION_PATTERNS:
            if pattern.search(text):
                findings.append(f"Potential injection: {pattern.pattern}")
        return findings

    @staticmethod
    def sanitize_log(text: str) -> str:
        """Remove control characters that could cause log injection."""
        return _LOG_UNSAFE.sub("", text)

    @staticmethod
    def truncate(text: str, max_chars: int = 50_000) -> str:
        """Truncate text to max_chars, adding indicator if truncated."""
        if len(text) <= max_chars:
            return text
        return text[:max_chars] + "\n...(truncated)"

    @staticmethod
    def redact_env_values(text: str, env_keys: list[str] | None = None) -> str:
        """
        Redact known environment variable values from output.
        Prevents accidental credential leakage in tool output.
        """
        import os

        keys_to_check = env_keys or [
            k
            for k in os.environ
            if any(s in k.lower() for s in ("key", "secret", "token", "password", "pat"))
        ]
        result = text
        for key in keys_to_check:
            val = os.environ.get(key, "")
            if val and len(val) > 4:
                result = result.replace(val, "[REDACTED]")
        return result
