"""
Enterprise audit logger — records all significant actions for compliance.

Every tool execution, channel message, and auth event is logged with
correlation IDs and automatic secret redaction.
"""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from loguru import logger

from workpilot.config.schema import AuditConfig

_REDACT_KEYS = frozenset(
    {
        "password",
        "secret",
        "token",
        "key",
        "credential",
        "authorization",
        "apikey",
        "api_key",
        "pat",
        "api_secret",
        "client_secret",
        "app_password",
        "webhook_secret",
    }
)

_SECRET_PATTERNS = [
    re.compile(r"(eyJ[A-Za-z0-9_-]{10,}\.){1,2}[A-Za-z0-9_-]{10,}"),  # JWT
    re.compile(r"AKIA[0-9A-Z]{16}"),  # AWS
    re.compile(r"gh[pousr]_[A-Za-z0-9_]{36,}"),  # GitHub tokens (PAT, OAuth, user-to-server, etc.)
    re.compile(r"xox[bpors]-[A-Za-z0-9-]+"),  # Slack
    re.compile(r"sk-[A-Za-z0-9]{20,}"),  # OpenAI-style
]


def _redact_dict(obj: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for k, v in obj.items():
        if k.lower() in _REDACT_KEYS:
            result[k] = "[REDACTED]"
        elif isinstance(v, dict):
            result[k] = _redact_dict(v)
        elif isinstance(v, str):
            result[k] = _redact_string(v)
        else:
            result[k] = v
    return result


def _redact_string(value: str) -> str:
    for pattern in _SECRET_PATTERNS:
        value = pattern.sub("[REDACTED]", value)
    return value


class AuditLogger:
    """Structured audit logger with secret redaction."""

    def __init__(self, config: AuditConfig | None = None) -> None:
        self._enabled = config.enabled if config else False
        self._redact = config.redact_secrets if config else True
        self._file = Path(config.log_file) if config and config.log_file else None
        if self._file:
            self._file.parent.mkdir(parents=True, exist_ok=True)

    def _write(self, entry: dict[str, Any]) -> None:
        if not self._enabled:
            return
        if self._redact:
            entry = _redact_dict(entry)
        line = json.dumps(entry, default=str)
        if self._file:
            with self._file.open("a", encoding="utf-8") as f:
                f.write(line + "\n")
        else:
            logger.info(f"AUDIT: {line}")

    def log_tool(
        self,
        *,
        tool: str,
        actor: str,
        args: dict[str, Any],
        result: str,
        is_error: bool = False,
        session_id: str | None = None,
        duration_ms: float | None = None,
    ) -> None:
        self._write(
            {
                "ts": datetime.now(UTC).isoformat(),
                "event": "tool:execute",
                "tool": tool,
                "actor": actor,
                "args": args,
                "result_preview": (result or "")[:200],
                "is_error": is_error,
                "session_id": session_id,
                "duration_ms": duration_ms,
            }
        )

    def log_message(
        self,
        *,
        channel: str,
        direction: str,
        actor: str,
        session_id: str | None = None,
    ) -> None:
        self._write(
            {
                "ts": datetime.now(UTC).isoformat(),
                "event": f"channel:{direction}",
                "channel": channel,
                "actor": actor,
                "session_id": session_id,
            }
        )

    def log_auth(
        self,
        *,
        provider: str,
        actor: str,
        result: str,
    ) -> None:
        self._write(
            {
                "ts": datetime.now(UTC).isoformat(),
                "event": "auth:attempt",
                "provider": provider,
                "actor": actor,
                "result": result,
            }
        )

    def log_security(
        self,
        *,
        event: str,
        details: dict[str, Any],
        severity: str = "warning",
    ) -> None:
        self._write(
            {
                **details,
                "ts": datetime.now(UTC).isoformat(),
                "event": f"security:{event}",
                "severity": severity,
            }
        )

    def log_event(self, *, action: str, data: dict[str, Any]) -> None:
        """Log a generic workflow/lifecycle event."""
        self._write(
            {
                **data,
                "ts": datetime.now(UTC).isoformat(),
                "event": action,
            }
        )
