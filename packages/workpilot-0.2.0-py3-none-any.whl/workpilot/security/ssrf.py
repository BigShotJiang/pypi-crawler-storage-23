"""
Shared SSRF (Server-Side Request Forgery) protection.

Validates URLs against private/reserved networks, blocked hostnames,
and DNS rebinding attacks. Used by both HttpRequestTool and BrowserTool.
"""

from __future__ import annotations

import asyncio
import ipaddress
import socket
from urllib.parse import urlparse

_BLOCKED_NETWORKS = [
    ipaddress.ip_network("127.0.0.0/8"),
    ipaddress.ip_network("10.0.0.0/8"),
    ipaddress.ip_network("172.16.0.0/12"),
    ipaddress.ip_network("192.168.0.0/16"),
    ipaddress.ip_network("169.254.0.0/16"),  # link-local / cloud metadata
    ipaddress.ip_network("100.64.0.0/10"),  # carrier-grade NAT
    ipaddress.ip_network("0.0.0.0/8"),
    ipaddress.ip_network("::1/128"),
    ipaddress.ip_network("fc00::/7"),
    ipaddress.ip_network("fe80::/10"),
]

_BLOCKED_HOSTNAMES = {"localhost", "metadata.google.internal"}
_BLOCKED_HOSTNAME_SUFFIXES = (".localhost", ".local", ".internal")


def _is_blocked_ip(addr: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
    """Return True if *addr* falls within any blocked network."""
    if any(addr in network for network in _BLOCKED_NETWORKS):
        return True
    # IPv4-mapped IPv6 addresses (e.g. ::ffff:127.0.0.1) must also be checked
    # against IPv4 blocked ranges to prevent SSRF bypass.
    if isinstance(addr, ipaddress.IPv6Address) and addr.ipv4_mapped:
        for net in _BLOCKED_NETWORKS:
            if addr.ipv4_mapped in net:
                return True
    return False


async def check_url_safety(url: str) -> str | None:
    """Validate a URL against SSRF rules.

    Returns an error message string if the URL is unsafe, or ``None`` if it
    passes all checks.

    Checks performed:
    1. Scheme must be http or https.
    2. Userinfo (user:password@) is rejected.
    3. Hostname is checked against blocklists.
    4. Literal IP addresses are checked against blocked networks.
    5. DNS resolution results are checked against blocked networks.
    """
    parsed = urlparse(url)

    # 1. Scheme check
    if parsed.scheme not in ("http", "https"):
        return f"URL scheme '{parsed.scheme}' not allowed (http/https only)"

    # 2. Userinfo rejection
    if parsed.username or parsed.password:
        return "URLs with user:password@ are not allowed"

    hostname = parsed.hostname
    if not hostname:
        return "URL must include a hostname"
    hostname_lower = hostname.lower()

    # 3. Blocked hostnames
    if hostname_lower in _BLOCKED_HOSTNAMES:
        return f"Request to '{hostname}' blocked (SSRF protection)"
    if any(hostname_lower.endswith(s) for s in _BLOCKED_HOSTNAME_SUFFIXES):
        return f"Request to '{hostname}' blocked (SSRF protection)"

    # 4. Literal IP check
    try:
        addr = ipaddress.ip_address(hostname)
        if _is_blocked_ip(addr):
            return f"Request to private/reserved IP {addr} blocked (SSRF protection)"
    except ValueError:
        pass  # Not a literal IP — hostname, which is fine

    # 5. DNS resolution check (async to avoid blocking the event loop)
    try:
        loop = asyncio.get_running_loop()
        results = await loop.getaddrinfo(hostname, None)
        for _family, _type, _proto, _canonname, sockaddr in results:
            addr = ipaddress.ip_address(sockaddr[0])
            if _is_blocked_ip(addr):
                return (
                    f"Hostname '{hostname}' resolves to private IP {addr} "
                    f"(SSRF — DNS rebinding blocked)"
                )
    except socket.gaierror:
        pass  # DNS failure will be caught by the caller

    return None
