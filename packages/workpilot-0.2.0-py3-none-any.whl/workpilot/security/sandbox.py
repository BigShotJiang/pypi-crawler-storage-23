"""
Sandbox — enforces workspace boundaries and command restrictions.

Enterprise safety layer that prevents:
- Path traversal outside workspace
- Dangerous shell commands (rm -rf /, fork bombs, etc.)
- Access to sensitive system paths
- Oversized file writes
"""

from __future__ import annotations

import re
from pathlib import Path

from loguru import logger

from workpilot.config.schema import FileSystemConfig, ShellConfig


class CommandDeniedError(Exception):
    """Raised when a shell command is blocked by security rules."""


class PathDeniedError(Exception):
    """Raised when a file path is blocked by security rules."""


class Sandbox:
    """Workspace-scoped sandbox for file and command operations."""

    def __init__(
        self,
        workspace: Path,
        shell_config: ShellConfig | None = None,
        fs_config: FileSystemConfig | None = None,
    ) -> None:
        self._workspace = workspace.resolve()
        self._shell = shell_config or ShellConfig()
        self._fs = fs_config or FileSystemConfig()
        self._deny_re = [re.compile(p, re.IGNORECASE) for p in self._shell.deny_patterns]
        self._allow_re = [re.compile(p, re.IGNORECASE) for p in self._shell.allow_patterns]
        self._deny_paths = [Path(p).expanduser().resolve() for p in self._fs.deny_paths]

    # ── Command sandbox ──────────────────────────────────────────────────

    def check_command(self, command: str) -> None:
        """Raise CommandDeniedError if the command matches a deny pattern."""
        for pattern in self._deny_re:
            if pattern.search(command):
                logger.warning(f"Command blocked by deny pattern: {command!r}")
                raise CommandDeniedError(
                    f"Command blocked by security policy (matched: {pattern.pattern})"
                )

        # If allow patterns are set, command must match at least one
        if self._allow_re:
            if not any(p.search(command) for p in self._allow_re):
                raise CommandDeniedError("Command not in allow list")

    # ── File sandbox ─────────────────────────────────────────────────────

    def resolve_path(self, path: str | Path) -> Path:
        """
        Resolve a path, ensuring it stays within the workspace.
        Returns the resolved absolute path.
        Raises PathDeniedError on violation.
        """
        resolved = (self._workspace / Path(path).expanduser()).resolve()

        # Workspace restriction
        if self._fs.restrict_to_workspace:
            if not self._is_within(resolved, self._workspace):
                raise PathDeniedError(f"Path escapes workspace: {path} -> {resolved}")

        # Deny-list check
        for deny_path in self._deny_paths:
            if self._is_within(resolved, deny_path) or resolved == deny_path:
                raise PathDeniedError(f"Access denied to protected path: {path}")

        return resolved

    def check_file_size(self, content: str | bytes) -> None:
        """Raise if content exceeds max file size."""
        size = len(content) if isinstance(content, bytes) else len(content.encode("utf-8"))
        if size > self._fs.max_file_size_bytes:
            raise PathDeniedError(
                f"File content exceeds maximum size "
                f"({size:,} > {self._fs.max_file_size_bytes:,} bytes)"
            )

    @property
    def workspace(self) -> Path:
        return self._workspace

    @property
    def shell_timeout(self) -> int:
        return self._shell.timeout

    @property
    def max_output_chars(self) -> int:
        return self._shell.max_output_chars

    @staticmethod
    def _is_within(child: Path, parent: Path) -> bool:
        """Check if child path is within parent directory."""
        try:
            child.relative_to(parent)
            return True
        except ValueError:
            return False
