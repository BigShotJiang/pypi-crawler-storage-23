"""
Provider router — resolves "auto" model selection and maps provider
credentials to litellm kwargs.

Secrets are read from config (primary) or environment (fallback) and
passed as arguments to litellm — never written to ``os.environ``.
"""

from __future__ import annotations

import os
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from workpilot.providers.litellm_provider import LiteLLMProvider

from loguru import logger
from pydantic import SecretStr

from workpilot.config.schema import ProvidersConfig

_FALLBACK_MODEL = "openai/gpt-4o"


# ── helpers ──────────────────────────────────────────────────────────────────


def _secret(value: SecretStr | None) -> str | None:
    """Unwrap a SecretStr, returning *None* for empty / missing values."""
    if value is None:
        return None
    plain = value.get_secret_value()
    return plain if plain else None


def _secret_or_env(value: SecretStr | None, *env_names: str) -> str | None:
    """Return the config value if set, otherwise fall back to env vars.

    This lets users export keys directly in their shell without adding
    them to the YAML config.  We only *read* ``os.environ`` — we never
    write to it.
    """
    result = _secret(value)
    if result:
        return result
    for name in env_names:
        result = os.environ.get(name)
        if result:
            return result
    return None


# ── auto-resolution ──────────────────────────────────────────────────────────

# Each entry: (check_fn, default_model, label)
# check_fn receives ProvidersConfig and returns a truthy value when the
# provider is configured (via config OR environment).
_AUTO_CANDIDATES: list[tuple[Any, str, str]] = [
    (
        lambda p: _secret_or_env(p.github_copilot.token, "GITHUB_TOKEN"),
        "github/gpt-5.2",
        "GitHub Copilot",
    ),
    (
        lambda p: (
            (p.ai_foundry.endpoint or os.environ.get("AZURE_AI_FOUNDRY_ENDPOINT"))
            and _secret_or_env(p.ai_foundry.api_key, "AZURE_AI_FOUNDRY_API_KEY")
        ),
        "azure_ai/gpt-4o",
        "Azure AI Foundry",
    ),
    (
        lambda p: _secret_or_env(p.anthropic.api_key, "ANTHROPIC_API_KEY"),
        "anthropic/claude-sonnet-4-5-20250929",
        "Anthropic",
    ),
    (
        lambda p: _secret_or_env(p.openai.api_key, "OPENAI_API_KEY"),
        "openai/gpt-4o",
        "OpenAI",
    ),
    (
        lambda p: _secret_or_env(p.azure_openai.api_key, "AZURE_API_KEY", "AZURE_OPENAI_API_KEY"),
        "azure/gpt-4o",
        "Azure OpenAI",
    ),
]


# Known aliases that get special resolution
_ALIASES = frozenset({"auto", "fast", "reasoning", "coding"})

# Preferred models for each alias when resolved to "auto"
_FAST_CANDIDATES: list[tuple[Any, str, str]] = [
    (
        lambda p: _secret_or_env(p.github_copilot.token, "GITHUB_TOKEN"),
        "github/gpt-5-mini",
        "GitHub Copilot",
    ),
    (
        lambda p: _secret_or_env(p.anthropic.api_key, "ANTHROPIC_API_KEY"),
        "anthropic/claude-haiku-4-5-20251001",
        "Anthropic",
    ),
    (
        lambda p: _secret_or_env(p.openai.api_key, "OPENAI_API_KEY"),
        "openai/gpt-4o-mini",
        "OpenAI",
    ),
]

_REASONING_CANDIDATES: list[tuple[Any, str, str]] = [
    (
        lambda p: _secret_or_env(p.anthropic.api_key, "ANTHROPIC_API_KEY"),
        "anthropic/claude-sonnet-4-5-20250929",
        "Anthropic",
    ),
    (
        lambda p: _secret_or_env(p.openai.api_key, "OPENAI_API_KEY"),
        "openai/o1",
        "OpenAI",
    ),
]


def resolve_model(model: str, providers: ProvidersConfig | None = None) -> str:
    """Resolve model aliases (auto/fast/reasoning/coding) to concrete model IDs.

    Resolution order:
    1. If not an alias, return as-is (concrete model ID)
    2. Check providers.aliases for user-configured mapping
    3. If alias maps to "auto", use alias-specific auto-resolution
    4. Fall back to default auto-resolution
    """
    if model not in _ALIASES:
        return model

    # Check user-configured alias mapping
    if providers is not None:
        alias_map = {
            "auto": providers.aliases.default,
            "fast": providers.aliases.fast,
            "reasoning": providers.aliases.reasoning,
            "coding": providers.aliases.coding,
        }
        configured = alias_map.get(model, "auto")
        if configured != "auto":
            logger.info("Alias '{}' resolved to '{}' via config", model, configured)
            return configured

    # Alias-specific auto-resolution
    if providers is not None:
        if model == "fast":
            for check_fn, default_model, label in _FAST_CANDIDATES:
                if check_fn(providers):
                    logger.info("Alias 'fast' auto-resolved to {} ({})", default_model, label)
                    return default_model

        elif model == "reasoning":
            for check_fn, default_model, label in _REASONING_CANDIDATES:
                if check_fn(providers):
                    logger.info("Alias 'reasoning' auto-resolved to {} ({})", default_model, label)
                    return default_model

        elif model == "coding":
            # coding uses same candidates as default auto
            for check_fn, default_model, label in _AUTO_CANDIDATES:
                if check_fn(providers):
                    logger.info("Alias 'coding' auto-resolved to {} ({})", default_model, label)
                    return default_model

    # Default auto-resolution (for "auto" alias or fallback)
    if providers is not None:
        for check_fn, default_model, label in _AUTO_CANDIDATES:
            if check_fn(providers):
                logger.info("Auto-resolved model to {} ({})", default_model, label)
                return default_model

    logger.warning(
        "No provider credentials found for '{}' resolution, falling back to {}",
        model,
        _FALLBACK_MODEL,
    )
    return _FALLBACK_MODEL


# ── credential resolution ────────────────────────────────────────────────────


def resolve_credentials(model: str, providers: ProvidersConfig) -> dict[str, Any]:
    """Return litellm kwargs (``api_key``, ``api_base``, …) for *model*.

    Config values take priority; environment variables are a read-only
    fallback.  Nothing is written to ``os.environ``.
    """
    kwargs: dict[str, Any] = {}

    if model.startswith("github/"):
        # The device-flow OAuth token has Copilot access, not GitHub Models
        # access.  Exchange it for a Copilot session token and route through
        # the Copilot API (OpenAI-compatible).
        github_token = _secret_or_env(providers.github_copilot.token, "GITHUB_TOKEN")
        if github_token:
            from workpilot.security.github_auth import (
                _COPILOT_HEADERS,
                get_copilot_api_base,
                get_copilot_token,
            )

            kwargs["api_key"] = get_copilot_token(github_token)
            kwargs["api_base"] = get_copilot_api_base()
            kwargs["extra_headers"] = _COPILOT_HEADERS

    elif model.startswith("azure_ai/"):
        key = _secret_or_env(providers.ai_foundry.api_key, "AZURE_AI_FOUNDRY_API_KEY")
        if key:
            kwargs["api_key"] = key
        base = providers.ai_foundry.endpoint or os.environ.get("AZURE_AI_FOUNDRY_ENDPOINT")
        if base:
            kwargs["api_base"] = base

    elif model.startswith("anthropic/"):
        key = _secret_or_env(providers.anthropic.api_key, "ANTHROPIC_API_KEY")
        if key:
            kwargs["api_key"] = key
        if providers.anthropic.api_base:
            kwargs["api_base"] = providers.anthropic.api_base

    elif model.startswith("openai/"):
        key = _secret_or_env(providers.openai.api_key, "OPENAI_API_KEY")
        if key:
            kwargs["api_key"] = key
        if providers.openai.api_base:
            kwargs["api_base"] = providers.openai.api_base

    elif model.startswith("azure/"):
        key = _secret_or_env(
            providers.azure_openai.api_key, "AZURE_API_KEY", "AZURE_OPENAI_API_KEY"
        )
        if key:
            kwargs["api_key"] = key
        if providers.azure_openai.endpoint:
            kwargs["api_base"] = providers.azure_openai.endpoint
        if providers.azure_openai.api_version:
            kwargs["api_version"] = providers.azure_openai.api_version

    return kwargs


# ── factory ──────────────────────────────────────────────────────────────────


def get_provider(providers: ProvidersConfig | None = None) -> LiteLLMProvider:
    """Create and return a configured LiteLLM provider."""
    from workpilot.providers.litellm_provider import LiteLLMProvider

    return LiteLLMProvider(providers=providers)
