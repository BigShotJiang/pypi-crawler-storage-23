"""
LiteLLM-based unified provider — routes to any LLM backend via a single library.

Supports: Anthropic, OpenAI, Azure OpenAI, DeepSeek, Groq, Gemini, and 100+ more
via litellm's model prefix routing.
"""

from __future__ import annotations

import json
import time
from collections.abc import AsyncIterator
from typing import Any

from loguru import logger

from workpilot.config.schema import ProvidersConfig
from workpilot.providers.base import LLMChunk, LLMProvider, LLMResponse, ToolCallRequest
from workpilot.providers.router import resolve_credentials, resolve_model


def _sanitize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Sanitize messages for OpenAI-compatible APIs.

    Fixes:
    - Missing 'content' on assistant messages (must be "" not None/missing)
    - tool_calls.function.arguments must be a JSON string, not a dict
    """
    out = []
    for msg in messages:
        msg = dict(msg)  # shallow copy

        # Ensure content is always present as a string
        if "content" not in msg or msg["content"] is None:
            msg["content"] = ""

        # Fix tool_calls arguments: dict → JSON string
        if "tool_calls" in msg and msg["tool_calls"]:
            fixed_calls = []
            for tc in msg["tool_calls"]:
                tc = dict(tc)
                if "function" in tc:
                    fn = dict(tc["function"])
                    if isinstance(fn.get("arguments"), dict):
                        fn["arguments"] = json.dumps(fn["arguments"])
                    tc["function"] = fn
                fixed_calls.append(tc)
            msg["tool_calls"] = fixed_calls

        out.append(msg)
    return out


class LiteLLMProvider(LLMProvider):
    """LiteLLM-backed provider that handles all model routing.

    Provider credentials are passed as kwargs to ``litellm.acompletion``
    rather than being written to ``os.environ``.
    """

    def __init__(self, providers: ProvidersConfig | None = None) -> None:
        self._providers = providers or ProvidersConfig()

    def _build_kwargs(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 8192,
    ) -> tuple[str, dict[str, Any]]:
        """Build litellm kwargs from call parameters. Returns (resolved_model, kwargs)."""
        model = resolve_model(model, self._providers)
        creds = resolve_credentials(model, self._providers)

        litellm_model = model
        if model.startswith("github/"):
            litellm_model = "openai/" + model.removeprefix("github/")

        kwargs: dict[str, Any] = {
            "model": litellm_model,
            "messages": _sanitize_messages(messages),
            "temperature": temperature,
            "max_tokens": max_tokens,
            "drop_params": True,
            **creds,
        }
        if tools:
            kwargs["tools"] = tools

        return model, kwargs

    async def complete(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 8192,
    ) -> LLMResponse:
        import litellm

        model, litellm_kwargs = self._build_kwargs(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
        )
        start = time.monotonic()

        try:
            response = await litellm.acompletion(**litellm_kwargs)
        except Exception as exc:
            logger.error(f"LLM error ({model}): {exc}")
            raise

        elapsed_ms = (time.monotonic() - start) * 1000
        choice = response.choices[0]
        msg = choice.message

        # Parse tool calls
        tool_calls: list[ToolCallRequest] = []
        if msg.tool_calls:
            for tc in msg.tool_calls:
                args = tc.function.arguments
                if isinstance(args, str):
                    try:
                        args = json.loads(args)
                    except json.JSONDecodeError:
                        args = {"raw": args}
                tool_calls.append(
                    ToolCallRequest(
                        id=tc.id,
                        name=tc.function.name,
                        arguments=args,
                    )
                )

        usage = response.usage
        result = LLMResponse(
            content=msg.content or "",
            tool_calls=tool_calls,
            finish_reason=choice.finish_reason or "stop",
            model=response.model or model,
            prompt_tokens=usage.prompt_tokens if usage else 0,
            completion_tokens=usage.completion_tokens if usage else 0,
            duration_ms=elapsed_ms,
        )

        logger.debug(
            f"LLM {model}: {result.prompt_tokens}+{result.completion_tokens} tokens, "
            f"{elapsed_ms:.0f}ms, {len(tool_calls)} tool calls"
        )

        return result

    async def stream(
        self,
        *,
        model: str,
        messages: list[dict[str, Any]],
        tools: list[dict[str, Any]] | None = None,
        temperature: float = 0.3,
        max_tokens: int = 8192,
    ) -> AsyncIterator[LLMChunk]:
        """Yield response chunks via litellm streaming."""
        import litellm

        model, litellm_kwargs = self._build_kwargs(
            model=model,
            messages=messages,
            tools=tools,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        try:
            response = await litellm.acompletion(**litellm_kwargs, stream=True)
        except Exception as exc:
            logger.error(f"LLM stream error ({model}): {exc}")
            raise

        async for chunk in response:
            choice = chunk.choices[0]
            delta = choice.delta
            yield LLMChunk(
                content=delta.content or "",
                finish_reason=choice.finish_reason,
                model=chunk.model or model,
            )
