"""
E-stop ASGI middleware — returns 503 for /api/* when E-stop is active.

Exempt paths: /api/health (monitoring), /api/estop, /api/reset (halt management).
Non-/api/ paths pass through for backward compatibility.
"""

from __future__ import annotations

import json
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from workpilot.security.estop import EStop


class EStopMiddleware:
    """ASGI middleware that returns 503 for /api/* when E-stop is active."""

    _EXEMPT_PATHS: frozenset[str] = frozenset({"/api/health", "/api/estop", "/api/reset"})

    def __init__(self, app: object, estop: EStop) -> None:
        self._app = app
        self._estop = estop

    async def __call__(self, scope: dict, receive: object, send: object) -> None:  # noqa: ANN401
        if scope["type"] not in ("http", "websocket"):
            await self._app(scope, receive, send)  # type: ignore[operator]
            return

        path: str = scope.get("path", "")

        # Only gate /api/* paths (excluding exempt ones)
        if path.startswith("/api/") and path not in self._EXEMPT_PATHS and self._estop.is_halted:
            if scope["type"] == "websocket":
                await self._close_ws(receive, send, self._estop.reason)
            else:
                await self._send_503(send, self._estop.reason)
            return

        await self._app(scope, receive, send)  # type: ignore[operator]

    @staticmethod
    async def _close_ws(receive: object, send: object, reason: str) -> None:
        """Reject a WebSocket connection when E-stop is active."""
        await receive()  # type: ignore[operator]  # consume ws connect
        await send(  # type: ignore[operator]
            {"type": "websocket.close", "code": 1013, "reason": f"E-stop active: {reason}"}
        )

    @staticmethod
    async def _send_503(send: object, reason: str) -> None:
        """Send a 503 Service Unavailable JSON response."""
        body = json.dumps(
            {
                "error": "service_unavailable",
                "message": f"E-stop active: {reason}",
            }
        ).encode()

        await send(  # type: ignore[operator]
            {
                "type": "http.response.start",
                "status": 503,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode()),
                ],
            }
        )
        await send(  # type: ignore[operator]
            {
                "type": "http.response.body",
                "body": body,
            }
        )
