"""Plugin loader — discover and load plugins from directories."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from loguru import logger


class PluginLoader:
    """Discover and load plugin manifests."""

    def __init__(self) -> None:
        self._plugins: dict[str, dict[str, Any]] = {}

    def load(self, plugin_dir: Path) -> dict[str, Any] | None:
        manifest_path = plugin_dir / "plugin.json"
        if not manifest_path.is_file():
            return None
        try:
            manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
            name = manifest.get("name", plugin_dir.name)
            self._plugins[name] = manifest
            logger.info(f"Plugin loaded: {name} v{manifest.get('version', '?')}")
            return dict(manifest)
        except Exception as exc:
            logger.error(f"Plugin load error ({plugin_dir}): {exc}")
            return None

    def list_plugins(self) -> list[dict[str, Any]]:
        return list(self._plugins.values())
