"""
Scheduler service — unified trigger framework for cron, interval, and event jobs.

Jobs execute via AgentLoop.run_once() — full tool hook pipeline applies.
Results recorded in run history and optionally delivered to notify channels.

Based on nanobot (agent pipeline + HEARTBEAT.md + CronTool) and
OpenClaw (session modes + run history).
"""

from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from loguru import logger

from workpilot.bus.events import EventType, OutboundMessage
from workpilot.config.schema import CronConfig

if TYPE_CHECKING:
    from workpilot.agent.loop import AgentLoop
    from workpilot.bus.queue import MessageBus


# ── Internal job representation ──────────────────────────────────────────────


@dataclass
class _Job:
    name: str
    schedule: str | int  # cron expr, interval seconds, or event type
    agent: str
    prompt: str
    session_mode: str = "isolated"
    notify_channels: list[str] = field(default_factory=list)
    enabled: bool = True
    dynamic: bool = False  # True if added via CronTool/CLI (persisted to jobs.json)
    failure_count: int = 0
    _running: bool = field(default=False, repr=False)  # guard against concurrent execution


def _safe_filename(name: str) -> str:
    """Sanitize job name for use in file paths."""
    import re

    return re.sub(r"[^\w\-.]", "_", name)[:100]


def _parse_at_schedule(schedule: str) -> datetime | None:
    """Parse 'at' schedule into target datetime.

    Formats:
      'at'                            → None (immediate)
      'at:+60'                        → now + 60 seconds (relative)
      'at:2026-03-04T15:00:00'        → absolute ISO datetime (assumes UTC)
      'at:2026-03-04T15:00:00+08:00'  → absolute ISO with timezone
    """
    from datetime import timedelta

    s = str(schedule).strip()
    # "at" with nothing after → immediate
    if len(s) <= 2 or s[2:3] not in (":",):
        return None
    value = s[3:]  # everything after "at:"
    if not value:
        return None
    if value.startswith("+"):
        try:
            seconds = int(value[1:])
        except ValueError:
            logger.error("Invalid relative 'at' schedule {!r}; expected integer after '+'", value)
            return None
        return datetime.now(UTC) + timedelta(seconds=seconds)
    # Absolute ISO datetime
    try:
        dt = datetime.fromisoformat(value)
    except ValueError:
        logger.error("Invalid absolute 'at' schedule {!r}; expected ISO 8601 datetime", value)
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt


def _detect_trigger_type(schedule: str | int) -> str:
    """Auto-detect trigger type from schedule value.

    Supports: cron expressions, interval seconds, event types,
    and 'at' one-shot (immediate, relative delay, or absolute ISO datetime).
    """
    if isinstance(schedule, str):
        s = schedule.strip().lower()
        if s == "at" or s.startswith("at:"):
            return "at"
    if isinstance(schedule, int):
        return "interval"
    # JSON may deserialize 3600 as string — check if it's a numeric string
    if isinstance(schedule, str) and schedule.isdigit():
        return "interval"
    if (
        isinstance(schedule, str)
        and "." in schedule
        and schedule.replace(".", "").replace("_", "").isalpha()
    ):
        return "event"
    return "cron"


# ── Service ──────────────────────────────────────────────────────────────────


class SchedulerService:
    """Unified scheduler: cron + interval + event triggers + heartbeat.

    Jobs execute via AgentLoop.run_once() with full hook pipeline.
    APScheduler imported lazily — not a hard dependency.
    """

    MAX_CONSECUTIVE_FAILURES = 5
    HISTORY_MAX_ENTRIES = 100

    def __init__(
        self,
        config: CronConfig,
        workspace: Path,
        bus: MessageBus | None = None,
        active_channels_fn: Any = None,
    ) -> None:
        self._config = config
        self._workspace = workspace
        self._bus = bus
        self._active_channels_fn = active_channels_fn  # () -> list[str]
        self._agent_loop: AgentLoop | None = None
        self._jobs: dict[str, _Job] = {}
        self._scheduler: Any = None
        self._running = False
        self._event_subscriptions: list[
            tuple[str, EventType, Any]
        ] = []  # (job_name, event_type, handler)
        self._job_semaphore = asyncio.Semaphore(config.max_concurrent_jobs)

        # Persistence dirs
        self._cron_dir = workspace / ".workpilot" / "cron"
        self._runs_dir = self._cron_dir / "runs"
        self._jobs_file = self._cron_dir / "jobs.json"

        # Load config jobs
        for name, cfg in config.jobs.items():
            self._jobs[name] = _Job(
                name=name,
                schedule=cfg.schedule,
                agent=cfg.agent,
                prompt=cfg.prompt,
                session_mode=cfg.session_mode,
                notify_channels=cfg.notify_channels,
                enabled=cfg.enabled,
            )

        # Load dynamic jobs
        self._load_dynamic_jobs()

    def set_agent_loop(self, agent_loop: AgentLoop) -> None:
        """Wire the agent loop for job execution. Called by Runtime."""
        self._agent_loop = agent_loop

    # ── Lifecycle ────────────────────────────────────────────────────────

    async def start(self) -> None:
        """Load jobs, register heartbeat, start APScheduler."""
        if not self._config.enabled:
            logger.info("Scheduler disabled — skipping start")
            return

        try:
            from apscheduler.schedulers.asyncio import AsyncIOScheduler
        except ImportError:
            logger.warning("apscheduler not installed — scheduler will not run")
            return

        self._scheduler = AsyncIOScheduler()

        # Register all enabled jobs
        for job in self._jobs.values():
            if job.enabled:
                self._register_trigger(job)

        # Register heartbeat
        if self._config.heartbeat.enabled:
            self._register_heartbeat()

        self._scheduler.start()
        self._running = True
        logger.info(
            "Scheduler started ({} jobs, heartbeat={})",
            len([j for j in self._jobs.values() if j.enabled]),
            self._config.heartbeat.enabled,
        )

    async def stop(self) -> None:
        """Graceful shutdown."""
        if self._scheduler and self._running:
            self._scheduler.shutdown(wait=False)
            self._running = False
            # Unsubscribe event triggers
            if self._bus:
                for _name, event_type, handler in self._event_subscriptions:
                    self._bus.events.off(event_type, handler)
            self._event_subscriptions.clear()
            logger.info("Scheduler stopped")

    # ── Job management ───────────────────────────────────────────────────

    def add_job(
        self,
        name: str,
        schedule: str | int,
        prompt: str,
        *,
        agent: str = "default",
        session_mode: str = "isolated",
        notify_channels: list[str] | None = None,
        dynamic: bool = True,
    ) -> None:
        """Register a new job. Validates schedule before persisting."""
        # Validate schedule format before storing
        trigger_type = _detect_trigger_type(schedule)
        if trigger_type == "at":
            # Validate at schedule format
            schedule_str = str(schedule).strip()
            if len(schedule_str) > 2 and schedule_str[2:3] == ":":
                value = schedule_str[3:]
                if not value:
                    raise ValueError(
                        f"Invalid at schedule '{schedule}'. "
                        "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                    )
                if value.startswith("+"):
                    try:
                        delay = int(value[1:])
                    except ValueError:
                        raise ValueError(
                            f"Invalid at schedule '{schedule}'. "
                            "Use 'at', 'at:+SECONDS', or 'at:ISO_DATETIME'"
                        ) from None
                    if delay <= 0:
                        raise ValueError(f"Delay must be positive, got {delay}")
                elif value:
                    try:
                        dt = datetime.fromisoformat(value)
                    except ValueError:
                        raise ValueError(f"Invalid ISO datetime in schedule '{schedule}'") from None
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=UTC)
                    if dt < datetime.now(UTC):
                        raise ValueError(f"Schedule time is in the past: {value}")
        elif trigger_type == "cron":
            try:
                from apscheduler.triggers.cron import CronTrigger

                CronTrigger.from_crontab(str(schedule))
            except ImportError:
                pass  # APScheduler not installed — skip validation, will fail at start()
            except (ValueError, TypeError) as exc:
                raise ValueError(f"Invalid cron expression '{schedule}': {exc}") from exc
        elif trigger_type == "interval":
            if int(schedule) <= 0:
                raise ValueError(f"Interval must be positive, got {schedule}")
        elif trigger_type == "event":
            valid = {et.value for et in EventType}
            if str(schedule) not in valid:
                raise ValueError(
                    f"Unknown event type '{schedule}'. Valid: {', '.join(sorted(valid))}"
                )

        job = _Job(
            name=name,
            schedule=schedule,
            agent=agent,
            prompt=prompt,
            session_mode=session_mode,
            notify_channels=notify_channels or [],
            dynamic=dynamic,
        )
        self._jobs[name] = job

        if self._running:
            self._register_trigger(job)

        if dynamic:
            self._persist_dynamic_jobs()

        logger.info("Added job '{}' (schedule={})", name, schedule)

    def remove_job(self, name: str) -> None:
        """Remove a job."""
        job = self._jobs.pop(name, None)
        if job and self._running:
            self._unregister_trigger(job)

        if job and job.dynamic:
            self._persist_dynamic_jobs()

        logger.info("Removed job '{}'", name)

    def enable(self, name: str) -> None:
        """Enable a disabled job."""
        job = self._jobs.get(name)
        if not job:
            return
        job.enabled = True
        job.failure_count = 0
        if self._running:
            self._unregister_trigger(job)  # remove stale subscription first
            self._register_trigger(job)
        if job.dynamic:
            self._persist_dynamic_jobs()
        logger.info("Enabled job '{}'", name)

    def disable(self, name: str) -> None:
        """Disable a job without removing it."""
        job = self._jobs.get(name)
        if not job:
            return
        job.enabled = False
        if self._running:
            self._unregister_trigger(job)
        if job.dynamic:
            self._persist_dynamic_jobs()
        logger.info("Disabled job '{}'", name)

    def run_now(self, name: str) -> None:
        """Force immediate execution of a job."""
        job = self._jobs.get(name)
        if not job:
            logger.warning("Job '{}' not found", name)
            return
        try:
            loop = asyncio.get_running_loop()
            loop.create_task(self._execute_job(job))
        except RuntimeError:
            logger.warning("No event loop — cannot run job '{}' immediately", name)

    def list_jobs(self) -> list[dict[str, Any]]:
        """All jobs with status."""
        result = []
        for job in self._jobs.values():
            next_run = None
            if self._scheduler:
                ap_job = self._scheduler.get_job(job.name)
                if ap_job and ap_job.next_run_time:
                    next_run = ap_job.next_run_time.isoformat()
            entry: dict[str, Any] = {
                "name": job.name,
                "schedule": job.schedule,
                "trigger_type": _detect_trigger_type(job.schedule),
                "agent": job.agent,
                "enabled": job.enabled,
                "session_mode": job.session_mode,
                "failure_count": job.failure_count,
                "dynamic": job.dynamic,
                "next_run": next_run,
            }
            result.append(entry)
        return result

    def health(self) -> dict[str, Any]:
        """Scheduler health status."""
        active = sum(1 for j in self._jobs.values() if j.enabled)
        disabled = sum(1 for j in self._jobs.values() if not j.enabled)
        return {
            "running": self._running,
            "total_jobs": len(self._jobs),
            "active_jobs": active,
            "disabled_jobs": disabled,
            "heartbeat_enabled": self._config.heartbeat.enabled,
        }

    # ── Trigger registration ─────────────────────────────────────────────

    def _unregister_trigger(self, job: _Job) -> None:
        """Remove a job's trigger from APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "at":
            # Cancel pending DateTrigger if registered in APScheduler
            if self._scheduler:
                try:
                    self._scheduler.remove_job(job.name)
                except Exception:
                    pass  # May not be registered (immediate or already fired)
            return
        elif trigger_type == "event" and self._bus:
            to_remove = [(n, et, h) for n, et, h in self._event_subscriptions if n == job.name]
            for name, et, handler in to_remove:
                self._bus.events.off(et, handler)
                self._event_subscriptions.remove((name, et, handler))
        elif self._scheduler:
            try:
                self._scheduler.remove_job(job.name)
            except Exception:
                pass

    def _register_trigger(self, job: _Job) -> None:
        """Register appropriate trigger in APScheduler or EventBus."""
        trigger_type = _detect_trigger_type(job.schedule)

        if trigger_type == "event":
            self._register_event_trigger(job)
            return

        if trigger_type == "at":
            self._register_at_trigger(job)
            return

        if not self._scheduler:
            return

        try:
            if trigger_type == "cron":
                from apscheduler.triggers.cron import CronTrigger

                trigger = CronTrigger.from_crontab(str(job.schedule))
            else:  # interval
                from apscheduler.triggers.interval import IntervalTrigger

                trigger = IntervalTrigger(seconds=int(job.schedule))

            self._scheduler.add_job(
                self._execute_job,
                trigger=trigger,
                args=[job],
                id=job.name,
                name=job.name,
                replace_existing=True,
                max_instances=1,
            )
            logger.debug("Registered {} trigger for '{}'", trigger_type, job.name)
        except Exception as exc:
            logger.error("Failed to register trigger for '{}': {}", job.name, exc)

    def _register_at_trigger(self, job: _Job) -> None:
        """Execute a job at a specific time, then auto-remove on success.

        Schedule formats (nanobot at_iso pattern):
          "at"                            — execute immediately
          "at:+60"                        — execute after 60 seconds
          "at:2026-03-04T15:00:00"        — execute at absolute ISO datetime
          "at:2026-03-04T15:00:00+08:00"  — execute at absolute ISO with timezone
        """
        run_at = _parse_at_schedule(str(job.schedule))

        if run_at is not None and self._scheduler:
            # Scheduled one-shot via APScheduler DateTrigger
            from apscheduler.triggers.date import DateTrigger

            async def _run_and_remove_scheduled() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            self._scheduler.add_job(
                _run_and_remove_scheduled,
                trigger=DateTrigger(run_date=run_at),
                id=job.name,
                name=job.name,
                replace_existing=True,
            )
            logger.info("One-shot job '{}' scheduled for {}", job.name, run_at.isoformat())
        else:
            # Immediate execution
            async def _run_and_remove() -> None:
                result = await self._execute_job(job)
                if result is not None:  # success — clean up
                    self.remove_job(job.name)
                    logger.info("One-shot job '{}' completed and removed", job.name)
                else:  # failure — keep for inspection
                    self.disable(job.name)
                    logger.warning("One-shot job '{}' failed — disabled for inspection", job.name)

            try:
                loop = asyncio.get_running_loop()
                loop.create_task(_run_and_remove())
            except RuntimeError:
                logger.warning("No event loop — cannot schedule one-shot job '{}'", job.name)

    def _register_event_trigger(self, job: _Job) -> None:
        """Subscribe to EventBus for event-triggered jobs."""
        if not self._bus:
            logger.warning("No bus — cannot register event trigger for '{}'", job.name)
            return

        event_name = str(job.schedule)
        # Find matching EventType
        for et in EventType:
            if et.value == event_name:

                async def _handler(event_type: EventType, payload: dict, _job: _Job = job) -> None:
                    await self._execute_job(_job)

                self._bus.events.on(et, _handler)
                self._event_subscriptions.append((job.name, et, _handler))
                logger.debug("Registered event trigger for '{}' on {}", job.name, event_name)
                return

        logger.warning("Unknown event type '{}' for job '{}'", event_name, job.name)

    def _register_heartbeat(self) -> None:
        """Register the built-in heartbeat interval job."""
        interval = self._config.heartbeat.interval
        heartbeat_md = self._workspace / "HEARTBEAT.md"

        prompt = "No HEARTBEAT.md found. Nothing to do."
        if heartbeat_md.is_file():
            prompt = heartbeat_md.read_text(encoding="utf-8").strip()
            if not prompt:
                prompt = "HEARTBEAT.md is empty. Nothing to do."

        job = _Job(
            name="__heartbeat__",
            schedule=interval,
            agent="default",
            prompt=prompt,
            session_mode="persistent",
        )
        self._jobs["__heartbeat__"] = job

        if self._scheduler:
            from apscheduler.triggers.interval import IntervalTrigger

            self._scheduler.add_job(
                self._execute_heartbeat,
                trigger=IntervalTrigger(seconds=interval),
                id="__heartbeat__",
                name="__heartbeat__",
                replace_existing=True,
                max_instances=1,
            )
        logger.info("Heartbeat registered (every {}s)", interval)

    # ── Execution ────────────────────────────────────────────────────────

    async def _execute_job(self, job: _Job) -> str | None:
        """Execute a job via AgentLoop.run_once()."""
        if not self._agent_loop:
            logger.error("Agent loop not set — cannot execute '{}'", job.name)
            return None

        # Guard against concurrent execution (especially for event triggers)
        if job._running:
            logger.debug("Job '{}' already running — skipping", job.name)
            return None
        job._running = True

        run_id = uuid.uuid4().hex[:12]
        session_id = (
            f"scheduler:{job.name}:{run_id}"
            if job.session_mode == "isolated"
            else f"scheduler:{job.name}"
        )

        started = datetime.now(UTC)
        try:
            logger.info("Executing job '{}' (session={})", job.name, session_id)
            async with self._job_semaphore:
                result = await self._agent_loop.run_once(job.prompt, session_id=session_id)

            duration = (datetime.now(UTC) - started).total_seconds()
            self._record_run(job.name, run_id, "success", result, duration, started_at=started)

            # Reset failure counter on success
            job.failure_count = 0

            # Deliver to notify channels ("*" = all active channels)
            if job.notify_channels and result and self._bus:
                targets = list(job.notify_channels)
                if "*" in targets and self._active_channels_fn:
                    targets = self._active_channels_fn()
                for channel in targets:
                    if channel == "*":
                        continue  # skip unresolved wildcard
                    try:
                        await self._bus.publish_outbound(
                            OutboundMessage(
                                channel=channel,
                                channel_id=f"scheduler:{job.name}",
                                content=f"[Cron: {job.name}]\n{result}",
                                metadata={
                                    "source": "scheduler",
                                    "job_name": job.name,
                                    "session_id": session_id,
                                },
                            )
                        )
                    except Exception as exc:
                        logger.warning("Cron notify to '{}' failed: {}", channel, exc)

            return result

        except Exception as exc:
            duration = (datetime.now(UTC) - started).total_seconds()
            logger.error("Job '{}' failed: {}", job.name, exc)
            self._record_run(
                job.name,
                run_id,
                "failed",
                str(exc),
                duration,
                started_at=started,
                error_type=type(exc).__name__,
            )

            job.failure_count += 1
            if job.failure_count >= self.MAX_CONSECUTIVE_FAILURES:
                logger.warning(
                    "Job '{}' auto-disabled after {} failures",
                    job.name,
                    job.failure_count,
                )
                self.disable(job.name)

            return None

        finally:
            job._running = False

    async def _execute_heartbeat(self) -> None:
        """Execute the heartbeat job. Re-reads HEARTBEAT.md each time."""
        heartbeat_md = self._workspace / "HEARTBEAT.md"
        if not heartbeat_md.is_file():
            return

        prompt = heartbeat_md.read_text(encoding="utf-8").strip()
        if not prompt:
            return

        job = self._jobs.get("__heartbeat__")
        if job:
            job.prompt = prompt  # refresh from file
            await self._execute_job(job)

    # ── Persistence ──────────────────────────────────────────────────────

    def _load_dynamic_jobs(self) -> None:
        """Load dynamic jobs from .workpilot/cron/jobs.json."""
        if not self._jobs_file.is_file():
            return
        try:
            data = json.loads(self._jobs_file.read_text(encoding="utf-8"))
            for item in data:
                name = item["name"]
                if name not in self._jobs:  # config jobs take precedence
                    self._jobs[name] = _Job(
                        name=name,
                        schedule=item["schedule"],
                        agent=item.get("agent", "default"),
                        prompt=item.get("prompt", ""),
                        session_mode=item.get("session_mode", "isolated"),
                        notify_channels=item.get("notify_channels", []),
                        enabled=item.get("enabled", True),
                        dynamic=True,
                    )
            logger.debug("Loaded {} dynamic jobs", len(data))
        except Exception as exc:
            logger.warning("Failed to load dynamic jobs: {}", exc)

    def _persist_dynamic_jobs(self) -> None:
        """Save dynamic jobs to .workpilot/cron/jobs.json."""
        self._cron_dir.mkdir(parents=True, exist_ok=True)
        dynamic = [
            {
                "name": j.name,
                "schedule": j.schedule,
                "agent": j.agent,
                "prompt": j.prompt,
                "session_mode": j.session_mode,
                "notify_channels": j.notify_channels,
                "enabled": j.enabled,
            }
            for j in self._jobs.values()
            if j.dynamic
        ]
        self._jobs_file.write_text(json.dumps(dynamic, indent=2), encoding="utf-8")

    def _record_run(
        self,
        job_id: str,
        run_id: str,
        status: str,
        result: str | None,
        duration: float,
        started_at: datetime | None = None,
        error_type: str | None = None,
    ) -> None:
        """Append run record to .workpilot/cron/runs/{job_id}.jsonl."""
        self._runs_dir.mkdir(parents=True, exist_ok=True)
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        record: dict[str, Any] = {
            "run_id": run_id,
            "triggered_at": (started_at or datetime.now(UTC)).isoformat(),
            "status": status,
            "result_preview": result[:500] if result else "",
            "duration_s": round(duration, 2),
        }
        if error_type:
            record["error_type"] = error_type
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record) + "\n")

        # Auto-prune: keep last N entries
        self._prune_history(path)

    def _prune_history(self, path: Path) -> None:
        """Keep only the last HISTORY_MAX_ENTRIES lines."""
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
            if len(lines) > self.HISTORY_MAX_ENTRIES:
                path.write_text(
                    "\n".join(lines[-self.HISTORY_MAX_ENTRIES :]) + "\n",
                    encoding="utf-8",
                )
        except Exception:
            pass

    def get_history(self, job_id: str, limit: int = 20) -> list[dict]:
        """Read run history for a job."""
        path = self._runs_dir / f"{_safe_filename(job_id)}.jsonl"
        if not path.is_file():
            return []
        entries = []
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line:
                try:
                    entries.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        return entries[-limit:]
