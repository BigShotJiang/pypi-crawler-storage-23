"""Allow `python -m workpilot`."""

from workpilot.cli.commands import app

app()
