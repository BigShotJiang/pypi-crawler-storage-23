# flake8: noqa: E402

from sage.common.components.sage_embedding.embedding_model import EmbeddingModel


def apply_embedding_model(name: str = "default", **kwargs) -> EmbeddingModel:
    """Create an ``EmbeddingModel`` instance by method name.

    Args:
        name: Embedding method name, such as ``sagellm``, ``openai``, ``jina``.
        **kwargs: Method-specific arguments, such as ``model``, ``api_key`` and ``base_url``.
    """
    return EmbeddingModel(method=name, **kwargs)
