"""
agentcents local.py — Phase 10
Local LLM (Ollama) proxy with GPU power cost tracking.

Ollama calls go to: http://localhost:8082/ollama/<path>
  e.g. POST http://localhost:8082/ollama/api/chat

Config in ~/.agentcents.toml:
  [local]
  gpu_watts        = 40      # M1 Max under LLM load
  electricity_rate = 0.12    # $/kWh
  ollama_base_url  = "http://localhost:11434"

Cost formula:
  electricity_cost = (inference_seconds / 3600) * gpu_watts * electricity_rate
"""

import json
import time
import logging
from typing import Optional

import httpx
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse, JSONResponse

from agentcents.ledger import record_call

logger = logging.getLogger("agentcents.local")

router = APIRouter(prefix="/ollama")

# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _local_config() -> dict:
    try:
        from agentcents.config import load as load_config
        return load_config().get("local", {})
    except Exception:
        return {}


def _ollama_base() -> str:
    return _local_config().get("ollama_base_url", "http://localhost:11434")


def _gpu_watts() -> float:
    return float(_local_config().get("gpu_watts", 40))


def _electricity_rate() -> float:
    return float(_local_config().get("electricity_rate", 0.12))


def _calc_power_cost(elapsed_s: float) -> float:
    """Estimate electricity cost for inference."""
    hours = elapsed_s / 3600
    return hours * (_gpu_watts() / 1000) * _electricity_rate()


# ---------------------------------------------------------------------------
# Ollama routes
# ---------------------------------------------------------------------------

@router.api_route("/{path:path}", methods=["GET", "POST", "PUT", "DELETE"])
async def ollama_proxy(path: str, request: Request):
    """
    Transparent proxy to local Ollama instance.
    Tracks inference time and estimates GPU electricity cost.

    Usage: point your Ollama client at http://localhost:8082/ollama
    e.g.:  OLLAMA_HOST=http://localhost:8082/ollama ollama run llama3:8b
    """
    tag        = request.headers.get("X-Agentcents-Tag", "default")
    session_id = request.headers.get("X-Agentcents-Session", f"local-{int(time.time())}")
    target_url = f"{_ollama_base().rstrip('/')}/{path}"

    body_bytes = await request.body()
    body_json: Optional[dict] = None
    try:
        body_json = json.loads(body_bytes) if body_bytes else None
    except Exception:
        pass

    # Extract model from Ollama request format
    model_id = None
    if body_json:
        model_id = body_json.get("model")
        if model_id:
            model_id = f"ollama/{model_id}"

    is_streaming = body_json.get("stream", True) if body_json else True

    forward_headers = {
        k: v for k, v in request.headers.items()
        if k.lower() not in ("host", "content-length") and
           not k.lower().startswith("x-agentcents")
    }

    t0 = time.monotonic()

    async with httpx.AsyncClient(timeout=300) as client:
        if is_streaming:
            return await _handle_ollama_streaming(
                client, request.method, target_url,
                forward_headers, body_bytes, body_json,
                model_id, tag, session_id, t0,
            )
        else:
            return await _handle_ollama_standard(
                client, request.method, target_url,
                forward_headers, body_bytes, body_json,
                model_id, tag, session_id, t0,
            )


# ---------------------------------------------------------------------------
# Standard (non-streaming) Ollama response
# ---------------------------------------------------------------------------

async def _handle_ollama_standard(
    client, method, url, headers, body, body_json,
    model_id, tag, session_id, t0,
):
    resp    = await client.request(method, url, headers=headers, content=body)
    elapsed = time.monotonic() - t0

    resp_json     = None
    prompt_tokens = completion_tokens = None
    power_cost    = _calc_power_cost(elapsed)

    try:
        resp_json = resp.json()
        # Ollama /api/chat response format
        usage = resp_json.get("prompt_eval_count"), resp_json.get("eval_count")
        prompt_tokens     = resp_json.get("prompt_eval_count")
        completion_tokens = resp_json.get("eval_count")
    except Exception:
        pass

    record_call(
        model_id   = model_id or "ollama/unknown",
        tag        = tag,
        session_id = session_id,
        prompt_tokens     = prompt_tokens,
        completion_tokens = completion_tokens,
        cost_usd   = power_cost,
        elapsed_s  = elapsed,
        status     = resp.status_code,
    )

    logger.info(
        f"[{tag}|{session_id}] ✓ {model_id}  "
        f"in={prompt_tokens} out={completion_tokens}  "
        f"power=${power_cost:.6f}  {elapsed:.2f}s"
    )

    return JSONResponse(
        content    = resp_json if resp_json else {},
        status_code = resp.status_code,
    )


# ---------------------------------------------------------------------------
# Streaming Ollama response
# ---------------------------------------------------------------------------

async def _handle_ollama_streaming(
    client, method, url, headers, body, body_json,
    model_id, tag, session_id, t0,
):
    accumulated_prompt_tokens     = 0
    accumulated_completion_tokens = 0
    final_chunk: Optional[dict]   = None

    async def stream_generator():
        nonlocal accumulated_prompt_tokens, accumulated_completion_tokens, final_chunk

        async with client.stream(method, url, headers=headers, content=body) as resp:
            async for line in resp.aiter_lines():
                if not line.strip():
                    continue
                yield (line + "\n").encode()

                # Parse each NDJSON chunk from Ollama
                try:
                    chunk = json.loads(line)
                    if chunk.get("done"):
                        accumulated_prompt_tokens     = chunk.get("prompt_eval_count", 0)
                        accumulated_completion_tokens = chunk.get("eval_count", 0)
                        final_chunk = chunk
                except Exception:
                    pass

        elapsed    = time.monotonic() - t0
        power_cost = _calc_power_cost(elapsed)

        record_call(
            model_id   = model_id or "ollama/unknown",
            tag        = tag,
            session_id = session_id,
            prompt_tokens     = accumulated_prompt_tokens or None,
            completion_tokens = accumulated_completion_tokens or None,
            cost_usd   = power_cost,
            elapsed_s  = elapsed,
            status     = 200,
            streamed   = True,
        )

        logger.info(
            f"[{tag}|{session_id}] ✓ {model_id} (streamed)  "
            f"in={accumulated_prompt_tokens} out={accumulated_completion_tokens}  "
            f"power=${power_cost:.6f}  {elapsed:.2f}s"
        )

    return StreamingResponse(
        stream_generator(),
        media_type="application/x-ndjson",
    )


# ---------------------------------------------------------------------------
# Ollama model list helper
# ---------------------------------------------------------------------------

async def list_local_models() -> list:
    """Return list of locally available Ollama models."""
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{_ollama_base()}/api/tags")
            data = resp.json()
            return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []
