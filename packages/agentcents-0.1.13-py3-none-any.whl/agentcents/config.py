"""
agentcents config.py — Phase 5
Reads ~/.agentcents.toml for budget thresholds and settings.

Example ~/.agentcents.toml:
---
[budgets]
hourly  = 0.10      # alert if >$0.10/hour
daily   = 1.00      # alert if >$1.00/day
monthly = 20.00     # alert if >$20.00/month

[budgets.tags.my-project]
daily = 0.50        # per-tag daily budget

[advisor]
min_saving_pct = 20  # only suggest if saving >= 20%
"""

import os
from pathlib import Path

CONFIG_PATH = Path.home() / ".agentcents.toml"

DEFAULTS = {
    "budgets": {
        "hourly":  None,
        "daily":   None,
        "monthly": None,
        "tags":    {},
    },
    "advisor": {
        "min_saving_pct": 20,
    }
}


def load() -> dict:
    config = _deep_copy(DEFAULTS)
    if not CONFIG_PATH.exists():
        return config
    try:
        import tomllib  # Python 3.11+
    except ImportError:
        try:
            import tomli as tomllib  # pip install tomli
        except ImportError:
            return config  # no toml parser available
    try:
        with open(CONFIG_PATH, "rb") as f:
            user = tomllib.load(f)
        _merge(config, user)
    except Exception:
        pass
    return config


def write_default():
    """Write a starter config if none exists."""
    if CONFIG_PATH.exists():
        return
    CONFIG_PATH.write_text("""\
# agentcents configuration
# https://github.com/labham/agentcents

[budgets]
# Uncomment and set your thresholds (USD)
# hourly  = 0.10
# daily   = 1.00
# monthly = 20.00

# Per-tag budgets:
# [budgets.tags.my-project]
# daily = 0.50

[advisor]
min_saving_pct = 20   # only suggest alternatives with >= 20% savings
""")
    print(f"Created config: {CONFIG_PATH}")


def _deep_copy(d):
    import copy
    return copy.deepcopy(d)


def _merge(base, override):
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _merge(base[k], v)
        else:
            base[k] = v
