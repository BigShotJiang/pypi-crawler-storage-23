|Build Status| |PyPI|

vws-python
==========

Python library for the Vuforia Web Services (VWS) API and the Vuforia
Web Query API.

Installation
------------

.. code-block:: shell

   pip install vws-python

This is tested on Python |minimum-python-version|\+. Get in touch with
``adamdangoor@gmail.com`` if you would like to use this with another
language.

Getting Started
---------------

.. code-block:: python

   """Add a target to VWS and then query it."""

   import os
   import pathlib
   import uuid

   from vws import VWS, CloudRecoService

   server_access_key = os.environ["VWS_SERVER_ACCESS_KEY"]
   server_secret_key = os.environ["VWS_SERVER_SECRET_KEY"]
   client_access_key = os.environ["VWS_CLIENT_ACCESS_KEY"]
   client_secret_key = os.environ["VWS_CLIENT_SECRET_KEY"]

   vws_client = VWS(
       server_access_key=server_access_key,
       server_secret_key=server_secret_key,
   )

   cloud_reco_client = CloudRecoService(
       client_access_key=client_access_key,
       client_secret_key=client_secret_key,
   )

   name = "my_image_name_" + uuid.uuid4().hex

   image = pathlib.Path("high_quality_image.jpg")
   with image.open(mode="rb") as my_image_file:
       target_id = vws_client.add_target(
           name=name,
           width=1,
           image=my_image_file,
           active_flag=True,
           application_metadata=None,
       )

   vws_client.wait_for_target_processed(target_id=target_id)

   with image.open(mode="rb") as my_image_file:
       matching_targets = cloud_reco_client.query(image=my_image_file)

   assert matching_targets[0].target_id == target_id

Full Documentation
------------------

See the `full documentation <https://vws-python.github.io/vws-python/>`__.

.. |Build Status| image:: https://github.com/VWS-Python/vws-python/actions/workflows/ci.yml/badge.svg?branch=main
   :target: https://github.com/VWS-Python/vws-python/actions
.. |PyPI| image:: https://badge.fury.io/py/VWS-Python.svg
   :target: https://badge.fury.io/py/VWS-Python
.. |minimum-python-version| replace:: 3.13
