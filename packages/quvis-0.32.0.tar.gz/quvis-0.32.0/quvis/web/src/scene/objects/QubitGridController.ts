import * as THREE from 'three';
import { CircuitDataManager } from '../../data/managers/CircuitDataManager.js';
import { LayoutManager } from '../core/LayoutManager.js';
import { RenderManager } from '../core/RenderManager.js';
import { VisualizationStateManager } from '../core/VisualizationStateManager.js';
import { HeatmapManager } from '../core/HeatmapManager.js';
import { SmartCameraAlignment } from '../interaction/modules/SmartCameraAlignment.js';


/**
 * QubitGridController - Refactored main class that coordinates all subsystems
 * Maintains backward compatibility with the original QubitGrid API
 */
export class QubitGridController {
    // Core subsystems
    private dataManager: CircuitDataManager;
    private layoutManager: LayoutManager;
    private renderManager: RenderManager;
    private stateManager: VisualizationStateManager;
    private heatmapManager: HeatmapManager;
    private smartAlignment?: SmartCameraAlignment;

    // Scene references
    private scene: THREE.Scene;
    private camera: THREE.PerspectiveCamera;
    private mouse: THREE.Vector2;
    private onSlicesLoadedCallback?: (
        count: number,
        initialIndex: number
    ) => void;
    private onSettingsChanged?: (settings: any) => void;

    // State tracking
    public isFullyLoaded = false;
    private currentNumDeviceQubits: number = 0;
    private currentLayoutRunId: number = 0;

    constructor(
        scene: THREE.Scene,
        mouse: THREE.Vector2,
        camera: THREE.PerspectiveCamera,
        data: any, // Change to 'any' to handle the object type
        visualizationMode: 'compiled' | 'logical',
        initialMaxSlicesForHeatmap: number = 10,
        initialKRepel: number = 0.3,
        initialIdealDist: number = 5.0,
        initialIterations: number = 300,
        initialCoreDistance: number = 5.0,
        initialConnectionThickness: number = 0.05,
        initialInactiveElementAlpha: number = 0.1,
        initialQubitSize: number = 1.0,
        initialBlochSpheresVisible: boolean = false,
        initialConnectionLinesVisible: boolean = true,
        onSlicesLoadedCallback?: (count: number, initialIndex: number) => void,
        isLightBackground?: () => boolean,
        smartAlignment?: SmartCameraAlignment,
        onSettingsChanged?: (settings: any) => void
    ) {
        this.scene = scene;
        this.mouse = mouse;
        this.camera = camera;
        this.onSlicesLoadedCallback = onSlicesLoadedCallback;
        this.smartAlignment = smartAlignment;
        this.onSettingsChanged = onSettingsChanged;

        // Initialize subsystems
        this.dataManager = new CircuitDataManager();
        this.layoutManager = new LayoutManager({
            iterations: initialIterations,
            coreDistance: initialCoreDistance,
        });
        this.renderManager = new RenderManager(
            scene,
            initialQubitSize,
            initialConnectionThickness,
            initialInactiveElementAlpha,
            initialBlochSpheresVisible,
            initialConnectionLinesVisible,
            isLightBackground
        );
        this.stateManager = new VisualizationStateManager(
            (sliceIndex) => this.loadStateFromSlice(sliceIndex),
            initialMaxSlicesForHeatmap,
            visualizationMode
        );
        this.heatmapManager = new HeatmapManager(
            camera,
            1, // initial qubit count (will be updated)
            initialMaxSlicesForHeatmap
        );

        // Load initial data
        this.loadData(data);
    }

    // Public API methods (maintaining backward compatibility)

    public getActiveSliceCount(): number {
        return this.stateManager.getActiveSliceCount();
    }

    public getActiveCurrentSliceIndex(): number {
        return this.stateManager.getActiveCurrentSliceIndex();
    }

    get current_slice_data() {
        return this.stateManager.currentSliceData;
    }

    get lastMaxObservedRawHeatmapSum(): number {
        return this.heatmapManager.maxObservedRawSum;
    }

    get lastEffectiveSlicesForHeatmap(): number {
        return this.heatmapManager.effectiveSlicesForHeatmap;
    }

    get lastLayoutCalculationTime(): number {
        return this.layoutManager.lastLayoutCalculationTime;
    }

    get maxSlicesForHeatmap(): number {
        return this.heatmapManager.maxSlices;
    }

    get heatmap() {
        return this.heatmapManager.heatmapInstance;
    }

    get legend() {
        return this.heatmapManager.legendInstance;
    }

    get timeline() {
        return this.stateManager.timelineInstance;
    }

    public setCurrentSlice(sliceIndex: number): void {
        this.loadStateFromSlice(sliceIndex);
    }

    public loadStateFromSlice(sliceIndex: number): void {
        this.stateManager.setCurrentSliceInternal(sliceIndex);
        this.updateVisualization();
    }

    public get simulationParameters() {
        return {
            layout: this.layoutManager.parameters,
            appearance: this.renderManager.parameters // We might need to expose this too
        };
    }

    public get layoutParameters() {
        return this.layoutManager.parameters;
    }

    public isMultiCore(): boolean {
        return (this.dataManager.modularInfo?.num_cores || 1) > 1;
    }

    private runModularLayoutForCurrentCircuit(onComplete?: () => void): void {
        const deviceQubitCount = this.dataManager.deviceQubitCount;
        if (deviceQubitCount <= 0) {
            onComplete?.();
            return;
        }

        const runId = ++this.currentLayoutRunId;

        const layoutNodes = this.dataManager.layoutNodes;
        if (layoutNodes && layoutNodes.length > 0) {
            this.layoutManager.applyDeterministicLayout(layoutNodes);
            this.renderManager.updateQubitPositions(this.layoutManager.positions);
            this.heatmapManager.clearPositionsCache();
            this.heatmapManager.setVisible(true);
            this.updateVisualization();
            this.autoAlignCameraToLayout();
            onComplete?.();
            return;
        }

        const modularInfo = this.dataManager.modularInfo || {
            num_cores: 1,
            qubits_per_core: deviceQubitCount,
            global_topology: "custom",
            inter_core_links: []
        };

        this.heatmapManager.setVisible(false);

        this.layoutManager.calculateModularLayout(
            modularInfo,
            this.layoutManager.parameters.coreDistance,
            this.dataManager.couplingMap || [],
            (positions) => {
                if (this.currentLayoutRunId !== runId) return;
                this.renderManager.updateQubitPositions(positions);
                this.updateVisualization();
            }
        ).then(() => {
            if (this.currentLayoutRunId !== runId) return;
            // Layout is complete, render final and cleanup
            this.renderManager.updateQubitPositions(this.layoutManager.positions);
            this.heatmapManager.clearPositionsCache();
            this.heatmapManager.setVisible(true);
            this.updateVisualization();

            // Auto-align camera to optimal viewing angle for the layout
            this.autoAlignCameraToLayout();

            onComplete?.();
        });
    }



    public updateLayoutParameters(
        params: {
            repelForce?: number;
            idealDistance?: number;
            iterations?: number;
            coreDistance?: number;
            is3D?: boolean;
            distanceMaxMultiplier?: number;
        },
        onLayoutComplete?: () => void
    ): void {
        // Always update parameters
        this.layoutManager.updateParameters(params);

        const deviceQubitCount = this.dataManager.deviceQubitCount;

        if (deviceQubitCount > 0) {
            console.log('Calculating unified layout...');
            this.runModularLayoutForCurrentCircuit(onLayoutComplete);
        } else {
            onLayoutComplete?.();
        }
    }



    /**
     * Update connection colors based on current background mode
     */
    public updateConnectionColors(): void {
        this.renderManager.updateConnectionColors();
    }

    public updateIdealDistance(distance: number): void {
        this.layoutManager.updateIdealDistance(distance);
        this.renderManager.updateQubitPositions(this.layoutManager.positions);
        this.heatmapManager.clearPositionsCache();
        this.updateVisualization();
    }

    public applyGridLayout(): void {
        this.currentLayoutRunId++;
        this.heatmapManager.setVisible(true);
        this.layoutManager.applyGridLayoutToExistingQubits();
        this.renderManager.updateQubitPositions(this.layoutManager.positions);

        this.heatmapManager.clearPositionsCache();
        this.updateVisualization();
    }

    public setVisualizationMode(mode: 'compiled' | 'logical'): void {
        // Since we're always in multi-circuit mode now, we need to switch to the appropriate circuit
        // rather than switching modes within the same circuit
        console.warn(
            'setVisualizationMode is deprecated. Use switchToCircuit instead for multi-circuit mode.'
        );

        // Try to find a circuit of the desired type
        const circuits = this.dataManager.allCircuitsInfo;
        const targetCircuitIndex = circuits.findIndex(
            (circuit) => circuit.circuit_type === mode
        );

        if (targetCircuitIndex !== -1) {
            this.switchToCircuit(targetCircuitIndex);
        }
    }

    public switchToCircuit(circuitIndex: number): void {
        if (!this.dataManager.isMultiCircuit) {
            console.warn('Not in multi-circuit mode');
            return;
        }

        const previousQubitCount = this.currentNumDeviceQubits;

        this.dataManager.switchToCircuit(circuitIndex);
        this.stateManager.setVisualizationMode(
            this.dataManager.visualizationMode
        );

        // Reinitialize slices for new circuit
        this.stateManager.initializeSlices(this.dataManager.operationsPerSlice);

        // Get the new device info and qubit count
        const deviceQubitCount = this.dataManager.deviceQubitCount;
        if (deviceQubitCount === 0) {
            console.warn('No device info available for circuit');
            return;
        }

        const newQubitCount = deviceQubitCount;
        this.currentNumDeviceQubits = newQubitCount;

        // Check if we need to recreate the grid (different qubit count)
        if (newQubitCount !== previousQubitCount) {
            console.log(
                `Qubit count changed from ${previousQubitCount} to ${newQubitCount}, recreating grid`
            );

            // Recreate the grid with new qubit count
            this.recreateGridForNewQubitCount(newQubitCount);
        } else {
            console.log(
                `Qubit count unchanged (${newQubitCount}), updating existing grid`
            );
        }

        // Apply layout for this circuit.
        // runModularLayoutForCurrentCircuit applies deterministic backend layout
        // if layout_nodes are present, otherwise falls back to force-directed.
        this.runModularLayoutForCurrentCircuit();

        // Update connections based on circuit type
        if (this.dataManager.visualizationMode === 'logical') {
            let maxLogicalConnections = 0;
            this.dataManager.operationsPerSlice.forEach((ops_in_slice) => {
                const twoQubitOps = ops_in_slice.filter(
                    (op) => op.qubits.length === 2
                ).length;
                if (twoQubitOps > maxLogicalConnections) {
                    maxLogicalConnections = twoQubitOps;
                }
            });
            this.renderManager.initializeLogicalInstancedConnections(
                maxLogicalConnections
            );
        } else {
            const couplingMap = this.dataManager.couplingMap;
            if (couplingMap) {
                this.renderManager.initializeInstancedConnections(
                    couplingMap.length
                );
            }
        }

        // Apply per-circuit settings if available
        const circuitSettings = this.dataManager.currentCircuitSettings;
        if (circuitSettings) {
            console.log('Applying per-circuit settings:', circuitSettings);

            // Apply Layout Settings
            this.updateLayoutParameters({
                repelForce: circuitSettings.layout?.repel_force,
                idealDistance: circuitSettings.layout?.ideal_distance,
                iterations: circuitSettings.layout?.iterations,
                coreDistance: circuitSettings.layout?.core_distance,
            });

            // Apply Appearance Settings
            this.updateAppearanceParameters({
                qubitSize: circuitSettings.appearance?.qubit_size,
                connectionThickness: circuitSettings.appearance?.connection_thickness,
                inactiveAlpha: circuitSettings.appearance?.inactive_alpha,
                baseSize: circuitSettings.heatmap?.base_size,
            });

            if (circuitSettings.appearance?.render_bloch_spheres !== undefined) {
                this.setBlochSpheresVisible(circuitSettings.appearance.render_bloch_spheres);
            }
            if (circuitSettings.appearance?.render_connection_lines !== undefined) {
                this.setConnectionLinesVisible(circuitSettings.appearance.render_connection_lines);
            }

            // Apply Heatmap Settings
            this.updateHeatmapColorParameters({
                fadeThreshold: circuitSettings.heatmap?.fade_threshold,
                greenThreshold: circuitSettings.heatmap?.green_threshold,
                yellowThreshold: circuitSettings.heatmap?.yellow_threshold,
                intensityPower: circuitSettings.heatmap?.intensity_power,
                minIntensity: circuitSettings.heatmap?.min_intensity,
                borderWidth: circuitSettings.heatmap?.border_width,
            });

            if (circuitSettings.heatmap?.max_slices !== undefined && circuitSettings.heatmap.max_slices !== -1) {
                this.updateHeatmapSlices(circuitSettings.heatmap.max_slices);
            }

            // Notify UI of new settings
            if (this.onSettingsChanged) {
                this.onSettingsChanged(circuitSettings);
            }
        }

        this.updateVisualization();

        console.log(
            `Switched to circuit: ${circuitIndex} (${this.dataManager.visualizationMode})`
        );
    }

    // ...

    public updateAppearanceParameters(params: {
        qubitSize?: number;
        connectionThickness?: number;
        inactiveAlpha?: number;
        baseSize?: number;
    }): void {
        if (params.qubitSize !== undefined) {
            this.renderManager.setQubitScale(params.qubitSize);
        }
        if (params.connectionThickness !== undefined) {
            this.renderManager.setConnectionThickness(params.connectionThickness);
        }
        if (params.inactiveAlpha !== undefined) {
            this.renderManager.setInactiveElementAlpha(params.inactiveAlpha);
        }
        if (params.baseSize !== undefined) {
            this.heatmapManager.updateBaseSize(params.baseSize);
        }
        this.updateVisualization();
    }

    private recreateGridForNewQubitCount(newQubitCount: number): void {
        this.currentLayoutRunId++;

        // Seed positions with placeholder entries so the grid layout has keys to work with.
        // The actual layout (deterministic, force, etc.) is applied by the
        // caller (switchToCircuit) immediately after this method returns.
        this.layoutManager.clearPositions();
        for (let i = 0; i < newQubitCount; i++) {
            this.layoutManager.positions.set(i, new THREE.Vector3());
        }
        this.layoutManager.applyGridLayoutToExistingQubits();

        this.renderManager.createGrid(
            newQubitCount,
            this.layoutManager.positions
        );

        this.heatmapManager.initializeForSetup(
            this.camera,
            this.dataManager.qubitCount,
        );

        const renderWidth = this.camera.aspect || 1;
        const renderHeight = 1;
        this.heatmapManager.setAspectRatio(renderWidth / renderHeight);
        this.heatmapManager.setVisible(false);
    }

    public updateHeatmapSlices(maxSlices: number): void {
        this.stateManager.updateMaxSlicesForHeatmap(maxSlices);
        this.heatmapManager.updateMaxSlicesForHeatmap(maxSlices);
        this.updateVisualization();
    }

    public updateFidelityParameters(params: {
        oneQubitBase?: number;
        twoQubitBase?: number;
    }): void {
        console.log(
            'Fidelity parameters received in QubitGridController:',
            params
        );
        // Future implementation for fidelity visualization
    }

    private autoAlignCameraToLayout(): void {
        if (this.smartAlignment && this.layoutManager.positions.size > 0) {

            // Use 3-point plane detection method
            this.smartAlignment.alignToForceLayout(this.layoutManager.positions);

            // Alternative: Use minimal variance plane detection
            // this.smartAlignment.alignToMinimalVariancePlane(this.layoutManager.positions);
        } else {
            console.warn("Smart alignment not available or no qubit positions");
        }
    }

    public updateHeatmapColorParameters(params: {
        fadeThreshold?: number;
        greenThreshold?: number;
        yellowThreshold?: number;
        intensityPower?: number;
        minIntensity?: number;
        borderWidth?: number;
    }): void {
        this.heatmapManager.updateColorParameters(params);
        this.updateVisualization();
    }

    public updateHeatmapLightBackground(isLight: boolean): void {
        this.heatmapManager.updateLightBackground(isLight);
    }

    public getHeatmapColorParameters(): {
        fadeThreshold: number;
        greenThreshold: number;
        yellowThreshold: number;
        intensityPower: number;
        minIntensity: number;
        borderWidth: number;
    } {
        return this.heatmapManager.getColorParameters();
    }

    public updateLOD(cameraDistance: number): void {
        this.renderManager.updateLOD(
            cameraDistance,
            this.layoutManager.areaSide
        );
    }

    public setBlochSpheresVisible(visible: boolean): void {
        this.renderManager.setBlochSpheresVisible(
            visible,
            this.layoutManager.positions
        );
    }

    public setConnectionLinesVisible(visible: boolean): void {
        this.renderManager.setConnectionLinesVisible(visible);
    }

    public getGateCountForQubit(qubitId: number): {
        oneQubitGatesInWindow: number;
        twoQubitGatesInWindow: number;
        totalOneQubitGates: number;
        totalTwoQubitGates: number;
        windowForCountsInWindow: number;
    } {
        return this.dataManager.getGateCountForQubit(
            qubitId,
            this.stateManager.currentSlice,
            this.stateManager.lastEffectiveSlicesForHeatmap
        );
    }

    public dispose(): void {
        console.log('QubitGridController dispose called');

        // Dispose of all subsystems
        this.dataManager.clearData();
        this.layoutManager.dispose();
        this.renderManager.dispose();
        this.stateManager.dispose();
        this.heatmapManager.dispose();

        console.log('QubitGridController resources cleaned up');
    }

    // Private methods

    private async loadData(data: any): Promise<void> {
        console.log('loadData called with data:', data);
        try {
            if (data && typeof data === 'object') {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                this.dataManager.loadData(data.circuits);
            }

            await this.initializeAfterDataLoad();
            this.onSlicesLoadedCallback?.(
                this.dataManager.getSliceCount(),
                this.stateManager.currentSlice
            );
        } catch (error) {
            console.error('Failed to load data:', error);
            this.handleLoadError();
        }
    }

    private async initializeAfterDataLoad(): Promise<void> {
        const deviceQubitCount = this.dataManager.deviceQubitCount;
        if (deviceQubitCount === 0) return;

        const couplingMap = this.dataManager.couplingMap;
        const qubitCount = this.dataManager.qubitCount;

        // Initialize layout
        const runId = ++this.currentLayoutRunId;
        const layoutNodes = this.dataManager.layoutNodes;

        if (layoutNodes && layoutNodes.length > 0) {
            console.log('Applying deterministic backend layout...');
            this.layoutManager.applyDeterministicLayout(layoutNodes);
        } else {
            const modularInfo = this.dataManager.modularInfo || {
                num_cores: 1,
                qubits_per_core: deviceQubitCount,
                global_topology: "custom",
                inter_core_links: []
            };

            this.heatmapManager.setVisible(false);
            console.log('Initializing unified layout...');
            await this.layoutManager.calculateModularLayout(
                modularInfo,
                this.layoutManager.parameters.coreDistance,
                couplingMap || []
            );
        }

        if (this.currentLayoutRunId !== runId) return;

        // Initialize slices in state manager
        this.stateManager.initializeSlices(this.dataManager.operationsPerSlice);

        // Create qubits in render manager
        this.renderManager.createGrid(
            deviceQubitCount,
            this.layoutManager.positions
        );

        // Initialize connections
        if (couplingMap) {
            this.renderManager.initializeInstancedConnections(
                couplingMap.length
            );
        }

        // Initialize heatmap
        this.heatmapManager.initializeForSetup(
            this.camera,
            qubitCount,
        );

        // Update heatmap aspect ratio
        const renderWidth = this.camera.aspect || 1;
        const renderHeight = 1;
        this.heatmapManager.setAspectRatio(renderWidth / renderHeight);

        // Initial visualization update
        this.heatmapManager.setVisible(true);
        this.updateVisualization();

        // Set fully loaded flag when data is ready
        this.isFullyLoaded = this.dataManager.isFullyLoaded;
    }

    private handleLoadError(): void {
        console.error('Handling load error with fallback data');

        const runId = ++this.currentLayoutRunId;
        this.heatmapManager.setVisible(false);

        // Create fallback layout
        this.layoutManager.calculateModularLayout({
            num_cores: 1,
            qubits_per_core: 9,
            global_topology: "custom"
        }, this.layoutManager.parameters.coreDistance, []).then(() => {
            if (this.currentLayoutRunId !== runId) return;
            // Create fallback state
            this.stateManager.createFallbackState();

            // Create fallback qubits
            this.renderManager.createGrid(9, this.layoutManager.positions);

            // Create fallback heatmap
            this.heatmapManager.handleError(this.camera, 9);
            this.heatmapManager.setVisible(true);

            this.onSlicesLoadedCallback?.(1, 0);
        });
    }

    private updateVisualization(): void {
        // Get current state data
        const currentSliceIndex = this.stateManager.currentSlice;
        const interactingQubits =
            this.stateManager.getInteractingQubitsForSlice(currentSliceIndex);
        const lastSliceChangeData = this.stateManager.lastSliceChangeData;
        const maxSlicesForHeatmap = this.stateManager.maxHeatmapSlices;

        // Update qubit states
        this.renderManager.updateQubitStates(interactingQubits);

        // Update qubit opacities
        this.renderManager.updateQubitOpacities(
            lastSliceChangeData,
            maxSlicesForHeatmap
        );

        // Update heatmap
        const lastLoadedSlice = this.dataManager.processedSlicesCount - 1;
        const effectiveSliceIndex = Math.min(
            currentSliceIndex,
            lastLoadedSlice
        );

        const heatmapResult = this.heatmapManager.updateHeatmap(
            this.layoutManager.positions,
            effectiveSliceIndex,
            this.dataManager.cumulativeQubitInteractionData
        );

        // Update state manager with heatmap results
        this.stateManager.updateHeatmapResults(
            heatmapResult.maxObservedRawWeightedSum,
            heatmapResult.numSlicesEffectivelyUsed
        );

        // Update connections
        const currentSliceInteractionPairs =
            this.stateManager.getCurrentSliceInteractionPairs(
                this.dataManager.interactionPairsPerSlice
            );

        // Identify inter-core connections if modular info exists
        let interCoreConnections: Set<string> | undefined;
        const modularInfo = this.dataManager.modularInfo;
        const couplingMap = this.dataManager.couplingMap;

        if (modularInfo && couplingMap) {
            interCoreConnections = new Set<string>();
            const qubitsPerCore = modularInfo.qubits_per_core;

            for (const pair of couplingMap) {
                const q1 = pair[0];
                const q2 = pair[1];
                const core1 = Math.floor(q1 / qubitsPerCore);
                const core2 = Math.floor(q2 / qubitsPerCore);

                if (core1 !== core2) {
                    interCoreConnections.add(`${Math.min(q1, q2)}-${Math.max(q1, q2)}`);
                }
            }
        }

        this.renderManager.drawConnections(
            this.stateManager.visualizationMode,
            this.layoutManager.positions,
            this.dataManager.couplingMap,
            currentSliceInteractionPairs,
            this.dataManager,
            currentSliceIndex,
            maxSlicesForHeatmap,
            interCoreConnections
        );

        // Update isFullyLoaded status
        this.isFullyLoaded = this.dataManager.isFullyLoaded;
    }

    // Getters for accessing subsystem instances (for debugging/advanced usage)
    public get dataManagerInstance(): CircuitDataManager {
        return this.dataManager;
    }

    public get layoutManagerInstance(): LayoutManager {
        return this.layoutManager;
    }

    public get renderManagerInstance(): RenderManager {
        return this.renderManager;
    }

    public get stateManagerInstance(): VisualizationStateManager {
        return this.stateManager;
    }

    public get heatmapManagerInstance(): HeatmapManager {
        return this.heatmapManager;
    }
}
