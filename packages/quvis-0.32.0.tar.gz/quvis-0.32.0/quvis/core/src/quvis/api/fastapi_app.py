"""
FastAPI Backend for Quvis Quantum Circuit Visualization

This module provides a REST API for quantum circuit generation and visualization.
"""

import logging
from typing import Any
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn


from .playground import PlaygroundAPI
from ..enums import AlgorithmType, TopologyType
from ..config import CircuitGenerationConfig
from .constants import (
    MIN_QUBITS, MAX_QUBITS,
    MIN_OPTIMIZATION_LEVEL, MAX_OPTIMIZATION_LEVEL, DEFAULT_OPTIMIZATION_LEVEL,
    MIN_HEAVY_HEX_DISTANCE,
    MIN_QAOA_REPS,
    DEFAULT_QUBITS,
    DEFAULT_HEAVY_HEX_DISTANCE, MAX_HEAVY_HEX_DISTANCE, STEP_HEAVY_HEX_DISTANCE,
    MIN_GRID_SIZE, MAX_GRID_SIZE, DEFAULT_GRID_SIZE,
    MAX_QAOA_REPS, DEFAULT_QAOA_REPS,
)

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class CircuitGenerationRequest(BaseModel):
    """Request model for circuit generation endpoint."""

    algorithm: str = Field(
        ...,
        description=f"Algorithm type: {', '.join([a.value for a in AlgorithmType])}",
        examples=[AlgorithmType.QFT.value]
    )
    num_qubits: int = Field(
        ...,
        ge=MIN_QUBITS,
        le=MAX_QUBITS,
        description="Number of logical qubits",
        examples=[5]
    )
    physical_qubits: int | None = Field(
        None,
        ge=MIN_QUBITS,
        le=MAX_QUBITS,
        description="Number of physical qubits for device topology (defaults to num_qubits)",
        examples=[9]
    )
    topology: str = Field(
        ...,
        description=f"Device topology: {', '.join([t.value for t in TopologyType])}",
        examples=[TopologyType.GRID.value]
    )
    optimization_level: int = Field(
        DEFAULT_OPTIMIZATION_LEVEL,
        ge=MIN_OPTIMIZATION_LEVEL,
        le=MAX_OPTIMIZATION_LEVEL,
        description="Qiskit transpiler optimization level",
        examples=[DEFAULT_OPTIMIZATION_LEVEL]
    )
    reps: int | None = Field(
        None,
        ge=MIN_QAOA_REPS,
        le=MAX_QAOA_REPS,
        description="Number of repetitions for QAOA algorithm",
        examples=[DEFAULT_QAOA_REPS]
    )
    heavy_hex_distance: int | None = Field(
        None,
        ge=MIN_HEAVY_HEX_DISTANCE,
        le=MAX_HEAVY_HEX_DISTANCE,
        description="Odd distance parameter for Heavy Hex topology",
        examples=[DEFAULT_HEAVY_HEX_DISTANCE]
    )
    qasm: str | None = Field(
        None,
        description="QASM string content for custom circuits",
        examples=["OPENQASM 2.0;\\ninclude \\\"qelib1.inc\\\";\\nqreg q[2];\\nh q[0];\\ncx q[0],q[1];\\n"]
    )

    class Config:
        json_schema_extra = {
            "example": {
                "algorithm": AlgorithmType.QFT.value,
                "num_qubits": 5,
                "physical_qubits": 9,
                "topology": TopologyType.GRID.value,
                "optimization_level": 1
            }
        }


class CircuitGenerationResponse(BaseModel):
    """Response model for circuit generation."""

    circuits: list[dict[str, Any]]
    total_circuits: int
    generation_successful: bool
    error_message: str | None = None


class ErrorResponse(BaseModel):
    """Error response model."""

    error: str
    generation_successful: bool = False


class HealthCheckResponse(BaseModel):
    """Health check response model."""

    status: str
    version: str
    supported_algorithms: list[str]


# Application lifecycle
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application startup and shutdown."""
    logger.info("🚀 Starting Quvis FastAPI Backend")
    logger.info("✓ PlaygroundAPI initialized")
    yield
    logger.info("👋 Shutting down Quvis FastAPI Backend")


# Create FastAPI application
app = FastAPI(
    title="Quvis API",
    description="Quantum Circuit Visualization API for generating and transpiling quantum circuits",
    version="v0.32.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",  # Vite dev server
        "http://localhost:4173",  # Vite preview server
        "https://*.github.io",    # GitHub Pages (wildcard)
        "https://*.amazonaws.com", # AWS deployments
        "https://*.cloudfront.net", # CloudFront
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize PlaygroundAPI
playground_api = PlaygroundAPI()


# Routes
@app.get("/", response_model=dict)
async def root():
    """Root endpoint."""
    return {
        "service": "Quvis API",
        "version": "v0.32.0",
        "docs": "/docs",
        "health": "/api/health"
    }


@app.get("/api/health", response_model=HealthCheckResponse)
async def health_check():
    """Health check endpoint."""
    return HealthCheckResponse(
        status="healthy",
        version="v0.32.0",
        supported_algorithms=playground_api.get_supported_algorithms()
    )


@app.get("/api/constants")
async def get_constants():
    """Return all parameter bounds and defaults for the playground UI."""
    return {
        "qubits": {
            "min": MIN_QUBITS,
            "max": MAX_QUBITS,
            "default": DEFAULT_QUBITS,
        },
        "heavy_hex_distance": {
            "min": MIN_HEAVY_HEX_DISTANCE,
            "max": MAX_HEAVY_HEX_DISTANCE,
            "step": STEP_HEAVY_HEX_DISTANCE,
            "default": DEFAULT_HEAVY_HEX_DISTANCE,
        },
        "grid_size": {
            "min": MIN_GRID_SIZE,
            "max": MAX_GRID_SIZE,
            "default": DEFAULT_GRID_SIZE,
        },
        "optimization_level": {
            "min": MIN_OPTIMIZATION_LEVEL,
            "max": MAX_OPTIMIZATION_LEVEL,
            "default": DEFAULT_OPTIMIZATION_LEVEL,
        },
        "qaoa_reps": {
            "min": MIN_QAOA_REPS,
            "max": MAX_QAOA_REPS,
            "default": DEFAULT_QAOA_REPS,
        },
    }


@app.post(
    "/api/generate-circuit",
    response_model=CircuitGenerationResponse,
    responses={
        200: {"description": "Circuit generated successfully"},
        400: {"model": ErrorResponse, "description": "Invalid request parameters"},
        500: {"model": ErrorResponse, "description": "Circuit generation failed"},
    }
)
async def generate_circuit(request: CircuitGenerationRequest):
    """
    Generate quantum circuit visualization data.

    This endpoint creates both logical and compiled versions of a quantum circuit
    based on the specified algorithm, topology, and optimization parameters.
    """
    try:
        logger.info(
            f"📥 Received circuit generation request: "
            f"algorithm={request.algorithm}, qubits={request.num_qubits}, "
            f"topology={request.topology}"
        )

        # Set physical qubits to num_qubits if not provided
        physical_qubits = request.physical_qubits or request.num_qubits

        # Prepare kwargs for algorithm-specific parameters
        kwargs = {"optimization_level": request.optimization_level}
        if request.reps is not None:
            kwargs["reps"] = request.reps
            
        import os, tempfile
        temp_qasm_file = None
        
        try:
            if request.algorithm == AlgorithmType.CUSTOM_QASM and request.qasm:
                # We need to write it to a temp file because the playground API expects a file path
                fd, temp_qasm_path = tempfile.mkstemp(suffix=".qasm", prefix="quvis_api_")
                with os.fdopen(fd, 'w') as f:
                    f.write(request.qasm)
                temp_qasm_file = temp_qasm_path
                kwargs["qasm_path"] = temp_qasm_path
            elif request.algorithm == AlgorithmType.CUSTOM_QASM:
                raise ValueError("qasm parameter is required for Custom QASM")

            # Create configuration object
            config = CircuitGenerationConfig(
                algorithm=AlgorithmType(request.algorithm),
                num_qubits=request.num_qubits,
                physical_qubits=request.physical_qubits or request.num_qubits,
                topology=TopologyType(request.topology),
                optimization_level=request.optimization_level,
                heavy_hex_distance=request.heavy_hex_distance,
                algorithm_params=kwargs
            )

            # Generate circuit data
            result = playground_api.generate_visualization_data(config)
            
        finally:
            if temp_qasm_file and os.path.exists(temp_qasm_file):
                try:
                    os.unlink(temp_qasm_file)
                except Exception as e:
                    logger.warning(f"Failed to clean up temp QASM file: {e}")

        logger.info("✅ Circuit generated successfully")

        return CircuitGenerationResponse(
            circuits=result["circuits"],
            total_circuits=result["total_circuits"],
            generation_successful=True
        )

    except ValueError as e:
        logger.error(f"❌ Validation error: {e}")
        raise HTTPException(
            status_code=400,
            detail=str(e)
        )
    except Exception as e:
        logger.error(f"❌ Circuit generation failed: {e}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Circuit generation failed: {str(e)}"
        )


if __name__ == "__main__":

    uvicorn.run(
        "quvis.api.fastapi_app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )
