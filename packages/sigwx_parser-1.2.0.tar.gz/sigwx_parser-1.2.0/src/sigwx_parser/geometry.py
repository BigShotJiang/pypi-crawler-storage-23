from typing import Optional
from xml.etree.ElementTree import Element

import antimeridian
from shapely.geometry import shape, mapping
from shapely.geometry.polygon import orient


def _parse_poslist(element: Element) -> list:
    """Parse a GML posList element into [[lon, lat], ...] coordinates.

    Args:
        element: An XML element whose text contains space-separated lat/lon pairs.

    Returns:
        A list of [lon, lat] coordinate pairs as floats.

    Raises:
        ValueError: If the element has no text content.
    """
    if element.text is None:
        raise ValueError("posList element has no text content")
    raw = element.text.strip().split()
    return [[float(y), float(x)] for x, y in zip(raw[::2], raw[1::2])]


def _build_feature(geometry: dict, feature_type: str, feature_id: str,
                   upper_fl: Optional[str] = None,
                   lower_fl: Optional[str] = None) -> dict:
    return {
        "type": "Feature",
        "geometry": geometry,
        "properties": {
            "feature_id": feature_id,
            "phenomenon": feature_type,
            "upper_fl": upper_fl,
            "lower_fl": lower_fl,
        },
    }


def process_polygons(feature_type: str, polygon_patch: Element, feature_id: str,
                     upper_fl: Optional[str] = None,
                     lower_fl: Optional[str] = None) -> dict:
    """Parse a GML PolygonPatch element and return a GeoJSON Feature with Polygon geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        polygon_patch: An XML element containing the GML PolygonPatch data.
        feature_id: A unique identifier for the feature.
        upper_fl: Optional upper flight level.
        lower_fl: Optional lower flight level.

    Returns:
        A GeoJSON Feature dict with Polygon geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
    """
    exterior_el = polygon_patch.find(".//exterior//posList")
    if exterior_el is None or exterior_el.text is None:
        raise ValueError(f"Missing exterior posList in feature {feature_id}")
    exterior = _parse_poslist(exterior_el)

    interiors = []
    for interior in polygon_patch.findall(".//interior//posList"):
        if interior.text is None:
            raise ValueError(f"Missing interior posList text in feature {feature_id}")
        interiors.append(_parse_poslist(interior))

    feature = _build_feature(
        {"type": "Polygon", "coordinates": [exterior, *interiors]},
        feature_type,
        feature_id,
        upper_fl,
        lower_fl,
    )
    raw_shape = shape(feature["geometry"])
    properly_wound_shape = orient(raw_shape, sign=1.0)
    feature["geometry"] = mapping(properly_wound_shape)

    fixed_feature = antimeridian.fix_geojson(feature)
    return fixed_feature


def process_points(feature_type: str, point: Element, feature_id: str,
                   upper_fl: Optional[str] = None,
                   lower_fl: Optional[str] = None) -> dict:
    """Parse a GML Point element and return a GeoJSON Feature with Point geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        point: An XML element containing the GML Point data.
        feature_id: A unique identifier for the feature.
        upper_fl: Optional upper flight level.
        lower_fl: Optional lower flight level.

    Returns:
        A GeoJSON Feature dict with Point geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
    """
    pos_el = point.find(".//pos")
    if pos_el is None or pos_el.text is None:
        raise ValueError(f"Missing pos element in feature {feature_id}")
    coords = pos_el.text.strip().split()
    coords[1], coords[0] = float(coords[0]), float(coords[1])  # Swap to [lon, lat] (GeoJSON order)
    return _build_feature(
        {"type": "Point", "coordinates": coords},
        feature_type,
        feature_id,
        upper_fl,
        lower_fl,
    )


def process_lines(feature_type: str, line: Element, feature_id: str,
                  upper_fl: Optional[str] = None,
                  lower_fl: Optional[str] = None) -> dict:
    """Parse a GML curve/line element and return a GeoJSON Feature with LineString geometry.

    Args:
        feature_type: The phenomenon type label for the feature.
        line: An XML element containing the GML line data.
        feature_id: A unique identifier for the feature.
        upper_fl: Optional upper flight level.
        lower_fl: Optional lower flight level.

    Returns:
        A GeoJSON Feature dict with LineString geometry.

    Raises:
        ValueError: If required XML elements are missing or have no text content.
    """
    poslist_el = line.find(".//posList")
    if poslist_el is None or poslist_el.text is None:
        raise ValueError(f"Missing posList element in feature {feature_id}")
    coords = _parse_poslist(poslist_el)
    feature = _build_feature(
        {"type": "LineString", "coordinates": coords},
        feature_type,
        feature_id,
        upper_fl,
        lower_fl,
    )
    fixed_feature = antimeridian.fix_geojson(feature)
    return fixed_feature

