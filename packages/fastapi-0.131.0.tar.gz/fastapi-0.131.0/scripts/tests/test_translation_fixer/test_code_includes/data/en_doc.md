# Header

{* ../../docs_src/dependencies/tutorial013_an_py310.py ln[19:21] *}

Some text

{* ../../docs_src/bigger_applications/app_an_py310/internal/admin.py hl[3] title["app/internal/admin.py"] *}

Some more text

{* ../../docs_src/dependencies/tutorial013_an_py310.py ln[30:38] hl[31:33] *}

And even more text
