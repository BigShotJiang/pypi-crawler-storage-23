from pathlib import Path

import pytest

from tutorbot_safety_agent.curriculum.config_loader import load_curriculum_configs
from tutorbot_safety_agent.curriculum.versioning import parse_version


def write_yaml(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def test_parse_version():
    assert parse_version("1") == (1,)
    assert parse_version("1.0") == (1, 0)
    assert parse_version("2.3.4") == (2, 3, 4)


def test_highest_version_is_selected(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse_v1.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        """,
    )

    write_yaml(
        tmp_path / "cbse_v2.yaml",
        """
        curriculum_id: CBSE
        version: 2.0
        grades: {}
        """,
    )

    configs = load_curriculum_configs(tmp_path)

    assert configs["CBSE"].version == "2.0"


def test_multiple_curricula_versioned_independently(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        """,
    )

    write_yaml(
        tmp_path / "ccss.yaml",
        """
        curriculum_id: CCSS
        version: 3.1
        grades: {}
        """,
    )

    configs = load_curriculum_configs(tmp_path)

    assert configs["CBSE"].version == "1.0"
    assert configs["CCSS"].version == "3.1"
