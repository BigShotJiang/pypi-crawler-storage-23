from tutorbot_safety_agent.rules.engine import RuleEngine
from tutorbot_safety_agent.rules.forbidden_topic import ForbiddenTopicRule
from tutorbot_safety_agent.rules.grade_depth import GradeDepthRule
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


def make_als(statement_id: str, text: str):
    return AtomicLearningStatement(
        statement_id=statement_id,
        text=text,
        source_text=text,
    )


def base_context_and_curriculum(grade: int):
    context = StudentContext(
        curriculum="CBSE",
        grade=grade,
        subject="Physics",
    )

    curriculum = CurriculumExpectation(
        curriculum_id="CBSE",
        grade=grade,
        subject="Physics",
        allowed_topics=[],
        disallowed_topics=["Quantum Mechanics"],
    )

    return context, curriculum


# --------------------------------------------------
# Test 1: No violations
# --------------------------------------------------

def test_rule_engine_no_violations():
    statements = [
        make_als("s1", "Force is a push or pull."),
    ]

    context, curriculum = base_context_and_curriculum(grade=5)

    engine = RuleEngine(
        rules=[
            ForbiddenTopicRule(),
            GradeDepthRule(),
        ]
    )

    result = engine.evaluate(
        statements=statements,
        student_context=context,
        curriculum=curriculum,
    )

    assert result.violations == []
    assert result.has_violations is False


def test_rule_engine_single_statement_multiple_violations():
    statements = [
        make_als("s1", "Quantum mechanics explains particles."),
    ]

    context, curriculum = base_context_and_curriculum(grade=8)

    engine = RuleEngine(
        rules=[
            ForbiddenTopicRule(),
            GradeDepthRule(),
        ]
    )

    result = engine.evaluate(
        statements=statements,
        student_context=context,
        curriculum=curriculum,
    )

    assert result.violation_count == 2
    assert result.has_violations is True

    rule_ids = {v.rule_id for v in result.violations}
    assert rule_ids == {
        "FORBIDDEN_TOPIC",
        "GRADE_DEPTH_MISMATCH",
    }



# --------------------------------------------------
# Test 3: Multiple violations from different rules
# --------------------------------------------------

def test_rule_engine_multiple_violations():
    statements = [
        make_als("s1", "Quantum mechanics uses integrals."),
    ]

    context, curriculum = base_context_and_curriculum(grade=6)

    engine = RuleEngine(
        rules=[
            ForbiddenTopicRule(),
            GradeDepthRule(),
        ]
    )

    result = engine.evaluate(
        statements=statements,
        student_context=context,
        curriculum=curriculum,
    )

    assert result.violation_count == 2
    assert result.has_violations is True

    rule_ids = {v.rule_id for v in result.violations}
    assert rule_ids == {
        "FORBIDDEN_TOPIC",
        "GRADE_DEPTH_MISMATCH",
    }
