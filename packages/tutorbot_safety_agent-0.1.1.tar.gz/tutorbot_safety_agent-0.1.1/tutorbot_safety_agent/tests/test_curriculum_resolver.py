import pytest

from tutorbot_safety_agent.context.resolution import resolve_student_context
from tutorbot_safety_agent.curriculum.resolver import BaseCurriculumResolver
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


def test_resolver_returns_none_when_context_missing():
    """
    STRICT mode: missing student context → resolver must return None.
    """
    resolver = BaseCurriculumResolver()

    context_resolution = resolve_student_context(None)
    expectation = resolver.resolve(context_resolution)

    assert expectation is None


def test_resolver_returns_none_when_context_invalid():
    """
    STRICT mode: invalid student context → resolver must return None.
    """
    resolver = BaseCurriculumResolver()

    context_resolution = resolve_student_context({
        "curriculum": "CBSE",
        "grade": 99,  # invalid grade
        "subject": "Physics",
    })

    expectation = resolver.resolve(context_resolution)

    assert expectation is None


def test_resolver_returns_expectation_when_context_valid():
    """
    Non-STRICT mode: valid context → resolver returns CurriculumExpectation.
    """
    resolver = BaseCurriculumResolver()

    context_resolution = resolve_student_context({
        "curriculum": "CBSE",
        "grade": 8,
        "subject": "Physics",
    })

    expectation = resolver.resolve(context_resolution)

    assert expectation is not None
    assert isinstance(expectation, CurriculumExpectation)


def test_expectation_fields_match_student_context():
    """
    Resolver output must faithfully reflect student context.
    """
    resolver = BaseCurriculumResolver()

    context_resolution = resolve_student_context({
        "curriculum": "CCSS",
        "grade": 5,
        "subject": "math",
    })

    expectation = resolver.resolve(context_resolution)

    assert expectation is not None
    assert expectation.curriculum_id == "CCSS"
    assert expectation.grade == 5
    assert expectation.subject == "Math"


def test_default_expectation_is_safe_and_empty():
    """
    Default resolver must not allow any topics implicitly.
    """
    resolver = BaseCurriculumResolver()

    context_resolution = resolve_student_context({
        "curriculum": "AU",
        "grade": 10,
        "subject": "Science",
    })

    expectation = resolver.resolve(context_resolution)

    assert expectation is not None
    assert expectation.allowed_topics == []
    assert expectation.disallowed_topics == []
    assert "default safe state" in (expectation.notes or "").lower()
