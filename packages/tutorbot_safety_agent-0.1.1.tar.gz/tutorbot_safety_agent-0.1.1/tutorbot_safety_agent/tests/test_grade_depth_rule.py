from tutorbot_safety_agent.rules.grade_depth import GradeDepthRule
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation
from tutorbot_safety_agent.rules.reason_codes import ReasonCode


def make_als(text: str):
    return AtomicLearningStatement(
        statement_id="stmt-1",
        text=text,
        source_text=text,
    )


def test_no_violation_for_basic_content():
    rule = GradeDepthRule()

    violations = rule.evaluate(
        statements=[make_als("Force is a push or pull.")],
        student_context=StudentContext(
            curriculum="CBSE",
            grade=5,
            subject="Physics",
        ),
        curriculum=CurriculumExpectation(
            curriculum_id="CBSE",
            grade=5,
            subject="Physics",
            allowed_topics=[],
            disallowed_topics=[],
        ),
    )

    assert violations == []


def test_violation_for_advanced_depth_in_low_grade():
    rule = GradeDepthRule()

    violations = rule.evaluate(
        statements=[make_als("The integral of velocity gives displacement.")],
        student_context=StudentContext(
            curriculum="CBSE",
            grade=6,
            subject="Physics",
        ),
        curriculum=CurriculumExpectation(
            curriculum_id="CBSE",
            grade=6,
            subject="Physics",
            allowed_topics=[],
            disallowed_topics=[],
        ),
    )

    assert len(violations) == 1
    v = violations[0]

    assert v.rule_id == "GRADE_DEPTH_MISMATCH"
    assert v.reason_code == ReasonCode.GRADE_DEPTH_EXCEEDED
