from tutorbot_safety_agent.rules.forbidden_topic import ForbiddenTopicRule
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


def make_als(text: str):
    return AtomicLearningStatement(
        statement_id="stmt-1",
        text=text,
        source_text=text,
    )


def test_no_violation_when_no_disallowed_topics():
    rule = ForbiddenTopicRule()

    violations = rule.evaluate(
        statements=[make_als("Force is push or pull.")],
        student_context=StudentContext(
            curriculum="CBSE",
            grade=8,
            subject="Physics",
        ),
        curriculum=CurriculumExpectation(
            curriculum_id="CBSE",
            grade=8,
            subject="Physics",
            allowed_topics=[],
            disallowed_topics=[],
        ),
    )

    assert violations == []


def test_violation_detected_for_forbidden_topic():
    rule = ForbiddenTopicRule()

    violations = rule.evaluate(
        statements=[make_als("Quantum mechanics explains particles.")],
        student_context=StudentContext(
            curriculum="CBSE",
            grade=8,
            subject="Physics",
        ),
        curriculum=CurriculumExpectation(
            curriculum_id="CBSE",
            grade=8,
            subject="Physics",
            allowed_topics=[],
            disallowed_topics=["Quantum Mechanics"],
        ),
    )

    assert len(violations) == 1
    v = violations[0]

    assert v.rule_id == "FORBIDDEN_TOPIC"
    assert v.reason_code == "FORBIDDEN_TOPIC_DETECTED"
    assert v.statement_id == "stmt-1"
    assert "Quantum Mechanics" not in v.message  # lowercased internally
