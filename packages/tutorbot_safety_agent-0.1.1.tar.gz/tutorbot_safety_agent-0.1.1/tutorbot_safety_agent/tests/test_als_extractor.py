import pytest

from tutorbot_safety_agent.extractor import extract_atomic_learning_statements
from tutorbot_safety_agent.schemas import AtomicLearningStatement


def extract_texts(result):
    """Helper to extract ALS text content only."""
    return [als.text for als in result]


def test_empty_input_returns_empty_list():
    assert extract_atomic_learning_statements("") == []
    assert extract_atomic_learning_statements("   ") == []
    assert extract_atomic_learning_statements(None) == []


def test_single_sentence():
    text = "Ohm's Law states that V = IR."
    als = extract_atomic_learning_statements(text)

    assert len(als) == 1
    assert als[0].text == "Ohm's Law states that V = IR."


def test_multiple_simple_sentences():
    text = "Voltage is V. Current is I. Resistance is R."
    als = extract_atomic_learning_statements(text)

    assert extract_texts(als) == [
        "Voltage is V.",
        "Current is I.",
        "Resistance is R.",
    ]


def test_abbreviation_over_splitting_is_accepted_v1():
    """
    v1 behavior: abbreviations like 'e.g.' may over-split.
    This is documented and accepted.
    """
    text = "Ohm's Law applies, e.g. V = IR."
    als = extract_atomic_learning_statements(text)

    assert extract_texts(als) == [
        "Ohm's Law applies, e.g.",
        "V = IR.",
    ]


def test_decimal_numbers_may_split_v1():
    """
    v1 behavior: decimals may be split.
    This is acceptable for safety evaluation.
    """
    text = "The value is 3.14 volts. This is approximate."
    als = extract_atomic_learning_statements(text)

    assert extract_texts(als) == [
        "The value is 3.14 volts.",
        "This is approximate.",
    ]


def test_real_world_mixed_example():
    """
    Canonical example discussed during design.
    Over-splitting is acceptable.
    """
    text = (
        "Dr. Smith explained Ohm's Law, e.g. V = IR. "
        "The resistance was 3.14 ohMs. This is correct!"
    )

    als = extract_atomic_learning_statements(text)

    assert extract_texts(als) == [
        "Dr.",
        "Smith explained Ohm's Law, e.g.",
        "V = IR.",
        "The resistance was 3.14 ohMs.",
        "This is correct!",
    ]


def test_each_als_has_required_fields():
    text = "Voltage equals current times resistance."
    als = extract_atomic_learning_statements(text)

    for item in als:
        assert isinstance(item, AtomicLearningStatement)
        assert isinstance(item.statement_id, str)
        assert isinstance(item.text, str)
        assert isinstance(item.source_text, str)
        assert item.text == item.source_text


def test_deterministic_number_of_statements():
    """
    Determinism check: same input → same ALS count.
    """
    text = "A. B. C."
    als1 = extract_atomic_learning_statements(text)
    als2 = extract_atomic_learning_statements(text)

    assert len(als1) == len(als2)
