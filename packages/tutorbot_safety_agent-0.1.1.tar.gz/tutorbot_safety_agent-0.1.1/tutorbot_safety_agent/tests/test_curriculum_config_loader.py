from pathlib import Path

import pytest

from tutorbot_safety_agent.curriculum.config_loader import (
    load_curriculum_configs,
    CurriculumLoadError,
)


def write_yaml(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")


def test_invalid_yaml_raises_error(tmp_path: Path):
    write_yaml(
        tmp_path / "bad.yaml",
        "curriculum_id: CBSE\nversion: 1.0\ngrades: [",
    )

    with pytest.raises(CurriculumLoadError):
        load_curriculum_configs(tmp_path)


def test_missing_required_fields_raises_error(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        """,
    )

    with pytest.raises(CurriculumLoadError):
        load_curriculum_configs(tmp_path)


def test_extra_fields_are_rejected(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        unexpected_field: true
        """,
    )

    with pytest.raises(CurriculumLoadError):
        load_curriculum_configs(tmp_path)


def test_multiple_versions_select_highest(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse_v1.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        """,
    )

    write_yaml(
        tmp_path / "cbse_v2.yaml",
        """
        curriculum_id: CBSE
        version: 2.0
        grades: {}
        """,
    )

    configs = load_curriculum_configs(tmp_path)

    assert "CBSE" in configs
    assert configs["CBSE"].version == "2.0"

def test_same_version_duplicate_is_rejected(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse_a.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        """,
    )

    write_yaml(
        tmp_path / "cbse_b.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades: {}
        """,
    )

    with pytest.raises(CurriculumLoadError):
        load_curriculum_configs(tmp_path)


def test_valid_configs_load_successfully(tmp_path: Path):
    write_yaml(
        tmp_path / "cbse.yaml",
        """
        curriculum_id: CBSE
        version: 1.0
        grades:
          8:
            subjects:
              Physics:
                allowed_topics:
                  - Force and Pressure
        """,
    )

    write_yaml(
        tmp_path / "ccss.yaml",
        """
        curriculum_id: CCSS
        version: 1.0
        grades:
          5:
            subjects:
              Math:
                allowed_topics:
                  - Fractions
        """,
    )

    configs = load_curriculum_configs(tmp_path)

    assert set(configs.keys()) == {"CBSE", "CCSS"}
    assert configs["CBSE"].grades[8].subjects["Physics"].allowed_topics == [
        "Force and Pressure"
    ]
