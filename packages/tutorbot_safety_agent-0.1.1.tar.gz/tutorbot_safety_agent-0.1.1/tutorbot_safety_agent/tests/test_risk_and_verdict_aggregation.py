from tutorbot_safety_agent.aggregation.risk import calculate_risk_score
from tutorbot_safety_agent.aggregation.verdict import aggregate_verdict, Verdict
from tutorbot_safety_agent.rules.violations import RuleViolation
from tutorbot_safety_agent.rules.reason_codes import ReasonCode
from tutorbot_safety_agent.rules.categories import RuleCategory
from tutorbot_safety_agent.rules.results import RuleEvaluationResult


def make_violation(reason_code: ReasonCode) -> RuleViolation:
    return RuleViolation(
        rule_id="TEST_RULE",
        category=RuleCategory.GRADE,
        reason_code=reason_code,
        message="test",
        statement_id="s1",
    )


# --------------------------------------------------
# Risk scoring tests
# --------------------------------------------------

def test_risk_score_no_violations():
    score = calculate_risk_score([])
    assert score == 0.0


def test_risk_score_single_forbidden_topic():
    score = calculate_risk_score(
        [make_violation(ReasonCode.FORBIDDEN_TOPIC_DETECTED)]
    )
    assert score == 1.0


def test_risk_score_single_grade_depth():
    score = calculate_risk_score(
        [make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED)]
    )
    assert score == 0.7


def test_risk_score_duplicate_reason_codes_do_not_stack():
    score = calculate_risk_score(
        [
            make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED),
            make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED),
        ]
    )
    assert score == 0.7


def test_risk_score_multiple_reason_codes_cap_at_one():
    score = calculate_risk_score(
        [
            make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED),
            make_violation(ReasonCode.UNSAFE_PEDAGOGY),
        ]
    )
    assert score == 1.0 or score == 0.7 + 0.4  # capped to 1.0 in implementation


# --------------------------------------------------
# Verdict aggregation tests
# --------------------------------------------------

def test_verdict_pass_when_no_violations():
    result = RuleEvaluationResult(violations=[])
    verdict, risk = aggregate_verdict(result)

    assert verdict == Verdict.PASS
    assert risk == 0.0


def test_verdict_rewrite_for_medium_risk():
    result = RuleEvaluationResult(
        violations=[make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED)]
    )
    verdict, risk = aggregate_verdict(result)

    assert verdict == Verdict.REWRITE
    assert risk == 0.7


def test_verdict_block_for_critical_risk():
    result = RuleEvaluationResult(
        violations=[make_violation(ReasonCode.FORBIDDEN_TOPIC_DETECTED)]
    )
    verdict, risk = aggregate_verdict(result)

    assert verdict == Verdict.BLOCK
    assert risk == 1.0


def test_verdict_block_dominates_mixed_violations():
    result = RuleEvaluationResult(
        violations=[
            make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED),
            make_violation(ReasonCode.FORBIDDEN_TOPIC_DETECTED),
        ]
    )
    verdict, risk = aggregate_verdict(result)

    assert verdict == Verdict.BLOCK
    assert risk == 1.0


def test_verdict_rewrite_for_multiple_non_critical_violations():
    result = RuleEvaluationResult(
        violations=[
            make_violation(ReasonCode.GRADE_DEPTH_EXCEEDED),
            make_violation(ReasonCode.UNSAFE_PEDAGOGY),
        ]
    )
    verdict, risk = aggregate_verdict(result)

    assert verdict == Verdict.BLOCK
    assert risk == 1.0
