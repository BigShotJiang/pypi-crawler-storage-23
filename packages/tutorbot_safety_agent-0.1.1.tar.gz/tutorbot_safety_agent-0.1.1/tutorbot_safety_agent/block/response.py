from dataclasses import dataclass
from typing import Optional

from tutorbot_safety_agent.rules.results import RuleEvaluationResult


@dataclass(frozen=True)
class BlockResponse:
    """
    Represents a safe response when content is blocked.
    """

    message: str
    rule_result: RuleEvaluationResult

    # Optional reference for internal use (never shown to student)
    internal_reason: Optional[str] = None
