from tutorbot_safety_agent.block.response import BlockResponse
from tutorbot_safety_agent.rules.results import RuleEvaluationResult


def default_block_fallback(
    rule_result: RuleEvaluationResult,
) -> BlockResponse:
    """
    Default safe fallback when content is blocked.
    """

    return BlockResponse(
        message=(
            "Let’s pause here and take a safer approach. "
            "This topic isn’t suitable for your current level, "
            "but I can help explain a related concept in a simpler way. "
            "Tell me what part you’d like to learn next."
        ),
        rule_result=rule_result,
        internal_reason="BLOCK_VERDICT_TRIGGERED",
    )
