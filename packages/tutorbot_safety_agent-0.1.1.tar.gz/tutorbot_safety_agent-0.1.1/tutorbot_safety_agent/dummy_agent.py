from typing import Dict

from .agent import SafetyAgent
from .schemas import SafetyDecision, DecisionType


class DummySafetyAgent(SafetyAgent):
    """
    Dummy implementation of SafetyAgent.

    This agent performs no real safety evaluation and always
    returns PASS. Intended only for development and integration
    testing.
    """

    def evaluate(
        self,
        ai_output: str,
        student_context: Dict
    ) -> SafetyDecision:
        return SafetyDecision(
            decision=DecisionType.PASS,
            reason_codes=["dummy_agent_not_implemented"],
            rewritten_text=None,
            risk_score=0.0,
        )
