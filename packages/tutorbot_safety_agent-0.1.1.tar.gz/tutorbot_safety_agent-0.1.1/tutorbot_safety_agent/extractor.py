import re
import uuid
from typing import List

from .logging_utils import log_event
from .schemas import AtomicLearningStatement


# Simple, deterministic sentence boundary:
# split on '.', '?', '!' followed by whitespace
_SENTENCE_SPLIT_REGEX = re.compile(r'(?<=[.!?])\s+')


def extract_atomic_learning_statements(
    text: str,
) -> List[AtomicLearningStatement]:
    """
    Atomic Learning Statement (ALS) extractor – v1.

    Design principles:
    - Deterministic
    - Simple
    - Over-splitting is acceptable
    - No NLP heuristics
    - No abbreviation intelligence

    Known limitations (accepted in v1):
    - Abbreviations like 'e.g.' may split into multiple ALS
    - Some ALS may be fragments
    """

    if not text or not text.strip():
        return []

    raw_parts = _SENTENCE_SPLIT_REGEX.split(text.strip())

    statements: List[AtomicLearningStatement] = []

    for part in raw_parts:
        cleaned = part.strip()
        if not cleaned:
            continue

        als = AtomicLearningStatement(
            statement_id=str(uuid.uuid4()),
            text=cleaned,
            source_text=cleaned,
        )

        statements.append(als)

        # 🔍 Task 5: Audit / debug logging (opt-in via env var)
        log_event(
            event="ALS_EXTRACTED",
            payload={
                "statement_id": als.statement_id,
                "text": als.text,
            },
        )

    return statements
