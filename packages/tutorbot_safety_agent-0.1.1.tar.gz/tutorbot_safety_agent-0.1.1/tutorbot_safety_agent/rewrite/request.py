from dataclasses import dataclass
from typing import List

from tutorbot_safety_agent.rules.results import RuleEvaluationResult
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


@dataclass(frozen=True)
class RewriteRequest:
    """
    Encapsulates all information needed to safely rewrite a response.
    """

    original_response: str

    student_context: StudentContext
    curriculum: CurriculumExpectation

    rule_result: RuleEvaluationResult

    constraints: List[str]
