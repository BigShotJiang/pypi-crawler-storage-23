from abc import ABC, abstractmethod

from tutorbot_safety_agent.rewrite.request import RewriteRequest


class RewriteHandler(ABC):
    """
    Interface for safe rewrite implementations.
    """

    @abstractmethod
    def rewrite(self, request: RewriteRequest) -> str:
        """
        Produce a safe, student-appropriate rewritten response.

        Rules:
        - Must respect student context and curriculum
        - Must avoid all detected violations
        - Must use supportive, instructional tone
        """
        raise NotImplementedError
