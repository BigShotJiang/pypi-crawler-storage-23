from pathlib import Path
from typing import Dict

import yaml
from pydantic import ValidationError

from collections import defaultdict
from tutorbot_safety_agent.curriculum.versioning import parse_version


from tutorbot_safety_agent.curriculum.schemas import CurriculumConfig


class CurriculumLoadError(RuntimeError):
    """Raised when curriculum configuration loading fails."""
    pass


def load_curriculum_configs(
    config_dir: Path,
) -> Dict[str, CurriculumConfig]:
    """
    Load, validate, and select active curriculum configs.

    Returns:
        Dict[curriculum_id, CurriculumConfig] (active versions only)

    Raises:
        CurriculumLoadError if any config is invalid or ambiguous.
    """

    if not config_dir.exists() or not config_dir.is_dir():
        raise CurriculumLoadError(
            f"Curriculum config directory not found: {config_dir}"
        )

    grouped = defaultdict(list)

    for path in sorted(config_dir.glob("*.yaml")):
        try:
            with path.open("r", encoding="utf-8") as f:
                raw = yaml.safe_load(f)

            config = CurriculumConfig(**raw)
            existing_versions = {
                c.version for c in grouped[config.curriculum_id]
            }

            if config.version in existing_versions:
                raise CurriculumLoadError(
                    f"Duplicate curriculum version detected: "
                    f"{config.curriculum_id} v{config.version}"
                )

            grouped[config.curriculum_id].append(config)

        except (yaml.YAMLError, ValidationError) as e:
            raise CurriculumLoadError(
                f"Invalid curriculum config: {path.name}"
            ) from e

    if not grouped:
        raise CurriculumLoadError("No curriculum configs found")

    active: Dict[str, CurriculumConfig] = {}

    for curriculum_id, configs in grouped.items():
        try:
            # Sort by parsed semantic version
            configs.sort(
                key=lambda c: parse_version(c.version)
            )
        except Exception as e:
            raise CurriculumLoadError(
                f"Invalid version in curriculum {curriculum_id}"
            ) from e

        # Select highest version
        active[curriculum_id] = configs[-1]

    return active