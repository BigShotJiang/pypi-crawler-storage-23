from abc import ABC, abstractmethod
from typing import Optional

from tutorbot_safety_agent.context.resolution import ContextResolution
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


class CurriculumResolver(ABC):
    """
    Abstract curriculum resolver interface.
    """

    @abstractmethod
    def resolve(
        self,
        context_resolution: ContextResolution,
    ) -> Optional[CurriculumExpectation]:
        """
        Resolve curriculum expectations for a student.

        Returns:
        - CurriculumExpectation when resolution is possible
        - None when STRICT mode applies
        """
        raise NotImplementedError
    
class BaseCurriculumResolver(CurriculumResolver):
    """
    Default resolver implementation.

    Behavior:
    - STRICT mode → return None
    - Non-STRICT → placeholder resolution (to be backed by config)
    """

    def resolve(
        self,
        context_resolution: ContextResolution,
    ) -> Optional[CurriculumExpectation]:

        # STRICT mode: fail closed
        if context_resolution.strict_mode:
            return None

        context = context_resolution.context
        if context is None:
            return None  # defensive

        # Placeholder resolution (real rules come in User Story 3.2)
        return CurriculumExpectation(
            curriculum_id=context.curriculum.value,
            grade=context.grade,
            subject=context.subject,
            allowed_topics=[],
            disallowed_topics=[],
            notes="No curriculum rules loaded (default safe state)",
        )
