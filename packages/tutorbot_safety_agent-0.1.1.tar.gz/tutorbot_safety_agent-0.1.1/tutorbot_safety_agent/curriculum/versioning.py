from typing import Tuple


class InvalidCurriculumVersion(ValueError):
    pass


def parse_version(version: str) -> Tuple[int, ...]:
    """
    Parse a semantic version string into a comparable tuple.

    Examples:
        "1" -> (1,)
        "1.0" -> (1, 0)
        "1.2.3" -> (1, 2, 3)
    """
    try:
        parts = tuple(int(p) for p in version.split("."))
    except ValueError as e:
        raise InvalidCurriculumVersion(
            f"Invalid curriculum version: {version}"
        ) from e

    if not parts:
        raise InvalidCurriculumVersion(
            f"Empty curriculum version: {version}"
        )

    return parts
