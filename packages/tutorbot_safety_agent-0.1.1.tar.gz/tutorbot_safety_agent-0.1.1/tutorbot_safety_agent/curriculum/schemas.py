from dataclasses import dataclass
from typing import Dict, List, Optional, Union

from pydantic import BaseModel, Field, ConfigDict, field_validator


# ============================================================
# Runtime schema (USED BY RESOLVER)
# ============================================================

@dataclass(frozen=True)
class CurriculumExpectation:
    """
    Represents curriculum expectations for a student context.

    This is a runtime object produced by the curriculum resolver.
    """

    curriculum_id: str
    grade: int
    subject: str

    allowed_topics: List[str]
    disallowed_topics: List[str]

    notes: Optional[str] = None


# ============================================================
# Configuration schemas (USED AT STARTUP)
# ============================================================

class SubjectRules(BaseModel):
    """
    Rules for a single subject at a given grade.
    """
    model_config = ConfigDict(extra="forbid")

    allowed_topics: List[str] = Field(default_factory=list)
    disallowed_topics: List[str] = Field(default_factory=list)


class GradeRules(BaseModel):
    """
    Rules for all subjects within a grade.
    """
    model_config = ConfigDict(extra="forbid")

    subjects: Dict[str, SubjectRules]


class CurriculumConfig(BaseModel):
    """
    Schema for a curriculum configuration file (YAML / JSON).

    Loaded and validated at startup.
    """
    model_config = ConfigDict(extra="forbid")

    curriculum_id: str
    version: Union[str, float, int]
    grades: Dict[int, "GradeRules"]

    @field_validator("version", mode="before")
    @classmethod
    def normalize_version(cls, v) -> str:
        """
        Normalize YAML numeric versions (e.g. 1.0) to string.
        """
        return str(v)
