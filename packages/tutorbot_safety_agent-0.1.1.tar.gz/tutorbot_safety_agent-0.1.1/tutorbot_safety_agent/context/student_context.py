from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field, validator


class Curriculum(str, Enum):
    CBSE = "CBSE"
    CCSS = "CCSS"
    AU = "AU"


class StudentContext(BaseModel):
    """
    Represents curriculum-relevant student context.

    This context is provided by TutorBot at runtime and
    drives curriculum-aware safety evaluation.
    """

    curriculum: Curriculum = Field(
        ...,
        description="Curriculum or board (e.g., CBSE, CCSS, AU)",
    )

    grade: int = Field(
        ...,
        ge=1,
        le=12,
        description="Grade or year level of the student",
    )

    subject: str = Field(
        ...,
        min_length=1,
        description="Subject being studied (e.g., Math, Physics)",
    )

    country: Optional[str] = Field(
        None,
        description="Country or region (e.g., IN, US, AU)",
    )

    language: Optional[str] = Field(
        None,
        description="Instruction language (e.g., en, hi)",
    )

    @validator("subject")
    def normalize_subject(cls, v: str) -> str:
        return v.strip().title()
