from dataclasses import dataclass
from typing import Optional

from pydantic import ValidationError

from .student_context import StudentContext


@dataclass(frozen=True)
class ContextResolution:
    """
    Result of resolving student context.
    """
    context: Optional[StudentContext]
    strict_mode: bool
    reason: str


def resolve_student_context(
    raw_context: Optional[dict],
) -> ContextResolution:
    """
    Resolve and validate StudentContext.

    STRICT mode is enabled when:
    - Context is missing
    - Context is invalid
    - Required fields are absent
    """

    if raw_context is None:
        return ContextResolution(
            context=None,
            strict_mode=True,
            reason="student_context_missing",
        )

    try:
        context = StudentContext(**raw_context)
        return ContextResolution(
            context=context,
            strict_mode=False,
            reason="student_context_valid",
        )

    except ValidationError as e:
        return ContextResolution(
            context=None,
            strict_mode=True,
            reason="student_context_invalid",
        )
