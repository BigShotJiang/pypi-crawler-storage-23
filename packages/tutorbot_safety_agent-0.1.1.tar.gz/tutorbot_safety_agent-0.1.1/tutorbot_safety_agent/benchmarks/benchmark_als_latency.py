import time
from tutorbot_safety_agent.streaming_buffer import SentenceBuffer
from tutorbot_safety_agent.extractor import extract_atomic_learning_statements


def benchmark():
    buffer = SentenceBuffer()

    chunk = "Voltage is V. Current is I. Resistance is R. "
    iterations = 10_000

    start = time.perf_counter()

    for _ in range(iterations):
        segments = buffer.push(chunk)
        for seg in segments:
            extract_atomic_learning_statements(seg)

    end = time.perf_counter()

    total_ms = (end - start) * 1000
    avg_us = (total_ms / iterations) * 1000

    print(f"Iterations: {iterations}")
    print(f"Total time: {total_ms:.2f} ms")
    print(f"Avg per iteration: {avg_us:.2f} µs")


if __name__ == "__main__":
    benchmark()
