from typing import Iterable, Set

from tutorbot_safety_agent.rules.reason_codes import ReasonCode
from tutorbot_safety_agent.rules.violations import RuleViolation


# ----------------------------
# Risk weights (v1)
# ----------------------------

RISK_WEIGHTS = {
    ReasonCode.FORBIDDEN_TOPIC_DETECTED: 1.0,
    ReasonCode.GRADE_DEPTH_EXCEEDED: 0.7,
    ReasonCode.SUBJECT_MISMATCH: 0.7,
    ReasonCode.UNSAFE_PEDAGOGY: 0.4,
}


def calculate_risk_score(
    violations: Iterable[RuleViolation],
) -> float:
    """
    Calculate aggregated risk score from rule violations.

    - Each reason code contributes once
    - Score is capped at 1.0
    - Deterministic and explainable
    """

    seen: Set[ReasonCode] = set()
    score = 0.0

    for v in violations:
        if v.reason_code in seen:
            continue

        weight = RISK_WEIGHTS.get(v.reason_code, 0.0)
        score += weight
        seen.add(v.reason_code)

    return min(1.0, round(score, 2))
