from enum import Enum
from typing import Iterable, Tuple

from tutorbot_safety_agent.aggregation.risk import calculate_risk_score
from tutorbot_safety_agent.rules.results import RuleEvaluationResult


class Verdict(str, Enum):
    PASS = "PASS"
    REWRITE = "REWRITE"
    BLOCK = "BLOCK"


_VERDICT_PRECEDENCE = {
    Verdict.PASS: 0,
    Verdict.REWRITE: 1,
    Verdict.BLOCK: 2,
}


def aggregate_verdict(
    result: RuleEvaluationResult,
) -> Tuple[Verdict, float]:
    """
    Aggregate rule evaluation into a final verdict.

    Mixed-statement handling rule:
    - BLOCK dominates
    - REWRITE dominates PASS
    """

    risk = calculate_risk_score(result.violations)

    # Primary mapping (risk-based)
    if risk >= 1.0:
        verdict = Verdict.BLOCK
    elif risk >= 0.4:
        verdict = Verdict.REWRITE
    else:
        verdict = Verdict.PASS

    return verdict, risk
