from typing import List

from tutorbot_safety_agent.rules.base import Rule
from tutorbot_safety_agent.rules.categories import RuleCategory
from tutorbot_safety_agent.rules.violations import RuleViolation
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation
from tutorbot_safety_agent.rules.reason_codes import ReasonCode


class ForbiddenTopicRule(Rule):
    """
    Detects explicitly forbidden curriculum topics in ALS text.
    """

    rule_id = "FORBIDDEN_TOPIC"

    def evaluate(
        self,
        statements: List[AtomicLearningStatement],
        student_context: StudentContext,
        curriculum: CurriculumExpectation,
    ) -> List[RuleViolation]:

        violations: List[RuleViolation] = []

        disallowed = [
            topic.lower() for topic in curriculum.disallowed_topics
        ]

        if not disallowed:
            return violations  # nothing to check

        for statement in statements:
            text = statement.text.lower()

            for topic in disallowed:
                if topic in text:
                    violations.append(
                        RuleViolation(
                            rule_id=self.rule_id,
                            category=RuleCategory.GRADE,
                            reason_code=ReasonCode.FORBIDDEN_TOPIC_DETECTED,
                            message=(
                                f"Topic '{topic}' is not allowed for "
                                f"{curriculum.subject} Grade {curriculum.grade}"
                            ),
                            statement_id=statement.statement_id,
                            metadata={
                                "topic": topic,
                                "grade": str(curriculum.grade),
                                "subject": curriculum.subject,
                                "curriculum": curriculum.curriculum_id,
                            },
                        )
                    )

        return violations
