import json
import logging
from typing import Any, Dict

from tutorbot_safety_agent.rules.results import RuleEvaluationResult
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation


logger = logging.getLogger("tutorbot_safety.rules")


def log_rule_evaluation(
    *,
    student_context: StudentContext,
    curriculum: CurriculumExpectation,
    result: RuleEvaluationResult,
) -> None:
    """
    Emit a structured log entry for deterministic rule evaluation.
    """

    payload: Dict[str, Any] = {
        "event": "RULE_EVALUATION",
        "curriculum_id": curriculum.curriculum_id,
        "grade": student_context.grade,
        "subject": student_context.subject,
        "violation_count": result.violation_count,
        "violations": [
            {
                "rule_id": v.rule_id,
                "category": v.category.value,
                "reason_code": v.reason_code.value,
                "statement_id": v.statement_id,
                "metadata": v.metadata,
            }
            for v in result.violations
        ],
    }

    logger.info(json.dumps(payload))
