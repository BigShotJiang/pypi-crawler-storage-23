from enum import Enum


class ReasonCode(str, Enum):
    """
    Canonical reason codes for deterministic safety violations.

    These codes are part of the Safety Agent compliance contract.
    """

    # Grade-related
    FORBIDDEN_TOPIC_DETECTED = "FORBIDDEN_TOPIC_DETECTED"
    GRADE_DEPTH_EXCEEDED = "GRADE_DEPTH_EXCEEDED"

    # Subject-related (reserved)
    SUBJECT_MISMATCH = "SUBJECT_MISMATCH"

    # Pedagogy-related (reserved)
    UNSAFE_PEDAGOGY = "UNSAFE_PEDAGOGY"
