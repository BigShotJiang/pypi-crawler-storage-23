from typing import Iterable, List

from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation
from tutorbot_safety_agent.rules.base import Rule
from tutorbot_safety_agent.rules.violations import RuleViolation
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.rules.results import RuleEvaluationResult
from tutorbot_safety_agent.rules.logging import log_rule_evaluation


class RuleEngine:
    """
    Deterministic rule evaluation engine.

    Executes rules in order and aggregates violations.
    """

    def __init__(self, rules: Iterable[Rule]):
        self._rules = list(rules)

    def evaluate(
    self,
    statements,
    student_context,
    curriculum,
    ):
        violations = []

        for rule in self._rules:
            result = rule.evaluate(
                statements=statements,
                student_context=student_context,
                curriculum=curriculum,
            )

            if result:
                violations.extend(result)

        evaluation_result = RuleEvaluationResult(violations=violations)

        # 🔒 Centralized logging hook
        log_rule_evaluation(
            student_context=student_context,
            curriculum=curriculum,
            result=evaluation_result,
        )

        return evaluation_result
