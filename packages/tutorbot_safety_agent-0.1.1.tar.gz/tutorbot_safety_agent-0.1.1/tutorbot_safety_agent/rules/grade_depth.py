from typing import List

from tutorbot_safety_agent.rules.base import Rule
from tutorbot_safety_agent.rules.categories import RuleCategory
from tutorbot_safety_agent.rules.violations import RuleViolation
from tutorbot_safety_agent.schemas import AtomicLearningStatement
from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation
from tutorbot_safety_agent.rules.reason_codes import ReasonCode


# ----------------------------
# Depth configuration (v1)
# ----------------------------

GRADE_MAX_DEPTH = {
    range(1, 6): 0,     # Grades 1–5
    range(6, 11): 1,    # Grades 6–10
    range(11, 13): 2,   # Grades 11–12
}

DEPTH_KEYWORDS = {
    2: [
        "quantum",
        "derivation",
        "proof",
        "integral",
        "differential",
        "matrix",
        "tensor",
        "eigen",
        "wave function",
    ],
    1: [
        "formula",
        "equation",
        "derive",
        "graph",
        "solve for",
    ],
}


def max_allowed_depth(grade: int) -> int:
    for grade_range, depth in GRADE_MAX_DEPTH.items():
        if grade in grade_range:
            return depth
    return 0  # fail-safe


def detect_statement_depth(text: str) -> int:
    lowered = text.lower()
    for depth, keywords in DEPTH_KEYWORDS.items():
        for kw in keywords:
            if kw in lowered:
                return depth
    return 0


class GradeDepthRule(Rule):
    """
    Detects grade-depth mismatches in ALS content.
    """

    rule_id = "GRADE_DEPTH_MISMATCH"

    def evaluate(
        self,
        statements: List[AtomicLearningStatement],
        student_context: StudentContext,
        curriculum: CurriculumExpectation,
    ) -> List[RuleViolation]:

        violations: List[RuleViolation] = []

        allowed_depth = max_allowed_depth(student_context.grade)

        for stmt in statements:
            detected_depth = detect_statement_depth(stmt.text)

            if detected_depth > allowed_depth:
                violations.append(
                    RuleViolation(
                        rule_id=self.rule_id,
                        category=RuleCategory.GRADE,
                        reason_code=ReasonCode.GRADE_DEPTH_EXCEEDED,
                        message=(
                            f"Content depth ({detected_depth}) exceeds "
                            f"allowed depth for Grade {student_context.grade}"
                        ),
                        statement_id=stmt.statement_id,
                        metadata={
                            "detected_depth": str(detected_depth),
                            "allowed_depth": str(allowed_depth),
                            "grade": str(student_context.grade),
                            "subject": student_context.subject,
                        },
                    )
                )

        return violations
