from dataclasses import dataclass
from typing import Dict, Optional

from tutorbot_safety_agent.rules.categories import RuleCategory
from tutorbot_safety_agent.rules.reason_codes import ReasonCode


@dataclass(frozen=True)
class RuleViolation:
    """
    Represents a deterministic rule violation.

    This is a factual, explainable safety finding.
    """

    rule_id: str
    category: RuleCategory

    message: str
    reason_code: ReasonCode

    statement_id: Optional[str] = None
    metadata: Optional[Dict[str, str]] = None
