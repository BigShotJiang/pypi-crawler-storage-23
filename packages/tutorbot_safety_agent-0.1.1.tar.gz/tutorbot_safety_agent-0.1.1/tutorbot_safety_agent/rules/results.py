from dataclasses import dataclass, field
from typing import List

from tutorbot_safety_agent.rules.violations import RuleViolation


@dataclass(frozen=True)
class RuleEvaluationResult:
    """
    Structured result of deterministic rule evaluation.

    This is the canonical output of the rules engine.
    """

    violations: List[RuleViolation] = field(default_factory=list)

    @property
    def has_violations(self) -> bool:
        return len(self.violations) > 0

    @property
    def violation_count(self) -> int:
        return len(self.violations)
