from abc import ABC, abstractmethod
from typing import List

from tutorbot_safety_agent.context.student_context import StudentContext
from tutorbot_safety_agent.curriculum.schemas import CurriculumExpectation
from tutorbot_safety_agent.rules.violations import RuleViolation
from tutorbot_safety_agent.schemas import AtomicLearningStatement


class Rule(ABC):
    """
    Base interface for all deterministic safety rules.
    """

    rule_id: str

    @abstractmethod
    def evaluate(
        self,
        statements: List[AtomicLearningStatement],
        student_context: StudentContext,
        curriculum: CurriculumExpectation,
    ) -> List[RuleViolation]:
        """
        Evaluate the rule against given inputs.

        Returns:
            List of RuleViolation (empty if no violations).
        """
        raise NotImplementedError
