from enum import Enum


class RuleCategory(str, Enum):
    """
    High-level categories for deterministic safety rules.

    Categories describe *why* a rule exists, not how it is implemented.
    """

    GRADE = "grade"
    SUBJECT = "subject"
    PEDAGOGY = "pedagogy"
