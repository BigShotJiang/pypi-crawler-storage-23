from abc import ABC, abstractmethod
from typing import Dict

from .schemas import SafetyDecision


class SafetyAgent(ABC):
    """
    Safety Agent contract.

    Any implementation MUST:
    - Accept raw AI output and student context
    - Return a SafetyDecision
    - Be deterministic
    - Fail closed (handled by caller)
    """

    @abstractmethod
    def evaluate(
        self,
        ai_output: str,
        student_context: Dict
    ) -> SafetyDecision:
        """
        Evaluate AI-generated content and return a safety decision.

        :param ai_output: Raw text produced by TutorBot LLM
        :param student_context: Curriculum, grade, subject, mode, etc.
        :return: SafetyDecision (PASS / REWRITE / BLOCK)
        """
        raise NotImplementedError
