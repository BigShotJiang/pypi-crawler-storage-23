def assert_no_unsafe_leak(
    *,
    original: str,
    output: str,
    context: str,
) -> None:
    """
    Development-time invariant to prevent unsafe content leaks.
    """

    if original.strip() and original.strip() in output:
        raise AssertionError(
            f"Unsafe content leak detected in {context}"
        )
