import json
import logging
import os
from typing import Dict, Any

_LOGGING_ENABLED = False  # runtime switch


def enable_safety_logging() -> None:
    """
    Explicitly enable safety logging at runtime.
    """
    global _LOGGING_ENABLED
    _LOGGING_ENABLED = True


def get_safety_logger() -> logging.Logger:
    logger = logging.getLogger("tutorbot_safety_agent")

    if logger.handlers:
        return logger

    enabled = (
        _LOGGING_ENABLED
        or os.getenv("TUTORBOT_SAFETY_LOGGING", "").lower() == "true"
    )

    logger.setLevel(logging.INFO if enabled else logging.CRITICAL)

    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    handler.setFormatter(formatter)

    logger.addHandler(handler)
    logger.propagate = False

    return logger


def log_event(event: str, payload: Dict[str, Any]) -> None:
    logger = get_safety_logger()
    logger.info(json.dumps({"event": event, **payload}))
