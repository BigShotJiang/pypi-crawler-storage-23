from typing import List, Optional


class SentenceBuffer:
    """
    Streaming sentence buffer for ALS extraction.

    Safeguards:
    - Never emits partial sentences
    - Ignores whitespace-only chunks
    - Flushes remainder only at stream end
    """

    def __init__(self) -> None:
        self._buffer: str = ""

    def push(self, chunk: str) -> List[str]:
        """
        Add a new text chunk from the stream.

        Returns a list of COMPLETE text segments
        safe for ALS extraction.
        """
        if not chunk or not chunk.strip():
            return []

        self._buffer += chunk
        return self._flush_complete_sentences()

    def flush(self) -> Optional[str]:
        """
        Flush remaining buffer at stream end.
        """
        if not self._buffer or not self._buffer.strip():
            self._buffer = ""
            return None

        remaining = self._buffer.strip()
        self._buffer = ""
        return remaining

    def _flush_complete_sentences(self) -> List[str]:
        completed: List[str] = []

        last_delim_index = max(
            self._buffer.rfind("."),
            self._buffer.rfind("?"),
            self._buffer.rfind("!"),
        )

        if last_delim_index == -1:
            return completed

        # Candidate complete text
        candidate = self._buffer[: last_delim_index + 1].strip()

        # Safeguard: avoid mid-word / junk endings
        if not candidate or not candidate[-2].isalnum():
            return completed

        # Emit safe segment
        completed.append(candidate)

        # Preserve remainder
        self._buffer = self._buffer[last_delim_index + 1 :]

        return completed
