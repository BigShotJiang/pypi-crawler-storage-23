from dataclasses import dataclass
from enum import Enum
from typing import List, Optional


class DecisionType(str, Enum):
    """
    Allowed safety decisions.
    """
    PASS = "pass"
    REWRITE = "rewrite"
    BLOCK = "block"


@dataclass
class SafetyDecision:
    """
    Structured result returned by the Safety Agent.
    """
    decision: DecisionType
    reason_codes: List[str]
    rewritten_text: Optional[str] = None
    risk_score: float = 0.0


# Default message shown when content is blocked or rewritten for safety
DEFAULT_SAFE_FALLBACK = (
    "Let’s approach this step by step in a way that’s appropriate for your level."
)

from dataclasses import dataclass
from typing import Optional


@dataclass
class AtomicLearningStatement:
    """
    Represents a single, checkable learning statement extracted
    from an AI-generated response.
    """
    statement_id: str
    text: str
    source_text: Optional[str] = None
