# TutorBot Safety Agent

A deterministic, non-autonomous Safety Agent used to evaluate AI-generated
responses before they are shown to students.

## Purpose

The Safety Agent provides a single, enforceable decision point for:
- Allowing safe responses
- Rewriting risky responses
- Blocking unsafe responses

This package is framework-agnostic and can be reused or extracted into
a standalone service in the future.

## Public API

```python
from tutorbot_safety_agent import (
    SafetyAgent,
    DummySafetyAgent,
    SafetyDecision,
    DecisionType,
)
