from typing import NamedTuple


class Span(NamedTuple):
    offset: int
    length: int
