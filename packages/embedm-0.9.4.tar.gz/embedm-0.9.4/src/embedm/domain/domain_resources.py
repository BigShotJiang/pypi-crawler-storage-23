from types import SimpleNamespace

str_resources = SimpleNamespace(
    cannot_cast_directive_option="Cannot cast option '{name}' to {cast_name} (Value: '{value}')",
)
