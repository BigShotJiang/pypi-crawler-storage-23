from types import SimpleNamespace

str_resources = SimpleNamespace(
    note_no_toc_content="> [!NOTE]\n> No headings found in document.",
)
