"""공개 API 임포트 테스트."""


def test_import_main_classes() -> None:
    """ModalGpuEzLLM과 ModalGpuEzEmbeddings를 임포트할 수 있어야 한다."""
    from langchain_modal_gpu_ez import ModalGpuEzEmbeddings, ModalGpuEzLLM

    assert ModalGpuEzLLM is not None
    assert ModalGpuEzEmbeddings is not None


def test_import_version() -> None:
    """버전 문자열을 임포트할 수 있어야 한다."""
    from langchain_modal_gpu_ez import __version__

    assert isinstance(__version__, str)
    assert __version__ == "0.1.0"
