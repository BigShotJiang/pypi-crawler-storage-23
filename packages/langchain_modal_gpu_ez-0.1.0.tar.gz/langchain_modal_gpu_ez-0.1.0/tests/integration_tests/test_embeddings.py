"""ModalGpuEzEmbeddings 통합 테스트 — 실제 모델 호출 필요."""

from __future__ import annotations

import pytest

from langchain_modal_gpu_ez import ModalGpuEzEmbeddings


@pytest.mark.skipif(
    not pytest.importorskip("modal", reason="Modal SDK 필요"),
    reason="Modal SDK 미설치",
)
class TestModalGpuEzEmbeddingsIntegration:
    """실제 모델을 사용하는 통합 테스트."""

    def test_embed_documents(self) -> None:
        """로컬 임베딩이 올바른 차원의 벡터를 반환해야 한다."""
        emb = ModalGpuEzEmbeddings(
            model_id="BAAI/bge-small-en-v1.5",
            gpu="Local",
        )
        result = emb.embed_documents(["hello world", "test sentence"])
        assert len(result) == 2
        assert all(isinstance(v, list) for v in result)
        assert all(isinstance(x, float) for x in result[0])

    def test_embed_query(self) -> None:
        """단일 쿼리 임베딩이 float 리스트를 반환해야 한다."""
        emb = ModalGpuEzEmbeddings(
            model_id="BAAI/bge-small-en-v1.5",
            gpu="Local",
        )
        result = emb.embed_query("hello world")
        assert isinstance(result, list)
        assert all(isinstance(x, float) for x in result)
