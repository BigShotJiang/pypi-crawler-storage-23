"""ModalGpuEzLLM 통합 테스트 — 실제 Modal GPU 호출 필요."""

from __future__ import annotations

import pytest

from langchain_modal_gpu_ez import ModalGpuEzLLM


@pytest.mark.skipif(
    not pytest.importorskip("modal", reason="Modal SDK 필요"),
    reason="Modal SDK 미설치",
)
class TestModalGpuEzLLMIntegration:
    """실제 Modal GPU를 사용하는 통합 테스트."""

    def test_text_generation(self) -> None:
        """distilgpt2로 텍스트 생성이 동작해야 한다."""
        llm = ModalGpuEzLLM(
            model_id="distilgpt2",
            gpu="T4",
            max_new_tokens=20,
        )
        result = llm.invoke("Once upon a time")
        assert isinstance(result, str)
        assert len(result) > 0

    def test_chain_usage(self) -> None:
        """LangChain 체인에서 정상 동작해야 한다."""
        from langchain_core.prompts import PromptTemplate

        llm = ModalGpuEzLLM(
            model_id="distilgpt2",
            gpu="T4",
            max_new_tokens=20,
        )
        prompt = PromptTemplate.from_template("Tell me about {topic}")
        chain = prompt | llm
        result = chain.invoke({"topic": "python"})
        assert isinstance(result, str)
        assert len(result) > 0
