"""ai_sync package."""

from .cli import main

__all__ = ["main"]
