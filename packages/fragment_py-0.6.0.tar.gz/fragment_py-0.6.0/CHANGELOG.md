# Changelog

## 0.6.0 (2026-02-20)

Full Changelog: [v0.5.0...v0.6.0](https://github.com/fragment-dev/fragment-py/compare/v0.5.0...v0.6.0)

### Features

* **api:** update SDK from prod (8d737b90aab6f5a1025d4eef6d9d25694140b220) ([af51366](https://github.com/fragment-dev/fragment-py/commit/af51366be4c80936e708807d63b67f55b14b5023))

## 0.5.0 (2026-02-20)

Full Changelog: [v0.4.0...v0.5.0](https://github.com/fragment-dev/fragment-py/compare/v0.4.0...v0.5.0)

### Features

* **api:** update SDK from prod (02129bd3c8d07cabd99ba1849b1ce21f4a73c752) ([972d94a](https://github.com/fragment-dev/fragment-py/commit/972d94af4473fb8b59d1a7f27ab0ed8d55183464))
* **api:** update SDK from prod (041a7148982b6eb68cdc510d139846bb9acf48f9) ([0e05896](https://github.com/fragment-dev/fragment-py/commit/0e058968554e5af724f0e208200cf4c419fe973a))
* **api:** update SDK from prod (bafb7c5c7699ca57dac84e441c66bd40b1d9ba93) ([2eb8cb3](https://github.com/fragment-dev/fragment-py/commit/2eb8cb3f6fb25fdd07d1470f2890dcf47a7fa004))
* **api:** update SDK from prod (dc1f471db694468a6bfd4a3b15c6af34a19fbc3e) ([8f139d0](https://github.com/fragment-dev/fragment-py/commit/8f139d0e8469e21372539338d464ce7c685ec37c))
* **api:** update SDK from prod (f13cfc23ac55aaae9d293cb5cbb431e4fe2e98a4) ([cfbf9f9](https://github.com/fragment-dev/fragment-py/commit/cfbf9f9adb4186a1f76eac09f6843ba05ea29c3c))


### Chores

* **internal:** remove mock server code ([27c6f12](https://github.com/fragment-dev/fragment-py/commit/27c6f128118ba36cd3959eeb6be018f6948e96eb))
* update mock server docs ([78dccf4](https://github.com/fragment-dev/fragment-py/commit/78dccf437bc05484bb55334e0d10f191b5408302))

## 0.4.0 (2026-02-16)

Full Changelog: [v0.3.2...v0.4.0](https://github.com/fragment-dev/fragment-py/compare/v0.3.2...v0.4.0)

### Features

* **api:** manual updates ([72bcc66](https://github.com/fragment-dev/fragment-py/commit/72bcc6626908a38f2156928796cb1bc8875e47e3))

## 0.3.2 (2026-02-13)

Full Changelog: [v0.3.1...v0.3.2](https://github.com/fragment-dev/fragment-py/compare/v0.3.1...v0.3.2)

### Chores

* format all `api.md` files ([41b3e60](https://github.com/fragment-dev/fragment-py/commit/41b3e6015cb99db9be7aa990a5e6c63ab532f2e0))
* **internal:** fix lint error on Python 3.14 ([4e8ff95](https://github.com/fragment-dev/fragment-py/commit/4e8ff95efc79d174acafd76e5cee4ff139530be1))

## 0.3.1 (2026-02-10)

Full Changelog: [v0.3.0...v0.3.1](https://github.com/fragment-dev/fragment-py/compare/v0.3.0...v0.3.1)

### Chores

* **internal:** bump dependencies ([90b74c2](https://github.com/fragment-dev/fragment-py/commit/90b74c2b42c1edac4bb1a8aa693594e7e42d51e3))

## 0.3.0 (2026-02-05)

Full Changelog: [v0.2.0...v0.3.0](https://github.com/fragment-dev/fragment-py/compare/v0.2.0...v0.3.0)

### Features

* **api:** breaking API changes ([4a6e374](https://github.com/fragment-dev/fragment-py/commit/4a6e3749f2d98bddf436e07ba849d2e2c7073dc6))

## 0.2.0 (2026-02-03)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/fragment-dev/fragment-py/compare/v0.1.0...v0.2.0)

### Features

* **api:** OpenAPI spec update via Stainless ([#4](https://github.com/fragment-dev/fragment-py/issues/4)) ([6dd1723](https://github.com/fragment-dev/fragment-py/commit/6dd17231504a28f7a5008d5c54c7eabff8910a16))

## 0.1.0 (2026-02-02)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/fragment-dev/fragment-py/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([6ed6c9f](https://github.com/fragment-dev/fragment-py/commit/6ed6c9fb6f1c6e4a0d90661a2f45086d4693ecd3))
* **api:** api update ([a36f59b](https://github.com/fragment-dev/fragment-py/commit/a36f59b2fad84a8a62431018e062c911b9f6284f))


### Bug Fixes

* **client/oauth:** send grant_type in the right location ([da1f6db](https://github.com/fragment-dev/fragment-py/commit/da1f6db06f11bf666fa02a2fc01535b6e628f2ce))


### Chores

* configure new SDK language ([32d4975](https://github.com/fragment-dev/fragment-py/commit/32d4975e21ad1144cdc047e8bb7eb8c7a202a239))
* update SDK settings ([5b46542](https://github.com/fragment-dev/fragment-py/commit/5b46542034f3fef7df86b372d20ca5bd68cc3613))
* update SDK settings ([dceb203](https://github.com/fragment-dev/fragment-py/commit/dceb2030cfd3b47037ae0365fffa4d71ba418919))
* update SDK settings ([931490f](https://github.com/fragment-dev/fragment-py/commit/931490fb3310f3348befc5a6df33ae0813149e16))
* update SDK settings ([6a2ba6c](https://github.com/fragment-dev/fragment-py/commit/6a2ba6c1b775d248c3cb1743d0d2de34885eae5c))
* update SDK settings ([b141e78](https://github.com/fragment-dev/fragment-py/commit/b141e789dbae9df530ea965d4473cc67b400a4e1))
* update SDK settings ([0ecf9e6](https://github.com/fragment-dev/fragment-py/commit/0ecf9e650956e9f73b80a899ce2b51811445ed20))
* update SDK settings ([399dc85](https://github.com/fragment-dev/fragment-py/commit/399dc851eeac705826d88c49a4bece529011c91b))
