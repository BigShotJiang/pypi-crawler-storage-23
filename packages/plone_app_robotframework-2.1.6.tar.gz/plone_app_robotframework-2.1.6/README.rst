plone.app.robotframework
------------------------

.. image:: https://img.shields.io/pypi/v/plone.app.robotframework.svg
        :target: https://pypi.org/project/plone.app.robotframework/

**plone.app.robotframework** provides `Robot Framework
<http://code.google.com/p/robotframework/>`_ compatible resources and tools for
writing functional Selenium tests (including acceptance tests) for Plone CMS
and its add-ons.

Please read the full documentation at `Plone Developer Documentation
<https://docs.plone.org/external/plone.app.robotframework/docs/source/index.html>`_.
