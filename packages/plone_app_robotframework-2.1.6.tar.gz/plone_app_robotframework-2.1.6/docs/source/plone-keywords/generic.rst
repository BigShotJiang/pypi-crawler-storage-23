================
Generic Keywords
================

Remove line from textarea
=========================
::

    Remove line from textarea
    [arguments]  ${fieldName}  ${value}

Example::

    Remove '${tag}' from the valid tags list
        Remove line from textarea  form.widgets.valid_tags  ${tag}

