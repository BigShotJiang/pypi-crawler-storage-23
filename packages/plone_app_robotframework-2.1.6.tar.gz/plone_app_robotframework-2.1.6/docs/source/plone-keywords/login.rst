==============================================================================
Plone Login/Logout Keywords
==============================================================================

.. robot_keywords:: Log in.*
   :source: plone.app.robotframework:keywords.robot

.. robot_keywords:: Log out.*
   :source: plone.app.robotframework:keywords.robot
