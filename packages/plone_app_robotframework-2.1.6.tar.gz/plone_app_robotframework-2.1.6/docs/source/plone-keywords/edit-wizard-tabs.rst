==============================================================================
Edit Wizard Keywords
==============================================================================

Wizard tabs
-----------

Open Wizard Tab::

    Open wizard tabs with <title> title

    [arguments]  ${title}
