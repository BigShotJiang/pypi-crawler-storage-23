# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 - 2026 BMO Soluciones, S.A.
"""
Canonical version of coati_payroll.
"""

__version__ = "1.7.2"
