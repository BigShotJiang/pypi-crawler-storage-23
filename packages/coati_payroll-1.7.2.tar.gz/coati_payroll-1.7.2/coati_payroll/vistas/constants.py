# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: 2025 - 2026 BMO Soluciones, S.A.
"""Constants for the vistas module."""

# Number of items per page for pagination
PER_PAGE = 10
