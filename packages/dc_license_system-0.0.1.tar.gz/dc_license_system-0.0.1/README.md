# License System

## Project Description

License System is a lightweight Python package for managing desktop software licenses on Windows.

It generates license keys tied to a unique hardware ID (HWID), stores the license securely in the Windows Registry, and validates it online using Google Sheets.

This package is designed for developers who want a simple but effective way to:

- Control application access  
- Bind licenses to specific machines  
- Set expiry dates  
- Approve or reject users remotely  
- Receive Telegram notifications for new registrations  

## Usage
```python
from license_system.license_manager import LicenseKeys
from license_system.telegram_notifier import TelegramNotifier

# Optional: enable Telegram notification
telegram = TelegramNotifier(
    token="YOUR_BOT_TOKEN",
    chat_id="YOUR_CHAT_ID"
)

# Create license manager
license_manager = LicenseKeys(
    telegram=telegram,
    sheetID="YOUR_GOOGLE_SHEET_ID"
)

# Step 1: Generate license if not exists
license_manager.check_or_generate_license()

# Step 2: Validate license
if license_manager.validate_local_license():
    print("License is valid")
else:
    print("License is invalid or expired")

# Step 3: Get expiry date
expiry = license_manager.get_online_expiry_date()
print("License expires on:", expiry)
```

## Installation

```bash
pip install dc-license-system