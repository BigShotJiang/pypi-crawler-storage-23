from .license_manager import LicenseKeys as License

__all__ = ['License']