# Credit: Dai Chao Online
import requests
from dataclasses import dataclass

@dataclass
class TelegramNotifier:
    botToken: str
    chatID: str

    def __post_init__(self):
        self.api = f"https://api.telegram.org/bot{self.botToken}/sendMessage"

    def send_message(self, message: str) -> bool:
        _message = f"<code>{message}</code>"

        payload = {
            "chat_id": self.chatID,
            "text": _message,
            "parse_mode": "HTML"
        }

        try:
            resp = requests.post(self.api, data=payload, timeout=10)
            return resp.status_code == 200
        except Exception:
            return False