# Credit: Dai Chao Online
import random
import string
import requests
from datetime import datetime
from .hardware import HardwareManager
from .telegram_notifier import TelegramNotifier
from dataclasses import dataclass
import winreg  # For Windows Registry access

@dataclass
class LicenseKeys:
    telegram: TelegramNotifier = None  # Optional Telegram notifier
    sheetID: str = None  # Google Sheet ID
    getHwd: str = HardwareManager().get_hardware()  # Get current machine HWID

    # Registry path and key name
    REG_PATH: str = r"Software\MyAppLicense"
    REG_NAME: str = "LicenseData"

    # Generate a random license key
    def generate_license_key(self):
        chars = string.ascii_uppercase + string.digits  # Use A-Z and 0-9
        raw = "".join(random.choice(chars) for _ in range(20))  # 20 characters
        return "-".join(raw[i:i+4] for i in range(0, 20, 4))  # Format XXXX-XXXX-XXXX-XXXX-XXXX

    # Generate license info for this user (key + HWID)
    def generate_license_for_user(self):
        key = self.generate_license_key()
        return f"Key:{key} | HWD:{self.getHwd}"

    # Save license string to Windows Registry
    def save_license_to_registry(self, data: str):
        try:
            key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, self.REG_PATH)  # Create or open key
            winreg.SetValueEx(key, self.REG_NAME, 0, winreg.REG_SZ, data)  # Save license string
            winreg.CloseKey(key)
        except Exception:
            pass  # Fail silently if registry write fails

    # Load license string from Windows Registry
    def load_license_from_registry(self):
        try:
            key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, self.REG_PATH)  # Open key
            value, _ = winreg.QueryValueEx(key, self.REG_NAME)  # Read license value
            winreg.CloseKey(key)
            return value
        except Exception:
            return None  # Return None if not found

    # Check registry, generate license if missing, notify Telegram
    def check_or_generate_license(self):
        existing = self.load_license_from_registry()  # Check registry
        if not existing:
            info = self.generate_license_for_user()  # Generate new license
            self.save_license_to_registry(info)  # Save to registry

            # Send Telegram notification if configured
            if self.telegram:
                message = f"New user registered!\nHWID: {self.getHwd}\nLicense: {info}"
                self.telegram.send_message(message)

    # Validate a license key online against Google Sheet
    def validate_license_key(self, key: str) -> bool:
        try:
            sheet_url = f"https://docs.google.com/spreadsheets/d/{self.sheetID}/export?format=csv"
            resp = requests.get(sheet_url, timeout=10)
            resp.raise_for_status()
            lines = resp.text.splitlines()

            headers = [h.strip() for h in lines[0].split(",")]
            idx_hwid = headers.index("HWID")
            idx_name = headers.index("Username")
            idx_key = headers.index("Key")
            idx_exp = headers.index("Expiry")
            idx_status = headers.index("Status")

            for row in lines[1:]:
                cols = [c.strip() for c in row.split(",")]
                if len(cols) <= max(idx_hwid, idx_name, idx_key, idx_exp, idx_status):
                    continue

                if cols[idx_key] == key and cols[idx_hwid] == self.getHwd:
                    if cols[idx_status].lower() != "approved":
                        return False
                    try:
                        exp = datetime.fromisoformat(cols[idx_exp])
                        return datetime.now() <= exp
                    except Exception:
                        return False
            return False
        except Exception:
            return False

    # Validate local license from registry
    def validate_local_license(self) -> bool:
        content = self.load_license_from_registry()  # Load license from registry
        if not content:
            return False

        parts = content.split("|")
        key = ""

        for p in parts:
            if p.strip().startswith("Key:"):
                key = p.replace("Key:", "").strip()

        if not key:
            return False

        return self.validate_license_key(key)  # Validate online

    # Get online expiry date of license
    def get_online_expiry_date(self):
        content = self.load_license_from_registry()
        if not content:
            return None

        parts = content.split("|")
        key = ""

        for p in parts:
            if p.strip().startswith("Key:"):
                key = p.replace("Key:", "").strip()

        if not key:
            return None

        try:
            sheet_url = f"https://docs.google.com/spreadsheets/d/{self.sheetID}/export?format=csv"
            resp = requests.get(sheet_url, timeout=10)
            resp.raise_for_status()
            lines = resp.text.splitlines()

            headers = [h.strip() for h in lines[0].split(",")]
            idx_hwid = headers.index("HWID")
            idx_name = headers.index("Username")
            idx_key = headers.index("Key")
            idx_exp = headers.index("Expiry")

            for row in lines[1:]:
                cols = [c.strip() for c in row.split(",")]
                if len(cols) <= max(idx_hwid, idx_name, idx_key, idx_exp):
                    continue

                if cols[idx_key] == key and cols[idx_hwid] == self.getHwd:
                    try:
                        return datetime.fromisoformat(cols[idx_exp])
                    except:
                        return None
        except Exception:
            return None

        return None