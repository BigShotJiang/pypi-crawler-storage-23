# ztlctl Plugin

Claude Code plugin for ztlctl vault management.

## Overview

This plugin provides skills, hooks, commands, and agents for working
with ztlctl vaults within Claude Code sessions.

## Usage

Install by adding this plugin directory to your Claude Code configuration.
