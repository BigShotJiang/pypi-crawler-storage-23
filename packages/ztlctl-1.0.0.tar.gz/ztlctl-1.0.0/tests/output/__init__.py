"""Tests for the output formatting layer."""
