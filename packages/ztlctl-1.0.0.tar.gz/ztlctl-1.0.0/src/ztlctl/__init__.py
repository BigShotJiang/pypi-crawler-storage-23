"""ztlctl — Zettelkasten Control CLI utility."""

__version__ = "1.0.0"
