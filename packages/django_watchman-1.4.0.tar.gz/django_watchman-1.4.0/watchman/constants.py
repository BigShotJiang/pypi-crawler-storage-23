DEFAULT_CHECKS: tuple[str, ...] = (
    "watchman.checks.caches",
    "watchman.checks.databases",
    "watchman.checks.storage",
)

PAID_CHECKS: tuple[str, ...] = ("watchman.checks.email",)
