# Changelog

## 0.1.1
- Fixed `agenttrader init` to run Alembic migrations programmatically from package-local config.
- Added packaged Alembic config and migration files under `agenttrader/db/`.
- Updated packaging rules to include Alembic files and dashboard static assets in distributions.

## 0.1.0
- Initial release.
