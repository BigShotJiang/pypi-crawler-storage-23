from .web import WebInterface

__all__ = [
    "WebInterface",
]
