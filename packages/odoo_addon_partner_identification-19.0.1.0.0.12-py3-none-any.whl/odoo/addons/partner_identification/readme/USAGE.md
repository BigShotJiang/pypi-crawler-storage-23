In partner form you will see another tab called 'ID Numbers'. You can
add any IDs to this partner, defining:

Category:  
ID type defined in configuration. For example, Driver License

ID Number:  
The ID itself. For example, Driver License number of this person

Issued by:  
Another partner, who issued this ID. For example, Traffic National
Institution

Place of Issuance:  
The place where the ID has been issued. For example the country for
passports and visa

Valid from:  
Issued date. For example, date when person approved his driving exam,
21/10/2009

Valid until:  
Expiration date. For example, date when person needs to renew his driver
license, 21/10/2019

Status:  
ID status. For example new/to renew/expired

Notes:  
Any further information related with this ID. For example, vehicle types
this person can drive
