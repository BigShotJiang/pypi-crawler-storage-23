# AzureEnvironmentVariable

The environment variable to set within the container instance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the name of the environment variable. | [optional] 
**value** | **str** | Gets or sets the value of the environment variable. | [optional] 
**secure_value** | **str** | Gets or sets the value of the secure environment variable. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_environment_variable import AzureEnvironmentVariable

# TODO update the JSON string below
json = "{}"
# create an instance of AzureEnvironmentVariable from a JSON string
azure_environment_variable_instance = AzureEnvironmentVariable.from_json(json)
# print the JSON string representation of the object
print(AzureEnvironmentVariable.to_json())

# convert the object into a dict
azure_environment_variable_dict = azure_environment_variable_instance.to_dict()
# create an instance of AzureEnvironmentVariable from a dict
azure_environment_variable_from_dict = AzureEnvironmentVariable.from_dict(azure_environment_variable_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


