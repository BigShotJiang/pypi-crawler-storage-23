# AzureNetworkInterfaceReference


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource Id | [optional] 
**properties_primary** | **bool** | Gets or sets specifies the primary network interface in case the virtual machine has more than 1 network interface. | [optional] 
**properties_delete_option** | **str** | Gets or sets specify what happens to the network interface when the VM is deleted. Possible values include: &#39;Delete&#39;, &#39;Detach&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface_reference import AzureNetworkInterfaceReference

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterfaceReference from a JSON string
azure_network_interface_reference_instance = AzureNetworkInterfaceReference.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterfaceReference.to_json())

# convert the object into a dict
azure_network_interface_reference_dict = azure_network_interface_reference_instance.to_dict()
# create an instance of AzureNetworkInterfaceReference from a dict
azure_network_interface_reference_from_dict = AzureNetworkInterfaceReference.from_dict(azure_network_interface_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


