# AwsNetworkBinding


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bind_ip** | **str** |  | [optional] 
**container_port** | **int** |  | [optional] 
**container_port_range** | **str** |  | [optional] 
**host_port** | **int** |  | [optional] 
**host_port_range** | **str** |  | [optional] 
**protocol** | [**AwsTransportProtocol**](AwsTransportProtocol.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_network_binding import AwsNetworkBinding

# TODO update the JSON string below
json = "{}"
# create an instance of AwsNetworkBinding from a JSON string
aws_network_binding_instance = AwsNetworkBinding.from_json(json)
# print the JSON string representation of the object
print(AwsNetworkBinding.to_json())

# convert the object into a dict
aws_network_binding_dict = aws_network_binding_instance.to_dict()
# create an instance of AwsNetworkBinding from a dict
aws_network_binding_from_dict = AwsNetworkBinding.from_dict(aws_network_binding_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


