# AzureProtectedItem


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**backup_management_type** | **str** |  | [optional] 
**workload_type** | **str** |  | [optional] 
**container_name** | **str** |  | [optional] 
**source_resource_id** | **str** |  | [optional] 
**policy_id** | **str** |  | [optional] 
**last_recovery_point** | **datetime** |  | [optional] 
**backup_set_name** | **str** |  | [optional] 
**create_mode** | **str** |  | [optional] 
**deferred_delete_time_in_utc** | **datetime** |  | [optional] 
**is_scheduled_for_deferred_delete** | **bool** |  | [optional] 
**deferred_delete_time_remaining** | **str** |  | [optional] 
**is_deferred_delete_schedule_upcoming** | **bool** |  | [optional] 
**is_rehydrate** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_protected_item import AzureProtectedItem

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProtectedItem from a JSON string
azure_protected_item_instance = AzureProtectedItem.from_json(json)
# print the JSON string representation of the object
print(AzureProtectedItem.to_json())

# convert the object into a dict
azure_protected_item_dict = azure_protected_item_instance.to_dict()
# create an instance of AzureProtectedItem from a dict
azure_protected_item_from_dict = AzureProtectedItem.from_dict(azure_protected_item_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


