# AWSWorkspaceRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**resource_tags** | **Dict[str, str]** |  | [optional] 
**state** | **str** |  | [optional] 
**zone** | [**AvailabilityZone**](AvailabilityZone.md) |  | [optional] 
**instance_type** | **str** |  | [optional] 
**directory_id** | **str** |  | [optional] 
**bundle_id** | **str** |  | [optional] 
**user_name** | **str** |  | [optional] 
**given_name** | **str** |  | [optional] 
**sur_name** | **str** |  | [optional] 
**user_email_address** | **str** |  | [optional] 
**password** | **str** |  | [optional] 
**wrk_space_type** | [**WorkspaceType**](WorkspaceType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_workspace_request import AWSWorkspaceRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AWSWorkspaceRequest from a JSON string
aws_workspace_request_instance = AWSWorkspaceRequest.from_json(json)
# print the JSON string representation of the object
print(AWSWorkspaceRequest.to_json())

# convert the object into a dict
aws_workspace_request_dict = aws_workspace_request_instance.to_dict()
# create an instance of AWSWorkspaceRequest from a dict
aws_workspace_request_from_dict = AWSWorkspaceRequest.from_dict(aws_workspace_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


