# AzureProxyResource3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_proxy_resource3 import AzureProxyResource3

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProxyResource3 from a JSON string
azure_proxy_resource3_instance = AzureProxyResource3.from_json(json)
# print the JSON string representation of the object
print(AzureProxyResource3.to_json())

# convert the object into a dict
azure_proxy_resource3_dict = azure_proxy_resource3_instance.to_dict()
# create an instance of AzureProxyResource3 from a dict
azure_proxy_resource3_from_dict = AzureProxyResource3.from_dict(azure_proxy_resource3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


