# AmazonRedshiftSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**AmazonRedshiftNodeData**](AmazonRedshiftNodeData.md) |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amazon_redshift_source import AmazonRedshiftSource

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonRedshiftSource from a JSON string
amazon_redshift_source_instance = AmazonRedshiftSource.from_json(json)
# print the JSON string representation of the object
print(AmazonRedshiftSource.to_json())

# convert the object into a dict
amazon_redshift_source_dict = amazon_redshift_source_instance.to_dict()
# create an instance of AmazonRedshiftSource from a dict
amazon_redshift_source_from_dict = AmazonRedshiftSource.from_dict(amazon_redshift_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


