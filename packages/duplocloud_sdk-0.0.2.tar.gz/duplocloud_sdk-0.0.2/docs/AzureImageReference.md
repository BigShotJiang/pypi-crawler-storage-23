# AzureImageReference


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource Id | [optional] 
**publisher** | **str** | Gets or sets the image publisher. | [optional] 
**offer** | **str** | Gets or sets specifies the offer of the platform image or marketplace image used to create the virtual machine. | [optional] 
**sku** | **str** | Gets or sets the image SKU. | [optional] 
**version** | **str** | Gets or sets specifies the version of the platform image or marketplace image used to create the virtual machine. The allowed formats are Major.Minor.Build or &#39;latest&#39;. Major, Minor, and Build are decimal numbers. Specify &#39;latest&#39; to use the latest version of an image available at deploy time. Even if you use &#39;latest&#39;, the VM image will not automatically update after deploy time even if a new version becomes available. Please do not use field &#39;version&#39; for gallery image deployment, gallery image should always use &#39;id&#39; field for deployment, to use &#39;latest&#39; version of gallery image, just set &#39;/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.Compute/galleries/{galleryName}/images/{imageName}&#39; in the &#39;id&#39; field without version input. | [optional] 
**exact_version** | **str** | Gets specifies in decimal numbers, the version of platform image or marketplace image used to create the virtual machine. This readonly field differs from &#39;version&#39;, only if the value specified in &#39;version&#39; field is &#39;latest&#39;. | [optional] 
**shared_gallery_image_id** | **str** | Gets or sets specified the shared gallery image unique id for vm deployment. This can be fetched from shared gallery image GET call. | [optional] 
**community_gallery_image_id** | **str** | Gets or sets specified the community gallery image unique id for vm deployment. This can be fetched from community gallery image GET call. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_image_reference import AzureImageReference

# TODO update the JSON string below
json = "{}"
# create an instance of AzureImageReference from a JSON string
azure_image_reference_instance = AzureImageReference.from_json(json)
# print the JSON string representation of the object
print(AzureImageReference.to_json())

# convert the object into a dict
azure_image_reference_dict = azure_image_reference_instance.to_dict()
# create an instance of AzureImageReference from a dict
azure_image_reference_from_dict = AzureImageReference.from_dict(azure_image_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


