# duplocloud_sdk.AWSRDSEngineVersionsAndInstanceTypesApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_engine_versions**](AWSRDSEngineVersionsAndInstanceTypesApi.md#rds_api_engine_versions) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/engineVersions | 


# **rds_api_engine_versions**
> RdsEngineVersionsResponse rds_api_engine_versions(subscription_id, rds_engine_versions_request=rds_engine_versions_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_engine_versions_request import RdsEngineVersionsRequest
from duplocloud_sdk.models.rds_engine_versions_response import RdsEngineVersionsResponse
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSEngineVersionsAndInstanceTypesApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    rds_engine_versions_request = duplocloud_sdk.RdsEngineVersionsRequest() # RdsEngineVersionsRequest |  (optional)

    try:
        api_response = api_instance.rds_api_engine_versions(subscription_id, rds_engine_versions_request=rds_engine_versions_request)
        print("The response of AWSRDSEngineVersionsAndInstanceTypesApi->rds_api_engine_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSEngineVersionsAndInstanceTypesApi->rds_api_engine_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **rds_engine_versions_request** | [**RdsEngineVersionsRequest**](RdsEngineVersionsRequest.md)|  | [optional] 

### Return type

[**RdsEngineVersionsResponse**](RdsEngineVersionsResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

