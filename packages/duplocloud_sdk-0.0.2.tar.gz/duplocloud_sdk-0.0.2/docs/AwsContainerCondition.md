# AwsContainerCondition


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container_condition import AwsContainerCondition

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainerCondition from a JSON string
aws_container_condition_instance = AwsContainerCondition.from_json(json)
# print the JSON string representation of the object
print(AwsContainerCondition.to_json())

# convert the object into a dict
aws_container_condition_dict = aws_container_condition_instance.to_dict()
# create an instance of AwsContainerCondition from a dict
aws_container_condition_from_dict = AwsContainerCondition.from_dict(aws_container_condition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


