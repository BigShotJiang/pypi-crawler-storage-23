# AwsPlacementStrategy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**var_field** | **str** |  | [optional] 
**type** | [**AwsPlacementStrategyType**](AwsPlacementStrategyType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_placement_strategy import AwsPlacementStrategy

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPlacementStrategy from a JSON string
aws_placement_strategy_instance = AwsPlacementStrategy.from_json(json)
# print the JSON string representation of the object
print(AwsPlacementStrategy.to_json())

# convert the object into a dict
aws_placement_strategy_dict = aws_placement_strategy_instance.to_dict()
# create an instance of AwsPlacementStrategy from a dict
aws_placement_strategy_from_dict = AwsPlacementStrategy.from_dict(aws_placement_strategy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


