# AzureInternalLoadBalancingMode



## Enum

* `NONE_` (value: `'None'`)

* `Web` (value: `'Web'`)

* `Publishing` (value: `'Publishing'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


