# AmazonCloudFrontRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_cloud_front_request import AmazonCloudFrontRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonCloudFrontRequest from a JSON string
amazon_cloud_front_request_instance = AmazonCloudFrontRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonCloudFrontRequest.to_json())

# convert the object into a dict
amazon_cloud_front_request_dict = amazon_cloud_front_request_instance.to_dict()
# create an instance of AmazonCloudFrontRequest from a dict
amazon_cloud_front_request_from_dict = AmazonCloudFrontRequest.from_dict(amazon_cloud_front_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


