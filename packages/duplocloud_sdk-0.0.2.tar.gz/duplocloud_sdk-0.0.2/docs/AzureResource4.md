# AzureResource4


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**e_tag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource4 import AzureResource4

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource4 from a JSON string
azure_resource4_instance = AzureResource4.from_json(json)
# print the JSON string representation of the object
print(AzureResource4.to_json())

# convert the object into a dict
azure_resource4_dict = azure_resource4_instance.to_dict()
# create an instance of AzureResource4 from a dict
azure_resource4_from_dict = AzureResource4.from_dict(azure_resource4_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


