# AzureConnectionStringType



## Enum

* `MySql` (value: `'MySql'`)

* `SQLServer` (value: `'SQLServer'`)

* `SQLAzure` (value: `'SQLAzure'`)

* `Custom` (value: `'Custom'`)

* `NotificationHub` (value: `'NotificationHub'`)

* `ServiceBus` (value: `'ServiceBus'`)

* `EventHub` (value: `'EventHub'`)

* `ApiHub` (value: `'ApiHub'`)

* `DocDb` (value: `'DocDb'`)

* `RedisCache` (value: `'RedisCache'`)

* `PostgreSQL` (value: `'PostgreSQL'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


