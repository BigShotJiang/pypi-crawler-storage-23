# AwsConnectivity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_connectivity import AwsConnectivity

# TODO update the JSON string below
json = "{}"
# create an instance of AwsConnectivity from a JSON string
aws_connectivity_instance = AwsConnectivity.from_json(json)
# print the JSON string representation of the object
print(AwsConnectivity.to_json())

# convert the object into a dict
aws_connectivity_dict = aws_connectivity_instance.to_dict()
# create an instance of AwsConnectivity from a dict
aws_connectivity_from_dict = AwsConnectivity.from_dict(aws_connectivity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


