# AzureApiErrorBase

Api error base.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | Gets or sets the error code. | [optional] 
**target** | **str** | Gets or sets the target of the particular error. | [optional] 
**message** | **str** | Gets or sets the error message. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_api_error_base import AzureApiErrorBase

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApiErrorBase from a JSON string
azure_api_error_base_instance = AzureApiErrorBase.from_json(json)
# print the JSON string representation of the object
print(AzureApiErrorBase.to_json())

# convert the object into a dict
azure_api_error_base_dict = azure_api_error_base_instance.to_dict()
# create an instance of AzureApiErrorBase from a dict
azure_api_error_base_from_dict = AzureApiErrorBase.from_dict(azure_api_error_base_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


