# AzureAutomaticRepairsPolicy

Specifies the configuration parameters for automatic repairs on the virtual machine scale set.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | Gets or sets specifies whether automatic repairs should be enabled on the virtual machine scale set. The default value is false. | [optional] 
**grace_period** | **str** | Gets or sets the amount of time for which automatic repairs are suspended due to a state change on VM. The grace time starts after the state change has completed. This helps avoid premature or accidental repairs. The time duration should be specified in ISO 8601 format. The minimum allowed grace period is 10 minutes (PT10M), which is also the default value. The maximum allowed grace period is 90 minutes (PT90M). | [optional] 
**repair_action** | **str** | Gets or sets type of repair action (replace, restart, reimage) that will be used for repairing unhealthy virtual machines in the scale set. Default value is replace. Possible values include: &#39;Replace&#39;, &#39;Restart&#39;, &#39;Reimage&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_automatic_repairs_policy import AzureAutomaticRepairsPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutomaticRepairsPolicy from a JSON string
azure_automatic_repairs_policy_instance = AzureAutomaticRepairsPolicy.from_json(json)
# print the JSON string representation of the object
print(AzureAutomaticRepairsPolicy.to_json())

# convert the object into a dict
azure_automatic_repairs_policy_dict = azure_automatic_repairs_policy_instance.to_dict()
# create an instance of AzureAutomaticRepairsPolicy from a dict
azure_automatic_repairs_policy_from_dict = AzureAutomaticRepairsPolicy.from_dict(azure_automatic_repairs_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


