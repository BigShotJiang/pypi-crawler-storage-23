# AwsServiceEvent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** |  | [optional] 
**id** | **str** |  | [optional] 
**message** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_event import AwsServiceEvent

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceEvent from a JSON string
aws_service_event_instance = AwsServiceEvent.from_json(json)
# print the JSON string representation of the object
print(AwsServiceEvent.to_json())

# convert the object into a dict
aws_service_event_dict = aws_service_event_instance.to_dict()
# create an instance of AwsServiceEvent from a dict
aws_service_event_from_dict = AwsServiceEvent.from_dict(aws_service_event_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


