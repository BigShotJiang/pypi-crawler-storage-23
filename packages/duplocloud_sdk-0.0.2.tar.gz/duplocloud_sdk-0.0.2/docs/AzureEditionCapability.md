# AzureEditionCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**supported_service_level_objectives** | [**List[AzureServiceObjectiveCapability]**](AzureServiceObjectiveCapability.md) |  | [optional] 
**zone_redundant** | **bool** |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_edition_capability import AzureEditionCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureEditionCapability from a JSON string
azure_edition_capability_instance = AzureEditionCapability.from_json(json)
# print the JSON string representation of the object
print(AzureEditionCapability.to_json())

# convert the object into a dict
azure_edition_capability_dict = azure_edition_capability_instance.to_dict()
# create an instance of AzureEditionCapability from a dict
azure_edition_capability_from_dict = AzureEditionCapability.from_dict(azure_edition_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


