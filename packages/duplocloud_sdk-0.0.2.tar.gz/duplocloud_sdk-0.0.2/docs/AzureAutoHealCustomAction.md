# AzureAutoHealCustomAction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exe** | **str** |  | [optional] 
**parameters** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_auto_heal_custom_action import AzureAutoHealCustomAction

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutoHealCustomAction from a JSON string
azure_auto_heal_custom_action_instance = AzureAutoHealCustomAction.from_json(json)
# print the JSON string representation of the object
print(AzureAutoHealCustomAction.to_json())

# convert the object into a dict
azure_auto_heal_custom_action_dict = azure_auto_heal_custom_action_instance.to_dict()
# create an instance of AzureAutoHealCustomAction from a dict
azure_auto_heal_custom_action_from_dict = AzureAutoHealCustomAction.from_dict(azure_auto_heal_custom_action_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


