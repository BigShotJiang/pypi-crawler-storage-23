# AwsTaskDefinition


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compatibilities** | **List[str]** |  | [optional] 
**container_definitions** | [**List[AwsContainerDefinition]**](AwsContainerDefinition.md) |  | [optional] 
**cpu** | **str** |  | [optional] 
**deregistered_at** | **datetime** |  | [optional] 
**enable_fault_injection** | **bool** |  | [optional] 
**ephemeral_storage** | [**AwsEphemeralStorage**](AwsEphemeralStorage.md) |  | [optional] 
**execution_role_arn** | **str** |  | [optional] 
**family** | **str** |  | [optional] 
**inference_accelerators** | [**List[AwsInferenceAccelerator]**](AwsInferenceAccelerator.md) |  | [optional] 
**ipc_mode** | [**AwsIpcMode**](AwsIpcMode.md) |  | [optional] 
**memory** | **str** |  | [optional] 
**network_mode** | [**AwsNetworkMode**](AwsNetworkMode.md) |  | [optional] 
**pid_mode** | [**AwsPidMode**](AwsPidMode.md) |  | [optional] 
**placement_constraints** | [**List[AwsTaskDefinitionPlacementConstraint]**](AwsTaskDefinitionPlacementConstraint.md) |  | [optional] 
**proxy_configuration** | [**AwsProxyConfiguration**](AwsProxyConfiguration.md) |  | [optional] 
**registered_at** | **datetime** |  | [optional] 
**registered_by** | **str** |  | [optional] 
**requires_attributes** | [**List[AwsAttribute]**](AwsAttribute.md) |  | [optional] 
**requires_compatibilities** | **List[str]** |  | [optional] 
**revision** | **int** |  | [optional] 
**runtime_platform** | [**AwsRuntimePlatform**](AwsRuntimePlatform.md) |  | [optional] 
**status** | [**AwsTaskDefinitionStatus**](AwsTaskDefinitionStatus.md) |  | [optional] 
**task_definition_arn** | **str** |  | [optional] 
**task_role_arn** | **str** |  | [optional] 
**volumes** | [**List[AwsVolume]**](AwsVolume.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_definition import AwsTaskDefinition

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskDefinition from a JSON string
aws_task_definition_instance = AwsTaskDefinition.from_json(json)
# print the JSON string representation of the object
print(AwsTaskDefinition.to_json())

# convert the object into a dict
aws_task_definition_dict = aws_task_definition_instance.to_dict()
# create an instance of AwsTaskDefinition from a dict
aws_task_definition_from_dict = AwsTaskDefinition.from_dict(aws_task_definition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


