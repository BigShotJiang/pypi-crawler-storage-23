# AzureApplicationProfile

Contains the list of gallery applications that should be made available to the VM/VMSS

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**gallery_applications** | [**List[AzureVMGalleryApplication]**](AzureVMGalleryApplication.md) | Gets or sets specifies the gallery applications that should be made available to the VM/VMSS | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_profile import AzureApplicationProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationProfile from a JSON string
azure_application_profile_instance = AzureApplicationProfile.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationProfile.to_json())

# convert the object into a dict
azure_application_profile_dict = azure_application_profile_instance.to_dict()
# create an instance of AzureApplicationProfile from a dict
azure_application_profile_from_dict = AzureApplicationProfile.from_dict(azure_application_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


