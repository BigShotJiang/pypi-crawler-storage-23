# AvailabilityZone2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**load_balancer_addresses** | [**List[LoadBalancerAddress]**](LoadBalancerAddress.md) |  | [optional] 
**outpost_id** | **str** |  | [optional] 
**subnet_id** | **str** |  | [optional] 
**zone_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.availability_zone2 import AvailabilityZone2

# TODO update the JSON string below
json = "{}"
# create an instance of AvailabilityZone2 from a JSON string
availability_zone2_instance = AvailabilityZone2.from_json(json)
# print the JSON string representation of the object
print(AvailabilityZone2.to_json())

# convert the object into a dict
availability_zone2_dict = availability_zone2_instance.to_dict()
# create an instance of AvailabilityZone2 from a dict
availability_zone2_from_dict = AvailabilityZone2.from_dict(availability_zone2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


