# AzureContainerPort

The port exposed on the container instance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protocol** | **str** | Gets or sets the protocol associated with the port. Possible values include: &#39;TCP&#39;, &#39;UDP&#39; | [optional] 
**port** | **int** | Gets or sets the port number exposed within the container group. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_port import AzureContainerPort

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerPort from a JSON string
azure_container_port_instance = AzureContainerPort.from_json(json)
# print the JSON string representation of the object
print(AzureContainerPort.to_json())

# convert the object into a dict
azure_container_port_dict = azure_container_port_instance.to_dict()
# create an instance of AzureContainerPort from a dict
azure_container_port_from_dict = AzureContainerPort.from_dict(azure_container_port_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


