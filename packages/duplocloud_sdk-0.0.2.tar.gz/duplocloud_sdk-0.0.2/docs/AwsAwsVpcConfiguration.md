# AwsAwsVpcConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**assign_public_ip** | [**AwsAssignPublicIp**](AwsAssignPublicIp.md) |  | [optional] 
**security_groups** | **List[str]** |  | [optional] 
**subnets** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_aws_vpc_configuration import AwsAwsVpcConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAwsVpcConfiguration from a JSON string
aws_aws_vpc_configuration_instance = AwsAwsVpcConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsAwsVpcConfiguration.to_json())

# convert the object into a dict
aws_aws_vpc_configuration_dict = aws_aws_vpc_configuration_instance.to_dict()
# create an instance of AwsAwsVpcConfiguration from a dict
aws_aws_vpc_configuration_from_dict = AwsAwsVpcConfiguration.from_dict(aws_aws_vpc_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


