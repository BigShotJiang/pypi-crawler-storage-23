# AzureKeyVaultKeyReference

Describes a reference to Key Vault Key

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key_url** | **str** | Gets or sets the URL referencing a key encryption key in Key Vault. | [optional] 
**source_vault** | [**AzureSubResource2**](AzureSubResource2.md) | Gets or sets the relative URL of the Key Vault containing the key. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_key_vault_key_reference import AzureKeyVaultKeyReference

# TODO update the JSON string below
json = "{}"
# create an instance of AzureKeyVaultKeyReference from a JSON string
azure_key_vault_key_reference_instance = AzureKeyVaultKeyReference.from_json(json)
# print the JSON string representation of the object
print(AzureKeyVaultKeyReference.to_json())

# convert the object into a dict
azure_key_vault_key_reference_dict = azure_key_vault_key_reference_instance.to_dict()
# create an instance of AzureKeyVaultKeyReference from a dict
azure_key_vault_key_reference_from_dict = AzureKeyVaultKeyReference.from_dict(azure_key_vault_key_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


