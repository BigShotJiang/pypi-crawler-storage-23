# AwsAction


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authenticate_cognito_config** | [**AuthenticateCognitoActionConfig**](AuthenticateCognitoActionConfig.md) |  | [optional] 
**authenticate_oidc_config** | [**AuthenticateOidcActionConfig**](AuthenticateOidcActionConfig.md) |  | [optional] 
**fixed_response_config** | [**FixedResponseActionConfig**](FixedResponseActionConfig.md) |  | [optional] 
**forward_config** | [**AwsForwardActionConfig**](AwsForwardActionConfig.md) |  | [optional] 
**order** | **int** |  | [optional] 
**redirect_config** | [**RedirectActionConfig**](RedirectActionConfig.md) |  | [optional] 
**target_group_arn** | **str** |  | [optional] 
**type** | [**ActionTypeEnum**](ActionTypeEnum.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_action import AwsAction

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAction from a JSON string
aws_action_instance = AwsAction.from_json(json)
# print the JSON string representation of the object
print(AwsAction.to_json())

# convert the object into a dict
aws_action_dict = aws_action_instance.to_dict()
# create an instance of AwsAction from a dict
aws_action_from_dict = AwsAction.from_dict(aws_action_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


