# AcmCertificateDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **str** |  | [optional] 
**state** | **str** |  | [optional] 
**certificate_name** | **str** |  | [optional] 
**certificate_domain** | **str** |  | [optional] 
**additional_domains** | **List[str]** |  | [optional] 
**region** | **str** |  | [optional] 
**acm_cert_summary** | [**CertificateSummary**](CertificateSummary.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.acm_certificate_details import AcmCertificateDetails

# TODO update the JSON string below
json = "{}"
# create an instance of AcmCertificateDetails from a JSON string
acm_certificate_details_instance = AcmCertificateDetails.from_json(json)
# print the JSON string representation of the object
print(AcmCertificateDetails.to_json())

# convert the object into a dict
acm_certificate_details_dict = acm_certificate_details_instance.to_dict()
# create an instance of AcmCertificateDetails from a dict
acm_certificate_details_from_dict = AcmCertificateDetails.from_dict(acm_certificate_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


