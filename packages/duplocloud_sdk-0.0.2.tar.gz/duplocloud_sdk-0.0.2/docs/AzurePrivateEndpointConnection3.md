# AzurePrivateEndpointConnection3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 
**properties_private_endpoint** | [**AzurePrivateEndpoint3**](AzurePrivateEndpoint3.md) | Gets or sets the resource of private end point. | [optional] 
**properties_private_link_service_connection_state** | [**AzurePrivateLinkServiceConnectionState3**](AzurePrivateLinkServiceConnectionState3.md) | Gets or sets a collection of information about the state of the connection between service consumer and provider. | [optional] 
**properties_provisioning_state** | **str** | Gets or sets the provisioning state of the private endpoint connection resource. Possible values include: &#39;Succeeded&#39;, &#39;Creating&#39;, &#39;Deleting&#39;, &#39;Failed&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_connection3 import AzurePrivateEndpointConnection3

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointConnection3 from a JSON string
azure_private_endpoint_connection3_instance = AzurePrivateEndpointConnection3.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointConnection3.to_json())

# convert the object into a dict
azure_private_endpoint_connection3_dict = azure_private_endpoint_connection3_instance.to_dict()
# create an instance of AzurePrivateEndpointConnection3 from a dict
azure_private_endpoint_connection3_from_dict = AzurePrivateEndpointConnection3.from_dict(azure_private_endpoint_connection3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


