# AzurePrivateLinkServiceIpConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_private_ip_address** | **str** |  | [optional] 
**properties_private_ip_allocation_method** | **str** |  | [optional] 
**properties_subnet** | [**AzureSubnet**](AzureSubnet.md) |  | [optional] 
**properties_primary** | **bool** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_private_ip_address_version** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_ip_configuration import AzurePrivateLinkServiceIpConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceIpConfiguration from a JSON string
azure_private_link_service_ip_configuration_instance = AzurePrivateLinkServiceIpConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceIpConfiguration.to_json())

# convert the object into a dict
azure_private_link_service_ip_configuration_dict = azure_private_link_service_ip_configuration_instance.to_dict()
# create an instance of AzurePrivateLinkServiceIpConfiguration from a dict
azure_private_link_service_ip_configuration_from_dict = AzurePrivateLinkServiceIpConfiguration.from_dict(azure_private_link_service_ip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


