# AwsTimeoutConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**idle_timeout_seconds** | **int** |  | [optional] 
**per_request_timeout_seconds** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_timeout_configuration import AwsTimeoutConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTimeoutConfiguration from a JSON string
aws_timeout_configuration_instance = AwsTimeoutConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsTimeoutConfiguration.to_json())

# convert the object into a dict
aws_timeout_configuration_dict = aws_timeout_configuration_instance.to_dict()
# create an instance of AwsTimeoutConfiguration from a dict
aws_timeout_configuration_from_dict = AwsTimeoutConfiguration.from_dict(aws_timeout_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


