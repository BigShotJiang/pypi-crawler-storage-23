# AwsMountPoint


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_path** | **str** |  | [optional] 
**read_only** | **bool** |  | [optional] 
**source_volume** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_mount_point import AwsMountPoint

# TODO update the JSON string below
json = "{}"
# create an instance of AwsMountPoint from a JSON string
aws_mount_point_instance = AwsMountPoint.from_json(json)
# print the JSON string representation of the object
print(AwsMountPoint.to_json())

# convert the object into a dict
aws_mount_point_dict = aws_mount_point_instance.to_dict()
# create an instance of AwsMountPoint from a dict
aws_mount_point_from_dict = AwsMountPoint.from_dict(aws_mount_point_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


