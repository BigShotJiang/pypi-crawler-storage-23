# AzureEventModel

A container group or container instance event.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Gets the count of the event. | [optional] 
**first_timestamp** | **datetime** | Gets the date-time of the earliest logged event. | [optional] 
**last_timestamp** | **datetime** | Gets the date-time of the latest logged event. | [optional] 
**name** | **str** | Gets the event name. | [optional] 
**message** | **str** | Gets the event message. | [optional] 
**type** | **str** | Gets the event type. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_event_model import AzureEventModel

# TODO update the JSON string below
json = "{}"
# create an instance of AzureEventModel from a JSON string
azure_event_model_instance = AzureEventModel.from_json(json)
# print the JSON string representation of the object
print(AzureEventModel.to_json())

# convert the object into a dict
azure_event_model_dict = azure_event_model_instance.to_dict()
# create an instance of AzureEventModel from a dict
azure_event_model_from_dict = AzureEventModel.from_dict(azure_event_model_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


