# AwsDockerVolumeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**autoprovision** | **bool** |  | [optional] 
**driver** | **str** |  | [optional] 
**driver_opts** | **Dict[str, str]** |  | [optional] 
**labels** | **Dict[str, str]** |  | [optional] 
**scope** | [**AwsScope**](AwsScope.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_docker_volume_configuration import AwsDockerVolumeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDockerVolumeConfiguration from a JSON string
aws_docker_volume_configuration_instance = AwsDockerVolumeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsDockerVolumeConfiguration.to_json())

# convert the object into a dict
aws_docker_volume_configuration_dict = aws_docker_volume_configuration_instance.to_dict()
# create an instance of AwsDockerVolumeConfiguration from a dict
aws_docker_volume_configuration_from_dict = AwsDockerVolumeConfiguration.from_dict(aws_docker_volume_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


