# AzureNetworkInterfaceIPConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_gateway_load_balancer** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_virtual_network_taps** | [**List[AzureVirtualNetworkTap]**](AzureVirtualNetworkTap.md) |  | [optional] 
**properties_application_gateway_backend_address_pools** | [**List[AzureApplicationGatewayBackendAddressPool]**](AzureApplicationGatewayBackendAddressPool.md) |  | [optional] 
**properties_load_balancer_backend_address_pools** | [**List[AzureBackendAddressPool]**](AzureBackendAddressPool.md) |  | [optional] 
**properties_load_balancer_inbound_nat_rules** | [**List[AzureInboundNatRule]**](AzureInboundNatRule.md) |  | [optional] 
**properties_private_ip_address** | **str** |  | [optional] 
**properties_private_ip_allocation_method** | **str** |  | [optional] 
**properties_private_ip_address_version** | **str** |  | [optional] 
**properties_subnet** | [**AzureSubnet**](AzureSubnet.md) |  | [optional] 
**properties_primary** | **bool** |  | [optional] 
**properties_public_ip_address** | [**AzurePublicIPAddress**](AzurePublicIPAddress.md) |  | [optional] 
**properties_application_security_groups** | [**List[AzureApplicationSecurityGroup]**](AzureApplicationSecurityGroup.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_private_link_connection_properties** | [**AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties**](AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties.md) |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface_ip_configuration import AzureNetworkInterfaceIPConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterfaceIPConfiguration from a JSON string
azure_network_interface_ip_configuration_instance = AzureNetworkInterfaceIPConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterfaceIPConfiguration.to_json())

# convert the object into a dict
azure_network_interface_ip_configuration_dict = azure_network_interface_ip_configuration_instance.to_dict()
# create an instance of AzureNetworkInterfaceIPConfiguration from a dict
azure_network_interface_ip_configuration_from_dict = AzureNetworkInterfaceIPConfiguration.from_dict(azure_network_interface_ip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


