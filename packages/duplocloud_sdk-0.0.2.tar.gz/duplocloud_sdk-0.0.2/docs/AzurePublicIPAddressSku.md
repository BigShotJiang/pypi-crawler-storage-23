# AzurePublicIPAddressSku


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**tier** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_public_ip_address_sku import AzurePublicIPAddressSku

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePublicIPAddressSku from a JSON string
azure_public_ip_address_sku_instance = AzurePublicIPAddressSku.from_json(json)
# print the JSON string representation of the object
print(AzurePublicIPAddressSku.to_json())

# convert the object into a dict
azure_public_ip_address_sku_dict = azure_public_ip_address_sku_instance.to_dict()
# create an instance of AzurePublicIPAddressSku from a dict
azure_public_ip_address_sku_from_dict = AzurePublicIPAddressSku.from_dict(azure_public_ip_address_sku_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


