# AzureOSProfile

Specifies the operating system settings for the virtual machine. Some of the settings cannot be changed once VM is provisioned.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**computer_name** | **str** | Gets or sets specifies the host OS name of the virtual machine. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; This name cannot be updated after the VM is created. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Windows):** 15 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Linux):** 64 characters. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; For naming conventions and restrictions see [Azure infrastructure services implementation guidelines](https://docs.microsoft.com/azure/azure-resource-manager/management/resource-name-rules). | [optional] 
**admin_username** | **str** | Gets or sets specifies the name of the administrator account. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; This property cannot be updated after the VM is created. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Windows-only restriction:** Cannot end in \&quot;.\&quot; &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Disallowed values:** \&quot;administrator\&quot;, \&quot;admin\&quot;, \&quot;user\&quot;, \&quot;user1\&quot;, \&quot;test\&quot;, \&quot;user2\&quot;, \&quot;test1\&quot;, \&quot;user3\&quot;, \&quot;admin1\&quot;, \&quot;1\&quot;, \&quot;123\&quot;, \&quot;a\&quot;, \&quot;actuser\&quot;, \&quot;adm\&quot;, \&quot;admin2\&quot;, \&quot;aspnet\&quot;, \&quot;backup\&quot;, \&quot;console\&quot;, \&quot;david\&quot;, \&quot;guest\&quot;, \&quot;john\&quot;, \&quot;owner\&quot;, \&quot;root\&quot;, \&quot;server\&quot;, \&quot;sql\&quot;, \&quot;support\&quot;, \&quot;support_388945a0\&quot;, \&quot;sys\&quot;, \&quot;test2\&quot;, \&quot;test3\&quot;, \&quot;user4\&quot;, \&quot;user5\&quot;. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Minimum-length (Linux):** 1 character &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Linux):** 64 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Windows):** 20 characters. | [optional] 
**admin_password** | **str** | Gets or sets specifies the password of the administrator account. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Minimum-length (Windows):** 8 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Minimum-length (Linux):** 6 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Windows):** 123 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Max-length (Linux):** 72 characters &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Complexity requirements:** 3 out of 4 conditions below need to be fulfilled &amp;lt;br&amp;gt; Has lower characters &amp;lt;br&amp;gt;Has upper characters &amp;lt;br&amp;gt; Has a digit &amp;lt;br&amp;gt; Has a special character (Regex match [\\W_]) &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Disallowed values:** \&quot;abc@123\&quot;, \&quot;P@$$w0rd\&quot;, \&quot;P@ssw0rd\&quot;, \&quot;P@ssword123\&quot;, \&quot;Pa$$word\&quot;, \&quot;pass@word1\&quot;, \&quot;Password!\&quot;, \&quot;Password1\&quot;, \&quot;Password22\&quot;, \&quot;iloveyou!\&quot; &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; For resetting the password, see [How to reset the Remote Desktop service or its login password in a Windows VM](https://docs.microsoft.com/troubleshoot/azure/virtual-machines/reset-rdp) &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; For resetting root password, see [Manage users, SSH, and check or repair disks on Azure Linux VMs using the VMAccess Extension](https://docs.microsoft.com/troubleshoot/azure/virtual-machines/troubleshoot-ssh-connection) | [optional] 
**custom_data** | **str** | Gets or sets specifies a base-64 encoded string of custom data. The base-64 encoded string is decoded to a binary array that is saved as a file on the Virtual Machine. The maximum length of the binary array is 65535 bytes. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Note: Do not pass any secrets or passwords in customData property** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; This property cannot be updated after the VM is created. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; customData is passed to the VM to be saved as a file, for more information see [Custom Data on Azure VMs](https://azure.microsoft.com/blog/custom-data-and-cloud-init-on-windows-azure/) &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; For using cloud-init for your Linux VM, see [Using cloud-init to customize a Linux VM during creation](https://docs.microsoft.com/azure/virtual-machines/linux/using-cloud-init) | [optional] 
**windows_configuration** | [**AzureWindowsConfiguration**](AzureWindowsConfiguration.md) | Gets or sets specifies Windows operating system settings on the virtual machine. | [optional] 
**linux_configuration** | [**AzureLinuxConfiguration**](AzureLinuxConfiguration.md) | Gets or sets specifies the Linux operating system settings on the virtual machine. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;For a list of supported Linux distributions, see [Linux on Azure-Endorsed Distributions](https://docs.microsoft.com/azure/virtual-machines/linux/endorsed-distros). | [optional] 
**secrets** | [**List[AzureVaultSecretGroup]**](AzureVaultSecretGroup.md) | Gets or sets specifies set of certificates that should be installed onto the virtual machine. To install certificates on a virtual machine it is recommended to use the [Azure Key Vault virtual machine extension for Linux](https://docs.microsoft.com/azure/virtual-machines/extensions/key-vault-linux) or the [Azure Key Vault virtual machine extension for Windows](https://docs.microsoft.com/azure/virtual-machines/extensions/key-vault-windows). | [optional] 
**allow_extension_operations** | **bool** | Gets or sets specifies whether extension operations should be allowed on the virtual machine. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;This may only be set to False when no extensions are present on the virtual machine. | [optional] 
**require_guest_provision_signal** | **bool** | Gets or sets optional property which must either be set to True or omitted. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_os_profile import AzureOSProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureOSProfile from a JSON string
azure_os_profile_instance = AzureOSProfile.from_json(json)
# print the JSON string representation of the object
print(AzureOSProfile.to_json())

# convert the object into a dict
azure_os_profile_dict = azure_os_profile_instance.to_dict()
# create an instance of AzureOSProfile from a dict
azure_os_profile_from_dict = AzureOSProfile.from_dict(azure_os_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


