# AwsRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**actions** | [**List[AwsAction]**](AwsAction.md) |  | [optional] 
**conditions** | [**List[RuleCondition]**](RuleCondition.md) |  | [optional] 
**is_default** | **bool** |  | [optional] 
**priority** | **str** |  | [optional] 
**rule_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_rule import AwsRule

# TODO update the JSON string below
json = "{}"
# create an instance of AwsRule from a JSON string
aws_rule_instance = AwsRule.from_json(json)
# print the JSON string representation of the object
print(AwsRule.to_json())

# convert the object into a dict
aws_rule_dict = aws_rule_instance.to_dict()
# create an instance of AwsRule from a dict
aws_rule_from_dict = AwsRule.from_dict(aws_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


