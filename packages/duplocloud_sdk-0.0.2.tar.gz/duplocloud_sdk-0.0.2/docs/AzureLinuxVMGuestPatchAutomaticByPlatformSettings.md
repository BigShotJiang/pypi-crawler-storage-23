# AzureLinuxVMGuestPatchAutomaticByPlatformSettings

Specifies additional settings to be applied when patch mode AutomaticByPlatform is selected in Linux patch settings.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**reboot_setting** | **str** | Gets or sets specifies the reboot setting for all AutomaticByPlatform patch installation operations. Possible values include: &#39;Unknown&#39;, &#39;IfRequired&#39;, &#39;Never&#39;, &#39;Always&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_linux_vm_guest_patch_automatic_by_platform_settings import AzureLinuxVMGuestPatchAutomaticByPlatformSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLinuxVMGuestPatchAutomaticByPlatformSettings from a JSON string
azure_linux_vm_guest_patch_automatic_by_platform_settings_instance = AzureLinuxVMGuestPatchAutomaticByPlatformSettings.from_json(json)
# print the JSON string representation of the object
print(AzureLinuxVMGuestPatchAutomaticByPlatformSettings.to_json())

# convert the object into a dict
azure_linux_vm_guest_patch_automatic_by_platform_settings_dict = azure_linux_vm_guest_patch_automatic_by_platform_settings_instance.to_dict()
# create an instance of AzureLinuxVMGuestPatchAutomaticByPlatformSettings from a dict
azure_linux_vm_guest_patch_automatic_by_platform_settings_from_dict = AzureLinuxVMGuestPatchAutomaticByPlatformSettings.from_dict(azure_linux_vm_guest_patch_automatic_by_platform_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


