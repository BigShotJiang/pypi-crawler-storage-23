# AzureRedisCommonPropertiesRedisConfiguration

All Redis Settings. Few possible keys: rdb-backup-enabled,rdb-storage-connection-string,rdb-backup-frequency,maxmemory-delta,maxmemory-policy,notify-keyspace-events,maxmemory-samples,slowlog-log-slower-than,slowlog-max-len,list-max-ziplist-entries,list-max-ziplist-value,hash-max-ziplist-entries,hash-max-ziplist-value,set-max-intset-entries,zset-max-ziplist-entries,zset-max-ziplist-value etc.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rdb_backup_enabled** | **str** | Gets or sets specifies whether the rdb backup is enabled | [optional] 
**rdb_backup_frequency** | **str** | Gets or sets specifies the frequency for creating rdb backup | [optional] 
**rdb_backup_max_snapshot_count** | **str** | Gets or sets specifies the maximum number of snapshots for rdb backup | [optional] 
**rdb_storage_connection_string** | **str** | Gets or sets the storage account connection string for storing rdb file | [optional] 
**aof_storage_connection_string_0** | **str** | Gets or sets first storage account connection string | [optional] 
**aof_storage_connection_string_1** | **str** | Gets or sets second storage account connection string | [optional] 
**maxfragmentationmemory_reserved** | **str** | Gets or sets value in megabytes reserved for fragmentation per shard | [optional] 
**maxmemory_policy** | **str** | Gets or sets the eviction strategy used when your data won&#39;t fit within its memory limit. | [optional] 
**maxmemory_reserved** | **str** | Gets or sets value in megabytes reserved for non-cache usage per shard e.g. failover. | [optional] 
**maxmemory_delta** | **str** | Gets or sets value in megabytes reserved for non-cache usage per shard e.g. failover. | [optional] 
**maxclients** | **str** | Gets the max clients config | [optional] 
**preferred_data_archive_auth_method** | **str** | Gets preferred auth method to communicate to storage account used for data archive, specify SAS or ManagedIdentity, default value is SAS | [optional] 
**preferred_data_persistence_auth_method** | **str** | Gets preferred auth method to communicate to storage account used for data persistence, specify SAS or ManagedIdentity, default value is SAS | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_common_properties_redis_configuration import AzureRedisCommonPropertiesRedisConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisCommonPropertiesRedisConfiguration from a JSON string
azure_redis_common_properties_redis_configuration_instance = AzureRedisCommonPropertiesRedisConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureRedisCommonPropertiesRedisConfiguration.to_json())

# convert the object into a dict
azure_redis_common_properties_redis_configuration_dict = azure_redis_common_properties_redis_configuration_instance.to_dict()
# create an instance of AzureRedisCommonPropertiesRedisConfiguration from a dict
azure_redis_common_properties_redis_configuration_from_dict = AzureRedisCommonPropertiesRedisConfiguration.from_dict(azure_redis_common_properties_redis_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


