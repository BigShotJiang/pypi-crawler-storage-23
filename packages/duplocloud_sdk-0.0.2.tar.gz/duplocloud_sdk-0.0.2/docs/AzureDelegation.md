# AzureDelegation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_service_name** | **str** |  | [optional] 
**properties_actions** | **List[str]** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_delegation import AzureDelegation

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDelegation from a JSON string
azure_delegation_instance = AzureDelegation.from_json(json)
# print the JSON string representation of the object
print(AzureDelegation.to_json())

# convert the object into a dict
azure_delegation_dict = azure_delegation_instance.to_dict()
# create an instance of AzureDelegation from a dict
azure_delegation_from_dict = AzureDelegation.from_dict(azure_delegation_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


