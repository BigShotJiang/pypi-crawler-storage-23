# AmazonGlueRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_glue_request import AmazonGlueRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonGlueRequest from a JSON string
amazon_glue_request_instance = AmazonGlueRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonGlueRequest.to_json())

# convert the object into a dict
amazon_glue_request_dict = amazon_glue_request_instance.to_dict()
# create an instance of AmazonGlueRequest from a dict
amazon_glue_request_from_dict = AmazonGlueRequest.from_dict(amazon_glue_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


