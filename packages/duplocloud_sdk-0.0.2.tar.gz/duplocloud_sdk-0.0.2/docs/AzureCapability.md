# AzureCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value** | **str** |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_capability import AzureCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCapability from a JSON string
azure_capability_instance = AzureCapability.from_json(json)
# print the JSON string representation of the object
print(AzureCapability.to_json())

# convert the object into a dict
azure_capability_dict = azure_capability_instance.to_dict()
# create an instance of AzureCapability from a dict
azure_capability_from_dict = AzureCapability.from_dict(azure_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


