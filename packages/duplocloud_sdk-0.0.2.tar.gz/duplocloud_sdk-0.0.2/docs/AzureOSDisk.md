# AzureOSDisk

Specifies information about the operating system disk used by the virtual machine. <br><br> For more information about disks, see [About disks and VHDs for Azure virtual machines](https://docs.microsoft.com/azure/virtual-machines/managed-disks-overview).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**os_type** | [**AzureOperatingSystemTypes**](AzureOperatingSystemTypes.md) | Gets or sets this property allows you to specify the type of the OS that is included in the disk if creating a VM from user-image or a specialized VHD. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Windows** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Linux**. Possible values include: &#39;Windows&#39;, &#39;Linux&#39; | [optional] 
**encryption_settings** | [**AzureDiskEncryptionSettings**](AzureDiskEncryptionSettings.md) | Gets or sets specifies the encryption settings for the OS Disk. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Minimum api-version: 2015-06-15 | [optional] 
**name** | **str** | Gets or sets the disk name. | [optional] 
**vhd** | [**AzureVirtualHardDisk**](AzureVirtualHardDisk.md) | Gets or sets the virtual hard disk. | [optional] 
**image** | [**AzureVirtualHardDisk**](AzureVirtualHardDisk.md) | Gets or sets the source user image virtual hard disk. The virtual hard disk will be copied before being attached to the virtual machine. If SourceImage is provided, the destination virtual hard drive must not exist. | [optional] 
**caching** | [**AzureCachingTypes**](AzureCachingTypes.md) | Gets or sets specifies the caching requirements. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **None** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **ReadOnly** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **ReadWrite** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Default: **None** for Standard storage. **ReadOnly** for Premium storage. Possible values include: &#39;None&#39;, &#39;ReadOnly&#39;, &#39;ReadWrite&#39; | [optional] 
**write_accelerator_enabled** | **bool** | Gets or sets specifies whether writeAccelerator should be enabled or disabled on the disk. | [optional] 
**diff_disk_settings** | [**AzureDiffDiskSettings**](AzureDiffDiskSettings.md) | Gets or sets specifies the ephemeral Disk Settings for the operating system disk used by the virtual machine. | [optional] 
**create_option** | **str** | Gets or sets specifies how the virtual machine should be created.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are:&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Attach** \\u2013 This value is used when you are using a specialized disk to create the virtual machine.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **FromImage** \\u2013 This value is used when you are using an image to create the virtual machine. If you are using a platform image, you also use the imageReference element described above. If you are using a marketplace image, you  also use the plan element previously described. Possible values include: &#39;FromImage&#39;, &#39;Empty&#39;, &#39;Attach&#39; | [optional] 
**disk_size_gb** | **int** | Gets or sets specifies the size of an empty data disk in gigabytes. This element can be used to overwrite the size of the disk in a virtual machine image. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; diskSizeGB is the number of bytes x 1024^3 for the disk and the value cannot be larger than 1023 | [optional] 
**managed_disk** | [**AzureManagedDiskParameters**](AzureManagedDiskParameters.md) | Gets or sets the managed disk parameters. | [optional] 
**delete_option** | **str** | Gets or sets specifies whether OS Disk should be deleted or detached upon VM deletion. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Delete** If this value is used, the OS disk is deleted when VM is deleted.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Detach** If this value is used, the os disk is retained after VM is deleted. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; The default value is set to **detach**. For an ephemeral OS Disk, the default value is set to **Delete**. User cannot change the delete option for ephemeral OS Disk. Possible values include: &#39;Delete&#39;, &#39;Detach&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_os_disk import AzureOSDisk

# TODO update the JSON string below
json = "{}"
# create an instance of AzureOSDisk from a JSON string
azure_os_disk_instance = AzureOSDisk.from_json(json)
# print the JSON string representation of the object
print(AzureOSDisk.to_json())

# convert the object into a dict
azure_os_disk_dict = azure_os_disk_instance.to_dict()
# create an instance of AzureOSDisk from a dict
azure_os_disk_from_dict = AzureOSDisk.from_dict(azure_os_disk_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


