# Administrators


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**login** | **str** |  | [optional] 
**sid** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**administrator_type** | **str** |  | [optional] 
**principal_type** | **str** |  | [optional] 
**azure_ad_only_authentication** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.administrators import Administrators

# TODO update the JSON string below
json = "{}"
# create an instance of Administrators from a JSON string
administrators_instance = Administrators.from_json(json)
# print the JSON string representation of the object
print(Administrators.to_json())

# convert the object into a dict
administrators_dict = administrators_instance.to_dict()
# create an instance of Administrators from a dict
administrators_from_dict = Administrators.from_dict(administrators_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


