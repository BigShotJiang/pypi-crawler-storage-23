# AwsService


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**availability_zone_rebalancing** | [**AwsAvailabilityZoneRebalancing**](AwsAvailabilityZoneRebalancing.md) |  | [optional] 
**capacity_provider_strategy** | [**List[AwsCapacityProviderStrategyItem]**](AwsCapacityProviderStrategyItem.md) |  | [optional] 
**cluster_arn** | **str** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**created_by** | **str** |  | [optional] 
**deployment_configuration** | [**AwsDeploymentConfiguration**](AwsDeploymentConfiguration.md) |  | [optional] 
**deployment_controller** | [**AwsDeploymentController**](AwsDeploymentController.md) |  | [optional] 
**deployments** | [**List[AwsDeployment]**](AwsDeployment.md) |  | [optional] 
**desired_count** | **int** |  | [optional] 
**enable_ecs_managed_tags** | **bool** |  | [optional] 
**enable_execute_command** | **bool** |  | [optional] 
**events** | [**List[AwsServiceEvent]**](AwsServiceEvent.md) |  | [optional] 
**health_check_grace_period_seconds** | **int** |  | [optional] 
**launch_type** | [**AwsLaunchType**](AwsLaunchType.md) |  | [optional] 
**load_balancers** | [**List[AwsLoadBalancer]**](AwsLoadBalancer.md) |  | [optional] 
**network_configuration** | [**AwsNetworkConfiguration**](AwsNetworkConfiguration.md) |  | [optional] 
**pending_count** | **int** |  | [optional] 
**placement_constraints** | [**List[AwsPlacementConstraint]**](AwsPlacementConstraint.md) |  | [optional] 
**placement_strategy** | [**List[AwsPlacementStrategy]**](AwsPlacementStrategy.md) |  | [optional] 
**platform_family** | **str** |  | [optional] 
**platform_version** | **str** |  | [optional] 
**propagate_tags** | [**AwsPropagateTags**](AwsPropagateTags.md) |  | [optional] 
**role_arn** | **str** |  | [optional] 
**running_count** | **int** |  | [optional] 
**scheduling_strategy** | [**AwsSchedulingStrategy**](AwsSchedulingStrategy.md) |  | [optional] 
**service_arn** | **str** |  | [optional] 
**service_name** | **str** |  | [optional] 
**service_registries** | [**List[AwsServiceRegistry]**](AwsServiceRegistry.md) |  | [optional] 
**status** | **str** |  | [optional] 
**tags** | [**List[AwsTag]**](AwsTag.md) |  | [optional] 
**task_definition** | **str** |  | [optional] 
**task_sets** | [**List[AwsTaskSet]**](AwsTaskSet.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service import AwsService

# TODO update the JSON string below
json = "{}"
# create an instance of AwsService from a JSON string
aws_service_instance = AwsService.from_json(json)
# print the JSON string representation of the object
print(AwsService.to_json())

# convert the object into a dict
aws_service_dict = aws_service_instance.to_dict()
# create an instance of AwsService from a dict
aws_service_from_dict = AwsService.from_dict(aws_service_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


