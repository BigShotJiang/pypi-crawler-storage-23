# AzureAutoHealActionType



## Enum

* `Recycle` (value: `'Recycle'`)

* `LogEvent` (value: `'LogEvent'`)

* `CustomAction` (value: `'CustomAction'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


