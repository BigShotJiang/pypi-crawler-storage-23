# AwsAmazonECSRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.aws_amazon_ecs_request import AwsAmazonECSRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAmazonECSRequest from a JSON string
aws_amazon_ecs_request_instance = AwsAmazonECSRequest.from_json(json)
# print the JSON string representation of the object
print(AwsAmazonECSRequest.to_json())

# convert the object into a dict
aws_amazon_ecs_request_dict = aws_amazon_ecs_request_instance.to_dict()
# create an instance of AwsAmazonECSRequest from a dict
aws_amazon_ecs_request_from_dict = AwsAmazonECSRequest.from_dict(aws_amazon_ecs_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


