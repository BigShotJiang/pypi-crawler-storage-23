# AthenaConnectorSource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**connection_name** | **str** |  | [optional] 
**connection_table** | **str** |  | [optional] 
**connection_type** | **str** |  | [optional] 
**connector_name** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**output_schemas** | [**List[GlueSchema]**](GlueSchema.md) |  | [optional] 
**schema_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.athena_connector_source import AthenaConnectorSource

# TODO update the JSON string below
json = "{}"
# create an instance of AthenaConnectorSource from a JSON string
athena_connector_source_instance = AthenaConnectorSource.from_json(json)
# print the JSON string representation of the object
print(AthenaConnectorSource.to_json())

# convert the object into a dict
athena_connector_source_dict = athena_connector_source_instance.to_dict()
# create an instance of AthenaConnectorSource from a dict
athena_connector_source_from_dict = AthenaConnectorSource.from_dict(athena_connector_source_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


