# AwsScaleUnit


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_scale_unit import AwsScaleUnit

# TODO update the JSON string below
json = "{}"
# create an instance of AwsScaleUnit from a JSON string
aws_scale_unit_instance = AwsScaleUnit.from_json(json)
# print the JSON string representation of the object
print(AwsScaleUnit.to_json())

# convert the object into a dict
aws_scale_unit_dict = aws_scale_unit_instance.to_dict()
# create an instance of AwsScaleUnit from a dict
aws_scale_unit_from_dict = AwsScaleUnit.from_dict(aws_scale_unit_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


