# AwsNetworkInterface


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attachment_id** | **str** |  | [optional] 
**ipv6_address** | **str** |  | [optional] 
**private_ipv4_address** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_network_interface import AwsNetworkInterface

# TODO update the JSON string below
json = "{}"
# create an instance of AwsNetworkInterface from a JSON string
aws_network_interface_instance = AwsNetworkInterface.from_json(json)
# print the JSON string representation of the object
print(AwsNetworkInterface.to_json())

# convert the object into a dict
aws_network_interface_dict = aws_network_interface_instance.to_dict()
# create an instance of AwsNetworkInterface from a dict
aws_network_interface_from_dict = AwsNetworkInterface.from_dict(aws_network_interface_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


