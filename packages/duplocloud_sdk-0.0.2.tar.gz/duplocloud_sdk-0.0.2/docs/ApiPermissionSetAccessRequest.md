# ApiPermissionSetAccessRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_name** | **str** |  | [optional] 
**applicable_permission_sets** | **List[str]** |  | [optional] 
**resource** | **str** |  | [optional] 
**api_name** | **str** |  | [optional] 
**api_method** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.api_permission_set_access_request import ApiPermissionSetAccessRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ApiPermissionSetAccessRequest from a JSON string
api_permission_set_access_request_instance = ApiPermissionSetAccessRequest.from_json(json)
# print the JSON string representation of the object
print(ApiPermissionSetAccessRequest.to_json())

# convert the object into a dict
api_permission_set_access_request_dict = api_permission_set_access_request_instance.to_dict()
# create an instance of ApiPermissionSetAccessRequest from a dict
api_permission_set_access_request_from_dict = ApiPermissionSetAccessRequest.from_dict(api_permission_set_access_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


