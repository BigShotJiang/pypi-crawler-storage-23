# AzureIdentityData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_identity_data import AzureIdentityData

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIdentityData from a JSON string
azure_identity_data_instance = AzureIdentityData.from_json(json)
# print the JSON string representation of the object
print(AzureIdentityData.to_json())

# convert the object into a dict
azure_identity_data_dict = azure_identity_data_instance.to_dict()
# create an instance of AzureIdentityData from a dict
azure_identity_data_from_dict = AzureIdentityData.from_dict(azure_identity_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


