# AzureFirewallRule3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**properties_start_ip_address** | **str** |  | [optional] 
**properties_end_ip_address** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_firewall_rule3 import AzureFirewallRule3

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFirewallRule3 from a JSON string
azure_firewall_rule3_instance = AzureFirewallRule3.from_json(json)
# print the JSON string representation of the object
print(AzureFirewallRule3.to_json())

# convert the object into a dict
azure_firewall_rule3_dict = azure_firewall_rule3_instance.to_dict()
# create an instance of AzureFirewallRule3 from a dict
azure_firewall_rule3_from_dict = AzureFirewallRule3.from_dict(azure_firewall_rule3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


