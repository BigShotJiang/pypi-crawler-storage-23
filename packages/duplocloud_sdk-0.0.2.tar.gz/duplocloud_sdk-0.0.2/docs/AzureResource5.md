# AzureResource5

Resource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource5 import AzureResource5

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource5 from a JSON string
azure_resource5_instance = AzureResource5.from_json(json)
# print the JSON string representation of the object
print(AzureResource5.to_json())

# convert the object into a dict
azure_resource5_dict = azure_resource5_instance.to_dict()
# create an instance of AzureResource5 from a dict
azure_resource5_from_dict = AzureResource5.from_dict(azure_resource5_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


