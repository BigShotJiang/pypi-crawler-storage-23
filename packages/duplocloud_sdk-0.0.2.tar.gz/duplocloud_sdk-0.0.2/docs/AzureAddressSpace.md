# AzureAddressSpace


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**address_prefixes** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_address_space import AzureAddressSpace

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAddressSpace from a JSON string
azure_address_space_instance = AzureAddressSpace.from_json(json)
# print the JSON string representation of the object
print(AzureAddressSpace.to_json())

# convert the object into a dict
azure_address_space_dict = azure_address_space_instance.to_dict()
# create an instance of AzureAddressSpace from a dict
azure_address_space_from_dict = AzureAddressSpace.from_dict(azure_address_space_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


