# AzurePrivateLinkServiceConnectionState


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**actions_required** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_connection_state import AzurePrivateLinkServiceConnectionState

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceConnectionState from a JSON string
azure_private_link_service_connection_state_instance = AzurePrivateLinkServiceConnectionState.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceConnectionState.to_json())

# convert the object into a dict
azure_private_link_service_connection_state_dict = azure_private_link_service_connection_state_instance.to_dict()
# create an instance of AzurePrivateLinkServiceConnectionState from a dict
azure_private_link_service_connection_state_from_dict = AzurePrivateLinkServiceConnectionState.from_dict(azure_private_link_service_connection_state_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


