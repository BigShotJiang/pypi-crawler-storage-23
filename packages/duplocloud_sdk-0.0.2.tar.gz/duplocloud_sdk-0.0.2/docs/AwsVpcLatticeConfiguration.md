# AwsVpcLatticeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**port_name** | **str** |  | [optional] 
**role_arn** | **str** |  | [optional] 
**target_group_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_vpc_lattice_configuration import AwsVpcLatticeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsVpcLatticeConfiguration from a JSON string
aws_vpc_lattice_configuration_instance = AwsVpcLatticeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsVpcLatticeConfiguration.to_json())

# convert the object into a dict
aws_vpc_lattice_configuration_dict = aws_vpc_lattice_configuration_instance.to_dict()
# create an instance of AwsVpcLatticeConfiguration from a dict
aws_vpc_lattice_configuration_from_dict = AwsVpcLatticeConfiguration.from_dict(aws_vpc_lattice_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


