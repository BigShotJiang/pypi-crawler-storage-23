# AzureDnsConfiguration

DNS configuration for the container group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name_servers** | **List[str]** | Gets or sets the DNS servers for the container group. | [optional] 
**search_domains** | **str** | Gets or sets the DNS search domains for hostname lookup in the container group. | [optional] 
**options** | **str** | Gets or sets the DNS options for the container group. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_dns_configuration import AzureDnsConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDnsConfiguration from a JSON string
azure_dns_configuration_instance = AzureDnsConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureDnsConfiguration.to_json())

# convert the object into a dict
azure_dns_configuration_dict = azure_dns_configuration_instance.to_dict()
# create an instance of AzureDnsConfiguration from a dict
azure_dns_configuration_from_dict = AzureDnsConfiguration.from_dict(azure_dns_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


