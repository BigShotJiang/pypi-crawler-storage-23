# AzureRedisLinkedServer

Linked server Id

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets linked server Id. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_linked_server import AzureRedisLinkedServer

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisLinkedServer from a JSON string
azure_redis_linked_server_instance = AzureRedisLinkedServer.from_json(json)
# print the JSON string representation of the object
print(AzureRedisLinkedServer.to_json())

# convert the object into a dict
azure_redis_linked_server_dict = azure_redis_linked_server_instance.to_dict()
# create an instance of AzureRedisLinkedServer from a dict
azure_redis_linked_server_from_dict = AzureRedisLinkedServer.from_dict(azure_redis_linked_server_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


