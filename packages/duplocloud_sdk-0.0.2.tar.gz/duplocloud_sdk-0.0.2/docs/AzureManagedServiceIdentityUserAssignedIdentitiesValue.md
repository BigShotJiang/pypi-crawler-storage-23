# AzureManagedServiceIdentityUserAssignedIdentitiesValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** |  | [optional] 
**client_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_service_identity_user_assigned_identities_value import AzureManagedServiceIdentityUserAssignedIdentitiesValue

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedServiceIdentityUserAssignedIdentitiesValue from a JSON string
azure_managed_service_identity_user_assigned_identities_value_instance = AzureManagedServiceIdentityUserAssignedIdentitiesValue.from_json(json)
# print the JSON string representation of the object
print(AzureManagedServiceIdentityUserAssignedIdentitiesValue.to_json())

# convert the object into a dict
azure_managed_service_identity_user_assigned_identities_value_dict = azure_managed_service_identity_user_assigned_identities_value_instance.to_dict()
# create an instance of AzureManagedServiceIdentityUserAssignedIdentitiesValue from a dict
azure_managed_service_identity_user_assigned_identities_value_from_dict = AzureManagedServiceIdentityUserAssignedIdentitiesValue.from_dict(azure_managed_service_identity_user_assigned_identities_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


