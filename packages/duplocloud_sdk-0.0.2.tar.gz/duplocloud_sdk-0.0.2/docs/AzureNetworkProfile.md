# AzureNetworkProfile

Specifies the network interfaces or the networking configuration of the virtual machine.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**network_interfaces** | [**List[AzureNetworkInterfaceReference]**](AzureNetworkInterfaceReference.md) | Gets or sets specifies the list of resource Ids for the network interfaces associated with the virtual machine. | [optional] 
**network_api_version** | **str** | Gets or sets specifies the Microsoft.Network API version used when creating networking resources in the Network Interface Configurations. Possible values include: &#39;2020-11-01&#39; | [optional] 
**network_interface_configurations** | [**List[AzureVirtualMachineNetworkInterfaceConfiguration]**](AzureVirtualMachineNetworkInterfaceConfiguration.md) | Gets or sets specifies the networking configurations that will be used to create the virtual machine networking resources. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_profile import AzureNetworkProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkProfile from a JSON string
azure_network_profile_instance = AzureNetworkProfile.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkProfile.to_json())

# convert the object into a dict
azure_network_profile_dict = azure_network_profile_instance.to_dict()
# create an instance of AzureNetworkProfile from a dict
azure_network_profile_from_dict = AzureNetworkProfile.from_dict(azure_network_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


