# AzurePort

The port exposed on the container group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protocol** | **str** | Gets or sets the protocol associated with the port. Possible values include: &#39;TCP&#39;, &#39;UDP&#39; | [optional] 
**port** | **int** | Gets or sets the port number. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_port import AzurePort

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePort from a JSON string
azure_port_instance = AzurePort.from_json(json)
# print the JSON string representation of the object
print(AzurePort.to_json())

# convert the object into a dict
azure_port_dict = azure_port_instance.to_dict()
# create an instance of AzurePort from a dict
azure_port_from_dict = AzurePort.from_dict(azure_port_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


