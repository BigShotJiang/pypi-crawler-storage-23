# AwsProxyConfigurationType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_proxy_configuration_type import AwsProxyConfigurationType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsProxyConfigurationType from a JSON string
aws_proxy_configuration_type_instance = AwsProxyConfigurationType.from_json(json)
# print the JSON string representation of the object
print(AwsProxyConfigurationType.to_json())

# convert the object into a dict
aws_proxy_configuration_type_dict = aws_proxy_configuration_type_instance.to_dict()
# create an instance of AwsProxyConfigurationType from a dict
aws_proxy_configuration_type_from_dict = AwsProxyConfigurationType.from_dict(aws_proxy_configuration_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


