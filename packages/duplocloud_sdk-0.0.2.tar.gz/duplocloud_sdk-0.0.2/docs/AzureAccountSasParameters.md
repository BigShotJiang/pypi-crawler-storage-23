# AzureAccountSasParameters

The parameters to list SAS credentials of a storage account.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**signed_services** | **str** | Gets or sets the signed services accessible with the account SAS. Possible values include: Blob (b), Queue (q), Table (t), File (f). Possible values include: &#39;b&#39;, &#39;q&#39;, &#39;t&#39;, &#39;f&#39; | [optional] 
**signed_resource_types** | **str** | Gets or sets the signed resource types that are accessible with the account SAS. Service (s): Access to service-level APIs; Container (c): Access to container-level APIs; Object (o): Access to object-level APIs for blobs, queue messages, table entities, and files. Possible values include: &#39;s&#39;, &#39;c&#39;, &#39;o&#39; | [optional] 
**signed_permission** | **str** | Gets or sets the signed permissions for the account SAS. Possible values include: Read (r), Write (w), Delete (d), List (l), Add (a), Create (c), Update (u) and Process (p). Possible values include: &#39;r&#39;, &#39;d&#39;, &#39;w&#39;, &#39;l&#39;, &#39;a&#39;, &#39;c&#39;, &#39;u&#39;, &#39;p&#39; | [optional] 
**signed_ip** | **str** | Gets or sets an IP address or a range of IP addresses from which to accept requests. | [optional] 
**signed_protocol** | [**AzureHttpProtocol**](AzureHttpProtocol.md) | Gets or sets the protocol permitted for a request made with the account SAS. Possible values include: &#39;https,http&#39;, &#39;https&#39; | [optional] 
**signed_start** | **datetime** | Gets or sets the time at which the SAS becomes valid. | [optional] 
**signed_expiry** | **datetime** | Gets or sets the time at which the shared access signature becomes invalid. | [optional] 
**key_to_sign** | **str** | Gets or sets the key to sign the account SAS token with. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_account_sas_parameters import AzureAccountSasParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAccountSasParameters from a JSON string
azure_account_sas_parameters_instance = AzureAccountSasParameters.from_json(json)
# print the JSON string representation of the object
print(AzureAccountSasParameters.to_json())

# convert the object into a dict
azure_account_sas_parameters_dict = azure_account_sas_parameters_instance.to_dict()
# create an instance of AzureAccountSasParameters from a dict
azure_account_sas_parameters_from_dict = AzureAccountSasParameters.from_dict(azure_account_sas_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


