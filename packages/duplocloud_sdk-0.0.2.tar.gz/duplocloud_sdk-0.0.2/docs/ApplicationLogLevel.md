# ApplicationLogLevel


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.application_log_level import ApplicationLogLevel

# TODO update the JSON string below
json = "{}"
# create an instance of ApplicationLogLevel from a JSON string
application_log_level_instance = ApplicationLogLevel.from_json(json)
# print the JSON string representation of the object
print(ApplicationLogLevel.to_json())

# convert the object into a dict
application_log_level_dict = application_log_level_instance.to_dict()
# create an instance of ApplicationLogLevel from a dict
application_log_level_from_dict = ApplicationLogLevel.from_dict(application_log_level_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


