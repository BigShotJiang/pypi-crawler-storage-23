# AzureContainerHttpGet

The container Http Get settings, for liveness or readiness probe

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**path** | **str** | Gets or sets the path to probe. | [optional] 
**port** | **int** | Gets or sets the port number to probe. | [optional] 
**scheme** | **str** | Gets or sets the scheme. Possible values include: &#39;http&#39;, &#39;https&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_http_get import AzureContainerHttpGet

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerHttpGet from a JSON string
azure_container_http_get_instance = AzureContainerHttpGet.from_json(json)
# print the JSON string representation of the object
print(AzureContainerHttpGet.to_json())

# convert the object into a dict
azure_container_http_get_dict = azure_container_http_get_instance.to_dict()
# create an instance of AzureContainerHttpGet from a dict
azure_container_http_get_from_dict = AzureContainerHttpGet.from_dict(azure_container_http_get_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


