# AwsListener


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**port** | **int** |  | [optional] 
**protocol** | **str** |  | [optional] 
**ssl_certificate_arn** | **str** |  | [optional] 
**target_group_arn** | **str** |  | [optional] 
**is_secure** | **bool** |  | [optional] 
**name** | **str** |  | [optional] 
**default_actions** | [**List[AwsAction]**](AwsAction.md) |  | [optional] 
**certificates** | [**List[Certificate]**](Certificate.md) |  | [optional] 
**rules** | [**List[AwsRule]**](AwsRule.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_listener import AwsListener

# TODO update the JSON string below
json = "{}"
# create an instance of AwsListener from a JSON string
aws_listener_instance = AwsListener.from_json(json)
# print the JSON string representation of the object
print(AwsListener.to_json())

# convert the object into a dict
aws_listener_dict = aws_listener_instance.to_dict()
# create an instance of AwsListener from a dict
aws_listener_from_dict = AwsListener.from_dict(aws_listener_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


