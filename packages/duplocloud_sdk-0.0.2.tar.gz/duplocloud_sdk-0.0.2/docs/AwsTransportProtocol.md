# AwsTransportProtocol


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_transport_protocol import AwsTransportProtocol

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTransportProtocol from a JSON string
aws_transport_protocol_instance = AwsTransportProtocol.from_json(json)
# print the JSON string representation of the object
print(AwsTransportProtocol.to_json())

# convert the object into a dict
aws_transport_protocol_dict = aws_transport_protocol_instance.to_dict()
# create an instance of AwsTransportProtocol from a dict
aws_transport_protocol_from_dict = AwsTransportProtocol.from_dict(aws_transport_protocol_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


