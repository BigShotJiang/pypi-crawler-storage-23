# duplocloud_sdk.AWSApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_cluster_all**](AWSApi.md#rds_api_cluster_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/cluster | 
[**rds_api_cluster_get**](AWSApi.md#rds_api_cluster_get) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id} | 
[**rds_api_cluster_post**](AWSApi.md#rds_api_cluster_post) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/start | 
[**rds_api_cluster_post2**](AWSApi.md#rds_api_cluster_post2) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/stop | 
[**rds_api_cluster_post3**](AWSApi.md#rds_api_cluster_post3) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/reboot | 
[**rds_api_cluster_post4**](AWSApi.md#rds_api_cluster_post4) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/auroraToV2Serverless | 
[**rds_api_cluster_post5**](AWSApi.md#rds_api_cluster_post5) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/restorePointInTime | 
[**rds_api_cluster_put**](AWSApi.md#rds_api_cluster_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id} | 
[**rds_api_db_subnet_groups**](AWSApi.md#rds_api_db_subnet_groups) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/dbSubnetGroups | 
[**rds_api_engine_versions**](AWSApi.md#rds_api_engine_versions) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/engineVersions | 
[**rds_api_instance_all**](AWSApi.md#rds_api_instance_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance | 
[**rds_api_instance_delete**](AWSApi.md#rds_api_instance_delete) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 
[**rds_api_instance_get**](AWSApi.md#rds_api_instance_get) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 
[**rds_api_instance_get2**](AWSApi.md#rds_api_instance_get2) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/describe | 
[**rds_api_instance_get3**](AWSApi.md#rds_api_instance_get3) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/groupDetails | 
[**rds_api_instance_post**](AWSApi.md#rds_api_instance_post) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance | 
[**rds_api_instance_post10**](AWSApi.md#rds_api_instance_post10) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/restorePointInTime | 
[**rds_api_instance_post2**](AWSApi.md#rds_api_instance_post2) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/changePassword | 
[**rds_api_instance_post3**](AWSApi.md#rds_api_instance_post3) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/replica | 
[**rds_api_instance_post4**](AWSApi.md#rds_api_instance_post4) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/replica/promote | 
[**rds_api_instance_post5**](AWSApi.md#rds_api_instance_post5) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/snapshot | 
[**rds_api_instance_post6**](AWSApi.md#rds_api_instance_post6) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/reboot | 
[**rds_api_instance_post7**](AWSApi.md#rds_api_instance_post7) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/start | 
[**rds_api_instance_post8**](AWSApi.md#rds_api_instance_post8) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/stop | 
[**rds_api_instance_post9**](AWSApi.md#rds_api_instance_post9) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/authToken | 
[**rds_api_instance_put**](AWSApi.md#rds_api_instance_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 
[**rds_api_quota**](AWSApi.md#rds_api_quota) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/quota | 
[**rds_api_snapshot_all**](AWSApi.md#rds_api_snapshot_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot | 
[**rds_api_snapshot_all2**](AWSApi.md#rds_api_snapshot_all2) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/tenantOwned | 
[**rds_api_snapshot_delete**](AWSApi.md#rds_api_snapshot_delete) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id} | 
[**rds_api_snapshot_delete2**](AWSApi.md#rds_api_snapshot_delete2) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id}/clusterSnapshot | 
[**rds_api_snapshot_put**](AWSApi.md#rds_api_snapshot_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id}/share | 


# **rds_api_cluster_all**
> List[DBCluster] rds_api_cluster_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_cluster import DBCluster
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_cluster_all(subscription_id)
        print("The response of AWSApi->rds_api_cluster_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[DBCluster]**](DBCluster.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_get**
> DBCluster rds_api_cluster_get(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_cluster import DBCluster
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_cluster_get(subscription_id, id)
        print("The response of AWSApi->rds_api_cluster_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBCluster**](DBCluster.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post**
> rds_api_cluster_post(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post2**
> rds_api_cluster_post2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post2(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_post2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post3**
> rds_api_cluster_post3(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post3(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_post3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post4**
> rds_api_cluster_post4(subscription_id, id, rdsdb_instance_details=rdsdb_instance_details)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance_details = duplocloud_sdk.RDSDBInstanceDetails() # RDSDBInstanceDetails |  (optional)

    try:
        api_instance.rds_api_cluster_post4(subscription_id, id, rdsdb_instance_details=rdsdb_instance_details)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_post4: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance_details** | [**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post5**
> rds_api_cluster_post5(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_point_in_time_restore_request import RdsPointInTimeRestoreRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rds_point_in_time_restore_request = duplocloud_sdk.RdsPointInTimeRestoreRequest() # RdsPointInTimeRestoreRequest |  (optional)

    try:
        api_instance.rds_api_cluster_post5(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_post5: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rds_point_in_time_restore_request** | [**RdsPointInTimeRestoreRequest**](RdsPointInTimeRestoreRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_put**
> rds_api_cluster_put(subscription_id, id, modify_db_cluster_request_ext=modify_db_cluster_request_ext)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.modify_db_cluster_request_ext import ModifyDBClusterRequestExt
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    modify_db_cluster_request_ext = duplocloud_sdk.ModifyDBClusterRequestExt() # ModifyDBClusterRequestExt |  (optional)

    try:
        api_instance.rds_api_cluster_put(subscription_id, id, modify_db_cluster_request_ext=modify_db_cluster_request_ext)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_cluster_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **modify_db_cluster_request_ext** | [**ModifyDBClusterRequestExt**](ModifyDBClusterRequestExt.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_db_subnet_groups**
> List[DBSubnetGroup] rds_api_db_subnet_groups(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_subnet_group import DBSubnetGroup
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_db_subnet_groups(subscription_id)
        print("The response of AWSApi->rds_api_db_subnet_groups:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_db_subnet_groups: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[DBSubnetGroup]**](DBSubnetGroup.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_engine_versions**
> RdsEngineVersionsResponse rds_api_engine_versions(subscription_id, rds_engine_versions_request=rds_engine_versions_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_engine_versions_request import RdsEngineVersionsRequest
from duplocloud_sdk.models.rds_engine_versions_response import RdsEngineVersionsResponse
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    rds_engine_versions_request = duplocloud_sdk.RdsEngineVersionsRequest() # RdsEngineVersionsRequest |  (optional)

    try:
        api_response = api_instance.rds_api_engine_versions(subscription_id, rds_engine_versions_request=rds_engine_versions_request)
        print("The response of AWSApi->rds_api_engine_versions:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_engine_versions: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **rds_engine_versions_request** | [**RdsEngineVersionsRequest**](RdsEngineVersionsRequest.md)|  | [optional] 

### Return type

[**RdsEngineVersionsResponse**](RdsEngineVersionsResponse.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_all**
> List[RDSDBInstanceDetails] rds_api_instance_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_all(subscription_id)
        print("The response of AWSApi->rds_api_instance_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBInstanceDetails]**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_delete**
> RDSDBInstanceDetails rds_api_instance_delete(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_delete(subscription_id, id)
        print("The response of AWSApi->rds_api_instance_delete:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_get**
> RDSDBInstanceDetails rds_api_instance_get(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get(subscription_id, id)
        print("The response of AWSApi->rds_api_instance_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_get2**
> DBInstance rds_api_instance_get2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_instance import DBInstance
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get2(subscription_id, id)
        print("The response of AWSApi->rds_api_instance_get2:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_get2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBInstance**](DBInstance.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_get3**
> DBInstanceWithReplicas rds_api_instance_get3(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_instance_with_replicas import DBInstanceWithReplicas
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get3(subscription_id, id)
        print("The response of AWSApi->rds_api_instance_get3:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_get3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBInstanceWithReplicas**](DBInstanceWithReplicas.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post**
> RDSDBInstanceDetails rds_api_instance_post(subscription_id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post(subscription_id, rdsdb_instance=rdsdb_instance)
        print("The response of AWSApi->rds_api_instance_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post10**
> rds_api_instance_post10(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_point_in_time_restore_request import RdsPointInTimeRestoreRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rds_point_in_time_restore_request = duplocloud_sdk.RdsPointInTimeRestoreRequest() # RdsPointInTimeRestoreRequest |  (optional)

    try:
        api_instance.rds_api_instance_post10(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post10: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rds_point_in_time_restore_request** | [**RdsPointInTimeRestoreRequest**](RdsPointInTimeRestoreRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post2**
> rds_api_instance_post2(subscription_id, id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_instance.rds_api_instance_post2(subscription_id, id, rdsdb_instance=rdsdb_instance)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post3**
> RDSDBInstanceDetails rds_api_instance_post3(subscription_id, id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post3(subscription_id, id, rdsdb_instance=rdsdb_instance)
        print("The response of AWSApi->rds_api_instance_post3:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post4**
> rds_api_instance_post4(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post4(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post4: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post5**
> str rds_api_instance_post5(subscription_id, id, rdsdb_snapshot_request=rdsdb_snapshot_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_request import RDSDBSnapshotRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_snapshot_request = duplocloud_sdk.RDSDBSnapshotRequest() # RDSDBSnapshotRequest |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post5(subscription_id, id, rdsdb_snapshot_request=rdsdb_snapshot_request)
        print("The response of AWSApi->rds_api_instance_post5:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post5: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_snapshot_request** | [**RDSDBSnapshotRequest**](RDSDBSnapshotRequest.md)|  | [optional] 

### Return type

**str**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post6**
> rds_api_instance_post6(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post6(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post6: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post7**
> rds_api_instance_post7(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post7(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post7: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post8**
> rds_api_instance_post8(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post8(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post8: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post9**
> str rds_api_instance_post9(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_post9(subscription_id, id)
        print("The response of AWSApi->rds_api_instance_post9:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_post9: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

**str**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_put**
> rds_api_instance_put(subscription_id, id, modify_db_instance_request_ext=modify_db_instance_request_ext)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.modify_db_instance_request_ext import ModifyDBInstanceRequestExt
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    modify_db_instance_request_ext = duplocloud_sdk.ModifyDBInstanceRequestExt() # ModifyDBInstanceRequestExt |  (optional)

    try:
        api_instance.rds_api_instance_put(subscription_id, id, modify_db_instance_request_ext=modify_db_instance_request_ext)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_instance_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **modify_db_instance_request_ext** | [**ModifyDBInstanceRequestExt**](ModifyDBInstanceRequestExt.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_quota**
> Dict[str, AwsAccountQuota] rds_api_quota(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.aws_account_quota import AwsAccountQuota
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_quota(subscription_id)
        print("The response of AWSApi->rds_api_quota:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_quota: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**Dict[str, AwsAccountQuota]**](AwsAccountQuota.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_all**
> List[RDSDBSnapshotDetails] rds_api_snapshot_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_details import RDSDBSnapshotDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_snapshot_all(subscription_id)
        print("The response of AWSApi->rds_api_snapshot_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_snapshot_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBSnapshotDetails]**](RDSDBSnapshotDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_all2**
> List[RDSDBSnapshotDetails] rds_api_snapshot_all2(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_details import RDSDBSnapshotDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_snapshot_all2(subscription_id)
        print("The response of AWSApi->rds_api_snapshot_all2:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_snapshot_all2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBSnapshotDetails]**](RDSDBSnapshotDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_delete**
> rds_api_snapshot_delete(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_snapshot_delete(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_snapshot_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_delete2**
> rds_api_snapshot_delete2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_snapshot_delete2(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_snapshot_delete2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_put**
> rds_api_snapshot_put(subscription_id, id, rdsdb_snapshot_share_request=rdsdb_snapshot_share_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_share_request import RDSDBSnapshotShareRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_snapshot_share_request = duplocloud_sdk.RDSDBSnapshotShareRequest() # RDSDBSnapshotShareRequest |  (optional)

    try:
        api_instance.rds_api_snapshot_put(subscription_id, id, rdsdb_snapshot_share_request=rdsdb_snapshot_share_request)
    except Exception as e:
        print("Exception when calling AWSApi->rds_api_snapshot_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_snapshot_share_request** | [**RDSDBSnapshotShareRequest**](RDSDBSnapshotShareRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

