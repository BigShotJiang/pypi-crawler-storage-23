# AzureContainerGroup


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets the resource id. | [optional] 
**name** | **str** | Gets the resource name. | [optional] 
**type** | **str** | Gets the resource type. | [optional] 
**location** | **str** | Gets or sets the resource location. | [optional] 
**tags** | **Dict[str, str]** | Gets or sets the resource tags. | [optional] 
**identity** | [**AzureContainerGroupIdentity**](AzureContainerGroupIdentity.md) | Gets or sets the identity of the container group, if configured. | [optional] 
**properties_provisioning_state** | **str** | Gets the provisioning state of the container group. This only appears in the response. | [optional] 
**properties_containers** | [**List[AzureContainer]**](AzureContainer.md) | Gets or sets the containers within the container group. | [optional] 
**properties_image_registry_credentials** | [**List[AzureImageRegistryCredential]**](AzureImageRegistryCredential.md) | Gets or sets the image registry credentials by which the container group is created from. | [optional] 
**properties_restart_policy** | **str** | Gets or sets restart policy for all containers within the container group. - &#x60;Always&#x60; Always restart - &#x60;OnFailure&#x60; Restart on failure - &#x60;Never&#x60; Never restart . Possible values include: &#39;Always&#39;, &#39;OnFailure&#39;, &#39;Never&#39; | [optional] 
**properties_ip_address** | [**AzureIpAddress**](AzureIpAddress.md) | Gets or sets the IP address type of the container group. | [optional] 
**properties_os_type** | **str** | Gets or sets the operating system type required by the containers in the container group. Possible values include: &#39;Windows&#39;, &#39;Linux&#39; | [optional] 
**properties_volumes** | [**List[AzureVolume]**](AzureVolume.md) | Gets or sets the list of volumes that can be mounted by containers in this container group. | [optional] 
**properties_instance_view** | [**AzureContainerGroupPropertiesInstanceView**](AzureContainerGroupPropertiesInstanceView.md) | Gets the instance view of the container group. Only valid in response. | [optional] 
**properties_diagnostics** | [**AzureContainerGroupDiagnostics**](AzureContainerGroupDiagnostics.md) | Gets or sets the diagnostic information for a container group. | [optional] 
**properties_network_profile** | [**AzureContainerGroupNetworkProfile**](AzureContainerGroupNetworkProfile.md) | Gets or sets the network profile information for a container group. | [optional] 
**properties_dns_config** | [**AzureDnsConfiguration**](AzureDnsConfiguration.md) | Gets or sets the DNS config information for a container group. | [optional] 
**properties_sku** | **str** | Gets or sets the SKU for a container group. Possible values include: &#39;Standard&#39;, &#39;Dedicated&#39; | [optional] 
**properties_encryption_properties** | [**AzureEncryptionProperties**](AzureEncryptionProperties.md) | Gets or sets the encryption properties for a container group. | [optional] 
**properties_init_containers** | [**List[AzureInitContainerDefinition]**](AzureInitContainerDefinition.md) | Gets or sets the init containers for a container group. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group import AzureContainerGroup

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroup from a JSON string
azure_container_group_instance = AzureContainerGroup.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroup.to_json())

# convert the object into a dict
azure_container_group_dict = azure_container_group_instance.to_dict()
# create an instance of AzureContainerGroup from a dict
azure_container_group_from_dict = AzureContainerGroup.from_dict(azure_container_group_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


