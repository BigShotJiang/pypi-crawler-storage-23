# AzureApplicationGatewayIPConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_subnet** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_ip_configuration import AzureApplicationGatewayIPConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayIPConfiguration from a JSON string
azure_application_gateway_ip_configuration_instance = AzureApplicationGatewayIPConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayIPConfiguration.to_json())

# convert the object into a dict
azure_application_gateway_ip_configuration_dict = azure_application_gateway_ip_configuration_instance.to_dict()
# create an instance of AzureApplicationGatewayIPConfiguration from a dict
azure_application_gateway_ip_configuration_from_dict = AzureApplicationGatewayIPConfiguration.from_dict(azure_application_gateway_ip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


