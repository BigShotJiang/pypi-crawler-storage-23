# AwsOSFamily


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_os_family import AwsOSFamily

# TODO update the JSON string below
json = "{}"
# create an instance of AwsOSFamily from a JSON string
aws_os_family_instance = AwsOSFamily.from_json(json)
# print the JSON string representation of the object
print(AwsOSFamily.to_json())

# convert the object into a dict
aws_os_family_dict = aws_os_family_instance.to_dict()
# create an instance of AwsOSFamily from a dict
aws_os_family_from_dict = AwsOSFamily.from_dict(aws_os_family_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


