# ArnResourceType



## Enum

* `Unknown` (value: `0`)

* `ApplicationELB` (value: `1`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


