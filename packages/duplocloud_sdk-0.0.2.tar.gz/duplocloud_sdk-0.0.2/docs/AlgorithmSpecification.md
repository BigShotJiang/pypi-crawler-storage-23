# AlgorithmSpecification


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**algorithm_name** | **str** |  | [optional] 
**container_arguments** | **List[str]** |  | [optional] 
**container_entrypoint** | **List[str]** |  | [optional] 
**enable_sage_maker_metrics_time_series** | **bool** |  | [optional] 
**metric_definitions** | [**List[MetricDefinition]**](MetricDefinition.md) |  | [optional] 
**training_image** | **str** |  | [optional] 
**training_image_config** | [**TrainingImageConfig**](TrainingImageConfig.md) |  | [optional] 
**training_input_mode** | [**TrainingInputMode**](TrainingInputMode.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.algorithm_specification import AlgorithmSpecification

# TODO update the JSON string below
json = "{}"
# create an instance of AlgorithmSpecification from a JSON string
algorithm_specification_instance = AlgorithmSpecification.from_json(json)
# print the JSON string representation of the object
print(AlgorithmSpecification.to_json())

# convert the object into a dict
algorithm_specification_dict = algorithm_specification_instance.to_dict()
# create an instance of AlgorithmSpecification from a dict
algorithm_specification_from_dict = AlgorithmSpecification.from_dict(algorithm_specification_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


