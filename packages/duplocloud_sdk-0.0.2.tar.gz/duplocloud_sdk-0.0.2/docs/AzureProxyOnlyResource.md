# AzureProxyOnlyResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_proxy_only_resource import AzureProxyOnlyResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProxyOnlyResource from a JSON string
azure_proxy_only_resource_instance = AzureProxyOnlyResource.from_json(json)
# print the JSON string representation of the object
print(AzureProxyOnlyResource.to_json())

# convert the object into a dict
azure_proxy_only_resource_dict = azure_proxy_only_resource_instance.to_dict()
# create an instance of AzureProxyOnlyResource from a dict
azure_proxy_only_resource_from_dict = AzureProxyOnlyResource.from_dict(azure_proxy_only_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


