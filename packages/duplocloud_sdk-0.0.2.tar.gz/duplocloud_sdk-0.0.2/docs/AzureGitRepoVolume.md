# AzureGitRepoVolume

Represents a volume that is populated with the contents of a git repository

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**directory** | **str** | Gets or sets target directory name. Must not contain or start with &#39;..&#39;.  If &#39;.&#39; is supplied, the volume directory will be the git repository.  Otherwise, if specified, the volume will contain the git repository in the subdirectory with the given name. | [optional] 
**repository** | **str** | Gets or sets repository URL | [optional] 
**revision** | **str** | Gets or sets commit hash for the specified revision. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_git_repo_volume import AzureGitRepoVolume

# TODO update the JSON string below
json = "{}"
# create an instance of AzureGitRepoVolume from a JSON string
azure_git_repo_volume_instance = AzureGitRepoVolume.from_json(json)
# print the JSON string representation of the object
print(AzureGitRepoVolume.to_json())

# convert the object into a dict
azure_git_repo_volume_dict = azure_git_repo_volume_instance.to_dict()
# create an instance of AzureGitRepoVolume from a dict
azure_git_repo_volume_from_dict = AzureGitRepoVolume.from_dict(azure_git_repo_volume_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


