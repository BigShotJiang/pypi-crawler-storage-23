# AzureIpTag


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ip_tag_type** | **str** |  | [optional] 
**tag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_tag import AzureIpTag

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIpTag from a JSON string
azure_ip_tag_instance = AzureIpTag.from_json(json)
# print the JSON string representation of the object
print(AzureIpTag.to_json())

# convert the object into a dict
azure_ip_tag_dict = azure_ip_tag_instance.to_dict()
# create an instance of AzureIpTag from a dict
azure_ip_tag_from_dict = AzureIpTag.from_dict(azure_ip_tag_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


