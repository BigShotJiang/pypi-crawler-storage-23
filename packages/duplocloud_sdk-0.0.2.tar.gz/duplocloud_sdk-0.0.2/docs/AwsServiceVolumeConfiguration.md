# AwsServiceVolumeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**managed_ebs_volume** | [**AwsServiceManagedEBSVolumeConfiguration**](AwsServiceManagedEBSVolumeConfiguration.md) |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_volume_configuration import AwsServiceVolumeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceVolumeConfiguration from a JSON string
aws_service_volume_configuration_instance = AwsServiceVolumeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsServiceVolumeConfiguration.to_json())

# convert the object into a dict
aws_service_volume_configuration_dict = aws_service_volume_configuration_instance.to_dict()
# create an instance of AwsServiceVolumeConfiguration from a dict
aws_service_volume_configuration_from_dict = AwsServiceVolumeConfiguration.from_dict(aws_service_volume_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


