# ArnRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**duplo_identifier** | **str** |  | [optional] 
**resource_type** | [**ArnResourceType**](ArnResourceType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.arn_request import ArnRequest

# TODO update the JSON string below
json = "{}"
# create an instance of ArnRequest from a JSON string
arn_request_instance = ArnRequest.from_json(json)
# print the JSON string representation of the object
print(ArnRequest.to_json())

# convert the object into a dict
arn_request_dict = arn_request_instance.to_dict()
# create an instance of ArnRequest from a dict
arn_request_from_dict = ArnRequest.from_dict(arn_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


