# AmazonRedshiftNodeData


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_type** | **str** |  | [optional] 
**action** | **str** |  | [optional] 
**advanced_options** | [**List[AmazonRedshiftAdvancedOption]**](AmazonRedshiftAdvancedOption.md) |  | [optional] 
**catalog_database** | [**Option**](Option.md) |  | [optional] 
**catalog_redshift_schema** | **str** |  | [optional] 
**catalog_redshift_table** | **str** |  | [optional] 
**catalog_table** | [**Option**](Option.md) |  | [optional] 
**connection** | [**Option**](Option.md) |  | [optional] 
**crawler_connection** | **str** |  | [optional] 
**iam_role** | [**Option**](Option.md) |  | [optional] 
**merge_action** | **str** |  | [optional] 
**merge_clause** | **str** |  | [optional] 
**merge_when_matched** | **str** |  | [optional] 
**merge_when_not_matched** | **str** |  | [optional] 
**post_action** | **str** |  | [optional] 
**pre_action** | **str** |  | [optional] 
**sample_query** | **str** |  | [optional] 
**var_schema** | [**Option**](Option.md) |  | [optional] 
**selected_columns** | [**List[Option]**](Option.md) |  | [optional] 
**source_type** | **str** |  | [optional] 
**staging_table** | **str** |  | [optional] 
**table** | [**Option**](Option.md) |  | [optional] 
**table_prefix** | **str** |  | [optional] 
**table_schema** | [**List[Option]**](Option.md) |  | [optional] 
**temp_dir** | **str** |  | [optional] 
**upsert** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amazon_redshift_node_data import AmazonRedshiftNodeData

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonRedshiftNodeData from a JSON string
amazon_redshift_node_data_instance = AmazonRedshiftNodeData.from_json(json)
# print the JSON string representation of the object
print(AmazonRedshiftNodeData.to_json())

# convert the object into a dict
amazon_redshift_node_data_dict = amazon_redshift_node_data_instance.to_dict()
# create an instance of AmazonRedshiftNodeData from a dict
amazon_redshift_node_data_from_dict = AmazonRedshiftNodeData.from_dict(amazon_redshift_node_data_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


