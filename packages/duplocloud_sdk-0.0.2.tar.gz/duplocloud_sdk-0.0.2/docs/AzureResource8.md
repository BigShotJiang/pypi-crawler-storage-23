# AzureResource8

Resource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource8 import AzureResource8

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource8 from a JSON string
azure_resource8_instance = AzureResource8.from_json(json)
# print the JSON string representation of the object
print(AzureResource8.to_json())

# convert the object into a dict
azure_resource8_dict = azure_resource8_instance.to_dict()
# create an instance of AzureResource8 from a dict
azure_resource8_from_dict = AzureResource8.from_dict(azure_resource8_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


