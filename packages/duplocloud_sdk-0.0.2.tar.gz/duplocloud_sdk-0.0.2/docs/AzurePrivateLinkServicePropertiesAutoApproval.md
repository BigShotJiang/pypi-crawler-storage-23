# AzurePrivateLinkServicePropertiesAutoApproval


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**subscriptions** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_properties_auto_approval import AzurePrivateLinkServicePropertiesAutoApproval

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServicePropertiesAutoApproval from a JSON string
azure_private_link_service_properties_auto_approval_instance = AzurePrivateLinkServicePropertiesAutoApproval.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServicePropertiesAutoApproval.to_json())

# convert the object into a dict
azure_private_link_service_properties_auto_approval_dict = azure_private_link_service_properties_auto_approval_instance.to_dict()
# create an instance of AzurePrivateLinkServicePropertiesAutoApproval from a dict
azure_private_link_service_properties_auto_approval_from_dict = AzurePrivateLinkServicePropertiesAutoApproval.from_dict(azure_private_link_service_properties_auto_approval_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


