# AwsRuntimePlatform


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cpu_architecture** | [**AwsCPUArchitecture**](AwsCPUArchitecture.md) |  | [optional] 
**operating_system_family** | [**AwsOSFamily**](AwsOSFamily.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_runtime_platform import AwsRuntimePlatform

# TODO update the JSON string below
json = "{}"
# create an instance of AwsRuntimePlatform from a JSON string
aws_runtime_platform_instance = AwsRuntimePlatform.from_json(json)
# print the JSON string representation of the object
print(AwsRuntimePlatform.to_json())

# convert the object into a dict
aws_runtime_platform_dict = aws_runtime_platform_instance.to_dict()
# create an instance of AwsRuntimePlatform from a dict
aws_runtime_platform_from_dict = AwsRuntimePlatform.from_dict(aws_runtime_platform_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


