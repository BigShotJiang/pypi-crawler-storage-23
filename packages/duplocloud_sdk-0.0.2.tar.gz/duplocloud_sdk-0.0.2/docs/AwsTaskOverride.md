# AwsTaskOverride


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_overrides** | [**List[AwsContainerOverride]**](AwsContainerOverride.md) |  | [optional] 
**cpu** | **str** |  | [optional] 
**ephemeral_storage** | [**AwsEphemeralStorage**](AwsEphemeralStorage.md) |  | [optional] 
**execution_role_arn** | **str** |  | [optional] 
**inference_accelerator_overrides** | [**List[AwsInferenceAcceleratorOverride]**](AwsInferenceAcceleratorOverride.md) |  | [optional] 
**memory** | **str** |  | [optional] 
**task_role_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_override import AwsTaskOverride

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskOverride from a JSON string
aws_task_override_instance = AwsTaskOverride.from_json(json)
# print the JSON string representation of the object
print(AwsTaskOverride.to_json())

# convert the object into a dict
aws_task_override_dict = aws_task_override_instance.to_dict()
# create an instance of AwsTaskOverride from a dict
aws_task_override_from_dict = AwsTaskOverride.from_dict(aws_task_override_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


