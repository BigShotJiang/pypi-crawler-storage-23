# AzureManagedInstanceFamilyCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**sku** | **str** |  | [optional] 
**supported_license_types** | [**List[AzureLicenseTypeCapability]**](AzureLicenseTypeCapability.md) |  | [optional] 
**supported_vcores_values** | [**List[AzureManagedInstanceVcoresCapability]**](AzureManagedInstanceVcoresCapability.md) |  | [optional] 
**included_max_size** | [**AzureMaxSizeCapability**](AzureMaxSizeCapability.md) |  | [optional] 
**supported_storage_sizes** | [**List[AzureMaxSizeRangeCapability]**](AzureMaxSizeRangeCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_instance_family_capability import AzureManagedInstanceFamilyCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedInstanceFamilyCapability from a JSON string
azure_managed_instance_family_capability_instance = AzureManagedInstanceFamilyCapability.from_json(json)
# print the JSON string representation of the object
print(AzureManagedInstanceFamilyCapability.to_json())

# convert the object into a dict
azure_managed_instance_family_capability_dict = azure_managed_instance_family_capability_instance.to_dict()
# create an instance of AzureManagedInstanceFamilyCapability from a dict
azure_managed_instance_family_capability_from_dict = AzureManagedInstanceFamilyCapability.from_dict(azure_managed_instance_family_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


