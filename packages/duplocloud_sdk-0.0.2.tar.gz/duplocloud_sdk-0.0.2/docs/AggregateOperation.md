# AggregateOperation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**agg_func** | [**AggFunction**](AggFunction.md) |  | [optional] 
**column** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aggregate_operation import AggregateOperation

# TODO update the JSON string below
json = "{}"
# create an instance of AggregateOperation from a JSON string
aggregate_operation_instance = AggregateOperation.from_json(json)
# print the JSON string representation of the object
print(AggregateOperation.to_json())

# convert the object into a dict
aggregate_operation_dict = aggregate_operation_instance.to_dict()
# create an instance of AggregateOperation from a dict
aggregate_operation_from_dict = AggregateOperation.from_dict(aggregate_operation_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


