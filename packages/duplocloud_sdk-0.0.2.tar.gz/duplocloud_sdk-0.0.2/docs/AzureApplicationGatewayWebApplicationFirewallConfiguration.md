# AzureApplicationGatewayWebApplicationFirewallConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**firewall_mode** | **str** |  | [optional] 
**rule_set_type** | **str** |  | [optional] 
**rule_set_version** | **str** |  | [optional] 
**disabled_rule_groups** | [**List[AzureApplicationGatewayFirewallDisabledRuleGroup]**](AzureApplicationGatewayFirewallDisabledRuleGroup.md) |  | [optional] 
**request_body_check** | **bool** |  | [optional] 
**max_request_body_size** | **int** |  | [optional] 
**max_request_body_size_in_kb** | **int** |  | [optional] 
**file_upload_limit_in_mb** | **int** |  | [optional] 
**exclusions** | [**List[AzureApplicationGatewayFirewallExclusion]**](AzureApplicationGatewayFirewallExclusion.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_web_application_firewall_configuration import AzureApplicationGatewayWebApplicationFirewallConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayWebApplicationFirewallConfiguration from a JSON string
azure_application_gateway_web_application_firewall_configuration_instance = AzureApplicationGatewayWebApplicationFirewallConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayWebApplicationFirewallConfiguration.to_json())

# convert the object into a dict
azure_application_gateway_web_application_firewall_configuration_dict = azure_application_gateway_web_application_firewall_configuration_instance.to_dict()
# create an instance of AzureApplicationGatewayWebApplicationFirewallConfiguration from a dict
azure_application_gateway_web_application_firewall_configuration_from_dict = AzureApplicationGatewayWebApplicationFirewallConfiguration.from_dict(azure_application_gateway_web_application_firewall_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


