# duplocloud_sdk.AdminApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_vpn_config**](AdminApi.md#get_vpn_config) | **GET** /v3/admin/systemSettings/vpnConfig | 
[**v3_admin_system_settings_api_add_acm_certificate**](AdminApi.md#v3_admin_system_settings_api_add_acm_certificate) | **POST** /v3/admin/systemSettings/acmCertificate | 
[**v3_admin_system_settings_api_add_api_permission_set**](AdminApi.md#v3_admin_system_settings_api_add_api_permission_set) | **POST** /v3/admin/systemSettings/apiPermissionSet | 
[**v3_admin_system_settings_api_add_aws_account_security_setting**](AdminApi.md#v3_admin_system_settings_api_add_aws_account_security_setting) | **POST** /v3/admin/systemSettings/awsAccountSecuritySettings | 
[**v3_admin_system_settings_api_add_system_setting**](AdminApi.md#v3_admin_system_settings_api_add_system_setting) | **POST** /v3/admin/systemSettings/config | 
[**v3_admin_system_settings_api_aws_account_security**](AdminApi.md#v3_admin_system_settings_api_aws_account_security) | **GET** /v3/admin/systemSettings/awsAccountSecurity | 
[**v3_admin_system_settings_api_aws_account_security_features**](AdminApi.md#v3_admin_system_settings_api_aws_account_security_features) | **POST** /v3/admin/systemSettings/awsAccountSecurityFeatures | 
[**v3_admin_system_settings_api_aws_account_security_settings**](AdminApi.md#v3_admin_system_settings_api_aws_account_security_settings) | **DELETE** /v3/admin/systemSettings/awsAccountSecuritySettings/{id} | 
[**v3_admin_system_settings_api_delete_system_setting**](AdminApi.md#v3_admin_system_settings_api_delete_system_setting) | **DELETE** /v3/admin/systemSettings/config/{id} | 
[**v3_admin_system_settings_api_gcp_account_security**](AdminApi.md#v3_admin_system_settings_api_gcp_account_security) | **GET** /v3/admin/systemSettings/gcpAccountSecurity | 
[**v3_admin_system_settings_api_gcp_account_security2**](AdminApi.md#v3_admin_system_settings_api_gcp_account_security2) | **GET** /v3/admin/systemSettings/gcpAccountSecurity/{accountId} | 
[**v3_admin_system_settings_api_gcp_account_security_features**](AdminApi.md#v3_admin_system_settings_api_gcp_account_security_features) | **POST** /v3/admin/systemSettings/gcpAccountSecurityFeatures/{accountID} | 
[**v3_admin_system_settings_api_get_acm_certificates**](AdminApi.md#v3_admin_system_settings_api_get_acm_certificates) | **GET** /v3/admin/systemSettings/acmCertificate/{region} | 
[**v3_admin_system_settings_api_get_api_permission_set**](AdminApi.md#v3_admin_system_settings_api_get_api_permission_set) | **GET** /v3/admin/systemSettings/userApiPermissionSet/{name} | 
[**v3_admin_system_settings_api_get_api_permission_set_db**](AdminApi.md#v3_admin_system_settings_api_get_api_permission_set_db) | **GET** /v3/admin/systemSettings/userApiPermissionSetDB | 
[**v3_admin_system_settings_api_get_permission_set_list**](AdminApi.md#v3_admin_system_settings_api_get_permission_set_list) | **GET** /v3/admin/systemSettings/permissionSetList | 
[**v3_admin_system_settings_api_get_permission_set_swagger**](AdminApi.md#v3_admin_system_settings_api_get_permission_set_swagger) | **GET** /v3/admin/systemSettings/permissionSetSwagger | 
[**v3_admin_system_settings_api_get_system_setting**](AdminApi.md#v3_admin_system_settings_api_get_system_setting) | **GET** /v3/admin/systemSettings/config/{id} | 
[**v3_admin_system_settings_api_get_system_settings**](AdminApi.md#v3_admin_system_settings_api_get_system_settings) | **GET** /v3/admin/systemSettings/config | 
[**v3_admin_system_settings_api_remove_api_permission_set**](AdminApi.md#v3_admin_system_settings_api_remove_api_permission_set) | **DELETE** /v3/admin/systemSettings/apiPermissionSet/{name} | 
[**v3_admin_system_settings_api_test_permission_set_for_user_api**](AdminApi.md#v3_admin_system_settings_api_test_permission_set_for_user_api) | **POST** /v3/admin/systemSettings/testPermissionSetForUserApi | 
[**v3_admin_system_settings_api_update_api_permission_set**](AdminApi.md#v3_admin_system_settings_api_update_api_permission_set) | **PUT** /v3/admin/systemSettings/apiPermissionSet | 
[**v3_admin_system_settings_api_update_api_permission_set_db_status**](AdminApi.md#v3_admin_system_settings_api_update_api_permission_set_db_status) | **POST** /v3/admin/systemSettings/updateApiPermissionSetDbStatus/{status} | 
[**v3_admin_system_settings_api_update_aws_account_password_policy**](AdminApi.md#v3_admin_system_settings_api_update_aws_account_password_policy) | **POST** /v3/admin/systemSettings/awsAccountPasswordPolicy | 
[**v3_admin_system_settings_api_update_aws_account_security_hub_initialized**](AdminApi.md#v3_admin_system_settings_api_update_aws_account_security_hub_initialized) | **POST** /v3/admin/systemSettings/awsAccountSecurityHubInitializedRegions | 
[**v3_admin_system_settings_api_update_aws_account_security_setting**](AdminApi.md#v3_admin_system_settings_api_update_aws_account_security_setting) | **PUT** /v3/admin/systemSettings/awsAccountSecuritySettings/{id} | 


# **get_vpn_config**
> VpnConfig get_vpn_config()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.vpn_config import VpnConfig
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.get_vpn_config()
        print("The response of AdminApi->get_vpn_config:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->get_vpn_config: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**VpnConfig**](VpnConfig.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_add_acm_certificate**
> v3_admin_system_settings_api_add_acm_certificate(certificate_request=certificate_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.certificate_request import CertificateRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    certificate_request = duplocloud_sdk.CertificateRequest() # CertificateRequest |  (optional)

    try:
        api_instance.v3_admin_system_settings_api_add_acm_certificate(certificate_request=certificate_request)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_add_acm_certificate: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **certificate_request** | [**CertificateRequest**](CertificateRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_add_api_permission_set**
> DuploApiPermissionSet v3_admin_system_settings_api_add_api_permission_set(duplo_api_permission_set=duplo_api_permission_set)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.duplo_api_permission_set import DuploApiPermissionSet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    duplo_api_permission_set = duplocloud_sdk.DuploApiPermissionSet() # DuploApiPermissionSet |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_add_api_permission_set(duplo_api_permission_set=duplo_api_permission_set)
        print("The response of AdminApi->v3_admin_system_settings_api_add_api_permission_set:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_add_api_permission_set: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duplo_api_permission_set** | [**DuploApiPermissionSet**](DuploApiPermissionSet.md)|  | [optional] 

### Return type

[**DuploApiPermissionSet**](DuploApiPermissionSet.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_add_aws_account_security_setting**
> CustomDataEx v3_admin_system_settings_api_add_aws_account_security_setting(custom_data_ex=custom_data_ex)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.custom_data_ex import CustomDataEx
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    custom_data_ex = duplocloud_sdk.CustomDataEx() # CustomDataEx |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_add_aws_account_security_setting(custom_data_ex=custom_data_ex)
        print("The response of AdminApi->v3_admin_system_settings_api_add_aws_account_security_setting:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_add_aws_account_security_setting: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **custom_data_ex** | [**CustomDataEx**](CustomDataEx.md)|  | [optional] 

### Return type

[**CustomDataEx**](CustomDataEx.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_add_system_setting**
> CustomDataEx v3_admin_system_settings_api_add_system_setting(custom_data_ex=custom_data_ex)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.custom_data_ex import CustomDataEx
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    custom_data_ex = duplocloud_sdk.CustomDataEx() # CustomDataEx |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_add_system_setting(custom_data_ex=custom_data_ex)
        print("The response of AdminApi->v3_admin_system_settings_api_add_system_setting:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_add_system_setting: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **custom_data_ex** | [**CustomDataEx**](CustomDataEx.md)|  | [optional] 

### Return type

[**CustomDataEx**](CustomDataEx.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_aws_account_security**
> AwsAccountSecurity v3_admin_system_settings_api_aws_account_security()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.aws_account_security import AwsAccountSecurity
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_aws_account_security()
        print("The response of AdminApi->v3_admin_system_settings_api_aws_account_security:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_aws_account_security: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**AwsAccountSecurity**](AwsAccountSecurity.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_aws_account_security_features**
> AwsAccountSecurityFeatures v3_admin_system_settings_api_aws_account_security_features(aws_account_security_features=aws_account_security_features)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.aws_account_security_features import AwsAccountSecurityFeatures
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    aws_account_security_features = duplocloud_sdk.AwsAccountSecurityFeatures() # AwsAccountSecurityFeatures |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_aws_account_security_features(aws_account_security_features=aws_account_security_features)
        print("The response of AdminApi->v3_admin_system_settings_api_aws_account_security_features:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_aws_account_security_features: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **aws_account_security_features** | [**AwsAccountSecurityFeatures**](AwsAccountSecurityFeatures.md)|  | [optional] 

### Return type

[**AwsAccountSecurityFeatures**](AwsAccountSecurityFeatures.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_aws_account_security_settings**
> v3_admin_system_settings_api_aws_account_security_settings(id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    id = 'id_example' # str | 

    try:
        api_instance.v3_admin_system_settings_api_aws_account_security_settings(id)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_aws_account_security_settings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_delete_system_setting**
> v3_admin_system_settings_api_delete_system_setting(id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    id = 'id_example' # str | 

    try:
        api_instance.v3_admin_system_settings_api_delete_system_setting(id)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_delete_system_setting: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_gcp_account_security**
> GcpAccountSecurity v3_admin_system_settings_api_gcp_account_security()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.gcp_account_security import GcpAccountSecurity
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_gcp_account_security()
        print("The response of AdminApi->v3_admin_system_settings_api_gcp_account_security:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_gcp_account_security: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**GcpAccountSecurity**](GcpAccountSecurity.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_gcp_account_security2**
> GcpAccountSecurityFeatures v3_admin_system_settings_api_gcp_account_security2(account_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.gcp_account_security_features import GcpAccountSecurityFeatures
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    account_id = 'account_id_example' # str | 

    try:
        api_response = api_instance.v3_admin_system_settings_api_gcp_account_security2(account_id)
        print("The response of AdminApi->v3_admin_system_settings_api_gcp_account_security2:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_gcp_account_security2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 

### Return type

[**GcpAccountSecurityFeatures**](GcpAccountSecurityFeatures.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_gcp_account_security_features**
> GcpAccountSecurityFeatures v3_admin_system_settings_api_gcp_account_security_features(account_id, gcp_account_security_features=gcp_account_security_features)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.gcp_account_security_features import GcpAccountSecurityFeatures
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    account_id = 'account_id_example' # str | 
    gcp_account_security_features = duplocloud_sdk.GcpAccountSecurityFeatures() # GcpAccountSecurityFeatures |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_gcp_account_security_features(account_id, gcp_account_security_features=gcp_account_security_features)
        print("The response of AdminApi->v3_admin_system_settings_api_gcp_account_security_features:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_gcp_account_security_features: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **account_id** | **str**|  | 
 **gcp_account_security_features** | [**GcpAccountSecurityFeatures**](GcpAccountSecurityFeatures.md)|  | [optional] 

### Return type

[**GcpAccountSecurityFeatures**](GcpAccountSecurityFeatures.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_acm_certificates**
> List[AcmCertificateDetails] v3_admin_system_settings_api_get_acm_certificates(region)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.acm_certificate_details import AcmCertificateDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    region = 'region_example' # str | 

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_acm_certificates(region)
        print("The response of AdminApi->v3_admin_system_settings_api_get_acm_certificates:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_acm_certificates: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **region** | **str**|  | 

### Return type

[**List[AcmCertificateDetails]**](AcmCertificateDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_api_permission_set**
> DuploApiPermissionSet v3_admin_system_settings_api_get_api_permission_set(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.duplo_api_permission_set import DuploApiPermissionSet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    name = 'name_example' # str | 

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_api_permission_set(name)
        print("The response of AdminApi->v3_admin_system_settings_api_get_api_permission_set:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_api_permission_set: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

[**DuploApiPermissionSet**](DuploApiPermissionSet.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_api_permission_set_db**
> DuploApiPermissionSetDB v3_admin_system_settings_api_get_api_permission_set_db()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.duplo_api_permission_set_db import DuploApiPermissionSetDB
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_api_permission_set_db()
        print("The response of AdminApi->v3_admin_system_settings_api_get_api_permission_set_db:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_api_permission_set_db: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**DuploApiPermissionSetDB**](DuploApiPermissionSetDB.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_permission_set_list**
> List[PermissionSetRow] v3_admin_system_settings_api_get_permission_set_list()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.permission_set_row import PermissionSetRow
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_permission_set_list()
        print("The response of AdminApi->v3_admin_system_settings_api_get_permission_set_list:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_permission_set_list: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[PermissionSetRow]**](PermissionSetRow.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_permission_set_swagger**
> bytearray v3_admin_system_settings_api_get_permission_set_swagger()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_permission_set_swagger()
        print("The response of AdminApi->v3_admin_system_settings_api_get_permission_set_swagger:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_permission_set_swagger: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**bytearray**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/octet-stream

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_system_setting**
> CustomDataEx v3_admin_system_settings_api_get_system_setting(id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.custom_data_ex import CustomDataEx
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    id = 'id_example' # str | 

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_system_setting(id)
        print("The response of AdminApi->v3_admin_system_settings_api_get_system_setting:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_system_setting: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 

### Return type

[**CustomDataEx**](CustomDataEx.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_get_system_settings**
> List[CustomDataEx] v3_admin_system_settings_api_get_system_settings()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.custom_data_ex import CustomDataEx
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)

    try:
        api_response = api_instance.v3_admin_system_settings_api_get_system_settings()
        print("The response of AdminApi->v3_admin_system_settings_api_get_system_settings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_get_system_settings: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

[**List[CustomDataEx]**](CustomDataEx.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_remove_api_permission_set**
> v3_admin_system_settings_api_remove_api_permission_set(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    name = 'name_example' # str | 

    try:
        api_instance.v3_admin_system_settings_api_remove_api_permission_set(name)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_remove_api_permission_set: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_test_permission_set_for_user_api**
> DuploPermissionEffectResult v3_admin_system_settings_api_test_permission_set_for_user_api(api_permission_set_access_request=api_permission_set_access_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.api_permission_set_access_request import ApiPermissionSetAccessRequest
from duplocloud_sdk.models.duplo_permission_effect_result import DuploPermissionEffectResult
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    api_permission_set_access_request = duplocloud_sdk.ApiPermissionSetAccessRequest() # ApiPermissionSetAccessRequest |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_test_permission_set_for_user_api(api_permission_set_access_request=api_permission_set_access_request)
        print("The response of AdminApi->v3_admin_system_settings_api_test_permission_set_for_user_api:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_test_permission_set_for_user_api: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **api_permission_set_access_request** | [**ApiPermissionSetAccessRequest**](ApiPermissionSetAccessRequest.md)|  | [optional] 

### Return type

[**DuploPermissionEffectResult**](DuploPermissionEffectResult.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_update_api_permission_set**
> DuploApiPermissionSet v3_admin_system_settings_api_update_api_permission_set(duplo_api_permission_set=duplo_api_permission_set)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.duplo_api_permission_set import DuploApiPermissionSet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    duplo_api_permission_set = duplocloud_sdk.DuploApiPermissionSet() # DuploApiPermissionSet |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_update_api_permission_set(duplo_api_permission_set=duplo_api_permission_set)
        print("The response of AdminApi->v3_admin_system_settings_api_update_api_permission_set:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_update_api_permission_set: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **duplo_api_permission_set** | [**DuploApiPermissionSet**](DuploApiPermissionSet.md)|  | [optional] 

### Return type

[**DuploApiPermissionSet**](DuploApiPermissionSet.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_update_api_permission_set_db_status**
> v3_admin_system_settings_api_update_api_permission_set_db_status(status)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    status = True # bool | 

    try:
        api_instance.v3_admin_system_settings_api_update_api_permission_set_db_status(status)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_update_api_permission_set_db_status: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **status** | **bool**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_update_aws_account_password_policy**
> PasswordPolicy v3_admin_system_settings_api_update_aws_account_password_policy(password_policy=password_policy)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.password_policy import PasswordPolicy
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    password_policy = duplocloud_sdk.PasswordPolicy() # PasswordPolicy |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_update_aws_account_password_policy(password_policy=password_policy)
        print("The response of AdminApi->v3_admin_system_settings_api_update_aws_account_password_policy:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_update_aws_account_password_policy: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **password_policy** | [**PasswordPolicy**](PasswordPolicy.md)|  | [optional] 

### Return type

[**PasswordPolicy**](PasswordPolicy.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_update_aws_account_security_hub_initialized**
> List[str] v3_admin_system_settings_api_update_aws_account_security_hub_initialized(request_body=request_body)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    request_body = ['request_body_example'] # List[str] |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_update_aws_account_security_hub_initialized(request_body=request_body)
        print("The response of AdminApi->v3_admin_system_settings_api_update_aws_account_security_hub_initialized:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_update_aws_account_security_hub_initialized: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **request_body** | [**List[str]**](str.md)|  | [optional] 

### Return type

**List[str]**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_system_settings_api_update_aws_account_security_setting**
> CustomDataEx v3_admin_system_settings_api_update_aws_account_security_setting(id, custom_data_ex=custom_data_ex)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.custom_data_ex import CustomDataEx
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminApi(api_client)
    id = 'id_example' # str | 
    custom_data_ex = duplocloud_sdk.CustomDataEx() # CustomDataEx |  (optional)

    try:
        api_response = api_instance.v3_admin_system_settings_api_update_aws_account_security_setting(id, custom_data_ex=custom_data_ex)
        print("The response of AdminApi->v3_admin_system_settings_api_update_aws_account_security_setting:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminApi->v3_admin_system_settings_api_update_aws_account_security_setting: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **str**|  | 
 **custom_data_ex** | [**CustomDataEx**](CustomDataEx.md)|  | [optional] 

### Return type

[**CustomDataEx**](CustomDataEx.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

