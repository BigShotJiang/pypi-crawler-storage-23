# AwsVersionConsistency


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_version_consistency import AwsVersionConsistency

# TODO update the JSON string below
json = "{}"
# create an instance of AwsVersionConsistency from a JSON string
aws_version_consistency_instance = AwsVersionConsistency.from_json(json)
# print the JSON string representation of the object
print(AwsVersionConsistency.to_json())

# convert the object into a dict
aws_version_consistency_dict = aws_version_consistency_instance.to_dict()
# create an instance of AwsVersionConsistency from a dict
aws_version_consistency_from_dict = AwsVersionConsistency.from_dict(aws_version_consistency_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


