# AzureContainerGroupIdentityUserAssignedIdentitiesValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** | Gets the principal id of user assigned identity. | [optional] 
**client_id** | **str** | Gets the client id of user assigned identity. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group_identity_user_assigned_identities_value import AzureContainerGroupIdentityUserAssignedIdentitiesValue

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroupIdentityUserAssignedIdentitiesValue from a JSON string
azure_container_group_identity_user_assigned_identities_value_instance = AzureContainerGroupIdentityUserAssignedIdentitiesValue.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroupIdentityUserAssignedIdentitiesValue.to_json())

# convert the object into a dict
azure_container_group_identity_user_assigned_identities_value_dict = azure_container_group_identity_user_assigned_identities_value_instance.to_dict()
# create an instance of AzureContainerGroupIdentityUserAssignedIdentitiesValue from a dict
azure_container_group_identity_user_assigned_identities_value_from_dict = AzureContainerGroupIdentityUserAssignedIdentitiesValue.from_dict(azure_container_group_identity_user_assigned_identities_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


