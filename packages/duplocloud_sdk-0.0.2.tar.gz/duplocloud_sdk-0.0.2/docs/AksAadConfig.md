# AksAadConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_azure_rbac_enabled** | **bool** |  | [optional] 
**is_managed_aad_enabled** | **bool** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**admin_group_object_ids** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aks_aad_config import AksAadConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AksAadConfig from a JSON string
aks_aad_config_instance = AksAadConfig.from_json(json)
# print the JSON string representation of the object
print(AksAadConfig.to_json())

# convert the object into a dict
aks_aad_config_dict = aks_aad_config_instance.to_dict()
# create an instance of AksAadConfig from a dict
aks_aad_config_from_dict = AksAadConfig.from_dict(aks_aad_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


