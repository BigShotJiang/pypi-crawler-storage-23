# AzureContainerPropertiesInstanceView

The instance view of the container instance. Only valid in response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restart_count** | **int** | Gets the number of times that the container instance has been restarted. | [optional] 
**current_state** | [**AzureContainerState**](AzureContainerState.md) | Gets current container instance state. | [optional] 
**previous_state** | [**AzureContainerState**](AzureContainerState.md) | Gets previous container instance state. | [optional] 
**events** | [**List[AzureEventModel]**](AzureEventModel.md) | Gets the events of the container instance. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_properties_instance_view import AzureContainerPropertiesInstanceView

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerPropertiesInstanceView from a JSON string
azure_container_properties_instance_view_instance = AzureContainerPropertiesInstanceView.from_json(json)
# print the JSON string representation of the object
print(AzureContainerPropertiesInstanceView.to_json())

# convert the object into a dict
azure_container_properties_instance_view_dict = azure_container_properties_instance_view_instance.to_dict()
# create an instance of AzureContainerPropertiesInstanceView from a dict
azure_container_properties_instance_view_from_dict = AzureContainerPropertiesInstanceView.from_dict(azure_container_properties_instance_view_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


