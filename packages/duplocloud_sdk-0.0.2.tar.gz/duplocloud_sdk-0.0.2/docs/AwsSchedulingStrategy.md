# AwsSchedulingStrategy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_scheduling_strategy import AwsSchedulingStrategy

# TODO update the JSON string below
json = "{}"
# create an instance of AwsSchedulingStrategy from a JSON string
aws_scheduling_strategy_instance = AwsSchedulingStrategy.from_json(json)
# print the JSON string representation of the object
print(AwsSchedulingStrategy.to_json())

# convert the object into a dict
aws_scheduling_strategy_dict = aws_scheduling_strategy_instance.to_dict()
# create an instance of AwsSchedulingStrategy from a dict
aws_scheduling_strategy_from_dict = AwsSchedulingStrategy.from_dict(aws_scheduling_strategy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


