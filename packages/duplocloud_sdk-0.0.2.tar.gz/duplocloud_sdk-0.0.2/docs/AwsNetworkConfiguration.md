# AwsNetworkConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**awsvpc_configuration** | [**AwsAwsVpcConfiguration**](AwsAwsVpcConfiguration.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_network_configuration import AwsNetworkConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsNetworkConfiguration from a JSON string
aws_network_configuration_instance = AwsNetworkConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsNetworkConfiguration.to_json())

# convert the object into a dict
aws_network_configuration_dict = aws_network_configuration_instance.to_dict()
# create an instance of AwsNetworkConfiguration from a dict
aws_network_configuration_from_dict = AwsNetworkConfiguration.from_dict(aws_network_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


