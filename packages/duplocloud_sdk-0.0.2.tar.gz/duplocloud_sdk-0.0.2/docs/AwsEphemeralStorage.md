# AwsEphemeralStorage


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**size_in_gi_b** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ephemeral_storage import AwsEphemeralStorage

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEphemeralStorage from a JSON string
aws_ephemeral_storage_instance = AwsEphemeralStorage.from_json(json)
# print the JSON string representation of the object
print(AwsEphemeralStorage.to_json())

# convert the object into a dict
aws_ephemeral_storage_dict = aws_ephemeral_storage_instance.to_dict()
# create an instance of AwsEphemeralStorage from a dict
aws_ephemeral_storage_from_dict = AwsEphemeralStorage.from_dict(aws_ephemeral_storage_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


