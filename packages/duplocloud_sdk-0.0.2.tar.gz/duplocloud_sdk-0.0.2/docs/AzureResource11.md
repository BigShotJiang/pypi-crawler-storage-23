# AzureResource11

The Resource model definition.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets resource Id | [optional] 
**name** | **str** | Gets resource name | [optional] 
**type** | **str** | Gets resource type | [optional] 
**location** | **str** | Gets or sets resource location | [optional] 
**tags** | **Dict[str, str]** | Gets or sets resource tags | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource11 import AzureResource11

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource11 from a JSON string
azure_resource11_instance = AzureResource11.from_json(json)
# print the JSON string representation of the object
print(AzureResource11.to_json())

# convert the object into a dict
azure_resource11_dict = azure_resource11_instance.to_dict()
# create an instance of AzureResource11 from a dict
azure_resource11_from_dict = AzureResource11.from_dict(azure_resource11_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


