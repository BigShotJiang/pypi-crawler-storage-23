# AzureHostingEnvironmentStatus



## Enum

* `Preparing` (value: `'Preparing'`)

* `Ready` (value: `'Ready'`)

* `Scaling` (value: `'Scaling'`)

* `Deleting` (value: `'Deleting'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


