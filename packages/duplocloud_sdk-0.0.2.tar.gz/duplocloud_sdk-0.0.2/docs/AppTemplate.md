# AppTemplate


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**contents** | **str** |  | [optional] 
**owner** | **str** |  | [optional] 
**author** | **str** |  | [optional] 
**is_private** | **bool** |  | [optional] 
**status** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.app_template import AppTemplate

# TODO update the JSON string below
json = "{}"
# create an instance of AppTemplate from a JSON string
app_template_instance = AppTemplate.from_json(json)
# print the JSON string representation of the object
print(AppTemplate.to_json())

# convert the object into a dict
app_template_dict = app_template_instance.to_dict()
# create an instance of AppTemplate from a dict
app_template_from_dict = AppTemplate.from_dict(app_template_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


