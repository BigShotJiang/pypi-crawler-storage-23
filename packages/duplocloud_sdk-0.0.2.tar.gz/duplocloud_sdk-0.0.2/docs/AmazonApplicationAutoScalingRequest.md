# AmazonApplicationAutoScalingRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_application_auto_scaling_request import AmazonApplicationAutoScalingRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonApplicationAutoScalingRequest from a JSON string
amazon_application_auto_scaling_request_instance = AmazonApplicationAutoScalingRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonApplicationAutoScalingRequest.to_json())

# convert the object into a dict
amazon_application_auto_scaling_request_dict = amazon_application_auto_scaling_request_instance.to_dict()
# create an instance of AmazonApplicationAutoScalingRequest from a dict
amazon_application_auto_scaling_request_from_dict = AmazonApplicationAutoScalingRequest.from_dict(amazon_application_auto_scaling_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


