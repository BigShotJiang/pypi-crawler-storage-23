# AzureEncryptionProperties

The container group encryption properties.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vault_base_url** | **str** | Gets or sets the keyvault base url. | [optional] 
**key_name** | **str** | Gets or sets the encryption key name. | [optional] 
**key_version** | **str** | Gets or sets the encryption key version. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_encryption_properties import AzureEncryptionProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureEncryptionProperties from a JSON string
azure_encryption_properties_instance = AzureEncryptionProperties.from_json(json)
# print the JSON string representation of the object
print(AzureEncryptionProperties.to_json())

# convert the object into a dict
azure_encryption_properties_dict = azure_encryption_properties_instance.to_dict()
# create an instance of AzureEncryptionProperties from a dict
azure_encryption_properties_from_dict = AzureEncryptionProperties.from_dict(azure_encryption_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


