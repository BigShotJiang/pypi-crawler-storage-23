# AwsDevice


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_path** | **str** |  | [optional] 
**host_path** | **str** |  | [optional] 
**permissions** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_device import AwsDevice

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDevice from a JSON string
aws_device_instance = AwsDevice.from_json(json)
# print the JSON string representation of the object
print(AwsDevice.to_json())

# convert the object into a dict
aws_device_dict = aws_device_instance.to_dict()
# create an instance of AwsDevice from a dict
aws_device_from_dict = AwsDevice.from_dict(aws_device_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


