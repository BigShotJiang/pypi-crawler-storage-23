# AzureApplicationGatewayFirewallExclusion


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**match_variable** | **str** |  | [optional] 
**selector_match_operator** | **str** |  | [optional] 
**selector** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_firewall_exclusion import AzureApplicationGatewayFirewallExclusion

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayFirewallExclusion from a JSON string
azure_application_gateway_firewall_exclusion_instance = AzureApplicationGatewayFirewallExclusion.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayFirewallExclusion.to_json())

# convert the object into a dict
azure_application_gateway_firewall_exclusion_dict = azure_application_gateway_firewall_exclusion_instance.to_dict()
# create an instance of AzureApplicationGatewayFirewallExclusion from a dict
azure_application_gateway_firewall_exclusion_from_dict = AzureApplicationGatewayFirewallExclusion.from_dict(azure_application_gateway_firewall_exclusion_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


