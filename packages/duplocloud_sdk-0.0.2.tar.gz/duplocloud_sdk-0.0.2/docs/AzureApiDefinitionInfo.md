# AzureApiDefinitionInfo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**url** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_api_definition_info import AzureApiDefinitionInfo

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApiDefinitionInfo from a JSON string
azure_api_definition_info_instance = AzureApiDefinitionInfo.from_json(json)
# print the JSON string representation of the object
print(AzureApiDefinitionInfo.to_json())

# convert the object into a dict
azure_api_definition_info_dict = azure_api_definition_info_instance.to_dict()
# create an instance of AzureApiDefinitionInfo from a dict
azure_api_definition_info_from_dict = AzureApiDefinitionInfo.from_dict(azure_api_definition_info_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


