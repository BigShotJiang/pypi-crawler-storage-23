# AzureCloudBlobContainer


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**service_client** | [**AzureCloudBlobClient**](AzureCloudBlobClient.md) |  | [optional] 
**uri** | **str** |  | [optional] 
**storage_uri** | [**AzureStorageUri**](AzureStorageUri.md) |  | [optional] 
**name** | **str** |  | [optional] 
**metadata** | **Dict[str, str]** |  | [optional] 
**properties** | [**AzureBlobContainerProperties**](AzureBlobContainerProperties.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_cloud_blob_container import AzureCloudBlobContainer

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCloudBlobContainer from a JSON string
azure_cloud_blob_container_instance = AzureCloudBlobContainer.from_json(json)
# print the JSON string representation of the object
print(AzureCloudBlobContainer.to_json())

# convert the object into a dict
azure_cloud_blob_container_dict = azure_cloud_blob_container_instance.to_dict()
# create an instance of AzureCloudBlobContainer from a dict
azure_cloud_blob_container_from_dict = AzureCloudBlobContainer.from_dict(azure_cloud_blob_container_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


