# duplocloud_sdk.AdminInfrastructureVPCPeerSubnetsApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v3_admin_infrastructure_api_add_subnets_to_route_table**](AdminInfrastructureVPCPeerSubnetsApi.md#v3_admin_infrastructure_api_add_subnets_to_route_table) | **POST** /v3/admin/infrastructure/{name}/vpcPeeringSubnets | 
[**v3_admin_infrastructure_api_delete_subnets_from_route_table**](AdminInfrastructureVPCPeerSubnetsApi.md#v3_admin_infrastructure_api_delete_subnets_from_route_table) | **POST** /v3/admin/infrastructure/{name}/vpcPeeringSubnets/delete | 
[**v3_admin_infrastructure_api_get_routable_subnets**](AdminInfrastructureVPCPeerSubnetsApi.md#v3_admin_infrastructure_api_get_routable_subnets) | **GET** /v3/admin/infrastructure/{name}/vpcPeeringSubnets | 


# **v3_admin_infrastructure_api_add_subnets_to_route_table**
> List[PeerSubnet] v3_admin_infrastructure_api_add_subnets_to_route_table(name, peer_subnet=peer_subnet)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.peer_subnet import PeerSubnet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeerSubnetsApi(api_client)
    name = 'name_example' # str | 
    peer_subnet = [duplocloud_sdk.PeerSubnet()] # List[PeerSubnet] |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_add_subnets_to_route_table(name, peer_subnet=peer_subnet)
        print("The response of AdminInfrastructureVPCPeerSubnetsApi->v3_admin_infrastructure_api_add_subnets_to_route_table:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeerSubnetsApi->v3_admin_infrastructure_api_add_subnets_to_route_table: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **peer_subnet** | [**List[PeerSubnet]**](PeerSubnet.md)|  | [optional] 

### Return type

[**List[PeerSubnet]**](PeerSubnet.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_delete_subnets_from_route_table**
> v3_admin_infrastructure_api_delete_subnets_from_route_table(name, peer_subnet=peer_subnet)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.peer_subnet import PeerSubnet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeerSubnetsApi(api_client)
    name = 'name_example' # str | 
    peer_subnet = [duplocloud_sdk.PeerSubnet()] # List[PeerSubnet] |  (optional)

    try:
        api_instance.v3_admin_infrastructure_api_delete_subnets_from_route_table(name, peer_subnet=peer_subnet)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeerSubnetsApi->v3_admin_infrastructure_api_delete_subnets_from_route_table: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **peer_subnet** | [**List[PeerSubnet]**](PeerSubnet.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_routable_subnets**
> List[PeerSubnet] v3_admin_infrastructure_api_get_routable_subnets(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.peer_subnet import PeerSubnet
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeerSubnetsApi(api_client)
    name = 'name_example' # str | 

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_routable_subnets(name)
        print("The response of AdminInfrastructureVPCPeerSubnetsApi->v3_admin_infrastructure_api_get_routable_subnets:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeerSubnetsApi->v3_admin_infrastructure_api_get_routable_subnets: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

[**List[PeerSubnet]**](PeerSubnet.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

