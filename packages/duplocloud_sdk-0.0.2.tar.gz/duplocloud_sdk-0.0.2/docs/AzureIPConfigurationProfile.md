# AzureIPConfigurationProfile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_subnet** | [**AzureSubnet**](AzureSubnet.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_configuration_profile import AzureIPConfigurationProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIPConfigurationProfile from a JSON string
azure_ip_configuration_profile_instance = AzureIPConfigurationProfile.from_json(json)
# print the JSON string representation of the object
print(AzureIPConfigurationProfile.to_json())

# convert the object into a dict
azure_ip_configuration_profile_dict = azure_ip_configuration_profile_instance.to_dict()
# create an instance of AzureIPConfigurationProfile from a dict
azure_ip_configuration_profile_from_dict = AzureIPConfigurationProfile.from_dict(azure_ip_configuration_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


