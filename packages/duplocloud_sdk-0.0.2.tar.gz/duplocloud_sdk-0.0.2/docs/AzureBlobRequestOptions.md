# AzureBlobRequestOptions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**retry_policy** | **object** |  | [optional] 
**encryption_policy** | [**AzureBlobEncryptionPolicy**](AzureBlobEncryptionPolicy.md) |  | [optional] 
**require_encryption** | **bool** |  | [optional] 
**absorb_conditional_errors_on_retry** | **bool** |  | [optional] 
**location_mode** | [**AzureLocationMode**](AzureLocationMode.md) |  | [optional] 
**server_timeout** | **str** |  | [optional] 
**maximum_execution_time** | **str** |  | [optional] 
**parallel_operation_thread_count** | **int** |  | [optional] 
**single_blob_upload_threshold_in_bytes** | **int** |  | [optional] 
**use_transactional_md5** | **bool** |  | [optional] 
**store_blob_content_md5** | **bool** |  | [optional] 
**disable_content_md5_validation** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_blob_request_options import AzureBlobRequestOptions

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBlobRequestOptions from a JSON string
azure_blob_request_options_instance = AzureBlobRequestOptions.from_json(json)
# print the JSON string representation of the object
print(AzureBlobRequestOptions.to_json())

# convert the object into a dict
azure_blob_request_options_dict = azure_blob_request_options_instance.to_dict()
# create an instance of AzureBlobRequestOptions from a dict
azure_blob_request_options_from_dict = AzureBlobRequestOptions.from_dict(azure_blob_request_options_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


