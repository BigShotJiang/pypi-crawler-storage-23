# AzureConnStringInfo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**connection_string** | **str** |  | [optional] 
**type** | [**AzureConnectionStringType**](AzureConnectionStringType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_conn_string_info import AzureConnStringInfo

# TODO update the JSON string below
json = "{}"
# create an instance of AzureConnStringInfo from a JSON string
azure_conn_string_info_instance = AzureConnStringInfo.from_json(json)
# print the JSON string representation of the object
print(AzureConnStringInfo.to_json())

# convert the object into a dict
azure_conn_string_info_dict = azure_conn_string_info_instance.to_dict()
# create an instance of AzureConnStringInfo from a dict
azure_conn_string_info_from_dict = AzureConnStringInfo.from_dict(azure_conn_string_info_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


