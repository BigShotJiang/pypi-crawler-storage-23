# AwsEFSTransitEncryption


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_efs_transit_encryption import AwsEFSTransitEncryption

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEFSTransitEncryption from a JSON string
aws_efs_transit_encryption_instance = AwsEFSTransitEncryption.from_json(json)
# print the JSON string representation of the object
print(AwsEFSTransitEncryption.to_json())

# convert the object into a dict
aws_efs_transit_encryption_dict = aws_efs_transit_encryption_instance.to_dict()
# create an instance of AwsEFSTransitEncryption from a dict
aws_efs_transit_encryption_from_dict = AwsEFSTransitEncryption.from_dict(aws_efs_transit_encryption_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


