# AzurePrivateEndpointConnection


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_private_endpoint** | [**AzurePrivateEndpoint**](AzurePrivateEndpoint.md) |  | [optional] 
**properties_private_link_service_connection_state** | [**AzurePrivateLinkServiceConnectionState**](AzurePrivateLinkServiceConnectionState.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_link_identifier** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_connection import AzurePrivateEndpointConnection

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointConnection from a JSON string
azure_private_endpoint_connection_instance = AzurePrivateEndpointConnection.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointConnection.to_json())

# convert the object into a dict
azure_private_endpoint_connection_dict = azure_private_endpoint_connection_instance.to_dict()
# create an instance of AzurePrivateEndpointConnection from a dict
azure_private_endpoint_connection_from_dict = AzurePrivateEndpointConnection.from_dict(azure_private_endpoint_connection_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


