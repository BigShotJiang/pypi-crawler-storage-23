# AzureResource9


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource9 import AzureResource9

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource9 from a JSON string
azure_resource9_instance = AzureResource9.from_json(json)
# print the JSON string representation of the object
print(AzureResource9.to_json())

# convert the object into a dict
azure_resource9_dict = azure_resource9_instance.to_dict()
# create an instance of AzureResource9 from a dict
azure_resource9_from_dict = AzureResource9.from_dict(azure_resource9_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


