# AzureProxyResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_proxy_resource import AzureProxyResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProxyResource from a JSON string
azure_proxy_resource_instance = AzureProxyResource.from_json(json)
# print the JSON string representation of the object
print(AzureProxyResource.to_json())

# convert the object into a dict
azure_proxy_resource_dict = azure_proxy_resource_instance.to_dict()
# create an instance of AzureProxyResource from a dict
azure_proxy_resource_from_dict = AzureProxyResource.from_dict(azure_proxy_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


