# AzureAutomaticOSUpgradePolicy

The configuration parameters used for performing automatic OS upgrade.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enable_automatic_os_upgrade** | **bool** | Gets or sets indicates whether OS upgrades should automatically be applied to scale set instances in a rolling fashion when a newer version of the OS image becomes available. Default value is false. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; If this is set to true for Windows based scale sets, [enableAutomaticUpdates](https://docs.microsoft.com/dotnet/api/microsoft.azure.management.compute.models.windowsconfiguration.enableautomaticupdates?view&#x3D;azure-dotnet) is automatically set to false and cannot be set to true. | [optional] 
**disable_automatic_rollback** | **bool** | Gets or sets whether OS image rollback feature should be disabled. Default value is false. | [optional] 
**use_rolling_upgrade_policy** | **bool** | Gets or sets indicates whether rolling upgrade policy should be used during Auto OS Upgrade. Default value is false. Auto OS Upgrade will fallback to the default policy if no policy is defined on the VMSS. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_automatic_os_upgrade_policy import AzureAutomaticOSUpgradePolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutomaticOSUpgradePolicy from a JSON string
azure_automatic_os_upgrade_policy_instance = AzureAutomaticOSUpgradePolicy.from_json(json)
# print the JSON string representation of the object
print(AzureAutomaticOSUpgradePolicy.to_json())

# convert the object into a dict
azure_automatic_os_upgrade_policy_dict = azure_automatic_os_upgrade_policy_instance.to_dict()
# create an instance of AzureAutomaticOSUpgradePolicy from a dict
azure_automatic_os_upgrade_policy_from_dict = AzureAutomaticOSUpgradePolicy.from_dict(azure_automatic_os_upgrade_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


