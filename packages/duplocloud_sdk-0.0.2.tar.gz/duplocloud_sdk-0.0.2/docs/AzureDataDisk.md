# AzureDataDisk

Describes a data disk.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**lun** | **int** | Gets or sets specifies the logical unit number of the data disk. This value is used to identify data disks within the VM and therefore must be unique for each data disk attached to a VM. | [optional] 
**name** | **str** | Gets or sets the disk name. | [optional] 
**vhd** | [**AzureVirtualHardDisk**](AzureVirtualHardDisk.md) | Gets or sets the virtual hard disk. | [optional] 
**image** | [**AzureVirtualHardDisk**](AzureVirtualHardDisk.md) | Gets or sets the source user image virtual hard disk. The virtual hard disk will be copied before being attached to the virtual machine. If SourceImage is provided, the destination virtual hard drive must not exist. | [optional] 
**caching** | [**AzureCachingTypes**](AzureCachingTypes.md) | Gets or sets specifies the caching requirements. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **None** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **ReadOnly** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **ReadWrite** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Default: **None for Standard storage. ReadOnly for Premium storage**. Possible values include: &#39;None&#39;, &#39;ReadOnly&#39;, &#39;ReadWrite&#39; | [optional] 
**write_accelerator_enabled** | **bool** | Gets or sets specifies whether writeAccelerator should be enabled or disabled on the disk. | [optional] 
**create_option** | **str** | Gets or sets specifies how the virtual machine should be created.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are:&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Attach** \\u2013 This value is used when you are using a specialized disk to create the virtual machine.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **FromImage** \\u2013 This value is used when you are using an image to create the virtual machine. If you are using a platform image, you also use the imageReference element described above. If you are using a marketplace image, you  also use the plan element previously described. Possible values include: &#39;FromImage&#39;, &#39;Empty&#39;, &#39;Attach&#39; | [optional] 
**disk_size_gb** | **int** | Gets or sets specifies the size of an empty data disk in gigabytes. This element can be used to overwrite the size of the disk in a virtual machine image. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; diskSizeGB is the number of bytes x 1024^3 for the disk and the value cannot be larger than 1023 | [optional] 
**managed_disk** | [**AzureManagedDiskParameters**](AzureManagedDiskParameters.md) | Gets or sets the managed disk parameters. | [optional] 
**to_be_detached** | **bool** | Gets or sets specifies whether the data disk is in process of detachment from the VirtualMachine/VirtualMachineScaleset | [optional] 
**disk_iops_read_write** | **int** | Gets specifies the Read-Write IOPS for the managed disk when StorageAccountType is UltraSSD_LRS. Returned only for VirtualMachine ScaleSet VM disks. Can be updated only via updates to the VirtualMachine Scale Set. | [optional] 
**disk_m_bps_read_write** | **int** | Gets specifies the bandwidth in MB per second for the managed disk when StorageAccountType is UltraSSD_LRS. Returned only for VirtualMachine ScaleSet VM disks. Can be updated only via updates to the VirtualMachine Scale Set. | [optional] 
**detach_option** | **str** | Gets or sets specifies the detach behavior to be used while detaching a disk or which is already in the process of detachment from the virtual machine. Supported values: **ForceDetach**. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; detachOption: **ForceDetach** is applicable only for managed data disks. If a previous detachment attempt of the data disk did not complete due to an unexpected failure from the virtual machine and the disk is still not released then use force-detach as a last resort option to detach the disk forcibly from the VM. All writes might not have been flushed when using this detach behavior. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; This feature is still in preview mode and is not supported for VirtualMachineScaleSet. To force-detach a data disk update toBeDetached to &#39;true&#39; along with setting detachOption: &#39;ForceDetach&#39;. Possible values include: &#39;ForceDetach&#39; | [optional] 
**delete_option** | **str** | Gets or sets specifies whether data disk should be deleted or detached upon VM deletion.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Delete** If this value is used, the data disk is deleted when VM is deleted.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **Detach** If this value is used, the data disk is retained after VM is deleted.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; The default value is set to **detach**. Possible values include: &#39;Delete&#39;, &#39;Detach&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_data_disk import AzureDataDisk

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDataDisk from a JSON string
azure_data_disk_instance = AzureDataDisk.from_json(json)
# print the JSON string representation of the object
print(AzureDataDisk.to_json())

# convert the object into a dict
azure_data_disk_dict = azure_data_disk_instance.to_dict()
# create an instance of AzureDataDisk from a dict
azure_data_disk_from_dict = AzureDataDisk.from_dict(azure_data_disk_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


