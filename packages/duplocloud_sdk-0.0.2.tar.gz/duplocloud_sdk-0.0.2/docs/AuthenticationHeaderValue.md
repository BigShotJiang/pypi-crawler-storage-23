# AuthenticationHeaderValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scheme** | **str** |  | [optional] 
**parameter** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.authentication_header_value import AuthenticationHeaderValue

# TODO update the JSON string below
json = "{}"
# create an instance of AuthenticationHeaderValue from a JSON string
authentication_header_value_instance = AuthenticationHeaderValue.from_json(json)
# print the JSON string representation of the object
print(AuthenticationHeaderValue.to_json())

# convert the object into a dict
authentication_header_value_dict = authentication_header_value_instance.to_dict()
# create an instance of AuthenticationHeaderValue from a dict
authentication_header_value_from_dict = AuthenticationHeaderValue.from_dict(authentication_header_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


