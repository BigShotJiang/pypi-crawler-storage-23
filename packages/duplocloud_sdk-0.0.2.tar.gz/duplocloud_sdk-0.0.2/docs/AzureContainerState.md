# AzureContainerState

The container instance state.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | **str** | Gets the state of the container instance. | [optional] 
**start_time** | **datetime** | Gets the date-time when the container instance state started. | [optional] 
**exit_code** | **int** | Gets the container instance exit codes correspond to those from the &#x60;docker run&#x60; command. | [optional] 
**finish_time** | **datetime** | Gets the date-time when the container instance state finished. | [optional] 
**detail_status** | **str** | Gets the human-readable status of the container instance state. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_state import AzureContainerState

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerState from a JSON string
azure_container_state_instance = AzureContainerState.from_json(json)
# print the JSON string representation of the object
print(AzureContainerState.to_json())

# convert the object into a dict
azure_container_state_dict = azure_container_state_instance.to_dict()
# create an instance of AzureContainerState from a dict
azure_container_state_from_dict = AzureContainerState.from_dict(azure_container_state_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


