# AzureLastPatchInstallationSummary

Describes the properties of the last installed patch summary.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Gets the overall success or failure status of the operation. It remains \&quot;InProgress\&quot; until the operation completes. At that point it will become \&quot;Unknown\&quot;, \&quot;Failed\&quot;, \&quot;Succeeded\&quot;, or \&quot;CompletedWithWarnings.\&quot;. Possible values include: &#39;Unknown&#39;, &#39;InProgress&#39;, &#39;Failed&#39;, &#39;Succeeded&#39;, &#39;CompletedWithWarnings&#39; | [optional] 
**installation_activity_id** | **str** | Gets the activity ID of the operation that produced this result. It is used to correlate across CRP and extension logs. | [optional] 
**maintenance_window_exceeded** | **bool** | Gets describes whether the operation ran out of time before it completed all its intended actions | [optional] 
**not_selected_patch_count** | **int** | Gets the number of all available patches but not going to be installed because it didn&#39;t match a classification or inclusion list entry. | [optional] 
**excluded_patch_count** | **int** | Gets the number of all available patches but excluded explicitly by a customer-specified exclusion list match. | [optional] 
**pending_patch_count** | **int** | Gets the number of all available patches expected to be installed over the course of the patch installation operation. | [optional] 
**installed_patch_count** | **int** | Gets the count of patches that successfully installed. | [optional] 
**failed_patch_count** | **int** | Gets the count of patches that failed installation. | [optional] 
**start_time** | **datetime** | Gets the UTC timestamp when the operation began. | [optional] 
**last_modified_time** | **datetime** | Gets the UTC timestamp when the operation began. | [optional] 
**error** | [**AzureApiError**](AzureApiError.md) | Gets the errors that were encountered during execution of the operation. The details array contains the list of them. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_last_patch_installation_summary import AzureLastPatchInstallationSummary

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLastPatchInstallationSummary from a JSON string
azure_last_patch_installation_summary_instance = AzureLastPatchInstallationSummary.from_json(json)
# print the JSON string representation of the object
print(AzureLastPatchInstallationSummary.to_json())

# convert the object into a dict
azure_last_patch_installation_summary_dict = azure_last_patch_installation_summary_instance.to_dict()
# create an instance of AzureLastPatchInstallationSummary from a dict
azure_last_patch_installation_summary_from_dict = AzureLastPatchInstallationSummary.from_dict(azure_last_patch_installation_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


