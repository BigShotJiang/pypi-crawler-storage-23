# AzureNetworkInterfaceDnsSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dns_servers** | **List[str]** |  | [optional] 
**applied_dns_servers** | **List[str]** |  | [optional] 
**internal_dns_name_label** | **str** |  | [optional] 
**internal_fqdn** | **str** |  | [optional] 
**internal_domain_name_suffix** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface_dns_settings import AzureNetworkInterfaceDnsSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterfaceDnsSettings from a JSON string
azure_network_interface_dns_settings_instance = AzureNetworkInterfaceDnsSettings.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterfaceDnsSettings.to_json())

# convert the object into a dict
azure_network_interface_dns_settings_dict = azure_network_interface_dns_settings_instance.to_dict()
# create an instance of AzureNetworkInterfaceDnsSettings from a dict
azure_network_interface_dns_settings_from_dict = AzureNetworkInterfaceDnsSettings.from_dict(azure_network_interface_dns_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


