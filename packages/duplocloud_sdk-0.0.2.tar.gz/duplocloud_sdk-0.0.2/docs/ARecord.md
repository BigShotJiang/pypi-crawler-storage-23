# ARecord


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**domain_id** | **str** |  | [optional] 
**dns_name** | **str** |  | [optional] 
**address** | **str** |  | [optional] 
**state** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.a_record import ARecord

# TODO update the JSON string below
json = "{}"
# create an instance of ARecord from a JSON string
a_record_instance = ARecord.from_json(json)
# print the JSON string representation of the object
print(ARecord.to_json())

# convert the object into a dict
a_record_dict = a_record_instance.to_dict()
# create an instance of ARecord from a dict
a_record_from_dict = ARecord.from_dict(a_record_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


