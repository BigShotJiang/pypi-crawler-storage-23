# AmazonElasticLoadBalancingV2Request


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_elastic_load_balancing_v2_request import AmazonElasticLoadBalancingV2Request

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonElasticLoadBalancingV2Request from a JSON string
amazon_elastic_load_balancing_v2_request_instance = AmazonElasticLoadBalancingV2Request.from_json(json)
# print the JSON string representation of the object
print(AmazonElasticLoadBalancingV2Request.to_json())

# convert the object into a dict
amazon_elastic_load_balancing_v2_request_dict = amazon_elastic_load_balancing_v2_request_instance.to_dict()
# create an instance of AmazonElasticLoadBalancingV2Request from a dict
amazon_elastic_load_balancing_v2_request_from_dict = AmazonElasticLoadBalancingV2Request.from_dict(amazon_elastic_load_balancing_v2_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


