# AmazonRDSRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_rds_request import AmazonRDSRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonRDSRequest from a JSON string
amazon_rds_request_instance = AmazonRDSRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonRDSRequest.to_json())

# convert the object into a dict
amazon_rds_request_dict = amazon_rds_request_instance.to_dict()
# create an instance of AmazonRDSRequest from a dict
amazon_rds_request_from_dict = AmazonRDSRequest.from_dict(amazon_rds_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


