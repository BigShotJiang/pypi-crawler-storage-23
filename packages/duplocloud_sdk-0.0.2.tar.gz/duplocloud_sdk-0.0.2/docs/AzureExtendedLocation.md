# AzureExtendedLocation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_extended_location import AzureExtendedLocation

# TODO update the JSON string below
json = "{}"
# create an instance of AzureExtendedLocation from a JSON string
azure_extended_location_instance = AzureExtendedLocation.from_json(json)
# print the JSON string representation of the object
print(AzureExtendedLocation.to_json())

# convert the object into a dict
azure_extended_location_dict = azure_extended_location_instance.to_dict()
# create an instance of AzureExtendedLocation from a dict
azure_extended_location_from_dict = AzureExtendedLocation.from_dict(azure_extended_location_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


