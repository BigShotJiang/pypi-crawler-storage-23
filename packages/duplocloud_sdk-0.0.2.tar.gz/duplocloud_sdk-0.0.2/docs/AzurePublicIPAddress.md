# AzurePublicIPAddress


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**extended_location** | [**AzureExtendedLocation**](AzureExtendedLocation.md) |  | [optional] 
**sku** | [**AzurePublicIPAddressSku**](AzurePublicIPAddressSku.md) |  | [optional] 
**properties_public_ip_allocation_method** | **str** |  | [optional] 
**properties_public_ip_address_version** | **str** |  | [optional] 
**properties_ip_configuration** | [**AzureIPConfiguration**](AzureIPConfiguration.md) |  | [optional] 
**properties_dns_settings** | [**AzurePublicIPAddressDnsSettings**](AzurePublicIPAddressDnsSettings.md) |  | [optional] 
**properties_ddos_settings** | [**AzureDdosSettings**](AzureDdosSettings.md) |  | [optional] 
**properties_ip_tags** | [**List[AzureIpTag]**](AzureIpTag.md) |  | [optional] 
**properties_ip_address** | **str** |  | [optional] 
**properties_public_ip_prefix** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_idle_timeout_in_minutes** | **int** |  | [optional] 
**properties_resource_guid** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_service_public_ip_address** | [**AzurePublicIPAddress**](AzurePublicIPAddress.md) |  | [optional] 
**properties_nat_gateway** | [**AzureNatGateway**](AzureNatGateway.md) |  | [optional] 
**properties_migration_phase** | **str** |  | [optional] 
**properties_linked_public_ip_address** | [**AzurePublicIPAddress**](AzurePublicIPAddress.md) |  | [optional] 
**properties_delete_option** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**zones** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_public_ip_address import AzurePublicIPAddress

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePublicIPAddress from a JSON string
azure_public_ip_address_instance = AzurePublicIPAddress.from_json(json)
# print the JSON string representation of the object
print(AzurePublicIPAddress.to_json())

# convert the object into a dict
azure_public_ip_address_dict = azure_public_ip_address_instance.to_dict()
# create an instance of AzurePublicIPAddress from a dict
azure_public_ip_address_from_dict = AzurePublicIPAddress.from_dict(azure_public_ip_address_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


