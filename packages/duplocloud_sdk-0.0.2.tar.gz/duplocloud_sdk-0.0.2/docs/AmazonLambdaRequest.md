# AmazonLambdaRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_lambda_request import AmazonLambdaRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonLambdaRequest from a JSON string
amazon_lambda_request_instance = AmazonLambdaRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonLambdaRequest.to_json())

# convert the object into a dict
amazon_lambda_request_dict = amazon_lambda_request_instance.to_dict()
# create an instance of AmazonLambdaRequest from a dict
amazon_lambda_request_from_dict = AmazonLambdaRequest.from_dict(amazon_lambda_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


