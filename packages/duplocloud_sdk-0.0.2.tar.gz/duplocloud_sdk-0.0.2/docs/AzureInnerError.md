# AzureInnerError

Inner error details.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**exceptiontype** | **str** | Gets or sets the exception type. | [optional] 
**errordetail** | **str** | Gets or sets the internal error message or exception dump. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_inner_error import AzureInnerError

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInnerError from a JSON string
azure_inner_error_instance = AzureInnerError.from_json(json)
# print the JSON string representation of the object
print(AzureInnerError.to_json())

# convert the object into a dict
azure_inner_error_dict = azure_inner_error_instance.to_dict()
# create an instance of AzureInnerError from a dict
azure_inner_error_from_dict = AzureInnerError.from_dict(azure_inner_error_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


