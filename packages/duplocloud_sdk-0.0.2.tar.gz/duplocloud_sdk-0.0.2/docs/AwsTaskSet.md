# AwsTaskSet


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capacity_provider_strategy** | [**List[AwsCapacityProviderStrategyItem]**](AwsCapacityProviderStrategyItem.md) |  | [optional] 
**cluster_arn** | **str** |  | [optional] 
**computed_desired_count** | **int** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**external_id** | **str** |  | [optional] 
**fargate_ephemeral_storage** | [**AwsDeploymentEphemeralStorage**](AwsDeploymentEphemeralStorage.md) |  | [optional] 
**id** | **str** |  | [optional] 
**launch_type** | [**AwsLaunchType**](AwsLaunchType.md) |  | [optional] 
**load_balancers** | [**List[AwsLoadBalancer]**](AwsLoadBalancer.md) |  | [optional] 
**network_configuration** | [**AwsNetworkConfiguration**](AwsNetworkConfiguration.md) |  | [optional] 
**pending_count** | **int** |  | [optional] 
**platform_family** | **str** |  | [optional] 
**platform_version** | **str** |  | [optional] 
**running_count** | **int** |  | [optional] 
**scale** | [**AwsScale**](AwsScale.md) |  | [optional] 
**service_arn** | **str** |  | [optional] 
**service_registries** | [**List[AwsServiceRegistry]**](AwsServiceRegistry.md) |  | [optional] 
**stability_status** | [**AwsStabilityStatus**](AwsStabilityStatus.md) |  | [optional] 
**stability_status_at** | **datetime** |  | [optional] 
**started_by** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**tags** | [**List[AwsTag]**](AwsTag.md) |  | [optional] 
**task_definition** | **str** |  | [optional] 
**task_set_arn** | **str** |  | [optional] 
**updated_at** | **datetime** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_set import AwsTaskSet

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskSet from a JSON string
aws_task_set_instance = AwsTaskSet.from_json(json)
# print the JSON string representation of the object
print(AwsTaskSet.to_json())

# convert the object into a dict
aws_task_set_dict = aws_task_set_instance.to_dict()
# create an instance of AwsTaskSet from a dict
aws_task_set_from_dict = AwsTaskSet.from_dict(aws_task_set_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


