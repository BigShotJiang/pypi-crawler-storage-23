# AwsServiceConnectConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**log_configuration** | [**AwsLogConfiguration**](AwsLogConfiguration.md) |  | [optional] 
**namespace** | **str** |  | [optional] 
**services** | [**List[AwsServiceConnectService]**](AwsServiceConnectService.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_configuration import AwsServiceConnectConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectConfiguration from a JSON string
aws_service_connect_configuration_instance = AwsServiceConnectConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectConfiguration.to_json())

# convert the object into a dict
aws_service_connect_configuration_dict = aws_service_connect_configuration_instance.to_dict()
# create an instance of AwsServiceConnectConfiguration from a dict
aws_service_connect_configuration_from_dict = AwsServiceConnectConfiguration.from_dict(aws_service_connect_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


