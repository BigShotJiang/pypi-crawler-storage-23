# AzureRedisResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 
**tags** | **Dict[str, str]** | Gets or sets resource tags. | [optional] 
**location** | **str** | Gets or sets the geo-location where the resource lives | [optional] 
**properties_redis_configuration** | [**AzureRedisCommonPropertiesRedisConfiguration**](AzureRedisCommonPropertiesRedisConfiguration.md) | Gets or sets all Redis Settings. Few possible keys: rdb-backup-enabled,rdb-storage-connection-string,rdb-backup-frequency,maxmemory-delta,maxmemory-policy,notify-keyspace-events,maxmemory-samples,slowlog-log-slower-than,slowlog-max-len,list-max-ziplist-entries,list-max-ziplist-value,hash-max-ziplist-entries,hash-max-ziplist-value,set-max-intset-entries,zset-max-ziplist-entries,zset-max-ziplist-value etc. | [optional] 
**properties_redis_version** | **str** | Gets or sets redis version. Only major version will be used in PUT/PATCH request with current valid values: (4, 6) | [optional] 
**properties_enable_non_ssl_port** | **bool** | Gets or sets specifies whether the non-ssl Redis server port (6379) is enabled. | [optional] 
**properties_replicas_per_master** | **int** | Gets or sets the number of replicas to be created per primary. | [optional] 
**properties_replicas_per_primary** | **int** | Gets or sets the number of replicas to be created per primary. | [optional] 
**properties_tenant_settings** | **Dict[str, str]** | Gets or sets a dictionary of tenant settings | [optional] 
**properties_shard_count** | **int** | Gets or sets the number of shards to be created on a Premium Cluster Cache. | [optional] 
**properties_minimum_tls_version** | **str** | Gets or sets optional: requires clients to use a specified TLS version (or higher) to connect (e,g, &#39;1.0&#39;, &#39;1.1&#39;, &#39;1.2&#39;). Possible values include: &#39;1.0&#39;, &#39;1.1&#39;, &#39;1.2&#39; | [optional] 
**properties_public_network_access** | **str** | Gets or sets whether or not public endpoint access is allowed for this cache.  Value is optional but if passed in, must be &#39;Enabled&#39; or &#39;Disabled&#39;. If &#39;Disabled&#39;, private endpoints are the exclusive access method. Default value is &#39;Enabled&#39;. Possible values include: &#39;Enabled&#39;, &#39;Disabled&#39; | [optional] 
**properties_sku** | [**AzureSku5**](AzureSku5.md) | Gets or sets the SKU of the Redis cache to deploy. | [optional] 
**properties_subnet_id** | **str** | Gets or sets the full resource ID of a subnet in a virtual network to deploy the Redis cache in. Example format: /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/Microsoft.{Network|ClassicNetwork}/VirtualNetworks/vnet1/subnets/subnet1 | [optional] 
**properties_static_ip** | **str** | Gets or sets static IP address. Optionally, may be specified when deploying a Redis cache inside an existing Azure Virtual Network; auto assigned by default. | [optional] 
**properties_provisioning_state** | **str** | Gets redis instance provisioning status. Possible values include: &#39;Creating&#39;, &#39;Deleting&#39;, &#39;Disabled&#39;, &#39;Failed&#39;, &#39;Linking&#39;, &#39;Provisioning&#39;, &#39;RecoveringScaleFailure&#39;, &#39;Scaling&#39;, &#39;Succeeded&#39;, &#39;Unlinking&#39;, &#39;Unprovisioning&#39;, &#39;Updating&#39; | [optional] 
**properties_host_name** | **str** | Gets redis host name. | [optional] 
**properties_port** | **int** | Gets redis non-SSL port. | [optional] 
**properties_ssl_port** | **int** | Gets redis SSL port. | [optional] 
**properties_access_keys** | [**AzureRedisAccessKeys**](AzureRedisAccessKeys.md) | Gets the keys of the Redis cache - not set if this object is not the response to Create or Update redis cache | [optional] 
**properties_linked_servers** | [**List[AzureRedisLinkedServer]**](AzureRedisLinkedServer.md) | Gets list of the linked servers associated with the cache | [optional] 
**properties_instances** | [**List[AzureRedisInstanceDetails]**](AzureRedisInstanceDetails.md) | Gets list of the Redis instances associated with the cache | [optional] 
**properties_private_endpoint_connections** | [**List[AzurePrivateEndpointConnection3]**](AzurePrivateEndpointConnection3.md) | Gets list of private endpoint connection associated with the specified redis cache | [optional] 
**zones** | **List[str]** | Gets or sets a list of availability zones denoting where the resource needs to come from. | [optional] 
**identity** | [**AzureManagedServiceIdentity**](AzureManagedServiceIdentity.md) | Gets or sets the identity of the resource. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_resource import AzureRedisResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisResource from a JSON string
azure_redis_resource_instance = AzureRedisResource.from_json(json)
# print the JSON string representation of the object
print(AzureRedisResource.to_json())

# convert the object into a dict
azure_redis_resource_dict = azure_redis_resource_instance.to_dict()
# create an instance of AzureRedisResource from a dict
azure_redis_resource_from_dict = AzureRedisResource.from_dict(azure_redis_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


