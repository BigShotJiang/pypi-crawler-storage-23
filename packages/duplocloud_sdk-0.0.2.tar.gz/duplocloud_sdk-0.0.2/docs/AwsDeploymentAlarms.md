# AwsDeploymentAlarms


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alarm_names** | **List[str]** |  | [optional] 
**enable** | **bool** |  | [optional] 
**rollback** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_alarms import AwsDeploymentAlarms

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentAlarms from a JSON string
aws_deployment_alarms_instance = AwsDeploymentAlarms.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentAlarms.to_json())

# convert the object into a dict
aws_deployment_alarms_dict = aws_deployment_alarms_instance.to_dict()
# create an instance of AwsDeploymentAlarms from a dict
aws_deployment_alarms_from_dict = AwsDeploymentAlarms.from_dict(aws_deployment_alarms_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


