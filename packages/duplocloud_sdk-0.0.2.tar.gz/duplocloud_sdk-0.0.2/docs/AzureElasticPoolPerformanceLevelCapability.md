# AzureElasticPoolPerformanceLevelCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**performance_level** | [**AzurePerformanceLevelCapability**](AzurePerformanceLevelCapability.md) |  | [optional] 
**sku** | [**AzureSku3**](AzureSku3.md) |  | [optional] 
**supported_license_types** | [**List[AzureLicenseTypeCapability]**](AzureLicenseTypeCapability.md) |  | [optional] 
**max_database_count** | **int** |  | [optional] 
**included_max_size** | [**AzureMaxSizeCapability**](AzureMaxSizeCapability.md) |  | [optional] 
**supported_max_sizes** | [**List[AzureMaxSizeRangeCapability]**](AzureMaxSizeRangeCapability.md) |  | [optional] 
**supported_per_database_max_sizes** | [**List[AzureMaxSizeRangeCapability]**](AzureMaxSizeRangeCapability.md) |  | [optional] 
**supported_per_database_max_performance_levels** | [**List[AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability]**](AzureElasticPoolPerDatabaseMaxPerformanceLevelCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_elastic_pool_performance_level_capability import AzureElasticPoolPerformanceLevelCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureElasticPoolPerformanceLevelCapability from a JSON string
azure_elastic_pool_performance_level_capability_instance = AzureElasticPoolPerformanceLevelCapability.from_json(json)
# print the JSON string representation of the object
print(AzureElasticPoolPerformanceLevelCapability.to_json())

# convert the object into a dict
azure_elastic_pool_performance_level_capability_dict = azure_elastic_pool_performance_level_capability_instance.to_dict()
# create an instance of AzureElasticPoolPerformanceLevelCapability from a dict
azure_elastic_pool_performance_level_capability_from_dict = AzureElasticPoolPerformanceLevelCapability.from_dict(azure_elastic_pool_performance_level_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


