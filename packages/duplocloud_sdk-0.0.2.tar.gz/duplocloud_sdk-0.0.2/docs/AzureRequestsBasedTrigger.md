# AzureRequestsBasedTrigger


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** |  | [optional] 
**time_interval** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_requests_based_trigger import AzureRequestsBasedTrigger

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRequestsBasedTrigger from a JSON string
azure_requests_based_trigger_instance = AzureRequestsBasedTrigger.from_json(json)
# print the JSON string representation of the object
print(AzureRequestsBasedTrigger.to_json())

# convert the object into a dict
azure_requests_based_trigger_dict = azure_requests_based_trigger_instance.to_dict()
# create an instance of AzureRequestsBasedTrigger from a dict
azure_requests_based_trigger_from_dict = AzureRequestsBasedTrigger.from_dict(azure_requests_based_trigger_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


