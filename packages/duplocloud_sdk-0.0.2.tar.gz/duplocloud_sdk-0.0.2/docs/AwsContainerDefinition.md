# AwsContainerDefinition


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**command** | **List[str]** |  | [optional] 
**cpu** | **int** |  | [optional] 
**credential_specs** | **List[str]** |  | [optional] 
**depends_on** | [**List[AwsContainerDependency]**](AwsContainerDependency.md) |  | [optional] 
**disable_networking** | **bool** |  | [optional] 
**dns_search_domains** | **List[str]** |  | [optional] 
**dns_servers** | **List[str]** |  | [optional] 
**docker_labels** | **Dict[str, str]** |  | [optional] 
**docker_security_options** | **List[str]** |  | [optional] 
**entry_point** | **List[str]** |  | [optional] 
**environment** | [**List[AwsKeyValuePair]**](AwsKeyValuePair.md) |  | [optional] 
**environment_files** | [**List[AwsEnvironmentFile]**](AwsEnvironmentFile.md) |  | [optional] 
**essential** | **bool** |  | [optional] 
**extra_hosts** | [**List[AwsHostEntry]**](AwsHostEntry.md) |  | [optional] 
**firelens_configuration** | [**AwsFirelensConfiguration**](AwsFirelensConfiguration.md) |  | [optional] 
**health_check** | [**AwsHealthCheck**](AwsHealthCheck.md) |  | [optional] 
**hostname** | **str** |  | [optional] 
**image** | **str** |  | [optional] 
**interactive** | **bool** |  | [optional] 
**links** | **List[str]** |  | [optional] 
**linux_parameters** | [**AwsLinuxParameters**](AwsLinuxParameters.md) |  | [optional] 
**log_configuration** | [**AwsLogConfiguration**](AwsLogConfiguration.md) |  | [optional] 
**memory** | **int** |  | [optional] 
**memory_reservation** | **int** |  | [optional] 
**mount_points** | [**List[AwsMountPoint]**](AwsMountPoint.md) |  | [optional] 
**name** | **str** |  | [optional] 
**port_mappings** | [**List[AwsPortMapping]**](AwsPortMapping.md) |  | [optional] 
**privileged** | **bool** |  | [optional] 
**pseudo_terminal** | **bool** |  | [optional] 
**readonly_root_filesystem** | **bool** |  | [optional] 
**repository_credentials** | [**AwsRepositoryCredentials**](AwsRepositoryCredentials.md) |  | [optional] 
**resource_requirements** | [**List[AwsResourceRequirement]**](AwsResourceRequirement.md) |  | [optional] 
**restart_policy** | [**AwsContainerRestartPolicy**](AwsContainerRestartPolicy.md) |  | [optional] 
**secrets** | [**List[AwsSecret]**](AwsSecret.md) |  | [optional] 
**start_timeout** | **int** |  | [optional] 
**stop_timeout** | **int** |  | [optional] 
**system_controls** | [**List[AwsSystemControl]**](AwsSystemControl.md) |  | [optional] 
**ulimits** | [**List[AwsUlimit]**](AwsUlimit.md) |  | [optional] 
**user** | **str** |  | [optional] 
**version_consistency** | [**AwsVersionConsistency**](AwsVersionConsistency.md) |  | [optional] 
**volumes_from** | [**List[AwsVolumeFrom]**](AwsVolumeFrom.md) |  | [optional] 
**working_directory** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container_definition import AwsContainerDefinition

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainerDefinition from a JSON string
aws_container_definition_instance = AwsContainerDefinition.from_json(json)
# print the JSON string representation of the object
print(AwsContainerDefinition.to_json())

# convert the object into a dict
aws_container_definition_dict = aws_container_definition_instance.to_dict()
# create an instance of AwsContainerDefinition from a dict
aws_container_definition_from_dict = AwsContainerDefinition.from_dict(aws_container_definition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


