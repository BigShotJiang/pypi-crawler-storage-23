# AzureFirewallRule2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 
**properties_start_ip_address** | **str** | Gets or sets the start IP address of the server firewall rule. Must be IPv4 format. | [optional] 
**properties_end_ip_address** | **str** | Gets or sets the end IP address of the server firewall rule. Must be IPv4 format. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_firewall_rule2 import AzureFirewallRule2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFirewallRule2 from a JSON string
azure_firewall_rule2_instance = AzureFirewallRule2.from_json(json)
# print the JSON string representation of the object
print(AzureFirewallRule2.to_json())

# convert the object into a dict
azure_firewall_rule2_dict = azure_firewall_rule2_instance.to_dict()
# create an instance of AzureFirewallRule2 from a dict
azure_firewall_rule2_from_dict = AzureFirewallRule2.from_dict(azure_firewall_rule2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


