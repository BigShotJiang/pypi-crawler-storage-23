# AzureContainerGroupNetworkProfile

Container group network profile information.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets the identifier for a network profile. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group_network_profile import AzureContainerGroupNetworkProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroupNetworkProfile from a JSON string
azure_container_group_network_profile_instance = AzureContainerGroupNetworkProfile.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroupNetworkProfile.to_json())

# convert the object into a dict
azure_container_group_network_profile_dict = azure_container_group_network_profile_instance.to_dict()
# create an instance of AzureContainerGroupNetworkProfile from a dict
azure_container_group_network_profile_from_dict = AzureContainerGroupNetworkProfile.from_dict(azure_container_group_network_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


