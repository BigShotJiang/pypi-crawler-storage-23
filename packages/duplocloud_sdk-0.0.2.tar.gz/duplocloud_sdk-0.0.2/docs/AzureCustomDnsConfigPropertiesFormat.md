# AzureCustomDnsConfigPropertiesFormat


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fqdn** | **str** |  | [optional] 
**ip_addresses** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_custom_dns_config_properties_format import AzureCustomDnsConfigPropertiesFormat

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCustomDnsConfigPropertiesFormat from a JSON string
azure_custom_dns_config_properties_format_instance = AzureCustomDnsConfigPropertiesFormat.from_json(json)
# print the JSON string representation of the object
print(AzureCustomDnsConfigPropertiesFormat.to_json())

# convert the object into a dict
azure_custom_dns_config_properties_format_dict = azure_custom_dns_config_properties_format_instance.to_dict()
# create an instance of AzureCustomDnsConfigPropertiesFormat from a dict
azure_custom_dns_config_properties_format_from_dict = AzureCustomDnsConfigPropertiesFormat.from_dict(azure_custom_dns_config_properties_format_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


