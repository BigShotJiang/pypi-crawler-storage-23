# AwsManagedAgent


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**last_started_at** | **datetime** |  | [optional] 
**last_status** | **str** |  | [optional] 
**name** | [**AwsManagedAgentName**](AwsManagedAgentName.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_managed_agent import AwsManagedAgent

# TODO update the JSON string below
json = "{}"
# create an instance of AwsManagedAgent from a JSON string
aws_managed_agent_instance = AwsManagedAgent.from_json(json)
# print the JSON string representation of the object
print(AwsManagedAgent.to_json())

# convert the object into a dict
aws_managed_agent_dict = aws_managed_agent_instance.to_dict()
# create an instance of AwsManagedAgent from a dict
aws_managed_agent_from_dict = AwsManagedAgent.from_dict(aws_managed_agent_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


