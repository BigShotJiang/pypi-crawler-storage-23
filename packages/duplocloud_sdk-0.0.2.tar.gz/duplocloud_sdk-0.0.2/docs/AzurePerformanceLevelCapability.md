# AzurePerformanceLevelCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **float** |  | [optional] 
**unit** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_performance_level_capability import AzurePerformanceLevelCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePerformanceLevelCapability from a JSON string
azure_performance_level_capability_instance = AzurePerformanceLevelCapability.from_json(json)
# print the JSON string representation of the object
print(AzurePerformanceLevelCapability.to_json())

# convert the object into a dict
azure_performance_level_capability_dict = azure_performance_level_capability_instance.to_dict()
# create an instance of AzurePerformanceLevelCapability from a dict
azure_performance_level_capability_from_dict = AzurePerformanceLevelCapability.from_dict(azure_performance_level_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


