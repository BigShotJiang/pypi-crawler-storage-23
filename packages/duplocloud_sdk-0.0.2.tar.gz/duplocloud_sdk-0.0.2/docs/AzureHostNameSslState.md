# AzureHostNameSslState


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**ssl_state** | [**AzureSslState**](AzureSslState.md) |  | [optional] 
**virtual_ip** | **str** |  | [optional] 
**thumbprint** | **str** |  | [optional] 
**to_update** | **bool** |  | [optional] 
**host_type** | [**AzureHostType**](AzureHostType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_host_name_ssl_state import AzureHostNameSslState

# TODO update the JSON string below
json = "{}"
# create an instance of AzureHostNameSslState from a JSON string
azure_host_name_ssl_state_instance = AzureHostNameSslState.from_json(json)
# print the JSON string representation of the object
print(AzureHostNameSslState.to_json())

# convert the object into a dict
azure_host_name_ssl_state_dict = azure_host_name_ssl_state_instance.to_dict()
# create an instance of AzureHostNameSslState from a dict
azure_host_name_ssl_state_from_dict = AzureHostNameSslState.from_dict(azure_host_name_ssl_state_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


