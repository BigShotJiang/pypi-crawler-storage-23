# AutoTuneState


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.auto_tune_state import AutoTuneState

# TODO update the JSON string below
json = "{}"
# create an instance of AutoTuneState from a JSON string
auto_tune_state_instance = AutoTuneState.from_json(json)
# print the JSON string representation of the object
print(AutoTuneState.to_json())

# convert the object into a dict
auto_tune_state_dict = auto_tune_state_instance.to_dict()
# create an instance of AutoTuneState from a dict
auto_tune_state_from_dict = AutoTuneState.from_dict(auto_tune_state_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


