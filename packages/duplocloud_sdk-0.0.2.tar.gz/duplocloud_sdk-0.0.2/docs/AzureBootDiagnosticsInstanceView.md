# AzureBootDiagnosticsInstanceView

The instance view of a virtual machine boot diagnostics.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**console_screenshot_blob_uri** | **str** | Gets the console screenshot blob URI. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;NOTE: This will **not** be set if boot diagnostics is currently enabled with managed storage. | [optional] 
**serial_console_log_blob_uri** | **str** | Gets the serial console log blob Uri. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;NOTE: This will **not** be set if boot diagnostics is currently enabled with managed storage. | [optional] 
**status** | [**AzureInstanceViewStatus**](AzureInstanceViewStatus.md) | Gets the boot diagnostics status information for the VM. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; NOTE: It will be set only if there are errors encountered in enabling boot diagnostics. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_boot_diagnostics_instance_view import AzureBootDiagnosticsInstanceView

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBootDiagnosticsInstanceView from a JSON string
azure_boot_diagnostics_instance_view_instance = AzureBootDiagnosticsInstanceView.from_json(json)
# print the JSON string representation of the object
print(AzureBootDiagnosticsInstanceView.to_json())

# convert the object into a dict
azure_boot_diagnostics_instance_view_dict = azure_boot_diagnostics_instance_view_instance.to_dict()
# create an instance of AzureBootDiagnosticsInstanceView from a dict
azure_boot_diagnostics_instance_view_from_dict = AzureBootDiagnosticsInstanceView.from_dict(azure_boot_diagnostics_instance_view_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


