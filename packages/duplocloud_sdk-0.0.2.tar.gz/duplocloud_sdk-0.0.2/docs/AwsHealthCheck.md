# AwsHealthCheck


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**command** | **List[str]** |  | [optional] 
**interval** | **int** |  | [optional] 
**retries** | **int** |  | [optional] 
**start_period** | **int** |  | [optional] 
**timeout** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_health_check import AwsHealthCheck

# TODO update the JSON string below
json = "{}"
# create an instance of AwsHealthCheck from a JSON string
aws_health_check_instance = AwsHealthCheck.from_json(json)
# print the JSON string representation of the object
print(AwsHealthCheck.to_json())

# convert the object into a dict
aws_health_check_dict = aws_health_check_instance.to_dict()
# create an instance of AwsHealthCheck from a dict
aws_health_check_from_dict = AwsHealthCheck.from_dict(aws_health_check_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


