# AwsIpcMode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ipc_mode import AwsIpcMode

# TODO update the JSON string below
json = "{}"
# create an instance of AwsIpcMode from a JSON string
aws_ipc_mode_instance = AwsIpcMode.from_json(json)
# print the JSON string representation of the object
print(AwsIpcMode.to_json())

# convert the object into a dict
aws_ipc_mode_dict = aws_ipc_mode_instance.to_dict()
# create an instance of AwsIpcMode from a dict
aws_ipc_mode_from_dict = AwsIpcMode.from_dict(aws_ipc_mode_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


