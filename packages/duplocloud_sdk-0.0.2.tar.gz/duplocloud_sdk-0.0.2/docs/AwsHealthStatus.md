# AwsHealthStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_health_status import AwsHealthStatus

# TODO update the JSON string below
json = "{}"
# create an instance of AwsHealthStatus from a JSON string
aws_health_status_instance = AwsHealthStatus.from_json(json)
# print the JSON string representation of the object
print(AwsHealthStatus.to_json())

# convert the object into a dict
aws_health_status_dict = aws_health_status_instance.to_dict()
# create an instance of AwsHealthStatus from a dict
aws_health_status_from_dict = AwsHealthStatus.from_dict(aws_health_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


