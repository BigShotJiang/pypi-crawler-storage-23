# AzureObjectIdentifier


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base_identifier** | **str** |  | [optional] 
**identifier** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**vault** | **str** |  | [optional] 
**vault_without_scheme** | **str** |  | [optional] 
**version** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_object_identifier import AzureObjectIdentifier

# TODO update the JSON string below
json = "{}"
# create an instance of AzureObjectIdentifier from a JSON string
azure_object_identifier_instance = AzureObjectIdentifier.from_json(json)
# print the JSON string representation of the object
print(AzureObjectIdentifier.to_json())

# convert the object into a dict
azure_object_identifier_dict = azure_object_identifier_instance.to_dict()
# create an instance of AzureObjectIdentifier from a dict
azure_object_identifier_from_dict = AzureObjectIdentifier.from_dict(azure_object_identifier_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


