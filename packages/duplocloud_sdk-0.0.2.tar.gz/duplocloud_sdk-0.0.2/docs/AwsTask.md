# AwsTask


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attachments** | [**List[AwsAttachment]**](AwsAttachment.md) |  | [optional] 
**attributes** | [**List[AwsAttribute]**](AwsAttribute.md) |  | [optional] 
**availability_zone** | **str** |  | [optional] 
**capacity_provider_name** | **str** |  | [optional] 
**cluster_arn** | **str** |  | [optional] 
**connectivity** | [**AwsConnectivity**](AwsConnectivity.md) |  | [optional] 
**connectivity_at** | **datetime** |  | [optional] 
**container_instance_arn** | **str** |  | [optional] 
**containers** | [**List[AwsContainer]**](AwsContainer.md) |  | [optional] 
**cpu** | **str** |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**desired_status** | **str** |  | [optional] 
**enable_execute_command** | **bool** |  | [optional] 
**ephemeral_storage** | [**AwsEphemeralStorage**](AwsEphemeralStorage.md) |  | [optional] 
**execution_stopped_at** | **datetime** |  | [optional] 
**fargate_ephemeral_storage** | [**AwsTaskEphemeralStorage**](AwsTaskEphemeralStorage.md) |  | [optional] 
**group** | **str** |  | [optional] 
**health_status** | [**AwsHealthStatus**](AwsHealthStatus.md) |  | [optional] 
**inference_accelerators** | [**List[AwsInferenceAccelerator]**](AwsInferenceAccelerator.md) |  | [optional] 
**last_status** | **str** |  | [optional] 
**launch_type** | [**AwsLaunchType**](AwsLaunchType.md) |  | [optional] 
**memory** | **str** |  | [optional] 
**overrides** | [**AwsTaskOverride**](AwsTaskOverride.md) |  | [optional] 
**platform_family** | **str** |  | [optional] 
**platform_version** | **str** |  | [optional] 
**pull_started_at** | **datetime** |  | [optional] 
**pull_stopped_at** | **datetime** |  | [optional] 
**started_at** | **datetime** |  | [optional] 
**started_by** | **str** |  | [optional] 
**stop_code** | [**AwsTaskStopCode**](AwsTaskStopCode.md) |  | [optional] 
**stopped_at** | **datetime** |  | [optional] 
**stopped_reason** | **str** |  | [optional] 
**stopping_at** | **datetime** |  | [optional] 
**tags** | [**List[AwsTag]**](AwsTag.md) |  | [optional] 
**task_arn** | **str** |  | [optional] 
**task_definition_arn** | **str** |  | [optional] 
**version** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task import AwsTask

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTask from a JSON string
aws_task_instance = AwsTask.from_json(json)
# print the JSON string representation of the object
print(AwsTask.to_json())

# convert the object into a dict
aws_task_dict = aws_task_instance.to_dict()
# create an instance of AwsTask from a dict
aws_task_from_dict = AwsTask.from_dict(aws_task_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


