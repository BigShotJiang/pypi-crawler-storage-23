# AwsEBSTagSpecification


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**propagate_tags** | [**AwsPropagateTags**](AwsPropagateTags.md) |  | [optional] 
**resource_type** | [**AwsEBSResourceType**](AwsEBSResourceType.md) |  | [optional] 
**tags** | [**List[AwsTag]**](AwsTag.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ebs_tag_specification import AwsEBSTagSpecification

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEBSTagSpecification from a JSON string
aws_ebs_tag_specification_instance = AwsEBSTagSpecification.from_json(json)
# print the JSON string representation of the object
print(AwsEBSTagSpecification.to_json())

# convert the object into a dict
aws_ebs_tag_specification_dict = aws_ebs_tag_specification_instance.to_dict()
# create an instance of AwsEBSTagSpecification from a dict
aws_ebs_tag_specification_from_dict = AwsEBSTagSpecification.from_dict(aws_ebs_tag_specification_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


