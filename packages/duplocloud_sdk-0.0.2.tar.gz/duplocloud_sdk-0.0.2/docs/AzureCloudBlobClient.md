# AzureCloudBlobClient


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authentication_scheme** | [**AzureAuthenticationScheme**](AzureAuthenticationScheme.md) |  | [optional] 
**buffer_manager** | **object** |  | [optional] 
**credentials** | [**AzureStorageCredentials**](AzureStorageCredentials.md) |  | [optional] 
**base_uri** | **str** |  | [optional] 
**storage_uri** | [**AzureStorageUri**](AzureStorageUri.md) |  | [optional] 
**default_request_options** | [**AzureBlobRequestOptions**](AzureBlobRequestOptions.md) |  | [optional] 
**retry_policy** | **object** |  | [optional] 
**default_delimiter** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_cloud_blob_client import AzureCloudBlobClient

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCloudBlobClient from a JSON string
azure_cloud_blob_client_instance = AzureCloudBlobClient.from_json(json)
# print the JSON string representation of the object
print(AzureCloudBlobClient.to_json())

# convert the object into a dict
azure_cloud_blob_client_dict = azure_cloud_blob_client_instance.to_dict()
# create an instance of AzureCloudBlobClient from a dict
azure_cloud_blob_client_from_dict = AzureCloudBlobClient.from_dict(azure_cloud_blob_client_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


