# AzureBlobContainerProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**e_tag** | **str** |  | [optional] 
**last_modified** | **datetime** |  | [optional] 
**lease_status** | [**AzureLeaseStatus**](AzureLeaseStatus.md) |  | [optional] 
**lease_state** | [**AzureLeaseState**](AzureLeaseState.md) |  | [optional] 
**lease_duration** | [**AzureLeaseDuration**](AzureLeaseDuration.md) |  | [optional] 
**public_access** | [**AzureBlobContainerPublicAccessType**](AzureBlobContainerPublicAccessType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_blob_container_properties import AzureBlobContainerProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBlobContainerProperties from a JSON string
azure_blob_container_properties_instance = AzureBlobContainerProperties.from_json(json)
# print the JSON string representation of the object
print(AzureBlobContainerProperties.to_json())

# convert the object into a dict
azure_blob_container_properties_dict = azure_blob_container_properties_instance.to_dict()
# create an instance of AzureBlobContainerProperties from a dict
azure_blob_container_properties_from_dict = AzureBlobContainerProperties.from_dict(azure_blob_container_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


