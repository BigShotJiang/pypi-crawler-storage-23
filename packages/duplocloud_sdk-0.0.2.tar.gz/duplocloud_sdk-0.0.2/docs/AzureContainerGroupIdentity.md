# AzureContainerGroupIdentity

Identity for the container group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** | Gets the principal id of the container group identity. This property will only be provided for a system assigned identity. | [optional] 
**tenant_id** | **str** | Gets the tenant id associated with the container group. This property will only be provided for a system assigned identity. | [optional] 
**type** | [**AzureResourceIdentityType**](AzureResourceIdentityType.md) | Gets or sets the type of identity used for the container group. The type &#39;SystemAssigned, UserAssigned&#39; includes both an implicitly created identity and a set of user assigned identities. The type &#39;None&#39; will remove any identities from the container group. Possible values include: &#39;SystemAssigned&#39;, &#39;UserAssigned&#39;, &#39;SystemAssigned, UserAssigned&#39;, &#39;None&#39; | [optional] 
**user_assigned_identities** | [**Dict[str, AzureContainerGroupIdentityUserAssignedIdentitiesValue]**](AzureContainerGroupIdentityUserAssignedIdentitiesValue.md) | Gets or sets the list of user identities associated with the container group. The user identity dictionary key references will be ARM resource ids in the form: &#39;/subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/Microsoft.ManagedIdentity/userAssignedIdentities/{identityName}&#39;. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group_identity import AzureContainerGroupIdentity

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroupIdentity from a JSON string
azure_container_group_identity_instance = AzureContainerGroupIdentity.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroupIdentity.to_json())

# convert the object into a dict
azure_container_group_identity_dict = azure_container_group_identity_instance.to_dict()
# create an instance of AzureContainerGroupIdentity from a dict
azure_container_group_identity_from_dict = AzureContainerGroupIdentity.from_dict(azure_container_group_identity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


