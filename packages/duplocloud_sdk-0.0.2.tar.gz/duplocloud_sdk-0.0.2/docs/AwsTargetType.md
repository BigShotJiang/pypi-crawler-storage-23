# AwsTargetType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_target_type import AwsTargetType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTargetType from a JSON string
aws_target_type_instance = AwsTargetType.from_json(json)
# print the JSON string representation of the object
print(AwsTargetType.to_json())

# convert the object into a dict
aws_target_type_dict = aws_target_type_instance.to_dict()
# create an instance of AwsTargetType from a dict
aws_target_type_from_dict = AwsTargetType.from_dict(aws_target_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


