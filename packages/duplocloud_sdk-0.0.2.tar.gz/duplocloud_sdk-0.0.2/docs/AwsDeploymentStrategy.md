# AwsDeploymentStrategy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_strategy import AwsDeploymentStrategy

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentStrategy from a JSON string
aws_deployment_strategy_instance = AwsDeploymentStrategy.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentStrategy.to_json())

# convert the object into a dict
aws_deployment_strategy_dict = aws_deployment_strategy_instance.to_dict()
# create an instance of AwsDeploymentStrategy from a dict
aws_deployment_strategy_from_dict = AwsDeploymentStrategy.from_dict(aws_deployment_strategy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


