# AwsReplicationDestination


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_control_translation** | [**AccessControlTranslation**](AccessControlTranslation.md) |  | [optional] 
**account_id** | **str** |  | [optional] 
**bucket_arn** | **str** |  | [optional] 
**encryption_configuration** | [**EncryptionConfiguration**](EncryptionConfiguration.md) |  | [optional] 
**metrics** | [**Metrics**](Metrics.md) |  | [optional] 
**replication_time** | [**ReplicationTime**](ReplicationTime.md) |  | [optional] 
**storage_class** | [**S3StorageClass**](S3StorageClass.md) |  | [optional] 
**tenant_name** | **str** |  | [optional] 
**bucket_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_replication_destination import AwsReplicationDestination

# TODO update the JSON string below
json = "{}"
# create an instance of AwsReplicationDestination from a JSON string
aws_replication_destination_instance = AwsReplicationDestination.from_json(json)
# print the JSON string representation of the object
print(AwsReplicationDestination.to_json())

# convert the object into a dict
aws_replication_destination_dict = aws_replication_destination_instance.to_dict()
# create an instance of AwsReplicationDestination from a dict
aws_replication_destination_from_dict = AwsReplicationDestination.from_dict(aws_replication_destination_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


