# AzureContainerGroupPropertiesInstanceView

The instance view of the container group. Only valid in response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**events** | [**List[AzureEventModel]**](AzureEventModel.md) | Gets the events of this container group. | [optional] 
**state** | **str** | Gets the state of the container group. Only valid in response. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group_properties_instance_view import AzureContainerGroupPropertiesInstanceView

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroupPropertiesInstanceView from a JSON string
azure_container_group_properties_instance_view_instance = AzureContainerGroupPropertiesInstanceView.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroupPropertiesInstanceView.to_json())

# convert the object into a dict
azure_container_group_properties_instance_view_dict = azure_container_group_properties_instance_view_instance.to_dict()
# create an instance of AzureContainerGroupPropertiesInstanceView from a dict
azure_container_group_properties_instance_view_from_dict = AzureContainerGroupPropertiesInstanceView.from_dict(azure_container_group_properties_instance_view_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


