# AwsFSxWindowsFileServerAuthorizationConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credentials_parameter** | **str** |  | [optional] 
**domain** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_fsx_windows_file_server_authorization_config import AwsFSxWindowsFileServerAuthorizationConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AwsFSxWindowsFileServerAuthorizationConfig from a JSON string
aws_fsx_windows_file_server_authorization_config_instance = AwsFSxWindowsFileServerAuthorizationConfig.from_json(json)
# print the JSON string representation of the object
print(AwsFSxWindowsFileServerAuthorizationConfig.to_json())

# convert the object into a dict
aws_fsx_windows_file_server_authorization_config_dict = aws_fsx_windows_file_server_authorization_config_instance.to_dict()
# create an instance of AwsFSxWindowsFileServerAuthorizationConfig from a dict
aws_fsx_windows_file_server_authorization_config_from_dict = AwsFSxWindowsFileServerAuthorizationConfig.from_dict(aws_fsx_windows_file_server_authorization_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


