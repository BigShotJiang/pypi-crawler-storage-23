# AwsTaskDefinitionPlacementConstraint


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expression** | **str** |  | [optional] 
**type** | [**AwsTaskDefinitionPlacementConstraintType**](AwsTaskDefinitionPlacementConstraintType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_definition_placement_constraint import AwsTaskDefinitionPlacementConstraint

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskDefinitionPlacementConstraint from a JSON string
aws_task_definition_placement_constraint_instance = AwsTaskDefinitionPlacementConstraint.from_json(json)
# print the JSON string representation of the object
print(AwsTaskDefinitionPlacementConstraint.to_json())

# convert the object into a dict
aws_task_definition_placement_constraint_dict = aws_task_definition_placement_constraint_instance.to_dict()
# create an instance of AwsTaskDefinitionPlacementConstraint from a dict
aws_task_definition_placement_constraint_from_dict = AwsTaskDefinitionPlacementConstraint.from_dict(aws_task_definition_placement_constraint_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


