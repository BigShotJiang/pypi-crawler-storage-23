# AmazonRedshiftAdvancedOption


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amazon_redshift_advanced_option import AmazonRedshiftAdvancedOption

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonRedshiftAdvancedOption from a JSON string
amazon_redshift_advanced_option_instance = AmazonRedshiftAdvancedOption.from_json(json)
# print the JSON string representation of the object
print(AmazonRedshiftAdvancedOption.to_json())

# convert the object into a dict
amazon_redshift_advanced_option_dict = amazon_redshift_advanced_option_instance.to_dict()
# create an instance of AmazonRedshiftAdvancedOption from a dict
amazon_redshift_advanced_option_from_dict = AmazonRedshiftAdvancedOption.from_dict(amazon_redshift_advanced_option_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


