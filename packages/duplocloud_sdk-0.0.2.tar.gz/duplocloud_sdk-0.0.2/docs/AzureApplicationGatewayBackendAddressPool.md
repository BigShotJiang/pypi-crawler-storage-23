# AzureApplicationGatewayBackendAddressPool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_backend_ip_configurations** | [**List[AzureNetworkInterfaceIPConfiguration]**](AzureNetworkInterfaceIPConfiguration.md) |  | [optional] 
**properties_backend_addresses** | [**List[AzureApplicationGatewayBackendAddress]**](AzureApplicationGatewayBackendAddress.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_backend_address_pool import AzureApplicationGatewayBackendAddressPool

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayBackendAddressPool from a JSON string
azure_application_gateway_backend_address_pool_instance = AzureApplicationGatewayBackendAddressPool.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayBackendAddressPool.to_json())

# convert the object into a dict
azure_application_gateway_backend_address_pool_dict = azure_application_gateway_backend_address_pool_instance.to_dict()
# create an instance of AzureApplicationGatewayBackendAddressPool from a dict
azure_application_gateway_backend_address_pool_from_dict = AzureApplicationGatewayBackendAddressPool.from_dict(azure_application_gateway_backend_address_pool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


