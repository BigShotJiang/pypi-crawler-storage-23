# AzureProtectedItemResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**e_tag** | **str** |  | [optional] 
**properties** | [**AzureProtectedItem**](AzureProtectedItem.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_protected_item_resource import AzureProtectedItemResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureProtectedItemResource from a JSON string
azure_protected_item_resource_instance = AzureProtectedItemResource.from_json(json)
# print the JSON string representation of the object
print(AzureProtectedItemResource.to_json())

# convert the object into a dict
azure_protected_item_resource_dict = azure_protected_item_resource_instance.to_dict()
# create an instance of AzureProtectedItemResource from a dict
azure_protected_item_resource_from_dict = AzureProtectedItemResource.from_dict(azure_protected_item_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


