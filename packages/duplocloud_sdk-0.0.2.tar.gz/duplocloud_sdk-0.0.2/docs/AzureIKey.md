# AzureIKey

Interface for Keys

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**default_encryption_algorithm** | **str** | The default encryption algorithm for this key | [optional] 
**default_key_wrap_algorithm** | **str** | The default key wrap algorithm for this key | [optional] 
**default_signature_algorithm** | **str** | The default signature algorithm for this key | [optional] 
**kid** | **str** | The key identifier | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_i_key import AzureIKey

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIKey from a JSON string
azure_i_key_instance = AzureIKey.from_json(json)
# print the JSON string representation of the object
print(AzureIKey.to_json())

# convert the object into a dict
azure_i_key_dict = azure_i_key_instance.to_dict()
# create an instance of AzureIKey from a dict
azure_i_key_from_dict = AzureIKey.from_dict(azure_i_key_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


