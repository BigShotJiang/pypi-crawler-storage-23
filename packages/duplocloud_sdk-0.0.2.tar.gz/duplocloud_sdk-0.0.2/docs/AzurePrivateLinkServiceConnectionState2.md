# AzurePrivateLinkServiceConnectionState2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** |  | [optional] 
**description** | **str** |  | [optional] 
**actions_required** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_connection_state2 import AzurePrivateLinkServiceConnectionState2

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceConnectionState2 from a JSON string
azure_private_link_service_connection_state2_instance = AzurePrivateLinkServiceConnectionState2.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceConnectionState2.to_json())

# convert the object into a dict
azure_private_link_service_connection_state2_dict = azure_private_link_service_connection_state2_instance.to_dict()
# create an instance of AzurePrivateLinkServiceConnectionState2 from a dict
azure_private_link_service_connection_state2_from_dict = AzurePrivateLinkServiceConnectionState2.from_dict(azure_private_link_service_connection_state2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


