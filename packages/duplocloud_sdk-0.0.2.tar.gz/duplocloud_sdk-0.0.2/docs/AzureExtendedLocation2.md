# AzureExtendedLocation2

The complex type of the extended location.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the name of the extended location. | [optional] 
**type** | **str** | Gets or sets the type of the extended location. Possible values include: &#39;EdgeZone&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_extended_location2 import AzureExtendedLocation2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureExtendedLocation2 from a JSON string
azure_extended_location2_instance = AzureExtendedLocation2.from_json(json)
# print the JSON string representation of the object
print(AzureExtendedLocation2.to_json())

# convert the object into a dict
azure_extended_location2_dict = azure_extended_location2_instance.to_dict()
# create an instance of AzureExtendedLocation2 from a dict
azure_extended_location2_from_dict = AzureExtendedLocation2.from_dict(azure_extended_location2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


