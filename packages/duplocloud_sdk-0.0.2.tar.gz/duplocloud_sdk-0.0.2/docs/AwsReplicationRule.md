# AwsReplicationRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**priority** | **int** |  | [optional] 
**prefix** | **str** |  | [optional] 
**filter** | [**ReplicationRuleFilter**](ReplicationRuleFilter.md) |  | [optional] 
**status** | [**ReplicationRuleStatus**](ReplicationRuleStatus.md) |  | [optional] 
**destination** | [**AwsReplicationDestination**](AwsReplicationDestination.md) |  | [optional] 
**source_selection_criteria** | [**SourceSelectionCriteria**](SourceSelectionCriteria.md) |  | [optional] 
**existing_object_replication** | [**ExistingObjectReplication**](ExistingObjectReplication.md) |  | [optional] 
**delete_marker_replication** | [**DeleteMarkerReplication**](DeleteMarkerReplication.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_replication_rule import AwsReplicationRule

# TODO update the JSON string below
json = "{}"
# create an instance of AwsReplicationRule from a JSON string
aws_replication_rule_instance = AwsReplicationRule.from_json(json)
# print the JSON string representation of the object
print(AwsReplicationRule.to_json())

# convert the object into a dict
aws_replication_rule_dict = aws_replication_rule_instance.to_dict()
# create an instance of AwsReplicationRule from a dict
aws_replication_rule_from_dict = AwsReplicationRule.from_dict(aws_replication_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


