# AwsDeploymentEphemeralStorage


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kms_key_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_ephemeral_storage import AwsDeploymentEphemeralStorage

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentEphemeralStorage from a JSON string
aws_deployment_ephemeral_storage_instance = AwsDeploymentEphemeralStorage.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentEphemeralStorage.to_json())

# convert the object into a dict
aws_deployment_ephemeral_storage_dict = aws_deployment_ephemeral_storage_instance.to_dict()
# create an instance of AwsDeploymentEphemeralStorage from a dict
aws_deployment_ephemeral_storage_from_dict = AwsDeploymentEphemeralStorage.from_dict(aws_deployment_ephemeral_storage_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


