# AzureBootDiagnostics

Boot Diagnostics is a debugging feature which allows you to view Console Output and Screenshot to diagnose VM status. <br><br> You can easily view the output of your console log. <br><br> Azure also enables you to see a screenshot of the VM from the hypervisor.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** | Gets or sets whether boot diagnostics should be enabled on the Virtual Machine. | [optional] 
**storage_uri** | **str** | Gets or sets uri of the storage account to use for placing the console output and screenshot. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt;If storageUri is not specified while enabling boot diagnostics, managed storage will be used. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_boot_diagnostics import AzureBootDiagnostics

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBootDiagnostics from a JSON string
azure_boot_diagnostics_instance = AzureBootDiagnostics.from_json(json)
# print the JSON string representation of the object
print(AzureBootDiagnostics.to_json())

# convert the object into a dict
azure_boot_diagnostics_dict = azure_boot_diagnostics_instance.to_dict()
# create an instance of AzureBootDiagnostics from a dict
azure_boot_diagnostics_from_dict = AzureBootDiagnostics.from_dict(azure_boot_diagnostics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


