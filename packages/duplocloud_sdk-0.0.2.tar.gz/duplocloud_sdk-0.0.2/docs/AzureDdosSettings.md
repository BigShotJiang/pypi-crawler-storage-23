# AzureDdosSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protection_mode** | **str** |  | [optional] 
**ddos_protection_plan** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ddos_settings import AzureDdosSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDdosSettings from a JSON string
azure_ddos_settings_instance = AzureDdosSettings.from_json(json)
# print the JSON string representation of the object
print(AzureDdosSettings.to_json())

# convert the object into a dict
azure_ddos_settings_dict = azure_ddos_settings_instance.to_dict()
# create an instance of AzureDdosSettings from a dict
azure_ddos_settings_from_dict = AzureDdosSettings.from_dict(azure_ddos_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


