# AmazonCloudWatchLogsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_cloud_watch_logs_request import AmazonCloudWatchLogsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonCloudWatchLogsRequest from a JSON string
amazon_cloud_watch_logs_request_instance = AmazonCloudWatchLogsRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonCloudWatchLogsRequest.to_json())

# convert the object into a dict
amazon_cloud_watch_logs_request_dict = amazon_cloud_watch_logs_request_instance.to_dict()
# create an instance of AmazonCloudWatchLogsRequest from a dict
amazon_cloud_watch_logs_request_from_dict = AmazonCloudWatchLogsRequest.from_dict(amazon_cloud_watch_logs_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


