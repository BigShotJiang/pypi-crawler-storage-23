# AwsContainerRestartPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**ignored_exit_codes** | **List[int]** |  | [optional] 
**restart_attempt_period** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container_restart_policy import AwsContainerRestartPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainerRestartPolicy from a JSON string
aws_container_restart_policy_instance = AwsContainerRestartPolicy.from_json(json)
# print the JSON string representation of the object
print(AwsContainerRestartPolicy.to_json())

# convert the object into a dict
aws_container_restart_policy_dict = aws_container_restart_policy_instance.to_dict()
# create an instance of AwsContainerRestartPolicy from a dict
aws_container_restart_policy_from_dict = AwsContainerRestartPolicy.from_dict(aws_container_restart_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


