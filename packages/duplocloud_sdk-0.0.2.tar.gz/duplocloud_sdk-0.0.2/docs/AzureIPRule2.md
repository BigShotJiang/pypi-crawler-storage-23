# AzureIPRule2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_rule2 import AzureIPRule2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIPRule2 from a JSON string
azure_ip_rule2_instance = AzureIPRule2.from_json(json)
# print the JSON string representation of the object
print(AzureIPRule2.to_json())

# convert the object into a dict
azure_ip_rule2_dict = azure_ip_rule2_instance.to_dict()
# create an instance of AzureIPRule2 from a dict
azure_ip_rule2_from_dict = AzureIPRule2.from_dict(azure_ip_rule2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


