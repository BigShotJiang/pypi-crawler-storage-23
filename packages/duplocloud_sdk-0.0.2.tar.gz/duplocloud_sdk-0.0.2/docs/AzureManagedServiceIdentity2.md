# AzureManagedServiceIdentity2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AzureManagedServiceIdentityType**](AzureManagedServiceIdentityType.md) |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**principal_id** | **str** |  | [optional] 
**user_assigned_identities** | [**Dict[str, AzureManagedServiceIdentityUserAssignedIdentitiesValue]**](AzureManagedServiceIdentityUserAssignedIdentitiesValue.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_service_identity2 import AzureManagedServiceIdentity2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedServiceIdentity2 from a JSON string
azure_managed_service_identity2_instance = AzureManagedServiceIdentity2.from_json(json)
# print the JSON string representation of the object
print(AzureManagedServiceIdentity2.to_json())

# convert the object into a dict
azure_managed_service_identity2_dict = azure_managed_service_identity2_instance.to_dict()
# create an instance of AzureManagedServiceIdentity2 from a dict
azure_managed_service_identity2_from_dict = AzureManagedServiceIdentity2.from_dict(azure_managed_service_identity2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


