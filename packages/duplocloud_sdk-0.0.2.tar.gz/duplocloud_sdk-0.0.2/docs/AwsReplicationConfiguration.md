# AwsReplicationConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**role** | **str** |  | [optional] 
**rules** | [**List[AwsReplicationRule]**](AwsReplicationRule.md) |  | [optional] 
**bucket_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_replication_configuration import AwsReplicationConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsReplicationConfiguration from a JSON string
aws_replication_configuration_instance = AwsReplicationConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsReplicationConfiguration.to_json())

# convert the object into a dict
aws_replication_configuration_dict = aws_replication_configuration_instance.to_dict()
# create an instance of AwsReplicationConfiguration from a dict
aws_replication_configuration_from_dict = AwsReplicationConfiguration.from_dict(aws_replication_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


