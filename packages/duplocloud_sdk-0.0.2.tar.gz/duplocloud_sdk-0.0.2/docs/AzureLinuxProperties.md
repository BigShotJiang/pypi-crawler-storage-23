# AzureLinuxProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**included_package_classifications** | **str** |  | [optional] 
**excluded_package_name_masks** | **List[str]** |  | [optional] 
**included_package_name_masks** | **List[str]** |  | [optional] 
**reboot_setting** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_linux_properties import AzureLinuxProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLinuxProperties from a JSON string
azure_linux_properties_instance = AzureLinuxProperties.from_json(json)
# print the JSON string representation of the object
print(AzureLinuxProperties.to_json())

# convert the object into a dict
azure_linux_properties_dict = azure_linux_properties_instance.to_dict()
# create an instance of AzureLinuxProperties from a dict
azure_linux_properties_from_dict = AzureLinuxProperties.from_dict(azure_linux_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


