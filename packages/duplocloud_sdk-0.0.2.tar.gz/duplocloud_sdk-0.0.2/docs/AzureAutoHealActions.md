# AzureAutoHealActions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action_type** | [**AzureAutoHealActionType**](AzureAutoHealActionType.md) |  | [optional] 
**custom_action** | [**AzureAutoHealCustomAction**](AzureAutoHealCustomAction.md) |  | [optional] 
**min_process_execution_time** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_auto_heal_actions import AzureAutoHealActions

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutoHealActions from a JSON string
azure_auto_heal_actions_instance = AzureAutoHealActions.from_json(json)
# print the JSON string representation of the object
print(AzureAutoHealActions.to_json())

# convert the object into a dict
azure_auto_heal_actions_dict = azure_auto_heal_actions_instance.to_dict()
# create an instance of AzureAutoHealActions from a dict
azure_auto_heal_actions_from_dict = AzureAutoHealActions.from_dict(azure_auto_heal_actions_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


