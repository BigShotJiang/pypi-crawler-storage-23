# AzureManagedServiceIdentityType



## Enum

* `NONE_` (value: `'None'`)

* `SystemAssigned` (value: `'SystemAssigned'`)

* `UserAssigned` (value: `'UserAssigned'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


