# AzureProvisioningState



## Enum

* `Succeeded` (value: `'Succeeded'`)

* `Failed` (value: `'Failed'`)

* `Canceled` (value: `'Canceled'`)

* `InProgress` (value: `'InProgress'`)

* `Deleting` (value: `'Deleting'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


