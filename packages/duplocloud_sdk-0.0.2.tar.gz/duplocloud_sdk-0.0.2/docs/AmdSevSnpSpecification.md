# AmdSevSnpSpecification


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amd_sev_snp_specification import AmdSevSnpSpecification

# TODO update the JSON string below
json = "{}"
# create an instance of AmdSevSnpSpecification from a JSON string
amd_sev_snp_specification_instance = AmdSevSnpSpecification.from_json(json)
# print the JSON string representation of the object
print(AmdSevSnpSpecification.to_json())

# convert the object into a dict
amd_sev_snp_specification_dict = amd_sev_snp_specification_instance.to_dict()
# create an instance of AmdSevSnpSpecification from a dict
amd_sev_snp_specification_from_dict = AmdSevSnpSpecification.from_dict(amd_sev_snp_specification_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


