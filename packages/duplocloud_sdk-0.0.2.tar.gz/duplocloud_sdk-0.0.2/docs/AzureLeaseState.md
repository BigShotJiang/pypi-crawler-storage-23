# AzureLeaseState



## Enum

* `Unspecified` (value: `0`)

* `Available` (value: `1`)

* `Leased` (value: `2`)

* `Expired` (value: `3`)

* `Breaking` (value: `4`)

* `Broken` (value: `5`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


