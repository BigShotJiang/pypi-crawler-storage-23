# AwsLBBackendConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name_ex** | **str** |  | [optional] 
**instance_protocol** | **str** |  | [optional] 
**frontend_port** | **int** |  | [optional] 
**backend_port** | **int** |  | [optional] 
**monitor** | **int** |  | [optional] 
**certificate_arn** | **str** |  | [optional] 
**protocol** | **str** |  | [optional] 
**protocol_version** | **str** |  | [optional] 
**alpn_policy** | **str** |  | [optional] 
**health_check_url** | **str** |  | [optional] 
**lb_type** | [**LBType**](LBType.md) |  | [optional] 
**lb_target_type** | [**LBTargetType**](LBTargetType.md) |  | [optional] 
**tg_count** | **int** |  | [optional] 
**health_check_config** | [**LbHealthCheckConfig**](LbHealthCheckConfig.md) |  | [optional] 
**tg_arn** | **str** |  | [optional] 
**custom_cidrs** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_lb_backend_configuration import AwsLBBackendConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLBBackendConfiguration from a JSON string
aws_lb_backend_configuration_instance = AwsLBBackendConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsLBBackendConfiguration.to_json())

# convert the object into a dict
aws_lb_backend_configuration_dict = aws_lb_backend_configuration_instance.to_dict()
# create an instance of AwsLBBackendConfiguration from a dict
aws_lb_backend_configuration_from_dict = AwsLBBackendConfiguration.from_dict(aws_lb_backend_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


