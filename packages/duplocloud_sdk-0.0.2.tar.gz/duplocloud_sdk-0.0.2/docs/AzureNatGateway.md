# AzureNatGateway


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**sku** | [**AzureNatGatewaySku**](AzureNatGatewaySku.md) |  | [optional] 
**properties_idle_timeout_in_minutes** | **int** |  | [optional] 
**properties_public_ip_addresses** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_public_ip_prefixes** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_subnets** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_resource_guid** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**zones** | **List[str]** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_nat_gateway import AzureNatGateway

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNatGateway from a JSON string
azure_nat_gateway_instance = AzureNatGateway.from_json(json)
# print the JSON string representation of the object
print(AzureNatGateway.to_json())

# convert the object into a dict
azure_nat_gateway_dict = azure_nat_gateway_instance.to_dict()
# create an instance of AzureNatGateway from a dict
azure_nat_gateway_from_dict = AzureNatGateway.from_dict(azure_nat_gateway_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


