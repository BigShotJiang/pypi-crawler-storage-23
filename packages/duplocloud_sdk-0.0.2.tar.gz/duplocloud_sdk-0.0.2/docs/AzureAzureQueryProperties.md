# AzureAzureQueryProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**scope** | **List[str]** |  | [optional] 
**locations** | **List[str]** |  | [optional] 
**tag_settings** | [**AzureTagSettingsProperties**](AzureTagSettingsProperties.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_azure_query_properties import AzureAzureQueryProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAzureQueryProperties from a JSON string
azure_azure_query_properties_instance = AzureAzureQueryProperties.from_json(json)
# print the JSON string representation of the object
print(AzureAzureQueryProperties.to_json())

# convert the object into a dict
azure_azure_query_properties_dict = azure_azure_query_properties_instance.to_dict()
# create an instance of AzureAzureQueryProperties from a dict
azure_azure_query_properties_from_dict = AzureAzureQueryProperties.from_dict(azure_azure_query_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


