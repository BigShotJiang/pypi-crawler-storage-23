# AwsAttachment


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**details** | [**List[AwsKeyValuePair]**](AwsKeyValuePair.md) |  | [optional] 
**id** | **str** |  | [optional] 
**status** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_attachment import AwsAttachment

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAttachment from a JSON string
aws_attachment_instance = AwsAttachment.from_json(json)
# print the JSON string representation of the object
print(AwsAttachment.to_json())

# convert the object into a dict
aws_attachment_dict = aws_attachment_instance.to_dict()
# create an instance of AwsAttachment from a dict
aws_attachment_from_dict = AwsAttachment.from_dict(aws_attachment_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


