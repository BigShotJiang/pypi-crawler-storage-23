# AzureDatabase3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**sku** | [**AzureSku3**](AzureSku3.md) |  | [optional] 
**kind** | **str** |  | [optional] 
**managed_by** | **str** |  | [optional] 
**properties_create_mode** | **str** |  | [optional] 
**properties_collation** | **str** |  | [optional] 
**properties_max_size_bytes** | **int** |  | [optional] 
**properties_sample_name** | **str** |  | [optional] 
**properties_elastic_pool_id** | **str** |  | [optional] 
**properties_source_database_id** | **str** |  | [optional] 
**properties_status** | **str** |  | [optional] 
**properties_database_id** | **str** |  | [optional] 
**properties_creation_date** | **datetime** |  | [optional] 
**properties_current_service_objective_name** | **str** |  | [optional] 
**properties_requested_service_objective_name** | **str** |  | [optional] 
**properties_default_secondary_location** | **str** |  | [optional] 
**properties_failover_group_id** | **str** |  | [optional] 
**properties_restore_point_in_time** | **datetime** |  | [optional] 
**properties_source_database_deletion_date** | **datetime** |  | [optional] 
**properties_recovery_services_recovery_point_id** | **str** |  | [optional] 
**properties_long_term_retention_backup_resource_id** | **str** |  | [optional] 
**properties_recoverable_database_id** | **str** |  | [optional] 
**properties_restorable_dropped_database_id** | **str** |  | [optional] 
**properties_catalog_collation** | **str** |  | [optional] 
**properties_zone_redundant** | **bool** |  | [optional] 
**properties_license_type** | **str** |  | [optional] 
**properties_max_log_size_bytes** | **int** |  | [optional] 
**properties_earliest_restore_date** | **datetime** |  | [optional] 
**properties_read_scale** | **str** |  | [optional] 
**properties_read_replica_count** | **int** |  | [optional] 
**properties_current_sku** | [**AzureSku3**](AzureSku3.md) |  | [optional] 
**properties_auto_pause_delay** | **int** |  | [optional] 
**properties_min_capacity** | **float** |  | [optional] 
**properties_paused_date** | **datetime** |  | [optional] 
**properties_resumed_date** | **datetime** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_database3 import AzureDatabase3

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDatabase3 from a JSON string
azure_database3_instance = AzureDatabase3.from_json(json)
# print the JSON string representation of the object
print(AzureDatabase3.to_json())

# convert the object into a dict
azure_database3_dict = azure_database3_instance.to_dict()
# create an instance of AzureDatabase3 from a dict
azure_database3_from_dict = AzureDatabase3.from_dict(azure_database3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


