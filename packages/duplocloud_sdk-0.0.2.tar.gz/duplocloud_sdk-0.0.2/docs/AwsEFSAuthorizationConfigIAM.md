# AwsEFSAuthorizationConfigIAM


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_efs_authorization_config_iam import AwsEFSAuthorizationConfigIAM

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEFSAuthorizationConfigIAM from a JSON string
aws_efs_authorization_config_iam_instance = AwsEFSAuthorizationConfigIAM.from_json(json)
# print the JSON string representation of the object
print(AwsEFSAuthorizationConfigIAM.to_json())

# convert the object into a dict
aws_efs_authorization_config_iam_dict = aws_efs_authorization_config_iam_instance.to_dict()
# create an instance of AwsEFSAuthorizationConfigIAM from a dict
aws_efs_authorization_config_iam_from_dict = AwsEFSAuthorizationConfigIAM.from_dict(aws_efs_authorization_config_iam_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


