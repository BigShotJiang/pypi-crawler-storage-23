# AzureAgentPool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **str** |  | [optional] 
**friendly_name** | **str** |  | [optional] 
**computer_name** | **str** |  | [optional] 
**image_id** | **str** |  | [optional] 
**capacity** | **str** |  | [optional] 
**is_minion** | **bool** |  | [optional] 
**zone** | [**AvailabilityZone**](AvailabilityZone.md) |  | [optional] 
**volumes** | [**List[NativeHostVolume]**](NativeHostVolume.md) |  | [optional] 
**tags** | [**List[KeyValuePairOfStringAndString]**](KeyValuePairOfStringAndString.md) |  | [optional] 
**tags_ex** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**tags_csv** | **str** |  | [optional] 
**base64_user_data** | **str** |  | [optional] 
**shutdown_behavior** | **str** |  | [optional] 
**agent_platform** | [**Platform**](Platform.md) |  | [optional] 
**is_ebs_optimized** | **bool** |  | [optional] 
**cloud** | [**CloudPlatform**](CloudPlatform.md) |  | [optional] 
**spot_price** | **str** |  | [optional] 
**allocated_public_ip** | **bool** |  | [optional] 
**network_interfaces** | [**List[NativeHostNetworkInterface]**](NativeHostNetworkInterface.md) |  | [optional] 
**meta_data** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**minion_tags** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**encrypt_disk** | **bool** |  | [optional] 
**key_pair_type** | [**KeyPairType**](KeyPairType.md) |  | [optional] 
**is_user_data_combined** | **bool** |  | [optional] 
**dedicated_host_id** | **str** |  | [optional] 
**extra_node_labels** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**taints** | [**List[Taint]**](Taint.md) |  | [optional] 
**disk_controller_type** | **str** |  | [optional] 
**install_duplo_native_agent** | **bool** |  | [optional] 
**security_type** | **str** |  | [optional] 
**is_encrypt_at_host** | **bool** |  | [optional] 
**is_secure_boot** | **bool** |  | [optional] 
**isv_tpm** | **bool** |  | [optional] 
**availability_set_id** | **str** |  | [optional] 
**k8s_worker_os** | [**K8SWorkerOs**](K8SWorkerOs.md) |  | [optional] 
**custom_data_tags** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**availability_zones** | **List[str]** |  | [optional] 
**node_taints** | **List[str]** |  | [optional] 
**node_labels** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**desired_capacity** | **int** |  | [optional] 
**max_size** | **int** |  | [optional] 
**min_size** | **int** |  | [optional] 
**state** | **str** |  | [optional] 
**subnet_id** | **str** |  | [optional] 
**enable_auto_scaling** | **bool** |  | [optional] 
**scale_set_priority** | **str** |  | [optional] 
**scale_set_eviction_policy** | **str** |  | [optional] 
**spot_max_price** | **float** |  | [optional] 
**max_pods** | **int** |  | [optional] 
**os_sku** | **str** |  | [optional] 
**os_disk_size_gb** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_agent_pool import AzureAgentPool

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAgentPool from a JSON string
azure_agent_pool_instance = AzureAgentPool.from_json(json)
# print the JSON string representation of the object
print(AzureAgentPool.to_json())

# convert the object into a dict
azure_agent_pool_dict = azure_agent_pool_instance.to_dict()
# create an instance of AzureAgentPool from a dict
azure_agent_pool_from_dict = AzureAgentPool.from_dict(azure_agent_pool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


