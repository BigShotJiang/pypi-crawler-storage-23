# AzureLeaseDuration



## Enum

* `Unspecified` (value: `0`)

* `Fixed` (value: `1`)

* `Infinite` (value: `2`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


