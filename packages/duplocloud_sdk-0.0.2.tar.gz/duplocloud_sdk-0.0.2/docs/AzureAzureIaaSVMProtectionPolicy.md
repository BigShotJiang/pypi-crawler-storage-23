# AzureAzureIaaSVMProtectionPolicy


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**protected_items_count** | **int** |  | [optional] 
**instant_rp_details** | [**AzureInstantRPAdditionalDetails**](AzureInstantRPAdditionalDetails.md) |  | [optional] 
**schedule_policy** | **object** |  | [optional] 
**retention_policy** | **object** |  | [optional] 
**instant_rp_retention_range_in_days** | **int** |  | [optional] 
**time_zone** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_azure_iaa_svm_protection_policy import AzureAzureIaaSVMProtectionPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAzureIaaSVMProtectionPolicy from a JSON string
azure_azure_iaa_svm_protection_policy_instance = AzureAzureIaaSVMProtectionPolicy.from_json(json)
# print the JSON string representation of the object
print(AzureAzureIaaSVMProtectionPolicy.to_json())

# convert the object into a dict
azure_azure_iaa_svm_protection_policy_dict = azure_azure_iaa_svm_protection_policy_instance.to_dict()
# create an instance of AzureAzureIaaSVMProtectionPolicy from a dict
azure_azure_iaa_svm_protection_policy_from_dict = AzureAzureIaaSVMProtectionPolicy.from_dict(azure_azure_iaa_svm_protection_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


