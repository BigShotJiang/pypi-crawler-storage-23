# AwsKernelCapabilities


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**add** | **List[str]** |  | [optional] 
**drop** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_kernel_capabilities import AwsKernelCapabilities

# TODO update the JSON string below
json = "{}"
# create an instance of AwsKernelCapabilities from a JSON string
aws_kernel_capabilities_instance = AwsKernelCapabilities.from_json(json)
# print the JSON string representation of the object
print(AwsKernelCapabilities.to_json())

# convert the object into a dict
aws_kernel_capabilities_dict = aws_kernel_capabilities_instance.to_dict()
# create an instance of AwsKernelCapabilities from a dict
aws_kernel_capabilities_from_dict = AwsKernelCapabilities.from_dict(aws_kernel_capabilities_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


