# AzureDiffDiskSettings

Describes the parameters of ephemeral disk settings that can be specified for operating system disk. <br><br> NOTE: The ephemeral disk settings can only be specified for managed disk.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**option** | **str** | Gets or sets specifies the ephemeral disk settings for operating system disk. Possible values include: &#39;Local&#39; | [optional] 
**placement** | **str** | Gets or sets specifies the ephemeral disk placement for operating system disk.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Possible values are: &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **CacheDisk** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; **ResourceDisk** &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Default: **CacheDisk** if one is configured for the VM size otherwise **ResourceDisk** is used.&amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Refer to VM size documentation for Windows VM at https://docs.microsoft.com/azure/virtual-machines/windows/sizes and Linux VM at https://docs.microsoft.com/azure/virtual-machines/linux/sizes to check which VM sizes exposes a cache disk. Possible values include: &#39;CacheDisk&#39;, &#39;ResourceDisk&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_diff_disk_settings import AzureDiffDiskSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDiffDiskSettings from a JSON string
azure_diff_disk_settings_instance = AzureDiffDiskSettings.from_json(json)
# print the JSON string representation of the object
print(AzureDiffDiskSettings.to_json())

# convert the object into a dict
azure_diff_disk_settings_dict = azure_diff_disk_settings_instance.to_dict()
# create an instance of AzureDiffDiskSettings from a dict
azure_diff_disk_settings_from_dict = AzureDiffDiskSettings.from_dict(azure_diff_disk_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


