# AzurePrivateEndpointProperty


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource id of the private endpoint. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_property import AzurePrivateEndpointProperty

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointProperty from a JSON string
azure_private_endpoint_property_instance = AzurePrivateEndpointProperty.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointProperty.to_json())

# convert the object into a dict
azure_private_endpoint_property_dict = azure_private_endpoint_property_instance.to_dict()
# create an instance of AzurePrivateEndpointProperty from a dict
azure_private_endpoint_property_from_dict = AzurePrivateEndpointProperty.from_dict(azure_private_endpoint_property_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


