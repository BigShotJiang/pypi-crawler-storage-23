# AwsDeploymentConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alarms** | [**AwsDeploymentAlarms**](AwsDeploymentAlarms.md) |  | [optional] 
**bake_time_in_minutes** | **int** |  | [optional] 
**deployment_circuit_breaker** | [**AwsDeploymentCircuitBreaker**](AwsDeploymentCircuitBreaker.md) |  | [optional] 
**lifecycle_hooks** | [**List[AwsDeploymentLifecycleHook]**](AwsDeploymentLifecycleHook.md) |  | [optional] 
**maximum_percent** | **int** |  | [optional] 
**minimum_healthy_percent** | **int** |  | [optional] 
**strategy** | [**AwsDeploymentStrategy**](AwsDeploymentStrategy.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_configuration import AwsDeploymentConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentConfiguration from a JSON string
aws_deployment_configuration_instance = AwsDeploymentConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentConfiguration.to_json())

# convert the object into a dict
aws_deployment_configuration_dict = aws_deployment_configuration_instance.to_dict()
# create an instance of AwsDeploymentConfiguration from a dict
aws_deployment_configuration_from_dict = AwsDeploymentConfiguration.from_dict(aws_deployment_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


