# AdminSystemSettingDto


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key** | **str** |  | [optional] 
**value** | **str** |  | [optional] 
**all_layers_allowed** | **bool** |  | [optional] 
**is_auth_by_iam** | **bool** |  | [optional] 
**enable_aws_resource_management_by_tags** | **bool** |  | [optional] 
**aws_default_region** | **str** |  | [optional] 
**aws_internal_elb_subnet** | **str** |  | [optional] 
**aws_key** | **str** |  | [optional] 
**aws_value** | **str** |  | [optional] 
**aws_account_id** | **str** |  | [optional] 
**aws_extra_regions** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.admin_system_setting_dto import AdminSystemSettingDto

# TODO update the JSON string below
json = "{}"
# create an instance of AdminSystemSettingDto from a JSON string
admin_system_setting_dto_instance = AdminSystemSettingDto.from_json(json)
# print the JSON string representation of the object
print(AdminSystemSettingDto.to_json())

# convert the object into a dict
admin_system_setting_dto_dict = admin_system_setting_dto_instance.to_dict()
# create an instance of AdminSystemSettingDto from a dict
admin_system_setting_dto_from_dict = AdminSystemSettingDto.from_dict(admin_system_setting_dto_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


