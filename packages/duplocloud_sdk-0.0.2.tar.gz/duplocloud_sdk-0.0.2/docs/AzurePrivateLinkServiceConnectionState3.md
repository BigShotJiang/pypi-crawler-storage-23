# AzurePrivateLinkServiceConnectionState3

A collection of information about the state of the connection between service consumer and provider.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Gets or sets indicates whether the connection has been Approved/Rejected/Removed by the owner of the service. Possible values include: &#39;Pending&#39;, &#39;Approved&#39;, &#39;Rejected&#39; | [optional] 
**description** | **str** | Gets or sets the reason for approval/rejection of the connection. | [optional] 
**actions_required** | **str** | Gets or sets a message indicating if changes on the service provider require any updates on the consumer. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_connection_state3 import AzurePrivateLinkServiceConnectionState3

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceConnectionState3 from a JSON string
azure_private_link_service_connection_state3_instance = AzurePrivateLinkServiceConnectionState3.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceConnectionState3.to_json())

# convert the object into a dict
azure_private_link_service_connection_state3_dict = azure_private_link_service_connection_state3_instance.to_dict()
# create an instance of AzurePrivateLinkServiceConnectionState3 from a dict
azure_private_link_service_connection_state3_from_dict = AzurePrivateLinkServiceConnectionState3.from_dict(azure_private_link_service_connection_state3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


