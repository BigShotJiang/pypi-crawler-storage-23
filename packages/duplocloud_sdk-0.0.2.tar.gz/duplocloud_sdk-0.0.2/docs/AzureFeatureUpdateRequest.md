# AzureFeatureUpdateRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**component_id** | **str** |  | [optional] 
**feature_name** | **str** |  | [optional] 
**disable** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_feature_update_request import AzureFeatureUpdateRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFeatureUpdateRequest from a JSON string
azure_feature_update_request_instance = AzureFeatureUpdateRequest.from_json(json)
# print the JSON string representation of the object
print(AzureFeatureUpdateRequest.to_json())

# convert the object into a dict
azure_feature_update_request_dict = azure_feature_update_request_instance.to_dict()
# create an instance of AzureFeatureUpdateRequest from a dict
azure_feature_update_request_from_dict = AzureFeatureUpdateRequest.from_dict(azure_feature_update_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


