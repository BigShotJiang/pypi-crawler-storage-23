# AwsCapacityProviderStrategyItem


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base** | **int** |  | [optional] 
**capacity_provider** | **str** |  | [optional] 
**weight** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_capacity_provider_strategy_item import AwsCapacityProviderStrategyItem

# TODO update the JSON string below
json = "{}"
# create an instance of AwsCapacityProviderStrategyItem from a JSON string
aws_capacity_provider_strategy_item_instance = AwsCapacityProviderStrategyItem.from_json(json)
# print the JSON string representation of the object
print(AwsCapacityProviderStrategyItem.to_json())

# convert the object into a dict
aws_capacity_provider_strategy_item_dict = aws_capacity_provider_strategy_item_instance.to_dict()
# create an instance of AwsCapacityProviderStrategyItem from a dict
aws_capacity_provider_strategy_item_from_dict = AwsCapacityProviderStrategyItem.from_dict(aws_capacity_provider_strategy_item_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


