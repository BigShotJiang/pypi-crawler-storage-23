# AzureAdditionalUnattendContent

Specifies additional XML formatted information that can be included in the Unattend.xml file, which is used by Windows Setup. Contents are defined by setting name, component name, and the pass in which the content is applied.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**pass_name** | [**AzurePassNames**](AzurePassNames.md) | Gets or sets the pass name. Currently, the only allowable value is OobeSystem. Possible values include: &#39;OobeSystem&#39; | [optional] 
**component_name** | [**AzureComponentNames**](AzureComponentNames.md) | Gets or sets the component name. Currently, the only allowable value is Microsoft-Windows-Shell-Setup. Possible values include: &#39;Microsoft-Windows-Shell-Setup&#39; | [optional] 
**setting_name** | [**AzureSettingNames**](AzureSettingNames.md) | Gets or sets specifies the name of the setting to which the content applies. Possible values are: FirstLogonCommands and AutoLogon. Possible values include: &#39;AutoLogon&#39;, &#39;FirstLogonCommands&#39; | [optional] 
**content** | **str** | Gets or sets specifies the XML formatted content that is added to the unattend.xml file for the specified path and component. The XML must be less than 4KB and must include the root element for the setting or feature that is being inserted. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_additional_unattend_content import AzureAdditionalUnattendContent

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAdditionalUnattendContent from a JSON string
azure_additional_unattend_content_instance = AzureAdditionalUnattendContent.from_json(json)
# print the JSON string representation of the object
print(AzureAdditionalUnattendContent.to_json())

# convert the object into a dict
azure_additional_unattend_content_dict = azure_additional_unattend_content_instance.to_dict()
# create an instance of AzureAdditionalUnattendContent from a dict
azure_additional_unattend_content_from_dict = AzureAdditionalUnattendContent.from_dict(azure_additional_unattend_content_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


