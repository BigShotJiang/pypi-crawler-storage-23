# AzureAvailablePatchSummary

Describes the properties of an virtual machine instance view for available patch summary.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**status** | **str** | Gets the overall success or failure status of the operation. It remains \&quot;InProgress\&quot; until the operation completes. At that point it will become \&quot;Unknown\&quot;, \&quot;Failed\&quot;, \&quot;Succeeded\&quot;, or \&quot;CompletedWithWarnings.\&quot;. Possible values include: &#39;Unknown&#39;, &#39;InProgress&#39;, &#39;Failed&#39;, &#39;Succeeded&#39;, &#39;CompletedWithWarnings&#39; | [optional] 
**assessment_activity_id** | **str** | Gets the activity ID of the operation that produced this result. It is used to correlate across CRP and extension logs. | [optional] 
**reboot_pending** | **bool** | Gets the overall reboot status of the VM. It will be true when partially installed patches require a reboot to complete installation but the reboot has not yet occurred. | [optional] 
**critical_and_security_patch_count** | **int** | Gets the number of critical or security patches that have been detected as available and not yet installed. | [optional] 
**other_patch_count** | **int** | Gets the number of all available patches excluding critical and security. | [optional] 
**start_time** | **datetime** | Gets the UTC timestamp when the operation began. | [optional] 
**last_modified_time** | **datetime** | Gets the UTC timestamp when the operation began. | [optional] 
**error** | [**AzureApiError**](AzureApiError.md) | Gets the errors that were encountered during execution of the operation. The details array contains the list of them. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_available_patch_summary import AzureAvailablePatchSummary

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAvailablePatchSummary from a JSON string
azure_available_patch_summary_instance = AzureAvailablePatchSummary.from_json(json)
# print the JSON string representation of the object
print(AzureAvailablePatchSummary.to_json())

# convert the object into a dict
azure_available_patch_summary_dict = azure_available_patch_summary_instance.to_dict()
# create an instance of AzureAvailablePatchSummary from a dict
azure_available_patch_summary_from_dict = AzureAvailablePatchSummary.from_dict(azure_available_patch_summary_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


