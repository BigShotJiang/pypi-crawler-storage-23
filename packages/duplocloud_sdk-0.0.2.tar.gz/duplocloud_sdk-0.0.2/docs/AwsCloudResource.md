# AwsCloudResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**resource_tags** | **Dict[str, str]** |  | [optional] 
**state** | **str** |  | [optional] 
**resource_type** | [**CloudResourceType**](CloudResourceType.md) |  | [optional] 
**meta_data** | **str** |  | [optional] 
**meta_data_object** | **object** |  | [optional] 
**arn** | **str** |  | [optional] 
**status** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_cloud_resource import AwsCloudResource

# TODO update the JSON string below
json = "{}"
# create an instance of AwsCloudResource from a JSON string
aws_cloud_resource_instance = AwsCloudResource.from_json(json)
# print the JSON string representation of the object
print(AwsCloudResource.to_json())

# convert the object into a dict
aws_cloud_resource_dict = aws_cloud_resource_instance.to_dict()
# create an instance of AwsCloudResource from a dict
aws_cloud_resource_from_dict = AwsCloudResource.from_dict(aws_cloud_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


