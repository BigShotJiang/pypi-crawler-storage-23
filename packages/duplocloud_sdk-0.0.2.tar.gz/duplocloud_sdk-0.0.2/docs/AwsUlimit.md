# AwsUlimit


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hard_limit** | **int** |  | [optional] 
**name** | [**AwsUlimitName**](AwsUlimitName.md) |  | [optional] 
**soft_limit** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ulimit import AwsUlimit

# TODO update the JSON string below
json = "{}"
# create an instance of AwsUlimit from a JSON string
aws_ulimit_instance = AwsUlimit.from_json(json)
# print the JSON string representation of the object
print(AwsUlimit.to_json())

# convert the object into a dict
aws_ulimit_dict = aws_ulimit_instance.to_dict()
# create an instance of AwsUlimit from a dict
aws_ulimit_from_dict = AwsUlimit.from_dict(aws_ulimit_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


