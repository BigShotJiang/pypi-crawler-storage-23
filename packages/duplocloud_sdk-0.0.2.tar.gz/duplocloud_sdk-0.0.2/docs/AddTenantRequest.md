# AddTenantRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**plan_id** | **str** |  | [optional] 
**account_name** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**existing_k8s_namespace** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.add_tenant_request import AddTenantRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AddTenantRequest from a JSON string
add_tenant_request_instance = AddTenantRequest.from_json(json)
# print the JSON string representation of the object
print(AddTenantRequest.to_json())

# convert the object into a dict
add_tenant_request_dict = add_tenant_request_instance.to_dict()
# create an instance of AddTenantRequest from a dict
add_tenant_request_from_dict = AddTenantRequest.from_dict(add_tenant_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


