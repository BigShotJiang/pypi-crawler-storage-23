# AzureJitNetworkAccessPolicyInitiateVirtualMachine


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource ID of the virtual machine that is linked to this policy | [optional] 
**ports** | [**List[AzureJitNetworkAccessPolicyInitiatePort]**](AzureJitNetworkAccessPolicyInitiatePort.md) | Gets or sets the ports to open for the resource with the &#x60;id&#x60; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_jit_network_access_policy_initiate_virtual_machine import AzureJitNetworkAccessPolicyInitiateVirtualMachine

# TODO update the JSON string below
json = "{}"
# create an instance of AzureJitNetworkAccessPolicyInitiateVirtualMachine from a JSON string
azure_jit_network_access_policy_initiate_virtual_machine_instance = AzureJitNetworkAccessPolicyInitiateVirtualMachine.from_json(json)
# print the JSON string representation of the object
print(AzureJitNetworkAccessPolicyInitiateVirtualMachine.to_json())

# convert the object into a dict
azure_jit_network_access_policy_initiate_virtual_machine_dict = azure_jit_network_access_policy_initiate_virtual_machine_instance.to_dict()
# create an instance of AzureJitNetworkAccessPolicyInitiateVirtualMachine from a dict
azure_jit_network_access_policy_initiate_virtual_machine_from_dict = AzureJitNetworkAccessPolicyInitiateVirtualMachine.from_dict(azure_jit_network_access_policy_initiate_virtual_machine_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


