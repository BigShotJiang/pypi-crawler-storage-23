# AzureRecoveryPointResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**e_tag** | **str** |  | [optional] 
**properties** | **object** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_recovery_point_resource import AzureRecoveryPointResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRecoveryPointResource from a JSON string
azure_recovery_point_resource_instance = AzureRecoveryPointResource.from_json(json)
# print the JSON string representation of the object
print(AzureRecoveryPointResource.to_json())

# convert the object into a dict
azure_recovery_point_resource_dict = azure_recovery_point_resource_instance.to_dict()
# create an instance of AzureRecoveryPointResource from a dict
azure_recovery_point_resource_from_dict = AzureRecoveryPointResource.from_dict(azure_recovery_point_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


