# AwsRepositoryCredentials


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**credentials_parameter** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_repository_credentials import AwsRepositoryCredentials

# TODO update the JSON string below
json = "{}"
# create an instance of AwsRepositoryCredentials from a JSON string
aws_repository_credentials_instance = AwsRepositoryCredentials.from_json(json)
# print the JSON string representation of the object
print(AwsRepositoryCredentials.to_json())

# convert the object into a dict
aws_repository_credentials_dict = aws_repository_credentials_instance.to_dict()
# create an instance of AwsRepositoryCredentials from a dict
aws_repository_credentials_from_dict = AwsRepositoryCredentials.from_dict(aws_repository_credentials_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


