# AzureHttpProtocol

Defines values for HttpProtocol.

## Enum

* `Httpshttp` (value: `'https,http'`)

* `Https` (value: `'https'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


