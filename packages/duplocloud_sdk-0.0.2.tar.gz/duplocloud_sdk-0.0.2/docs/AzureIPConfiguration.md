# AzureIPConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_private_ip_address** | **str** |  | [optional] 
**properties_private_ip_allocation_method** | **str** |  | [optional] 
**properties_subnet** | [**AzureSubnet**](AzureSubnet.md) |  | [optional] 
**properties_public_ip_address** | [**AzurePublicIPAddress**](AzurePublicIPAddress.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_configuration import AzureIPConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIPConfiguration from a JSON string
azure_ip_configuration_instance = AzureIPConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureIPConfiguration.to_json())

# convert the object into a dict
azure_ip_configuration_dict = azure_ip_configuration_instance.to_dict()
# create an instance of AzureIPConfiguration from a dict
azure_ip_configuration_from_dict = AzureIPConfiguration.from_dict(azure_ip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


