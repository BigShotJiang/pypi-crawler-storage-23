# AmazonWAFV2Request


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_wafv2_request import AmazonWAFV2Request

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonWAFV2Request from a JSON string
amazon_wafv2_request_instance = AmazonWAFV2Request.from_json(json)
# print the JSON string representation of the object
print(AmazonWAFV2Request.to_json())

# convert the object into a dict
amazon_wafv2_request_dict = amazon_wafv2_request_instance.to_dict()
# create an instance of AmazonWAFV2Request from a dict
amazon_wafv2_request_from_dict = AmazonWAFV2Request.from_dict(amazon_wafv2_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


