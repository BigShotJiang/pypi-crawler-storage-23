# AwsProxyConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_name** | **str** |  | [optional] 
**properties** | [**List[AwsKeyValuePair]**](AwsKeyValuePair.md) |  | [optional] 
**type** | [**AwsProxyConfigurationType**](AwsProxyConfigurationType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_proxy_configuration import AwsProxyConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsProxyConfiguration from a JSON string
aws_proxy_configuration_instance = AwsProxyConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsProxyConfiguration.to_json())

# convert the object into a dict
aws_proxy_configuration_dict = aws_proxy_configuration_instance.to_dict()
# create an instance of AwsProxyConfiguration from a dict
aws_proxy_configuration_from_dict = AwsProxyConfiguration.from_dict(aws_proxy_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


