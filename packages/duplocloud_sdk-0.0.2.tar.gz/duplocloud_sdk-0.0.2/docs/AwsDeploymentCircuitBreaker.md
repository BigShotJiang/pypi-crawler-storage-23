# AwsDeploymentCircuitBreaker


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enable** | **bool** |  | [optional] 
**rollback** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_circuit_breaker import AwsDeploymentCircuitBreaker

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentCircuitBreaker from a JSON string
aws_deployment_circuit_breaker_instance = AwsDeploymentCircuitBreaker.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentCircuitBreaker.to_json())

# convert the object into a dict
aws_deployment_circuit_breaker_dict = aws_deployment_circuit_breaker_instance.to_dict()
# create an instance of AwsDeploymentCircuitBreaker from a dict
aws_deployment_circuit_breaker_from_dict = AwsDeploymentCircuitBreaker.from_dict(aws_deployment_circuit_breaker_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


