# AzurePrivateLinkScopedResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**resource_id** | **str** |  | [optional] 
**scope_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_scoped_resource import AzurePrivateLinkScopedResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkScopedResource from a JSON string
azure_private_link_scoped_resource_instance = AzurePrivateLinkScopedResource.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkScopedResource.to_json())

# convert the object into a dict
azure_private_link_scoped_resource_dict = azure_private_link_scoped_resource_instance.to_dict()
# create an instance of AzurePrivateLinkScopedResource from a dict
azure_private_link_scoped_resource_from_dict = AzurePrivateLinkScopedResource.from_dict(azure_private_link_scoped_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


