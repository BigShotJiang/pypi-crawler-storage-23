# AddVpnConnectionRouteRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vpn_connection_id** | **str** |  | [optional] 
**route_cidr** | **str** |  | [optional] 
**infra_name** | **str** |  | [optional] 
**region** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.add_vpn_connection_route_request import AddVpnConnectionRouteRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AddVpnConnectionRouteRequest from a JSON string
add_vpn_connection_route_request_instance = AddVpnConnectionRouteRequest.from_json(json)
# print the JSON string representation of the object
print(AddVpnConnectionRouteRequest.to_json())

# convert the object into a dict
add_vpn_connection_route_request_dict = add_vpn_connection_route_request_instance.to_dict()
# create an instance of AddVpnConnectionRouteRequest from a dict
add_vpn_connection_route_request_from_dict = AddVpnConnectionRouteRequest.from_dict(add_vpn_connection_route_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


