# AzureIaasVMRestoreRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**recovery_point_id** | **str** |  | [optional] 
**recovery_type** | **str** |  | [optional] 
**source_resource_id** | **str** |  | [optional] 
**target_virtual_machine_id** | **str** |  | [optional] 
**target_resource_group_id** | **str** |  | [optional] 
**storage_account_id** | **str** |  | [optional] 
**virtual_network_id** | **str** |  | [optional] 
**subnet_id** | **str** |  | [optional] 
**target_domain_name_id** | **str** |  | [optional] 
**region** | **str** |  | [optional] 
**affinity_group** | **str** |  | [optional] 
**create_new_cloud_service** | **bool** |  | [optional] 
**original_storage_account_option** | **bool** |  | [optional] 
**encryption_details** | [**AzureEncryptionDetails**](AzureEncryptionDetails.md) |  | [optional] 
**restore_disk_lun_list** | **List[int]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_iaas_vm_restore_request import AzureIaasVMRestoreRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIaasVMRestoreRequest from a JSON string
azure_iaas_vm_restore_request_instance = AzureIaasVMRestoreRequest.from_json(json)
# print the JSON string representation of the object
print(AzureIaasVMRestoreRequest.to_json())

# convert the object into a dict
azure_iaas_vm_restore_request_dict = azure_iaas_vm_restore_request_instance.to_dict()
# create an instance of AzureIaasVMRestoreRequest from a dict
azure_iaas_vm_restore_request_from_dict = AzureIaasVMRestoreRequest.from_dict(azure_iaas_vm_restore_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


