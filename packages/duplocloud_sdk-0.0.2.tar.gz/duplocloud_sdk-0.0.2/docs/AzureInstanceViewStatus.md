# AzureInstanceViewStatus

Instance view status.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **str** | Gets or sets the status code. | [optional] 
**level** | [**AzureStatusLevelTypes**](AzureStatusLevelTypes.md) | Gets or sets the level code. Possible values include: &#39;Info&#39;, &#39;Warning&#39;, &#39;Error&#39; | [optional] 
**display_status** | **str** | Gets or sets the short localizable label for the status. | [optional] 
**message** | **str** | Gets or sets the detailed status message, including for alerts and error messages. | [optional] 
**time** | **datetime** | Gets or sets the time of the status. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_instance_view_status import AzureInstanceViewStatus

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInstanceViewStatus from a JSON string
azure_instance_view_status_instance = AzureInstanceViewStatus.from_json(json)
# print the JSON string representation of the object
print(AzureInstanceViewStatus.to_json())

# convert the object into a dict
azure_instance_view_status_dict = azure_instance_view_status_instance.to_dict()
# create an instance of AzureInstanceViewStatus from a dict
azure_instance_view_status_from_dict = AzureInstanceViewStatus.from_dict(azure_instance_view_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


