# AccessLogSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**destination_arn** | **str** |  | [optional] 
**format** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.access_log_settings import AccessLogSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AccessLogSettings from a JSON string
access_log_settings_instance = AccessLogSettings.from_json(json)
# print the JSON string representation of the object
print(AccessLogSettings.to_json())

# convert the object into a dict
access_log_settings_dict = access_log_settings_instance.to_dict()
# create an instance of AccessLogSettings from a dict
access_log_settings_from_dict = AccessLogSettings.from_dict(access_log_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


