# AwsUlimitName


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ulimit_name import AwsUlimitName

# TODO update the JSON string below
json = "{}"
# create an instance of AwsUlimitName from a JSON string
aws_ulimit_name_instance = AwsUlimitName.from_json(json)
# print the JSON string representation of the object
print(AwsUlimitName.to_json())

# convert the object into a dict
aws_ulimit_name_dict = aws_ulimit_name_instance.to_dict()
# create an instance of AwsUlimitName from a dict
aws_ulimit_name_from_dict = AwsUlimitName.from_dict(aws_ulimit_name_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


