# AwsLoadBalancer


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**advanced_configuration** | [**AwsAdvancedConfiguration**](AwsAdvancedConfiguration.md) |  | [optional] 
**container_name** | **str** |  | [optional] 
**container_port** | **int** |  | [optional] 
**load_balancer_name** | **str** |  | [optional] 
**target_group_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_load_balancer import AwsLoadBalancer

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLoadBalancer from a JSON string
aws_load_balancer_instance = AwsLoadBalancer.from_json(json)
# print the JSON string representation of the object
print(AwsLoadBalancer.to_json())

# convert the object into a dict
aws_load_balancer_dict = aws_load_balancer_instance.to_dict()
# create an instance of AwsLoadBalancer from a dict
aws_load_balancer_from_dict = AwsLoadBalancer.from_dict(aws_load_balancer_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


