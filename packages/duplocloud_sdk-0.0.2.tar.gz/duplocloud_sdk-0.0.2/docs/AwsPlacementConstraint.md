# AwsPlacementConstraint


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**expression** | **str** |  | [optional] 
**type** | [**AwsPlacementConstraintType**](AwsPlacementConstraintType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_placement_constraint import AwsPlacementConstraint

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPlacementConstraint from a JSON string
aws_placement_constraint_instance = AwsPlacementConstraint.from_json(json)
# print the JSON string representation of the object
print(AwsPlacementConstraint.to_json())

# convert the object into a dict
aws_placement_constraint_dict = aws_placement_constraint_instance.to_dict()
# create an instance of AwsPlacementConstraint from a dict
aws_placement_constraint_from_dict = AwsPlacementConstraint.from_dict(aws_placement_constraint_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


