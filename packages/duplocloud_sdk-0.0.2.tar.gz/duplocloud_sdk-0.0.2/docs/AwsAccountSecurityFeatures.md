# AwsAccountSecurityFeatures


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enable_vpc_flow_logs** | **bool** |  | [optional] 
**enable_security_hub** | **bool** |  | [optional] 
**enable_guard_duty** | **bool** |  | [optional] 
**enable_cloud_trail** | **bool** |  | [optional] 
**enable_password_policy** | **bool** |  | [optional] 
**delete_default_vpcs** | **bool** |  | [optional] 
**revoke_default_sg_rules** | **bool** |  | [optional] 
**enable_global_s3_public_access_block** | **bool** |  | [optional] 
**delete_default_nacl_rules** | **bool** |  | [optional] 
**enable_all_security_hub_regions** | **bool** |  | [optional] 
**security_hub_membership_type** | [**AwsSecurityHubMembershipType**](AwsSecurityHubMembershipType.md) |  | [optional] 
**security_hub_other_accounts** | **List[str]** |  | [optional] 
**security_hub_admin_account** | **str** |  | [optional] 
**enable_cis_cloud_trail_cloud_watch_alarms** | **bool** |  | [optional] 
**cis_cloud_watch_alarm_notification_email** | **str** |  | [optional] 
**cis_cloud_watch_alarm_log_group** | **str** |  | [optional] 
**cloud_trail_log_bucket_type** | [**AwsSecurityLogBucketType**](AwsSecurityLogBucketType.md) |  | [optional] 
**cloud_trail_log_bucket_other_accounts** | **List[str]** |  | [optional] 
**cloud_trail_log_bucket_name** | **str** |  | [optional] 
**cloud_trail_log_bucket_account** | **str** |  | [optional] 
**cloud_trail_log_bucket_kms_key_id** | **str** |  | [optional] 
**config_log_bucket_type** | [**AwsSecurityLogBucketType**](AwsSecurityLogBucketType.md) |  | [optional] 
**config_log_bucket_other_accounts** | **List[str]** |  | [optional] 
**config_log_bucket_name** | **str** |  | [optional] 
**config_log_bucket_account** | **str** |  | [optional] 
**config_log_bucket_kms_key_id** | **str** |  | [optional] 
**enable_inspector** | **bool** |  | [optional] 
**enable_all_inspector_regions** | **bool** |  | [optional] 
**ignore_default_ebs_encryption** | **bool** |  | [optional] 
**ssm_inventory_rate** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_account_security_features import AwsAccountSecurityFeatures

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAccountSecurityFeatures from a JSON string
aws_account_security_features_instance = AwsAccountSecurityFeatures.from_json(json)
# print the JSON string representation of the object
print(AwsAccountSecurityFeatures.to_json())

# convert the object into a dict
aws_account_security_features_dict = aws_account_security_features_instance.to_dict()
# create an instance of AwsAccountSecurityFeatures from a dict
aws_account_security_features_from_dict = AwsAccountSecurityFeatures.from_dict(aws_account_security_features_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


