# AzureAzureStoragePropertyDictionaryResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**properties** | [**Dict[str, AzureAzureStorageInfoValue]**](AzureAzureStorageInfoValue.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_azure_storage_property_dictionary_resource import AzureAzureStoragePropertyDictionaryResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAzureStoragePropertyDictionaryResource from a JSON string
azure_azure_storage_property_dictionary_resource_instance = AzureAzureStoragePropertyDictionaryResource.from_json(json)
# print the JSON string representation of the object
print(AzureAzureStoragePropertyDictionaryResource.to_json())

# convert the object into a dict
azure_azure_storage_property_dictionary_resource_dict = azure_azure_storage_property_dictionary_resource_instance.to_dict()
# create an instance of AzureAzureStoragePropertyDictionaryResource from a dict
azure_azure_storage_property_dictionary_resource_from_dict = AzureAzureStoragePropertyDictionaryResource.from_dict(azure_azure_storage_property_dictionary_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


