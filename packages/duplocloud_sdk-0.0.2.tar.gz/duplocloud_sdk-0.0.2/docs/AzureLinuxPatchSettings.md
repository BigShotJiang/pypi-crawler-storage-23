# AzureLinuxPatchSettings

Specifies settings related to VM Guest Patching on Linux.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**patch_mode** | **str** | Gets or sets specifies the mode of VM Guest Patching to IaaS virtual machine or virtual machines associated to virtual machine scale set with OrchestrationMode as Flexible.&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; Possible values are:&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **ImageDefault** - The virtual machine&#39;s default patching configuration is used. &amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **AutomaticByPlatform** - The virtual machine will be automatically updated by the platform. The property provisionVMAgent must be true. Possible values include: &#39;ImageDefault&#39;, &#39;AutomaticByPlatform&#39; | [optional] 
**assessment_mode** | **str** | Gets or sets specifies the mode of VM Guest Patch Assessment for the IaaS virtual machine.&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; Possible values are:&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **ImageDefault** - You control the timing of patch assessments on a virtual machine. &amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **AutomaticByPlatform** - The platform will trigger periodic patch assessments. The property provisionVMAgent must be true. Possible values include: &#39;ImageDefault&#39;, &#39;AutomaticByPlatform&#39; | [optional] 
**automatic_by_platform_settings** | [**AzureLinuxVMGuestPatchAutomaticByPlatformSettings**](AzureLinuxVMGuestPatchAutomaticByPlatformSettings.md) | Gets or sets specifies additional settings for patch mode AutomaticByPlatform in VM Guest Patching on Linux. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_linux_patch_settings import AzureLinuxPatchSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLinuxPatchSettings from a JSON string
azure_linux_patch_settings_instance = AzureLinuxPatchSettings.from_json(json)
# print the JSON string representation of the object
print(AzureLinuxPatchSettings.to_json())

# convert the object into a dict
azure_linux_patch_settings_dict = azure_linux_patch_settings_instance.to_dict()
# create an instance of AzureLinuxPatchSettings from a dict
azure_linux_patch_settings_from_dict = AzureLinuxPatchSettings.from_dict(azure_linux_patch_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


