# AzureLocationMode



## Enum

* `PrimaryOnly` (value: `0`)

* `PrimaryThenSecondary` (value: `1`)

* `SecondaryOnly` (value: `2`)

* `SecondaryThenPrimary` (value: `3`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


