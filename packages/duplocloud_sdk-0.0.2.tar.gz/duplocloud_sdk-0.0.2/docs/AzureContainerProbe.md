# AzureContainerProbe

The container probe, for liveness or readiness

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**var_exec** | [**AzureContainerExec**](AzureContainerExec.md) | Gets or sets the execution command to probe | [optional] 
**http_get** | [**AzureContainerHttpGet**](AzureContainerHttpGet.md) | Gets or sets the Http Get settings to probe | [optional] 
**initial_delay_seconds** | **int** | Gets or sets the initial delay seconds. | [optional] 
**period_seconds** | **int** | Gets or sets the period seconds. | [optional] 
**failure_threshold** | **int** | Gets or sets the failure threshold. | [optional] 
**success_threshold** | **int** | Gets or sets the success threshold. | [optional] 
**timeout_seconds** | **int** | Gets or sets the timeout seconds. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_probe import AzureContainerProbe

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerProbe from a JSON string
azure_container_probe_instance = AzureContainerProbe.from_json(json)
# print the JSON string representation of the object
print(AzureContainerProbe.to_json())

# convert the object into a dict
azure_container_probe_dict = azure_container_probe_instance.to_dict()
# create an instance of AzureContainerProbe from a dict
azure_container_probe_from_dict = AzureContainerProbe.from_dict(azure_container_probe_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


