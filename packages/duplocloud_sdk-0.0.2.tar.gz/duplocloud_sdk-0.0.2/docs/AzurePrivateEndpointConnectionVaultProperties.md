# AzurePrivateEndpointConnectionVaultProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties** | [**AzurePrivateEndpointConnection2**](AzurePrivateEndpointConnection2.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_connection_vault_properties import AzurePrivateEndpointConnectionVaultProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointConnectionVaultProperties from a JSON string
azure_private_endpoint_connection_vault_properties_instance = AzurePrivateEndpointConnectionVaultProperties.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointConnectionVaultProperties.to_json())

# convert the object into a dict
azure_private_endpoint_connection_vault_properties_dict = azure_private_endpoint_connection_vault_properties_instance.to_dict()
# create an instance of AzurePrivateEndpointConnectionVaultProperties from a dict
azure_private_endpoint_connection_vault_properties_from_dict = AzurePrivateEndpointConnectionVaultProperties.from_dict(azure_private_endpoint_connection_vault_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


