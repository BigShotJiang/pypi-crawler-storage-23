# AwsDeploymentController


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AwsDeploymentControllerType**](AwsDeploymentControllerType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_controller import AwsDeploymentController

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentController from a JSON string
aws_deployment_controller_instance = AwsDeploymentController.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentController.to_json())

# convert the object into a dict
aws_deployment_controller_dict = aws_deployment_controller_instance.to_dict()
# create an instance of AwsDeploymentController from a dict
aws_deployment_controller_from_dict = AwsDeploymentController.from_dict(aws_deployment_controller_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


