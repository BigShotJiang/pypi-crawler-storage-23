# ArchitectureValues


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.architecture_values import ArchitectureValues

# TODO update the JSON string below
json = "{}"
# create an instance of ArchitectureValues from a JSON string
architecture_values_instance = ArchitectureValues.from_json(json)
# print the JSON string representation of the object
print(ArchitectureValues.to_json())

# convert the object into a dict
architecture_values_dict = architecture_values_instance.to_dict()
# create an instance of ArchitectureValues from a dict
architecture_values_from_dict = ArchitectureValues.from_dict(architecture_values_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


