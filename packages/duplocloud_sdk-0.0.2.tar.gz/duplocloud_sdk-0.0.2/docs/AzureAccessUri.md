# AzureAccessUri

A disk access SAS uri.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_sas** | **str** | Gets a SAS uri for accessing a disk. | [optional] 
**security_data_access_sas** | **str** | Gets a SAS uri for accessing a VM guest state. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_access_uri import AzureAccessUri

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAccessUri from a JSON string
azure_access_uri_instance = AzureAccessUri.from_json(json)
# print the JSON string representation of the object
print(AzureAccessUri.to_json())

# convert the object into a dict
azure_access_uri_dict = azure_access_uri_instance.to_dict()
# create an instance of AzureAccessUri from a dict
azure_access_uri_from_dict = AzureAccessUri.from_dict(azure_access_uri_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


