# AzureLoadBalancerBackendAddress


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**properties_virtual_network** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_subnet** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_ip_address** | **str** |  | [optional] 
**properties_network_interface_ip_configuration** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_load_balancer_frontend_ip_configuration** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_inbound_nat_rules_port_mapping** | [**List[AzureNatRulePortMapping]**](AzureNatRulePortMapping.md) |  | [optional] 
**properties_admin_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_load_balancer_backend_address import AzureLoadBalancerBackendAddress

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLoadBalancerBackendAddress from a JSON string
azure_load_balancer_backend_address_instance = AzureLoadBalancerBackendAddress.from_json(json)
# print the JSON string representation of the object
print(AzureLoadBalancerBackendAddress.to_json())

# convert the object into a dict
azure_load_balancer_backend_address_dict = azure_load_balancer_backend_address_instance.to_dict()
# create an instance of AzureLoadBalancerBackendAddress from a dict
azure_load_balancer_backend_address_from_dict = AzureLoadBalancerBackendAddress.from_dict(azure_load_balancer_backend_address_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


