# AzureElasticPoolPerDatabaseSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**min_capacity** | **float** |  | [optional] 
**max_capacity** | **float** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_elastic_pool_per_database_settings import AzureElasticPoolPerDatabaseSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureElasticPoolPerDatabaseSettings from a JSON string
azure_elastic_pool_per_database_settings_instance = AzureElasticPoolPerDatabaseSettings.from_json(json)
# print the JSON string representation of the object
print(AzureElasticPoolPerDatabaseSettings.to_json())

# convert the object into a dict
azure_elastic_pool_per_database_settings_dict = azure_elastic_pool_per_database_settings_instance.to_dict()
# create an instance of AzureElasticPoolPerDatabaseSettings from a dict
azure_elastic_pool_per_database_settings_from_dict = AzureElasticPoolPerDatabaseSettings.from_dict(azure_elastic_pool_per_database_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


