# AwsPidMode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_pid_mode import AwsPidMode

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPidMode from a JSON string
aws_pid_mode_instance = AwsPidMode.from_json(json)
# print the JSON string representation of the object
print(AwsPidMode.to_json())

# convert the object into a dict
aws_pid_mode_dict = aws_pid_mode_instance.to_dict()
# create an instance of AwsPidMode from a dict
aws_pid_mode_from_dict = AwsPidMode.from_dict(aws_pid_mode_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


