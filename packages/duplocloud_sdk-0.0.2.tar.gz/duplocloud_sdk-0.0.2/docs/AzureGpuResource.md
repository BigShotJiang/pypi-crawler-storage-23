# AzureGpuResource

The GPU resource.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | **int** | Gets or sets the count of the GPU resource. | [optional] 
**sku** | **str** | Gets or sets the SKU of the GPU resource. Possible values include: &#39;K80&#39;, &#39;P100&#39;, &#39;V100&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_gpu_resource import AzureGpuResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureGpuResource from a JSON string
azure_gpu_resource_instance = AzureGpuResource.from_json(json)
# print the JSON string representation of the object
print(AzureGpuResource.to_json())

# convert the object into a dict
azure_gpu_resource_dict = azure_gpu_resource_instance.to_dict()
# create an instance of AzureGpuResource from a dict
azure_gpu_resource_from_dict = AzureGpuResource.from_dict(azure_gpu_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


