# AzureIaaSVMProtectionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**vm_name** | **str** |  | [optional] 
**policy_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_iaa_svm_protection_request import AzureIaaSVMProtectionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIaaSVMProtectionRequest from a JSON string
azure_iaa_svm_protection_request_instance = AzureIaaSVMProtectionRequest.from_json(json)
# print the JSON string representation of the object
print(AzureIaaSVMProtectionRequest.to_json())

# convert the object into a dict
azure_iaa_svm_protection_request_dict = azure_iaa_svm_protection_request_instance.to_dict()
# create an instance of AzureIaaSVMProtectionRequest from a dict
azure_iaa_svm_protection_request_from_dict = AzureIaaSVMProtectionRequest.from_dict(azure_iaa_svm_protection_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


