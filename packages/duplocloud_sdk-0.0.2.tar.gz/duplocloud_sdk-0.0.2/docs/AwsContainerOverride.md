# AwsContainerOverride


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**command** | **List[str]** |  | [optional] 
**cpu** | **int** |  | [optional] 
**environment** | [**List[AwsKeyValuePair]**](AwsKeyValuePair.md) |  | [optional] 
**environment_files** | [**List[AwsEnvironmentFile]**](AwsEnvironmentFile.md) |  | [optional] 
**memory** | **int** |  | [optional] 
**memory_reservation** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**resource_requirements** | [**List[AwsResourceRequirement]**](AwsResourceRequirement.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container_override import AwsContainerOverride

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainerOverride from a JSON string
aws_container_override_instance = AwsContainerOverride.from_json(json)
# print the JSON string representation of the object
print(AwsContainerOverride.to_json())

# convert the object into a dict
aws_container_override_dict = aws_container_override_instance.to_dict()
# create an instance of AwsContainerOverride from a dict
aws_container_override_from_dict = AwsContainerOverride.from_dict(aws_container_override_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


