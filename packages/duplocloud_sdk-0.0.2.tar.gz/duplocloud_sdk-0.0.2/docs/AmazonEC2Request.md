# AmazonEC2Request


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_ec2_request import AmazonEC2Request

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonEC2Request from a JSON string
amazon_ec2_request_instance = AmazonEC2Request.from_json(json)
# print the JSON string representation of the object
print(AmazonEC2Request.to_json())

# convert the object into a dict
amazon_ec2_request_dict = amazon_ec2_request_instance.to_dict()
# create an instance of AmazonEC2Request from a dict
amazon_ec2_request_from_dict = AmazonEC2Request.from_dict(amazon_ec2_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


