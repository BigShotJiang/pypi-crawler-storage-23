# AutoTuneOptionsOutput


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**error_message** | **str** |  | [optional] 
**state** | [**AutoTuneState**](AutoTuneState.md) |  | [optional] 
**use_off_peak_window** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.auto_tune_options_output import AutoTuneOptionsOutput

# TODO update the JSON string below
json = "{}"
# create an instance of AutoTuneOptionsOutput from a JSON string
auto_tune_options_output_instance = AutoTuneOptionsOutput.from_json(json)
# print the JSON string representation of the object
print(AutoTuneOptionsOutput.to_json())

# convert the object into a dict
auto_tune_options_output_dict = auto_tune_options_output_instance.to_dict()
# create an instance of AutoTuneOptionsOutput from a dict
auto_tune_options_output_from_dict = AutoTuneOptionsOutput.from_dict(auto_tune_options_output_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


