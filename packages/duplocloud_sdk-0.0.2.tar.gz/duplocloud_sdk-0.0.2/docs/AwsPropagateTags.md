# AwsPropagateTags


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_propagate_tags import AwsPropagateTags

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPropagateTags from a JSON string
aws_propagate_tags_instance = AwsPropagateTags.from_json(json)
# print the JSON string representation of the object
print(AwsPropagateTags.to_json())

# convert the object into a dict
aws_propagate_tags_dict = aws_propagate_tags_instance.to_dict()
# create an instance of AwsPropagateTags from a dict
aws_propagate_tags_from_dict = AwsPropagateTags.from_dict(aws_propagate_tags_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


