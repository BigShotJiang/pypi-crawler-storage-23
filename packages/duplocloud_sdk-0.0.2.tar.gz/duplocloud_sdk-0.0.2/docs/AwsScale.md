# AwsScale


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unit** | [**AwsScaleUnit**](AwsScaleUnit.md) |  | [optional] 
**value** | **float** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_scale import AwsScale

# TODO update the JSON string below
json = "{}"
# create an instance of AwsScale from a JSON string
aws_scale_instance = AwsScale.from_json(json)
# print the JSON string representation of the object
print(AwsScale.to_json())

# convert the object into a dict
aws_scale_dict = aws_scale_instance.to_dict()
# create an instance of AwsScale from a dict
aws_scale_from_dict = AwsScale.from_dict(aws_scale_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


