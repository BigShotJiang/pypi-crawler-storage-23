# AzureCapabilityStatus



## Enum

* `Visible` (value: `'Visible'`)

* `Available` (value: `'Available'`)

* `Default` (value: `'Default'`)

* `Disabled` (value: `'Disabled'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


