# AvailabilityZone



## Enum

* `A` (value: `0`)

* `B` (value: `1`)

* `C` (value: `2`)

* `D` (value: `3`)

* `E` (value: `4`)

* `F` (value: `5`)

* `ObsoleteDefault` (value: `100`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


