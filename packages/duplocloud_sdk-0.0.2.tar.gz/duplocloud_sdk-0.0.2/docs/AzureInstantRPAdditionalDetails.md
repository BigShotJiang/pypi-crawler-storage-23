# AzureInstantRPAdditionalDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**azure_backup_rg_name_prefix** | **str** |  | [optional] 
**azure_backup_rg_name_suffix** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_instant_rp_additional_details import AzureInstantRPAdditionalDetails

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInstantRPAdditionalDetails from a JSON string
azure_instant_rp_additional_details_instance = AzureInstantRPAdditionalDetails.from_json(json)
# print the JSON string representation of the object
print(AzureInstantRPAdditionalDetails.to_json())

# convert the object into a dict
azure_instant_rp_additional_details_dict = azure_instant_rp_additional_details_instance.to_dict()
# create an instance of AzureInstantRPAdditionalDetails from a dict
azure_instant_rp_additional_details_from_dict = AzureInstantRPAdditionalDetails.from_dict(azure_instant_rp_additional_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


