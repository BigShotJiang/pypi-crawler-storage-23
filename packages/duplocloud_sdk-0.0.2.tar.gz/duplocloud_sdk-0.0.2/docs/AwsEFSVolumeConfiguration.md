# AwsEFSVolumeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorization_config** | [**AwsEFSAuthorizationConfig**](AwsEFSAuthorizationConfig.md) |  | [optional] 
**file_system_id** | **str** |  | [optional] 
**root_directory** | **str** |  | [optional] 
**transit_encryption** | [**AwsEFSTransitEncryption**](AwsEFSTransitEncryption.md) |  | [optional] 
**transit_encryption_port** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_efs_volume_configuration import AwsEFSVolumeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEFSVolumeConfiguration from a JSON string
aws_efs_volume_configuration_instance = AwsEFSVolumeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsEFSVolumeConfiguration.to_json())

# convert the object into a dict
aws_efs_volume_configuration_dict = aws_efs_volume_configuration_instance.to_dict()
# create an instance of AwsEFSVolumeConfiguration from a dict
aws_efs_volume_configuration_from_dict = AwsEFSVolumeConfiguration.from_dict(aws_efs_volume_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


