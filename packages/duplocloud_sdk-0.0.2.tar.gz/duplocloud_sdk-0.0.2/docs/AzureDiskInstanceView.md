# AzureDiskInstanceView

The instance view of the disk.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the disk name. | [optional] 
**encryption_settings** | [**List[AzureDiskEncryptionSettings]**](AzureDiskEncryptionSettings.md) | Gets or sets specifies the encryption settings for the OS Disk. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Minimum api-version: 2015-06-15 | [optional] 
**statuses** | [**List[AzureInstanceViewStatus]**](AzureInstanceViewStatus.md) | Gets or sets the resource status information. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_disk_instance_view import AzureDiskInstanceView

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDiskInstanceView from a JSON string
azure_disk_instance_view_instance = AzureDiskInstanceView.from_json(json)
# print the JSON string representation of the object
print(AzureDiskInstanceView.to_json())

# convert the object into a dict
azure_disk_instance_view_dict = azure_disk_instance_view_instance.to_dict()
# create an instance of AzureDiskInstanceView from a dict
azure_disk_instance_view_from_dict = AzureDiskInstanceView.from_dict(azure_disk_instance_view_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


