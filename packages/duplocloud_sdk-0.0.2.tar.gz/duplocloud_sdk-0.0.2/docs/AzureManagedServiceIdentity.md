# AzureManagedServiceIdentity

Managed service identity (system assigned and/or user assigned identities)

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**principal_id** | **str** | Gets the service principal ID of the system assigned identity. This property will only be provided for a system assigned identity. | [optional] 
**tenant_id** | **str** | Gets the tenant ID of the system assigned identity. This property will only be provided for a system assigned identity. | [optional] 
**type** | **str** | Gets or sets possible values include: &#39;None&#39;, &#39;SystemAssigned&#39;, &#39;UserAssigned&#39;, &#39;SystemAssigned, UserAssigned&#39; | [optional] 
**user_assigned_identities** | [**Dict[str, AzureUserAssignedIdentity]**](AzureUserAssignedIdentity.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_service_identity import AzureManagedServiceIdentity

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedServiceIdentity from a JSON string
azure_managed_service_identity_instance = AzureManagedServiceIdentity.from_json(json)
# print the JSON string representation of the object
print(AzureManagedServiceIdentity.to_json())

# convert the object into a dict
azure_managed_service_identity_dict = azure_managed_service_identity_instance.to_dict()
# create an instance of AzureManagedServiceIdentity from a dict
azure_managed_service_identity_from_dict = AzureManagedServiceIdentity.from_dict(azure_managed_service_identity_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


