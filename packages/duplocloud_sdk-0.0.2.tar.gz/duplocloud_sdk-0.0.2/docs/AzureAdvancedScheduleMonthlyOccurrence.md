# AzureAdvancedScheduleMonthlyOccurrence


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**occurrence** | **int** |  | [optional] 
**day** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_advanced_schedule_monthly_occurrence import AzureAdvancedScheduleMonthlyOccurrence

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAdvancedScheduleMonthlyOccurrence from a JSON string
azure_advanced_schedule_monthly_occurrence_instance = AzureAdvancedScheduleMonthlyOccurrence.from_json(json)
# print the JSON string representation of the object
print(AzureAdvancedScheduleMonthlyOccurrence.to_json())

# convert the object into a dict
azure_advanced_schedule_monthly_occurrence_dict = azure_advanced_schedule_monthly_occurrence_instance.to_dict()
# create an instance of AzureAdvancedScheduleMonthlyOccurrence from a dict
azure_advanced_schedule_monthly_occurrence_from_dict = AzureAdvancedScheduleMonthlyOccurrence.from_dict(azure_advanced_schedule_monthly_occurrence_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


