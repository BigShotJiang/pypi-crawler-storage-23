# AwsTaskEphemeralStorage


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**kms_key_id** | **str** |  | [optional] 
**size_in_gi_b** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_ephemeral_storage import AwsTaskEphemeralStorage

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskEphemeralStorage from a JSON string
aws_task_ephemeral_storage_instance = AwsTaskEphemeralStorage.from_json(json)
# print the JSON string representation of the object
print(AwsTaskEphemeralStorage.to_json())

# convert the object into a dict
aws_task_ephemeral_storage_dict = aws_task_ephemeral_storage_instance.to_dict()
# create an instance of AwsTaskEphemeralStorage from a dict
aws_task_ephemeral_storage_from_dict = AwsTaskEphemeralStorage.from_dict(aws_task_ephemeral_storage_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


