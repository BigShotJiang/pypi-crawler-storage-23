# AwsContainerDependency


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | [**AwsContainerCondition**](AwsContainerCondition.md) |  | [optional] 
**container_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container_dependency import AwsContainerDependency

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainerDependency from a JSON string
aws_container_dependency_instance = AwsContainerDependency.from_json(json)
# print the JSON string representation of the object
print(AwsContainerDependency.to_json())

# convert the object into a dict
aws_container_dependency_dict = aws_container_dependency_instance.to_dict()
# create an instance of AwsContainerDependency from a dict
aws_container_dependency_from_dict = AwsContainerDependency.from_dict(aws_container_dependency_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


