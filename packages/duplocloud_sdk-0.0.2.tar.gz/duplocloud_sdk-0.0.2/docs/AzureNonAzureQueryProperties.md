# AzureNonAzureQueryProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**function_alias** | **str** |  | [optional] 
**workspace_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_non_azure_query_properties import AzureNonAzureQueryProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNonAzureQueryProperties from a JSON string
azure_non_azure_query_properties_instance = AzureNonAzureQueryProperties.from_json(json)
# print the JSON string representation of the object
print(AzureNonAzureQueryProperties.to_json())

# convert the object into a dict
azure_non_azure_query_properties_dict = azure_non_azure_query_properties_instance.to_dict()
# create an instance of AzureNonAzureQueryProperties from a dict
azure_non_azure_query_properties_from_dict = AzureNonAzureQueryProperties.from_dict(azure_non_azure_query_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


