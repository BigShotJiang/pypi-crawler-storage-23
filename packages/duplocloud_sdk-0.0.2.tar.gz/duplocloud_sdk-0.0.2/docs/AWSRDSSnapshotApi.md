# duplocloud_sdk.AWSRDSSnapshotApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_snapshot_all**](AWSRDSSnapshotApi.md#rds_api_snapshot_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot | 
[**rds_api_snapshot_all2**](AWSRDSSnapshotApi.md#rds_api_snapshot_all2) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/tenantOwned | 
[**rds_api_snapshot_delete**](AWSRDSSnapshotApi.md#rds_api_snapshot_delete) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id} | 
[**rds_api_snapshot_delete2**](AWSRDSSnapshotApi.md#rds_api_snapshot_delete2) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id}/clusterSnapshot | 
[**rds_api_snapshot_put**](AWSRDSSnapshotApi.md#rds_api_snapshot_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/snapshot/{id}/share | 


# **rds_api_snapshot_all**
> List[RDSDBSnapshotDetails] rds_api_snapshot_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_details import RDSDBSnapshotDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSSnapshotApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_snapshot_all(subscription_id)
        print("The response of AWSRDSSnapshotApi->rds_api_snapshot_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSSnapshotApi->rds_api_snapshot_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBSnapshotDetails]**](RDSDBSnapshotDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_all2**
> List[RDSDBSnapshotDetails] rds_api_snapshot_all2(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_details import RDSDBSnapshotDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSSnapshotApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_snapshot_all2(subscription_id)
        print("The response of AWSRDSSnapshotApi->rds_api_snapshot_all2:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSSnapshotApi->rds_api_snapshot_all2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBSnapshotDetails]**](RDSDBSnapshotDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_delete**
> rds_api_snapshot_delete(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSSnapshotApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_snapshot_delete(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSSnapshotApi->rds_api_snapshot_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_delete2**
> rds_api_snapshot_delete2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSSnapshotApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_snapshot_delete2(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSSnapshotApi->rds_api_snapshot_delete2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_snapshot_put**
> rds_api_snapshot_put(subscription_id, id, rdsdb_snapshot_share_request=rdsdb_snapshot_share_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_share_request import RDSDBSnapshotShareRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSSnapshotApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_snapshot_share_request = duplocloud_sdk.RDSDBSnapshotShareRequest() # RDSDBSnapshotShareRequest |  (optional)

    try:
        api_instance.rds_api_snapshot_put(subscription_id, id, rdsdb_snapshot_share_request=rdsdb_snapshot_share_request)
    except Exception as e:
        print("Exception when calling AWSRDSSnapshotApi->rds_api_snapshot_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_snapshot_share_request** | [**RDSDBSnapshotShareRequest**](RDSDBSnapshotShareRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

