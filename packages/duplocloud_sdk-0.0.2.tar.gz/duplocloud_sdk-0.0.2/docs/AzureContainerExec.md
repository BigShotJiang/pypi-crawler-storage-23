# AzureContainerExec

The container execution command, for liveness or readiness probe

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**command** | **List[str]** | Gets or sets the commands to execute within the container. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_exec import AzureContainerExec

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerExec from a JSON string
azure_container_exec_instance = AzureContainerExec.from_json(json)
# print the JSON string representation of the object
print(AzureContainerExec.to_json())

# convert the object into a dict
azure_container_exec_dict = azure_container_exec_instance.to_dict()
# create an instance of AzureContainerExec from a dict
azure_container_exec_from_dict = AzureContainerExec.from_dict(azure_container_exec_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


