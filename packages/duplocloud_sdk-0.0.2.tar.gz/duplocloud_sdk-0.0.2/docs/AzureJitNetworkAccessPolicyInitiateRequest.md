# AzureJitNetworkAccessPolicyInitiateRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**virtual_machines** | [**List[AzureJitNetworkAccessPolicyInitiateVirtualMachine]**](AzureJitNetworkAccessPolicyInitiateVirtualMachine.md) | Gets or sets a list of virtual machines &amp;amp; ports to open access for | [optional] 
**justification** | **str** | Gets or sets the justification for making the initiate request | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_jit_network_access_policy_initiate_request import AzureJitNetworkAccessPolicyInitiateRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AzureJitNetworkAccessPolicyInitiateRequest from a JSON string
azure_jit_network_access_policy_initiate_request_instance = AzureJitNetworkAccessPolicyInitiateRequest.from_json(json)
# print the JSON string representation of the object
print(AzureJitNetworkAccessPolicyInitiateRequest.to_json())

# convert the object into a dict
azure_jit_network_access_policy_initiate_request_dict = azure_jit_network_access_policy_initiate_request_instance.to_dict()
# create an instance of AzureJitNetworkAccessPolicyInitiateRequest from a dict
azure_jit_network_access_policy_initiate_request_from_dict = AzureJitNetworkAccessPolicyInitiateRequest.from_dict(azure_jit_network_access_policy_initiate_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


