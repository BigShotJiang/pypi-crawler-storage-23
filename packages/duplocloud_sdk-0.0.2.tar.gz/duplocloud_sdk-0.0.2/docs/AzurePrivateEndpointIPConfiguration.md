# AzurePrivateEndpointIPConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**properties_group_id** | **str** |  | [optional] 
**properties_member_name** | **str** |  | [optional] 
**properties_private_ip_address** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_ip_configuration import AzurePrivateEndpointIPConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointIPConfiguration from a JSON string
azure_private_endpoint_ip_configuration_instance = AzurePrivateEndpointIPConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointIPConfiguration.to_json())

# convert the object into a dict
azure_private_endpoint_ip_configuration_dict = azure_private_endpoint_ip_configuration_instance.to_dict()
# create an instance of AzurePrivateEndpointIPConfiguration from a dict
azure_private_endpoint_ip_configuration_from_dict = AzurePrivateEndpointIPConfiguration.from_dict(azure_private_endpoint_ip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


