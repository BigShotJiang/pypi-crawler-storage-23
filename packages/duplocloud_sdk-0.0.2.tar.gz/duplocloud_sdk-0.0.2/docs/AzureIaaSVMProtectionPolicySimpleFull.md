# AzureIaaSVMProtectionPolicySimpleFull


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**properties** | **object** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_iaa_svm_protection_policy_simple_full import AzureIaaSVMProtectionPolicySimpleFull

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIaaSVMProtectionPolicySimpleFull from a JSON string
azure_iaa_svm_protection_policy_simple_full_instance = AzureIaaSVMProtectionPolicySimpleFull.from_json(json)
# print the JSON string representation of the object
print(AzureIaaSVMProtectionPolicySimpleFull.to_json())

# convert the object into a dict
azure_iaa_svm_protection_policy_simple_full_dict = azure_iaa_svm_protection_policy_simple_full_instance.to_dict()
# create an instance of AzureIaaSVMProtectionPolicySimpleFull from a dict
azure_iaa_svm_protection_policy_simple_full_from_dict = AzureIaaSVMProtectionPolicySimpleFull.from_dict(azure_iaa_svm_protection_policy_simple_full_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


