# AwsAssignPublicIp


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_assign_public_ip import AwsAssignPublicIp

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAssignPublicIp from a JSON string
aws_assign_public_ip_instance = AwsAssignPublicIp.from_json(json)
# print the JSON string representation of the object
print(AwsAssignPublicIp.to_json())

# convert the object into a dict
aws_assign_public_ip_dict = aws_assign_public_ip_instance.to_dict()
# create an instance of AwsAssignPublicIp from a dict
aws_assign_public_ip_from_dict = AwsAssignPublicIp.from_dict(aws_assign_public_ip_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


