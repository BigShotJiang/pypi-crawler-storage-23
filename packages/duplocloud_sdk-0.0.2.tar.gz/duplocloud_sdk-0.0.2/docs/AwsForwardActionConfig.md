# AwsForwardActionConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target_groups** | [**List[AwsTargetGroupTuple]**](AwsTargetGroupTuple.md) |  | [optional] 
**target_group_stickiness_config** | [**TargetGroupStickinessConfig**](TargetGroupStickinessConfig.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_forward_action_config import AwsForwardActionConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AwsForwardActionConfig from a JSON string
aws_forward_action_config_instance = AwsForwardActionConfig.from_json(json)
# print the JSON string representation of the object
print(AwsForwardActionConfig.to_json())

# convert the object into a dict
aws_forward_action_config_dict = aws_forward_action_config_instance.to_dict()
# create an instance of AwsForwardActionConfig from a dict
aws_forward_action_config_from_dict = AwsForwardActionConfig.from_dict(aws_forward_action_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


