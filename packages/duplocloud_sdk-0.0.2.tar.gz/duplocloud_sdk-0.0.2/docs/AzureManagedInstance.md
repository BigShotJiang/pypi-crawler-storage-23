# AzureManagedInstance


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**identity** | [**AzureResourceIdentity3**](AzureResourceIdentity3.md) |  | [optional] 
**sku** | [**AzureSku3**](AzureSku3.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_managed_instance_create_mode** | **str** |  | [optional] 
**properties_fully_qualified_domain_name** | **str** |  | [optional] 
**properties_administrator_login** | **str** |  | [optional] 
**properties_administrator_login_password** | **str** |  | [optional] 
**properties_subnet_id** | **str** |  | [optional] 
**properties_state** | **str** |  | [optional] 
**properties_license_type** | **str** |  | [optional] 
**properties_v_cores** | **int** |  | [optional] 
**properties_storage_size_in_gb** | **int** |  | [optional] 
**properties_collation** | **str** |  | [optional] 
**properties_dns_zone** | **str** |  | [optional] 
**properties_dns_zone_partner** | **str** |  | [optional] 
**properties_public_data_endpoint_enabled** | **bool** |  | [optional] 
**properties_source_managed_instance_id** | **str** |  | [optional] 
**properties_restore_point_in_time** | **datetime** |  | [optional] 
**properties_proxy_override** | **str** |  | [optional] 
**properties_timezone_id** | **str** |  | [optional] 
**properties_instance_pool_id** | **str** |  | [optional] 
**properties_minimal_tls_version** | **str** |  | [optional] 
**properties_storage_account_type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_instance import AzureManagedInstance

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedInstance from a JSON string
azure_managed_instance_instance = AzureManagedInstance.from_json(json)
# print the JSON string representation of the object
print(AzureManagedInstance.to_json())

# convert the object into a dict
azure_managed_instance_dict = azure_managed_instance_instance.to_dict()
# create an instance of AzureManagedInstance from a dict
azure_managed_instance_from_dict = AzureManagedInstance.from_dict(azure_managed_instance_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


