# AuthenticateCognitoActionConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authentication_request_extra_params** | **Dict[str, str]** |  | [optional] 
**on_unauthenticated_request** | [**AuthenticateCognitoActionConditionalBehaviorEnum**](AuthenticateCognitoActionConditionalBehaviorEnum.md) |  | [optional] 
**scope** | **str** |  | [optional] 
**session_cookie_name** | **str** |  | [optional] 
**session_timeout** | **int** |  | [optional] 
**user_pool_arn** | **str** |  | [optional] 
**user_pool_client_id** | **str** |  | [optional] 
**user_pool_domain** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.authenticate_cognito_action_config import AuthenticateCognitoActionConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AuthenticateCognitoActionConfig from a JSON string
authenticate_cognito_action_config_instance = AuthenticateCognitoActionConfig.from_json(json)
# print the JSON string representation of the object
print(AuthenticateCognitoActionConfig.to_json())

# convert the object into a dict
authenticate_cognito_action_config_dict = authenticate_cognito_action_config_instance.to_dict()
# create an instance of AuthenticateCognitoActionConfig from a dict
authenticate_cognito_action_config_from_dict = AuthenticateCognitoActionConfig.from_dict(authenticate_cognito_action_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


