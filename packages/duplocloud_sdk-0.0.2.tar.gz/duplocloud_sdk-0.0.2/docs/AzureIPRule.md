# AzureIPRule

IP rule with specific IP or IP range in CIDR format.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** | Gets or sets specifies the IP or IP range in CIDR format. Only IPV4 address is allowed. | [optional] 
**action** | [**AzureAction**](AzureAction.md) | Gets or sets the action of IP ACL rule. Possible values include: &#39;Allow&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_rule import AzureIPRule

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIPRule from a JSON string
azure_ip_rule_instance = AzureIPRule.from_json(json)
# print the JSON string representation of the object
print(AzureIPRule.to_json())

# convert the object into a dict
azure_ip_rule_dict = azure_ip_rule_instance.to_dict()
# create an instance of AzureIPRule from a dict
azure_ip_rule_from_dict = AzureIPRule.from_dict(azure_ip_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


