# AzureLocationCapabilities


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**supported_server_versions** | [**List[AzureServerVersionCapability]**](AzureServerVersionCapability.md) |  | [optional] 
**supported_managed_instance_versions** | [**List[AzureManagedInstanceVersionCapability]**](AzureManagedInstanceVersionCapability.md) |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_location_capabilities import AzureLocationCapabilities

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLocationCapabilities from a JSON string
azure_location_capabilities_instance = AzureLocationCapabilities.from_json(json)
# print the JSON string representation of the object
print(AzureLocationCapabilities.to_json())

# convert the object into a dict
azure_location_capabilities_dict = azure_location_capabilities_instance.to_dict()
# create an instance of AzureLocationCapabilities from a dict
azure_location_capabilities_from_dict = AzureLocationCapabilities.from_dict(azure_location_capabilities_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


