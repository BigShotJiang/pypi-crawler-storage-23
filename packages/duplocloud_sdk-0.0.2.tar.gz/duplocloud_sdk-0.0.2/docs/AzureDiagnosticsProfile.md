# AzureDiagnosticsProfile

Specifies the boot diagnostic settings state. <br><br>Minimum api-version: 2015-06-15.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**boot_diagnostics** | [**AzureBootDiagnostics**](AzureBootDiagnostics.md) | Gets or sets boot Diagnostics is a debugging feature which allows you to view Console Output and Screenshot to diagnose VM status. &amp;lt;br&amp;gt;**NOTE**: If storageUri is being specified then ensure that the storage account is in the same region and subscription as the VM. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; You can easily view the output of your console log. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; Azure also enables you to see a screenshot of the VM from the hypervisor. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_diagnostics_profile import AzureDiagnosticsProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDiagnosticsProfile from a JSON string
azure_diagnostics_profile_instance = AzureDiagnosticsProfile.from_json(json)
# print the JSON string representation of the object
print(AzureDiagnosticsProfile.to_json())

# convert the object into a dict
azure_diagnostics_profile_dict = azure_diagnostics_profile_instance.to_dict()
# create an instance of AzureDiagnosticsProfile from a dict
azure_diagnostics_profile_from_dict = AzureDiagnosticsProfile.from_dict(azure_diagnostics_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


