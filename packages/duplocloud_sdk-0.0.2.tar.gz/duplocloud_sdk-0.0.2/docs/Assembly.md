# Assembly


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code_base** | **str** |  | [optional] 
**escaped_code_base** | **str** |  | [optional] 
**full_name** | **str** |  | [optional] 
**entry_point** | [**MethodInfo**](MethodInfo.md) |  | [optional] 
**exported_types** | **List[str]** |  | [optional] 
**defined_types** | **List[str]** |  | [optional] 
**evidence** | **List[object]** |  | [optional] 
**permission_set** | **List[object]** |  | [optional] 
**is_fully_trusted** | **bool** |  | [optional] 
**security_rule_set** | [**SecurityRuleSet**](SecurityRuleSet.md) |  | [optional] 
**manifest_module** | [**Module**](Module.md) |  | [optional] 
**custom_attributes** | [**List[CustomAttributeData]**](CustomAttributeData.md) |  | [optional] 
**reflection_only** | **bool** |  | [optional] 
**modules** | [**List[Module]**](Module.md) |  | [optional] 
**location** | **str** |  | [optional] 
**image_runtime_version** | **str** |  | [optional] 
**global_assembly_cache** | **bool** |  | [optional] 
**host_context** | **int** |  | [optional] 
**is_dynamic** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.assembly import Assembly

# TODO update the JSON string below
json = "{}"
# create an instance of Assembly from a JSON string
assembly_instance = Assembly.from_json(json)
# print the JSON string representation of the object
print(Assembly.to_json())

# convert the object into a dict
assembly_dict = assembly_instance.to_dict()
# create an instance of Assembly from a dict
assembly_from_dict = Assembly.from_dict(assembly_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


