# AzureInitContainerDefinition

The init container definition.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the name for the init container. | [optional] 
**properties_image** | **str** | Gets or sets the image of the init container. | [optional] 
**properties_command** | **List[str]** | Gets or sets the command to execute within the init container in exec form. | [optional] 
**properties_environment_variables** | [**List[AzureEnvironmentVariable]**](AzureEnvironmentVariable.md) | Gets or sets the environment variables to set in the init container. | [optional] 
**properties_instance_view** | [**AzureInitContainerPropertiesDefinitionInstanceView**](AzureInitContainerPropertiesDefinitionInstanceView.md) | Gets the instance view of the init container. Only valid in response. | [optional] 
**properties_volume_mounts** | [**List[AzureVolumeMount]**](AzureVolumeMount.md) | Gets or sets the volume mounts available to the init container. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_init_container_definition import AzureInitContainerDefinition

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInitContainerDefinition from a JSON string
azure_init_container_definition_instance = AzureInitContainerDefinition.from_json(json)
# print the JSON string representation of the object
print(AzureInitContainerDefinition.to_json())

# convert the object into a dict
azure_init_container_definition_dict = azure_init_container_definition_instance.to_dict()
# create an instance of AzureInitContainerDefinition from a dict
azure_init_container_definition_from_dict = AzureInitContainerDefinition.from_dict(azure_init_container_definition_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


