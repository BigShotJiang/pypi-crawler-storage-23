# AzureCapacityReservationProfile

The parameters of a capacity reservation Profile.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capacity_reservation_group** | [**AzureSubResource2**](AzureSubResource2.md) | Gets or sets specifies the capacity reservation group resource id that should be used for allocating the virtual machine or scaleset vm instances provided enough capacity has been reserved. Please refer to https://aka.ms/CapacityReservation for more details. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_capacity_reservation_profile import AzureCapacityReservationProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCapacityReservationProfile from a JSON string
azure_capacity_reservation_profile_instance = AzureCapacityReservationProfile.from_json(json)
# print the JSON string representation of the object
print(AzureCapacityReservationProfile.to_json())

# convert the object into a dict
azure_capacity_reservation_profile_dict = azure_capacity_reservation_profile_instance.to_dict()
# create an instance of AzureCapacityReservationProfile from a dict
azure_capacity_reservation_profile_from_dict = AzureCapacityReservationProfile.from_dict(azure_capacity_reservation_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


