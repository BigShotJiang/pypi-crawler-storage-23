# duplocloud_sdk.AdminInfrastructureUpdateApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v3_admin_infrastructure_api_disable_k8s**](AdminInfrastructureUpdateApi.md#v3_admin_infrastructure_api_disable_k8s) | **PUT** /v3/admin/infrastructure/{name}/disableK8s | 
[**v3_admin_infrastructure_api_enable_k8s**](AdminInfrastructureUpdateApi.md#v3_admin_infrastructure_api_enable_k8s) | **PUT** /v3/admin/infrastructure/{name}/enableK8s | 
[**v3_admin_infrastructure_api_update_on_prem_eks_config**](AdminInfrastructureUpdateApi.md#v3_admin_infrastructure_api_update_on_prem_eks_config) | **PUT** /v3/admin/infrastructure/{name}/updateOnPremEksConfig | 


# **v3_admin_infrastructure_api_disable_k8s**
> InfraEnableEKSRequest v3_admin_infrastructure_api_disable_k8s(name, infra_enable_eks_request=infra_enable_eks_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.infra_enable_eks_request import InfraEnableEKSRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureUpdateApi(api_client)
    name = 'name_example' # str | 
    infra_enable_eks_request = duplocloud_sdk.InfraEnableEKSRequest() # InfraEnableEKSRequest |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_disable_k8s(name, infra_enable_eks_request=infra_enable_eks_request)
        print("The response of AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_disable_k8s:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_disable_k8s: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **infra_enable_eks_request** | [**InfraEnableEKSRequest**](InfraEnableEKSRequest.md)|  | [optional] 

### Return type

[**InfraEnableEKSRequest**](InfraEnableEKSRequest.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_enable_k8s**
> InfraEnableEKSRequest v3_admin_infrastructure_api_enable_k8s(name, infra_enable_eks_request=infra_enable_eks_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.infra_enable_eks_request import InfraEnableEKSRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureUpdateApi(api_client)
    name = 'name_example' # str | 
    infra_enable_eks_request = duplocloud_sdk.InfraEnableEKSRequest() # InfraEnableEKSRequest |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_enable_k8s(name, infra_enable_eks_request=infra_enable_eks_request)
        print("The response of AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_enable_k8s:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_enable_k8s: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **infra_enable_eks_request** | [**InfraEnableEKSRequest**](InfraEnableEKSRequest.md)|  | [optional] 

### Return type

[**InfraEnableEKSRequest**](InfraEnableEKSRequest.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_update_on_prem_eks_config**
> OnPremEKSConfig v3_admin_infrastructure_api_update_on_prem_eks_config(name, on_prem_eks_config=on_prem_eks_config)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.on_prem_eks_config import OnPremEKSConfig
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureUpdateApi(api_client)
    name = 'name_example' # str | 
    on_prem_eks_config = duplocloud_sdk.OnPremEKSConfig() # OnPremEKSConfig |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_update_on_prem_eks_config(name, on_prem_eks_config=on_prem_eks_config)
        print("The response of AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_update_on_prem_eks_config:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureUpdateApi->v3_admin_infrastructure_api_update_on_prem_eks_config: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **on_prem_eks_config** | [**OnPremEKSConfig**](OnPremEKSConfig.md)|  | [optional] 

### Return type

[**OnPremEKSConfig**](OnPremEKSConfig.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

