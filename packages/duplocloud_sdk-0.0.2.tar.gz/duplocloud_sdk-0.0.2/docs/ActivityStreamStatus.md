# ActivityStreamStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.activity_stream_status import ActivityStreamStatus

# TODO update the JSON string below
json = "{}"
# create an instance of ActivityStreamStatus from a JSON string
activity_stream_status_instance = ActivityStreamStatus.from_json(json)
# print the JSON string representation of the object
print(ActivityStreamStatus.to_json())

# convert the object into a dict
activity_stream_status_dict = activity_stream_status_instance.to_dict()
# create an instance of ActivityStreamStatus from a dict
activity_stream_status_from_dict = ActivityStreamStatus.from_dict(activity_stream_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


