# AwsVolume


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**configured_at_launch** | **bool** |  | [optional] 
**docker_volume_configuration** | [**AwsDockerVolumeConfiguration**](AwsDockerVolumeConfiguration.md) |  | [optional] 
**efs_volume_configuration** | [**AwsEFSVolumeConfiguration**](AwsEFSVolumeConfiguration.md) |  | [optional] 
**fsx_windows_file_server_volume_configuration** | [**AwsFSxWindowsFileServerVolumeConfiguration**](AwsFSxWindowsFileServerVolumeConfiguration.md) |  | [optional] 
**host** | [**AwsHostVolumeProperties**](AwsHostVolumeProperties.md) |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_volume import AwsVolume

# TODO update the JSON string below
json = "{}"
# create an instance of AwsVolume from a JSON string
aws_volume_instance = AwsVolume.from_json(json)
# print the JSON string representation of the object
print(AwsVolume.to_json())

# convert the object into a dict
aws_volume_dict = aws_volume_instance.to_dict()
# create an instance of AwsVolume from a dict
aws_volume_from_dict = AwsVolume.from_dict(aws_volume_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


