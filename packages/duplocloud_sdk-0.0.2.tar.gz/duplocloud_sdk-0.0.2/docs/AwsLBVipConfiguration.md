# AwsLBVipConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**aws_dns_name** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_lb_vip_configuration import AwsLBVipConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLBVipConfiguration from a JSON string
aws_lb_vip_configuration_instance = AwsLBVipConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsLBVipConfiguration.to_json())

# convert the object into a dict
aws_lb_vip_configuration_dict = aws_lb_vip_configuration_instance.to_dict()
# create an instance of AwsLBVipConfiguration from a dict
aws_lb_vip_configuration_from_dict = AwsLBVipConfiguration.from_dict(aws_lb_vip_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


