# AzureRedisAccessKeys

Redis cache access keys.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**primary_key** | **str** | Gets the current primary key that clients can use to authenticate with Redis cache. | [optional] 
**secondary_key** | **str** | Gets the current secondary key that clients can use to authenticate with Redis cache. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_access_keys import AzureRedisAccessKeys

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisAccessKeys from a JSON string
azure_redis_access_keys_instance = AzureRedisAccessKeys.from_json(json)
# print the JSON string representation of the object
print(AzureRedisAccessKeys.to_json())

# convert the object into a dict
azure_redis_access_keys_dict = azure_redis_access_keys_instance.to_dict()
# create an instance of AzureRedisAccessKeys from a dict
azure_redis_access_keys_from_dict = AzureRedisAccessKeys.from_dict(azure_redis_access_keys_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


