# AwsServiceRegistry


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_name** | **str** |  | [optional] 
**container_port** | **int** |  | [optional] 
**port** | **int** |  | [optional] 
**registry_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_registry import AwsServiceRegistry

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceRegistry from a JSON string
aws_service_registry_instance = AwsServiceRegistry.from_json(json)
# print the JSON string representation of the object
print(AwsServiceRegistry.to_json())

# convert the object into a dict
aws_service_registry_dict = aws_service_registry_instance.to_dict()
# create an instance of AwsServiceRegistry from a dict
aws_service_registry_from_dict = AwsServiceRegistry.from_dict(aws_service_registry_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


