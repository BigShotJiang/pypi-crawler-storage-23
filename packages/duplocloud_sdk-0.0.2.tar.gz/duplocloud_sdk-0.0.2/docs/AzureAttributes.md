# AzureAttributes


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**enabled** | **bool** |  | [optional] 
**nbf** | **datetime** |  | [optional] 
**exp** | **datetime** |  | [optional] 
**created** | **datetime** |  | [optional] 
**updated** | **datetime** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_attributes import AzureAttributes

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAttributes from a JSON string
azure_attributes_instance = AzureAttributes.from_json(json)
# print the JSON string representation of the object
print(AzureAttributes.to_json())

# convert the object into a dict
azure_attributes_dict = azure_attributes_instance.to_dict()
# create an instance of AzureAttributes from a dict
azure_attributes_from_dict = AzureAttributes.from_dict(azure_attributes_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


