# AzureFlowLog


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**properties_target_resource_id** | **str** |  | [optional] 
**properties_target_resource_guid** | **str** |  | [optional] 
**properties_storage_id** | **str** |  | [optional] 
**properties_enabled** | **bool** |  | [optional] 
**properties_retention_policy** | [**AzureRetentionPolicyParameters**](AzureRetentionPolicyParameters.md) |  | [optional] 
**properties_format** | [**AzureFlowLogFormatParameters**](AzureFlowLogFormatParameters.md) |  | [optional] 
**properties_flow_analytics_configuration** | [**AzureTrafficAnalyticsProperties**](AzureTrafficAnalyticsProperties.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_flow_log import AzureFlowLog

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFlowLog from a JSON string
azure_flow_log_instance = AzureFlowLog.from_json(json)
# print the JSON string representation of the object
print(AzureFlowLog.to_json())

# convert the object into a dict
azure_flow_log_dict = azure_flow_log_instance.to_dict()
# create an instance of AzureFlowLog from a dict
azure_flow_log_from_dict = AzureFlowLog.from_dict(azure_flow_log_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


