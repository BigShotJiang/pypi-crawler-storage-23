# AzureBlobContainerPublicAccessType



## Enum

* `Off` (value: `0`)

* `Container` (value: `1`)

* `Blob` (value: `2`)

* `Unknown` (value: `3`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


