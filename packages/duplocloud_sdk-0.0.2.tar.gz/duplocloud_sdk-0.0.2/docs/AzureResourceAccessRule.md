# AzureResourceAccessRule

Resource Access Rule.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **str** | Gets or sets tenant Id | [optional] 
**resource_id** | **str** | Gets or sets resource Id | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource_access_rule import AzureResourceAccessRule

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResourceAccessRule from a JSON string
azure_resource_access_rule_instance = AzureResourceAccessRule.from_json(json)
# print the JSON string representation of the object
print(AzureResourceAccessRule.to_json())

# convert the object into a dict
azure_resource_access_rule_dict = azure_resource_access_rule_instance.to_dict()
# create an instance of AzureResourceAccessRule from a dict
azure_resource_access_rule_from_dict = AzureResourceAccessRule.from_dict(azure_resource_access_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


