# AzurePrivateEndpointConnectionProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**private_endpoint** | [**AzurePrivateEndpointProperty3**](AzurePrivateEndpointProperty3.md) |  | [optional] 
**private_link_service_connection_state** | [**AzurePrivateLinkServiceConnectionStateProperty**](AzurePrivateLinkServiceConnectionStateProperty.md) |  | [optional] 
**provisioning_state** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_connection_properties import AzurePrivateEndpointConnectionProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointConnectionProperties from a JSON string
azure_private_endpoint_connection_properties_instance = AzurePrivateEndpointConnectionProperties.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointConnectionProperties.to_json())

# convert the object into a dict
azure_private_endpoint_connection_properties_dict = azure_private_endpoint_connection_properties_instance.to_dict()
# create an instance of AzurePrivateEndpointConnectionProperties from a dict
azure_private_endpoint_connection_properties_from_dict = AzurePrivateEndpointConnectionProperties.from_dict(azure_private_endpoint_connection_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


