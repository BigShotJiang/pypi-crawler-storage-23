# AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**group_id** | **str** |  | [optional] 
**required_member_name** | **str** |  | [optional] 
**fqdns** | **List[str]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface_ip_configuration_private_link_connection_properties import AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties from a JSON string
azure_network_interface_ip_configuration_private_link_connection_properties_instance = AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties.to_json())

# convert the object into a dict
azure_network_interface_ip_configuration_private_link_connection_properties_dict = azure_network_interface_ip_configuration_private_link_connection_properties_instance.to_dict()
# create an instance of AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties from a dict
azure_network_interface_ip_configuration_private_link_connection_properties_from_dict = AzureNetworkInterfaceIPConfigurationPrivateLinkConnectionProperties.from_dict(azure_network_interface_ip_configuration_private_link_connection_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


