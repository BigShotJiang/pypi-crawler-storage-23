# AzureRampUpRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action_host_name** | **str** |  | [optional] 
**reroute_percentage** | **float** |  | [optional] 
**change_step** | **float** |  | [optional] 
**change_interval_in_minutes** | **int** |  | [optional] 
**min_reroute_percentage** | **float** |  | [optional] 
**max_reroute_percentage** | **float** |  | [optional] 
**change_decision_callback_url** | **str** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ramp_up_rule import AzureRampUpRule

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRampUpRule from a JSON string
azure_ramp_up_rule_instance = AzureRampUpRule.from_json(json)
# print the JSON string representation of the object
print(AzureRampUpRule.to_json())

# convert the object into a dict
azure_ramp_up_rule_dict = azure_ramp_up_rule_instance.to_dict()
# create an instance of AzureRampUpRule from a dict
azure_ramp_up_rule_from_dict = AzureRampUpRule.from_dict(azure_ramp_up_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


