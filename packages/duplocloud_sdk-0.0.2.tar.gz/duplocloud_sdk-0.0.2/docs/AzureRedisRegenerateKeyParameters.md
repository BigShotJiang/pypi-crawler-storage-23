# AzureRedisRegenerateKeyParameters

Specifies which Redis access keys to reset.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**key_type** | [**AzureRedisKeyType**](AzureRedisKeyType.md) | Gets or sets the Redis access key to regenerate. Possible values include: &#39;Primary&#39;, &#39;Secondary&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_regenerate_key_parameters import AzureRedisRegenerateKeyParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisRegenerateKeyParameters from a JSON string
azure_redis_regenerate_key_parameters_instance = AzureRedisRegenerateKeyParameters.from_json(json)
# print the JSON string representation of the object
print(AzureRedisRegenerateKeyParameters.to_json())

# convert the object into a dict
azure_redis_regenerate_key_parameters_dict = azure_redis_regenerate_key_parameters_instance.to_dict()
# create an instance of AzureRedisRegenerateKeyParameters from a dict
azure_redis_regenerate_key_parameters_from_dict = AzureRedisRegenerateKeyParameters.from_dict(azure_redis_regenerate_key_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


