# AzureResource10

The Resource model definition.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets the resource id. | [optional] 
**name** | **str** | Gets the resource name. | [optional] 
**type** | **str** | Gets the resource type. | [optional] 
**location** | **str** | Gets or sets the resource location. | [optional] 
**tags** | **Dict[str, str]** | Gets or sets the resource tags. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource10 import AzureResource10

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource10 from a JSON string
azure_resource10_instance = AzureResource10.from_json(json)
# print the JSON string representation of the object
print(AzureResource10.to_json())

# convert the object into a dict
azure_resource10_dict = azure_resource10_instance.to_dict()
# create an instance of AzureResource10 from a dict
azure_resource10_from_dict = AzureResource10.from_dict(azure_resource10_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


