# AwsFirelensConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**options** | **Dict[str, str]** |  | [optional] 
**type** | [**AwsFirelensConfigurationType**](AwsFirelensConfigurationType.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_firelens_configuration import AwsFirelensConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsFirelensConfiguration from a JSON string
aws_firelens_configuration_instance = AwsFirelensConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsFirelensConfiguration.to_json())

# convert the object into a dict
aws_firelens_configuration_dict = aws_firelens_configuration_instance.to_dict()
# create an instance of AwsFirelensConfiguration from a dict
aws_firelens_configuration_from_dict = AwsFirelensConfiguration.from_dict(aws_firelens_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


