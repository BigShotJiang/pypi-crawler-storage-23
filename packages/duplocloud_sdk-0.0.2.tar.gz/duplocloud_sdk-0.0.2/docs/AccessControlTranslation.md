# AccessControlTranslation


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**owner** | [**OwnerOverride**](OwnerOverride.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.access_control_translation import AccessControlTranslation

# TODO update the JSON string below
json = "{}"
# create an instance of AccessControlTranslation from a JSON string
access_control_translation_instance = AccessControlTranslation.from_json(json)
# print the JSON string representation of the object
print(AccessControlTranslation.to_json())

# convert the object into a dict
access_control_translation_dict = access_control_translation_instance.to_dict()
# create an instance of AccessControlTranslation from a dict
access_control_translation_from_dict = AccessControlTranslation.from_dict(access_control_translation_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


