# AzureNetworkRuleSet

Network rule set

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bypass** | **str** | Gets or sets specifies whether traffic is bypassed for Logging/Metrics/AzureServices. Possible values are any combination of Logging|Metrics|AzureServices (For example, \&quot;Logging, Metrics\&quot;), or None to bypass none of those traffics. Possible values include: &#39;None&#39;, &#39;Logging&#39;, &#39;Metrics&#39;, &#39;AzureServices&#39; | [optional] 
**resource_access_rules** | [**List[AzureResourceAccessRule]**](AzureResourceAccessRule.md) | Gets or sets sets the resource access rules | [optional] 
**virtual_network_rules** | [**List[AzureVirtualNetworkRule4]**](AzureVirtualNetworkRule4.md) | Gets or sets sets the virtual network rules | [optional] 
**ip_rules** | [**List[AzureIPRule]**](AzureIPRule.md) | Gets or sets sets the IP ACL rules | [optional] 
**default_action** | [**AzureDefaultAction**](AzureDefaultAction.md) | Gets or sets specifies the default action of allow or deny when no other rules match. Possible values include: &#39;Allow&#39;, &#39;Deny&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_rule_set import AzureNetworkRuleSet

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkRuleSet from a JSON string
azure_network_rule_set_instance = AzureNetworkRuleSet.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkRuleSet.to_json())

# convert the object into a dict
azure_network_rule_set_dict = azure_network_rule_set_instance.to_dict()
# create an instance of AzureNetworkRuleSet from a dict
azure_network_rule_set_from_dict = AzureNetworkRuleSet.from_dict(azure_network_rule_set_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


