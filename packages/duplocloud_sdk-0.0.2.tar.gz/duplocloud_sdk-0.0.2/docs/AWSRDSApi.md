# duplocloud_sdk.AWSRDSApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_instance_all**](AWSRDSApi.md#rds_api_instance_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance | 
[**rds_api_instance_delete**](AWSRDSApi.md#rds_api_instance_delete) | **DELETE** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 
[**rds_api_instance_get**](AWSRDSApi.md#rds_api_instance_get) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 
[**rds_api_instance_get2**](AWSRDSApi.md#rds_api_instance_get2) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/describe | 
[**rds_api_instance_post**](AWSRDSApi.md#rds_api_instance_post) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance | 
[**rds_api_instance_post2**](AWSRDSApi.md#rds_api_instance_post2) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/changePassword | 
[**rds_api_instance_post3**](AWSRDSApi.md#rds_api_instance_post3) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/replica | 
[**rds_api_instance_post4**](AWSRDSApi.md#rds_api_instance_post4) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/replica/promote | 
[**rds_api_instance_post5**](AWSRDSApi.md#rds_api_instance_post5) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/snapshot | 
[**rds_api_instance_post9**](AWSRDSApi.md#rds_api_instance_post9) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id}/authToken | 
[**rds_api_instance_put**](AWSRDSApi.md#rds_api_instance_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/instance/{id} | 


# **rds_api_instance_all**
> List[RDSDBInstanceDetails] rds_api_instance_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_all(subscription_id)
        print("The response of AWSRDSApi->rds_api_instance_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[RDSDBInstanceDetails]**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_delete**
> RDSDBInstanceDetails rds_api_instance_delete(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_delete(subscription_id, id)
        print("The response of AWSRDSApi->rds_api_instance_delete:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_delete: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_get**
> RDSDBInstanceDetails rds_api_instance_get(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get(subscription_id, id)
        print("The response of AWSRDSApi->rds_api_instance_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_get2**
> DBInstance rds_api_instance_get2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_instance import DBInstance
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_get2(subscription_id, id)
        print("The response of AWSRDSApi->rds_api_instance_get2:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_get2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBInstance**](DBInstance.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post**
> RDSDBInstanceDetails rds_api_instance_post(subscription_id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post(subscription_id, rdsdb_instance=rdsdb_instance)
        print("The response of AWSRDSApi->rds_api_instance_post:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post2**
> rds_api_instance_post2(subscription_id, id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_instance.rds_api_instance_post2(subscription_id, id, rdsdb_instance=rdsdb_instance)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post3**
> RDSDBInstanceDetails rds_api_instance_post3(subscription_id, id, rdsdb_instance=rdsdb_instance)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance import RDSDBInstance
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance = duplocloud_sdk.RDSDBInstance() # RDSDBInstance |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post3(subscription_id, id, rdsdb_instance=rdsdb_instance)
        print("The response of AWSRDSApi->rds_api_instance_post3:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance** | [**RDSDBInstance**](RDSDBInstance.md)|  | [optional] 

### Return type

[**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post4**
> rds_api_instance_post4(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_instance_post4(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post4: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post5**
> str rds_api_instance_post5(subscription_id, id, rdsdb_snapshot_request=rdsdb_snapshot_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_snapshot_request import RDSDBSnapshotRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_snapshot_request = duplocloud_sdk.RDSDBSnapshotRequest() # RDSDBSnapshotRequest |  (optional)

    try:
        api_response = api_instance.rds_api_instance_post5(subscription_id, id, rdsdb_snapshot_request=rdsdb_snapshot_request)
        print("The response of AWSRDSApi->rds_api_instance_post5:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post5: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_snapshot_request** | [**RDSDBSnapshotRequest**](RDSDBSnapshotRequest.md)|  | [optional] 

### Return type

**str**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_post9**
> str rds_api_instance_post9(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_instance_post9(subscription_id, id)
        print("The response of AWSRDSApi->rds_api_instance_post9:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_post9: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

**str**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_instance_put**
> rds_api_instance_put(subscription_id, id, modify_db_instance_request_ext=modify_db_instance_request_ext)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.modify_db_instance_request_ext import ModifyDBInstanceRequestExt
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    modify_db_instance_request_ext = duplocloud_sdk.ModifyDBInstanceRequestExt() # ModifyDBInstanceRequestExt |  (optional)

    try:
        api_instance.rds_api_instance_put(subscription_id, id, modify_db_instance_request_ext=modify_db_instance_request_ext)
    except Exception as e:
        print("Exception when calling AWSRDSApi->rds_api_instance_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **modify_db_instance_request_ext** | [**ModifyDBInstanceRequestExt**](ModifyDBInstanceRequestExt.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

