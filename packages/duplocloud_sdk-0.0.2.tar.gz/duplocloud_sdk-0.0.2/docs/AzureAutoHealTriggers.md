# AzureAutoHealTriggers


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**requests** | [**AzureRequestsBasedTrigger**](AzureRequestsBasedTrigger.md) |  | [optional] 
**private_bytes_in_kb** | **int** |  | [optional] 
**status_codes** | [**List[AzureStatusCodesBasedTrigger]**](AzureStatusCodesBasedTrigger.md) |  | [optional] 
**slow_requests** | [**AzureSlowRequestsBasedTrigger**](AzureSlowRequestsBasedTrigger.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_auto_heal_triggers import AzureAutoHealTriggers

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutoHealTriggers from a JSON string
azure_auto_heal_triggers_instance = AzureAutoHealTriggers.from_json(json)
# print the JSON string representation of the object
print(AzureAutoHealTriggers.to_json())

# convert the object into a dict
azure_auto_heal_triggers_dict = azure_auto_heal_triggers_instance.to_dict()
# create an instance of AzureAutoHealTriggers from a dict
azure_auto_heal_triggers_from_dict = AzureAutoHealTriggers.from_dict(azure_auto_heal_triggers_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


