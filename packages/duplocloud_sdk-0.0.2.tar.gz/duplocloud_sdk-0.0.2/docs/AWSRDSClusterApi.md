# duplocloud_sdk.AWSRDSClusterApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**rds_api_cluster_all**](AWSRDSClusterApi.md#rds_api_cluster_all) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/cluster | 
[**rds_api_cluster_get**](AWSRDSClusterApi.md#rds_api_cluster_get) | **GET** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id} | 
[**rds_api_cluster_post**](AWSRDSClusterApi.md#rds_api_cluster_post) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/start | 
[**rds_api_cluster_post2**](AWSRDSClusterApi.md#rds_api_cluster_post2) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/stop | 
[**rds_api_cluster_post3**](AWSRDSClusterApi.md#rds_api_cluster_post3) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/reboot | 
[**rds_api_cluster_post4**](AWSRDSClusterApi.md#rds_api_cluster_post4) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/auroraToV2Serverless | 
[**rds_api_cluster_post5**](AWSRDSClusterApi.md#rds_api_cluster_post5) | **POST** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id}/restorePointInTime | 
[**rds_api_cluster_put**](AWSRDSClusterApi.md#rds_api_cluster_put) | **PUT** /v3/subscriptions/{subscriptionId}/aws/rds/cluster/{id} | 


# **rds_api_cluster_all**
> List[DBCluster] rds_api_cluster_all(subscription_id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_cluster import DBCluster
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 

    try:
        api_response = api_instance.rds_api_cluster_all(subscription_id)
        print("The response of AWSRDSClusterApi->rds_api_cluster_all:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_all: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 

### Return type

[**List[DBCluster]**](DBCluster.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_get**
> DBCluster rds_api_cluster_get(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.db_cluster import DBCluster
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_response = api_instance.rds_api_cluster_get(subscription_id, id)
        print("The response of AWSRDSClusterApi->rds_api_cluster_get:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_get: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

[**DBCluster**](DBCluster.md)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post**
> rds_api_cluster_post(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_post: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post2**
> rds_api_cluster_post2(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post2(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_post2: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post3**
> rds_api_cluster_post3(subscription_id, id)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 

    try:
        api_instance.rds_api_cluster_post3(subscription_id, id)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_post3: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post4**
> rds_api_cluster_post4(subscription_id, id, rdsdb_instance_details=rdsdb_instance_details)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rdsdb_instance_details import RDSDBInstanceDetails
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rdsdb_instance_details = duplocloud_sdk.RDSDBInstanceDetails() # RDSDBInstanceDetails |  (optional)

    try:
        api_instance.rds_api_cluster_post4(subscription_id, id, rdsdb_instance_details=rdsdb_instance_details)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_post4: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rdsdb_instance_details** | [**RDSDBInstanceDetails**](RDSDBInstanceDetails.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_post5**
> rds_api_cluster_post5(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.rds_point_in_time_restore_request import RdsPointInTimeRestoreRequest
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    rds_point_in_time_restore_request = duplocloud_sdk.RdsPointInTimeRestoreRequest() # RdsPointInTimeRestoreRequest |  (optional)

    try:
        api_instance.rds_api_cluster_post5(subscription_id, id, rds_point_in_time_restore_request=rds_point_in_time_restore_request)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_post5: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **rds_point_in_time_restore_request** | [**RdsPointInTimeRestoreRequest**](RdsPointInTimeRestoreRequest.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rds_api_cluster_put**
> rds_api_cluster_put(subscription_id, id, modify_db_cluster_request_ext=modify_db_cluster_request_ext)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.models.modify_db_cluster_request_ext import ModifyDBClusterRequestExt
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AWSRDSClusterApi(api_client)
    subscription_id = 'subscription_id_example' # str | 
    id = 'id_example' # str | 
    modify_db_cluster_request_ext = duplocloud_sdk.ModifyDBClusterRequestExt() # ModifyDBClusterRequestExt |  (optional)

    try:
        api_instance.rds_api_cluster_put(subscription_id, id, modify_db_cluster_request_ext=modify_db_cluster_request_ext)
    except Exception as e:
        print("Exception when calling AWSRDSClusterApi->rds_api_cluster_put: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **subscription_id** | **str**|  | 
 **id** | **str**|  | 
 **modify_db_cluster_request_ext** | [**ModifyDBClusterRequestExt**](ModifyDBClusterRequestExt.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

