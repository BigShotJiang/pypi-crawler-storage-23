# AzureDiskEncryptionSettings

Describes a Encryption Settings for a Disk

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disk_encryption_key** | [**AzureKeyVaultSecretReference**](AzureKeyVaultSecretReference.md) | Gets or sets specifies the location of the disk encryption key, which is a Key Vault Secret. | [optional] 
**key_encryption_key** | [**AzureKeyVaultKeyReference**](AzureKeyVaultKeyReference.md) | Gets or sets specifies the location of the key encryption key in Key Vault. | [optional] 
**enabled** | **bool** | Gets or sets specifies whether disk encryption should be enabled on the virtual machine. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_disk_encryption_settings import AzureDiskEncryptionSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDiskEncryptionSettings from a JSON string
azure_disk_encryption_settings_instance = AzureDiskEncryptionSettings.from_json(json)
# print the JSON string representation of the object
print(AzureDiskEncryptionSettings.to_json())

# convert the object into a dict
azure_disk_encryption_settings_dict = azure_disk_encryption_settings_instance.to_dict()
# create an instance of AzureDiskEncryptionSettings from a dict
azure_disk_encryption_settings_from_dict = AzureDiskEncryptionSettings.from_dict(azure_disk_encryption_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


