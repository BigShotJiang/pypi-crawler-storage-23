# AwsServiceManagedEBSVolumeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**encrypted** | **bool** |  | [optional] 
**filesystem_type** | [**AwsTaskFilesystemType**](AwsTaskFilesystemType.md) |  | [optional] 
**iops** | **int** |  | [optional] 
**kms_key_id** | **str** |  | [optional] 
**role_arn** | **str** |  | [optional] 
**size_in_gi_b** | **int** |  | [optional] 
**snapshot_id** | **str** |  | [optional] 
**tag_specifications** | [**List[AwsEBSTagSpecification]**](AwsEBSTagSpecification.md) |  | [optional] 
**throughput** | **int** |  | [optional] 
**volume_initialization_rate** | **int** |  | [optional] 
**volume_type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_managed_ebs_volume_configuration import AwsServiceManagedEBSVolumeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceManagedEBSVolumeConfiguration from a JSON string
aws_service_managed_ebs_volume_configuration_instance = AwsServiceManagedEBSVolumeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsServiceManagedEBSVolumeConfiguration.to_json())

# convert the object into a dict
aws_service_managed_ebs_volume_configuration_dict = aws_service_managed_ebs_volume_configuration_instance.to_dict()
# create an instance of AwsServiceManagedEBSVolumeConfiguration from a dict
aws_service_managed_ebs_volume_configuration_from_dict = AwsServiceManagedEBSVolumeConfiguration.from_dict(aws_service_managed_ebs_volume_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


