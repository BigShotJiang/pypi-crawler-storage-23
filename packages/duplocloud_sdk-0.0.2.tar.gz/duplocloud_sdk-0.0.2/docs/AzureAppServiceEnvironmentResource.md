# AzureAppServiceEnvironmentResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**properties_name** | **str** |  | [optional] 
**properties_location** | **str** |  | [optional] 
**properties_provisioning_state** | [**AzureProvisioningState**](AzureProvisioningState.md) |  | [optional] 
**properties_status** | [**AzureHostingEnvironmentStatus**](AzureHostingEnvironmentStatus.md) |  | [optional] 
**properties_vnet_name** | **str** |  | [optional] 
**properties_vnet_resource_group_name** | **str** |  | [optional] 
**properties_vnet_subnet_name** | **str** |  | [optional] 
**properties_virtual_network** | [**AzureVirtualNetworkProfile**](AzureVirtualNetworkProfile.md) |  | [optional] 
**properties_internal_load_balancing_mode** | [**AzureInternalLoadBalancingMode**](AzureInternalLoadBalancingMode.md) |  | [optional] 
**properties_multi_size** | **str** |  | [optional] 
**properties_multi_role_count** | **int** |  | [optional] 
**properties_worker_pools** | [**List[AzureWorkerPool]**](AzureWorkerPool.md) |  | [optional] 
**properties_ipssl_address_count** | **int** |  | [optional] 
**properties_database_edition** | **str** |  | [optional] 
**properties_database_service_objective** | **str** |  | [optional] 
**properties_upgrade_domains** | **int** |  | [optional] 
**properties_subscription_id** | **str** |  | [optional] 
**properties_dns_suffix** | **str** |  | [optional] 
**properties_last_action** | **str** |  | [optional] 
**properties_last_action_result** | **str** |  | [optional] 
**properties_allowed_multi_sizes** | **str** |  | [optional] 
**properties_allowed_worker_sizes** | **str** |  | [optional] 
**properties_maximum_number_of_machines** | **int** |  | [optional] 
**properties_vip_mappings** | [**List[AzureVirtualIPMapping]**](AzureVirtualIPMapping.md) |  | [optional] 
**properties_environment_capacities** | [**List[AzureStampCapacity]**](AzureStampCapacity.md) |  | [optional] 
**properties_network_access_control_list** | [**List[AzureNetworkAccessControlEntry]**](AzureNetworkAccessControlEntry.md) |  | [optional] 
**properties_environment_is_healthy** | **bool** |  | [optional] 
**properties_environment_status** | **str** |  | [optional] 
**properties_resource_group** | **str** |  | [optional] 
**properties_front_end_scale_factor** | **int** |  | [optional] 
**properties_default_front_end_scale_factor** | **int** |  | [optional] 
**properties_api_management_account_id** | **str** |  | [optional] 
**properties_suspended** | **bool** |  | [optional] 
**properties_dynamic_cache_enabled** | **bool** |  | [optional] 
**properties_cluster_settings** | [**List[AzureNameValuePair]**](AzureNameValuePair.md) |  | [optional] 
**properties_user_whitelisted_ip_ranges** | **List[str]** |  | [optional] 
**properties_has_linux_workers** | **bool** |  | [optional] 
**properties_ssl_cert_key_vault_id** | **str** |  | [optional] 
**properties_ssl_cert_key_vault_secret_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_app_service_environment_resource import AzureAppServiceEnvironmentResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAppServiceEnvironmentResource from a JSON string
azure_app_service_environment_resource_instance = AzureAppServiceEnvironmentResource.from_json(json)
# print the JSON string representation of the object
print(AzureAppServiceEnvironmentResource.to_json())

# convert the object into a dict
azure_app_service_environment_resource_dict = azure_app_service_environment_resource_instance.to_dict()
# create an instance of AzureAppServiceEnvironmentResource from a dict
azure_app_service_environment_resource_from_dict = AzureAppServiceEnvironmentResource.from_dict(azure_app_service_environment_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


