# AzurePrivateLinkServiceConnection


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_private_link_service_id** | **str** |  | [optional] 
**properties_group_ids** | **List[str]** |  | [optional] 
**properties_request_message** | **str** |  | [optional] 
**properties_private_link_service_connection_state** | [**AzurePrivateLinkServiceConnectionState**](AzurePrivateLinkServiceConnectionState.md) |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service_connection import AzurePrivateLinkServiceConnection

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkServiceConnection from a JSON string
azure_private_link_service_connection_instance = AzurePrivateLinkServiceConnection.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkServiceConnection.to_json())

# convert the object into a dict
azure_private_link_service_connection_dict = azure_private_link_service_connection_instance.to_dict()
# create an instance of AzurePrivateLinkServiceConnection from a dict
azure_private_link_service_connection_from_dict = AzurePrivateLinkServiceConnection.from_dict(azure_private_link_service_connection_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


