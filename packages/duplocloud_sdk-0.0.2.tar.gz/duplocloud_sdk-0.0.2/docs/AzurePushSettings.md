# AzurePushSettings


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**properties_is_push_enabled** | **bool** |  | [optional] 
**properties_tag_whitelist_json** | **str** |  | [optional] 
**properties_tags_requiring_auth** | **str** |  | [optional] 
**properties_dynamic_tags_json** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_push_settings import AzurePushSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePushSettings from a JSON string
azure_push_settings_instance = AzurePushSettings.from_json(json)
# print the JSON string representation of the object
print(AzurePushSettings.to_json())

# convert the object into a dict
azure_push_settings_dict = azure_push_settings_instance.to_dict()
# create an instance of AzurePushSettings from a dict
azure_push_settings_from_dict = AzurePushSettings.from_dict(azure_push_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


