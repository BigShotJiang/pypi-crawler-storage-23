# AzureApiEntityReference

The API entity reference.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets the ARM resource id in the form of /subscriptions/{SubscriptionId}/resourceGroups/{ResourceGroupName}/... | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_api_entity_reference import AzureApiEntityReference

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApiEntityReference from a JSON string
azure_api_entity_reference_instance = AzureApiEntityReference.from_json(json)
# print the JSON string representation of the object
print(AzureApiEntityReference.to_json())

# convert the object into a dict
azure_api_entity_reference_dict = azure_api_entity_reference_instance.to_dict()
# create an instance of AzureApiEntityReference from a dict
azure_api_entity_reference_from_dict = AzureApiEntityReference.from_dict(azure_api_entity_reference_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


