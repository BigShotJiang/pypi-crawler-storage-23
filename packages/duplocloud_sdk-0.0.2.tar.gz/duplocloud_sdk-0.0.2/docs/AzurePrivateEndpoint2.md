# AzurePrivateEndpoint2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint2 import AzurePrivateEndpoint2

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpoint2 from a JSON string
azure_private_endpoint2_instance = AzurePrivateEndpoint2.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpoint2.to_json())

# convert the object into a dict
azure_private_endpoint2_dict = azure_private_endpoint2_instance.to_dict()
# create an instance of AzurePrivateEndpoint2 from a dict
azure_private_endpoint2_from_dict = AzurePrivateEndpoint2.from_dict(azure_private_endpoint2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


