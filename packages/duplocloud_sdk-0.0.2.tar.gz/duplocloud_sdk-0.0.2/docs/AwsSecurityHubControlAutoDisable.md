# AwsSecurityHubControlAutoDisable


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**standards_prefix** | **str** |  | [optional] 
**control_id** | **str** |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_security_hub_control_auto_disable import AwsSecurityHubControlAutoDisable

# TODO update the JSON string below
json = "{}"
# create an instance of AwsSecurityHubControlAutoDisable from a JSON string
aws_security_hub_control_auto_disable_instance = AwsSecurityHubControlAutoDisable.from_json(json)
# print the JSON string representation of the object
print(AwsSecurityHubControlAutoDisable.to_json())

# convert the object into a dict
aws_security_hub_control_auto_disable_dict = aws_security_hub_control_auto_disable_instance.to_dict()
# create an instance of AwsSecurityHubControlAutoDisable from a dict
aws_security_hub_control_auto_disable_from_dict = AwsSecurityHubControlAutoDisable.from_dict(aws_security_hub_control_auto_disable_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


