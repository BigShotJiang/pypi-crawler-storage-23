# AzureDiskEncryptionSetParameters


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource Id | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_disk_encryption_set_parameters import AzureDiskEncryptionSetParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AzureDiskEncryptionSetParameters from a JSON string
azure_disk_encryption_set_parameters_instance = AzureDiskEncryptionSetParameters.from_json(json)
# print the JSON string representation of the object
print(AzureDiskEncryptionSetParameters.to_json())

# convert the object into a dict
azure_disk_encryption_set_parameters_dict = azure_disk_encryption_set_parameters_instance.to_dict()
# create an instance of AzureDiskEncryptionSetParameters from a dict
azure_disk_encryption_set_parameters_from_dict = AzureDiskEncryptionSetParameters.from_dict(azure_disk_encryption_set_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


