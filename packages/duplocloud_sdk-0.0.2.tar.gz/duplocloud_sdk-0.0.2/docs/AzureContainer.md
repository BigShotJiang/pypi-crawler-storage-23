# AzureContainer

A container instance.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the user-provided name of the container instance. | [optional] 
**properties_image** | **str** | Gets or sets the name of the image used to create the container instance. | [optional] 
**properties_command** | **List[str]** | Gets or sets the commands to execute within the container instance in exec form. | [optional] 
**properties_ports** | [**List[AzureContainerPort]**](AzureContainerPort.md) | Gets or sets the exposed ports on the container instance. | [optional] 
**properties_environment_variables** | [**List[AzureEnvironmentVariable]**](AzureEnvironmentVariable.md) | Gets or sets the environment variables to set in the container instance. | [optional] 
**properties_instance_view** | [**AzureContainerPropertiesInstanceView**](AzureContainerPropertiesInstanceView.md) | Gets the instance view of the container instance. Only valid in response. | [optional] 
**properties_resources** | [**AzureResourceRequirements**](AzureResourceRequirements.md) | Gets or sets the resource requirements of the container instance. | [optional] 
**properties_volume_mounts** | [**List[AzureVolumeMount]**](AzureVolumeMount.md) | Gets or sets the volume mounts available to the container instance. | [optional] 
**properties_liveness_probe** | [**AzureContainerProbe**](AzureContainerProbe.md) | Gets or sets the liveness probe. | [optional] 
**properties_readiness_probe** | [**AzureContainerProbe**](AzureContainerProbe.md) | Gets or sets the readiness probe. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container import AzureContainer

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainer from a JSON string
azure_container_instance = AzureContainer.from_json(json)
# print the JSON string representation of the object
print(AzureContainer.to_json())

# convert the object into a dict
azure_container_dict = azure_container_instance.to_dict()
# create an instance of AzureContainer from a dict
azure_container_from_dict = AzureContainer.from_dict(azure_container_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


