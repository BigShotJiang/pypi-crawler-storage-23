# AzurePlan

Specifies information about the marketplace image used to create the virtual machine. This element is only used for marketplace images. Before you can use a marketplace image from an API, you must enable the image for programmatic use.  In the Azure portal, find the marketplace image that you want to use and then click **Want to deploy programmatically, Get Started ->**. Enter any required information and then click **Save**.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets the plan ID. | [optional] 
**publisher** | **str** | Gets or sets the publisher ID. | [optional] 
**product** | **str** | Gets or sets specifies the product of the image from the marketplace. This is the same value as Offer under the imageReference element. | [optional] 
**promotion_code** | **str** | Gets or sets the promotion code. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_plan import AzurePlan

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePlan from a JSON string
azure_plan_instance = AzurePlan.from_json(json)
# print the JSON string representation of the object
print(AzurePlan.to_json())

# convert the object into a dict
azure_plan_dict = azure_plan_instance.to_dict()
# create an instance of AzurePlan from a dict
azure_plan_from_dict = AzurePlan.from_dict(azure_plan_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


