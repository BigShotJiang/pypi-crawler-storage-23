# AwsVolumeFrom


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**read_only** | **bool** |  | [optional] 
**source_container** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_volume_from import AwsVolumeFrom

# TODO update the JSON string below
json = "{}"
# create an instance of AwsVolumeFrom from a JSON string
aws_volume_from_instance = AwsVolumeFrom.from_json(json)
# print the JSON string representation of the object
print(AwsVolumeFrom.to_json())

# convert the object into a dict
aws_volume_from_dict = aws_volume_from_instance.to_dict()
# create an instance of AwsVolumeFrom from a dict
aws_volume_from_from_dict = AwsVolumeFrom.from_dict(aws_volume_from_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


