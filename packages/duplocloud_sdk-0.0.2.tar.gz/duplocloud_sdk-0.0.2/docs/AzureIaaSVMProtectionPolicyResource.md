# AzureIaaSVMProtectionPolicyResource


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**e_tag** | **str** |  | [optional] 
**properties** | [**AzureAzureIaaSVMProtectionPolicy**](AzureAzureIaaSVMProtectionPolicy.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_iaa_svm_protection_policy_resource import AzureIaaSVMProtectionPolicyResource

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIaaSVMProtectionPolicyResource from a JSON string
azure_iaa_svm_protection_policy_resource_instance = AzureIaaSVMProtectionPolicyResource.from_json(json)
# print the JSON string representation of the object
print(AzureIaaSVMProtectionPolicyResource.to_json())

# convert the object into a dict
azure_iaa_svm_protection_policy_resource_dict = azure_iaa_svm_protection_policy_resource_instance.to_dict()
# create an instance of AzureIaaSVMProtectionPolicyResource from a dict
azure_iaa_svm_protection_policy_resource_from_dict = AzureIaaSVMProtectionPolicyResource.from_dict(azure_iaa_svm_protection_policy_resource_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


