# AwsLogConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_driver** | [**AwsLogDriver**](AwsLogDriver.md) |  | [optional] 
**options** | **Dict[str, str]** |  | [optional] 
**secret_options** | [**List[AwsSecret]**](AwsSecret.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_log_configuration import AwsLogConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLogConfiguration from a JSON string
aws_log_configuration_instance = AwsLogConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsLogConfiguration.to_json())

# convert the object into a dict
aws_log_configuration_dict = aws_log_configuration_instance.to_dict()
# create an instance of AwsLogConfiguration from a dict
aws_log_configuration_from_dict = AwsLogConfiguration.from_dict(aws_log_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


