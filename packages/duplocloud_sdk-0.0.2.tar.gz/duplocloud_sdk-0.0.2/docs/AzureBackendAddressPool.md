# AzureBackendAddressPool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_location** | **str** |  | [optional] 
**properties_tunnel_interfaces** | [**List[AzureGatewayLoadBalancerTunnelInterface]**](AzureGatewayLoadBalancerTunnelInterface.md) |  | [optional] 
**properties_load_balancer_backend_addresses** | [**List[AzureLoadBalancerBackendAddress]**](AzureLoadBalancerBackendAddress.md) |  | [optional] 
**properties_backend_ip_configurations** | [**List[AzureNetworkInterfaceIPConfiguration]**](AzureNetworkInterfaceIPConfiguration.md) |  | [optional] 
**properties_load_balancing_rules** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_outbound_rule** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_outbound_rules** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_inbound_nat_rules** | [**List[AzureSubResource]**](AzureSubResource.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_drain_period_in_seconds** | **int** |  | [optional] 
**properties_virtual_network** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_backend_address_pool import AzureBackendAddressPool

# TODO update the JSON string below
json = "{}"
# create an instance of AzureBackendAddressPool from a JSON string
azure_backend_address_pool_instance = AzureBackendAddressPool.from_json(json)
# print the JSON string representation of the object
print(AzureBackendAddressPool.to_json())

# convert the object into a dict
azure_backend_address_pool_dict = azure_backend_address_pool_instance.to_dict()
# create an instance of AzureBackendAddressPool from a dict
azure_backend_address_pool_from_dict = AzureBackendAddressPool.from_dict(azure_backend_address_pool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


