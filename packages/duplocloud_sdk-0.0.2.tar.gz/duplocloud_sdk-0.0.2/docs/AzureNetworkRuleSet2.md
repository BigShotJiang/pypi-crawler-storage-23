# AzureNetworkRuleSet2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**bypass** | **str** |  | [optional] 
**default_action** | **str** |  | [optional] 
**ip_rules** | [**List[AzureIPRule2]**](AzureIPRule2.md) |  | [optional] 
**virtual_network_rules** | [**List[AzureVirtualNetworkRule5]**](AzureVirtualNetworkRule5.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_rule_set2 import AzureNetworkRuleSet2

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkRuleSet2 from a JSON string
azure_network_rule_set2_instance = AzureNetworkRuleSet2.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkRuleSet2.to_json())

# convert the object into a dict
azure_network_rule_set2_dict = azure_network_rule_set2_instance.to_dict()
# create an instance of AzureNetworkRuleSet2 from a dict
azure_network_rule_set2_from_dict = AzureNetworkRuleSet2.from_dict(azure_network_rule_set2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


