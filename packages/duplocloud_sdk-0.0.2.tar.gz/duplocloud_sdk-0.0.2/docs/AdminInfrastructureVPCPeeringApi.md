# duplocloud_sdk.AdminInfrastructureVPCPeeringApi

All URIs are relative to *http://localhost*

Method | HTTP request | Description
------------- | ------------- | -------------
[**v3_admin_infrastructure_api_create_vpc_peering_connection**](AdminInfrastructureVPCPeeringApi.md#v3_admin_infrastructure_api_create_vpc_peering_connection) | **POST** /v3/admin/infrastructure/{name}/vpcPeerings | 
[**v3_admin_infrastructure_api_delete_vpc_peering_connection**](AdminInfrastructureVPCPeeringApi.md#v3_admin_infrastructure_api_delete_vpc_peering_connection) | **POST** /v3/admin/infrastructure/{name}/vpcPeerings/delete | 
[**v3_admin_infrastructure_api_get_all_vpc_peerings**](AdminInfrastructureVPCPeeringApi.md#v3_admin_infrastructure_api_get_all_vpc_peerings) | **GET** /v3/admin/infrastructure/allVpcPeerings | 
[**v3_admin_infrastructure_api_get_vpc_peerings**](AdminInfrastructureVPCPeeringApi.md#v3_admin_infrastructure_api_get_vpc_peerings) | **GET** /v3/admin/infrastructure/{name}/vpcPeerings | 


# **v3_admin_infrastructure_api_create_vpc_peering_connection**
> List[str] v3_admin_infrastructure_api_create_vpc_peering_connection(name, request_body=request_body)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeeringApi(api_client)
    name = 'name_example' # str | 
    request_body = ['request_body_example'] # List[str] |  (optional)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_create_vpc_peering_connection(name, request_body=request_body)
        print("The response of AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_create_vpc_peering_connection:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_create_vpc_peering_connection: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **request_body** | [**List[str]**](str.md)|  | [optional] 

### Return type

**List[str]**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_delete_vpc_peering_connection**
> v3_admin_infrastructure_api_delete_vpc_peering_connection(name, request_body=request_body)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeeringApi(api_client)
    name = 'name_example' # str | 
    request_body = ['request_body_example'] # List[str] |  (optional)

    try:
        api_instance.v3_admin_infrastructure_api_delete_vpc_peering_connection(name, request_body=request_body)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_delete_vpc_peering_connection: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 
 **request_body** | [**List[str]**](str.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**204** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_all_vpc_peerings**
> List[str] v3_admin_infrastructure_api_get_all_vpc_peerings()

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeeringApi(api_client)

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_all_vpc_peerings()
        print("The response of AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_get_all_vpc_peerings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_get_all_vpc_peerings: %s\n" % e)
```



### Parameters

This endpoint does not need any parameter.

### Return type

**List[str]**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **v3_admin_infrastructure_api_get_vpc_peerings**
> List[str] v3_admin_infrastructure_api_get_vpc_peerings(name)

### Example

* Bearer (Duplo token) Authentication (bearerAuth):

```python
import duplocloud_sdk
from duplocloud_sdk.rest import ApiException
from pprint import pprint

# Defining the host is optional and defaults to http://localhost
# See configuration.py for a list of all supported configuration parameters.
configuration = duplocloud_sdk.Configuration(
    host = "http://localhost"
)

# The client must configure the authentication and authorization parameters
# in accordance with the API server security policy.
# Examples for each auth method are provided below, use the example that
# satisfies your auth use case.

# Configure Bearer authorization (Duplo token): bearerAuth
configuration = duplocloud_sdk.Configuration(
    access_token = os.environ["BEARER_TOKEN"]
)

# Enter a context with an instance of the API client
with duplocloud_sdk.ApiClient(configuration) as api_client:
    # Create an instance of the API class
    api_instance = duplocloud_sdk.AdminInfrastructureVPCPeeringApi(api_client)
    name = 'name_example' # str | 

    try:
        api_response = api_instance.v3_admin_infrastructure_api_get_vpc_peerings(name)
        print("The response of AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_get_vpc_peerings:\n")
        pprint(api_response)
    except Exception as e:
        print("Exception when calling AdminInfrastructureVPCPeeringApi->v3_admin_infrastructure_api_get_vpc_peerings: %s\n" % e)
```



### Parameters


Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **str**|  | 

### Return type

**List[str]**

### Authorization

[bearerAuth](../README.md#bearerAuth)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

### HTTP response details

| Status code | Description | Response headers |
|-------------|-------------|------------------|
**200** |  |  -  |

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

