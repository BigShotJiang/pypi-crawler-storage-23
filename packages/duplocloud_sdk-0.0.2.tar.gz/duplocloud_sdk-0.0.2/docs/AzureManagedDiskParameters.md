# AzureManagedDiskParameters


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource Id | [optional] 
**storage_account_type** | **str** | Gets or sets specifies the storage account type for the managed disk. NOTE: UltraSSD_LRS can only be used with data disks, it cannot be used with OS Disk. Possible values include: &#39;Standard_LRS&#39;, &#39;Premium_LRS&#39;, &#39;StandardSSD_LRS&#39;, &#39;UltraSSD_LRS&#39;, &#39;Premium_ZRS&#39;, &#39;StandardSSD_ZRS&#39;, &#39;PremiumV2_LRS&#39; | [optional] 
**disk_encryption_set** | [**AzureDiskEncryptionSetParameters**](AzureDiskEncryptionSetParameters.md) | Gets or sets specifies the customer managed disk encryption set resource id for the managed disk. | [optional] 
**security_profile** | [**AzureVMDiskSecurityProfile**](AzureVMDiskSecurityProfile.md) | Gets or sets specifies the security profile for the managed disk. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_managed_disk_parameters import AzureManagedDiskParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AzureManagedDiskParameters from a JSON string
azure_managed_disk_parameters_instance = AzureManagedDiskParameters.from_json(json)
# print the JSON string representation of the object
print(AzureManagedDiskParameters.to_json())

# convert the object into a dict
azure_managed_disk_parameters_dict = azure_managed_disk_parameters_instance.to_dict()
# create an instance of AzureManagedDiskParameters from a dict
azure_managed_disk_parameters_from_dict = AzureManagedDiskParameters.from_dict(azure_managed_disk_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


