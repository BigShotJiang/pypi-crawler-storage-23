# AzureApplicationGatewayFirewallDisabledRuleGroup


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**rule_group_name** | **str** |  | [optional] 
**rules** | **List[int]** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_firewall_disabled_rule_group import AzureApplicationGatewayFirewallDisabledRuleGroup

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayFirewallDisabledRuleGroup from a JSON string
azure_application_gateway_firewall_disabled_rule_group_instance = AzureApplicationGatewayFirewallDisabledRuleGroup.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayFirewallDisabledRuleGroup.to_json())

# convert the object into a dict
azure_application_gateway_firewall_disabled_rule_group_dict = azure_application_gateway_firewall_disabled_rule_group_instance.to_dict()
# create an instance of AzureApplicationGatewayFirewallDisabledRuleGroup from a dict
azure_application_gateway_firewall_disabled_rule_group_from_dict = AzureApplicationGatewayFirewallDisabledRuleGroup.from_dict(azure_application_gateway_firewall_disabled_rule_group_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


