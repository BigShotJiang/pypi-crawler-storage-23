# AzurePrivateEndpoint


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**extended_location** | [**AzureExtendedLocation**](AzureExtendedLocation.md) |  | [optional] 
**properties_subnet** | [**AzureSubnet**](AzureSubnet.md) |  | [optional] 
**properties_network_interfaces** | [**List[AzureNetworkInterface]**](AzureNetworkInterface.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_private_link_service_connections** | [**List[AzurePrivateLinkServiceConnection]**](AzurePrivateLinkServiceConnection.md) |  | [optional] 
**properties_manual_private_link_service_connections** | [**List[AzurePrivateLinkServiceConnection]**](AzurePrivateLinkServiceConnection.md) |  | [optional] 
**properties_custom_dns_configs** | [**List[AzureCustomDnsConfigPropertiesFormat]**](AzureCustomDnsConfigPropertiesFormat.md) |  | [optional] 
**properties_application_security_groups** | [**List[AzureApplicationSecurityGroup]**](AzureApplicationSecurityGroup.md) |  | [optional] 
**properties_ip_configurations** | [**List[AzurePrivateEndpointIPConfiguration]**](AzurePrivateEndpointIPConfiguration.md) |  | [optional] 
**properties_custom_network_interface_name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint import AzurePrivateEndpoint

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpoint from a JSON string
azure_private_endpoint_instance = AzurePrivateEndpoint.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpoint.to_json())

# convert the object into a dict
azure_private_endpoint_dict = azure_private_endpoint_instance.to_dict()
# create an instance of AzurePrivateEndpoint from a dict
azure_private_endpoint_from_dict = AzurePrivateEndpoint.from_dict(azure_private_endpoint_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


