# AzurePriorityMixPolicy

Specifies the target splits for Spot and Regular priority VMs within a scale set with flexible orchestration mode. <br><br>With this property the customer is able to specify the base number of regular priority VMs created as the VMSS flex instance scales out and the split between Spot and Regular priority VMs after this base target has been reached.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**base_regular_priority_count** | **int** | Gets or sets the base number of regular priority VMs that will be created in this scale set as it scales out. | [optional] 
**regular_priority_percentage_above_base** | **int** | Gets or sets the percentage of VM instances, after the base regular priority count has been reached, that are expected to use regular priority. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_priority_mix_policy import AzurePriorityMixPolicy

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePriorityMixPolicy from a JSON string
azure_priority_mix_policy_instance = AzurePriorityMixPolicy.from_json(json)
# print the JSON string representation of the object
print(AzurePriorityMixPolicy.to_json())

# convert the object into a dict
azure_priority_mix_policy_dict = azure_priority_mix_policy_instance.to_dict()
# create an instance of AzurePriorityMixPolicy from a dict
azure_priority_mix_policy_from_dict = AzurePriorityMixPolicy.from_dict(azure_priority_mix_policy_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


