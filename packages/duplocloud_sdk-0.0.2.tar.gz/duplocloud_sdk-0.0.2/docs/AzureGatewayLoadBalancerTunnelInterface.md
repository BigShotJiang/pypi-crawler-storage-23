# AzureGatewayLoadBalancerTunnelInterface


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**port** | **int** |  | [optional] 
**identifier** | **int** |  | [optional] 
**protocol** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_gateway_load_balancer_tunnel_interface import AzureGatewayLoadBalancerTunnelInterface

# TODO update the JSON string below
json = "{}"
# create an instance of AzureGatewayLoadBalancerTunnelInterface from a JSON string
azure_gateway_load_balancer_tunnel_interface_instance = AzureGatewayLoadBalancerTunnelInterface.from_json(json)
# print the JSON string representation of the object
print(AzureGatewayLoadBalancerTunnelInterface.to_json())

# convert the object into a dict
azure_gateway_load_balancer_tunnel_interface_dict = azure_gateway_load_balancer_tunnel_interface_instance.to_dict()
# create an instance of AzureGatewayLoadBalancerTunnelInterface from a dict
azure_gateway_load_balancer_tunnel_interface_from_dict = AzureGatewayLoadBalancerTunnelInterface.from_dict(azure_gateway_load_balancer_tunnel_interface_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


