# AzureApiError

Api error.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**details** | [**List[AzureApiErrorBase]**](AzureApiErrorBase.md) | Gets or sets the Api error details | [optional] 
**innererror** | [**AzureInnerError**](AzureInnerError.md) | Gets or sets the Api inner error | [optional] 
**code** | **str** | Gets or sets the error code. | [optional] 
**target** | **str** | Gets or sets the target of the particular error. | [optional] 
**message** | **str** | Gets or sets the error message. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_api_error import AzureApiError

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApiError from a JSON string
azure_api_error_instance = AzureApiError.from_json(json)
# print the JSON string representation of the object
print(AzureApiError.to_json())

# convert the object into a dict
azure_api_error_dict = azure_api_error_instance.to_dict()
# create an instance of AzureApiError from a dict
azure_api_error_from_dict = AzureApiError.from_dict(azure_api_error_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


