# AzureRedisInstanceDetails

Details of single instance of redis.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ssl_port** | **int** | Gets redis instance SSL port. | [optional] 
**non_ssl_port** | **int** | Gets if enableNonSslPort is true, provides Redis instance Non-SSL port. | [optional] 
**zone** | **str** | Gets if the Cache uses availability zones, specifies availability zone where this instance is located. | [optional] 
**shard_id** | **int** | Gets if clustering is enabled, the Shard ID of Redis Instance | [optional] 
**is_master** | **bool** | Gets specifies whether the instance is a primary node. | [optional] 
**is_primary** | **bool** | Gets specifies whether the instance is a primary node. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_redis_instance_details import AzureRedisInstanceDetails

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRedisInstanceDetails from a JSON string
azure_redis_instance_details_instance = AzureRedisInstanceDetails.from_json(json)
# print the JSON string representation of the object
print(AzureRedisInstanceDetails.to_json())

# convert the object into a dict
azure_redis_instance_details_dict = azure_redis_instance_details_instance.to_dict()
# create an instance of AzureRedisInstanceDetails from a dict
azure_redis_instance_details_from_dict = AzureRedisInstanceDetails.from_dict(azure_redis_instance_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


