# AzureMaintenanceRedeployStatus

Maintenance Operation Status.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**is_customer_initiated_maintenance_allowed** | **bool** | Gets or sets true, if customer is allowed to perform Maintenance. | [optional] 
**pre_maintenance_window_start_time** | **datetime** | Gets or sets start Time for the Pre Maintenance Window. | [optional] 
**pre_maintenance_window_end_time** | **datetime** | Gets or sets end Time for the Pre Maintenance Window. | [optional] 
**maintenance_window_start_time** | **datetime** | Gets or sets start Time for the Maintenance Window. | [optional] 
**maintenance_window_end_time** | **datetime** | Gets or sets end Time for the Maintenance Window. | [optional] 
**last_operation_result_code** | [**AzureMaintenanceOperationResultCodeTypes**](AzureMaintenanceOperationResultCodeTypes.md) | Gets or sets the Last Maintenance Operation Result Code. Possible values include: &#39;None&#39;, &#39;RetryLater&#39;, &#39;MaintenanceAborted&#39;, &#39;MaintenanceCompleted&#39; | [optional] 
**last_operation_message** | **str** | Gets or sets message returned for the last Maintenance Operation. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_maintenance_redeploy_status import AzureMaintenanceRedeployStatus

# TODO update the JSON string below
json = "{}"
# create an instance of AzureMaintenanceRedeployStatus from a JSON string
azure_maintenance_redeploy_status_instance = AzureMaintenanceRedeployStatus.from_json(json)
# print the JSON string representation of the object
print(AzureMaintenanceRedeployStatus.to_json())

# convert the object into a dict
azure_maintenance_redeploy_status_dict = azure_maintenance_redeploy_status_instance.to_dict()
# create an instance of AzureMaintenanceRedeployStatus from a dict
azure_maintenance_redeploy_status_from_dict = AzureMaintenanceRedeployStatus.from_dict(azure_maintenance_redeploy_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


