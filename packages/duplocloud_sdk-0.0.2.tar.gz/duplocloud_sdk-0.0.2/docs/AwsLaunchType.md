# AwsLaunchType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_launch_type import AwsLaunchType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLaunchType from a JSON string
aws_launch_type_instance = AwsLaunchType.from_json(json)
# print the JSON string representation of the object
print(AwsLaunchType.to_json())

# convert the object into a dict
aws_launch_type_dict = aws_launch_type_instance.to_dict()
# create an instance of AwsLaunchType from a dict
aws_launch_type_from_dict = AwsLaunchType.from_dict(aws_launch_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


