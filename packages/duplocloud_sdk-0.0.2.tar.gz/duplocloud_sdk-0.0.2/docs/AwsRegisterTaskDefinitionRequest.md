# AwsRegisterTaskDefinitionRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_definitions** | [**List[AwsContainerDefinition]**](AwsContainerDefinition.md) |  | [optional] 
**cpu** | **str** |  | [optional] 
**enable_fault_injection** | **bool** |  | [optional] 
**ephemeral_storage** | [**AwsEphemeralStorage**](AwsEphemeralStorage.md) |  | [optional] 
**execution_role_arn** | **str** |  | [optional] 
**family** | **str** |  | [optional] 
**inference_accelerators** | [**List[AwsInferenceAccelerator]**](AwsInferenceAccelerator.md) |  | [optional] 
**ipc_mode** | [**AwsIpcMode**](AwsIpcMode.md) |  | [optional] 
**memory** | **str** |  | [optional] 
**network_mode** | [**AwsNetworkMode**](AwsNetworkMode.md) |  | [optional] 
**pid_mode** | [**AwsPidMode**](AwsPidMode.md) |  | [optional] 
**placement_constraints** | [**List[AwsTaskDefinitionPlacementConstraint]**](AwsTaskDefinitionPlacementConstraint.md) |  | [optional] 
**proxy_configuration** | [**AwsProxyConfiguration**](AwsProxyConfiguration.md) |  | [optional] 
**requires_compatibilities** | **List[str]** |  | [optional] 
**runtime_platform** | [**AwsRuntimePlatform**](AwsRuntimePlatform.md) |  | [optional] 
**tags** | [**List[AwsTag]**](AwsTag.md) |  | [optional] 
**task_role_arn** | **str** |  | [optional] 
**volumes** | [**List[AwsVolume]**](AwsVolume.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_register_task_definition_request import AwsRegisterTaskDefinitionRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AwsRegisterTaskDefinitionRequest from a JSON string
aws_register_task_definition_request_instance = AwsRegisterTaskDefinitionRequest.from_json(json)
# print the JSON string representation of the object
print(AwsRegisterTaskDefinitionRequest.to_json())

# convert the object into a dict
aws_register_task_definition_request_dict = aws_register_task_definition_request_instance.to_dict()
# create an instance of AwsRegisterTaskDefinitionRequest from a dict
aws_register_task_definition_request_from_dict = AwsRegisterTaskDefinitionRequest.from_dict(aws_register_task_definition_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


