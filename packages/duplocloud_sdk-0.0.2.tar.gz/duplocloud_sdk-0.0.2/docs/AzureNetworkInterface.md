# AzureNetworkInterface


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**extended_location** | [**AzureExtendedLocation**](AzureExtendedLocation.md) |  | [optional] 
**properties_virtual_machine** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_network_security_group** | [**AzureNetworkSecurityGroup**](AzureNetworkSecurityGroup.md) |  | [optional] 
**properties_private_endpoint** | [**AzurePrivateEndpoint**](AzurePrivateEndpoint.md) |  | [optional] 
**properties_ip_configurations** | [**List[AzureNetworkInterfaceIPConfiguration]**](AzureNetworkInterfaceIPConfiguration.md) |  | [optional] 
**properties_tap_configurations** | [**List[AzureNetworkInterfaceTapConfiguration]**](AzureNetworkInterfaceTapConfiguration.md) |  | [optional] 
**properties_dns_settings** | [**AzureNetworkInterfaceDnsSettings**](AzureNetworkInterfaceDnsSettings.md) |  | [optional] 
**properties_mac_address** | **str** |  | [optional] 
**properties_primary** | **bool** |  | [optional] 
**properties_vnet_encryption_supported** | **bool** |  | [optional] 
**properties_enable_accelerated_networking** | **bool** |  | [optional] 
**properties_disable_tcp_state_tracking** | **bool** |  | [optional] 
**properties_enable_ip_forwarding** | **bool** |  | [optional] 
**properties_hosted_workloads** | **List[str]** |  | [optional] 
**properties_dscp_configuration** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_resource_guid** | **str** |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_workload_type** | **str** |  | [optional] 
**properties_nic_type** | **str** |  | [optional] 
**properties_private_link_service** | [**AzurePrivateLinkService**](AzurePrivateLinkService.md) |  | [optional] 
**properties_migration_phase** | **str** |  | [optional] 
**properties_auxiliary_mode** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface import AzureNetworkInterface

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterface from a JSON string
azure_network_interface_instance = AzureNetworkInterface.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterface.to_json())

# convert the object into a dict
azure_network_interface_dict = azure_network_interface_instance.to_dict()
# create an instance of AzureNetworkInterface from a dict
azure_network_interface_from_dict = AzureNetworkInterface.from_dict(azure_network_interface_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


