# AwsServiceConnectService


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**client_aliases** | [**List[AwsServiceConnectClientAlias]**](AwsServiceConnectClientAlias.md) |  | [optional] 
**discovery_name** | **str** |  | [optional] 
**ingress_port_override** | **int** |  | [optional] 
**port_name** | **str** |  | [optional] 
**timeout** | [**AwsTimeoutConfiguration**](AwsTimeoutConfiguration.md) |  | [optional] 
**tls** | [**AwsServiceConnectTlsConfiguration**](AwsServiceConnectTlsConfiguration.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_service import AwsServiceConnectService

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectService from a JSON string
aws_service_connect_service_instance = AwsServiceConnectService.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectService.to_json())

# convert the object into a dict
aws_service_connect_service_dict = aws_service_connect_service_instance.to_dict()
# create an instance of AwsServiceConnectService from a dict
aws_service_connect_service_from_dict = AwsServiceConnectService.from_dict(aws_service_connect_service_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


