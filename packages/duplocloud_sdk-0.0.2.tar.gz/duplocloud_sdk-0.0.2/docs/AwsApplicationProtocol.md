# AwsApplicationProtocol


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_application_protocol import AwsApplicationProtocol

# TODO update the JSON string below
json = "{}"
# create an instance of AwsApplicationProtocol from a JSON string
aws_application_protocol_instance = AwsApplicationProtocol.from_json(json)
# print the JSON string representation of the object
print(AwsApplicationProtocol.to_json())

# convert the object into a dict
aws_application_protocol_dict = aws_application_protocol_instance.to_dict()
# create an instance of AwsApplicationProtocol from a dict
aws_application_protocol_from_dict = AwsApplicationProtocol.from_dict(aws_application_protocol_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


