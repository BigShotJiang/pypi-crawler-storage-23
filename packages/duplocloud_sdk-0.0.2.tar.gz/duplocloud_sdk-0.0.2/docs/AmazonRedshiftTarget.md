# AmazonRedshiftTarget


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**AmazonRedshiftNodeData**](AmazonRedshiftNodeData.md) |  | [optional] 
**inputs** | **List[str]** |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amazon_redshift_target import AmazonRedshiftTarget

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonRedshiftTarget from a JSON string
amazon_redshift_target_instance = AmazonRedshiftTarget.from_json(json)
# print the JSON string representation of the object
print(AmazonRedshiftTarget.to_json())

# convert the object into a dict
amazon_redshift_target_dict = amazon_redshift_target_instance.to_dict()
# create an instance of AmazonRedshiftTarget from a dict
amazon_redshift_target_from_dict = AmazonRedshiftTarget.from_dict(amazon_redshift_target_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


