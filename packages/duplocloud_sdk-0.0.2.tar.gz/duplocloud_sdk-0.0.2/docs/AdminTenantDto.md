# AdminTenantDto


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **str** |  | [optional] 
**account_name** | **str** |  | [optional] 
**plan_id** | **str** |  | [optional] 
**address_range** | [**IPAddressRange**](IPAddressRange.md) |  | [optional] 
**networks** | [**Dict[str, Network]**](Network.md) |  | [optional] 
**nw_provider** | [**NetworkProvider**](NetworkProvider.md) |  | [optional] 
**infra_owner** | **str** |  | [optional] 
**storage_accounts** | [**List[StorageAccount]**](StorageAccount.md) |  | [optional] 
**env** | **str** |  | [optional] 
**tenant_policy** | [**Policy**](Policy.md) |  | [optional] 
**tenant_access_grants** | [**List[PolicyAccessGrant]**](PolicyAccessGrant.md) |  | [optional] 
**expiry** | **str** |  | [optional] 
**pause_time** | **str** |  | [optional] 
**monitoring_cfg** | [**MonConfig**](MonConfig.md) |  | [optional] 
**tags** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**metadata** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**creation_time** | **str** |  | [optional] 
**use_lb_index** | **bool** |  | [optional] 
**existing_k8s_namespace** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.admin_tenant_dto import AdminTenantDto

# TODO update the JSON string below
json = "{}"
# create an instance of AdminTenantDto from a JSON string
admin_tenant_dto_instance = AdminTenantDto.from_json(json)
# print the JSON string representation of the object
print(AdminTenantDto.to_json())

# convert the object into a dict
admin_tenant_dto_dict = admin_tenant_dto_instance.to_dict()
# create an instance of AdminTenantDto from a dict
admin_tenant_dto_from_dict = AdminTenantDto.from_dict(admin_tenant_dto_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


