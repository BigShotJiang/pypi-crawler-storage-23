# AwsSecret


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**value_from** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_secret import AwsSecret

# TODO update the JSON string below
json = "{}"
# create an instance of AwsSecret from a JSON string
aws_secret_instance = AwsSecret.from_json(json)
# print the JSON string representation of the object
print(AwsSecret.to_json())

# convert the object into a dict
aws_secret_dict = aws_secret_instance.to_dict()
# create an instance of AwsSecret from a dict
aws_secret_from_dict = AwsSecret.from_dict(aws_secret_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


