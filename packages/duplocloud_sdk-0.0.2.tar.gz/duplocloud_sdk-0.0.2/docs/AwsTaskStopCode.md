# AwsTaskStopCode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_task_stop_code import AwsTaskStopCode

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTaskStopCode from a JSON string
aws_task_stop_code_instance = AwsTaskStopCode.from_json(json)
# print the JSON string representation of the object
print(AwsTaskStopCode.to_json())

# convert the object into a dict
aws_task_stop_code_dict = aws_task_stop_code_instance.to_dict()
# create an instance of AwsTaskStopCode from a dict
aws_task_stop_code_from_dict = AwsTaskStopCode.from_dict(aws_task_stop_code_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


