# AzurePatchSettings

Specifies settings related to VM Guest Patching on Windows.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**patch_mode** | **str** | Gets or sets specifies the mode of VM Guest Patching to IaaS virtual machine or virtual machines associated to virtual machine scale set with OrchestrationMode as Flexible.&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; Possible values are:&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **Manual** - You  control the application of patches to a virtual machine. You do this by applying patches manually inside the VM. In this mode, automatic updates are disabled; the property WindowsConfiguration.enableAutomaticUpdates must be false&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **AutomaticByOS** - The virtual machine will automatically be updated by the OS. The property WindowsConfiguration.enableAutomaticUpdates must be true. &amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **AutomaticByPlatform** - the virtual machine will automatically updated by the platform. The properties provisionVMAgent and WindowsConfiguration.enableAutomaticUpdates must be true. Possible values include: &#39;Manual&#39;, &#39;AutomaticByOS&#39;, &#39;AutomaticByPlatform&#39; | [optional] 
**enable_hotpatching** | **bool** | Gets or sets enables customers to patch their Azure VMs without requiring a reboot. For enableHotpatching, the &#39;provisionVMAgent&#39; must be set to true and &#39;patchMode&#39; must be set to &#39;AutomaticByPlatform&#39;. | [optional] 
**assessment_mode** | **str** | Gets or sets specifies the mode of VM Guest patch assessment for the IaaS virtual machine.&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; Possible values are:&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **ImageDefault** - You control the timing of patch assessments on a virtual machine.&amp;lt;br /&amp;gt;&amp;lt;br /&amp;gt; **AutomaticByPlatform** - The platform will trigger periodic patch assessments. The property provisionVMAgent must be true. Possible values include: &#39;ImageDefault&#39;, &#39;AutomaticByPlatform&#39; | [optional] 
**automatic_by_platform_settings** | [**AzureWindowsVMGuestPatchAutomaticByPlatformSettings**](AzureWindowsVMGuestPatchAutomaticByPlatformSettings.md) | Gets or sets specifies additional settings for patch mode AutomaticByPlatform in VM Guest Patching on Windows. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_patch_settings import AzurePatchSettings

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePatchSettings from a JSON string
azure_patch_settings_instance = AzurePatchSettings.from_json(json)
# print the JSON string representation of the object
print(AzurePatchSettings.to_json())

# convert the object into a dict
azure_patch_settings_dict = azure_patch_settings_instance.to_dict()
# create an instance of AzurePatchSettings from a dict
azure_patch_settings_from_dict = AzurePatchSettings.from_dict(azure_patch_settings_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


