# AzureComponentNames

Defines values for ComponentNames.

## Enum

* `MicrosoftWindowsShellSetup` (value: `'Microsoft-Windows-Shell-Setup'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


