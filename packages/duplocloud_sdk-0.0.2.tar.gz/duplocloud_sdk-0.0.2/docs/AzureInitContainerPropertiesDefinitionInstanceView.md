# AzureInitContainerPropertiesDefinitionInstanceView

The instance view of the init container. Only valid in response.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**restart_count** | **int** | Gets the number of times that the init container has been restarted. | [optional] 
**current_state** | [**AzureContainerState**](AzureContainerState.md) | Gets the current state of the init container. | [optional] 
**previous_state** | [**AzureContainerState**](AzureContainerState.md) | Gets the previous state of the init container. | [optional] 
**events** | [**List[AzureEventModel]**](AzureEventModel.md) | Gets the events of the init container. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_init_container_properties_definition_instance_view import AzureInitContainerPropertiesDefinitionInstanceView

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInitContainerPropertiesDefinitionInstanceView from a JSON string
azure_init_container_properties_definition_instance_view_instance = AzureInitContainerPropertiesDefinitionInstanceView.from_json(json)
# print the JSON string representation of the object
print(AzureInitContainerPropertiesDefinitionInstanceView.to_json())

# convert the object into a dict
azure_init_container_properties_definition_instance_view_dict = azure_init_container_properties_definition_instance_view_instance.to_dict()
# create an instance of AzureInitContainerPropertiesDefinitionInstanceView from a dict
azure_init_container_properties_definition_instance_view_from_dict = AzureInitContainerPropertiesDefinitionInstanceView.from_dict(azure_init_container_properties_definition_instance_view_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


