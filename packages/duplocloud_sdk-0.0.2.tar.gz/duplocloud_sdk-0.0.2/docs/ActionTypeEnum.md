# ActionTypeEnum


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.action_type_enum import ActionTypeEnum

# TODO update the JSON string below
json = "{}"
# create an instance of ActionTypeEnum from a JSON string
action_type_enum_instance = ActionTypeEnum.from_json(json)
# print the JSON string representation of the object
print(ActionTypeEnum.to_json())

# convert the object into a dict
action_type_enum_dict = action_type_enum_instance.to_dict()
# create an instance of ActionTypeEnum from a dict
action_type_enum_from_dict = ActionTypeEnum.from_dict(action_type_enum_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


