# AzureInboundNatRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_frontend_ip_configuration** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_backend_ip_configuration** | [**AzureNetworkInterfaceIPConfiguration**](AzureNetworkInterfaceIPConfiguration.md) |  | [optional] 
**properties_protocol** | **str** |  | [optional] 
**properties_frontend_port** | **int** |  | [optional] 
**properties_backend_port** | **int** |  | [optional] 
**properties_idle_timeout_in_minutes** | **int** |  | [optional] 
**properties_enable_floating_ip** | **bool** |  | [optional] 
**properties_enable_tcp_reset** | **bool** |  | [optional] 
**properties_frontend_port_range_start** | **int** |  | [optional] 
**properties_frontend_port_range_end** | **int** |  | [optional] 
**properties_backend_address_pool** | [**AzureSubResource**](AzureSubResource.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_inbound_nat_rule import AzureInboundNatRule

# TODO update the JSON string below
json = "{}"
# create an instance of AzureInboundNatRule from a JSON string
azure_inbound_nat_rule_instance = AzureInboundNatRule.from_json(json)
# print the JSON string representation of the object
print(AzureInboundNatRule.to_json())

# convert the object into a dict
azure_inbound_nat_rule_dict = azure_inbound_nat_rule_instance.to_dict()
# create an instance of AzureInboundNatRule from a dict
azure_inbound_nat_rule_from_dict = AzureInboundNatRule.from_dict(azure_inbound_nat_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


