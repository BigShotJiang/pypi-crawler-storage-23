# AwsInferenceAcceleratorOverride


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**device_name** | **str** |  | [optional] 
**device_type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_inference_accelerator_override import AwsInferenceAcceleratorOverride

# TODO update the JSON string below
json = "{}"
# create an instance of AwsInferenceAcceleratorOverride from a JSON string
aws_inference_accelerator_override_instance = AwsInferenceAcceleratorOverride.from_json(json)
# print the JSON string representation of the object
print(AwsInferenceAcceleratorOverride.to_json())

# convert the object into a dict
aws_inference_accelerator_override_dict = aws_inference_accelerator_override_instance.to_dict()
# create an instance of AwsInferenceAcceleratorOverride from a dict
aws_inference_accelerator_override_from_dict = AwsInferenceAcceleratorOverride.from_dict(aws_inference_accelerator_override_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


