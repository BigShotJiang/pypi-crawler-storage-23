# AwsTmpfs


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_path** | **str** |  | [optional] 
**mount_options** | **List[str]** |  | [optional] 
**size** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_tmpfs import AwsTmpfs

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTmpfs from a JSON string
aws_tmpfs_instance = AwsTmpfs.from_json(json)
# print the JSON string representation of the object
print(AwsTmpfs.to_json())

# convert the object into a dict
aws_tmpfs_dict = aws_tmpfs_instance.to_dict()
# create an instance of AwsTmpfs from a dict
aws_tmpfs_from_dict = AwsTmpfs.from_dict(aws_tmpfs_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


