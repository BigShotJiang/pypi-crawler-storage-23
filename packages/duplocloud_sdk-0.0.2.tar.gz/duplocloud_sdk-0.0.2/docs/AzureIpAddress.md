# AzureIpAddress

IP address for the container group.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ports** | [**List[AzurePort]**](AzurePort.md) | Gets or sets the list of ports exposed on the container group. | [optional] 
**type** | **str** | Gets or sets specifies if the IP is exposed to the public internet or private VNET. Possible values include: &#39;Public&#39;, &#39;Private&#39; | [optional] 
**ip** | **str** | Gets or sets the IP exposed to the public internet. | [optional] 
**dns_name_label** | **str** | Gets or sets the Dns name label for the IP. | [optional] 
**fqdn** | **str** | Gets the FQDN for the IP. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_ip_address import AzureIpAddress

# TODO update the JSON string below
json = "{}"
# create an instance of AzureIpAddress from a JSON string
azure_ip_address_instance = AzureIpAddress.from_json(json)
# print the JSON string representation of the object
print(AzureIpAddress.to_json())

# convert the object into a dict
azure_ip_address_dict = azure_ip_address_instance.to_dict()
# create an instance of AzureIpAddress from a dict
azure_ip_address_from_dict = AzureIpAddress.from_dict(azure_ip_address_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


