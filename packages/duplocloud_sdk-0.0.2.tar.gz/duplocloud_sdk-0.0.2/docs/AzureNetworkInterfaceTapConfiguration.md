# AzureNetworkInterfaceTapConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**properties_virtual_network_tap** | [**AzureVirtualNetworkTap**](AzureVirtualNetworkTap.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**etag** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_interface_tap_configuration import AzureNetworkInterfaceTapConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkInterfaceTapConfiguration from a JSON string
azure_network_interface_tap_configuration_instance = AzureNetworkInterfaceTapConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkInterfaceTapConfiguration.to_json())

# convert the object into a dict
azure_network_interface_tap_configuration_dict = azure_network_interface_tap_configuration_instance.to_dict()
# create an instance of AzureNetworkInterfaceTapConfiguration from a dict
azure_network_interface_tap_configuration_from_dict = AzureNetworkInterfaceTapConfiguration.from_dict(azure_network_interface_tap_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


