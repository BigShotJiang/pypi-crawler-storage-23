# AzureIpFilterTag



## Enum

* `Default` (value: `'Default'`)

* `XffProxy` (value: `'XffProxy'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


