# AwsLogDriver


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_log_driver import AwsLogDriver

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLogDriver from a JSON string
aws_log_driver_instance = AwsLogDriver.from_json(json)
# print the JSON string representation of the object
print(AwsLogDriver.to_json())

# convert the object into a dict
aws_log_driver_dict = aws_log_driver_instance.to_dict()
# create an instance of AwsLogDriver from a dict
aws_log_driver_from_dict = AwsLogDriver.from_dict(aws_log_driver_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


