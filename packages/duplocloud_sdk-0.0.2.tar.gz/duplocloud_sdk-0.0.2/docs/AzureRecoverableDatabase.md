# AzureRecoverableDatabase


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**properties_edition** | **str** |  | [optional] 
**properties_service_level_objective** | **str** |  | [optional] 
**properties_elastic_pool_name** | **str** |  | [optional] 
**properties_last_available_backup_date** | **datetime** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_recoverable_database import AzureRecoverableDatabase

# TODO update the JSON string below
json = "{}"
# create an instance of AzureRecoverableDatabase from a JSON string
azure_recoverable_database_instance = AzureRecoverableDatabase.from_json(json)
# print the JSON string representation of the object
print(AzureRecoverableDatabase.to_json())

# convert the object into a dict
azure_recoverable_database_dict = azure_recoverable_database_instance.to_dict()
# create an instance of AzureRecoverableDatabase from a dict
azure_recoverable_database_from_dict = AzureRecoverableDatabase.from_dict(azure_recoverable_database_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


