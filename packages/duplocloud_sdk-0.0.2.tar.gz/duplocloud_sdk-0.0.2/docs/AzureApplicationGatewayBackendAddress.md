# AzureApplicationGatewayBackendAddress


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fqdn** | **str** |  | [optional] 
**ip_address** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_application_gateway_backend_address import AzureApplicationGatewayBackendAddress

# TODO update the JSON string below
json = "{}"
# create an instance of AzureApplicationGatewayBackendAddress from a JSON string
azure_application_gateway_backend_address_instance = AzureApplicationGatewayBackendAddress.from_json(json)
# print the JSON string representation of the object
print(AzureApplicationGatewayBackendAddress.to_json())

# convert the object into a dict
azure_application_gateway_backend_address_dict = azure_application_gateway_backend_address_instance.to_dict()
# create an instance of AzureApplicationGatewayBackendAddress from a dict
azure_application_gateway_backend_address_from_dict = AzureApplicationGatewayBackendAddress.from_dict(azure_application_gateway_backend_address_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


