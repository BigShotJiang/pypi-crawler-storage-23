# AwsServiceConnectClientAlias


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**dns_name** | **str** |  | [optional] 
**port** | **int** |  | [optional] 
**test_traffic_rules** | [**AwsServiceConnectTestTrafficRules**](AwsServiceConnectTestTrafficRules.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_client_alias import AwsServiceConnectClientAlias

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectClientAlias from a JSON string
aws_service_connect_client_alias_instance = AwsServiceConnectClientAlias.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectClientAlias.to_json())

# convert the object into a dict
aws_service_connect_client_alias_dict = aws_service_connect_client_alias_instance.to_dict()
# create an instance of AwsServiceConnectClientAlias from a dict
aws_service_connect_client_alias_from_dict = AwsServiceConnectClientAlias.from_dict(aws_service_connect_client_alias_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


