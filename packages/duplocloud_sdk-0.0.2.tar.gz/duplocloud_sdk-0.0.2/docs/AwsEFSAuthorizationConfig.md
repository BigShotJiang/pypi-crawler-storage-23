# AwsEFSAuthorizationConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**access_point_id** | **str** |  | [optional] 
**iam** | [**AwsEFSAuthorizationConfigIAM**](AwsEFSAuthorizationConfigIAM.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_efs_authorization_config import AwsEFSAuthorizationConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEFSAuthorizationConfig from a JSON string
aws_efs_authorization_config_instance = AwsEFSAuthorizationConfig.from_json(json)
# print the JSON string representation of the object
print(AwsEFSAuthorizationConfig.to_json())

# convert the object into a dict
aws_efs_authorization_config_dict = aws_efs_authorization_config_instance.to_dict()
# create an instance of AwsEFSAuthorizationConfig from a dict
aws_efs_authorization_config_from_dict = AwsEFSAuthorizationConfig.from_dict(aws_efs_authorization_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


