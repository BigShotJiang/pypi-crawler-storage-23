# AwsPortMapping


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**app_protocol** | [**AwsApplicationProtocol**](AwsApplicationProtocol.md) |  | [optional] 
**container_port** | **int** |  | [optional] 
**container_port_range** | **str** |  | [optional] 
**host_port** | **int** |  | [optional] 
**name** | **str** |  | [optional] 
**protocol** | [**AwsTransportProtocol**](AwsTransportProtocol.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_port_mapping import AwsPortMapping

# TODO update the JSON string below
json = "{}"
# create an instance of AwsPortMapping from a JSON string
aws_port_mapping_instance = AwsPortMapping.from_json(json)
# print the JSON string representation of the object
print(AwsPortMapping.to_json())

# convert the object into a dict
aws_port_mapping_dict = aws_port_mapping_instance.to_dict()
# create an instance of AwsPortMapping from a dict
aws_port_mapping_from_dict = AwsPortMapping.from_dict(aws_port_mapping_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


