# AzureNatRulePortMapping


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inbound_nat_rule_name** | **str** |  | [optional] 
**frontend_port** | **int** |  | [optional] 
**backend_port** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_nat_rule_port_mapping import AzureNatRulePortMapping

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNatRulePortMapping from a JSON string
azure_nat_rule_port_mapping_instance = AzureNatRulePortMapping.from_json(json)
# print the JSON string representation of the object
print(AzureNatRulePortMapping.to_json())

# convert the object into a dict
azure_nat_rule_port_mapping_dict = azure_nat_rule_port_mapping_instance.to_dict()
# create an instance of AzureNatRulePortMapping from a dict
azure_nat_rule_port_mapping_from_dict = AzureNatRulePortMapping.from_dict(azure_nat_rule_port_mapping_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


