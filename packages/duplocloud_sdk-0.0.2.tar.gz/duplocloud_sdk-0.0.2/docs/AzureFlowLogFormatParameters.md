# AzureFlowLogFormatParameters


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** |  | [optional] 
**version** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_flow_log_format_parameters import AzureFlowLogFormatParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFlowLogFormatParameters from a JSON string
azure_flow_log_format_parameters_instance = AzureFlowLogFormatParameters.from_json(json)
# print the JSON string representation of the object
print(AzureFlowLogFormatParameters.to_json())

# convert the object into a dict
azure_flow_log_format_parameters_dict = azure_flow_log_format_parameters_instance.to_dict()
# create an instance of AzureFlowLogFormatParameters from a dict
azure_flow_log_format_parameters_from_dict = AzureFlowLogFormatParameters.from_dict(azure_flow_log_format_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


