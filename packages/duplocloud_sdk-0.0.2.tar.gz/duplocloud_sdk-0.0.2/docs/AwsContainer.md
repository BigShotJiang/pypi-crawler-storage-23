# AwsContainer


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**container_arn** | **str** |  | [optional] 
**cpu** | **str** |  | [optional] 
**exit_code** | **int** |  | [optional] 
**gpu_ids** | **List[str]** |  | [optional] 
**health_status** | [**AwsHealthStatus**](AwsHealthStatus.md) |  | [optional] 
**image** | **str** |  | [optional] 
**image_digest** | **str** |  | [optional] 
**last_status** | **str** |  | [optional] 
**managed_agents** | [**List[AwsManagedAgent]**](AwsManagedAgent.md) |  | [optional] 
**memory** | **str** |  | [optional] 
**memory_reservation** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**network_bindings** | [**List[AwsNetworkBinding]**](AwsNetworkBinding.md) |  | [optional] 
**network_interfaces** | [**List[AwsNetworkInterface]**](AwsNetworkInterface.md) |  | [optional] 
**reason** | **str** |  | [optional] 
**runtime_id** | **str** |  | [optional] 
**task_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_container import AwsContainer

# TODO update the JSON string below
json = "{}"
# create an instance of AwsContainer from a JSON string
aws_container_instance = AwsContainer.from_json(json)
# print the JSON string representation of the object
print(AwsContainer.to_json())

# convert the object into a dict
aws_container_dict = aws_container_instance.to_dict()
# create an instance of AwsContainer from a dict
aws_container_from_dict = AwsContainer.from_dict(aws_container_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


