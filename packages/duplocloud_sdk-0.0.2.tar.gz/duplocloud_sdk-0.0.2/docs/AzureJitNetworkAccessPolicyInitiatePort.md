# AzureJitNetworkAccessPolicyInitiatePort


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**number** | **int** |  | [optional] 
**allowed_source_address_prefix** | **str** | Gets or sets source of the allowed traffic. If omitted, the request will be for the source IP address of the initiate request. | [optional] 
**end_time_utc** | **datetime** | Gets or sets the time to close the request in UTC | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_jit_network_access_policy_initiate_port import AzureJitNetworkAccessPolicyInitiatePort

# TODO update the JSON string below
json = "{}"
# create an instance of AzureJitNetworkAccessPolicyInitiatePort from a JSON string
azure_jit_network_access_policy_initiate_port_instance = AzureJitNetworkAccessPolicyInitiatePort.from_json(json)
# print the JSON string representation of the object
print(AzureJitNetworkAccessPolicyInitiatePort.to_json())

# convert the object into a dict
azure_jit_network_access_policy_initiate_port_dict = azure_jit_network_access_policy_initiate_port_instance.to_dict()
# create an instance of AzureJitNetworkAccessPolicyInitiatePort from a dict
azure_jit_network_access_policy_initiate_port_from_dict = AzureJitNetworkAccessPolicyInitiatePort.from_dict(azure_jit_network_access_policy_initiate_port_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


