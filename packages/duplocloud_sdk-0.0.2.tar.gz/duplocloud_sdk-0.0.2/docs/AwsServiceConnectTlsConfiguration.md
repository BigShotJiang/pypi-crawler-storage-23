# AwsServiceConnectTlsConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**issuer_certificate_authority** | [**AwsServiceConnectTlsCertificateAuthority**](AwsServiceConnectTlsCertificateAuthority.md) |  | [optional] 
**kms_key** | **str** |  | [optional] 
**role_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_tls_configuration import AwsServiceConnectTlsConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectTlsConfiguration from a JSON string
aws_service_connect_tls_configuration_instance = AwsServiceConnectTlsConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectTlsConfiguration.to_json())

# convert the object into a dict
aws_service_connect_tls_configuration_dict = aws_service_connect_tls_configuration_instance.to_dict()
# create an instance of AwsServiceConnectTlsConfiguration from a dict
aws_service_connect_tls_configuration_from_dict = AwsServiceConnectTlsConfiguration.from_dict(aws_service_connect_tls_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


