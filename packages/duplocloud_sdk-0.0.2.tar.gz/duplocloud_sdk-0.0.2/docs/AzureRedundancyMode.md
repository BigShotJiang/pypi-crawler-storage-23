# AzureRedundancyMode



## Enum

* `NONE_` (value: `'None'`)

* `Manual` (value: `'Manual'`)

* `Failover` (value: `'Failover'`)

* `ActiveActive` (value: `'ActiveActive'`)

* `GeoRedundant` (value: `'GeoRedundant'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


