# AzureCachingTypes

Defines values for CachingTypes.

## Enum

* `NONE_` (value: `'None'`)

* `ReadOnly` (value: `'ReadOnly'`)

* `ReadWrite` (value: `'ReadWrite'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


