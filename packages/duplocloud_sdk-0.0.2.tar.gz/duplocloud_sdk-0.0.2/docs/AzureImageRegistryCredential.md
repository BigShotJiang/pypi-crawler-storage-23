# AzureImageRegistryCredential

Image registry credential.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**server** | **str** | Gets or sets the Docker image registry server without a protocol such as \&quot;http\&quot; and \&quot;https\&quot;. | [optional] 
**username** | **str** | Gets or sets the username for the private registry. | [optional] 
**password** | **str** | Gets or sets the password for the private registry. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_image_registry_credential import AzureImageRegistryCredential

# TODO update the JSON string below
json = "{}"
# create an instance of AzureImageRegistryCredential from a JSON string
azure_image_registry_credential_instance = AzureImageRegistryCredential.from_json(json)
# print the JSON string representation of the object
print(AzureImageRegistryCredential.to_json())

# convert the object into a dict
azure_image_registry_credential_dict = azure_image_registry_credential_instance.to_dict()
# create an instance of AzureImageRegistryCredential from a dict
azure_image_registry_credential_from_dict = AzureImageRegistryCredential.from_dict(azure_image_registry_credential_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


