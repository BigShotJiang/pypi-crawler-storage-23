# AdvancedSecurityOptions


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**anonymous_auth_disable_date** | **datetime** |  | [optional] 
**anonymous_auth_enabled** | **bool** |  | [optional] 
**enabled** | **bool** |  | [optional] 
**internal_user_database_enabled** | **bool** |  | [optional] 
**saml_options** | [**SAMLOptionsOutput**](SAMLOptionsOutput.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.advanced_security_options import AdvancedSecurityOptions

# TODO update the JSON string below
json = "{}"
# create an instance of AdvancedSecurityOptions from a JSON string
advanced_security_options_instance = AdvancedSecurityOptions.from_json(json)
# print the JSON string representation of the object
print(AdvancedSecurityOptions.to_json())

# convert the object into a dict
advanced_security_options_dict = advanced_security_options_instance.to_dict()
# create an instance of AdvancedSecurityOptions from a dict
advanced_security_options_from_dict = AdvancedSecurityOptions.from_dict(advanced_security_options_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


