# AzurePrivateEndpointConnection2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**provisioning_state** | **str** |  | [optional] 
**private_endpoint** | [**AzurePrivateEndpoint2**](AzurePrivateEndpoint2.md) |  | [optional] 
**private_link_service_connection_state** | [**AzurePrivateLinkServiceConnectionState2**](AzurePrivateLinkServiceConnectionState2.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_connection2 import AzurePrivateEndpointConnection2

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointConnection2 from a JSON string
azure_private_endpoint_connection2_instance = AzurePrivateEndpointConnection2.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointConnection2.to_json())

# convert the object into a dict
azure_private_endpoint_connection2_dict = azure_private_endpoint_connection2_instance.to_dict()
# create an instance of AzurePrivateEndpointConnection2 from a dict
azure_private_endpoint_connection2_from_dict = AzurePrivateEndpointConnection2.from_dict(azure_private_endpoint_connection2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


