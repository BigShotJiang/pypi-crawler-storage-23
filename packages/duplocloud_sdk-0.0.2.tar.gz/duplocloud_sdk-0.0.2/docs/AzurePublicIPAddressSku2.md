# AzurePublicIPAddressSku2

Describes the public IP Sku. It can only be set with OrchestrationMode as Flexible.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** | Gets or sets specify public IP sku name. Possible values include: &#39;Basic&#39;, &#39;Standard&#39; | [optional] 
**tier** | **str** | Gets or sets specify public IP sku tier. Possible values include: &#39;Regional&#39;, &#39;Global&#39; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_public_ip_address_sku2 import AzurePublicIPAddressSku2

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePublicIPAddressSku2 from a JSON string
azure_public_ip_address_sku2_instance = AzurePublicIPAddressSku2.from_json(json)
# print the JSON string representation of the object
print(AzurePublicIPAddressSku2.to_json())

# convert the object into a dict
azure_public_ip_address_sku2_dict = azure_public_ip_address_sku2_instance.to_dict()
# create an instance of AzurePublicIPAddressSku2 from a dict
azure_public_ip_address_sku2_from_dict = AzurePublicIPAddressSku2.from_dict(azure_public_ip_address_sku2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


