# AWSWorkspace


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**resource_tags** | **Dict[str, str]** |  | [optional] 
**state** | **str** |  | [optional] 
**zone** | [**AvailabilityZone**](AvailabilityZone.md) |  | [optional] 
**instance_type** | **str** |  | [optional] 
**directory_id** | **str** |  | [optional] 
**bundle_id** | **str** |  | [optional] 
**user_name** | **str** |  | [optional] 
**given_name** | **str** |  | [optional] 
**sur_name** | **str** |  | [optional] 
**user_email_address** | **str** |  | [optional] 
**password** | **str** |  | [optional] 
**wrk_space_type** | [**WorkspaceType**](WorkspaceType.md) |  | [optional] 
**ip_address** | **str** |  | [optional] 
**workspace_id** | **str** |  | [optional] 
**registration_code** | **str** |  | [optional] 
**clients_link** | **str** |  | [optional] 
**dns_name** | **str** |  | [optional] 
**tenant_name** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_workspace import AWSWorkspace

# TODO update the JSON string below
json = "{}"
# create an instance of AWSWorkspace from a JSON string
aws_workspace_instance = AWSWorkspace.from_json(json)
# print the JSON string representation of the object
print(AWSWorkspace.to_json())

# convert the object into a dict
aws_workspace_dict = aws_workspace_instance.to_dict()
# create an instance of AWSWorkspace from a dict
aws_workspace_from_dict = AWSWorkspace.from_dict(aws_workspace_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


