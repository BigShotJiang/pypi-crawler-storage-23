# AwsResourceRequirement


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AwsResourceType**](AwsResourceType.md) |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_resource_requirement import AwsResourceRequirement

# TODO update the JSON string below
json = "{}"
# create an instance of AwsResourceRequirement from a JSON string
aws_resource_requirement_instance = AwsResourceRequirement.from_json(json)
# print the JSON string representation of the object
print(AwsResourceRequirement.to_json())

# convert the object into a dict
aws_resource_requirement_dict = aws_resource_requirement_instance.to_dict()
# create an instance of AwsResourceRequirement from a dict
aws_resource_requirement_from_dict = AwsResourceRequirement.from_dict(aws_resource_requirement_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


