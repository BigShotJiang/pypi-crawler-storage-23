# AdminCloudUsageReport


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_reports** | [**List[TenantCloudUsageReport]**](TenantCloudUsageReport.md) |  | [optional] 
**past_week_cost** | **str** |  | [optional] 
**past_month_cost** | **str** |  | [optional] 
**current_month_cost** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.admin_cloud_usage_report import AdminCloudUsageReport

# TODO update the JSON string below
json = "{}"
# create an instance of AdminCloudUsageReport from a JSON string
admin_cloud_usage_report_instance = AdminCloudUsageReport.from_json(json)
# print the JSON string representation of the object
print(AdminCloudUsageReport.to_json())

# convert the object into a dict
admin_cloud_usage_report_dict = admin_cloud_usage_report_instance.to_dict()
# create an instance of AdminCloudUsageReport from a dict
admin_cloud_usage_report_from_dict = AdminCloudUsageReport.from_dict(admin_cloud_usage_report_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


