# AzureExperiments


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ramp_up_rules** | [**List[AzureRampUpRule]**](AzureRampUpRule.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_experiments import AzureExperiments

# TODO update the JSON string below
json = "{}"
# create an instance of AzureExperiments from a JSON string
azure_experiments_instance = AzureExperiments.from_json(json)
# print the JSON string representation of the object
print(AzureExperiments.to_json())

# convert the object into a dict
azure_experiments_dict = azure_experiments_instance.to_dict()
# create an instance of AzureExperiments from a dict
azure_experiments_from_dict = AzureExperiments.from_dict(azure_experiments_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


