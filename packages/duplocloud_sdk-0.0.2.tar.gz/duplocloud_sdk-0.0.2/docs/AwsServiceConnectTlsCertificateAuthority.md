# AwsServiceConnectTlsCertificateAuthority


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**aws_pca_authority_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_tls_certificate_authority import AwsServiceConnectTlsCertificateAuthority

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectTlsCertificateAuthority from a JSON string
aws_service_connect_tls_certificate_authority_instance = AwsServiceConnectTlsCertificateAuthority.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectTlsCertificateAuthority.to_json())

# convert the object into a dict
aws_service_connect_tls_certificate_authority_dict = aws_service_connect_tls_certificate_authority_instance.to_dict()
# create an instance of AwsServiceConnectTlsCertificateAuthority from a dict
aws_service_connect_tls_certificate_authority_from_dict = AwsServiceConnectTlsCertificateAuthority.from_dict(aws_service_connect_tls_certificate_authority_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


