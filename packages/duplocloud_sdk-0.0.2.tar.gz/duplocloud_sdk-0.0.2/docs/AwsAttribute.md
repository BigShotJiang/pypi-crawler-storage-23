# AwsAttribute


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**target_id** | **str** |  | [optional] 
**target_type** | [**AwsTargetType**](AwsTargetType.md) |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_attribute import AwsAttribute

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAttribute from a JSON string
aws_attribute_instance = AwsAttribute.from_json(json)
# print the JSON string representation of the object
print(AwsAttribute.to_json())

# convert the object into a dict
aws_attribute_dict = aws_attribute_instance.to_dict()
# create an instance of AwsAttribute from a dict
aws_attribute_from_dict = AwsAttribute.from_dict(aws_attribute_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


