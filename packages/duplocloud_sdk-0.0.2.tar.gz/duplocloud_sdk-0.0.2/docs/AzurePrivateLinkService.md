# AzurePrivateLinkService


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**extended_location** | [**AzureExtendedLocation**](AzureExtendedLocation.md) |  | [optional] 
**properties_load_balancer_frontend_ip_configurations** | [**List[AzureFrontendIPConfiguration]**](AzureFrontendIPConfiguration.md) |  | [optional] 
**properties_ip_configurations** | [**List[AzurePrivateLinkServiceIpConfiguration]**](AzurePrivateLinkServiceIpConfiguration.md) |  | [optional] 
**properties_network_interfaces** | [**List[AzureNetworkInterface]**](AzureNetworkInterface.md) |  | [optional] 
**properties_provisioning_state** | **str** |  | [optional] 
**properties_private_endpoint_connections** | [**List[AzurePrivateEndpointConnection]**](AzurePrivateEndpointConnection.md) |  | [optional] 
**properties_visibility** | [**AzurePrivateLinkServicePropertiesVisibility**](AzurePrivateLinkServicePropertiesVisibility.md) |  | [optional] 
**properties_auto_approval** | [**AzurePrivateLinkServicePropertiesAutoApproval**](AzurePrivateLinkServicePropertiesAutoApproval.md) |  | [optional] 
**properties_fqdns** | **List[str]** |  | [optional] 
**properties_alias** | **str** |  | [optional] 
**properties_enable_proxy_protocol** | **bool** |  | [optional] 
**etag** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_link_service import AzurePrivateLinkService

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateLinkService from a JSON string
azure_private_link_service_instance = AzurePrivateLinkService.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateLinkService.to_json())

# convert the object into a dict
azure_private_link_service_dict = azure_private_link_service_instance.to_dict()
# create an instance of AzurePrivateLinkService from a dict
azure_private_link_service_from_dict = AzurePrivateLinkService.from_dict(azure_private_link_service_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


