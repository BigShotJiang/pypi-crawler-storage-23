# AzurePrivateEndpointProperty3


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_property3 import AzurePrivateEndpointProperty3

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointProperty3 from a JSON string
azure_private_endpoint_property3_instance = AzurePrivateEndpointProperty3.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointProperty3.to_json())

# convert the object into a dict
azure_private_endpoint_property3_dict = azure_private_endpoint_property3_instance.to_dict()
# create an instance of AzurePrivateEndpointProperty3 from a dict
azure_private_endpoint_property3_from_dict = AzurePrivateEndpointProperty3.from_dict(azure_private_endpoint_property3_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


