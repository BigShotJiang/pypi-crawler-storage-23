# AwsLBConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**tenant_id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**instances** | **List[str]** |  | [optional] 
**external_ip** | **str** |  | [optional] 
**friendly_name** | **str** |  | [optional] 
**be_configurations** | [**List[AwsLBBackendConfiguration]**](AwsLBBackendConfiguration.md) |  | [optional] 
**is_internal** | **bool** |  | [optional] 
**is_target_group_only** | **bool** |  | [optional] 
**state** | **str** |  | [optional] 
**role_name** | **str** |  | [optional] 
**elb_dns_name** | **str** |  | [optional] 
**unrestricted_ext_access** | **bool** |  | [optional] 
**restricted_lb_access** | **bool** |  | [optional] 
**enable_access_logs** | **bool** |  | [optional] 
**instance_ids** | **List[str]** |  | [optional] 
**lb_ignore_configs** | [**Dict[str, LBIgnoreConfig]**](LBIgnoreConfig.md) |  | [optional] 
**oob_instance_management** | **bool** |  | [optional] 
**agent_platform** | [**Platform**](Platform.md) |  | [optional] 
**expected_replicas_in_service** | **int** |  | [optional] 
**is_any_host_allowed** | **bool** |  | [optional] 
**requested_lb_type** | [**LoadBalancerTypeEnum**](LoadBalancerTypeEnum.md) |  | [optional] 
**listeners** | [**List[AwsListener]**](AwsListener.md) |  | [optional] 
**settings** | [**LbSettings**](LbSettings.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_lb_configuration import AwsLBConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLBConfiguration from a JSON string
aws_lb_configuration_instance = AwsLBConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsLBConfiguration.to_json())

# convert the object into a dict
aws_lb_configuration_dict = aws_lb_configuration_instance.to_dict()
# create an instance of AwsLBConfiguration from a dict
aws_lb_configuration_from_dict = AwsLBConfiguration.from_dict(aws_lb_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


