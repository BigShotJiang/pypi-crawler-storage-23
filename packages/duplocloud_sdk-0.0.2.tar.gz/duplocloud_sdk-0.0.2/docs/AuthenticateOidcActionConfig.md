# AuthenticateOidcActionConfig


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authentication_request_extra_params** | **Dict[str, str]** |  | [optional] 
**authorization_endpoint** | **str** |  | [optional] 
**client_id** | **str** |  | [optional] 
**client_secret** | **str** |  | [optional] 
**issuer** | **str** |  | [optional] 
**on_unauthenticated_request** | [**AuthenticateOidcActionConditionalBehaviorEnum**](AuthenticateOidcActionConditionalBehaviorEnum.md) |  | [optional] 
**scope** | **str** |  | [optional] 
**session_cookie_name** | **str** |  | [optional] 
**session_timeout** | **int** |  | [optional] 
**token_endpoint** | **str** |  | [optional] 
**use_existing_client_secret** | **bool** |  | [optional] 
**user_info_endpoint** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.authenticate_oidc_action_config import AuthenticateOidcActionConfig

# TODO update the JSON string below
json = "{}"
# create an instance of AuthenticateOidcActionConfig from a JSON string
authenticate_oidc_action_config_instance = AuthenticateOidcActionConfig.from_json(json)
# print the JSON string representation of the object
print(AuthenticateOidcActionConfig.to_json())

# convert the object into a dict
authenticate_oidc_action_config_dict = authenticate_oidc_action_config_instance.to_dict()
# create an instance of AuthenticateOidcActionConfig from a dict
authenticate_oidc_action_config_from_dict = AuthenticateOidcActionConfig.from_dict(authenticate_oidc_action_config_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


