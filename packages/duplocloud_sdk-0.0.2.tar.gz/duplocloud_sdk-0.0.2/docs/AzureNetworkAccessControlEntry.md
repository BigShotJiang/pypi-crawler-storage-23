# AzureNetworkAccessControlEntry


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**action** | [**AzureAccessControlEntryAction**](AzureAccessControlEntryAction.md) |  | [optional] 
**description** | **str** |  | [optional] 
**order** | **int** |  | [optional] 
**remote_subnet** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_network_access_control_entry import AzureNetworkAccessControlEntry

# TODO update the JSON string below
json = "{}"
# create an instance of AzureNetworkAccessControlEntry from a JSON string
azure_network_access_control_entry_instance = AzureNetworkAccessControlEntry.from_json(json)
# print the JSON string representation of the object
print(AzureNetworkAccessControlEntry.to_json())

# convert the object into a dict
azure_network_access_control_entry_dict = azure_network_access_control_entry_instance.to_dict()
# create an instance of AzureNetworkAccessControlEntry from a dict
azure_network_access_control_entry_from_dict = AzureNetworkAccessControlEntry.from_dict(azure_network_access_control_entry_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


