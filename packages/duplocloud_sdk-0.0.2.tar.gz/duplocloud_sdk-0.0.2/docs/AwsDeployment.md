# AwsDeployment


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capacity_provider_strategy** | [**List[AwsCapacityProviderStrategyItem]**](AwsCapacityProviderStrategyItem.md) |  | [optional] 
**created_at** | **datetime** |  | [optional] 
**desired_count** | **int** |  | [optional] 
**failed_tasks** | **int** |  | [optional] 
**fargate_ephemeral_storage** | [**AwsDeploymentEphemeralStorage**](AwsDeploymentEphemeralStorage.md) |  | [optional] 
**id** | **str** |  | [optional] 
**launch_type** | [**AwsLaunchType**](AwsLaunchType.md) |  | [optional] 
**network_configuration** | [**AwsNetworkConfiguration**](AwsNetworkConfiguration.md) |  | [optional] 
**pending_count** | **int** |  | [optional] 
**platform_family** | **str** |  | [optional] 
**platform_version** | **str** |  | [optional] 
**rollout_state** | [**AwsDeploymentRolloutState**](AwsDeploymentRolloutState.md) |  | [optional] 
**rollout_state_reason** | **str** |  | [optional] 
**running_count** | **int** |  | [optional] 
**service_connect_configuration** | [**AwsServiceConnectConfiguration**](AwsServiceConnectConfiguration.md) |  | [optional] 
**service_connect_resources** | [**List[AwsServiceConnectServiceResource]**](AwsServiceConnectServiceResource.md) |  | [optional] 
**status** | **str** |  | [optional] 
**task_definition** | **str** |  | [optional] 
**updated_at** | **datetime** |  | [optional] 
**volume_configurations** | [**List[AwsServiceVolumeConfiguration]**](AwsServiceVolumeConfiguration.md) |  | [optional] 
**vpc_lattice_configurations** | [**List[AwsVpcLatticeConfiguration]**](AwsVpcLatticeConfiguration.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment import AwsDeployment

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeployment from a JSON string
aws_deployment_instance = AwsDeployment.from_json(json)
# print the JSON string representation of the object
print(AwsDeployment.to_json())

# convert the object into a dict
aws_deployment_dict = aws_deployment_instance.to_dict()
# create an instance of AwsDeployment from a dict
aws_deployment_from_dict = AwsDeployment.from_dict(aws_deployment_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


