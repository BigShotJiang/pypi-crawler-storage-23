# AzureFunctionEnvelope


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**kind** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**properties_function_app_id** | **str** |  | [optional] 
**properties_script_root_path_href** | **str** |  | [optional] 
**properties_script_href** | **str** |  | [optional] 
**properties_config_href** | **str** |  | [optional] 
**properties_test_data_href** | **str** |  | [optional] 
**properties_secrets_file_href** | **str** |  | [optional] 
**properties_href** | **str** |  | [optional] 
**properties_config** | **object** |  | [optional] 
**properties_files** | **Dict[str, str]** |  | [optional] 
**properties_test_data** | **str** |  | [optional] 
**properties_invoke_url_template** | **str** |  | [optional] 
**properties_language** | **str** |  | [optional] 
**properties_is_disabled** | **bool** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_function_envelope import AzureFunctionEnvelope

# TODO update the JSON string below
json = "{}"
# create an instance of AzureFunctionEnvelope from a JSON string
azure_function_envelope_instance = AzureFunctionEnvelope.from_json(json)
# print the JSON string representation of the object
print(AzureFunctionEnvelope.to_json())

# convert the object into a dict
azure_function_envelope_dict = azure_function_envelope_instance.to_dict()
# create an instance of AzureFunctionEnvelope from a dict
azure_function_envelope_from_dict = AzureFunctionEnvelope.from_dict(azure_function_envelope_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


