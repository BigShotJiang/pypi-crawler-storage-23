# AmazonSageMakerRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_sage_maker_request import AmazonSageMakerRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonSageMakerRequest from a JSON string
amazon_sage_maker_request_instance = AmazonSageMakerRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonSageMakerRequest.to_json())

# convert the object into a dict
amazon_sage_maker_request_dict = amazon_sage_maker_request_instance.to_dict()
# create an instance of AmazonSageMakerRequest from a dict
amazon_sage_maker_request_from_dict = AmazonSageMakerRequest.from_dict(amazon_sage_maker_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


