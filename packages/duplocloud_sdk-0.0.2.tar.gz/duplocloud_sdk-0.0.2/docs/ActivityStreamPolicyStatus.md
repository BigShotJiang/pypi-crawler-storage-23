# ActivityStreamPolicyStatus


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.activity_stream_policy_status import ActivityStreamPolicyStatus

# TODO update the JSON string below
json = "{}"
# create an instance of ActivityStreamPolicyStatus from a JSON string
activity_stream_policy_status_instance = ActivityStreamPolicyStatus.from_json(json)
# print the JSON string representation of the object
print(ActivityStreamPolicyStatus.to_json())

# convert the object into a dict
activity_stream_policy_status_dict = activity_stream_policy_status_instance.to_dict()
# create an instance of ActivityStreamPolicyStatus from a dict
activity_stream_policy_status_from_dict = ActivityStreamPolicyStatus.from_dict(activity_stream_policy_status_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


