# AwsFSxWindowsFileServerVolumeConfiguration


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**authorization_config** | [**AwsFSxWindowsFileServerAuthorizationConfig**](AwsFSxWindowsFileServerAuthorizationConfig.md) |  | [optional] 
**file_system_id** | **str** |  | [optional] 
**root_directory** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_fsx_windows_file_server_volume_configuration import AwsFSxWindowsFileServerVolumeConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AwsFSxWindowsFileServerVolumeConfiguration from a JSON string
aws_fsx_windows_file_server_volume_configuration_instance = AwsFSxWindowsFileServerVolumeConfiguration.from_json(json)
# print the JSON string representation of the object
print(AwsFSxWindowsFileServerVolumeConfiguration.to_json())

# convert the object into a dict
aws_fsx_windows_file_server_volume_configuration_dict = aws_fsx_windows_file_server_volume_configuration_instance.to_dict()
# create an instance of AwsFSxWindowsFileServerVolumeConfiguration from a dict
aws_fsx_windows_file_server_volume_configuration_from_dict = AwsFSxWindowsFileServerVolumeConfiguration.from_dict(aws_fsx_windows_file_server_volume_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


