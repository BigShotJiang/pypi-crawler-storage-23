# AzureAzureStorageInfoValue


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AzureAzureStorageType**](AzureAzureStorageType.md) |  | [optional] 
**account_name** | **str** |  | [optional] 
**share_name** | **str** |  | [optional] 
**access_key** | **str** |  | [optional] 
**mount_path** | **str** |  | [optional] 
**state** | [**AzureAzureStorageState**](AzureAzureStorageState.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_azure_storage_info_value import AzureAzureStorageInfoValue

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAzureStorageInfoValue from a JSON string
azure_azure_storage_info_value_instance = AzureAzureStorageInfoValue.from_json(json)
# print the JSON string representation of the object
print(AzureAzureStorageInfoValue.to_json())

# convert the object into a dict
azure_azure_storage_info_value_dict = azure_azure_storage_info_value_instance.to_dict()
# create an instance of AzureAzureStorageInfoValue from a dict
azure_azure_storage_info_value_from_dict = AzureAzureStorageInfoValue.from_dict(azure_azure_storage_info_value_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


