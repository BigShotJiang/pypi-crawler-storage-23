# AwsAccountQuota


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**account_quota_name** | **str** |  | [optional] 
**max** | **int** |  | [optional] 
**used** | **int** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_account_quota import AwsAccountQuota

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAccountQuota from a JSON string
aws_account_quota_instance = AwsAccountQuota.from_json(json)
# print the JSON string representation of the object
print(AwsAccountQuota.to_json())

# convert the object into a dict
aws_account_quota_dict = aws_account_quota_instance.to_dict()
# create an instance of AwsAccountQuota from a dict
aws_account_quota_from_dict = AwsAccountQuota.from_dict(aws_account_quota_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


