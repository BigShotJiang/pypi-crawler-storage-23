# AzureHandlerMapping


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**extension** | **str** |  | [optional] 
**script_processor** | **str** |  | [optional] 
**arguments** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_handler_mapping import AzureHandlerMapping

# TODO update the JSON string below
json = "{}"
# create an instance of AzureHandlerMapping from a JSON string
azure_handler_mapping_instance = AzureHandlerMapping.from_json(json)
# print the JSON string representation of the object
print(AzureHandlerMapping.to_json())

# convert the object into a dict
azure_handler_mapping_dict = azure_handler_mapping_instance.to_dict()
# create an instance of AzureHandlerMapping from a dict
azure_handler_mapping_from_dict = AzureHandlerMapping.from_dict(azure_handler_mapping_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


