# AwsCPUArchitecture


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_cpu_architecture import AwsCPUArchitecture

# TODO update the JSON string below
json = "{}"
# create an instance of AwsCPUArchitecture from a JSON string
aws_cpu_architecture_instance = AwsCPUArchitecture.from_json(json)
# print the JSON string representation of the object
print(AwsCPUArchitecture.to_json())

# convert the object into a dict
aws_cpu_architecture_dict = aws_cpu_architecture_instance.to_dict()
# create an instance of AwsCPUArchitecture from a dict
aws_cpu_architecture_from_dict = AwsCPUArchitecture.from_dict(aws_cpu_architecture_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


