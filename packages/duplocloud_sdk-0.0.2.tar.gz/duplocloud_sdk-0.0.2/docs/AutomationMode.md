# AutomationMode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.automation_mode import AutomationMode

# TODO update the JSON string below
json = "{}"
# create an instance of AutomationMode from a JSON string
automation_mode_instance = AutomationMode.from_json(json)
# print the JSON string representation of the object
print(AutomationMode.to_json())

# convert the object into a dict
automation_mode_dict = automation_mode_instance.to_dict()
# create an instance of AutomationMode from a dict
automation_mode_from_dict = AutomationMode.from_dict(automation_mode_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


