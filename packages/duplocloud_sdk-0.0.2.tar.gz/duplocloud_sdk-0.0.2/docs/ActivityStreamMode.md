# ActivityStreamMode


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.activity_stream_mode import ActivityStreamMode

# TODO update the JSON string below
json = "{}"
# create an instance of ActivityStreamMode from a JSON string
activity_stream_mode_instance = ActivityStreamMode.from_json(json)
# print the JSON string representation of the object
print(ActivityStreamMode.to_json())

# convert the object into a dict
activity_stream_mode_dict = activity_stream_mode_instance.to_dict()
# create an instance of ActivityStreamMode from a dict
activity_stream_mode_from_dict = ActivityStreamMode.from_dict(activity_stream_mode_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


