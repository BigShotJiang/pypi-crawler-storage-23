# AzureAdvancedSchedule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**week_days** | **List[str]** |  | [optional] 
**month_days** | **List[int]** |  | [optional] 
**monthly_occurrences** | [**List[AzureAdvancedScheduleMonthlyOccurrence]**](AzureAdvancedScheduleMonthlyOccurrence.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_advanced_schedule import AzureAdvancedSchedule

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAdvancedSchedule from a JSON string
azure_advanced_schedule_instance = AzureAdvancedSchedule.from_json(json)
# print the JSON string representation of the object
print(AzureAdvancedSchedule.to_json())

# convert the object into a dict
azure_advanced_schedule_dict = azure_advanced_schedule_instance.to_dict()
# create an instance of AzureAdvancedSchedule from a dict
azure_advanced_schedule_from_dict = AzureAdvancedSchedule.from_dict(azure_advanced_schedule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


