# AwsAccessInfo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**console_url** | **str** |  | [optional] 
**access_key_id** | **str** |  | [optional] 
**secret_access_key** | **str** |  | [optional] 
**session_token** | **str** |  | [optional] 
**region** | **str** |  | [optional] 
**validity** | **int** |  | [optional] 
**expiration** | **datetime** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_access_info import AwsAccessInfo

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAccessInfo from a JSON string
aws_access_info_instance = AwsAccessInfo.from_json(json)
# print the JSON string representation of the object
print(AwsAccessInfo.to_json())

# convert the object into a dict
aws_access_info_dict = aws_access_info_instance.to_dict()
# create an instance of AwsAccessInfo from a dict
aws_access_info_from_dict = AwsAccessInfo.from_dict(aws_access_info_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


