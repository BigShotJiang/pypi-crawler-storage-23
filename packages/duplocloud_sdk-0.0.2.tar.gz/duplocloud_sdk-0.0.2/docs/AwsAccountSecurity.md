# AwsAccountSecurity


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**features** | [**AwsAccountSecurityFeatures**](AwsAccountSecurityFeatures.md) |  | [optional] 
**password_policy** | [**PasswordPolicy**](PasswordPolicy.md) |  | [optional] 
**auto_disable_security_hub_controls** | [**List[AwsSecurityHubControlAutoDisable]**](AwsSecurityHubControlAutoDisable.md) |  | [optional] 
**security_hub_controls_initialized_regions** | **List[str]** |  | [optional] 
**settings** | [**List[CustomDataEx]**](CustomDataEx.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_account_security import AwsAccountSecurity

# TODO update the JSON string below
json = "{}"
# create an instance of AwsAccountSecurity from a JSON string
aws_account_security_instance = AwsAccountSecurity.from_json(json)
# print the JSON string representation of the object
print(AwsAccountSecurity.to_json())

# convert the object into a dict
aws_account_security_dict = aws_account_security_instance.to_dict()
# create an instance of AwsAccountSecurity from a dict
aws_account_security_from_dict = AwsAccountSecurity.from_dict(aws_account_security_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


