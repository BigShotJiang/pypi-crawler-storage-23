# ApplyMapping


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**inputs** | **List[str]** |  | [optional] 
**mapping** | [**List[Mapping]**](Mapping.md) |  | [optional] 
**name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.apply_mapping import ApplyMapping

# TODO update the JSON string below
json = "{}"
# create an instance of ApplyMapping from a JSON string
apply_mapping_instance = ApplyMapping.from_json(json)
# print the JSON string representation of the object
print(ApplyMapping.to_json())

# convert the object into a dict
apply_mapping_dict = apply_mapping_instance.to_dict()
# create an instance of ApplyMapping from a dict
apply_mapping_from_dict = ApplyMapping.from_dict(apply_mapping_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


