# AzureOSImageNotificationProfile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**not_before_timeout** | **str** | Gets or sets length of time a Virtual Machine being reimaged or having its OS upgraded will have to potentially approve the OS Image Scheduled Event before the event is auto approved (timed out). The configuration is specified in ISO 8601 format, with the value set to 15 minutes (PT15M) | [optional] 
**enable** | **bool** | Gets or sets specifies whether the OS Image Scheduled event is enabled or disabled. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_os_image_notification_profile import AzureOSImageNotificationProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureOSImageNotificationProfile from a JSON string
azure_os_image_notification_profile_instance = AzureOSImageNotificationProfile.from_json(json)
# print the JSON string representation of the object
print(AzureOSImageNotificationProfile.to_json())

# convert the object into a dict
azure_os_image_notification_profile_dict = azure_os_image_notification_profile_instance.to_dict()
# create an instance of AzureOSImageNotificationProfile from a dict
azure_os_image_notification_profile_from_dict = AzureOSImageNotificationProfile.from_dict(azure_os_image_notification_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


