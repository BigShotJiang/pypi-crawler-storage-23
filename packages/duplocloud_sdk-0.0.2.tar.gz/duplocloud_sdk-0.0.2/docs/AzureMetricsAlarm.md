# AzureMetricsAlarm


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**alarm_name** | **str** |  | [optional] 
**alarm_description** | **str** |  | [optional] 
**metric_name** | **str** |  | [optional] 
**evaluation_periods** | **int** |  | [optional] 
**threshold** | **float** |  | [optional] 
**statistic** | **str** |  | [optional] 
**period** | **int** |  | [optional] 
**comparison_operator** | **str** |  | [optional] 
**tenant_id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**account_name** | **str** |  | [optional] 
**resource_id** | **str** |  | [optional] 
**severity** | [**Severity**](Severity.md) |  | [optional] 
**state** | **str** |  | [optional] 
**cloud** | [**CloudPlatform**](CloudPlatform.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_metrics_alarm import AzureMetricsAlarm

# TODO update the JSON string below
json = "{}"
# create an instance of AzureMetricsAlarm from a JSON string
azure_metrics_alarm_instance = AzureMetricsAlarm.from_json(json)
# print the JSON string representation of the object
print(AzureMetricsAlarm.to_json())

# convert the object into a dict
azure_metrics_alarm_dict = azure_metrics_alarm_instance.to_dict()
# create an instance of AzureMetricsAlarm from a dict
azure_metrics_alarm_from_dict = AzureMetricsAlarm.from_dict(azure_metrics_alarm_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


