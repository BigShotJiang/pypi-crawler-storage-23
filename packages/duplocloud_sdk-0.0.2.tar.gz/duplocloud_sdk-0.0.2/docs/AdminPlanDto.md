# AdminPlanDto


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**nw_provider** | [**NetworkProvider**](NetworkProvider.md) |  | [optional] 
**infra_owner** | **str** |  | [optional] 
**block_byo_hosts** | **bool** |  | [optional] 
**default_application_url** | **str** |  | [optional] 
**images** | [**List[NativeHostImage]**](NativeHostImage.md) |  | [optional] 
**quotas** | [**List[ResourceQuota]**](ResourceQuota.md) |  | [optional] 
**aws_config** | [**PlanAwsConfig**](PlanAwsConfig.md) |  | [optional] 
**unrestricted_ext_lb** | **bool** |  | [optional] 
**capabilities** | [**PlanCapabilities**](PlanCapabilities.md) |  | [optional] 
**cloud_platforms** | [**List[CloudPlatformInfo]**](CloudPlatformInfo.md) |  | [optional] 
**preferred_spot_prices** | [**List[PreferredSpotPrice]**](PreferredSpotPrice.md) |  | [optional] 
**certificates** | [**List[CertificateInfo]**](CertificateInfo.md) |  | [optional] 
**waf_infos** | [**List[WafInfo]**](WafInfo.md) |  | [optional] 
**kms_key_infos** | [**List[KmsKeyInfo]**](KmsKeyInfo.md) |  | [optional] 
**workspace_config** | [**WorkspaceConfig**](WorkspaceConfig.md) |  | [optional] 
**meta_data** | [**List[CustomData]**](CustomData.md) |  | [optional] 
**plan_config_data** | [**List[CustomDataEx]**](CustomDataEx.md) |  | [optional] 
**k8_cluster_configs** | [**List[K8ClusterConfig]**](K8ClusterConfig.md) |  | [optional] 
**dns_config** | [**PlanDnsConfig**](PlanDnsConfig.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.admin_plan_dto import AdminPlanDto

# TODO update the JSON string below
json = "{}"
# create an instance of AdminPlanDto from a JSON string
admin_plan_dto_instance = AdminPlanDto.from_json(json)
# print the JSON string representation of the object
print(AdminPlanDto.to_json())

# convert the object into a dict
admin_plan_dto_dict = admin_plan_dto_instance.to_dict()
# create an instance of AdminPlanDto from a dict
admin_plan_dto_from_dict = AdminPlanDto.from_dict(admin_plan_dto_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


