# AwsEnvironmentFile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | [**AwsEnvironmentFileType**](AwsEnvironmentFileType.md) |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_environment_file import AwsEnvironmentFile

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEnvironmentFile from a JSON string
aws_environment_file_instance = AwsEnvironmentFile.from_json(json)
# print the JSON string representation of the object
print(AwsEnvironmentFile.to_json())

# convert the object into a dict
aws_environment_file_dict = aws_environment_file_instance.to_dict()
# create an instance of AwsEnvironmentFile from a dict
aws_environment_file_from_dict = AwsEnvironmentFile.from_dict(aws_environment_file_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


