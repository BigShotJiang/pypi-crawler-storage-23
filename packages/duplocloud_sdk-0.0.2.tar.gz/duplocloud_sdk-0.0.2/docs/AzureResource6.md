# AzureResource6

Resource

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets fully qualified resource ID for the resource. Ex - /subscriptions/{subscriptionId}/resourceGroups/{resourceGroupName}/providers/{resourceProviderNamespace}/{resourceType}/{resourceName} | [optional] 
**name** | **str** | Gets the name of the resource | [optional] 
**type** | **str** | Gets the type of the resource. E.g. \&quot;Microsoft.Compute/virtualMachines\&quot; or \&quot;Microsoft.Storage/storageAccounts\&quot; | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_resource6 import AzureResource6

# TODO update the JSON string below
json = "{}"
# create an instance of AzureResource6 from a JSON string
azure_resource6_instance = AzureResource6.from_json(json)
# print the JSON string representation of the object
print(AzureResource6.to_json())

# convert the object into a dict
azure_resource6_dict = azure_resource6_instance.to_dict()
# create an instance of AzureResource6 from a dict
azure_resource6_from_dict = AzureResource6.from_dict(azure_resource6_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


