# AwsTargetGroupTuple


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**target_group_arn** | **str** |  | [optional] 
**weight** | **int** |  | [optional] 
**port** | **str** |  | [optional] 
**protocol** | **str** |  | [optional] 
**replication_controller_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_target_group_tuple import AwsTargetGroupTuple

# TODO update the JSON string below
json = "{}"
# create an instance of AwsTargetGroupTuple from a JSON string
aws_target_group_tuple_instance = AwsTargetGroupTuple.from_json(json)
# print the JSON string representation of the object
print(AwsTargetGroupTuple.to_json())

# convert the object into a dict
aws_target_group_tuple_dict = aws_target_group_tuple_instance.to_dict()
# create an instance of AwsTargetGroupTuple from a dict
aws_target_group_tuple_from_dict = AwsTargetGroupTuple.from_dict(aws_target_group_tuple_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


