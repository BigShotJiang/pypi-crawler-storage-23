# AwsServiceConnectTestTrafficRules


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**header** | [**AwsServiceConnectTestTrafficHeaderRules**](AwsServiceConnectTestTrafficHeaderRules.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_service_connect_test_traffic_rules import AwsServiceConnectTestTrafficRules

# TODO update the JSON string below
json = "{}"
# create an instance of AwsServiceConnectTestTrafficRules from a JSON string
aws_service_connect_test_traffic_rules_instance = AwsServiceConnectTestTrafficRules.from_json(json)
# print the JSON string representation of the object
print(AwsServiceConnectTestTrafficRules.to_json())

# convert the object into a dict
aws_service_connect_test_traffic_rules_dict = aws_service_connect_test_traffic_rules_instance.to_dict()
# create an instance of AwsServiceConnectTestTrafficRules from a dict
aws_service_connect_test_traffic_rules_from_dict = AwsServiceConnectTestTrafficRules.from_dict(aws_service_connect_test_traffic_rules_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


