# ArnResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**unique_identifier** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.arn_response import ArnResponse

# TODO update the JSON string below
json = "{}"
# create an instance of ArnResponse from a JSON string
arn_response_instance = ArnResponse.from_json(json)
# print the JSON string representation of the object
print(ArnResponse.to_json())

# convert the object into a dict
arn_response_dict = arn_response_instance.to_dict()
# create an instance of ArnResponse from a dict
arn_response_from_dict = ArnResponse.from_dict(arn_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


