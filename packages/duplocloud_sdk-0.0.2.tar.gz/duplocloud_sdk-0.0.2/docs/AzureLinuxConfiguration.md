# AzureLinuxConfiguration

Specifies the Linux operating system settings on the virtual machine. <br><br>For a list of supported Linux distributions, see [Linux on Azure-Endorsed Distributions](https://docs.microsoft.com/azure/virtual-machines/linux/endorsed-distros).

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**disable_password_authentication** | **bool** | Gets or sets specifies whether password authentication should be disabled. | [optional] 
**ssh** | [**AzureSshConfiguration**](AzureSshConfiguration.md) | Gets or sets specifies the ssh key configuration for a Linux OS. | [optional] 
**provision_vm_agent** | **bool** | Gets or sets indicates whether virtual machine agent should be provisioned on the virtual machine. &amp;lt;br&amp;gt;&amp;lt;br&amp;gt; When this property is not specified in the request body, default behavior is to set it to true.  This will ensure that VM Agent is installed on the VM so that extensions can be added to the VM later. | [optional] 
**patch_settings** | [**AzureLinuxPatchSettings**](AzureLinuxPatchSettings.md) | Gets or sets [Preview Feature] Specifies settings related to VM Guest Patching on Linux. | [optional] 
**enable_vm_agent_platform_updates** | **bool** | Gets or sets indicates whether VMAgent Platform Updates is enabled for the Linux virtual machine. Default value is false. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_linux_configuration import AzureLinuxConfiguration

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLinuxConfiguration from a JSON string
azure_linux_configuration_instance = AzureLinuxConfiguration.from_json(json)
# print the JSON string representation of the object
print(AzureLinuxConfiguration.to_json())

# convert the object into a dict
azure_linux_configuration_dict = azure_linux_configuration_instance.to_dict()
# create an instance of AzureLinuxConfiguration from a dict
azure_linux_configuration_from_dict = AzureLinuxConfiguration.from_dict(azure_linux_configuration_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


