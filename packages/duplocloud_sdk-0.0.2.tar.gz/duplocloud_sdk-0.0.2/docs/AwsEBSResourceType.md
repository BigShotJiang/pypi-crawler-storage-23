# AwsEBSResourceType


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_ebs_resource_type import AwsEBSResourceType

# TODO update the JSON string below
json = "{}"
# create an instance of AwsEBSResourceType from a JSON string
aws_ebs_resource_type_instance = AwsEBSResourceType.from_json(json)
# print the JSON string representation of the object
print(AwsEBSResourceType.to_json())

# convert the object into a dict
aws_ebs_resource_type_dict = aws_ebs_resource_type_instance.to_dict()
# create an instance of AwsEBSResourceType from a dict
aws_ebs_resource_type_from_dict = AwsEBSResourceType.from_dict(aws_ebs_resource_type_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


