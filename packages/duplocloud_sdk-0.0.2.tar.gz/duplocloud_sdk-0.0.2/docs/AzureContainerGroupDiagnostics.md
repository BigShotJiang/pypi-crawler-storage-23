# AzureContainerGroupDiagnostics

Container group diagnostic information.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**log_analytics** | [**AzureLogAnalytics**](AzureLogAnalytics.md) | Gets or sets container group log analytics information. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_container_group_diagnostics import AzureContainerGroupDiagnostics

# TODO update the JSON string below
json = "{}"
# create an instance of AzureContainerGroupDiagnostics from a JSON string
azure_container_group_diagnostics_instance = AzureContainerGroupDiagnostics.from_json(json)
# print the JSON string representation of the object
print(AzureContainerGroupDiagnostics.to_json())

# convert the object into a dict
azure_container_group_diagnostics_dict = azure_container_group_diagnostics_instance.to_dict()
# create an instance of AzureContainerGroupDiagnostics from a dict
azure_container_group_diagnostics_from_dict = AzureContainerGroupDiagnostics.from_dict(azure_container_group_diagnostics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


