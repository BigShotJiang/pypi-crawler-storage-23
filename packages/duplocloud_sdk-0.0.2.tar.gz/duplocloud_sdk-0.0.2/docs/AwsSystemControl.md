# AwsSystemControl


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**namespace** | **str** |  | [optional] 
**value** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_system_control import AwsSystemControl

# TODO update the JSON string below
json = "{}"
# create an instance of AwsSystemControl from a JSON string
aws_system_control_instance = AwsSystemControl.from_json(json)
# print the JSON string representation of the object
print(AwsSystemControl.to_json())

# convert the object into a dict
aws_system_control_dict = aws_system_control_instance.to_dict()
# create an instance of AwsSystemControl from a dict
aws_system_control_from_dict = AwsSystemControl.from_dict(aws_system_control_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


