# AzureElasticPoolEditionCapability


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**supported_elastic_pool_performance_levels** | [**List[AzureElasticPoolPerformanceLevelCapability]**](AzureElasticPoolPerformanceLevelCapability.md) |  | [optional] 
**zone_redundant** | **bool** |  | [optional] 
**status** | [**AzureCapabilityStatus**](AzureCapabilityStatus.md) |  | [optional] 
**reason** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_elastic_pool_edition_capability import AzureElasticPoolEditionCapability

# TODO update the JSON string below
json = "{}"
# create an instance of AzureElasticPoolEditionCapability from a JSON string
azure_elastic_pool_edition_capability_instance = AzureElasticPoolEditionCapability.from_json(json)
# print the JSON string representation of the object
print(AzureElasticPoolEditionCapability.to_json())

# convert the object into a dict
azure_elastic_pool_edition_capability_dict = azure_elastic_pool_edition_capability_instance.to_dict()
# create an instance of AzureElasticPoolEditionCapability from a dict
azure_elastic_pool_edition_capability_from_dict = AzureElasticPoolEditionCapability.from_dict(azure_elastic_pool_edition_capability_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


