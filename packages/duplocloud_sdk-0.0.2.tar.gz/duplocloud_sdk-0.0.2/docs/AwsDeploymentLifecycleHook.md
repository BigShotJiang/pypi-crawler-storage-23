# AwsDeploymentLifecycleHook


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**hook_details** | **List[object]** |  | [optional] 
**hook_target_arn** | **str** |  | [optional] 
**lifecycle_stages** | **List[str]** |  | [optional] 
**role_arn** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_deployment_lifecycle_hook import AwsDeploymentLifecycleHook

# TODO update the JSON string below
json = "{}"
# create an instance of AwsDeploymentLifecycleHook from a JSON string
aws_deployment_lifecycle_hook_instance = AwsDeploymentLifecycleHook.from_json(json)
# print the JSON string representation of the object
print(AwsDeploymentLifecycleHook.to_json())

# convert the object into a dict
aws_deployment_lifecycle_hook_dict = aws_deployment_lifecycle_hook_instance.to_dict()
# create an instance of AwsDeploymentLifecycleHook from a dict
aws_deployment_lifecycle_hook_from_dict = AwsDeploymentLifecycleHook.from_dict(aws_deployment_lifecycle_hook_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


