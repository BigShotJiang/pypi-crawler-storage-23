# AzurePrivateEndpointProperty2


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** | Gets or sets resource id of the private endpoint. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_private_endpoint_property2 import AzurePrivateEndpointProperty2

# TODO update the JSON string below
json = "{}"
# create an instance of AzurePrivateEndpointProperty2 from a JSON string
azure_private_endpoint_property2_instance = AzurePrivateEndpointProperty2.from_json(json)
# print the JSON string representation of the object
print(AzurePrivateEndpointProperty2.to_json())

# convert the object into a dict
azure_private_endpoint_property2_dict = azure_private_endpoint_property2_instance.to_dict()
# create an instance of AzurePrivateEndpointProperty2 from a dict
azure_private_endpoint_property2_from_dict = AzurePrivateEndpointProperty2.from_dict(azure_private_endpoint_property2_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


