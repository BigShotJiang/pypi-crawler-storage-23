# AwsHostVolumeProperties


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**source_path** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_host_volume_properties import AwsHostVolumeProperties

# TODO update the JSON string below
json = "{}"
# create an instance of AwsHostVolumeProperties from a JSON string
aws_host_volume_properties_instance = AwsHostVolumeProperties.from_json(json)
# print the JSON string representation of the object
print(AwsHostVolumeProperties.to_json())

# convert the object into a dict
aws_host_volume_properties_dict = aws_host_volume_properties_instance.to_dict()
# create an instance of AwsHostVolumeProperties from a dict
aws_host_volume_properties_from_dict = AwsHostVolumeProperties.from_dict(aws_host_volume_properties_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


