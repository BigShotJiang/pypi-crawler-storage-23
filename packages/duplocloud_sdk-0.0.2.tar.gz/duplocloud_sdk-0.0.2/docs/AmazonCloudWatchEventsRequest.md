# AmazonCloudWatchEventsRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from duplocloud_sdk.models.amazon_cloud_watch_events_request import AmazonCloudWatchEventsRequest

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonCloudWatchEventsRequest from a JSON string
amazon_cloud_watch_events_request_instance = AmazonCloudWatchEventsRequest.from_json(json)
# print the JSON string representation of the object
print(AmazonCloudWatchEventsRequest.to_json())

# convert the object into a dict
amazon_cloud_watch_events_request_dict = amazon_cloud_watch_events_request_instance.to_dict()
# create an instance of AmazonCloudWatchEventsRequest from a dict
amazon_cloud_watch_events_request_from_dict = AmazonCloudWatchEventsRequest.from_dict(amazon_cloud_watch_events_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


