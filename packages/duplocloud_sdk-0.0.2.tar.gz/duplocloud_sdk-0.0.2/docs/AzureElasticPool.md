# AzureElasticPool


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 
**location** | **str** |  | [optional] 
**tags** | **Dict[str, str]** |  | [optional] 
**sku** | [**AzureSku3**](AzureSku3.md) |  | [optional] 
**kind** | **str** |  | [optional] 
**properties_state** | **str** |  | [optional] 
**properties_creation_date** | **datetime** |  | [optional] 
**properties_max_size_bytes** | **int** |  | [optional] 
**properties_per_database_settings** | [**AzureElasticPoolPerDatabaseSettings**](AzureElasticPoolPerDatabaseSettings.md) |  | [optional] 
**properties_zone_redundant** | **bool** |  | [optional] 
**properties_license_type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_elastic_pool import AzureElasticPool

# TODO update the JSON string below
json = "{}"
# create an instance of AzureElasticPool from a JSON string
azure_elastic_pool_instance = AzureElasticPool.from_json(json)
# print the JSON string representation of the object
print(AzureElasticPool.to_json())

# convert the object into a dict
azure_elastic_pool_dict = azure_elastic_pool_instance.to_dict()
# create an instance of AzureElasticPool from a dict
azure_elastic_pool_from_dict = AzureElasticPool.from_dict(azure_elastic_pool_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


