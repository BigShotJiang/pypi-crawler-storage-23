# AzureAutoHealRules


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**triggers** | [**AzureAutoHealTriggers**](AzureAutoHealTriggers.md) |  | [optional] 
**actions** | [**AzureAutoHealActions**](AzureAutoHealActions.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_auto_heal_rules import AzureAutoHealRules

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAutoHealRules from a JSON string
azure_auto_heal_rules_instance = AzureAutoHealRules.from_json(json)
# print the JSON string representation of the object
print(AzureAutoHealRules.to_json())

# convert the object into a dict
azure_auto_heal_rules_dict = azure_auto_heal_rules_instance.to_dict()
# create an instance of AzureAutoHealRules from a dict
azure_auto_heal_rules_from_dict = AzureAutoHealRules.from_dict(azure_auto_heal_rules_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


