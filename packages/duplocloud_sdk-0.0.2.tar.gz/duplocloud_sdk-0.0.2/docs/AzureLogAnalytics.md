# AzureLogAnalytics

Container group log analytics information.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**workspace_id** | **str** | Gets or sets the workspace id for log analytics | [optional] 
**workspace_key** | **str** | Gets or sets the workspace key for log analytics | [optional] 
**log_type** | **str** | Gets or sets the log type to be used. Possible values include: &#39;ContainerInsights&#39;, &#39;ContainerInstanceLogs&#39; | [optional] 
**metadata** | **Dict[str, str]** | Gets or sets metadata for log analytics. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_log_analytics import AzureLogAnalytics

# TODO update the JSON string below
json = "{}"
# create an instance of AzureLogAnalytics from a JSON string
azure_log_analytics_instance = AzureLogAnalytics.from_json(json)
# print the JSON string representation of the object
print(AzureLogAnalytics.to_json())

# convert the object into a dict
azure_log_analytics_dict = azure_log_analytics_instance.to_dict()
# create an instance of AzureLogAnalytics from a dict
azure_log_analytics_from_dict = AzureLogAnalytics.from_dict(azure_log_analytics_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


