# AmazonWebServiceResponse


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**response_metadata** | [**ResponseMetadata**](ResponseMetadata.md) |  | [optional] 
**content_length** | **int** |  | [optional] 
**http_status_code** | [**HttpStatusCode**](HttpStatusCode.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.amazon_web_service_response import AmazonWebServiceResponse

# TODO update the JSON string below
json = "{}"
# create an instance of AmazonWebServiceResponse from a JSON string
amazon_web_service_response_instance = AmazonWebServiceResponse.from_json(json)
# print the JSON string representation of the object
print(AmazonWebServiceResponse.to_json())

# convert the object into a dict
amazon_web_service_response_dict = amazon_web_service_response_instance.to_dict()
# create an instance of AmazonWebServiceResponse from a dict
amazon_web_service_response_from_dict = AmazonWebServiceResponse.from_dict(amazon_web_service_response_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


