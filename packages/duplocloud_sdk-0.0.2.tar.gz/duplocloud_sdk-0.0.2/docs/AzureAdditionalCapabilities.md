# AzureAdditionalCapabilities

Enables or disables a capability on the virtual machine or virtual machine scale set.

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ultra_ssd_enabled** | **bool** | Gets or sets the flag that enables or disables a capability to have one or more managed data disks with UltraSSD_LRS storage account type on the VM or VMSS. Managed disks with storage account type UltraSSD_LRS can be added to a virtual machine or virtual machine scale set only if this property is enabled. | [optional] 
**hibernation_enabled** | **bool** | Gets or sets the flag that enables or disables hibernation capability on the VM. | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_additional_capabilities import AzureAdditionalCapabilities

# TODO update the JSON string below
json = "{}"
# create an instance of AzureAdditionalCapabilities from a JSON string
azure_additional_capabilities_instance = AzureAdditionalCapabilities.from_json(json)
# print the JSON string representation of the object
print(AzureAdditionalCapabilities.to_json())

# convert the object into a dict
azure_additional_capabilities_dict = azure_additional_capabilities_instance.to_dict()
# create an instance of AzureAdditionalCapabilities from a dict
azure_additional_capabilities_from_dict = AzureAdditionalCapabilities.from_dict(azure_additional_capabilities_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


