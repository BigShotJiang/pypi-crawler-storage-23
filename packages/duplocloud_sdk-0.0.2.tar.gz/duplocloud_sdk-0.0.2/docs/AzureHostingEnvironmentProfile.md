# AzureHostingEnvironmentProfile


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **str** |  | [optional] 
**name** | **str** |  | [optional] 
**type** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_hosting_environment_profile import AzureHostingEnvironmentProfile

# TODO update the JSON string below
json = "{}"
# create an instance of AzureHostingEnvironmentProfile from a JSON string
azure_hosting_environment_profile_instance = AzureHostingEnvironmentProfile.from_json(json)
# print the JSON string representation of the object
print(AzureHostingEnvironmentProfile.to_json())

# convert the object into a dict
azure_hosting_environment_profile_dict = azure_hosting_environment_profile_instance.to_dict()
# create an instance of AzureHostingEnvironmentProfile from a dict
azure_hosting_environment_profile_from_dict = AzureHostingEnvironmentProfile.from_dict(azure_hosting_environment_profile_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


