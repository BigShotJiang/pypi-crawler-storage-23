# AzureCloningInfo


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**correlation_id** | **str** |  | [optional] 
**overwrite** | **bool** |  | [optional] 
**clone_custom_host_names** | **bool** |  | [optional] 
**clone_source_control** | **bool** |  | [optional] 
**source_web_app_id** | **str** |  | [optional] 
**source_web_app_location** | **str** |  | [optional] 
**hosting_environment** | **str** |  | [optional] 
**app_settings_overrides** | **Dict[str, str]** |  | [optional] 
**configure_load_balancing** | **bool** |  | [optional] 
**traffic_manager_profile_id** | **str** |  | [optional] 
**traffic_manager_profile_name** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_cloning_info import AzureCloningInfo

# TODO update the JSON string below
json = "{}"
# create an instance of AzureCloningInfo from a JSON string
azure_cloning_info_instance = AzureCloningInfo.from_json(json)
# print the JSON string representation of the object
print(AzureCloningInfo.to_json())

# convert the object into a dict
azure_cloning_info_dict = azure_cloning_info_instance.to_dict()
# create an instance of AzureCloningInfo from a dict
azure_cloning_info_from_dict = AzureCloningInfo.from_dict(azure_cloning_info_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


