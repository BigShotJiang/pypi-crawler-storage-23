# AwsLinuxParameters


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**capabilities** | [**AwsKernelCapabilities**](AwsKernelCapabilities.md) |  | [optional] 
**devices** | [**List[AwsDevice]**](AwsDevice.md) |  | [optional] 
**init_process_enabled** | **bool** |  | [optional] 
**max_swap** | **int** |  | [optional] 
**shared_memory_size** | **int** |  | [optional] 
**swappiness** | **int** |  | [optional] 
**tmpfs** | [**List[AwsTmpfs]**](AwsTmpfs.md) |  | [optional] 

## Example

```python
from duplocloud_sdk.models.aws_linux_parameters import AwsLinuxParameters

# TODO update the JSON string below
json = "{}"
# create an instance of AwsLinuxParameters from a JSON string
aws_linux_parameters_instance = AwsLinuxParameters.from_json(json)
# print the JSON string representation of the object
print(AwsLinuxParameters.to_json())

# convert the object into a dict
aws_linux_parameters_dict = aws_linux_parameters_instance.to_dict()
# create an instance of AwsLinuxParameters from a dict
aws_linux_parameters_from_dict = AwsLinuxParameters.from_dict(aws_linux_parameters_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


