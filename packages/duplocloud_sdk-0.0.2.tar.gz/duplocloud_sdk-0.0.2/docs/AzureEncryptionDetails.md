# AzureEncryptionDetails


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**encryption_enabled** | **bool** |  | [optional] 
**kek_url** | **str** |  | [optional] 
**secret_key_url** | **str** |  | [optional] 
**kek_vault_id** | **str** |  | [optional] 
**secret_key_vault_id** | **str** |  | [optional] 

## Example

```python
from duplocloud_sdk.models.azure_encryption_details import AzureEncryptionDetails

# TODO update the JSON string below
json = "{}"
# create an instance of AzureEncryptionDetails from a JSON string
azure_encryption_details_instance = AzureEncryptionDetails.from_json(json)
# print the JSON string representation of the object
print(AzureEncryptionDetails.to_json())

# convert the object into a dict
azure_encryption_details_dict = azure_encryption_details_instance.to_dict()
# create an instance of AzureEncryptionDetails from a dict
azure_encryption_details_from_dict = AzureEncryptionDetails.from_dict(azure_encryption_details_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


