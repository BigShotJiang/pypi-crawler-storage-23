# AzureMaintenanceOperationResultCodeTypes

Defines values for MaintenanceOperationResultCodeTypes.

## Enum

* `NONE_` (value: `'None'`)

* `RetryLater` (value: `'RetryLater'`)

* `MaintenanceAborted` (value: `'MaintenanceAborted'`)

* `MaintenanceCompleted` (value: `'MaintenanceCompleted'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


