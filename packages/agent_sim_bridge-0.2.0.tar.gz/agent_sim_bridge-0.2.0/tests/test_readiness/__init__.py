"""Tests for the readiness subpackage."""
