# SCPN Fusion Core
__version__ = "3.9.1"

from scpn_fusion.io.logging_config import setup_fusion_logging

__all__ = ["setup_fusion_logging", "__version__"]
