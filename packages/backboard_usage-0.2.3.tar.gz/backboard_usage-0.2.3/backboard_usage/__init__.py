"""
Backboard Usage — live token and cost visibility for Backboard apps.

  pip install backboard-usage
  backboard-usage-server   # start server, open http://localhost:8766

  In your Backboard app:
    from backboard_usage import UsageTracker
    tracker = UsageTracker()
    response = await client.add_message(...)
    await tracker.record(response, agent="Idea Analyzer")
    await tracker.finish()

  Or use context manager:
    async with UsageTracker() as tracker:
        await tracker.record(response, agent="Agent Name")

  Or for sync (Streamlit etc):
    from backboard_usage import run_with_tracker
    result = run_with_tracker(my_async_flow)(prompt)
"""

__version__ = "0.2.3"
from backboard_usage.tracker import UsageTracker, run_with_tracker

__all__ = ["UsageTracker", "run_with_tracker", "__version__"]
