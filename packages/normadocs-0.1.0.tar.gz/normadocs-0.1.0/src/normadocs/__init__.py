"""
APA Engine - automated Markdown to APA 7th Edition DOCX converter.
"""

__version__ = "0.1.0"
