**Título del Proyecto ERS**

Nombre del Autor

Nombre del Programa

Número de Ficha

Nombre de la Institución

Nombre del Centro

Fecha

# Contenido

Resumen ..................................................... 3

Objetivos ................................................... 4

# Resumen

Este es un resumen de ejemplo. El documento debe seguir esta estructura para que el script de conversión funcione correctamente.
Los metadatos del inicio (primeras 14 líneas) son capturados para crear la portada.

*Palabras clave:* ejemplo, plantilla, ers

# Objetivos

## Objetivo General

Describir el objetivo general del sistema.

## Objetivos Específicos

1.  Objetivo específico 1.
2.  Objetivo específico 2.

# Descripción General del Sistema

## Propósito

El propósito del sistema es...

## Alcance

El alcance del proyecto abarca...

# Stakeholders o Interesados

| ID    | Interesado | Rol      | Poder | Interés | Estrategia           |
| ----- | ---------- | -------- | ----- | ------- | -------------------- |
| SH-01 | Gerente    | Dueño    | Alto  | Alto    | Gestionar Atentamente|

# Requisitos Funcionales

| **ID**                            | RF-001                            |
| --------------------------------- | --------------------------------- |
| **Nombre**                        | Nombre del Requisito              |
| **Descripción**                   | Descripción detallada...          |
| **Criterios de Aceptación**       | 1. Criterio uno.                  |
| **Prioridad**                     | Must (Debe tener)                 |

# Requisitos No Funcionales

| **ID**                            | RNF-001                           |
| --------------------------------- | --------------------------------- |
| **Atributo de Calidad**           | Usabilidad                        |
| **Descripción**                   | Descripción...                    |

# Referencias

Autor, A. A. (Fecha). Título de la fuente. Editorial.
