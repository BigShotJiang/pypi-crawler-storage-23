#!/usr/bin/python
# coding: utf-8
from tunnel_manager.mcp import tunnel_manager_mcp

if __name__ == "__main__":
    tunnel_manager_mcp()
