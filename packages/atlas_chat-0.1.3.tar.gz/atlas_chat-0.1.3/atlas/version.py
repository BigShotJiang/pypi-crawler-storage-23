"""Application version constant.

Single source of truth for the application version number.
"""

VERSION = "0.1.2"
