"""Chat application service."""

from .service import ChatService

__all__ = [
    "ChatService",
]
