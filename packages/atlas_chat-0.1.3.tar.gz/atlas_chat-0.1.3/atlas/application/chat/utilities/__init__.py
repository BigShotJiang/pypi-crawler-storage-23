"""
Chat utilities module - pure functions for chat operations.

This module provides stateless utility functions that can be used
by the ChatService to handle various operations without tight coupling.
"""
