"""Event modules for chat application."""
