"""Domain models for chat operations."""
