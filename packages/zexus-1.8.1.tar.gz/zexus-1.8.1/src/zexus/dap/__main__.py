"""Allow running the DAP server via ``python -m zexus.dap``."""
from .dap_server import main

main()
