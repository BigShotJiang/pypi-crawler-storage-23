"""Project `src` package.

This file exists to support tests/imports that use the form
`src.zexus...` while preserving the standard `zexus...` import style.

The actual application code lives under `src/zexus/`.
"""
