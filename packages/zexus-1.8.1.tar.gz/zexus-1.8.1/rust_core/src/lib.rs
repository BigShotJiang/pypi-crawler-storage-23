// ─────────────────────────────────────────────────────────────────────
// Zexus Blockchain — Rust Execution Core
// ─────────────────────────────────────────────────────────────────────
//
// High-performance native execution engine exposed to Python via PyO3.
//
// Hot paths moved to Rust:
//   • Batch transaction execution (parallel via Rayon)
//   • SHA-256 / Keccak-256 hashing
//   • ECDSA-secp256k1 signature verification
//   • Merkle root computation
//   • Block header validation
//
// The Python `ExecutionAccelerator` detects this extension at import
// time and delegates to it automatically.  When the extension is not
// compiled the system falls back to the pure-Python implementation
// with zero breakage.

use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use std::collections::HashMap;

mod binary_bytecode;
mod contract_vm;
mod executor;
mod hasher;
mod merkle;
mod rust_vm;
mod signature;
mod state_adapter;
mod validator;

use binary_bytecode::RustBytecodeReader;
use contract_vm::RustContractVM;
use executor::{RustBatchExecutor, TxBatchResult as RustTxBatchResult};
use rust_vm::RustVMExecutor;
use hasher::RustHasher;
use merkle::RustMerkle;
use signature::RustSignature;
use state_adapter::RustStateAdapter;
use validator::RustBlockValidator;

// ── Python module definition ──────────────────────────────────────────

/// The native Zexus execution core.
#[pymodule]
fn zexus_core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<RustBatchExecutor>()?;
    m.add_class::<RustTxBatchResult>()?;
    m.add_class::<RustHasher>()?;
    m.add_class::<RustMerkle>()?;
    m.add_class::<RustSignature>()?;
    m.add_class::<RustBlockValidator>()?;
    m.add_class::<RustBytecodeReader>()?;
    m.add_class::<RustVMExecutor>()?;
    m.add_class::<RustStateAdapter>()?;
    m.add_class::<RustContractVM>()?;

    // Convenience — quick check from Python:  `zexus_core.is_available()`
    #[pyfn(m)]
    fn is_available() -> bool {
        true
    }

    #[pyfn(m)]
    fn version() -> &'static str {
        env!("CARGO_PKG_VERSION")
    }

    Ok(())
}
