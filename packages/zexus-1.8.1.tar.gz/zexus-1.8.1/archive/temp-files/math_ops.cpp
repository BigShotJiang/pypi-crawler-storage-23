// High-performance math operations
#include <iostream>
#include <cmath>

double fibonacci(int n) {
    if (n <= 1) return n;
    double phi = (1 + sqrt(5)) / 2;
    return round(pow(phi, n) / sqrt(5));
}

int main() {
    return 0;
}
// High-performance math operations
#include <iostream>
#include <cmath>

double fibonacci(int n) {
    if (n <= 1) return n;
    double phi = (1 + sqrt(5)) / 2;
    return round(pow(phi, n) / sqrt(5));
}

int main() {
    return 0;
}
