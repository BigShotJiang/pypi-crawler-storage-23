"""FX rates test fixtures."""

from tests.fixtures.fx_rates.fx_rates import create_fx_rates, save_fx_rates

__all__ = ["create_fx_rates", "save_fx_rates"]
