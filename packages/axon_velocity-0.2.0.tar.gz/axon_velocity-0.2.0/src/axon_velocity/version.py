from importlib.metadata import version as _get_version

version = _get_version("axon_velocity")

