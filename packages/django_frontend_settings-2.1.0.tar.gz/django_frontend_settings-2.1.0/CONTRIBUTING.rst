Contributing
============

Env Setup
---------

.. highlight:: sh
   # create virtualenv and install dependencies
   make venv

   # run local tests
   make test

   # lint code
   make lint
