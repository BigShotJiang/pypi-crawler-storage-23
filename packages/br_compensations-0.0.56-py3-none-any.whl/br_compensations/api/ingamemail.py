from rest_framework import viewsets
from ..models import CharMailParse
from rest_framework.response import Response
from ..permissions import HasCompensationsPluginAccess
from allianceauth.services.hooks import get_extension_logger
from .serializers import CharMailParseSerializer

logger = get_extension_logger(__name__)

class MailParseViewSet(viewsets.ModelViewSet):
    queryset = CharMailParse.objects.all()
    serializer_class = CharMailParseSerializer
    permission_classes = [HasCompensationsPluginAccess]
    
    def get_queryset(self):
        """Оптимизация запросов"""
        return super().get_queryset()
    
    def destroy(self,request,pk=None, *args, **kwargs):
        if(pk):
            parser = CharMailParse.objects.get(character_id = pk)
            parser.delete()
            
            return Response(status=200)
        return Response(status=404)