import datetime
from typing import Dict, List, Optional, Set
from ..models import FilterEntity
from allianceauth.services.hooks import get_extension_logger
import requests
import json


logger = get_extension_logger(__name__)

class BrEvetools:
    
    RECENT_BR_API_URL = 'https://br.evetools.org/api/v1/recent-br'
    
    @classmethod
    def _get_latest_br(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        try:
            print(f"\n🔄 Запрашиваю данные...")
            response = requests.get(self.RECENT_BR_API_URL, headers=headers, timeout=15)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout:
            print(f"❌ Таймаут запроса для {self.RECENT_BR_API_URL}")
            return None
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP ошибка для {self.RECENT_BR_API_URL}: {e}")
            return None
        except requests.exceptions.RequestException as e:
            print(f"❌ Ошибка запроса для {self.RECENT_BR_API_URL}: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Ошибка парсинга JSON для {self.RECENT_BR_API_URL}: {e}")
            return None
        except Exception as e:
            print(f"❌ Неожиданная ошибка для {self.RECENT_BR_API_URL}: {e}")
            return None
    
    @classmethod
    def get_latest_brs_links(self,last_loaded_date:datetime = None) -> Set[str]:
        '''
            Возвращает ссылки на последние репорты, содержащие альянсы из списка филтрации
            Args:
            last_loaded_date: Дата последней проверки репортов. Если параметр пуст, будет обрабатывать все репорты
        
            Returns:
                Set[str]: Ссылки на репорты, которые соответстуют фильтрам
            
        '''
        try:
            result = set()
            
            filter_sets = self._prepare_filter_sets(FilterEntity.objects.all())
            
            #Не обрабатываем БРы если нет фильтров. Иначе будет загружено очень много данных.
            if filter_sets is None:
                logger.info('Не найдено ни одного фильтра. Обработка БРов не возможна!')
                return
            
            json_data = self._get_latest_br()
            
            if json_data is None:
                raise Exception(f'br.evetools.org вернул пустой ответ по адресу {self.RECENT_BR_API_URL}')
            
            reports_to_add = self._filter_reports(json_data,filter_sets,last_loaded_date)
            for id in reports_to_add:
                result.add(f'https://br.evetools.org/br/{id}')
            
            return result
        except Exception as e:
            raise e
        
    
    @classmethod 
    def _filter_reports(self, response_json, filter_set: Set[int], last_loaded_date:datetime = None) -> Set[str]:
        report_ids = set()
        if isinstance(response_json, dict):
            data = response_json
        elif isinstance(response_json,List):
            data = response_json
        else:
            data = json.loads(response_json)
            
        for report in data:
            #Если указана дата последней загрузки, пропускаем все репорты, созданные до этой даты
            if last_loaded_date is not None:
                if datetime.datetime.fromisoformat(report['createdAt']) <= last_loaded_date:
                    continue
            if 'allys' in report:
                for ally in self._get_allys_from_list(report['allys']):
                    if not self._matches_filter(ally, filter_set):
                        continue
                    if not report['_id'] in report_ids:
                        report_ids.add(report['_id'])
                    else:
                        continue
        return report_ids
    
    @classmethod
    def _get_allys_from_list(cls, allys: List[Dict[str,int]]) -> Set[int]:
        result = set()
        for ally in allys:
            if ':' in ally[0]:
                result.add(int(ally[0].split(':')[-1]))
            else:
                result.add(int(ally[0]))
        
        return result
    
    @classmethod
    def _matches_filter(cls, ally: int, filter_sets: Dict[str, Set[int]]) -> bool:
        """
        Проверяет, входит ли альянс в список фильтров
        
        Args:
            ally: Идентификатор альянса
            filter_sets: Словарь с множествами ID для фильтрации
        
        Returns:
            bool: True если альянс соответствует хотя бы одному фильтру
        """
        return (
            ally in filter_sets
        )
    
    @classmethod
    def _prepare_filter_sets(cls, filter_entities) -> Optional[Set[int]]:
        """
        Подготавливает множества ID для быстрого поиска по фильтрам
        
        Args:
            filter_entities: QuerySet или список объектов FilterEntity
        
        Returns:
            Dict с множествами ID или None если фильтры не заданы
        """
        if not filter_entities:
            return None
        
        # Преобразуем QuerySet в список если нужно
        if hasattr(filter_entities, 'all'):
            filter_entities = list(filter_entities.all())
        elif hasattr(filter_entities, '__iter__'):
            filter_entities = list(filter_entities)
        else:
            return None
        
        # Создаем множества для быстрого поиска
        result = set()
        
        for entity in filter_entities:
            if not entity.entity_type == FilterEntity.CHARACTER:
                result.add(entity.entity_id)
        
        if not any([result]):
            logger.warning("Нет активных фильтров для фильтрации")
            return None
        
        logger.info(
            f"Подготовлены фильтры: {len(result)}"
        )
        
        return result