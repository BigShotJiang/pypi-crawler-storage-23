# Issues

## Unresolved

## Resolved

### Form/Template

#### Relative path breaks after .exe is created

Found 0.3.3
Fixed 0.3.6

#### Form Extracts Wrong

Found 0.3.6
Fixed 0.3.7
