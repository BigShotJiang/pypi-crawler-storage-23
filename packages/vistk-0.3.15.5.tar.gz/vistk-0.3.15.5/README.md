# Welcome to my Visual Interfacing Structure (VIS)

A simple to use framework to build GUIs for python apps

Enjoy!
