/**
 * mermaid-theme-fire.js  —  mkdocs-revealjs bundled theme  (DARK theme)
 *
 * Anchor colors
 *   main  #ef5552  →  used as vivid accent on DARK backgrounds
 *   light #e57171  →  secondary accent
 *   bg    near-black with warm fire tint
 *
 * Design intent
 *   - Background: very dark, near-black with warm red/brown tint
 *   - Node fills: deep vivid reds/oranges — fire embers
 *   - Text: very light warm cream — maximum contrast on dark
 *   - Borders: vivid red/orange (glow effect on dark bg)
 *   - Pies, Git, XY: full-wheel vivid rainbow palette
 *
 * Used via:
 *   mermaid.initialize({ theme: 'base', themeVariables: window._mkdocsRevealFireThemeVars })
 */
window._mkdocsRevealFireThemeVars = {
  /* ── Core palette ───────────────────────────────────────────────── */
  background:          '#1b100e',   // near-black, warm fire tint
  primaryColor:        '#81180e',   // deep vivid red — node backgrounds
  secondaryColor:      '#692c11',   // deep orange-red — cluster backgrounds
  tertiaryColor:       '#563910',   // deep amber — composite backgrounds
  mainBkg:             '#81180e',
  secondBkg:           '#692c11',

  /* ── Lines & borders: vivid, glowing on dark bg ─────────────────── */
  lineColor:           '#f69431',   // bright orange
  arrowheadColor:      '#f69431',
  border1:             '#ed2e1d',   // vivid red  — tight borders
  border2:             '#e6560f',   // vivid orange — loose borders
  primaryBorderColor:  '#e6560f',

  /* ── Text: very light warm cream for contrast on dark ───────────── */
  primaryTextColor:    '#feeed7',
  secondaryTextColor:  '#feeed7',
  tertiaryTextColor:   '#feeed7',
  textColor:           '#feeed7',
  titleColor:          '#fadb9e',   // warm gold title

  /* ── Flowchart / nodes ──────────────────────────────────────────── */
  nodeBkg:             '#81180e',
  nodeBorder:          '#ed2e1d',
  clusterBkg:          '#692c11',
  clusterBorder:       '#e6560f',
  defaultLinkColor:    '#f69431',
  edgeLabelBackground: '#2d1f1b',

  /* ── Sequence diagram ───────────────────────────────────────────── */
  actorBkg:            '#81180e',
  actorBorder:         '#e6560f',
  actorTextColor:      '#feeed7',
  actorLineColor:      '#e6560f',
  signalColor:         '#f69431',
  signalTextColor:     '#feeed7',
  labelBoxBkgColor:    '#81180e',
  labelBoxBorderColor: '#ed2e1d',
  labelTextColor:      '#feeed7',
  loopTextColor:       '#feeed7',
  noteBorderColor:     '#e6560f',
  noteBkgColor:        '#34231d',   // dark warm brown note
  noteTextColor:       '#feeed7',
  activationBorderColor:'#e6560f',
  activationBkgColor:  '#422b24',
  sequenceNumberColor: '#feeed7',

  /* ── Gantt chart ────────────────────────────────────────────────── */
  sectionBkgColor:        '#701810',
  altSectionBkgColor:     '#1b100e',
  sectionBkgColor2:       '#701810',
  excludeBkgColor:        '#2a1a15',
  taskBorderColor:        '#ed2e1d',
  taskBkgColor:           '#4e160e',
  taskTextLightColor:     '#feeed7',
  taskTextColor:          '#feeed7',
  taskTextDarkColor:      '#feeed7',
  taskTextOutsideColor:   '#feeed7',
  taskTextClickableColor: '#fadb9e',
  activeTaskBorderColor:  '#ed2e1d',
  activeTaskBkgColor:     '#81180e',
  gridColor:              '#4a2a22',
  doneTaskBkgColor:       '#3a2020',
  doneTaskBorderColor:    '#6a3030',
  critBorderColor:        '#fadb9e',
  critBkgColor:           '#7a4000',
  todayLineColor:         '#fadb9e',

  /* ── State diagram ──────────────────────────────────────────────── */
  stateBkg:                '#81180e',
  stateLabelColor:         '#feeed7',
  transitionColor:         '#f69431',
  compositeBackground:     '#563910',
  compositeTitleBackground:'#81180e',
  compositeBorder:         '#ed2e1d',
  altBackground:           '#251a18',

  /* ── Git graph — full-wheel vivid palette (readable on dark) ─────── */
  git0: '#f05050', git1: '#f08020', git2: '#f0c020',
  git3: '#80e030', git4: '#20d0a0', git5: '#2090f0',
  git6: '#9040f0', git7: '#f040c0',
  gitBranchLabel0: 'white', gitBranchLabel1: '#1b100e',
  gitBranchLabel2: '#1b100e', gitBranchLabel3: '#1b100e',
  gitBranchLabel4: '#1b100e', gitBranchLabel5: 'white',
  gitBranchLabel6: 'white',  gitBranchLabel7: 'white',

  /* ── Pie chart — full-wheel vivid palette ───────────────────────── */
  pie1:  '#f05050', pie2:  '#f08020', pie3:  '#f0c020',
  pie4:  '#80e030', pie5:  '#20d0a0', pie6:  '#2090f0',
  pie7:  '#9040f0', pie8:  '#f040c0', pie9:  '#f06030',
  pie10: '#60e060', pie11: '#40c0f0', pie12: '#c060f0',
  pieStrokeColor:      '#1b100e',
  pieOuterStrokeColor: '#ed2e1d',
  pieLegendTextColor:  '#feeed7',

  /* ── XY chart — full-wheel vivid palette ────────────────────────── */
  /* red → orange → yellow → lime → teal → blue → indigo → violet → pink → cyan */
  xyChart: {
    plotColorPalette: '#f05050,#f08020,#f0c020,#80e030,#20d0a0,#2090f0,#9040f0,#f040c0,#f06030,#40c0f0'
  },

  /* ── Font ───────────────────────────────────────────────────────── */
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif',
  fontSize:   '16px',
};