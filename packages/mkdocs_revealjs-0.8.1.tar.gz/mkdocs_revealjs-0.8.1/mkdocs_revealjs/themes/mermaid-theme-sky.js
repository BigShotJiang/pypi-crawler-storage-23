/**
 * mermaid-theme-sky.js  —  mkdocs-revealjs bundled theme  (LIGHT theme)
 *
 * Anchor colors
 *   main  #2094f3  →  node backgrounds are VERY LIGHT blue tints
 *   light #42a5f5  →  cluster / secondary backgrounds
 *   text  dark navy on all light backgrounds
 *
 * Design intent
 *   - Background: near-white with a gentle blue tint
 *   - Node fills: soft sky-blue (readable, not blinding)
 *   - Text: very dark navy for maximum contrast
 *   - Borders: deep navy (tight) / mid blue (loose)
 *   - Pies, Git, XY: full-wheel vivid rainbow palette
 *
 * Used via:
 *   mermaid.initialize({ theme: 'base', themeVariables: window._mkdocsRevealSkyThemeVars })
 */
window._mkdocsRevealSkyThemeVars = {
  /* ── Core palette ───────────────────────────────────────────────── */
  background:          '#f2f8fd',   // near-white, gentle blue tint
  primaryColor:        '#c6e3fa',   // light sky — node / actor backgrounds
  secondaryColor:      '#dbebfa',   // slightly lighter — cluster backgrounds
  tertiaryColor:       '#ebf5fa',   // palest tint — composite backgrounds
  mainBkg:             '#c6e3fa',
  secondBkg:           '#dbebfa',

  /* ── Lines & borders ────────────────────────────────────────────── */
  lineColor:           '#14609f',   // mid-dark blue
  arrowheadColor:      '#14609f',
  border1:             '#104570',   // deep navy  — tight borders only
  border2:             '#1f67a3',   // mid blue   — loose borders
  primaryBorderColor:  '#1f67a3',

  /* ── Text: all dark navy for contrast on light backgrounds ──────── */
  primaryTextColor:    '#082345',
  secondaryTextColor:  '#082345',
  tertiaryTextColor:   '#082345',
  textColor:           '#082345',
  titleColor:          '#0d2f59',

  /* ── Flowchart / nodes ──────────────────────────────────────────── */
  nodeBkg:             '#c6e3fa',
  nodeBorder:          '#104570',
  clusterBkg:          '#dbebfa',
  clusterBorder:       '#1f67a3',
  defaultLinkColor:    '#14609f',
  edgeLabelBackground: '#eff5fb',

  /* ── Sequence diagram ───────────────────────────────────────────── */
  actorBkg:            '#c6e3fa',
  actorBorder:         '#1f67a3',
  actorTextColor:      '#082345',
  actorLineColor:      '#1f67a3',
  signalColor:         '#104570',
  signalTextColor:     '#104570',
  labelBoxBkgColor:    '#c6e3fa',
  labelBoxBorderColor: '#104570',
  labelTextColor:      '#082345',
  loopTextColor:       '#082345',
  noteBorderColor:     '#1f67a3',
  noteBkgColor:        '#e2f3f9',   // pale cyan tint
  noteTextColor:       '#082345',
  activationBorderColor:'#1f67a3',
  activationBkgColor:  '#eaf3fb',
  sequenceNumberColor: '#082345',

  /* ── Gantt chart ────────────────────────────────────────────────── */
  sectionBkgColor:        '#1f67a3',
  altSectionBkgColor:     '#f2f8fd',
  sectionBkgColor2:       '#1f67a3',
  excludeBkgColor:        '#dde8f0',
  taskBorderColor:        '#104570',
  taskBkgColor:           '#144d7b',
  taskTextLightColor:     'white',
  taskTextColor:          'white',
  taskTextDarkColor:      '#082345',
  taskTextOutsideColor:   '#082345',
  taskTextClickableColor: '#1f67a3',
  activeTaskBorderColor:  '#104570',
  activeTaskBkgColor:     '#c6e3fa',
  gridColor:              '#c0d8ee',
  doneTaskBkgColor:       '#c8d8e8',
  doneTaskBorderColor:    '#7a9ab8',
  critBorderColor:        '#e05555',
  critBkgColor:           '#ffcccc',
  todayLineColor:         '#e05555',

  /* ── State diagram ──────────────────────────────────────────────── */
  stateBkg:                '#c6e3fa',
  stateLabelColor:         '#082345',
  transitionColor:         '#14609f',
  compositeBackground:     '#ebf5fa',
  compositeTitleBackground:'#c6e3fa',
  compositeBorder:         '#104570',
  altBackground:           '#e7f1f8',

  /* ── Git graph — full-wheel vivid palette ───────────────────────── */
  git0: '#198ff0', git1: '#f07319', git2: '#19f0a9',
  git3: '#a919f0', git4: '#f0c519', git5: '#f019a9',
  git6: '#2419f0', git7: '#f01919',
  gitBranchLabel0: 'white', gitBranchLabel1: 'white',
  gitBranchLabel2: 'white', gitBranchLabel3: 'white',
  gitBranchLabel4: '#082345', gitBranchLabel5: '#082345',
  gitBranchLabel6: 'white',  gitBranchLabel7: 'white',

  /* ── Pie chart — full-wheel vivid palette ───────────────────────── */
  pie1:  '#369df2', pie2:  '#94f236', pie3:  '#b336f2',
  pie4:  '#f28436', pie5:  '#f23636', pie6:  '#3f36f2',
  pie7:  '#f2cc36', pie8:  '#f236b3', pie9:  '#36f255',
  pie10: '#36f2b3', pie11: '#36d3f2', pie12: '#3674f2',
  pieStrokeColor:      '#104570',
  pieOuterStrokeColor: '#104570',
  pieLegendTextColor:  '#082345',

  /* ── XY chart — full-wheel vivid palette ────────────────────────── */
  /* sky-blue → indigo → violet → pink → red → orange → amber → lime → teal → cyan */
  xyChart: {
    plotColorPalette: '#369df2,#3f36f2,#b336f2,#f236b3,#f23636,#f28436,#f2cc36,#94f236,#36f2b3,#36d3f2'
  },

  /* ── Font ───────────────────────────────────────────────────────── */
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif',
  fontSize:   '16px',
};