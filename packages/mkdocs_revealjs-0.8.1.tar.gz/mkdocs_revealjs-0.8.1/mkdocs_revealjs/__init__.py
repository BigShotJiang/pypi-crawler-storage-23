from mkdocs_revealjs.plugin import RevealjsPlugin
from mkdocs_revealjs._version import __version__

__all__ = ["RevealjsPlugin"]
