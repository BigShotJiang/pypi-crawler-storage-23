# -*- coding: utf-8 -*-
"""
Created on Sat Apr 11 17:22:09 2020

@author: Emmanuel Jordy Menvouta
Edits by Sven Serneels. 
"""


__name__ = "sudire"
__author__ = "Emmanuel Jordy Menvouta"
__license__ = "MIT"
__version__ = "0.1.6"
__date__ = "2022-10-09"
