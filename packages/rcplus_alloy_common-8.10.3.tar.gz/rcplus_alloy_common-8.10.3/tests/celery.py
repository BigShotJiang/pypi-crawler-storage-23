"""a fake celery module for testing purposes"""

import logging


class ColorFormatter(logging.Formatter):
    pass
