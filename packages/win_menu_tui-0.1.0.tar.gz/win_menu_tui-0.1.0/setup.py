from setuptools import setup,find_packages

setup(name="win_menu_tui",
      version="0.1.0",
      packages=find_packages(),
      install_requires=[])