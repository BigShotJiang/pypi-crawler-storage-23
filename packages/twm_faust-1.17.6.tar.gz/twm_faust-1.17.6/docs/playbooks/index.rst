.. _playbooks:

===============
 Playbooks
===============

:Release: |version|
:Date: |today|

.. toctree::
    :maxdepth: 1

    quickstart
    pageviews
    leaderelection
    vskafka
    vscelery
    cheatsheet
