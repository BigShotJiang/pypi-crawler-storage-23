=====================================================
 ``faust.auth``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.auth

.. automodule:: faust.auth
    :members:
    :undoc-members:
