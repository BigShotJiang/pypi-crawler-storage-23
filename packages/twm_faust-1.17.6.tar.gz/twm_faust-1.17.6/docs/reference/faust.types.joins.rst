=====================================================
 ``faust.types.joins``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.joins

.. automodule:: faust.types.joins
    :members:
    :undoc-members:
