=====================================================
 ``faust.types.fixups``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.fixups

.. automodule:: faust.types.fixups
    :members:
    :undoc-members:
