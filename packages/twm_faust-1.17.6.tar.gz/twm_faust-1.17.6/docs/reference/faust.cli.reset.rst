=====================================================
 ``faust.cli.reset``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.reset

.. automodule:: faust.cli.reset
    :members:
    :undoc-members:
