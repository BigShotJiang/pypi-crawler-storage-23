=====================================================
 ``faust.types.serializers``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.serializers

.. automodule:: faust.types.serializers
    :members:
    :undoc-members:
