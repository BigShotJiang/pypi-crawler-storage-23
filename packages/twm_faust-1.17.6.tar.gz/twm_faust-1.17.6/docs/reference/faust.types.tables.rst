=====================================================
 ``faust.types.tables``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.tables

.. automodule:: faust.types.tables
    :members:
    :undoc-members:
