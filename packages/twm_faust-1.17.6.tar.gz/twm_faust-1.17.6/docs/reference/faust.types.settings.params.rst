=====================================================
 ``faust.types.settings.params``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.settings.params

.. automodule:: faust.types.settings.params
    :members:
    :undoc-members:
