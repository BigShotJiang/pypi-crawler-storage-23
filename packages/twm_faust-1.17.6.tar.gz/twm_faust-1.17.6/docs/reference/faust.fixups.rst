=====================================================
 ``faust.fixups``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.fixups

.. automodule:: faust.fixups
    :members:
    :undoc-members:
