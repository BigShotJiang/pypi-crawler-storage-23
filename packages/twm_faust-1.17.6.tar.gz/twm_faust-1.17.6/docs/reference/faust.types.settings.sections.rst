=====================================================
 ``faust.types.settings.sections``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.settings.sections

.. automodule:: faust.types.settings.sections
    :members:
    :undoc-members:
