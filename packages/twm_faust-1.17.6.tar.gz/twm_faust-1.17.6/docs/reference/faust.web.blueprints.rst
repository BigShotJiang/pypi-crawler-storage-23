=====================================================
 ``faust.web.blueprints``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.web.blueprints

.. automodule:: faust.web.blueprints
    :members:
    :undoc-members:
