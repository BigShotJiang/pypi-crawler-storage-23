=====================================================
 ``faust.cli.tables``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.cli.tables

.. automodule:: faust.cli.tables
    :members:
    :undoc-members:
