=====================================================
 ``faust.types.app``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.types.app

.. automodule:: faust.types.app
    :members:
    :undoc-members:
