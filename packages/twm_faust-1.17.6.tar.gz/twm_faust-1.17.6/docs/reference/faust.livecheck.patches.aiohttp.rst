=====================================================
 ``faust.livecheck.patches.aiohttp``
=====================================================

.. contents::
    :local:
.. currentmodule:: faust.livecheck.patches.aiohttp

.. automodule:: faust.livecheck.patches.aiohttp
    :members:
    :undoc-members:
