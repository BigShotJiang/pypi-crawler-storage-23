=============================================
 Kafka - The basics you need to know
=============================================

.. contents::
    :local:
    :depth: 1

.. include:: ../includes/kafka.txt
