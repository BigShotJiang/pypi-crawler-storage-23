from proj323 import app


@app.command()
async def myprocesscommandi323():
    print('HELLO WORLD #323')
