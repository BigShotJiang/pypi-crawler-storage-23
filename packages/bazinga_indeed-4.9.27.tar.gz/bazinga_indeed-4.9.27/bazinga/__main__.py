#!/usr/bin/env python3
"""
Allow running as: python -m bazinga
"""
from .cli import main_sync

if __name__ == "__main__":
    main_sync()
