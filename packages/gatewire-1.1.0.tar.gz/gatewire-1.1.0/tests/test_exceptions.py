"""Tests for gatewire.exceptions."""

import pytest

from gatewire.exceptions import GateWireException


class TestGateWireException:
    def test_is_exception_subclass(self):
        assert issubclass(GateWireException, Exception)

    def test_message_stored_in_args(self):
        exc = GateWireException("something went wrong")
        assert exc.args[0] == "something went wrong"

    def test_default_status_code_is_zero(self):
        exc = GateWireException("oops")
        assert exc.status_code == 0

    def test_custom_status_code(self):
        exc = GateWireException("rate limited", status_code=429)
        assert exc.status_code == 429

    def test_str_with_status_code(self):
        exc = GateWireException("Insufficient balance.", status_code=402)
        assert str(exc) == "[402] Insufficient balance."

    def test_str_without_status_code(self):
        exc = GateWireException("Network timeout")
        assert str(exc) == "Network timeout"

    def test_str_with_status_code_zero_omits_bracket(self):
        exc = GateWireException("Network timeout", status_code=0)
        assert str(exc) == "Network timeout"

    def test_can_be_raised_and_caught(self):
        with pytest.raises(GateWireException) as exc_info:
            raise GateWireException("failed", status_code=503)
        assert exc_info.value.status_code == 503
        assert "failed" in str(exc_info.value)
