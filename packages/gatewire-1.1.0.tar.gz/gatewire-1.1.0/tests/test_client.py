"""Tests for gatewire.client.GateWireClient."""

import json
from unittest.mock import MagicMock, patch

import pytest
import requests

from gatewire.client import GateWireClient
from gatewire.exceptions import GateWireException

API_KEY = "test_api_key_abc123"
BASE_URL = "https://gatewire.raystate.com/api/v1"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def make_response(status_code: int, body: dict) -> MagicMock:
    """Build a fake requests.Response."""
    resp = MagicMock()
    resp.status_code = status_code
    resp.ok = 200 <= status_code < 300
    resp.json.return_value = body
    return resp


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture()
def client():
    return GateWireClient(api_key=API_KEY)


@pytest.fixture()
def mock_session(client):
    """Patch the session on an existing client and return the mock."""
    with patch.object(client, "_session") as mock:
        yield mock


# ---------------------------------------------------------------------------
# Constructor / session setup
# ---------------------------------------------------------------------------


class TestInit:
    def test_base_url_trailing_slash_stripped(self):
        c = GateWireClient(api_key=API_KEY, base_url=f"{BASE_URL}/")
        assert c.base_url == BASE_URL

    def test_authorization_header_set(self, client):
        assert client._session.headers["Authorization"] == f"Bearer {API_KEY}"

    def test_content_type_header_set(self, client):
        assert client._session.headers["Content-Type"] == "application/json"

    def test_accept_header_set(self, client):
        assert client._session.headers["Accept"] == "application/json"

    def test_user_agent_header_set(self, client):
        assert "GateWire-Python" in client._session.headers["User-Agent"]

    def test_session_created_once(self):
        """A single Session must be reused — not created per request."""
        c = GateWireClient(api_key=API_KEY)
        session_id = id(c._session)
        # Simulate multiple calls without actually hitting the network
        with patch.object(c._session, "request", return_value=make_response(200, {"reference_id": "x", "status": "pending"})):
            c.dispatch(phone="+213555000000")
            c.dispatch(phone="+213555000001")
        assert id(c._session) == session_id


# ---------------------------------------------------------------------------
# dispatch()
# ---------------------------------------------------------------------------


class TestDispatch:
    def test_calls_send_otp_endpoint(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        mock_session.request.assert_called_once()
        call_args = mock_session.request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1].endswith("/send-otp")

    def test_returns_reference_id_and_status(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        result = client.dispatch(phone="+213555123456")
        assert result["reference_id"] == "wg_01HX"
        assert result["status"] == "pending"

    def test_phone_sent_in_body(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        sent_json = mock_session.request.call_args[1]["json"]
        assert sent_json["phone"] == "+213555123456"

    def test_template_key_included_when_provided(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456", template_key="login_otp")
        sent_json = mock_session.request.call_args[1]["json"]
        assert sent_json["template_key"] == "login_otp"

    def test_template_key_omitted_when_none(self, client, mock_session):
        """None values must be stripped before sending."""
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        sent_json = mock_session.request.call_args[1]["json"]
        assert "template_key" not in sent_json

    def test_402_raises_gate_wire_exception(self, client, mock_session):
        mock_session.request.return_value = make_response(
            402, {"error": "Insufficient balance. Please top up your account."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 402
        assert "Insufficient balance" in str(exc_info.value)

    def test_429_raises_gate_wire_exception(self, client, mock_session):
        mock_session.request.return_value = make_response(
            429, {"error": "Daily OTP limit of 100 reached. Try again tomorrow."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 429

    def test_503_raises_gate_wire_exception(self, client, mock_session):
        mock_session.request.return_value = make_response(
            503, {"error": "No available devices."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 503

    def test_500_raises_gate_wire_exception(self, client, mock_session):
        mock_session.request.return_value = make_response(
            500, {"error": "Internal server error."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 500

    def test_no_message_or_priority_fields_sent(self, client, mock_session):
        """Removed parameters must never appear in the request body."""
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        sent_json = mock_session.request.call_args[1]["json"]
        assert "message" not in sent_json
        assert "priority" not in sent_json

    def test_does_not_call_dispatch_endpoint(self, client, mock_session):
        """The old /dispatch endpoint must never be used."""
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        url = mock_session.request.call_args[0][1]
        assert "/dispatch" not in url


# ---------------------------------------------------------------------------
# verify_otp()
# ---------------------------------------------------------------------------


class TestVerifyOtp:
    def test_calls_verify_otp_endpoint(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"status": "verified", "message": "Success"}
        )
        client.verify_otp(reference_id="wg_01HX", code="4827")
        call_args = mock_session.request.call_args
        assert call_args[0][0] == "POST"
        assert call_args[0][1].endswith("/verify-otp")

    def test_returns_verified_status(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"status": "verified", "message": "Success"}
        )
        result = client.verify_otp(reference_id="wg_01HX", code="4827")
        assert result["status"] == "verified"
        assert result["message"] == "Success"

    def test_reference_id_and_code_in_body(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"status": "verified", "message": "Success"}
        )
        client.verify_otp(reference_id="wg_01HX", code="4827")
        sent_json = mock_session.request.call_args[1]["json"]
        assert sent_json["reference_id"] == "wg_01HX"
        assert sent_json["code"] == "4827"

    def test_400_invalid_code_raises(self, client, mock_session):
        mock_session.request.return_value = make_response(
            400, {"error": "Invalid or expired code."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.verify_otp(reference_id="wg_01HX", code="0000")
        assert exc_info.value.status_code == 400
        assert "Invalid or expired code" in str(exc_info.value)

    def test_400_already_used_raises(self, client, mock_session):
        mock_session.request.return_value = make_response(
            400, {"error": "This OTP has already been used."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.verify_otp(reference_id="wg_01HX", code="4827")
        assert exc_info.value.status_code == 400
        assert "already been used" in str(exc_info.value)

    def test_400_cancelled_raises(self, client, mock_session):
        mock_session.request.return_value = make_response(
            400, {"error": "This OTP has been cancelled."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.verify_otp(reference_id="wg_01HX", code="4827")
        assert exc_info.value.status_code == 400

    def test_400_expired_raises(self, client, mock_session):
        mock_session.request.return_value = make_response(
            400, {"error": "This OTP has expired."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.verify_otp(reference_id="wg_01HX", code="4827")
        assert exc_info.value.status_code == 400

    def test_400_failed_delivery_raises(self, client, mock_session):
        mock_session.request.return_value = make_response(
            400, {"error": "This OTP failed to deliver."}
        )
        with pytest.raises(GateWireException) as exc_info:
            client.verify_otp(reference_id="wg_01HX", code="4827")
        assert exc_info.value.status_code == 400


# ---------------------------------------------------------------------------
# status()
# ---------------------------------------------------------------------------


class TestStatus:
    def test_calls_status_endpoint_with_reference_id(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200,
            {
                "reference_id": "wg_01HX",
                "status": "sent",
                "created_at": "2026-03-03T14:22:00Z",
            },
        )
        client.status(reference_id="wg_01HX")
        call_args = mock_session.request.call_args
        assert call_args[0][0] == "GET"
        assert call_args[0][1].endswith("/status/wg_01HX")

    def test_returns_full_status_dict(self, client, mock_session):
        body = {
            "reference_id": "wg_01HX",
            "status": "sent",
            "created_at": "2026-03-03T14:22:00Z",
        }
        mock_session.request.return_value = make_response(200, body)
        result = client.status(reference_id="wg_01HX")
        assert result == body

    def test_no_body_sent_for_get(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200,
            {"reference_id": "wg_01HX", "status": "pending", "created_at": ""},
        )
        client.status(reference_id="wg_01HX")
        sent_json = mock_session.request.call_args[1]["json"]
        assert sent_json is None

    @pytest.mark.parametrize(
        "status_value",
        ["pending", "dispatched", "sent", "verified", "failed", "expired", "cancelled"],
    )
    def test_all_status_values_returned_as_is(self, client, mock_session, status_value):
        mock_session.request.return_value = make_response(
            200,
            {"reference_id": "wg_01HX", "status": status_value, "created_at": ""},
        )
        result = client.status(reference_id="wg_01HX")
        assert result["status"] == status_value


# ---------------------------------------------------------------------------
# _request() — shared error-handling behaviour
# ---------------------------------------------------------------------------


class TestRequest:
    def test_error_key_used_not_message_key(self, client, mock_session):
        """Backend uses 'error', never 'message', for error bodies."""
        mock_session.request.return_value = make_response(
            402,
            {
                "error": "Insufficient balance.",
                "message": "should be ignored",
            },
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        # Must pick up "error", not "message"
        assert "Insufficient balance" in str(exc_info.value)
        assert "should be ignored" not in str(exc_info.value)

    def test_fallback_message_when_error_key_absent(self, client, mock_session):
        mock_session.request.return_value = make_response(500, {})
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert "HTTP 500" in str(exc_info.value)

    def test_network_error_raises_with_status_code_zero(self, client, mock_session):
        mock_session.request.side_effect = requests.exceptions.ConnectionError(
            "Connection refused"
        )
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 0

    def test_timeout_raises_gate_wire_exception(self, client, mock_session):
        mock_session.request.side_effect = requests.exceptions.Timeout("timed out")
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 0

    def test_invalid_json_response_handled(self, client, mock_session):
        resp = MagicMock()
        resp.status_code = 500
        resp.ok = False
        resp.json.side_effect = ValueError("No JSON")
        mock_session.request.return_value = resp
        with pytest.raises(GateWireException) as exc_info:
            client.dispatch(phone="+213555123456")
        assert exc_info.value.status_code == 500

    def test_none_values_stripped_from_payload(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"status": "verified", "message": "Success"}
        )
        # verify_otp has no optional fields, but dispatch's template_key=None
        # should be stripped — verified by test_template_key_omitted_when_none.
        # Here we check the general stripping logic via verify_otp directly.
        client.verify_otp(reference_id="wg_01HX", code="1234")
        sent_json = mock_session.request.call_args[1]["json"]
        assert all(v is not None for v in sent_json.values())

    def test_timeout_is_10_seconds(self, client, mock_session):
        mock_session.request.return_value = make_response(
            200, {"reference_id": "wg_01HX", "status": "pending"}
        )
        client.dispatch(phone="+213555123456")
        assert mock_session.request.call_args[1]["timeout"] == 10


# ---------------------------------------------------------------------------
# Removed methods / endpoints must not exist
# ---------------------------------------------------------------------------


class TestRemovedAPI:
    def test_get_balance_does_not_exist(self, client):
        assert not hasattr(client, "get_balance")

    def test_dispatch_has_no_message_param(self, client, mock_session):
        """Passing message= must raise TypeError (unknown kwarg)."""
        with pytest.raises(TypeError):
            client.dispatch(phone="+213555123456", message="hello")

    def test_dispatch_has_no_priority_param(self, client, mock_session):
        with pytest.raises(TypeError):
            client.dispatch(phone="+213555123456", priority=True)
