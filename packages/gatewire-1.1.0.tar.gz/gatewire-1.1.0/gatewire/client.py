import requests

from .exceptions import GateWireException


class GateWireClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = "https://gatewire.raystate.com/api/v1",
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "Accept": "application/json",
                "User-Agent": "GateWire-Python/1.1.0",
            }
        )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def dispatch(self, phone: str, template_key: str | None = None) -> dict:
        """Send an OTP to a phone number.

        Args:
            phone: Recipient in any format (e.g. "+213555123456").
            template_key: Optional message template key defined in the
                dashboard. Omit to use the account's default template.

        Returns:
            dict with keys: reference_id (str), status (str)

        Raises:
            GateWireException: 402 Insufficient balance
                               429 Rate limit reached
                               503 No devices available
                               500 Server error
        """
        payload = {"phone": phone, "template_key": template_key}
        return self._request("POST", "/send-otp", payload)

    def verify_otp(self, reference_id: str, code: str) -> dict:
        """Verify the OTP code entered by the end-user.

        Args:
            reference_id: The reference_id returned by dispatch().
            code: The code the user submitted.

        Returns:
            dict with keys: status ("verified"), message (str)

        Raises:
            GateWireException: 400 Invalid/expired/cancelled/already-used code
        """
        payload = {"reference_id": reference_id, "code": code}
        return self._request("POST", "/verify-otp", payload)

    def status(self, reference_id: str) -> dict:
        """Check the delivery status of an OTP.

        Args:
            reference_id: The reference_id returned by dispatch().

        Returns:
            dict with keys: reference_id (str), status (str), created_at (str)

        Status values:
            pending | dispatched | sent | verified | failed | expired | cancelled
        """
        return self._request("GET", f"/status/{reference_id}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _request(
        self, method: str, endpoint: str, data: dict | None = None
    ) -> dict:
        url = f"{self.base_url}{endpoint}"
        payload: dict | None = None
        if data is not None:
            payload = {k: v for k, v in data.items() if v is not None}

        try:
            response = self._session.request(method, url, json=payload, timeout=10)

            try:
                response_json: dict = response.json()
            except ValueError:
                response_json = {}

            if not response.ok:
                error_msg = response_json.get("error") or f"HTTP {response.status_code}"
                raise GateWireException(error_msg, status_code=response.status_code)

            return response_json

        except requests.exceptions.RequestException as exc:
            raise GateWireException(str(exc), status_code=0) from exc
