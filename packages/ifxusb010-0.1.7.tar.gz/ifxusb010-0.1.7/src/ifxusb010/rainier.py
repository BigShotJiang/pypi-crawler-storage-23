from .mckinley import xdpe152xx

class xdpe192xx(xdpe152xx):
    def __init__(self, device_address, dongle_instance):
        super().__init__(device_address, dongle_instance)
        
        self.device_family = "Rainier"

    