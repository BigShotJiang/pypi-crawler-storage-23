from .pmbus import PMBusDevice
from bitarray import bitarray as ba
from bitarray.util import hex2ba, ba2hex, pprint, ba2int, ba2base, base2ba, ba2int

from typing import Optional


class xdpe152xx(PMBusDevice):
    def __init__(self, device_address, dongle_instance):
        super().__init__(device_address, dongle_instance)
        self.device_otp_checksum: Optional[int] = None
        self.device_family = "McKinley"

        #self.get_device_otp_checksum()

    def get_device_otp_checksum(self):
        self.device_write([0xfd, 0x04, 0x00, 0x00, 0x00, 0x00])
        self.device_write([0xfe, 0x2d])
        result = self.device_read([0xfd], 5,result_reverse=True)
        #value = int.from_bytes(result['readData'][1:5][::-1], byteorder='big')
        #self.device_otp_checksum = hex(value)
        # 將 readData 轉為 bitarray（假設 readData 是位元組列表）
        data_ba = ba()
        data_ba.frombytes(bytes(result['readData']))  # 創建位陣列
        
     
        selected_bytes = bytes(result['readData'][0:4])  
        selected_ba = ba()
        selected_ba.frombytes(selected_bytes)
        
        # 轉為整數（big-endian）
        value = ba2int(selected_ba)  # bitarray.util 的 ba2int 函數
        self.device_otp_checksum = hex(value)
