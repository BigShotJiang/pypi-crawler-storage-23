"""Step-ca certificate service community plugin."""

from .StepCaCertService import StepCaCertService

__all__ = ["StepCaCertService"]
