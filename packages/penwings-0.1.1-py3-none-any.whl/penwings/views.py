from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.preprocessing import (
    TargetEncoder,
    OneHotEncoder,
    RobustScaler,
    KBinsDiscretizer,
    FunctionTransformer,
    PolynomialFeatures,
    OrdinalEncoder,
    StandardScaler,
)

LinearView = ColumnTransformer(
    [
        ("numerical", RobustScaler(), make_column_selector(dtype_exclude="category")),
        ("category", TargetEncoder(shuffle=True, smooth=10, random_state=42), make_column_selector(dtype_include="category")),
    ],
    remainder="drop",
    verbose_feature_names_out=False,
).set_output(transform="pandas")

DenseView = ColumnTransformer(
    [
        ("numerical", StandardScaler(), make_column_selector(dtype_exclude="category")),
        ("category", TargetEncoder(shuffle=True, smooth=10, random_state=42), make_column_selector(dtype_include="category")),
    ],
    remainder="drop",
    verbose_feature_names_out=False,
).set_output(transform="pandas")

CategoricalView = Pipeline(
    [
        (
            "bins",
            ColumnTransformer(
                [
                    (
                        "numerical",
                        KBinsDiscretizer(n_bins=4, strategy="quantile", quantile_method="averaged_inverted_cdf", encode="ordinal"),
                        make_column_selector(dtype_exclude="category"),
                    ),
                    (
                        "category",
                        OrdinalEncoder(handle_unknown="use_encoded_value", unknown_value=-1),
                        make_column_selector(dtype_include="category"),
                    ),
                ],
                remainder="drop",
                verbose_feature_names_out=False,
            ).set_output(transform="pandas"),
        ),
        ("cats", FunctionTransformer(lambda df: df.astype(int).astype("category"), feature_names_out="one-to-one")),
    ]
)

PolynomialView = Pipeline(
    [
        ("Linear", LinearView),
        ("poly", PolynomialFeatures(degree=2).set_output(transform="pandas")),
    ]
)

SparseView = ColumnTransformer(
    [
        (
            "num_bins",
            KBinsDiscretizer(n_bins=10, quantile_method="averaged_inverted_cdf", encode="onehot"),
            make_column_selector(dtype_exclude="category"),
        ),
        (
            "cat_ohe",
            OneHotEncoder(handle_unknown="ignore"),
            make_column_selector(dtype_include="category"),
        ),
    ],
    remainder="drop",
    verbose_feature_names_out=False,
)
