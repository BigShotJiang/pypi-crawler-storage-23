from optuna.trial import Trial


def tune_lgbm_params(trial: Trial, model="classifier"):
    if model == "classifier":
        metrics = {
            "objective": "binary",
            "metric": "auc",
        }

    params = {
        # Core
        "verbosity": -1,
        "boosting_type": "gbdt",
        # GPU
        "device": "gpu",
        "gpu_platform_id": 0,
        "gpu_device_id": 0,
        # Learning
        "learning_rate": trial.suggest_float("learning_rate", 0.005, 0.05, log=True),
        "n_estimators": trial.suggest_int("n_estimators", 1500, 5000),
        # Tree structure (GPU-safe)
        "num_leaves": trial.suggest_int("num_leaves", 31, 128),
        "max_depth": trial.suggest_int("max_depth", 4, 10),
        # Regularization / stability
        "min_child_samples": trial.suggest_int("min_child_samples", 10, 80),
        "min_child_weight": trial.suggest_float("min_child_weight", 1e-3, 10.0, log=True),
        "min_split_gain": trial.suggest_float("min_split_gain", 0.0, 1.0),
        # Sampling
        "subsample": trial.suggest_float("subsample", 0.6, 1.0),
        "subsample_freq": trial.suggest_int("subsample_freq", 1, 10),
        "feature_fraction": trial.suggest_float("feature_fraction", 0.6, 1.0),
        # Regularization
        "reg_alpha": trial.suggest_float("reg_alpha", 1e-8, 1.0, log=True),
        "reg_lambda": trial.suggest_float("reg_lambda", 1e-8, 5.0, log=True),
        # Histogram
        "max_bin": trial.suggest_int("max_bin", 64, 255),
        # Class imbalance (keep only if needed)
        "scale_pos_weight": trial.suggest_float("scale_pos_weight", 0.8, 3.0),
    }

    return metrics | params
