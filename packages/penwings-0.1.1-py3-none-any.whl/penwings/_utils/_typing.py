from typing import TypedDict, Sequence

class SQLParquetKwargs(TypedDict, total=False):
    index_col: str | list[str] | None
    parse_dates: Sequence[str] | None
    dtype: dict | None
    chuncksize: int
