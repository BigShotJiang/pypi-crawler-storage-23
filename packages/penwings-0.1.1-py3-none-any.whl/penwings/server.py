import os
import pandas as pd

from sqlalchemy import create_engine, Engine
from pathlib import Path
from datetime import datetime, timedelta
from typing import Unpack
from .paths import input_dir, output_dir
from ._utils._typing import SQLParquetKwargs
from ._utils._decorators import timing_sql


psw = os.environ["mssql_password"]
un = os.environ["mssql_user"]
sa = os.environ["mssql_address"]

SGH = create_engine(f"mssql+pyodbc://{un}:{psw}@{sa}/Finance?driver=ODBC+Driver+18+for+SQL+Server&TrustServerCertificate=yes")


class SQLParquetCache:
    def __init__(
        self,
        sql_dir: Path | str = input_dir / "sql",
        parquet_dir: Path | str = output_dir / "parquet",
        refresh_days: int = 7,
        conn: Engine = SGH,
        verbose: bool = True,
        **kwargs: Unpack[SQLParquetKwargs],
    ):
        self.sql_dir = sql_dir
        self.parquet_dir = parquet_dir
        self.refresh_days = refresh_days
        self.conn = conn
        self.global_kwargs = kwargs

        self.verbose = verbose
        self.source = "SQL"

    def set_params(self, **params):
        for key, value in params.items():
            if not hasattr(self, key):
                raise ValueError(f"Invalid parameter: {key}")
            setattr(self, key, value)
        return self

    def _sql_path(self, sql_file: str) -> Path:
        if not isinstance(self.sql_dir, Path):
            self.sql_dir = Path(self.sql_dir)
        return self.sql_dir / sql_file

    def _parquet_path(self, sql_file: str) -> Path:
        if not isinstance(self.parquet_dir, Path):
            self.parquet_dir = Path(self.parquet_dir)
        name = Path(sql_file).stem
        return self.parquet_dir / f"{name}.parquet"

    def _is_new(self, path: Path, refresh_window: int) -> bool:
        if not path.exists():
            return False

        last_modified = datetime.fromtimestamp(path.stat().st_mtime)
        return datetime.now() - last_modified < timedelta(days=refresh_window)

    def _return_sql(self, sql_file: str, conn, **kwargs: Unpack[SQLParquetKwargs]) -> pd.DataFrame:
        return pd.read_sql(self._sql_path(sql_file).read_text(), conn, **kwargs)

    @timing_sql
    def get(
        self, sql_file: str, conn: Engine = None, refresh_days: int = None, force: bool = False, **kwargs: Unpack[SQLParquetKwargs]
    ) -> pd.DataFrame:
        connection = conn or self.conn
        refresh_window = refresh_days or self.refresh_days
        parquet_path = self._parquet_path(sql_file)
        sql_kwargs = self.global_kwargs | kwargs

        if not force and self._is_new(parquet_path, refresh_window):
            source = "Parquet"
            return pd.read_parquet(parquet_path), source

        source = "SQL"
        df = self._return_sql(sql_file, connection, **sql_kwargs)
        self.parquet_dir.mkdir(parents=True, exist_ok=True)
        df.to_parquet(parquet_path, index=False)

        return df, source
