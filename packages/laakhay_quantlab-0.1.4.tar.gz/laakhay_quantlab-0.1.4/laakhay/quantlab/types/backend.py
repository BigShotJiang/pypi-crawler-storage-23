"""Backend-specific type definitions."""

BackendName = str

ArrayFunction = any
GradFunction = any
UnaryOp = any
BinaryOp = any

BackendProtocol = any
