"""Pydantic models for DeFiStream API responses."""

from typing import Any, Literal
from pydantic import BaseModel


class ResponseMetadata(BaseModel):
    """Metadata from API response headers."""

    rate_limit: int | None = None
    quota_remaining: int | None = None
    request_cost: int | None = None


class CostEstimate(BaseModel):
    """Cost estimation from the calculate-cost endpoint."""

    query: str
    cost: int
    quota_remaining: int
    quota_remaining_after: int
    breakdown: dict[str, Any] | None = None


class LinkInfo(BaseModel):
    """Information about a generated download link."""

    filename: str
    link: str
    expiry: str
    size: str


class EventsResponse(BaseModel):
    """Standard events API response."""

    status: Literal["success", "error"]
    events: list[dict[str, Any]] = []
    count: int = 0
    error: str | None = None


class ProtocolsResponse(BaseModel):
    """Response from /protocols endpoint."""

    protocols: list[str] = []
