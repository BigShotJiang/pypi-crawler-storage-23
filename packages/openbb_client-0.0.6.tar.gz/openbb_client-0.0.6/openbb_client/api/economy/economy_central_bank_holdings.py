import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_central_bank_holdings import OBBjectCentralBankHoldings
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    date: datetime.date | None | Unset = UNSET,
    holding_type: str | Unset = "all_treasury",
    summary: bool | Unset = False,
    cusip: None | str | Unset = UNSET,
    wam: bool | Unset = False,
    monthly: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    params["holding_type"] = holding_type

    params["summary"] = summary

    json_cusip: None | str | Unset
    if isinstance(cusip, Unset):
        json_cusip = UNSET
    else:
        json_cusip = cusip
    params["cusip"] = json_cusip

    params["wam"] = wam

    params["monthly"] = monthly

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/central_bank_holdings",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCentralBankHoldings.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    date: datetime.date | None | Unset = UNSET,
    holding_type: str | Unset = "all_treasury",
    summary: bool | Unset = False,
    cusip: None | str | Unset = UNSET,
    wam: bool | Unset = False,
    monthly: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse]:
    """Central Bank Holdings

     Get the balance sheet holdings of a central bank.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        date (datetime.date | None | Unset): A specific date to get data for.
        holding_type (str | Unset): Type of holdings to return. (provider: federal_reserve)
            Default: 'all_treasury'.
        summary (bool | Unset): If True, returns historical weekly summary by holding type. This
            parameter takes priority over other parameters. (provider: federal_reserve) Default:
            False.
        cusip (None | str | Unset):  Multiple comma separated items allowed.
        wam (bool | Unset): If True, returns weighted average maturity aggregated by agency or
            treasury securities. This parameter takes priority over `holding_type`, `cusip`, and
            `monthly`. (provider: federal_reserve) Default: False.
        monthly (bool | Unset): If True, returns historical data for all Treasury securities at a
            monthly interval. This parameter takes priority over other parameters, except `wam`. Only
            valid when `holding_type` is set to: 'all_treasury', 'bills', 'notesbonds', 'frn', 'tips'.
            (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        holding_type=holding_type,
        summary=summary,
        cusip=cusip,
        wam=wam,
        monthly=monthly,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    date: datetime.date | None | Unset = UNSET,
    holding_type: str | Unset = "all_treasury",
    summary: bool | Unset = False,
    cusip: None | str | Unset = UNSET,
    wam: bool | Unset = False,
    monthly: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse | None:
    """Central Bank Holdings

     Get the balance sheet holdings of a central bank.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        date (datetime.date | None | Unset): A specific date to get data for.
        holding_type (str | Unset): Type of holdings to return. (provider: federal_reserve)
            Default: 'all_treasury'.
        summary (bool | Unset): If True, returns historical weekly summary by holding type. This
            parameter takes priority over other parameters. (provider: federal_reserve) Default:
            False.
        cusip (None | str | Unset):  Multiple comma separated items allowed.
        wam (bool | Unset): If True, returns weighted average maturity aggregated by agency or
            treasury securities. This parameter takes priority over `holding_type`, `cusip`, and
            `monthly`. (provider: federal_reserve) Default: False.
        monthly (bool | Unset): If True, returns historical data for all Treasury securities at a
            monthly interval. This parameter takes priority over other parameters, except `wam`. Only
            valid when `holding_type` is set to: 'all_treasury', 'bills', 'notesbonds', 'frn', 'tips'.
            (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        date=date,
        holding_type=holding_type,
        summary=summary,
        cusip=cusip,
        wam=wam,
        monthly=monthly,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    date: datetime.date | None | Unset = UNSET,
    holding_type: str | Unset = "all_treasury",
    summary: bool | Unset = False,
    cusip: None | str | Unset = UNSET,
    wam: bool | Unset = False,
    monthly: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse]:
    """Central Bank Holdings

     Get the balance sheet holdings of a central bank.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        date (datetime.date | None | Unset): A specific date to get data for.
        holding_type (str | Unset): Type of holdings to return. (provider: federal_reserve)
            Default: 'all_treasury'.
        summary (bool | Unset): If True, returns historical weekly summary by holding type. This
            parameter takes priority over other parameters. (provider: federal_reserve) Default:
            False.
        cusip (None | str | Unset):  Multiple comma separated items allowed.
        wam (bool | Unset): If True, returns weighted average maturity aggregated by agency or
            treasury securities. This parameter takes priority over `holding_type`, `cusip`, and
            `monthly`. (provider: federal_reserve) Default: False.
        monthly (bool | Unset): If True, returns historical data for all Treasury securities at a
            monthly interval. This parameter takes priority over other parameters, except `wam`. Only
            valid when `holding_type` is set to: 'all_treasury', 'bills', 'notesbonds', 'frn', 'tips'.
            (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        date=date,
        holding_type=holding_type,
        summary=summary,
        cusip=cusip,
        wam=wam,
        monthly=monthly,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    date: datetime.date | None | Unset = UNSET,
    holding_type: str | Unset = "all_treasury",
    summary: bool | Unset = False,
    cusip: None | str | Unset = UNSET,
    wam: bool | Unset = False,
    monthly: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse | None:
    """Central Bank Holdings

     Get the balance sheet holdings of a central bank.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        date (datetime.date | None | Unset): A specific date to get data for.
        holding_type (str | Unset): Type of holdings to return. (provider: federal_reserve)
            Default: 'all_treasury'.
        summary (bool | Unset): If True, returns historical weekly summary by holding type. This
            parameter takes priority over other parameters. (provider: federal_reserve) Default:
            False.
        cusip (None | str | Unset):  Multiple comma separated items allowed.
        wam (bool | Unset): If True, returns weighted average maturity aggregated by agency or
            treasury securities. This parameter takes priority over `holding_type`, `cusip`, and
            `monthly`. (provider: federal_reserve) Default: False.
        monthly (bool | Unset): If True, returns historical data for all Treasury securities at a
            monthly interval. This parameter takes priority over other parameters, except `wam`. Only
            valid when `holding_type` is set to: 'all_treasury', 'bills', 'notesbonds', 'frn', 'tips'.
            (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCentralBankHoldings | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            date=date,
            holding_type=holding_type,
            summary=summary,
            cusip=cusip,
            wam=wam,
            monthly=monthly,
        )
    ).parsed
