from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_fomc_documents_response_200_type_1 import EconomyFomcDocumentsResponse200Type1
from ...models.http_validation_error import HTTPValidationError
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    year: int | None | Unset = UNSET,
    document_type: None | str | Unset = UNSET,
    pdf_only: bool | Unset = False,
    as_choices: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_year: int | None | Unset
    if isinstance(year, Unset):
        json_year = UNSET
    else:
        json_year = year
    params["year"] = json_year

    json_document_type: None | str | Unset
    if isinstance(document_type, Unset):
        json_document_type = UNSET
    else:
        json_document_type = document_type
    params["document_type"] = json_document_type

    params["pdf_only"] = pdf_only

    params["as_choices"] = as_choices

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/fomc_documents",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse | None:
    if response.status_code == 200:

        def _parse_response_200(data: object) -> EconomyFomcDocumentsResponse200Type1 | list[Any]:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                response_200_type_0 = cast(list[Any], data)

                return response_200_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            response_200_type_1 = EconomyFomcDocumentsResponse200Type1.from_dict(data)

            return response_200_type_1

        response_200 = _parse_response_200(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    year: int | None | Unset = UNSET,
    document_type: None | str | Unset = UNSET,
    pdf_only: bool | Unset = False,
    as_choices: bool | Unset = False,
) -> Response[Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse]:
    """Fomc Documents

     Get FOMC documents by year and document type.

    Source: https://www.federalreserve.gov/monetarypolicy/fomc_historical.htm

    Source: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm

    This function does not return the typical OBBject response.

    The response is `list[dict[str, str]]` of FOMC documents and their URLs.

    Each dictionary entry has keys: `date`, `url`, `doc_type`, and `doc_format`.

    If `as_choices` is True, the response is a list of valid Workspace parameter choices.
    Keys, `label` and `value`, correspond with the `doc_type` + `date`, and the `url`, respectively.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        year (int | None | Unset): The year of FOMC documents to retrieve. If None, all years
            since 1959 are returned. (provider: federal_reserve)
        document_type (None | str | Unset): Filter by document type. Default is all. Choose from:
            all, monetary_policy, minutes, projections, materials, press_release, press_conference,
            agenda, transcript, speaker_key, beige_book, teal_book, green_book, blue_book, red_book
            (provider: federal_reserve)
        pdf_only (bool | Unset): Whether to return as a list with only the PDF documents. Default
            is False. (provider: federal_reserve) Default: False.
        as_choices (bool | Unset): Whether to return cast as a list of valid Workspace parameter
            choices. Leave as False for typical use. (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        year=year,
        document_type=document_type,
        pdf_only=pdf_only,
        as_choices=as_choices,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    year: int | None | Unset = UNSET,
    document_type: None | str | Unset = UNSET,
    pdf_only: bool | Unset = False,
    as_choices: bool | Unset = False,
) -> Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse | None:
    """Fomc Documents

     Get FOMC documents by year and document type.

    Source: https://www.federalreserve.gov/monetarypolicy/fomc_historical.htm

    Source: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm

    This function does not return the typical OBBject response.

    The response is `list[dict[str, str]]` of FOMC documents and their URLs.

    Each dictionary entry has keys: `date`, `url`, `doc_type`, and `doc_format`.

    If `as_choices` is True, the response is a list of valid Workspace parameter choices.
    Keys, `label` and `value`, correspond with the `doc_type` + `date`, and the `url`, respectively.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        year (int | None | Unset): The year of FOMC documents to retrieve. If None, all years
            since 1959 are returned. (provider: federal_reserve)
        document_type (None | str | Unset): Filter by document type. Default is all. Choose from:
            all, monetary_policy, minutes, projections, materials, press_release, press_conference,
            agenda, transcript, speaker_key, beige_book, teal_book, green_book, blue_book, red_book
            (provider: federal_reserve)
        pdf_only (bool | Unset): Whether to return as a list with only the PDF documents. Default
            is False. (provider: federal_reserve) Default: False.
        as_choices (bool | Unset): Whether to return cast as a list of valid Workspace parameter
            choices. Leave as False for typical use. (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        year=year,
        document_type=document_type,
        pdf_only=pdf_only,
        as_choices=as_choices,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    year: int | None | Unset = UNSET,
    document_type: None | str | Unset = UNSET,
    pdf_only: bool | Unset = False,
    as_choices: bool | Unset = False,
) -> Response[Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse]:
    """Fomc Documents

     Get FOMC documents by year and document type.

    Source: https://www.federalreserve.gov/monetarypolicy/fomc_historical.htm

    Source: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm

    This function does not return the typical OBBject response.

    The response is `list[dict[str, str]]` of FOMC documents and their URLs.

    Each dictionary entry has keys: `date`, `url`, `doc_type`, and `doc_format`.

    If `as_choices` is True, the response is a list of valid Workspace parameter choices.
    Keys, `label` and `value`, correspond with the `doc_type` + `date`, and the `url`, respectively.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        year (int | None | Unset): The year of FOMC documents to retrieve. If None, all years
            since 1959 are returned. (provider: federal_reserve)
        document_type (None | str | Unset): Filter by document type. Default is all. Choose from:
            all, monetary_policy, minutes, projections, materials, press_release, press_conference,
            agenda, transcript, speaker_key, beige_book, teal_book, green_book, blue_book, red_book
            (provider: federal_reserve)
        pdf_only (bool | Unset): Whether to return as a list with only the PDF documents. Default
            is False. (provider: federal_reserve) Default: False.
        as_choices (bool | Unset): Whether to return cast as a list of valid Workspace parameter
            choices. Leave as False for typical use. (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        year=year,
        document_type=document_type,
        pdf_only=pdf_only,
        as_choices=as_choices,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["federal_reserve"] | Unset = "federal_reserve",
    year: int | None | Unset = UNSET,
    document_type: None | str | Unset = UNSET,
    pdf_only: bool | Unset = False,
    as_choices: bool | Unset = False,
) -> Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse | None:
    """Fomc Documents

     Get FOMC documents by year and document type.

    Source: https://www.federalreserve.gov/monetarypolicy/fomc_historical.htm

    Source: https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm

    This function does not return the typical OBBject response.

    The response is `list[dict[str, str]]` of FOMC documents and their URLs.

    Each dictionary entry has keys: `date`, `url`, `doc_type`, and `doc_format`.

    If `as_choices` is True, the response is a list of valid Workspace parameter choices.
    Keys, `label` and `value`, correspond with the `doc_type` + `date`, and the `url`, respectively.

    Args:
        provider (Literal['federal_reserve'] | Unset):  Default: 'federal_reserve'.
        year (int | None | Unset): The year of FOMC documents to retrieve. If None, all years
            since 1959 are returned. (provider: federal_reserve)
        document_type (None | str | Unset): Filter by document type. Default is all. Choose from:
            all, monetary_policy, minutes, projections, materials, press_release, press_conference,
            agenda, transcript, speaker_key, beige_book, teal_book, green_book, blue_book, red_book
            (provider: federal_reserve)
        pdf_only (bool | Unset): Whether to return as a list with only the PDF documents. Default
            is False. (provider: federal_reserve) Default: False.
        as_choices (bool | Unset): Whether to return cast as a list of valid Workspace parameter
            choices. Leave as False for typical use. (provider: federal_reserve) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | EconomyFomcDocumentsResponse200Type1 | list[Any] | HTTPValidationError | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            year=year,
            document_type=document_type,
            pdf_only=pdf_only,
            as_choices=as_choices,
        )
    ).parsed
