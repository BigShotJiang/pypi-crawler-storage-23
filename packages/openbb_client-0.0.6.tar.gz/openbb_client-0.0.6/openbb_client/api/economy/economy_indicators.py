import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.economy_indicators_provider import EconomyIndicatorsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_economic_indicators import OBBjectEconomicIndicators
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EconomyIndicatorsProvider,
    symbol: None | str,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    transform: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    dimension_values: list[str] | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    pivot: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_symbol: None | str
    json_symbol = symbol
    params["symbol"] = json_symbol

    json_country: None | str | Unset
    if isinstance(country, Unset):
        json_country = UNSET
    else:
        json_country = country
    params["country"] = json_country

    json_frequency: None | str | Unset
    if isinstance(frequency, Unset):
        json_frequency = UNSET
    else:
        json_frequency = frequency
    params["frequency"] = json_frequency

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_transform: None | str | Unset
    if isinstance(transform, Unset):
        json_transform = UNSET
    else:
        json_transform = transform
    params["transform"] = json_transform

    params["use_cache"] = use_cache

    json_dimension_values: list[str] | None | Unset
    if isinstance(dimension_values, Unset):
        json_dimension_values = UNSET
    elif isinstance(dimension_values, list):
        json_dimension_values = dimension_values

    else:
        json_dimension_values = dimension_values
    params["dimension_values"] = json_dimension_values

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["pivot"] = pivot

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/indicators",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEconomicIndicators.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyIndicatorsProvider,
    symbol: None | str,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    transform: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    dimension_values: list[str] | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    pivot: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse]:
    """Indicators

     Get economic indicators by country and indicator.

    Args:
        provider (EconomyIndicatorsProvider):
        symbol (None | str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): econdb, imf.;
                Symbol to get data for. The base symbol for the indicator (e.g. GDP, CPI, etc.). Use
            `available_indicators()` to get a list of available symbols. (provider: econdb);
                Symbol to get data for. Symbol format: 'dataflow::identifier' where identifier is
            either:
            - A table ID (starts with 'H_') for hierarchical table data
            - An indicator code for individual indicator data

            Examples:
                - 'BOP::H_BOP_BOP_AGG_STANDARD_PRESENTATION' - Balance of Payments table
                - 'BOP_AGG::GS_CD,BOP_AGG::GS_DB' - Multiple BOP_AGG indicators (Goods & Services)
                - 'IL::RGV_REVS' - Gold reserves in millions of fine troy ounces
                - 'WEO::NGDP_RPCH' - Real GDP growth (annual only)
                - 'WEO::POILBRE' - Brent crude oil price (use country='G001' for world)
                - 'PCPS::PGOLD' - Gold price per troy ounce (monthly/quarterly available)

            Use `obb.economy.available_indicators(provider='imf')` to discover symbols. Use
            `obb.economy.imf_utils.list_tables()` to see available tables. (provider: imf)
        country (None | str | Unset): The country to get data. Multiple comma separated items
            allowed for provider(s): econdb, imf.;
                The country to get data. ISO country codes or country names. (provider: econdb);
                ISO3 country code(s). Use comma-separated values for multiple countries. Validated
            against the dataflow's available countries via constraint API. (provider: imf)
        frequency (None | str | Unset): The frequency of the data.;
                The frequency of the data, default is 'quarter'. Only valid when 'symbol' is 'main'.
            (provider: econdb);
                The frequency of the data. Choices vary by indicator and country. Common options:
            'annual', 'quarter', 'month'. Use 'all' or '*' to return all available frequencies. Direct
            IMF codes (e.g., 'A', 'Q', 'M') are also accepted. (provider: imf)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        transform (None | str | Unset): The transformation to apply to the data, default is None.

                tpop: Change from previous period
                toya: Change from one year ago
                tusd: Values as US dollars
                tpgp: Values as a percent of GDP

                Only 'tpop' and 'toya' are applicable to all indicators. Applying transformations
            across multiple indicators/countries may produce unexpected results.
                This is because not all indicators are compatible with all transformations, and the
            original units and scale differ between entities.
                `tusd` should only be used where values are currencies. (provider: econdb);
                Transformation to apply to the data. User-friendly options: 'index' (raw values),
            'yoy' (year-over-year %), 'period' (period-over-period %). Use 'all' or '*' to return all
            available transformations. Direct IMF codes (e.g., 'USD', 'IX') are also accepted.
            (provider: imf)
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        dimension_values (list[str] | None | Unset): List of additional dimension filters in
            'DIM_ID:DIM_VALUE' format. Parameter can be entered multiple times. (provider: imf)
        limit (int | None | Unset): Maximum number of records to retrieve per series. (provider:
            imf)
        pivot (bool | Unset): If True, pivots the data to presentation view with 'indicator' and
            'country' as the index, date as values. (provider: imf) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
        transform=transform,
        use_cache=use_cache,
        dimension_values=dimension_values,
        limit=limit,
        pivot=pivot,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyIndicatorsProvider,
    symbol: None | str,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    transform: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    dimension_values: list[str] | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    pivot: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse | None:
    """Indicators

     Get economic indicators by country and indicator.

    Args:
        provider (EconomyIndicatorsProvider):
        symbol (None | str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): econdb, imf.;
                Symbol to get data for. The base symbol for the indicator (e.g. GDP, CPI, etc.). Use
            `available_indicators()` to get a list of available symbols. (provider: econdb);
                Symbol to get data for. Symbol format: 'dataflow::identifier' where identifier is
            either:
            - A table ID (starts with 'H_') for hierarchical table data
            - An indicator code for individual indicator data

            Examples:
                - 'BOP::H_BOP_BOP_AGG_STANDARD_PRESENTATION' - Balance of Payments table
                - 'BOP_AGG::GS_CD,BOP_AGG::GS_DB' - Multiple BOP_AGG indicators (Goods & Services)
                - 'IL::RGV_REVS' - Gold reserves in millions of fine troy ounces
                - 'WEO::NGDP_RPCH' - Real GDP growth (annual only)
                - 'WEO::POILBRE' - Brent crude oil price (use country='G001' for world)
                - 'PCPS::PGOLD' - Gold price per troy ounce (monthly/quarterly available)

            Use `obb.economy.available_indicators(provider='imf')` to discover symbols. Use
            `obb.economy.imf_utils.list_tables()` to see available tables. (provider: imf)
        country (None | str | Unset): The country to get data. Multiple comma separated items
            allowed for provider(s): econdb, imf.;
                The country to get data. ISO country codes or country names. (provider: econdb);
                ISO3 country code(s). Use comma-separated values for multiple countries. Validated
            against the dataflow's available countries via constraint API. (provider: imf)
        frequency (None | str | Unset): The frequency of the data.;
                The frequency of the data, default is 'quarter'. Only valid when 'symbol' is 'main'.
            (provider: econdb);
                The frequency of the data. Choices vary by indicator and country. Common options:
            'annual', 'quarter', 'month'. Use 'all' or '*' to return all available frequencies. Direct
            IMF codes (e.g., 'A', 'Q', 'M') are also accepted. (provider: imf)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        transform (None | str | Unset): The transformation to apply to the data, default is None.

                tpop: Change from previous period
                toya: Change from one year ago
                tusd: Values as US dollars
                tpgp: Values as a percent of GDP

                Only 'tpop' and 'toya' are applicable to all indicators. Applying transformations
            across multiple indicators/countries may produce unexpected results.
                This is because not all indicators are compatible with all transformations, and the
            original units and scale differ between entities.
                `tusd` should only be used where values are currencies. (provider: econdb);
                Transformation to apply to the data. User-friendly options: 'index' (raw values),
            'yoy' (year-over-year %), 'period' (period-over-period %). Use 'all' or '*' to return all
            available transformations. Direct IMF codes (e.g., 'USD', 'IX') are also accepted.
            (provider: imf)
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        dimension_values (list[str] | None | Unset): List of additional dimension filters in
            'DIM_ID:DIM_VALUE' format. Parameter can be entered multiple times. (provider: imf)
        limit (int | None | Unset): Maximum number of records to retrieve per series. (provider:
            imf)
        pivot (bool | Unset): If True, pivots the data to presentation view with 'indicator' and
            'country' as the index, date as values. (provider: imf) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
        transform=transform,
        use_cache=use_cache,
        dimension_values=dimension_values,
        limit=limit,
        pivot=pivot,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyIndicatorsProvider,
    symbol: None | str,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    transform: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    dimension_values: list[str] | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    pivot: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse]:
    """Indicators

     Get economic indicators by country and indicator.

    Args:
        provider (EconomyIndicatorsProvider):
        symbol (None | str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): econdb, imf.;
                Symbol to get data for. The base symbol for the indicator (e.g. GDP, CPI, etc.). Use
            `available_indicators()` to get a list of available symbols. (provider: econdb);
                Symbol to get data for. Symbol format: 'dataflow::identifier' where identifier is
            either:
            - A table ID (starts with 'H_') for hierarchical table data
            - An indicator code for individual indicator data

            Examples:
                - 'BOP::H_BOP_BOP_AGG_STANDARD_PRESENTATION' - Balance of Payments table
                - 'BOP_AGG::GS_CD,BOP_AGG::GS_DB' - Multiple BOP_AGG indicators (Goods & Services)
                - 'IL::RGV_REVS' - Gold reserves in millions of fine troy ounces
                - 'WEO::NGDP_RPCH' - Real GDP growth (annual only)
                - 'WEO::POILBRE' - Brent crude oil price (use country='G001' for world)
                - 'PCPS::PGOLD' - Gold price per troy ounce (monthly/quarterly available)

            Use `obb.economy.available_indicators(provider='imf')` to discover symbols. Use
            `obb.economy.imf_utils.list_tables()` to see available tables. (provider: imf)
        country (None | str | Unset): The country to get data. Multiple comma separated items
            allowed for provider(s): econdb, imf.;
                The country to get data. ISO country codes or country names. (provider: econdb);
                ISO3 country code(s). Use comma-separated values for multiple countries. Validated
            against the dataflow's available countries via constraint API. (provider: imf)
        frequency (None | str | Unset): The frequency of the data.;
                The frequency of the data, default is 'quarter'. Only valid when 'symbol' is 'main'.
            (provider: econdb);
                The frequency of the data. Choices vary by indicator and country. Common options:
            'annual', 'quarter', 'month'. Use 'all' or '*' to return all available frequencies. Direct
            IMF codes (e.g., 'A', 'Q', 'M') are also accepted. (provider: imf)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        transform (None | str | Unset): The transformation to apply to the data, default is None.

                tpop: Change from previous period
                toya: Change from one year ago
                tusd: Values as US dollars
                tpgp: Values as a percent of GDP

                Only 'tpop' and 'toya' are applicable to all indicators. Applying transformations
            across multiple indicators/countries may produce unexpected results.
                This is because not all indicators are compatible with all transformations, and the
            original units and scale differ between entities.
                `tusd` should only be used where values are currencies. (provider: econdb);
                Transformation to apply to the data. User-friendly options: 'index' (raw values),
            'yoy' (year-over-year %), 'period' (period-over-period %). Use 'all' or '*' to return all
            available transformations. Direct IMF codes (e.g., 'USD', 'IX') are also accepted.
            (provider: imf)
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        dimension_values (list[str] | None | Unset): List of additional dimension filters in
            'DIM_ID:DIM_VALUE' format. Parameter can be entered multiple times. (provider: imf)
        limit (int | None | Unset): Maximum number of records to retrieve per series. (provider:
            imf)
        pivot (bool | Unset): If True, pivots the data to presentation view with 'indicator' and
            'country' as the index, date as values. (provider: imf) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
        transform=transform,
        use_cache=use_cache,
        dimension_values=dimension_values,
        limit=limit,
        pivot=pivot,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EconomyIndicatorsProvider,
    symbol: None | str,
    country: None | str | Unset = UNSET,
    frequency: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    transform: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    dimension_values: list[str] | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    pivot: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse | None:
    """Indicators

     Get economic indicators by country and indicator.

    Args:
        provider (EconomyIndicatorsProvider):
        symbol (None | str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): econdb, imf.;
                Symbol to get data for. The base symbol for the indicator (e.g. GDP, CPI, etc.). Use
            `available_indicators()` to get a list of available symbols. (provider: econdb);
                Symbol to get data for. Symbol format: 'dataflow::identifier' where identifier is
            either:
            - A table ID (starts with 'H_') for hierarchical table data
            - An indicator code for individual indicator data

            Examples:
                - 'BOP::H_BOP_BOP_AGG_STANDARD_PRESENTATION' - Balance of Payments table
                - 'BOP_AGG::GS_CD,BOP_AGG::GS_DB' - Multiple BOP_AGG indicators (Goods & Services)
                - 'IL::RGV_REVS' - Gold reserves in millions of fine troy ounces
                - 'WEO::NGDP_RPCH' - Real GDP growth (annual only)
                - 'WEO::POILBRE' - Brent crude oil price (use country='G001' for world)
                - 'PCPS::PGOLD' - Gold price per troy ounce (monthly/quarterly available)

            Use `obb.economy.available_indicators(provider='imf')` to discover symbols. Use
            `obb.economy.imf_utils.list_tables()` to see available tables. (provider: imf)
        country (None | str | Unset): The country to get data. Multiple comma separated items
            allowed for provider(s): econdb, imf.;
                The country to get data. ISO country codes or country names. (provider: econdb);
                ISO3 country code(s). Use comma-separated values for multiple countries. Validated
            against the dataflow's available countries via constraint API. (provider: imf)
        frequency (None | str | Unset): The frequency of the data.;
                The frequency of the data, default is 'quarter'. Only valid when 'symbol' is 'main'.
            (provider: econdb);
                The frequency of the data. Choices vary by indicator and country. Common options:
            'annual', 'quarter', 'month'. Use 'all' or '*' to return all available frequencies. Direct
            IMF codes (e.g., 'A', 'Q', 'M') are also accepted. (provider: imf)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        transform (None | str | Unset): The transformation to apply to the data, default is None.

                tpop: Change from previous period
                toya: Change from one year ago
                tusd: Values as US dollars
                tpgp: Values as a percent of GDP

                Only 'tpop' and 'toya' are applicable to all indicators. Applying transformations
            across multiple indicators/countries may produce unexpected results.
                This is because not all indicators are compatible with all transformations, and the
            original units and scale differ between entities.
                `tusd` should only be used where values are currencies. (provider: econdb);
                Transformation to apply to the data. User-friendly options: 'index' (raw values),
            'yoy' (year-over-year %), 'period' (period-over-period %). Use 'all' or '*' to return all
            available transformations. Direct IMF codes (e.g., 'USD', 'IX') are also accepted.
            (provider: imf)
        use_cache (bool | Unset): If True, the request will be cached for one day. Using cache is
            recommended to avoid needlessly requesting the same data. (provider: econdb) Default:
            True.
        dimension_values (list[str] | None | Unset): List of additional dimension filters in
            'DIM_ID:DIM_VALUE' format. Parameter can be entered multiple times. (provider: imf)
        limit (int | None | Unset): Maximum number of records to retrieve per series. (provider:
            imf)
        pivot (bool | Unset): If True, pivots the data to presentation view with 'indicator' and
            'country' as the index, date as values. (provider: imf) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEconomicIndicators | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            country=country,
            frequency=frequency,
            start_date=start_date,
            end_date=end_date,
            transform=transform,
            use_cache=use_cache,
            dimension_values=dimension_values,
            limit=limit,
            pivot=pivot,
        )
    ).parsed
