import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_share_price_index import OBBjectSharePriceIndex
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["oecd"] | Unset = "oecd",
    country: str | Unset = "united_states",
    frequency: str | Unset = "monthly",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["country"] = country

    params["frequency"] = frequency

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/economy/share_price_index",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectSharePriceIndex.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    country: str | Unset = "united_states",
    frequency: str | Unset = "monthly",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse]:
    """Share Price Index

     Get the Share Price Index by country from the OECD Short-Term Economics Statistics.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        country (str | Unset): The country to get data. Multiple comma separated items allowed for
            provider(s): oecd. Default: 'united_states'.
        frequency (str | Unset): The frequency of the data. Default: 'monthly'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    country: str | Unset = "united_states",
    frequency: str | Unset = "monthly",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse | None:
    """Share Price Index

     Get the Share Price Index by country from the OECD Short-Term Economics Statistics.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        country (str | Unset): The country to get data. Multiple comma separated items allowed for
            provider(s): oecd. Default: 'united_states'.
        frequency (str | Unset): The frequency of the data. Default: 'monthly'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    country: str | Unset = "united_states",
    frequency: str | Unset = "monthly",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse]:
    """Share Price Index

     Get the Share Price Index by country from the OECD Short-Term Economics Statistics.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        country (str | Unset): The country to get data. Multiple comma separated items allowed for
            provider(s): oecd. Default: 'united_states'.
        frequency (str | Unset): The frequency of the data. Default: 'monthly'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        country=country,
        frequency=frequency,
        start_date=start_date,
        end_date=end_date,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["oecd"] | Unset = "oecd",
    country: str | Unset = "united_states",
    frequency: str | Unset = "monthly",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse | None:
    """Share Price Index

     Get the Share Price Index by country from the OECD Short-Term Economics Statistics.

    Args:
        provider (Literal['oecd'] | Unset):  Default: 'oecd'.
        country (str | Unset): The country to get data. Multiple comma separated items allowed for
            provider(s): oecd. Default: 'united_states'.
        frequency (str | Unset): The frequency of the data. Default: 'monthly'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectSharePriceIndex | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            country=country,
            frequency=frequency,
            start_date=start_date,
            end_date=end_date,
        )
    ).parsed
