import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_futures_historical import OBBjectFuturesHistorical
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["yfinance"] | Unset = "yfinance",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    expiration: None | str | Unset = UNSET,
    interval: str | Unset = "1d",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_expiration: None | str | Unset
    if isinstance(expiration, Unset):
        json_expiration = UNSET
    else:
        json_expiration = expiration
    params["expiration"] = json_expiration

    params["interval"] = interval

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/derivatives/futures/historical",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectFuturesHistorical.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["yfinance"] | Unset = "yfinance",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    expiration: None | str | Unset = UNSET,
    interval: str | Unset = "1d",
) -> Response[Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse]:
    """Historical

     Historical futures prices.

    Args:
        provider (Literal['yfinance'] | Unset):  Default: 'yfinance'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): yfinance.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        expiration (None | str | Unset): Future expiry date with format YYYY-MM
        interval (str | Unset): Time interval of the data to return. (provider: yfinance) Default:
            '1d'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        expiration=expiration,
        interval=interval,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["yfinance"] | Unset = "yfinance",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    expiration: None | str | Unset = UNSET,
    interval: str | Unset = "1d",
) -> Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse | None:
    """Historical

     Historical futures prices.

    Args:
        provider (Literal['yfinance'] | Unset):  Default: 'yfinance'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): yfinance.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        expiration (None | str | Unset): Future expiry date with format YYYY-MM
        interval (str | Unset): Time interval of the data to return. (provider: yfinance) Default:
            '1d'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        expiration=expiration,
        interval=interval,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["yfinance"] | Unset = "yfinance",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    expiration: None | str | Unset = UNSET,
    interval: str | Unset = "1d",
) -> Response[Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse]:
    """Historical

     Historical futures prices.

    Args:
        provider (Literal['yfinance'] | Unset):  Default: 'yfinance'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): yfinance.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        expiration (None | str | Unset): Future expiry date with format YYYY-MM
        interval (str | Unset): Time interval of the data to return. (provider: yfinance) Default:
            '1d'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        start_date=start_date,
        end_date=end_date,
        expiration=expiration,
        interval=interval,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["yfinance"] | Unset = "yfinance",
    symbol: str,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    expiration: None | str | Unset = UNSET,
    interval: str | Unset = "1d",
) -> Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse | None:
    """Historical

     Historical futures prices.

    Args:
        provider (Literal['yfinance'] | Unset):  Default: 'yfinance'.
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): yfinance.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        expiration (None | str | Unset): Future expiry date with format YYYY-MM
        interval (str | Unset): Time interval of the data to return. (provider: yfinance) Default:
            '1d'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFuturesHistorical | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            start_date=start_date,
            end_date=end_date,
            expiration=expiration,
            interval=interval,
        )
    ).parsed
