import datetime
from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.akshare_router_etf_holdings_provider import AkshareRouterEtfHoldingsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_etf_holdings import OBBjectEtfHoldings
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: AkshareRouterEtfHoldingsProvider,
    symbol: str,
    year: None | str | Unset = "2024",
    quarter: None | str | Unset = "4",
    use_cache: bool | None | Unset = True,
    date: datetime.date | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_year: None | str | Unset
    if isinstance(year, Unset):
        json_year = UNSET
    else:
        json_year = year
    params["year"] = json_year

    json_quarter: None | str | Unset
    if isinstance(quarter, Unset):
        json_quarter = UNSET
    else:
        json_quarter = quarter
    params["quarter"] = json_quarter

    json_use_cache: bool | None | Unset
    if isinstance(use_cache, Unset):
        json_use_cache = UNSET
    else:
        json_use_cache = use_cache
    params["use_cache"] = json_use_cache

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/akshare/etf_holdings",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEtfHoldings.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: AkshareRouterEtfHoldingsProvider,
    symbol: str,
    year: None | str | Unset = "2024",
    quarter: None | str | Unset = "4",
    use_cache: bool | None | Unset = True,
    date: datetime.date | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse]:
    """Etf Holdings

     Get ETF holdings data.

    Args:
        provider (AkshareRouterEtfHoldingsProvider):
        symbol (str): Symbol to get data for. (ETF)
        year (None | str | Unset):  Entering a year will attempt to return the NPORT-P filing for
            the entered year. For Provider Akshare, only the year of date functions. Use the
            holdings_date command/endpoint to find available filing year for the ETF. (provider:
            akshare) Default: '2024'.
        quarter (None | str | Unset): Enter the quarter for which you want to retrieve the ETF
            holdings data. (provider: akshare) Default: '4'.
        use_cache (bool | None | Unset): Whether or not to use cache. If True, cache will store
            for two days. (provider: akshare) Default: True.
        date (datetime.date | None | Unset): A specific date to get data for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        year=year,
        quarter=quarter,
        use_cache=use_cache,
        date=date,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: AkshareRouterEtfHoldingsProvider,
    symbol: str,
    year: None | str | Unset = "2024",
    quarter: None | str | Unset = "4",
    use_cache: bool | None | Unset = True,
    date: datetime.date | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse | None:
    """Etf Holdings

     Get ETF holdings data.

    Args:
        provider (AkshareRouterEtfHoldingsProvider):
        symbol (str): Symbol to get data for. (ETF)
        year (None | str | Unset):  Entering a year will attempt to return the NPORT-P filing for
            the entered year. For Provider Akshare, only the year of date functions. Use the
            holdings_date command/endpoint to find available filing year for the ETF. (provider:
            akshare) Default: '2024'.
        quarter (None | str | Unset): Enter the quarter for which you want to retrieve the ETF
            holdings data. (provider: akshare) Default: '4'.
        use_cache (bool | None | Unset): Whether or not to use cache. If True, cache will store
            for two days. (provider: akshare) Default: True.
        date (datetime.date | None | Unset): A specific date to get data for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        year=year,
        quarter=quarter,
        use_cache=use_cache,
        date=date,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: AkshareRouterEtfHoldingsProvider,
    symbol: str,
    year: None | str | Unset = "2024",
    quarter: None | str | Unset = "4",
    use_cache: bool | None | Unset = True,
    date: datetime.date | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse]:
    """Etf Holdings

     Get ETF holdings data.

    Args:
        provider (AkshareRouterEtfHoldingsProvider):
        symbol (str): Symbol to get data for. (ETF)
        year (None | str | Unset):  Entering a year will attempt to return the NPORT-P filing for
            the entered year. For Provider Akshare, only the year of date functions. Use the
            holdings_date command/endpoint to find available filing year for the ETF. (provider:
            akshare) Default: '2024'.
        quarter (None | str | Unset): Enter the quarter for which you want to retrieve the ETF
            holdings data. (provider: akshare) Default: '4'.
        use_cache (bool | None | Unset): Whether or not to use cache. If True, cache will store
            for two days. (provider: akshare) Default: True.
        date (datetime.date | None | Unset): A specific date to get data for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        year=year,
        quarter=quarter,
        use_cache=use_cache,
        date=date,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: AkshareRouterEtfHoldingsProvider,
    symbol: str,
    year: None | str | Unset = "2024",
    quarter: None | str | Unset = "4",
    use_cache: bool | None | Unset = True,
    date: datetime.date | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse | None:
    """Etf Holdings

     Get ETF holdings data.

    Args:
        provider (AkshareRouterEtfHoldingsProvider):
        symbol (str): Symbol to get data for. (ETF)
        year (None | str | Unset):  Entering a year will attempt to return the NPORT-P filing for
            the entered year. For Provider Akshare, only the year of date functions. Use the
            holdings_date command/endpoint to find available filing year for the ETF. (provider:
            akshare) Default: '2024'.
        quarter (None | str | Unset): Enter the quarter for which you want to retrieve the ETF
            holdings data. (provider: akshare) Default: '4'.
        use_cache (bool | None | Unset): Whether or not to use cache. If True, cache will store
            for two days. (provider: akshare) Default: True.
        date (datetime.date | None | Unset): A specific date to get data for. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEtfHoldings | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            year=year,
            quarter=quarter,
            use_cache=use_cache,
            date=date,
        )
    ).parsed
