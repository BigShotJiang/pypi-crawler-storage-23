from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.akshare_router_post_example_data import AkshareRouterPostExampleData
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bjectdict import OBBjectdict
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: AkshareRouterPostExampleData,
    bid_col: str | Unset = "bid",
    ask_col: str | Unset = "ask",
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["bid_col"] = bid_col

    params["ask_col"] = ask_col

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/api/v1/akshare/post_example",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectdict.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AkshareRouterPostExampleData,
    bid_col: str | Unset = "bid",
    ask_col: str | Unset = "ask",
) -> Response[Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse]:
    """Post Example

     Calculate mid and spread.

    Args:
        bid_col (str | Unset):  Default: 'bid'.
        ask_col (str | Unset):  Default: 'ask'.
        body (AkshareRouterPostExampleData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        bid_col=bid_col,
        ask_col=ask_col,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: AkshareRouterPostExampleData,
    bid_col: str | Unset = "bid",
    ask_col: str | Unset = "ask",
) -> Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse | None:
    """Post Example

     Calculate mid and spread.

    Args:
        bid_col (str | Unset):  Default: 'bid'.
        ask_col (str | Unset):  Default: 'ask'.
        body (AkshareRouterPostExampleData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        body=body,
        bid_col=bid_col,
        ask_col=ask_col,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: AkshareRouterPostExampleData,
    bid_col: str | Unset = "bid",
    ask_col: str | Unset = "ask",
) -> Response[Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse]:
    """Post Example

     Calculate mid and spread.

    Args:
        bid_col (str | Unset):  Default: 'bid'.
        ask_col (str | Unset):  Default: 'ask'.
        body (AkshareRouterPostExampleData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        body=body,
        bid_col=bid_col,
        ask_col=ask_col,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: AkshareRouterPostExampleData,
    bid_col: str | Unset = "bid",
    ask_col: str | Unset = "ask",
) -> Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse | None:
    """Post Example

     Calculate mid and spread.

    Args:
        bid_col (str | Unset):  Default: 'bid'.
        ask_col (str | Unset):  Default: 'ask'.
        body (AkshareRouterPostExampleData):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectdict | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            bid_col=bid_col,
            ask_col=ask_col,
        )
    ).parsed
