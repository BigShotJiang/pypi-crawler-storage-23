from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_screener_country_type_0 import EquityScreenerCountryType0
from ...models.equity_screener_exchange_type_1 import EquityScreenerExchangeType1
from ...models.equity_screener_exchange_type_2 import EquityScreenerExchangeType2
from ...models.equity_screener_provider import EquityScreenerProvider
from ...models.equity_screener_sector_type_1 import EquityScreenerSectorType1
from ...models.equity_screener_sector_type_2 import EquityScreenerSectorType2
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_equity_screener import OBBjectEquityScreener
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityScreenerProvider,
    sector: EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset = UNSET,
    exchange: EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 1000,
    mktcap_min: int | None | Unset = UNSET,
    mktcap_max: int | None | Unset = UNSET,
    price_min: float | None | Unset = UNSET,
    price_max: float | None | Unset = UNSET,
    beta_min: float | None | Unset = UNSET,
    beta_max: float | None | Unset = UNSET,
    volume_min: int | None | Unset = UNSET,
    volume_max: int | None | Unset = UNSET,
    dividend_min: float | None | Unset = UNSET,
    dividend_max: float | None | Unset = UNSET,
    industry: None | str | Unset = UNSET,
    country: EquityScreenerCountryType0 | None | str | Unset = UNSET,
    is_etf: bool | None | Unset = UNSET,
    is_active: bool | None | Unset = UNSET,
    is_fund: bool | None | Unset = UNSET,
    all_share_classes: bool | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_sector: None | str | Unset
    if isinstance(sector, Unset):
        json_sector = UNSET
    elif isinstance(sector, EquityScreenerSectorType1):
        json_sector = sector.value
    elif isinstance(sector, EquityScreenerSectorType2):
        json_sector = sector.value
    else:
        json_sector = sector
    params["sector"] = json_sector

    json_exchange: None | str | Unset
    if isinstance(exchange, Unset):
        json_exchange = UNSET
    elif isinstance(exchange, EquityScreenerExchangeType1):
        json_exchange = exchange.value
    elif isinstance(exchange, EquityScreenerExchangeType2):
        json_exchange = exchange.value
    else:
        json_exchange = exchange
    params["exchange"] = json_exchange

    params["use_cache"] = use_cache

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_mktcap_min: int | None | Unset
    if isinstance(mktcap_min, Unset):
        json_mktcap_min = UNSET
    else:
        json_mktcap_min = mktcap_min
    params["mktcap_min"] = json_mktcap_min

    json_mktcap_max: int | None | Unset
    if isinstance(mktcap_max, Unset):
        json_mktcap_max = UNSET
    else:
        json_mktcap_max = mktcap_max
    params["mktcap_max"] = json_mktcap_max

    json_price_min: float | None | Unset
    if isinstance(price_min, Unset):
        json_price_min = UNSET
    else:
        json_price_min = price_min
    params["price_min"] = json_price_min

    json_price_max: float | None | Unset
    if isinstance(price_max, Unset):
        json_price_max = UNSET
    else:
        json_price_max = price_max
    params["price_max"] = json_price_max

    json_beta_min: float | None | Unset
    if isinstance(beta_min, Unset):
        json_beta_min = UNSET
    else:
        json_beta_min = beta_min
    params["beta_min"] = json_beta_min

    json_beta_max: float | None | Unset
    if isinstance(beta_max, Unset):
        json_beta_max = UNSET
    else:
        json_beta_max = beta_max
    params["beta_max"] = json_beta_max

    json_volume_min: int | None | Unset
    if isinstance(volume_min, Unset):
        json_volume_min = UNSET
    else:
        json_volume_min = volume_min
    params["volume_min"] = json_volume_min

    json_volume_max: int | None | Unset
    if isinstance(volume_max, Unset):
        json_volume_max = UNSET
    else:
        json_volume_max = volume_max
    params["volume_max"] = json_volume_max

    json_dividend_min: float | None | Unset
    if isinstance(dividend_min, Unset):
        json_dividend_min = UNSET
    else:
        json_dividend_min = dividend_min
    params["dividend_min"] = json_dividend_min

    json_dividend_max: float | None | Unset
    if isinstance(dividend_max, Unset):
        json_dividend_max = UNSET
    else:
        json_dividend_max = dividend_max
    params["dividend_max"] = json_dividend_max

    json_industry: None | str | Unset
    if isinstance(industry, Unset):
        json_industry = UNSET
    else:
        json_industry = industry
    params["industry"] = json_industry

    json_country: None | str | Unset
    if isinstance(country, Unset):
        json_country = UNSET
    elif isinstance(country, EquityScreenerCountryType0):
        json_country = country.value
    else:
        json_country = country
    params["country"] = json_country

    json_is_etf: bool | None | Unset
    if isinstance(is_etf, Unset):
        json_is_etf = UNSET
    else:
        json_is_etf = is_etf
    params["is_etf"] = json_is_etf

    json_is_active: bool | None | Unset
    if isinstance(is_active, Unset):
        json_is_active = UNSET
    else:
        json_is_active = is_active
    params["is_active"] = json_is_active

    json_is_fund: bool | None | Unset
    if isinstance(is_fund, Unset):
        json_is_fund = UNSET
    else:
        json_is_fund = is_fund
    params["is_fund"] = json_is_fund

    json_all_share_classes: bool | None | Unset
    if isinstance(all_share_classes, Unset):
        json_all_share_classes = UNSET
    else:
        json_all_share_classes = all_share_classes
    params["all_share_classes"] = json_all_share_classes

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/screener",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEquityScreener.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityScreenerProvider,
    sector: EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset = UNSET,
    exchange: EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 1000,
    mktcap_min: int | None | Unset = UNSET,
    mktcap_max: int | None | Unset = UNSET,
    price_min: float | None | Unset = UNSET,
    price_max: float | None | Unset = UNSET,
    beta_min: float | None | Unset = UNSET,
    beta_max: float | None | Unset = UNSET,
    volume_min: int | None | Unset = UNSET,
    volume_max: int | None | Unset = UNSET,
    dividend_min: float | None | Unset = UNSET,
    dividend_max: float | None | Unset = UNSET,
    industry: None | str | Unset = UNSET,
    country: EquityScreenerCountryType0 | None | str | Unset = UNSET,
    is_etf: bool | None | Unset = UNSET,
    is_active: bool | None | Unset = UNSET,
    is_fund: bool | None | Unset = UNSET,
    all_share_classes: bool | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse]:
    """Screener

     Screen for companies meeting various criteria.

    These criteria include market cap, price, beta, volume, and dividend yield.

    Args:
        provider (EquityScreenerProvider):
        sector (EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset):
            Filter by sector. (provider: akshare,fmp, yfinance)
        exchange (EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset):
            Filter by exchange. (provider: akshare,fmp, yfinance)
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        limit (int | None | Unset): Limit the number of results to return. (provider: akshare,
            fmp);
                Limit the number of results returned. Default is, 200. Set to, 0, for all results.
            (provider: yfinance) Default: 1000.
        mktcap_min (int | None | Unset): Filter by market cap greater than this value. (provider:
            fmp, yfinance)
        mktcap_max (int | None | Unset): Filter by market cap less than this value. (provider:
            fmp, yfinance)
        price_min (float | None | Unset): Filter by price greater than this value. (provider: fmp,
            yfinance)
        price_max (float | None | Unset): Filter by price less than this value. (provider: fmp,
            yfinance)
        beta_min (float | None | Unset): Filter by a beta greater than this value. (provider: fmp,
            yfinance)
        beta_max (float | None | Unset): Filter by a beta less than this value. (provider: fmp,
            yfinance)
        volume_min (int | None | Unset): Filter by volume greater than this value. (provider: fmp,
            yfinance)
        volume_max (int | None | Unset): Filter by volume less than this value. (provider: fmp,
            yfinance)
        dividend_min (float | None | Unset): Filter by dividend amount greater than this value.
            (provider: fmp)
        dividend_max (float | None | Unset): Filter by dividend amount less than this value.
            (provider: fmp)
        industry (None | str | Unset): Filter by industry. (provider: fmp, yfinance)
        country (EquityScreenerCountryType0 | None | str | Unset): Filter by country, as a two-
            letter country code. (provider: fmp);
                Filter by country, as a two-letter country code. Default is, 'us'. Use, 'all', for all
            countries. (provider: yfinance)
        is_etf (bool | None | Unset): If true, includes ETFs. (provider: fmp)
        is_active (bool | None | Unset): If false, returns only inactive tickers. (provider: fmp)
        is_fund (bool | None | Unset): If true, includes funds. (provider: fmp)
        all_share_classes (bool | None | Unset): If true, includes all share classes of a equity.
            (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        sector=sector,
        exchange=exchange,
        use_cache=use_cache,
        limit=limit,
        mktcap_min=mktcap_min,
        mktcap_max=mktcap_max,
        price_min=price_min,
        price_max=price_max,
        beta_min=beta_min,
        beta_max=beta_max,
        volume_min=volume_min,
        volume_max=volume_max,
        dividend_min=dividend_min,
        dividend_max=dividend_max,
        industry=industry,
        country=country,
        is_etf=is_etf,
        is_active=is_active,
        is_fund=is_fund,
        all_share_classes=all_share_classes,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityScreenerProvider,
    sector: EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset = UNSET,
    exchange: EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 1000,
    mktcap_min: int | None | Unset = UNSET,
    mktcap_max: int | None | Unset = UNSET,
    price_min: float | None | Unset = UNSET,
    price_max: float | None | Unset = UNSET,
    beta_min: float | None | Unset = UNSET,
    beta_max: float | None | Unset = UNSET,
    volume_min: int | None | Unset = UNSET,
    volume_max: int | None | Unset = UNSET,
    dividend_min: float | None | Unset = UNSET,
    dividend_max: float | None | Unset = UNSET,
    industry: None | str | Unset = UNSET,
    country: EquityScreenerCountryType0 | None | str | Unset = UNSET,
    is_etf: bool | None | Unset = UNSET,
    is_active: bool | None | Unset = UNSET,
    is_fund: bool | None | Unset = UNSET,
    all_share_classes: bool | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse | None:
    """Screener

     Screen for companies meeting various criteria.

    These criteria include market cap, price, beta, volume, and dividend yield.

    Args:
        provider (EquityScreenerProvider):
        sector (EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset):
            Filter by sector. (provider: akshare,fmp, yfinance)
        exchange (EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset):
            Filter by exchange. (provider: akshare,fmp, yfinance)
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        limit (int | None | Unset): Limit the number of results to return. (provider: akshare,
            fmp);
                Limit the number of results returned. Default is, 200. Set to, 0, for all results.
            (provider: yfinance) Default: 1000.
        mktcap_min (int | None | Unset): Filter by market cap greater than this value. (provider:
            fmp, yfinance)
        mktcap_max (int | None | Unset): Filter by market cap less than this value. (provider:
            fmp, yfinance)
        price_min (float | None | Unset): Filter by price greater than this value. (provider: fmp,
            yfinance)
        price_max (float | None | Unset): Filter by price less than this value. (provider: fmp,
            yfinance)
        beta_min (float | None | Unset): Filter by a beta greater than this value. (provider: fmp,
            yfinance)
        beta_max (float | None | Unset): Filter by a beta less than this value. (provider: fmp,
            yfinance)
        volume_min (int | None | Unset): Filter by volume greater than this value. (provider: fmp,
            yfinance)
        volume_max (int | None | Unset): Filter by volume less than this value. (provider: fmp,
            yfinance)
        dividend_min (float | None | Unset): Filter by dividend amount greater than this value.
            (provider: fmp)
        dividend_max (float | None | Unset): Filter by dividend amount less than this value.
            (provider: fmp)
        industry (None | str | Unset): Filter by industry. (provider: fmp, yfinance)
        country (EquityScreenerCountryType0 | None | str | Unset): Filter by country, as a two-
            letter country code. (provider: fmp);
                Filter by country, as a two-letter country code. Default is, 'us'. Use, 'all', for all
            countries. (provider: yfinance)
        is_etf (bool | None | Unset): If true, includes ETFs. (provider: fmp)
        is_active (bool | None | Unset): If false, returns only inactive tickers. (provider: fmp)
        is_fund (bool | None | Unset): If true, includes funds. (provider: fmp)
        all_share_classes (bool | None | Unset): If true, includes all share classes of a equity.
            (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        sector=sector,
        exchange=exchange,
        use_cache=use_cache,
        limit=limit,
        mktcap_min=mktcap_min,
        mktcap_max=mktcap_max,
        price_min=price_min,
        price_max=price_max,
        beta_min=beta_min,
        beta_max=beta_max,
        volume_min=volume_min,
        volume_max=volume_max,
        dividend_min=dividend_min,
        dividend_max=dividend_max,
        industry=industry,
        country=country,
        is_etf=is_etf,
        is_active=is_active,
        is_fund=is_fund,
        all_share_classes=all_share_classes,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityScreenerProvider,
    sector: EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset = UNSET,
    exchange: EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 1000,
    mktcap_min: int | None | Unset = UNSET,
    mktcap_max: int | None | Unset = UNSET,
    price_min: float | None | Unset = UNSET,
    price_max: float | None | Unset = UNSET,
    beta_min: float | None | Unset = UNSET,
    beta_max: float | None | Unset = UNSET,
    volume_min: int | None | Unset = UNSET,
    volume_max: int | None | Unset = UNSET,
    dividend_min: float | None | Unset = UNSET,
    dividend_max: float | None | Unset = UNSET,
    industry: None | str | Unset = UNSET,
    country: EquityScreenerCountryType0 | None | str | Unset = UNSET,
    is_etf: bool | None | Unset = UNSET,
    is_active: bool | None | Unset = UNSET,
    is_fund: bool | None | Unset = UNSET,
    all_share_classes: bool | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse]:
    """Screener

     Screen for companies meeting various criteria.

    These criteria include market cap, price, beta, volume, and dividend yield.

    Args:
        provider (EquityScreenerProvider):
        sector (EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset):
            Filter by sector. (provider: akshare,fmp, yfinance)
        exchange (EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset):
            Filter by exchange. (provider: akshare,fmp, yfinance)
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        limit (int | None | Unset): Limit the number of results to return. (provider: akshare,
            fmp);
                Limit the number of results returned. Default is, 200. Set to, 0, for all results.
            (provider: yfinance) Default: 1000.
        mktcap_min (int | None | Unset): Filter by market cap greater than this value. (provider:
            fmp, yfinance)
        mktcap_max (int | None | Unset): Filter by market cap less than this value. (provider:
            fmp, yfinance)
        price_min (float | None | Unset): Filter by price greater than this value. (provider: fmp,
            yfinance)
        price_max (float | None | Unset): Filter by price less than this value. (provider: fmp,
            yfinance)
        beta_min (float | None | Unset): Filter by a beta greater than this value. (provider: fmp,
            yfinance)
        beta_max (float | None | Unset): Filter by a beta less than this value. (provider: fmp,
            yfinance)
        volume_min (int | None | Unset): Filter by volume greater than this value. (provider: fmp,
            yfinance)
        volume_max (int | None | Unset): Filter by volume less than this value. (provider: fmp,
            yfinance)
        dividend_min (float | None | Unset): Filter by dividend amount greater than this value.
            (provider: fmp)
        dividend_max (float | None | Unset): Filter by dividend amount less than this value.
            (provider: fmp)
        industry (None | str | Unset): Filter by industry. (provider: fmp, yfinance)
        country (EquityScreenerCountryType0 | None | str | Unset): Filter by country, as a two-
            letter country code. (provider: fmp);
                Filter by country, as a two-letter country code. Default is, 'us'. Use, 'all', for all
            countries. (provider: yfinance)
        is_etf (bool | None | Unset): If true, includes ETFs. (provider: fmp)
        is_active (bool | None | Unset): If false, returns only inactive tickers. (provider: fmp)
        is_fund (bool | None | Unset): If true, includes funds. (provider: fmp)
        all_share_classes (bool | None | Unset): If true, includes all share classes of a equity.
            (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        sector=sector,
        exchange=exchange,
        use_cache=use_cache,
        limit=limit,
        mktcap_min=mktcap_min,
        mktcap_max=mktcap_max,
        price_min=price_min,
        price_max=price_max,
        beta_min=beta_min,
        beta_max=beta_max,
        volume_min=volume_min,
        volume_max=volume_max,
        dividend_min=dividend_min,
        dividend_max=dividend_max,
        industry=industry,
        country=country,
        is_etf=is_etf,
        is_active=is_active,
        is_fund=is_fund,
        all_share_classes=all_share_classes,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityScreenerProvider,
    sector: EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset = UNSET,
    exchange: EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 1000,
    mktcap_min: int | None | Unset = UNSET,
    mktcap_max: int | None | Unset = UNSET,
    price_min: float | None | Unset = UNSET,
    price_max: float | None | Unset = UNSET,
    beta_min: float | None | Unset = UNSET,
    beta_max: float | None | Unset = UNSET,
    volume_min: int | None | Unset = UNSET,
    volume_max: int | None | Unset = UNSET,
    dividend_min: float | None | Unset = UNSET,
    dividend_max: float | None | Unset = UNSET,
    industry: None | str | Unset = UNSET,
    country: EquityScreenerCountryType0 | None | str | Unset = UNSET,
    is_etf: bool | None | Unset = UNSET,
    is_active: bool | None | Unset = UNSET,
    is_fund: bool | None | Unset = UNSET,
    all_share_classes: bool | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse | None:
    """Screener

     Screen for companies meeting various criteria.

    These criteria include market cap, price, beta, volume, and dividend yield.

    Args:
        provider (EquityScreenerProvider):
        sector (EquityScreenerSectorType1 | EquityScreenerSectorType2 | None | str | Unset):
            Filter by sector. (provider: akshare,fmp, yfinance)
        exchange (EquityScreenerExchangeType1 | EquityScreenerExchangeType2 | None | str | Unset):
            Filter by exchange. (provider: akshare,fmp, yfinance)
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        limit (int | None | Unset): Limit the number of results to return. (provider: akshare,
            fmp);
                Limit the number of results returned. Default is, 200. Set to, 0, for all results.
            (provider: yfinance) Default: 1000.
        mktcap_min (int | None | Unset): Filter by market cap greater than this value. (provider:
            fmp, yfinance)
        mktcap_max (int | None | Unset): Filter by market cap less than this value. (provider:
            fmp, yfinance)
        price_min (float | None | Unset): Filter by price greater than this value. (provider: fmp,
            yfinance)
        price_max (float | None | Unset): Filter by price less than this value. (provider: fmp,
            yfinance)
        beta_min (float | None | Unset): Filter by a beta greater than this value. (provider: fmp,
            yfinance)
        beta_max (float | None | Unset): Filter by a beta less than this value. (provider: fmp,
            yfinance)
        volume_min (int | None | Unset): Filter by volume greater than this value. (provider: fmp,
            yfinance)
        volume_max (int | None | Unset): Filter by volume less than this value. (provider: fmp,
            yfinance)
        dividend_min (float | None | Unset): Filter by dividend amount greater than this value.
            (provider: fmp)
        dividend_max (float | None | Unset): Filter by dividend amount less than this value.
            (provider: fmp)
        industry (None | str | Unset): Filter by industry. (provider: fmp, yfinance)
        country (EquityScreenerCountryType0 | None | str | Unset): Filter by country, as a two-
            letter country code. (provider: fmp);
                Filter by country, as a two-letter country code. Default is, 'us'. Use, 'all', for all
            countries. (provider: yfinance)
        is_etf (bool | None | Unset): If true, includes ETFs. (provider: fmp)
        is_active (bool | None | Unset): If false, returns only inactive tickers. (provider: fmp)
        is_fund (bool | None | Unset): If true, includes funds. (provider: fmp)
        all_share_classes (bool | None | Unset): If true, includes all share classes of a equity.
            (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityScreener | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            sector=sector,
            exchange=exchange,
            use_cache=use_cache,
            limit=limit,
            mktcap_min=mktcap_min,
            mktcap_max=mktcap_max,
            price_min=price_min,
            price_max=price_max,
            beta_min=beta_min,
            beta_max=beta_max,
            volume_min=volume_min,
            volume_max=volume_max,
            dividend_min=dividend_min,
            dividend_max=dividend_max,
            industry=industry,
            country=country,
            is_etf=is_etf,
            is_active=is_active,
            is_fund=is_fund,
            all_share_classes=all_share_classes,
        )
    ).parsed
