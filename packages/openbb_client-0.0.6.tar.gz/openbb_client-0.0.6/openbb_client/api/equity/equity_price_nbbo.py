import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_equity_nbbo import OBBjectEquityNBBO
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["polygon"] | Unset = "polygon",
    symbol: str,
    limit: int | Unset = 50000,
    date: datetime.date | None | Unset = UNSET,
    timestamp_lt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_lte: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gte: datetime.datetime | None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    params["limit"] = limit

    json_date: None | str | Unset
    if isinstance(date, Unset):
        json_date = UNSET
    elif isinstance(date, datetime.date):
        json_date = date.isoformat()
    else:
        json_date = date
    params["date"] = json_date

    json_timestamp_lt: None | str | Unset
    if isinstance(timestamp_lt, Unset):
        json_timestamp_lt = UNSET
    elif isinstance(timestamp_lt, datetime.datetime):
        json_timestamp_lt = timestamp_lt.isoformat()
    else:
        json_timestamp_lt = timestamp_lt
    params["timestamp_lt"] = json_timestamp_lt

    json_timestamp_gt: None | str | Unset
    if isinstance(timestamp_gt, Unset):
        json_timestamp_gt = UNSET
    elif isinstance(timestamp_gt, datetime.datetime):
        json_timestamp_gt = timestamp_gt.isoformat()
    else:
        json_timestamp_gt = timestamp_gt
    params["timestamp_gt"] = json_timestamp_gt

    json_timestamp_lte: None | str | Unset
    if isinstance(timestamp_lte, Unset):
        json_timestamp_lte = UNSET
    elif isinstance(timestamp_lte, datetime.datetime):
        json_timestamp_lte = timestamp_lte.isoformat()
    else:
        json_timestamp_lte = timestamp_lte
    params["timestamp_lte"] = json_timestamp_lte

    json_timestamp_gte: None | str | Unset
    if isinstance(timestamp_gte, Unset):
        json_timestamp_gte = UNSET
    elif isinstance(timestamp_gte, datetime.datetime):
        json_timestamp_gte = timestamp_gte.isoformat()
    else:
        json_timestamp_gte = timestamp_gte
    params["timestamp_gte"] = json_timestamp_gte

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/price/nbbo",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEquityNBBO.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["polygon"] | Unset = "polygon",
    symbol: str,
    limit: int | Unset = 50000,
    date: datetime.date | None | Unset = UNSET,
    timestamp_lt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_lte: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gte: datetime.datetime | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse]:
    """Nbbo

     Get the National Best Bid and Offer for a given stock.

    Args:
        provider (Literal['polygon'] | Unset):  Default: 'polygon'.
        symbol (str): Symbol to get data for.
        limit (int | Unset): The number of data entries to return. Up to ten million records will
            be returned. Pagination occurs in groups of 50,000. Remaining limit values will always
            return 50,000 more records unless it is the last page. High volume tickers will require
            multiple max requests for a single day's NBBO records. Expect stocks, like SPY, to
            approach 1GB in size, per day, as a raw CSV. Splitting large requests into chunks is
            recommended for full-day requests of high-volume symbols. (provider: polygon) Default:
            50000.
        date (datetime.date | None | Unset): A specific date to get data for. Use bracketed the
            timestamp parameters to specify exact time ranges. (provider: polygon)
        timestamp_lt (datetime.datetime | None | str | Unset): Query by datetime, less than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_gt (datetime.datetime | None | str | Unset): Query by datetime, greater than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_lte (datetime.datetime | None | str | Unset): Query by datetime, less than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)
        timestamp_gte (datetime.datetime | None | str | Unset): Query by datetime, greater than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        date=date,
        timestamp_lt=timestamp_lt,
        timestamp_gt=timestamp_gt,
        timestamp_lte=timestamp_lte,
        timestamp_gte=timestamp_gte,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["polygon"] | Unset = "polygon",
    symbol: str,
    limit: int | Unset = 50000,
    date: datetime.date | None | Unset = UNSET,
    timestamp_lt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_lte: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gte: datetime.datetime | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse | None:
    """Nbbo

     Get the National Best Bid and Offer for a given stock.

    Args:
        provider (Literal['polygon'] | Unset):  Default: 'polygon'.
        symbol (str): Symbol to get data for.
        limit (int | Unset): The number of data entries to return. Up to ten million records will
            be returned. Pagination occurs in groups of 50,000. Remaining limit values will always
            return 50,000 more records unless it is the last page. High volume tickers will require
            multiple max requests for a single day's NBBO records. Expect stocks, like SPY, to
            approach 1GB in size, per day, as a raw CSV. Splitting large requests into chunks is
            recommended for full-day requests of high-volume symbols. (provider: polygon) Default:
            50000.
        date (datetime.date | None | Unset): A specific date to get data for. Use bracketed the
            timestamp parameters to specify exact time ranges. (provider: polygon)
        timestamp_lt (datetime.datetime | None | str | Unset): Query by datetime, less than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_gt (datetime.datetime | None | str | Unset): Query by datetime, greater than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_lte (datetime.datetime | None | str | Unset): Query by datetime, less than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)
        timestamp_gte (datetime.datetime | None | str | Unset): Query by datetime, greater than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        limit=limit,
        date=date,
        timestamp_lt=timestamp_lt,
        timestamp_gt=timestamp_gt,
        timestamp_lte=timestamp_lte,
        timestamp_gte=timestamp_gte,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["polygon"] | Unset = "polygon",
    symbol: str,
    limit: int | Unset = 50000,
    date: datetime.date | None | Unset = UNSET,
    timestamp_lt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_lte: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gte: datetime.datetime | None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse]:
    """Nbbo

     Get the National Best Bid and Offer for a given stock.

    Args:
        provider (Literal['polygon'] | Unset):  Default: 'polygon'.
        symbol (str): Symbol to get data for.
        limit (int | Unset): The number of data entries to return. Up to ten million records will
            be returned. Pagination occurs in groups of 50,000. Remaining limit values will always
            return 50,000 more records unless it is the last page. High volume tickers will require
            multiple max requests for a single day's NBBO records. Expect stocks, like SPY, to
            approach 1GB in size, per day, as a raw CSV. Splitting large requests into chunks is
            recommended for full-day requests of high-volume symbols. (provider: polygon) Default:
            50000.
        date (datetime.date | None | Unset): A specific date to get data for. Use bracketed the
            timestamp parameters to specify exact time ranges. (provider: polygon)
        timestamp_lt (datetime.datetime | None | str | Unset): Query by datetime, less than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_gt (datetime.datetime | None | str | Unset): Query by datetime, greater than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_lte (datetime.datetime | None | str | Unset): Query by datetime, less than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)
        timestamp_gte (datetime.datetime | None | str | Unset): Query by datetime, greater than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        date=date,
        timestamp_lt=timestamp_lt,
        timestamp_gt=timestamp_gt,
        timestamp_lte=timestamp_lte,
        timestamp_gte=timestamp_gte,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["polygon"] | Unset = "polygon",
    symbol: str,
    limit: int | Unset = 50000,
    date: datetime.date | None | Unset = UNSET,
    timestamp_lt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gt: datetime.datetime | None | str | Unset = UNSET,
    timestamp_lte: datetime.datetime | None | str | Unset = UNSET,
    timestamp_gte: datetime.datetime | None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse | None:
    """Nbbo

     Get the National Best Bid and Offer for a given stock.

    Args:
        provider (Literal['polygon'] | Unset):  Default: 'polygon'.
        symbol (str): Symbol to get data for.
        limit (int | Unset): The number of data entries to return. Up to ten million records will
            be returned. Pagination occurs in groups of 50,000. Remaining limit values will always
            return 50,000 more records unless it is the last page. High volume tickers will require
            multiple max requests for a single day's NBBO records. Expect stocks, like SPY, to
            approach 1GB in size, per day, as a raw CSV. Splitting large requests into chunks is
            recommended for full-day requests of high-volume symbols. (provider: polygon) Default:
            50000.
        date (datetime.date | None | Unset): A specific date to get data for. Use bracketed the
            timestamp parameters to specify exact time ranges. (provider: polygon)
        timestamp_lt (datetime.datetime | None | str | Unset): Query by datetime, less than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_gt (datetime.datetime | None | str | Unset): Query by datetime, greater than.
            Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string, 'YYYY-MM-
            DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day and hour.
            (provider: polygon)
        timestamp_lte (datetime.datetime | None | str | Unset): Query by datetime, less than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)
        timestamp_gte (datetime.datetime | None | str | Unset): Query by datetime, greater than or
            equal to. Either a date with the format 'YYYY-MM-DD' or a TZ-aware timestamp string,
            'YYYY-MM-DDTH:M:S.000000000-04:00'. Include all nanoseconds and the 'T' between the day
            and hour. (provider: polygon)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityNBBO | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            limit=limit,
            date=date,
            timestamp_lt=timestamp_lt,
            timestamp_gt=timestamp_gt,
            timestamp_lte=timestamp_lte,
            timestamp_gte=timestamp_gte,
        )
    ).parsed
