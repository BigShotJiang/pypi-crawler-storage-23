from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_management_discussion_analysis_calendar_period_type_0 import (
    EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_management_discussion_analysis import OBBjectManagementDiscussionAnalysis
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None | Unset = UNSET,
    strategy: str | Unset = "trafilatura",
    wrap_length: int | Unset = 120,
    include_tables: bool | Unset = False,
    use_cache: bool | Unset = True,
    raw_html: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    params["symbol"] = symbol

    json_calendar_year: int | None | Unset
    if isinstance(calendar_year, Unset):
        json_calendar_year = UNSET
    else:
        json_calendar_year = calendar_year
    params["calendar_year"] = json_calendar_year

    json_calendar_period: None | str | Unset
    if isinstance(calendar_period, Unset):
        json_calendar_period = UNSET
    elif isinstance(calendar_period, EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0):
        json_calendar_period = calendar_period.value
    else:
        json_calendar_period = calendar_period
    params["calendar_period"] = json_calendar_period

    params["strategy"] = strategy

    params["wrap_length"] = wrap_length

    params["include_tables"] = include_tables

    params["use_cache"] = use_cache

    params["raw_html"] = raw_html

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/management_discussion_analysis",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectManagementDiscussionAnalysis.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None | Unset = UNSET,
    strategy: str | Unset = "trafilatura",
    wrap_length: int | Unset = 120,
    include_tables: bool | Unset = False,
    use_cache: bool | Unset = True,
    raw_html: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse]:
    """Management Discussion Analysis

     Get the Management Discussion & Analysis section from the financial statements for a given company.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        calendar_year (int | None | Unset): Calendar year of the report. By default, is the
            current year. If the calendar period is not provided, but the calendar year is, it will
            return the annual report.
        calendar_period (EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None |
            Unset): Calendar period of the report. By default, is the most recent report available for
            the symbol. If no calendar year and no calendar period are provided, it will return the
            most recent report.
        strategy (str | Unset): The strategy to use for extracting the text. Default is
            'trafilatura'. (provider: sec) Default: 'trafilatura'.
        wrap_length (int | Unset): The length to wrap the extracted text, excluding tables.
            Default is 120. (provider: sec) Default: 120.
        include_tables (bool | Unset): Return tables formatted as markdown in the text. Default is
            False. Tables may reveal 'missing' content, but will likely need some level of manual
            cleaning, post-request, to display properly. In some cases, tables may not be recoverable
            due to the nature of the document. (provider: sec) Default: False.
        use_cache (bool | Unset): When True, the file will be cached for use later. Default is
            True. (provider: sec) Default: True.
        raw_html (bool | Unset): When True, the raw HTML content of the entire filing will be
            returned. Default is False. Use this option to parse the document manually. (provider:
            sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
        strategy=strategy,
        wrap_length=wrap_length,
        include_tables=include_tables,
        use_cache=use_cache,
        raw_html=raw_html,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None | Unset = UNSET,
    strategy: str | Unset = "trafilatura",
    wrap_length: int | Unset = 120,
    include_tables: bool | Unset = False,
    use_cache: bool | Unset = True,
    raw_html: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse | None:
    """Management Discussion Analysis

     Get the Management Discussion & Analysis section from the financial statements for a given company.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        calendar_year (int | None | Unset): Calendar year of the report. By default, is the
            current year. If the calendar period is not provided, but the calendar year is, it will
            return the annual report.
        calendar_period (EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None |
            Unset): Calendar period of the report. By default, is the most recent report available for
            the symbol. If no calendar year and no calendar period are provided, it will return the
            most recent report.
        strategy (str | Unset): The strategy to use for extracting the text. Default is
            'trafilatura'. (provider: sec) Default: 'trafilatura'.
        wrap_length (int | Unset): The length to wrap the extracted text, excluding tables.
            Default is 120. (provider: sec) Default: 120.
        include_tables (bool | Unset): Return tables formatted as markdown in the text. Default is
            False. Tables may reveal 'missing' content, but will likely need some level of manual
            cleaning, post-request, to display properly. In some cases, tables may not be recoverable
            due to the nature of the document. (provider: sec) Default: False.
        use_cache (bool | Unset): When True, the file will be cached for use later. Default is
            True. (provider: sec) Default: True.
        raw_html (bool | Unset): When True, the raw HTML content of the entire filing will be
            returned. Default is False. Use this option to parse the document manually. (provider:
            sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
        strategy=strategy,
        wrap_length=wrap_length,
        include_tables=include_tables,
        use_cache=use_cache,
        raw_html=raw_html,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None | Unset = UNSET,
    strategy: str | Unset = "trafilatura",
    wrap_length: int | Unset = 120,
    include_tables: bool | Unset = False,
    use_cache: bool | Unset = True,
    raw_html: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse]:
    """Management Discussion Analysis

     Get the Management Discussion & Analysis section from the financial statements for a given company.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        calendar_year (int | None | Unset): Calendar year of the report. By default, is the
            current year. If the calendar period is not provided, but the calendar year is, it will
            return the annual report.
        calendar_period (EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None |
            Unset): Calendar period of the report. By default, is the most recent report available for
            the symbol. If no calendar year and no calendar period are provided, it will return the
            most recent report.
        strategy (str | Unset): The strategy to use for extracting the text. Default is
            'trafilatura'. (provider: sec) Default: 'trafilatura'.
        wrap_length (int | Unset): The length to wrap the extracted text, excluding tables.
            Default is 120. (provider: sec) Default: 120.
        include_tables (bool | Unset): Return tables formatted as markdown in the text. Default is
            False. Tables may reveal 'missing' content, but will likely need some level of manual
            cleaning, post-request, to display properly. In some cases, tables may not be recoverable
            due to the nature of the document. (provider: sec) Default: False.
        use_cache (bool | Unset): When True, the file will be cached for use later. Default is
            True. (provider: sec) Default: True.
        raw_html (bool | Unset): When True, the raw HTML content of the entire filing will be
            returned. Default is False. Use this option to parse the document manually. (provider:
            sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        calendar_year=calendar_year,
        calendar_period=calendar_period,
        strategy=strategy,
        wrap_length=wrap_length,
        include_tables=include_tables,
        use_cache=use_cache,
        raw_html=raw_html,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["sec"] | Unset = "sec",
    symbol: str,
    calendar_year: int | None | Unset = UNSET,
    calendar_period: EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None | Unset = UNSET,
    strategy: str | Unset = "trafilatura",
    wrap_length: int | Unset = 120,
    include_tables: bool | Unset = False,
    use_cache: bool | Unset = True,
    raw_html: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse | None:
    """Management Discussion Analysis

     Get the Management Discussion & Analysis section from the financial statements for a given company.

    Args:
        provider (Literal['sec'] | Unset):  Default: 'sec'.
        symbol (str): Symbol to get data for.
        calendar_year (int | None | Unset): Calendar year of the report. By default, is the
            current year. If the calendar period is not provided, but the calendar year is, it will
            return the annual report.
        calendar_period (EquityFundamentalManagementDiscussionAnalysisCalendarPeriodType0 | None |
            Unset): Calendar period of the report. By default, is the most recent report available for
            the symbol. If no calendar year and no calendar period are provided, it will return the
            most recent report.
        strategy (str | Unset): The strategy to use for extracting the text. Default is
            'trafilatura'. (provider: sec) Default: 'trafilatura'.
        wrap_length (int | Unset): The length to wrap the extracted text, excluding tables.
            Default is 120. (provider: sec) Default: 120.
        include_tables (bool | Unset): Return tables formatted as markdown in the text. Default is
            False. Tables may reveal 'missing' content, but will likely need some level of manual
            cleaning, post-request, to display properly. In some cases, tables may not be recoverable
            due to the nature of the document. (provider: sec) Default: False.
        use_cache (bool | Unset): When True, the file will be cached for use later. Default is
            True. (provider: sec) Default: True.
        raw_html (bool | Unset): When True, the raw HTML content of the entire filing will be
            returned. Default is False. Use this option to parse the document manually. (provider:
            sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectManagementDiscussionAnalysis | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            calendar_year=calendar_year,
            calendar_period=calendar_period,
            strategy=strategy,
            wrap_length=wrap_length,
            include_tables=include_tables,
            use_cache=use_cache,
            raw_html=raw_html,
        )
    ).parsed
