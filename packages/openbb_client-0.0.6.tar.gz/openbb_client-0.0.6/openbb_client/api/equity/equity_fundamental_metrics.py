from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_metrics_fmp import EquityFundamentalMetricsFmp
from ...models.equity_fundamental_metrics_period_type_0 import EquityFundamentalMetricsPeriodType0
from ...models.equity_fundamental_metrics_period_type_1 import EquityFundamentalMetricsPeriodType1
from ...models.equity_fundamental_metrics_provider import EquityFundamentalMetricsProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_key_metrics import OBBjectKeyMetrics
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityFundamentalMetricsProvider,
    symbol: str,
    period: EquityFundamentalMetricsPeriodType0
    | EquityFundamentalMetricsPeriodType1
    | Unset = EquityFundamentalMetricsPeriodType0.QUARTER,
    use_cache: bool | Unset = True,
    ttm: EquityFundamentalMetricsFmp | Unset = EquityFundamentalMetricsFmp.ONLY,
    limit: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_period: str | Unset
    if isinstance(period, Unset):
        json_period = UNSET
    elif isinstance(period, EquityFundamentalMetricsPeriodType0):
        json_period = period.value
    else:
        json_period = period.value

    params["period"] = json_period

    params["use_cache"] = use_cache

    json_ttm: str | Unset = UNSET
    if not isinstance(ttm, Unset):
        json_ttm = ttm.value

    params["ttm"] = json_ttm

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/metrics",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectKeyMetrics.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalMetricsProvider,
    symbol: str,
    period: EquityFundamentalMetricsPeriodType0
    | EquityFundamentalMetricsPeriodType1
    | Unset = EquityFundamentalMetricsPeriodType0.QUARTER,
    use_cache: bool | Unset = True,
    ttm: EquityFundamentalMetricsFmp | Unset = EquityFundamentalMetricsFmp.ONLY,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse]:
    """Metrics

     Get fundamental metrics for a given company.

    Args:
        provider (EquityFundamentalMetricsProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, intrinio, yfinance.
        period (EquityFundamentalMetricsPeriodType0 | EquityFundamentalMetricsPeriodType1 |
            Unset): Time period of the data to return. (provider: akshare);
                Specify the fiscal period for the data. Ignored when TTM is set to 'only'. (provider:
            fmp) Default: EquityFundamentalMetricsPeriodType0.QUARTER.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        ttm (EquityFundamentalMetricsFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalMetricsFmp.ONLY.
        limit (int | None | Unset): Only applicable when TTM is not set to 'only'. Defines the
            number of most recent reporting periods to return. The default is 5. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
        use_cache=use_cache,
        ttm=ttm,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalMetricsProvider,
    symbol: str,
    period: EquityFundamentalMetricsPeriodType0
    | EquityFundamentalMetricsPeriodType1
    | Unset = EquityFundamentalMetricsPeriodType0.QUARTER,
    use_cache: bool | Unset = True,
    ttm: EquityFundamentalMetricsFmp | Unset = EquityFundamentalMetricsFmp.ONLY,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse | None:
    """Metrics

     Get fundamental metrics for a given company.

    Args:
        provider (EquityFundamentalMetricsProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, intrinio, yfinance.
        period (EquityFundamentalMetricsPeriodType0 | EquityFundamentalMetricsPeriodType1 |
            Unset): Time period of the data to return. (provider: akshare);
                Specify the fiscal period for the data. Ignored when TTM is set to 'only'. (provider:
            fmp) Default: EquityFundamentalMetricsPeriodType0.QUARTER.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        ttm (EquityFundamentalMetricsFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalMetricsFmp.ONLY.
        limit (int | None | Unset): Only applicable when TTM is not set to 'only'. Defines the
            number of most recent reporting periods to return. The default is 5. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        period=period,
        use_cache=use_cache,
        ttm=ttm,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalMetricsProvider,
    symbol: str,
    period: EquityFundamentalMetricsPeriodType0
    | EquityFundamentalMetricsPeriodType1
    | Unset = EquityFundamentalMetricsPeriodType0.QUARTER,
    use_cache: bool | Unset = True,
    ttm: EquityFundamentalMetricsFmp | Unset = EquityFundamentalMetricsFmp.ONLY,
    limit: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse]:
    """Metrics

     Get fundamental metrics for a given company.

    Args:
        provider (EquityFundamentalMetricsProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, intrinio, yfinance.
        period (EquityFundamentalMetricsPeriodType0 | EquityFundamentalMetricsPeriodType1 |
            Unset): Time period of the data to return. (provider: akshare);
                Specify the fiscal period for the data. Ignored when TTM is set to 'only'. (provider:
            fmp) Default: EquityFundamentalMetricsPeriodType0.QUARTER.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        ttm (EquityFundamentalMetricsFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalMetricsFmp.ONLY.
        limit (int | None | Unset): Only applicable when TTM is not set to 'only'. Defines the
            number of most recent reporting periods to return. The default is 5. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        period=period,
        use_cache=use_cache,
        ttm=ttm,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalMetricsProvider,
    symbol: str,
    period: EquityFundamentalMetricsPeriodType0
    | EquityFundamentalMetricsPeriodType1
    | Unset = EquityFundamentalMetricsPeriodType0.QUARTER,
    use_cache: bool | Unset = True,
    ttm: EquityFundamentalMetricsFmp | Unset = EquityFundamentalMetricsFmp.ONLY,
    limit: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse | None:
    """Metrics

     Get fundamental metrics for a given company.

    Args:
        provider (EquityFundamentalMetricsProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): akshare, fmp, intrinio, yfinance.
        period (EquityFundamentalMetricsPeriodType0 | EquityFundamentalMetricsPeriodType1 |
            Unset): Time period of the data to return. (provider: akshare);
                Specify the fiscal period for the data. Ignored when TTM is set to 'only'. (provider:
            fmp) Default: EquityFundamentalMetricsPeriodType0.QUARTER.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare) Default: True.
        ttm (EquityFundamentalMetricsFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalMetricsFmp.ONLY.
        limit (int | None | Unset): Only applicable when TTM is not set to 'only'. Defines the
            number of most recent reporting periods to return. The default is 5. (provider: fmp)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectKeyMetrics | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            period=period,
            use_cache=use_cache,
            ttm=ttm,
            limit=limit,
        )
    ).parsed
