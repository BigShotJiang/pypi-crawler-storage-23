from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_fundamental_ratios_fmp import EquityFundamentalRatiosFmp
from ...models.equity_fundamental_ratios_period_type_0 import EquityFundamentalRatiosPeriodType0
from ...models.equity_fundamental_ratios_period_type_1 import EquityFundamentalRatiosPeriodType1
from ...models.equity_fundamental_ratios_provider import EquityFundamentalRatiosProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_financial_ratios import OBBjectFinancialRatios
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityFundamentalRatiosProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    ttm: EquityFundamentalRatiosFmp | Unset = EquityFundamentalRatiosFmp.ONLY,
    period: EquityFundamentalRatiosPeriodType0
    | EquityFundamentalRatiosPeriodType1
    | Unset = EquityFundamentalRatiosPeriodType0.ANNUAL,
    fiscal_year: int | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["symbol"] = symbol

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_ttm: str | Unset = UNSET
    if not isinstance(ttm, Unset):
        json_ttm = ttm.value

    params["ttm"] = json_ttm

    json_period: str | Unset
    if isinstance(period, Unset):
        json_period = UNSET
    elif isinstance(period, EquityFundamentalRatiosPeriodType0):
        json_period = period.value
    else:
        json_period = period.value

    params["period"] = json_period

    json_fiscal_year: int | None | Unset
    if isinstance(fiscal_year, Unset):
        json_fiscal_year = UNSET
    else:
        json_fiscal_year = fiscal_year
    params["fiscal_year"] = json_fiscal_year

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/fundamental/ratios",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectFinancialRatios.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalRatiosProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    ttm: EquityFundamentalRatiosFmp | Unset = EquityFundamentalRatiosFmp.ONLY,
    period: EquityFundamentalRatiosPeriodType0
    | EquityFundamentalRatiosPeriodType1
    | Unset = EquityFundamentalRatiosPeriodType0.ANNUAL,
    fiscal_year: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse]:
    """Ratios

     Get an extensive set of financial and accounting ratios for a given company over time.

    Args:
        provider (EquityFundamentalRatiosProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        limit (int | None | Unset): The number of data entries to return.;
                Only applicable when TTM is not set to 'only'. Defines the number of most recent
            reporting periods to return. The default is 5. (provider: fmp)
        ttm (EquityFundamentalRatiosFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalRatiosFmp.ONLY.
        period (EquityFundamentalRatiosPeriodType0 | EquityFundamentalRatiosPeriodType1 | Unset):
            Specify the fiscal period for the data. (provider: fmp);
                Time period of the data to return. (provider: intrinio) Default:
            EquityFundamentalRatiosPeriodType0.ANNUAL.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        ttm=ttm,
        period=period,
        fiscal_year=fiscal_year,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalRatiosProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    ttm: EquityFundamentalRatiosFmp | Unset = EquityFundamentalRatiosFmp.ONLY,
    period: EquityFundamentalRatiosPeriodType0
    | EquityFundamentalRatiosPeriodType1
    | Unset = EquityFundamentalRatiosPeriodType0.ANNUAL,
    fiscal_year: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse | None:
    """Ratios

     Get an extensive set of financial and accounting ratios for a given company over time.

    Args:
        provider (EquityFundamentalRatiosProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        limit (int | None | Unset): The number of data entries to return.;
                Only applicable when TTM is not set to 'only'. Defines the number of most recent
            reporting periods to return. The default is 5. (provider: fmp)
        ttm (EquityFundamentalRatiosFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalRatiosFmp.ONLY.
        period (EquityFundamentalRatiosPeriodType0 | EquityFundamentalRatiosPeriodType1 | Unset):
            Specify the fiscal period for the data. (provider: fmp);
                Time period of the data to return. (provider: intrinio) Default:
            EquityFundamentalRatiosPeriodType0.ANNUAL.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
        limit=limit,
        ttm=ttm,
        period=period,
        fiscal_year=fiscal_year,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalRatiosProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    ttm: EquityFundamentalRatiosFmp | Unset = EquityFundamentalRatiosFmp.ONLY,
    period: EquityFundamentalRatiosPeriodType0
    | EquityFundamentalRatiosPeriodType1
    | Unset = EquityFundamentalRatiosPeriodType0.ANNUAL,
    fiscal_year: int | None | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse]:
    """Ratios

     Get an extensive set of financial and accounting ratios for a given company over time.

    Args:
        provider (EquityFundamentalRatiosProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        limit (int | None | Unset): The number of data entries to return.;
                Only applicable when TTM is not set to 'only'. Defines the number of most recent
            reporting periods to return. The default is 5. (provider: fmp)
        ttm (EquityFundamentalRatiosFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalRatiosFmp.ONLY.
        period (EquityFundamentalRatiosPeriodType0 | EquityFundamentalRatiosPeriodType1 | Unset):
            Specify the fiscal period for the data. (provider: fmp);
                Time period of the data to return. (provider: intrinio) Default:
            EquityFundamentalRatiosPeriodType0.ANNUAL.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
        limit=limit,
        ttm=ttm,
        period=period,
        fiscal_year=fiscal_year,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityFundamentalRatiosProvider,
    symbol: str,
    limit: int | None | Unset = UNSET,
    ttm: EquityFundamentalRatiosFmp | Unset = EquityFundamentalRatiosFmp.ONLY,
    period: EquityFundamentalRatiosPeriodType0
    | EquityFundamentalRatiosPeriodType1
    | Unset = EquityFundamentalRatiosPeriodType0.ANNUAL,
    fiscal_year: int | None | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse | None:
    """Ratios

     Get an extensive set of financial and accounting ratios for a given company over time.

    Args:
        provider (EquityFundamentalRatiosProvider):
        symbol (str): Symbol to get data for. Multiple comma separated items allowed for
            provider(s): fmp.
        limit (int | None | Unset): The number of data entries to return.;
                Only applicable when TTM is not set to 'only'. Defines the number of most recent
            reporting periods to return. The default is 5. (provider: fmp)
        ttm (EquityFundamentalRatiosFmp | Unset): Specify whether to include, exclude, or only
            show TTM (Trailing Twelve Months) data. The default is 'only'. (provider: fmp) Default:
            EquityFundamentalRatiosFmp.ONLY.
        period (EquityFundamentalRatiosPeriodType0 | EquityFundamentalRatiosPeriodType1 | Unset):
            Specify the fiscal period for the data. (provider: fmp);
                Time period of the data to return. (provider: intrinio) Default:
            EquityFundamentalRatiosPeriodType0.ANNUAL.
        fiscal_year (int | None | Unset): The specific fiscal year.  Reports do not go beyond
            2008. (provider: intrinio)

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectFinancialRatios | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
            limit=limit,
            ttm=ttm,
            period=period,
            fiscal_year=fiscal_year,
        )
    ).parsed
