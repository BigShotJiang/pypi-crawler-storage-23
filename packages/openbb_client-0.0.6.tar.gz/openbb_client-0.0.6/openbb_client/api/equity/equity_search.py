from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_search_provider import EquitySearchProvider
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_equity_search import OBBjectEquitySearch
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquitySearchProvider,
    query: str | Unset = "",
    is_symbol: bool | Unset = False,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 10000,
    active: bool | Unset = True,
    is_fund: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    params["query"] = query

    params["is_symbol"] = is_symbol

    params["use_cache"] = use_cache

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params["active"] = active

    params["is_fund"] = is_fund

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/search",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEquitySearch.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquitySearchProvider,
    query: str | Unset = "",
    is_symbol: bool | Unset = False,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 10000,
    active: bool | Unset = True,
    is_fund: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse]:
    """Search

     Search for stock symbol, CIK, LEI, or company name.

    Args:
        provider (EquitySearchProvider):
        query (str | Unset): Search query. Default: ''.
        is_symbol (bool | Unset): Whether to search by ticker symbol. Default: False.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare);
                Whether to use the cache or not. (provider: sec) Default: True.
        limit (int | None | Unset): The number of data entries to return. (provider: akshare,
            intrinio) Default: 10000.
        active (bool | Unset): When true, return companies that are actively traded (having stock
            prices within the past 14 days). When false, return companies that are not actively traded
            or never have been traded. (provider: intrinio) Default: True.
        is_fund (bool | Unset): Whether to direct the search to the list of mutual funds and ETFs.
            (provider: sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        query=query,
        is_symbol=is_symbol,
        use_cache=use_cache,
        limit=limit,
        active=active,
        is_fund=is_fund,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquitySearchProvider,
    query: str | Unset = "",
    is_symbol: bool | Unset = False,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 10000,
    active: bool | Unset = True,
    is_fund: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse | None:
    """Search

     Search for stock symbol, CIK, LEI, or company name.

    Args:
        provider (EquitySearchProvider):
        query (str | Unset): Search query. Default: ''.
        is_symbol (bool | Unset): Whether to search by ticker symbol. Default: False.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare);
                Whether to use the cache or not. (provider: sec) Default: True.
        limit (int | None | Unset): The number of data entries to return. (provider: akshare,
            intrinio) Default: 10000.
        active (bool | Unset): When true, return companies that are actively traded (having stock
            prices within the past 14 days). When false, return companies that are not actively traded
            or never have been traded. (provider: intrinio) Default: True.
        is_fund (bool | Unset): Whether to direct the search to the list of mutual funds and ETFs.
            (provider: sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        query=query,
        is_symbol=is_symbol,
        use_cache=use_cache,
        limit=limit,
        active=active,
        is_fund=is_fund,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquitySearchProvider,
    query: str | Unset = "",
    is_symbol: bool | Unset = False,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 10000,
    active: bool | Unset = True,
    is_fund: bool | Unset = False,
) -> Response[Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse]:
    """Search

     Search for stock symbol, CIK, LEI, or company name.

    Args:
        provider (EquitySearchProvider):
        query (str | Unset): Search query. Default: ''.
        is_symbol (bool | Unset): Whether to search by ticker symbol. Default: False.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare);
                Whether to use the cache or not. (provider: sec) Default: True.
        limit (int | None | Unset): The number of data entries to return. (provider: akshare,
            intrinio) Default: 10000.
        active (bool | Unset): When true, return companies that are actively traded (having stock
            prices within the past 14 days). When false, return companies that are not actively traded
            or never have been traded. (provider: intrinio) Default: True.
        is_fund (bool | Unset): Whether to direct the search to the list of mutual funds and ETFs.
            (provider: sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        query=query,
        is_symbol=is_symbol,
        use_cache=use_cache,
        limit=limit,
        active=active,
        is_fund=is_fund,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquitySearchProvider,
    query: str | Unset = "",
    is_symbol: bool | Unset = False,
    use_cache: bool | Unset = True,
    limit: int | None | Unset = 10000,
    active: bool | Unset = True,
    is_fund: bool | Unset = False,
) -> Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse | None:
    """Search

     Search for stock symbol, CIK, LEI, or company name.

    Args:
        provider (EquitySearchProvider):
        query (str | Unset): Search query. Default: ''.
        is_symbol (bool | Unset): Whether to search by ticker symbol. Default: False.
        use_cache (bool | Unset): Whether to use a cached request. The quote is cached for one
            hour. (provider: akshare);
                Whether to use the cache or not. (provider: sec) Default: True.
        limit (int | None | Unset): The number of data entries to return. (provider: akshare,
            intrinio) Default: 10000.
        active (bool | Unset): When true, return companies that are actively traded (having stock
            prices within the past 14 days). When false, return companies that are not actively traded
            or never have been traded. (provider: intrinio) Default: True.
        is_fund (bool | Unset): Whether to direct the search to the list of mutual funds and ETFs.
            (provider: sec) Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquitySearch | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            query=query,
            is_symbol=is_symbol,
            use_cache=use_cache,
            limit=limit,
            active=active,
            is_fund=is_fund,
        )
    ).parsed
