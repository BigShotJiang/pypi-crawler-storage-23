from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_forward_pe_estimates import OBBjectForwardPeEstimates
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_symbol: None | str | Unset
    if isinstance(symbol, Unset):
        json_symbol = UNSET
    else:
        json_symbol = symbol
    params["symbol"] = json_symbol

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/estimates/forward_pe",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectForwardPeEstimates.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse]:
    """Forward Pe

     Get forward PE estimates.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): intrinio.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse | None:
    """Forward Pe

     Get forward PE estimates.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): intrinio.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        symbol=symbol,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
) -> Response[Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse]:
    """Forward Pe

     Get forward PE estimates.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): intrinio.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        symbol=symbol,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["intrinio"] | Unset = "intrinio",
    symbol: None | str | Unset = UNSET,
) -> Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse | None:
    """Forward Pe

     Get forward PE estimates.

    Args:
        provider (Literal['intrinio'] | Unset):  Default: 'intrinio'.
        symbol (None | str | Unset): Symbol to get data for. Multiple comma separated items
            allowed for provider(s): intrinio.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectForwardPeEstimates | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            symbol=symbol,
        )
    ).parsed
