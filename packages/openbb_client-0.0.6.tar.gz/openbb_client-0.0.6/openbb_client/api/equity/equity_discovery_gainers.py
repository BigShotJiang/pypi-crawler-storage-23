from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.equity_discovery_gainers_provider import EquityDiscoveryGainersProvider
from ...models.equity_discovery_gainers_sort import EquityDiscoveryGainersSort
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_equity_gainers import OBBjectEquityGainers
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: EquityDiscoveryGainersProvider,
    sort: EquityDiscoveryGainersSort | Unset = EquityDiscoveryGainersSort.DESC,
    limit: int | None | Unset = 200,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_provider = provider.value
    params["provider"] = json_provider

    json_sort: str | Unset = UNSET
    if not isinstance(sort, Unset):
        json_sort = sort.value

    params["sort"] = json_sort

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/equity/discovery/gainers",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectEquityGainers.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityDiscoveryGainersProvider,
    sort: EquityDiscoveryGainersSort | Unset = EquityDiscoveryGainersSort.DESC,
    limit: int | None | Unset = 200,
) -> Response[Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse]:
    """Gainers

     Get the top price gainers in the stock market.

    Args:
        provider (EquityDiscoveryGainersProvider):
        sort (EquityDiscoveryGainersSort | Unset): Sort order. Possible values: 'asc', 'desc'.
            Default: 'desc'. Default: EquityDiscoveryGainersSort.DESC.
        limit (int | None | Unset): Limit the number of results. (provider: yfinance) Default:
            200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        sort=sort,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityDiscoveryGainersProvider,
    sort: EquityDiscoveryGainersSort | Unset = EquityDiscoveryGainersSort.DESC,
    limit: int | None | Unset = 200,
) -> Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse | None:
    """Gainers

     Get the top price gainers in the stock market.

    Args:
        provider (EquityDiscoveryGainersProvider):
        sort (EquityDiscoveryGainersSort | Unset): Sort order. Possible values: 'asc', 'desc'.
            Default: 'desc'. Default: EquityDiscoveryGainersSort.DESC.
        limit (int | None | Unset): Limit the number of results. (provider: yfinance) Default:
            200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        sort=sort,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityDiscoveryGainersProvider,
    sort: EquityDiscoveryGainersSort | Unset = EquityDiscoveryGainersSort.DESC,
    limit: int | None | Unset = 200,
) -> Response[Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse]:
    """Gainers

     Get the top price gainers in the stock market.

    Args:
        provider (EquityDiscoveryGainersProvider):
        sort (EquityDiscoveryGainersSort | Unset): Sort order. Possible values: 'asc', 'desc'.
            Default: 'desc'. Default: EquityDiscoveryGainersSort.DESC.
        limit (int | None | Unset): Limit the number of results. (provider: yfinance) Default:
            200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        sort=sort,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: EquityDiscoveryGainersProvider,
    sort: EquityDiscoveryGainersSort | Unset = EquityDiscoveryGainersSort.DESC,
    limit: int | None | Unset = 200,
) -> Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse | None:
    """Gainers

     Get the top price gainers in the stock market.

    Args:
        provider (EquityDiscoveryGainersProvider):
        sort (EquityDiscoveryGainersSort | Unset): Sort order. Possible values: 'asc', 'desc'.
            Default: 'desc'. Default: EquityDiscoveryGainersSort.DESC.
        limit (int | None | Unset): Limit the number of results. (provider: yfinance) Default:
            200.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectEquityGainers | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            sort=sort,
            limit=limit,
        )
    ).parsed
