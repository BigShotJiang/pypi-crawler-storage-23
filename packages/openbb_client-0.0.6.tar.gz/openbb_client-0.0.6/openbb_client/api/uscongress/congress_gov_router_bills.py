import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_congress_bills import OBBjectCongressBills
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
    congress: int | None | Unset = UNSET,
    bill_type: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,
    sort_by: str | Unset = "desc",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_congress: int | None | Unset
    if isinstance(congress, Unset):
        json_congress = UNSET
    else:
        json_congress = congress
    params["congress"] = json_congress

    json_bill_type: None | str | Unset
    if isinstance(bill_type, Unset):
        json_bill_type = UNSET
    else:
        json_bill_type = bill_type
    params["bill_type"] = json_bill_type

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_offset: int | None | Unset
    if isinstance(offset, Unset):
        json_offset = UNSET
    else:
        json_offset = offset
    params["offset"] = json_offset

    params["sort_by"] = sort_by

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/uscongress/bills",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectCongressBills.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
    congress: int | None | Unset = UNSET,
    bill_type: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,
    sort_by: str | Unset = "desc",
) -> Response[Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse]:
    """Bills

     Get and filter lists of Congressional Bills.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        congress (int | None | Unset): Congress number (e.g., 118 for the 118th Congress). The
            103rd Congress started in 1993, which is the earliest date supporting full text versions.
            Each Congress spans two years, starting in odd-numbered years. (provider: congress_gov)
        bill_type (None | str | Unset): Bill type (e.g., "hr" for House bills).

            Must be one of: hr, s, hjres, sjres, hconres, sconres, hres, sres.

            Bills
            -----

            A bill is the form used for most legislation, whether permanent or temporary, general or
            special, public or private.

            A bill originating in the House of Representatives is designated by the letters “H.R.”,
            signifying “House of Representatives”, followed by a number that it retains throughout all
            its parliamentary stages.

            Bills are presented to the President for action when approved in identical form
            by both the House of Representatives and the Senate.

            Joint Resolutions
            -----------------

            Joint resolutions may originate either in the House of Representatives or in the Senate.

            There is little practical difference between a bill and a joint resolution. Both are
            subject to the same procedure,
            except for a joint resolution proposing an amendment to the Constitution.

            On approval of such a resolution by two-thirds of both the House and Senate,
            it is sent directly to the Administrator of General Services for submission to the
            individual states for ratification.

            It is not presented to the President for approval.
            A joint resolution originating in the House of Representatives is designated “H.J.Res.”
            followed by its individual number.
            Joint resolutions become law in the same manner as bills.

            Concurrent Resolutions
            ----------------------

            Matters affecting the operations of both the House of Representatives and Senate
            are usually initiated by means of concurrent resolutions.

            A concurrent resolution originating in the House of Representatives is designated
            “H.Con.Res.”
            followed by its individual number.

            On approval by both the House of Representatives and Senate,
            they are signed by the Clerk of the House and the Secretary of the Senate.

            They are not presented to the President for action.

            Simple Resolutions
            ------------------

            A matter concerning the operation of either the House of Representatives or Senate
            alone is initiated by a simple resolution.

            A resolution affecting the House of Representatives is designated “H.Res.” followed by its
            number.

            They are not presented to the President for action.

             (provider: congress_gov)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        limit (int | None | Unset): The number of data entries to return. When None, default sets
            to 100 (max 250). Set to 0 for no limit (must be used with 'bill_type' and 'congress').
            Setting to 0 will nullify the start_date, end_date, and offset parameters. (provider:
            congress_gov)
        offset (int | None | Unset): The starting record returned. 0 is the first record.
            (provider: congress_gov)
        sort_by (str | Unset): Sort by update date. Default is latest first. (provider:
            congress_gov) Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        congress=congress,
        bill_type=bill_type,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        offset=offset,
        sort_by=sort_by,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
    congress: int | None | Unset = UNSET,
    bill_type: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,
    sort_by: str | Unset = "desc",
) -> Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse | None:
    """Bills

     Get and filter lists of Congressional Bills.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        congress (int | None | Unset): Congress number (e.g., 118 for the 118th Congress). The
            103rd Congress started in 1993, which is the earliest date supporting full text versions.
            Each Congress spans two years, starting in odd-numbered years. (provider: congress_gov)
        bill_type (None | str | Unset): Bill type (e.g., "hr" for House bills).

            Must be one of: hr, s, hjres, sjres, hconres, sconres, hres, sres.

            Bills
            -----

            A bill is the form used for most legislation, whether permanent or temporary, general or
            special, public or private.

            A bill originating in the House of Representatives is designated by the letters “H.R.”,
            signifying “House of Representatives”, followed by a number that it retains throughout all
            its parliamentary stages.

            Bills are presented to the President for action when approved in identical form
            by both the House of Representatives and the Senate.

            Joint Resolutions
            -----------------

            Joint resolutions may originate either in the House of Representatives or in the Senate.

            There is little practical difference between a bill and a joint resolution. Both are
            subject to the same procedure,
            except for a joint resolution proposing an amendment to the Constitution.

            On approval of such a resolution by two-thirds of both the House and Senate,
            it is sent directly to the Administrator of General Services for submission to the
            individual states for ratification.

            It is not presented to the President for approval.
            A joint resolution originating in the House of Representatives is designated “H.J.Res.”
            followed by its individual number.
            Joint resolutions become law in the same manner as bills.

            Concurrent Resolutions
            ----------------------

            Matters affecting the operations of both the House of Representatives and Senate
            are usually initiated by means of concurrent resolutions.

            A concurrent resolution originating in the House of Representatives is designated
            “H.Con.Res.”
            followed by its individual number.

            On approval by both the House of Representatives and Senate,
            they are signed by the Clerk of the House and the Secretary of the Senate.

            They are not presented to the President for action.

            Simple Resolutions
            ------------------

            A matter concerning the operation of either the House of Representatives or Senate
            alone is initiated by a simple resolution.

            A resolution affecting the House of Representatives is designated “H.Res.” followed by its
            number.

            They are not presented to the President for action.

             (provider: congress_gov)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        limit (int | None | Unset): The number of data entries to return. When None, default sets
            to 100 (max 250). Set to 0 for no limit (must be used with 'bill_type' and 'congress').
            Setting to 0 will nullify the start_date, end_date, and offset parameters. (provider:
            congress_gov)
        offset (int | None | Unset): The starting record returned. 0 is the first record.
            (provider: congress_gov)
        sort_by (str | Unset): Sort by update date. Default is latest first. (provider:
            congress_gov) Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        congress=congress,
        bill_type=bill_type,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        offset=offset,
        sort_by=sort_by,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
    congress: int | None | Unset = UNSET,
    bill_type: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,
    sort_by: str | Unset = "desc",
) -> Response[Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse]:
    """Bills

     Get and filter lists of Congressional Bills.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        congress (int | None | Unset): Congress number (e.g., 118 for the 118th Congress). The
            103rd Congress started in 1993, which is the earliest date supporting full text versions.
            Each Congress spans two years, starting in odd-numbered years. (provider: congress_gov)
        bill_type (None | str | Unset): Bill type (e.g., "hr" for House bills).

            Must be one of: hr, s, hjres, sjres, hconres, sconres, hres, sres.

            Bills
            -----

            A bill is the form used for most legislation, whether permanent or temporary, general or
            special, public or private.

            A bill originating in the House of Representatives is designated by the letters “H.R.”,
            signifying “House of Representatives”, followed by a number that it retains throughout all
            its parliamentary stages.

            Bills are presented to the President for action when approved in identical form
            by both the House of Representatives and the Senate.

            Joint Resolutions
            -----------------

            Joint resolutions may originate either in the House of Representatives or in the Senate.

            There is little practical difference between a bill and a joint resolution. Both are
            subject to the same procedure,
            except for a joint resolution proposing an amendment to the Constitution.

            On approval of such a resolution by two-thirds of both the House and Senate,
            it is sent directly to the Administrator of General Services for submission to the
            individual states for ratification.

            It is not presented to the President for approval.
            A joint resolution originating in the House of Representatives is designated “H.J.Res.”
            followed by its individual number.
            Joint resolutions become law in the same manner as bills.

            Concurrent Resolutions
            ----------------------

            Matters affecting the operations of both the House of Representatives and Senate
            are usually initiated by means of concurrent resolutions.

            A concurrent resolution originating in the House of Representatives is designated
            “H.Con.Res.”
            followed by its individual number.

            On approval by both the House of Representatives and Senate,
            they are signed by the Clerk of the House and the Secretary of the Senate.

            They are not presented to the President for action.

            Simple Resolutions
            ------------------

            A matter concerning the operation of either the House of Representatives or Senate
            alone is initiated by a simple resolution.

            A resolution affecting the House of Representatives is designated “H.Res.” followed by its
            number.

            They are not presented to the President for action.

             (provider: congress_gov)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        limit (int | None | Unset): The number of data entries to return. When None, default sets
            to 100 (max 250). Set to 0 for no limit (must be used with 'bill_type' and 'congress').
            Setting to 0 will nullify the start_date, end_date, and offset parameters. (provider:
            congress_gov)
        offset (int | None | Unset): The starting record returned. 0 is the first record.
            (provider: congress_gov)
        sort_by (str | Unset): Sort by update date. Default is latest first. (provider:
            congress_gov) Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        congress=congress,
        bill_type=bill_type,
        start_date=start_date,
        end_date=end_date,
        limit=limit,
        offset=offset,
        sort_by=sort_by,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["congress_gov"] | Unset = "congress_gov",
    congress: int | None | Unset = UNSET,
    bill_type: None | str | Unset = UNSET,
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    limit: int | None | Unset = UNSET,
    offset: int | None | Unset = UNSET,
    sort_by: str | Unset = "desc",
) -> Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse | None:
    """Bills

     Get and filter lists of Congressional Bills.

    Args:
        provider (Literal['congress_gov'] | Unset):  Default: 'congress_gov'.
        congress (int | None | Unset): Congress number (e.g., 118 for the 118th Congress). The
            103rd Congress started in 1993, which is the earliest date supporting full text versions.
            Each Congress spans two years, starting in odd-numbered years. (provider: congress_gov)
        bill_type (None | str | Unset): Bill type (e.g., "hr" for House bills).

            Must be one of: hr, s, hjres, sjres, hconres, sconres, hres, sres.

            Bills
            -----

            A bill is the form used for most legislation, whether permanent or temporary, general or
            special, public or private.

            A bill originating in the House of Representatives is designated by the letters “H.R.”,
            signifying “House of Representatives”, followed by a number that it retains throughout all
            its parliamentary stages.

            Bills are presented to the President for action when approved in identical form
            by both the House of Representatives and the Senate.

            Joint Resolutions
            -----------------

            Joint resolutions may originate either in the House of Representatives or in the Senate.

            There is little practical difference between a bill and a joint resolution. Both are
            subject to the same procedure,
            except for a joint resolution proposing an amendment to the Constitution.

            On approval of such a resolution by two-thirds of both the House and Senate,
            it is sent directly to the Administrator of General Services for submission to the
            individual states for ratification.

            It is not presented to the President for approval.
            A joint resolution originating in the House of Representatives is designated “H.J.Res.”
            followed by its individual number.
            Joint resolutions become law in the same manner as bills.

            Concurrent Resolutions
            ----------------------

            Matters affecting the operations of both the House of Representatives and Senate
            are usually initiated by means of concurrent resolutions.

            A concurrent resolution originating in the House of Representatives is designated
            “H.Con.Res.”
            followed by its individual number.

            On approval by both the House of Representatives and Senate,
            they are signed by the Clerk of the House and the Secretary of the Senate.

            They are not presented to the President for action.

            Simple Resolutions
            ------------------

            A matter concerning the operation of either the House of Representatives or Senate
            alone is initiated by a simple resolution.

            A resolution affecting the House of Representatives is designated “H.Res.” followed by its
            number.

            They are not presented to the President for action.

             (provider: congress_gov)
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
            Filters bills by the last updated date. (provider: congress_gov)
        limit (int | None | Unset): The number of data entries to return. When None, default sets
            to 100 (max 250). Set to 0 for no limit (must be used with 'bill_type' and 'congress').
            Setting to 0 will nullify the start_date, end_date, and offset parameters. (provider:
            congress_gov)
        offset (int | None | Unset): The starting record returned. 0 is the first record.
            (provider: congress_gov)
        sort_by (str | Unset): Sort by update date. Default is latest first. (provider:
            congress_gov) Default: 'desc'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectCongressBills | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            congress=congress,
            bill_type=bill_type,
            start_date=start_date,
            end_date=end_date,
            limit=limit,
            offset=offset,
            sort_by=sort_by,
        )
    ).parsed
