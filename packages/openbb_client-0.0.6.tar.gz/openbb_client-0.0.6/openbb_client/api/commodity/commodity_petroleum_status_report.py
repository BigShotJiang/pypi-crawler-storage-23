import datetime
from http import HTTPStatus
from typing import Any, Literal, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.commodity_petroleum_status_report_eia import CommodityPetroleumStatusReportEia
from ...models.http_validation_error import HTTPValidationError
from ...models.ob_bject_petroleum_status_report import OBBjectPetroleumStatusReport
from ...models.open_bb_error_response import OpenBBErrorResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    provider: Literal["eia"] | Unset = "eia",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    category: CommodityPetroleumStatusReportEia | Unset = CommodityPetroleumStatusReportEia.BALANCE_SHEET,
    table: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["provider"] = provider

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    elif isinstance(start_date, datetime.date):
        json_start_date = start_date.isoformat()
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    elif isinstance(end_date, datetime.date):
        json_end_date = end_date.isoformat()
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_category: str | Unset = UNSET
    if not isinstance(category, Unset):
        json_category = category.value

    params["category"] = json_category

    json_table: None | str | Unset
    if isinstance(table, Unset):
        json_table = UNSET
    else:
        json_table = table
    params["table"] = json_table

    params["use_cache"] = use_cache

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/api/v1/commodity/petroleum_status_report",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse | None:
    if response.status_code == 200:
        response_200 = OBBjectPetroleumStatusReport.from_dict(response.json())

        return response_200

    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 400:
        response_400 = OpenBBErrorResponse.from_dict(response.json())

        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if response.status_code == 500:
        response_500 = OpenBBErrorResponse.from_dict(response.json())

        return response_500

    if response.status_code == 502:
        response_502 = OpenBBErrorResponse.from_dict(response.json())

        return response_502

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["eia"] | Unset = "eia",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    category: CommodityPetroleumStatusReportEia | Unset = CommodityPetroleumStatusReportEia.BALANCE_SHEET,
    table: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse]:
    """Petroleum Status Report

     EIA Weekly Petroleum Status Report.

    Args:
        provider (Literal['eia'] | Unset):  Default: 'eia'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        category (CommodityPetroleumStatusReportEia | Unset): The group of data to be returned.
            The default is the balance sheet. (provider: eia) Default:
            CommodityPetroleumStatusReportEia.BALANCE_SHEET.
        table (None | str | Unset): The specific table element within the category to be returned,
            default is 'stocks', if the category is 'weekly_estimates', else 'all'.
                Note: Choices represent all available tables from the entire collection and are not
            all available for every category.
                Invalid choices will raise a ValidationError with a message indicating the valid
            choices for the selected category.
                Choices are:
                    all
                    conventional_gas
                    crude
                    crude_production
                    crude_production_avg
                    diesel
                    ethanol_plant_production
                    ethanol_plant_production_avg
                    exports
                    exports_avg
                    heating_oil
                    imports
                    imports_avg
                    imports_by_country
                    imports_by_country_avg
                    inputs_and_utilization
                    inputs_and_utilization_avg
                    jet_fuel
                    monthly
                    net_imports_inc_spr_avg
                    net_imports_incl_spr
                    net_production
                    net_production_avg
                    net_production_by_product
                    net_production_by_production_avg
                    product_by_region
                    product_by_region_avg
                    product_supplied
                    product_supplied_avg
                    propane
                    rbob
                    refiner_blender_net_production
                    refiner_blender_net_production_avg
                    stocks
                    supply
                    supply_avg
                    ulta_low_sulfur_distillate_reclassification
                    ulta_low_sulfur_distillate_reclassification_avg
                    weekly
                Multiple comma separated items allowed. (provider: eia)
        use_cache (bool | Unset): Subsequent requests for the same source data are cached for the
            session using ALRU cache. (provider: eia) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        category=category,
        table=table,
        use_cache=use_cache,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["eia"] | Unset = "eia",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    category: CommodityPetroleumStatusReportEia | Unset = CommodityPetroleumStatusReportEia.BALANCE_SHEET,
    table: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse | None:
    """Petroleum Status Report

     EIA Weekly Petroleum Status Report.

    Args:
        provider (Literal['eia'] | Unset):  Default: 'eia'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        category (CommodityPetroleumStatusReportEia | Unset): The group of data to be returned.
            The default is the balance sheet. (provider: eia) Default:
            CommodityPetroleumStatusReportEia.BALANCE_SHEET.
        table (None | str | Unset): The specific table element within the category to be returned,
            default is 'stocks', if the category is 'weekly_estimates', else 'all'.
                Note: Choices represent all available tables from the entire collection and are not
            all available for every category.
                Invalid choices will raise a ValidationError with a message indicating the valid
            choices for the selected category.
                Choices are:
                    all
                    conventional_gas
                    crude
                    crude_production
                    crude_production_avg
                    diesel
                    ethanol_plant_production
                    ethanol_plant_production_avg
                    exports
                    exports_avg
                    heating_oil
                    imports
                    imports_avg
                    imports_by_country
                    imports_by_country_avg
                    inputs_and_utilization
                    inputs_and_utilization_avg
                    jet_fuel
                    monthly
                    net_imports_inc_spr_avg
                    net_imports_incl_spr
                    net_production
                    net_production_avg
                    net_production_by_product
                    net_production_by_production_avg
                    product_by_region
                    product_by_region_avg
                    product_supplied
                    product_supplied_avg
                    propane
                    rbob
                    refiner_blender_net_production
                    refiner_blender_net_production_avg
                    stocks
                    supply
                    supply_avg
                    ulta_low_sulfur_distillate_reclassification
                    ulta_low_sulfur_distillate_reclassification_avg
                    weekly
                Multiple comma separated items allowed. (provider: eia)
        use_cache (bool | Unset): Subsequent requests for the same source data are cached for the
            session using ALRU cache. (provider: eia) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse
    """

    return sync_detailed(
        client=client,
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        category=category,
        table=table,
        use_cache=use_cache,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["eia"] | Unset = "eia",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    category: CommodityPetroleumStatusReportEia | Unset = CommodityPetroleumStatusReportEia.BALANCE_SHEET,
    table: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Response[Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse]:
    """Petroleum Status Report

     EIA Weekly Petroleum Status Report.

    Args:
        provider (Literal['eia'] | Unset):  Default: 'eia'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        category (CommodityPetroleumStatusReportEia | Unset): The group of data to be returned.
            The default is the balance sheet. (provider: eia) Default:
            CommodityPetroleumStatusReportEia.BALANCE_SHEET.
        table (None | str | Unset): The specific table element within the category to be returned,
            default is 'stocks', if the category is 'weekly_estimates', else 'all'.
                Note: Choices represent all available tables from the entire collection and are not
            all available for every category.
                Invalid choices will raise a ValidationError with a message indicating the valid
            choices for the selected category.
                Choices are:
                    all
                    conventional_gas
                    crude
                    crude_production
                    crude_production_avg
                    diesel
                    ethanol_plant_production
                    ethanol_plant_production_avg
                    exports
                    exports_avg
                    heating_oil
                    imports
                    imports_avg
                    imports_by_country
                    imports_by_country_avg
                    inputs_and_utilization
                    inputs_and_utilization_avg
                    jet_fuel
                    monthly
                    net_imports_inc_spr_avg
                    net_imports_incl_spr
                    net_production
                    net_production_avg
                    net_production_by_product
                    net_production_by_production_avg
                    product_by_region
                    product_by_region_avg
                    product_supplied
                    product_supplied_avg
                    propane
                    rbob
                    refiner_blender_net_production
                    refiner_blender_net_production_avg
                    stocks
                    supply
                    supply_avg
                    ulta_low_sulfur_distillate_reclassification
                    ulta_low_sulfur_distillate_reclassification_avg
                    weekly
                Multiple comma separated items allowed. (provider: eia)
        use_cache (bool | Unset): Subsequent requests for the same source data are cached for the
            session using ALRU cache. (provider: eia) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse]
    """

    kwargs = _get_kwargs(
        provider=provider,
        start_date=start_date,
        end_date=end_date,
        category=category,
        table=table,
        use_cache=use_cache,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    provider: Literal["eia"] | Unset = "eia",
    start_date: datetime.date | None | Unset = UNSET,
    end_date: datetime.date | None | Unset = UNSET,
    category: CommodityPetroleumStatusReportEia | Unset = CommodityPetroleumStatusReportEia.BALANCE_SHEET,
    table: None | str | Unset = UNSET,
    use_cache: bool | Unset = True,
) -> Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse | None:
    """Petroleum Status Report

     EIA Weekly Petroleum Status Report.

    Args:
        provider (Literal['eia'] | Unset):  Default: 'eia'.
        start_date (datetime.date | None | Unset): Start date of the data, in YYYY-MM-DD format.
        end_date (datetime.date | None | Unset): End date of the data, in YYYY-MM-DD format.
        category (CommodityPetroleumStatusReportEia | Unset): The group of data to be returned.
            The default is the balance sheet. (provider: eia) Default:
            CommodityPetroleumStatusReportEia.BALANCE_SHEET.
        table (None | str | Unset): The specific table element within the category to be returned,
            default is 'stocks', if the category is 'weekly_estimates', else 'all'.
                Note: Choices represent all available tables from the entire collection and are not
            all available for every category.
                Invalid choices will raise a ValidationError with a message indicating the valid
            choices for the selected category.
                Choices are:
                    all
                    conventional_gas
                    crude
                    crude_production
                    crude_production_avg
                    diesel
                    ethanol_plant_production
                    ethanol_plant_production_avg
                    exports
                    exports_avg
                    heating_oil
                    imports
                    imports_avg
                    imports_by_country
                    imports_by_country_avg
                    inputs_and_utilization
                    inputs_and_utilization_avg
                    jet_fuel
                    monthly
                    net_imports_inc_spr_avg
                    net_imports_incl_spr
                    net_production
                    net_production_avg
                    net_production_by_product
                    net_production_by_production_avg
                    product_by_region
                    product_by_region_avg
                    product_supplied
                    product_supplied_avg
                    propane
                    rbob
                    refiner_blender_net_production
                    refiner_blender_net_production_avg
                    stocks
                    supply
                    supply_avg
                    ulta_low_sulfur_distillate_reclassification
                    ulta_low_sulfur_distillate_reclassification_avg
                    weekly
                Multiple comma separated items allowed. (provider: eia)
        use_cache (bool | Unset): Subsequent requests for the same source data are cached for the
            session using ALRU cache. (provider: eia) Default: True.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError | OBBjectPetroleumStatusReport | OpenBBErrorResponse
    """

    return (
        await asyncio_detailed(
            client=client,
            provider=provider,
            start_date=start_date,
            end_date=end_date,
            category=category,
            table=table,
            use_cache=use_cache,
        )
    ).parsed
