from enum import Enum


class CurrencySearchProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"
    POLYGON = "polygon"

    def __str__(self) -> str:
        return str(self.value)
