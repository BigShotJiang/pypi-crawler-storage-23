from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FMPCalendarDividendData")


@_attrs_define
class FMPCalendarDividendData:
    """FMP Dividend Calendar Data.

    Attributes:
        ex_dividend_date (datetime.date): The ex-dividend date - the date on which the stock begins trading without
            rights to the dividend.
        symbol (str): Symbol representing the entity requested in the data.
        amount (float | None | Unset): The dividend amount per share.
        name (None | str | Unset): Name of the entity.
        record_date (datetime.date | None | Unset): The record date of ownership for eligibility.
        payment_date (datetime.date | None | Unset): The payment date of the dividend.
        declaration_date (datetime.date | None | Unset): Declaration date of the dividend.
        adjusted_amount (float | None | Unset): The adjusted-dividend amount.
        dividend_yield (float | None | Unset): Annualized dividend yield.
        frequency (None | str | Unset): Frequency of the regular dividend payment.
    """

    ex_dividend_date: datetime.date
    symbol: str
    amount: float | None | Unset = UNSET
    name: None | str | Unset = UNSET
    record_date: datetime.date | None | Unset = UNSET
    payment_date: datetime.date | None | Unset = UNSET
    declaration_date: datetime.date | None | Unset = UNSET
    adjusted_amount: float | None | Unset = UNSET
    dividend_yield: float | None | Unset = UNSET
    frequency: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        ex_dividend_date = self.ex_dividend_date.isoformat()

        symbol = self.symbol

        amount: float | None | Unset
        if isinstance(self.amount, Unset):
            amount = UNSET
        else:
            amount = self.amount

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        record_date: None | str | Unset
        if isinstance(self.record_date, Unset):
            record_date = UNSET
        elif isinstance(self.record_date, datetime.date):
            record_date = self.record_date.isoformat()
        else:
            record_date = self.record_date

        payment_date: None | str | Unset
        if isinstance(self.payment_date, Unset):
            payment_date = UNSET
        elif isinstance(self.payment_date, datetime.date):
            payment_date = self.payment_date.isoformat()
        else:
            payment_date = self.payment_date

        declaration_date: None | str | Unset
        if isinstance(self.declaration_date, Unset):
            declaration_date = UNSET
        elif isinstance(self.declaration_date, datetime.date):
            declaration_date = self.declaration_date.isoformat()
        else:
            declaration_date = self.declaration_date

        adjusted_amount: float | None | Unset
        if isinstance(self.adjusted_amount, Unset):
            adjusted_amount = UNSET
        else:
            adjusted_amount = self.adjusted_amount

        dividend_yield: float | None | Unset
        if isinstance(self.dividend_yield, Unset):
            dividend_yield = UNSET
        else:
            dividend_yield = self.dividend_yield

        frequency: None | str | Unset
        if isinstance(self.frequency, Unset):
            frequency = UNSET
        else:
            frequency = self.frequency

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "ex_dividend_date": ex_dividend_date,
                "symbol": symbol,
            }
        )
        if amount is not UNSET:
            field_dict["amount"] = amount
        if name is not UNSET:
            field_dict["name"] = name
        if record_date is not UNSET:
            field_dict["record_date"] = record_date
        if payment_date is not UNSET:
            field_dict["payment_date"] = payment_date
        if declaration_date is not UNSET:
            field_dict["declaration_date"] = declaration_date
        if adjusted_amount is not UNSET:
            field_dict["adjusted_amount"] = adjusted_amount
        if dividend_yield is not UNSET:
            field_dict["dividend_yield"] = dividend_yield
        if frequency is not UNSET:
            field_dict["frequency"] = frequency

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ex_dividend_date = isoparse(d.pop("ex_dividend_date")).date()

        symbol = d.pop("symbol")

        def _parse_amount(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        amount = _parse_amount(d.pop("amount", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_record_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                record_date_type_0 = isoparse(data).date()

                return record_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        record_date = _parse_record_date(d.pop("record_date", UNSET))

        def _parse_payment_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                payment_date_type_0 = isoparse(data).date()

                return payment_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        payment_date = _parse_payment_date(d.pop("payment_date", UNSET))

        def _parse_declaration_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                declaration_date_type_0 = isoparse(data).date()

                return declaration_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        declaration_date = _parse_declaration_date(d.pop("declaration_date", UNSET))

        def _parse_adjusted_amount(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        adjusted_amount = _parse_adjusted_amount(d.pop("adjusted_amount", UNSET))

        def _parse_dividend_yield(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dividend_yield = _parse_dividend_yield(d.pop("dividend_yield", UNSET))

        def _parse_frequency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        frequency = _parse_frequency(d.pop("frequency", UNSET))

        fmp_calendar_dividend_data = cls(
            ex_dividend_date=ex_dividend_date,
            symbol=symbol,
            amount=amount,
            name=name,
            record_date=record_date,
            payment_date=payment_date,
            declaration_date=declaration_date,
            adjusted_amount=adjusted_amount,
            dividend_yield=dividend_yield,
            frequency=frequency,
        )

        fmp_calendar_dividend_data.additional_properties = d
        return fmp_calendar_dividend_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
