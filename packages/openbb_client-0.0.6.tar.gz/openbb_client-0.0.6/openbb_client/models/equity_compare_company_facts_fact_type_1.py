from enum import Enum


class EquityCompareCompanyFactsFactType1(str, Enum):
    ACCOUNTSPAYABLECURRENT = "AccountsPayableCurrent"
    ACCOUNTSRECEIVABLENET = "AccountsReceivableNet"
    ACCOUNTSRECEIVABLENETCURRENT = "AccountsReceivableNetCurrent"
    ACCRUALFORTAXESOTHERTHANINCOMETAXESCURRENT = "AccrualForTaxesOtherThanIncomeTaxesCurrent"
    ACCRUALFORTAXESOTHERTHANINCOMETAXESCURRENTANDNONCURRENT = "AccrualForTaxesOtherThanIncomeTaxesCurrentAndNoncurrent"
    ACCRUEDINCOMETAXESCURRENT = "AccruedIncomeTaxesCurrent"
    ACCRUEDINCOMETAXESNONCURRENT = "AccruedIncomeTaxesNoncurrent"
    ACCRUEDINSURANCECURRENT = "AccruedInsuranceCurrent"
    ACCRUEDLIABILITIESCURRENT = "AccruedLiabilitiesCurrent"
    ACCUMULATEDDEPRECIATIONDEPLETIONANDAMORTIZATIONPROPERTYPLANTANDEQUIPMENT = (
        "AccumulatedDepreciationDepletionAndAmortizationPropertyPlantAndEquipment"
    )
    ACCUMULATEDOTHERCOMPREHENSIVEINCOMELOSSNETOFTAX = "AccumulatedOtherComprehensiveIncomeLossNetOfTax"
    ACQUISITIONSNETOFCASHACQUIREDANDPURCHASESOFINTANGIBLEANDOTHERASSETS = (
        "AcquisitionsNetOfCashAcquiredAndPurchasesOfIntangibleAndOtherAssets"
    )
    ADJUSTMENTSTOADDITIONALPAIDINCAPITALSHAREBASEDCOMPENSATIONREQUISITESERVICEPERIODRECOGNITIONVALUE = (
        "AdjustmentsToAdditionalPaidInCapitalSharebasedCompensationRequisiteServicePeriodRecognitionValue"
    )
    ADVERTISINGEXPENSE = "AdvertisingExpense"
    ALLOCATEDSHAREBASEDCOMPENSATIONEXPENSE = "AllocatedShareBasedCompensationExpense"
    ANTIDILUTIVESECURITIESEXCLUDEDFROMCOMPUTATIONOFEARNINGSPERSHAREAMOUNT = (
        "AntidilutiveSecuritiesExcludedFromComputationOfEarningsPerShareAmount"
    )
    ASSETIMPAIRMENTCHARGES = "AssetImpairmentCharges"
    ASSETS = "Assets"
    ASSETSCURRENT = "AssetsCurrent"
    ASSETSNONCURRENT = "AssetsNoncurrent"
    BUILDINGSANDIMPROVEMENTSGROSS = "BuildingsAndImprovementsGross"
    CAPITALLEASEOBLIGATIONSCURRENT = "CapitalLeaseObligationsCurrent"
    CAPITALLEASEOBLIGATIONSNONCURRENT = "CapitalLeaseObligationsNoncurrent"
    CASH = "Cash"
    CASHANDCASHEQUIVALENTSATCARRYINGVALUE = "CashAndCashEquivalentsAtCarryingValue"
    CASHCASHEQUIVALENTSANDSHORTTERMINVESTMENTS = "CashCashEquivalentsAndShortTermInvestments"
    CASHCASHEQUIVALENTSRESTRICTEDCASHANDRESTRICTEDCASHEQUIVALENTS = (
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"
    )
    CASHCASHEQUIVALENTSRESTRICTEDCASHANDRESTRICTEDCASHEQUIVALENTSINCLUDINGDISPOSALGROUPANDDISCONTINUEDOPERATIONS = (
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsIncludingDisposalGroupAndDiscontinuedOperations"
    )
    CASHCASHEQUIVALENTSRESTRICTEDCASHANDRESTRICTEDCASHEQUIVALENTSPERIODINCREASEDECREASEINCLUDINGEXCHANGERATEEFFECT = (
        "CashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsPeriodIncreaseDecreaseIncludingExchangeRateEffect"
    )
    COMMERCIALPAPER = "CommercialPaper"
    COMMITMENTSANDCONTINGENCIES = "CommitmentsAndContingencies"
    COMMONSTOCKDIVIDENDSPERSHARECASHPAID = "CommonStockDividendsPerShareCashPaid"
    COMMONSTOCKDIVIDENDSPERSHAREDECLARED = "CommonStockDividendsPerShareDeclared"
    COMMONSTOCKSINCLUDINGADDITIONALPAIDINCAPITAL = "CommonStocksIncludingAdditionalPaidInCapital"
    COMPREHENSIVEINCOMENETOFTAX = "ComprehensiveIncomeNetOfTax"
    COMPREHENSIVEINCOMENETOFTAXATTRIBUTABLETONONCONTROLLINGINTEREST = (
        "ComprehensiveIncomeNetOfTaxAttributableToNoncontrollingInterest"
    )
    COMPREHENSIVEINCOMENETOFTAXINCLUDINGPORTIONATTRIBUTABLETONONCONTROLLINGINTEREST = (
        "ComprehensiveIncomeNetOfTaxIncludingPortionAttributableToNoncontrollingInterest"
    )
    CONSTRUCTIONINPROGRESSGROSS = "ConstructionInProgressGross"
    CONTRACTWITHCUSTOMERASSETNET = "ContractWithCustomerAssetNet"
    CONTRACTWITHCUSTOMERLIABILITY = "ContractWithCustomerLiability"
    CONTRACTWITHCUSTOMERLIABILITYCURRENT = "ContractWithCustomerLiabilityCurrent"
    CONTRACTWITHCUSTOMERLIABILITYNONCURRENT = "ContractWithCustomerLiabilityNoncurrent"
    COSTOFGOODSANDSERVICESSOLD = "CostOfGoodsAndServicesSold"
    COSTOFREVENUE = "CostOfRevenue"
    CURRENTFEDERALTAXEXPENSEBENEFIT = "CurrentFederalTaxExpenseBenefit"
    CURRENTFOREIGNTAXEXPENSEBENEFIT = "CurrentForeignTaxExpenseBenefit"
    CURRENTINCOMETAXEXPENSEBENEFIT = "CurrentIncomeTaxExpenseBenefit"
    CURRENTSTATEANDLOCALTAXEXPENSEBENEFIT = "CurrentStateAndLocalTaxExpenseBenefit"
    DEBTINSTRUMENTFACEAMOUNT = "DebtInstrumentFaceAmount"
    DEBTINSTRUMENTFAIRVALUE = "DebtInstrumentFairValue"
    DEBTLONGTERMANDSHORTTERMCOMBINEDAMOUNT = "DebtLongtermAndShorttermCombinedAmount"
    DEFERREDFEDERALINCOMETAXEXPENSEBENEFIT = "DeferredFederalIncomeTaxExpenseBenefit"
    DEFERREDFOREIGNINCOMETAXEXPENSEBENEFIT = "DeferredForeignIncomeTaxExpenseBenefit"
    DEFERREDINCOMETAXESANDTAXCREDITS = "DeferredIncomeTaxesAndTaxCredits"
    DEFERREDINCOMETAXEXPENSEBENEFIT = "DeferredIncomeTaxExpenseBenefit"
    DEFERREDINCOMETAXLIABILITIES = "DeferredIncomeTaxLiabilities"
    DEFERREDINCOMETAXLIABILITIESNET = "DeferredIncomeTaxLiabilitiesNet"
    DEFERREDREVENUE = "DeferredRevenue"
    DEFERREDTAXASSETSGROSS = "DeferredTaxAssetsGross"
    DEFERREDTAXASSETSLIABILITIESNET = "DeferredTaxAssetsLiabilitiesNet"
    DEFERREDTAXASSETSNET = "DeferredTaxAssetsNet"
    DEFERREDTAXLIABILITIES = "DeferredTaxLiabilities"
    DEFINEDCONTRIBUTIONPLANCOSTRECOGNIZED = "DefinedContributionPlanCostRecognized"
    DEPRECIATION = "Depreciation"
    DEPRECIATIONAMORTIZATIONANDACCRETIONNET = "DepreciationAmortizationAndAccretionNet"
    DEPRECIATIONAMORTIZATIONANDOTHER = "DepreciationAmortizationAndOther"
    DEPRECIATIONANDAMORTIZATION = "DepreciationAndAmortization"
    DEPRECIATIONDEPLETIONANDAMORTIZATION = "DepreciationDepletionAndAmortization"
    DERIVATIVECOLLATERALOBLIGATIONTORETURNCASH = "DerivativeCollateralObligationToReturnCash"
    DERIVATIVECOLLATERALRIGHTTORECLAIMCASH = "DerivativeCollateralRightToReclaimCash"
    DERIVATIVEFAIRVALUEOFDERIVATIVENET = "DerivativeFairValueOfDerivativeNet"
    DERIVATIVELIABILITYCOLLATERALRIGHTTORECLAIMCASHOFFSET = "DerivativeLiabilityCollateralRightToReclaimCashOffset"
    DERIVATIVENOTIONALAMOUNT = "DerivativeNotionalAmount"
    DISTRIBUTEDEARNINGS = "DistributedEarnings"
    DIVIDENDS = "Dividends"
    DIVIDENDSCASH = "DividendsCash"
    DIVIDENDSPAYABLEAMOUNTPERSHARE = "DividendsPayableAmountPerShare"
    DIVIDENDSPAYABLECURRENT = "DividendsPayableCurrent"
    EARNINGSPERSHAREBASIC = "EarningsPerShareBasic"
    EARNINGSPERSHAREDILUTED = "EarningsPerShareDiluted"
    EFFECTOFEXCHANGERATEONCASHCASHEQUIVALENTSRESTRICTEDCASHANDRESTRICTEDCASHEQUIVALENTS = (
        "EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalents"
    )
    EFFECTOFEXCHANGERATEONCASHCASHEQUIVALENTSRESTRICTEDCASHANDRESTRICTEDCASHEQUIVALENTSINCLUDINGDISPOSALGROUPANDDISCONTINUEDOPERATIONS = "EffectOfExchangeRateOnCashCashEquivalentsRestrictedCashAndRestrictedCashEquivalentsIncludingDisposalGroupAndDiscontinuedOperations"
    EMPLOYEERELATEDLIABILITIESCURRENT = "EmployeeRelatedLiabilitiesCurrent"
    EMPLOYEERELATEDLIABILITIESCURRENTANDNONCURRENT = "EmployeeRelatedLiabilitiesCurrentAndNoncurrent"
    EMPLOYEESERVICESHAREBASEDCOMPENSATIONTAXBENEFITFROMCOMPENSATIONEXPENSE = (
        "EmployeeServiceShareBasedCompensationTaxBenefitFromCompensationExpense"
    )
    FINANCELEASEINTERESTEXPENSE = "FinanceLeaseInterestExpense"
    FINANCELEASEINTERESTPAYMENTONLIABILITY = "FinanceLeaseInterestPaymentOnLiability"
    FINANCELEASELIABILITY = "FinanceLeaseLiability"
    FINANCELEASELIABILITYCURRENT = "FinanceLeaseLiabilityCurrent"
    FINANCELEASELIABILITYNONCURRENT = "FinanceLeaseLiabilityNoncurrent"
    FINANCELEASELIABILITYPAYMENTSDUE = "FinanceLeaseLiabilityPaymentsDue"
    FINANCELEASELIABILITYPAYMENTSDUEAFTERYEARFIVE = "FinanceLeaseLiabilityPaymentsDueAfterYearFive"
    FINANCELEASELIABILITYPAYMENTSDUENEXTTWELVEMONTHS = "FinanceLeaseLiabilityPaymentsDueNextTwelveMonths"
    FINANCELEASELIABILITYPAYMENTSDUEYEARFIVE = "FinanceLeaseLiabilityPaymentsDueYearFive"
    FINANCELEASELIABILITYPAYMENTSDUEYEARFOUR = "FinanceLeaseLiabilityPaymentsDueYearFour"
    FINANCELEASELIABILITYPAYMENTSDUEYEARTHREE = "FinanceLeaseLiabilityPaymentsDueYearThree"
    FINANCELEASELIABILITYPAYMENTSDUEYEARTWO = "FinanceLeaseLiabilityPaymentsDueYearTwo"
    FINANCELEASELIABILITYPAYMENTSREMAINDEROFFISCALYEAR = "FinanceLeaseLiabilityPaymentsRemainderOfFiscalYear"
    FINANCELEASELIABILITYUNDISCOUNTEDEXCESSAMOUNT = "FinanceLeaseLiabilityUndiscountedExcessAmount"
    FINANCELEASEPRINCIPALPAYMENTS = "FinanceLeasePrincipalPayments"
    FINANCELEASERIGHTOFUSEASSET = "FinanceLeaseRightOfUseAsset"
    FINANCINGRECEIVABLEALLOWANCEFORCREDITLOSSES = "FinancingReceivableAllowanceForCreditLosses"
    FINITELIVEDINTANGIBLEASSETSNET = "FiniteLivedIntangibleAssetsNet"
    FIXTURESANDEQUIPMENTGROSS = "FixturesAndEquipmentGross"
    GAINLOSSONINVESTMENTS = "GainLossOnInvestments"
    GAINLOSSONINVESTMENTSANDDERIVATIVEINSTRUMENTS = "GainLossOnInvestmentsAndDerivativeInstruments"
    GAINLOSSONSALEOFBUSINESS = "GainLossOnSaleOfBusiness"
    GAINSLOSSESONEXTINGUISHMENTOFDEBT = "GainsLossesOnExtinguishmentOfDebt"
    GENERALANDADMINISTRATIVEEXPENSE = "GeneralAndAdministrativeExpense"
    GOODWILL = "Goodwill"
    GROSSPROFIT = "GrossProfit"
    IMPAIRMENTOFINTANGIBLEASSETSEXCLUDINGGOODWILL = "ImpairmentOfIntangibleAssetsExcludingGoodwill"
    IMPAIRMENTOFINTANGIBLEASSETSINDEFINITELIVEDEXCLUDINGGOODWILL = (
        "ImpairmentOfIntangibleAssetsIndefinitelivedExcludingGoodwill"
    )
    INCOMELOSSFROMCONTINUINGOPERATIONS = "IncomeLossFromContinuingOperations"
    INCOMELOSSFROMCONTINUINGOPERATIONSATTRIBUTABLETONONCONTROLLINGENTITY = (
        "IncomeLossFromContinuingOperationsAttributableToNoncontrollingEntity"
    )
    INCOMELOSSFROMCONTINUINGOPERATIONSBEFOREINCOMETAXESEXTRAORDINARYITEMSNONCONTROLLINGINTEREST = (
        "IncomeLossFromContinuingOperationsBeforeIncomeTaxesExtraordinaryItemsNoncontrollingInterest"
    )
    INCOMELOSSFROMCONTINUINGOPERATIONSPERBASICSHARE = "IncomeLossFromContinuingOperationsPerBasicShare"
    INCOMELOSSFROMCONTINUINGOPERATIONSPERDILUTEDSHARE = "IncomeLossFromContinuingOperationsPerDilutedShare"
    INCOMETAXESPAID = "IncomeTaxesPaid"
    INCOMETAXESPAIDNET = "IncomeTaxesPaidNet"
    INCOMETAXEXPENSEBENEFIT = "IncomeTaxExpenseBenefit"
    INCREASEDECREASEINACCOUNTSANDOTHERRECEIVABLES = "IncreaseDecreaseInAccountsAndOtherReceivables"
    INCREASEDECREASEINACCOUNTSPAYABLE = "IncreaseDecreaseInAccountsPayable"
    INCREASEDECREASEINACCOUNTSRECEIVABLE = "IncreaseDecreaseInAccountsReceivable"
    INCREASEDECREASEINACCRUEDINCOMETAXESPAYABLE = "IncreaseDecreaseInAccruedIncomeTaxesPayable"
    INCREASEDECREASEINACCRUEDLIABILITIES = "IncreaseDecreaseInAccruedLiabilities"
    INCREASEDECREASEINACCRUEDTAXESPAYABLE = "IncreaseDecreaseInAccruedTaxesPayable"
    INCREASEDECREASEINCONTRACTWITHCUSTOMERLIABILITY = "IncreaseDecreaseInContractWithCustomerLiability"
    INCREASEDECREASEINDEFERREDINCOMETAXES = "IncreaseDecreaseInDeferredIncomeTaxes"
    INCREASEDECREASEININVENTORIES = "IncreaseDecreaseInInventories"
    INCREASEDECREASEINOTHERCURRENTASSETS = "IncreaseDecreaseInOtherCurrentAssets"
    INCREASEDECREASEINOTHERCURRENTLIABILITIES = "IncreaseDecreaseInOtherCurrentLiabilities"
    INCREASEDECREASEINOTHERNONCURRENTASSETS = "IncreaseDecreaseInOtherNoncurrentAssets"
    INCREASEDECREASEINOTHERNONCURRENTLIABILITIES = "IncreaseDecreaseInOtherNoncurrentLiabilities"
    INCREASEDECREASEINPENSIONPLANOBLIGATIONS = "IncreaseDecreaseInPensionPlanObligations"
    INCREMENTALCOMMONSHARESATTRIBUTABLETOSHAREBASEDPAYMENTARRANGEMENTS = (
        "IncrementalCommonSharesAttributableToShareBasedPaymentArrangements"
    )
    INTERESTANDDEBTEXPENSE = "InterestAndDebtExpense"
    INTERESTEXPENSEDEBT = "InterestExpenseDebt"
    INTERESTINCOMEEXPENSENET = "InterestIncomeExpenseNet"
    INTERESTPAID = "InterestPaid"
    INTERESTPAIDNET = "InterestPaidNet"
    INVENTORYNET = "InventoryNet"
    INVESTMENTINCOMEINTEREST = "InvestmentIncomeInterest"
    LAND = "Land"
    LEASEANDRENTALEXPENSE = "LeaseAndRentalExpense"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUE = "LesseeOperatingLeaseLiabilityPaymentsDue"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUEAFTERYEARFIVE = "LesseeOperatingLeaseLiabilityPaymentsDueAfterYearFive"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUENEXTTWELVEMONTHS = (
        "LesseeOperatingLeaseLiabilityPaymentsDueNextTwelveMonths"
    )
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUEYEARFIVE = "LesseeOperatingLeaseLiabilityPaymentsDueYearFive"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUEYEARFOUR = "LesseeOperatingLeaseLiabilityPaymentsDueYearFour"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUEYEARTHREE = "LesseeOperatingLeaseLiabilityPaymentsDueYearThree"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSDUEYEARTWO = "LesseeOperatingLeaseLiabilityPaymentsDueYearTwo"
    LESSEEOPERATINGLEASELIABILITYPAYMENTSREMAINDEROFFISCALYEAR = (
        "LesseeOperatingLeaseLiabilityPaymentsRemainderOfFiscalYear"
    )
    LETTERSOFCREDITOUTSTANDINGAMOUNT = "LettersOfCreditOutstandingAmount"
    LIABILITIES = "Liabilities"
    LIABILITIESANDSTOCKHOLDERSEQUITY = "LiabilitiesAndStockholdersEquity"
    LIABILITIESCURRENT = "LiabilitiesCurrent"
    LINEOFCREDIT = "LineOfCredit"
    LINEOFCREDITFACILITYMAXIMUMBORROWINGCAPACITY = "LineOfCreditFacilityMaximumBorrowingCapacity"
    LONGTERMDEBT = "LongTermDebt"
    LONGTERMDEBTCURRENT = "LongTermDebtCurrent"
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALAFTERYEARFIVE = (
        "LongTermDebtMaturitiesRepaymentsOfPrincipalAfterYearFive"
    )
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALINNEXTTWELVEMONTHS = (
        "LongTermDebtMaturitiesRepaymentsOfPrincipalInNextTwelveMonths"
    )
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALINYEARFIVE = "LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFive"
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALINYEARFOUR = "LongTermDebtMaturitiesRepaymentsOfPrincipalInYearFour"
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALINYEARTHREE = "LongTermDebtMaturitiesRepaymentsOfPrincipalInYearThree"
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALINYEARTWO = "LongTermDebtMaturitiesRepaymentsOfPrincipalInYearTwo"
    LONGTERMDEBTMATURITIESREPAYMENTSOFPRINCIPALREMAINDEROFFISCALYEAR = (
        "LongTermDebtMaturitiesRepaymentsOfPrincipalRemainderOfFiscalYear"
    )
    LONGTERMDEBTNONCURRENT = "LongTermDebtNoncurrent"
    LONGTERMINVESTMENTS = "LongTermInvestments"
    LOSSCONTINGENCYESTIMATEOFPOSSIBLELOSS = "LossContingencyEstimateOfPossibleLoss"
    MACHINERYANDEQUIPMENTGROSS = "MachineryAndEquipmentGross"
    MARKETABLESECURITIESCURRENT = "MarketableSecuritiesCurrent"
    MARKETABLESECURITIESNONCURRENT = "MarketableSecuritiesNoncurrent"
    MINORITYINTEREST = "MinorityInterest"
    NETCASHPROVIDEDBYUSEDINFINANCINGACTIVITIES = "NetCashProvidedByUsedInFinancingActivities"
    NETCASHPROVIDEDBYUSEDININVESTINGACTIVITIES = "NetCashProvidedByUsedInInvestingActivities"
    NETCASHPROVIDEDBYUSEDINOPERATINGACTIVITIES = "NetCashProvidedByUsedInOperatingActivities"
    NETINCOMELOSS = "NetIncomeLoss"
    NETINCOMELOSSATTRIBUTABLETONONCONTROLLINGINTEREST = "NetIncomeLossAttributableToNoncontrollingInterest"
    NETINCOMELOSSATTRIBUTABLETONONREDEEMABLENONCONTROLLINGINTEREST = (
        "NetIncomeLossAttributableToNonredeemableNoncontrollingInterest"
    )
    NETINCOMELOSSATTRIBUTABLETOREDEEMABLENONCONTROLLINGINTEREST = (
        "NetIncomeLossAttributableToRedeemableNoncontrollingInterest"
    )
    NONCURRENTASSETS = "NoncurrentAssets"
    NONINTERESTINCOME = "NoninterestIncome"
    NONOPERATINGINCOMEEXPENSE = "NonoperatingIncomeExpense"
    NOTESRECEIVABLENET = "NotesReceivableNet"
    OPERATINGEXPENSES = "OperatingExpenses"
    OPERATINGINCOMELOSS = "OperatingIncomeLoss"
    OPERATINGLEASECOST = "OperatingLeaseCost"
    OPERATINGLEASELIABILITY = "OperatingLeaseLiability"
    OPERATINGLEASELIABILITYCURRENT = "OperatingLeaseLiabilityCurrent"
    OPERATINGLEASELIABILITYNONCURRENT = "OperatingLeaseLiabilityNoncurrent"
    OPERATINGLEASERIGHTOFUSEASSET = "OperatingLeaseRightOfUseAsset"
    OTHERACCRUEDLIABILITIESCURRENT = "OtherAccruedLiabilitiesCurrent"
    OTHERASSETSCURRENT = "OtherAssetsCurrent"
    OTHERASSETSNONCURRENT = "OtherAssetsNoncurrent"
    OTHERCOMPREHENSIVEINCOMELOSSAVAILABLEFORSALESECURITIESADJUSTMENTNETOFTAX = (
        "OtherComprehensiveIncomeLossAvailableForSaleSecuritiesAdjustmentNetOfTax"
    )
    OTHERCOMPREHENSIVEINCOMELOSSCASHFLOWHEDGEGAINLOSSAFTERRECLASSIFICATIONANDTAX = (
        "OtherComprehensiveIncomeLossCashFlowHedgeGainLossAfterReclassificationAndTax"
    )
    OTHERCOMPREHENSIVEINCOMELOSSDERIVATIVEINSTRUMENTGAINLOSSAFTERRECLASSIFICATIONANDTAX = (
        "OtherComprehensiveIncomeLossDerivativeInstrumentGainLossafterReclassificationandTax"
    )
    OTHERCOMPREHENSIVEINCOMELOSSDERIVATIVEINSTRUMENTGAINLOSSBEFORERECLASSIFICATIONAFTERTAX = (
        "OtherComprehensiveIncomeLossDerivativeInstrumentGainLossbeforeReclassificationafterTax"
    )
    OTHERCOMPREHENSIVEINCOMELOSSFOREIGNCURRENCYTRANSACTIONANDTRANSLATIONADJUSTMENTNETOFTAX = (
        "OtherComprehensiveIncomeLossForeignCurrencyTransactionAndTranslationAdjustmentNetOfTax"
    )
    OTHERCOMPREHENSIVEINCOMELOSSNETOFTAX = "OtherComprehensiveIncomeLossNetOfTax"
    OTHERCOMPREHENSIVEINCOMELOSSNETOFTAXPORTIONATTRIBUTABLETOPARENT = (
        "OtherComprehensiveIncomeLossNetOfTaxPortionAttributableToParent"
    )
    OTHERCOMPREHENSIVEINCOMEUNREALIZEDHOLDINGGAINLOSSONSECURITIESARISINGDURINGPERIODNETOFTAX = (
        "OtherComprehensiveIncomeUnrealizedHoldingGainLossOnSecuritiesArisingDuringPeriodNetOfTax"
    )
    OTHERINCOME = "OtherIncome"
    OTHERLIABILITIESCURRENT = "OtherLiabilitiesCurrent"
    OTHERLIABILITIESNONCURRENT = "OtherLiabilitiesNoncurrent"
    OTHERLONGTERMDEBT = "OtherLongTermDebt"
    OTHERNONCASHINCOMEEXPENSE = "OtherNoncashIncomeExpense"
    PAYMENTSFORCAPITALIMPROVEMENTS = "PaymentsForCapitalImprovements"
    PAYMENTSFORPROCEEDSFROMBUSINESSESANDINTERESTINAFFILIATES = (
        "PaymentsForProceedsFromBusinessesAndInterestInAffiliates"
    )
    PAYMENTSFORPROCEEDSFROMOTHERINVESTINGACTIVITIES = "PaymentsForProceedsFromOtherInvestingActivities"
    PAYMENTSFORRENT = "PaymentsForRent"
    PAYMENTSFORREPURCHASEOFCOMMONSTOCK = "PaymentsForRepurchaseOfCommonStock"
    PAYMENTSOFDEBTEXTINGUISHMENTCOSTS = "PaymentsOfDebtExtinguishmentCosts"
    PAYMENTSOFDIVIDENDS = "PaymentsOfDividends"
    PAYMENTSOFDIVIDENDSMINORITYINTEREST = "PaymentsOfDividendsMinorityInterest"
    PAYMENTSTOACQUIREINVESTMENTS = "PaymentsToAcquireInvestments"
    PAYMENTSTOACQUIREPROPERTYPLANTANDEQUIPMENT = "PaymentsToAcquirePropertyPlantAndEquipment"
    PREFERREDSTOCKSHARESOUTSTANDING = "PreferredStockSharesOutstanding"
    PREFERREDSTOCKVALUE = "PreferredStockValue"
    PREPAIDEXPENSEANDOTHERASSETSCURRENT = "PrepaidExpenseAndOtherAssetsCurrent"
    PREPAIDEXPENSECURRENT = "PrepaidExpenseCurrent"
    PROCEEDSFROMDEBTMATURINGINMORETHANTHREEMONTHS = "ProceedsFromDebtMaturingInMoreThanThreeMonths"
    PROCEEDSFROMDEBTNETOFISSUANCECOSTS = "ProceedsFromDebtNetOfIssuanceCosts"
    PROCEEDSFROMDIVESTITUREOFBUSINESSES = "ProceedsFromDivestitureOfBusinesses"
    PROCEEDSFROMINVESTMENTS = "ProceedsFromInvestments"
    PROCEEDSFROMISSUANCEOFCOMMONSTOCK = "ProceedsFromIssuanceOfCommonStock"
    PROCEEDSFROMISSUANCEOFDEBT = "ProceedsFromIssuanceOfDebt"
    PROCEEDSFROMISSUANCEOFLONGTERMDEBT = "ProceedsFromIssuanceOfLongTermDebt"
    PROCEEDSFROMISSUANCEOFUNSECUREDDEBT = "ProceedsFromIssuanceOfUnsecuredDebt"
    PROCEEDSFROMISSUANCEORSALEOFEQUITY = "ProceedsFromIssuanceOrSaleOfEquity"
    PROCEEDSFROMMATURITIESPREPAYMENTSANDCALLSOFAVAILABLEFORSALESECURITIES = (
        "ProceedsFromMaturitiesPrepaymentsAndCallsOfAvailableForSaleSecurities"
    )
    PROCEEDSFROMPAYMENTSFOROTHERFINANCINGACTIVITIES = "ProceedsFromPaymentsForOtherFinancingActivities"
    PROCEEDSFROMPAYMENTSTOMINORITYSHAREHOLDERS = "ProceedsFromPaymentsToMinorityShareholders"
    PROCEEDSFROMREPAYMENTSOFSHORTTERMDEBT = "ProceedsFromRepaymentsOfShortTermDebt"
    PROCEEDSFROMREPAYMENTSOFSHORTTERMDEBTMATURINGINTHREEMONTHSORLESS = (
        "ProceedsFromRepaymentsOfShortTermDebtMaturingInThreeMonthsOrLess"
    )
    PROCEEDSFROMSALEOFPROPERTYPLANTANDEQUIPMENT = "ProceedsFromSaleOfPropertyPlantAndEquipment"
    PROCEEDSFROMSTOCKOPTIONSEXERCISED = "ProceedsFromStockOptionsExercised"
    PROFITLOSS = "ProfitLoss"
    PROPERTYPLANTANDEQUIPMENTGROSS = "PropertyPlantAndEquipmentGross"
    PROPERTYPLANTANDEQUIPMENTNET = "PropertyPlantAndEquipmentNet"
    RECEIVABLESNETCURRENT = "ReceivablesNetCurrent"
    REDEEMABLENONCONTROLLINGINTERESTEQUITYCARRYINGAMOUNT = "RedeemableNoncontrollingInterestEquityCarryingAmount"
    REPAYMENTSOFDEBTMATURINGINMORETHANTHREEMONTHS = "RepaymentsOfDebtMaturingInMoreThanThreeMonths"
    REPAYMENTSOFLONGTERMDEBT = "RepaymentsOfLongTermDebt"
    RESEARCHANDDEVELOPMENTEXPENSE = "ResearchAndDevelopmentExpense"
    RESTRICTEDCASH = "RestrictedCash"
    RESTRICTEDCASHANDCASHEQUIVALENTS = "RestrictedCashAndCashEquivalents"
    RESTRICTEDSTOCKEXPENSE = "RestrictedStockExpense"
    RESTRUCTURINGCHARGES = "RestructuringCharges"
    RETAINEDEARNINGSACCUMULATEDDEFICIT = "RetainedEarningsAccumulatedDeficit"
    REVENUEFROMCONTRACTWITHCUSTOMEREXCLUDINGASSESSEDTAX = "RevenueFromContractWithCustomerExcludingAssessedTax"
    REVENUES = "Revenues"
    SECUREDLONGTERMDEBT = "SecuredLongTermDebt"
    SELLINGANDMARKETINGEXPENSE = "SellingAndMarketingExpense"
    SELLINGGENERALANDADMINISTRATIVEEXPENSE = "SellingGeneralAndAdministrativeExpense"
    SHAREBASEDCOMPENSATION = "ShareBasedCompensation"
    SHORTTERMBORROWINGS = "ShortTermBorrowings"
    SHORTTERMINVESTMENTS = "ShortTermInvestments"
    STOCKHOLDERSEQUITY = "StockholdersEquity"
    STOCKHOLDERSEQUITYINCLUDINGPORTIONATTRIBUTABLETONONCONTROLLINGINTEREST = (
        "StockholdersEquityIncludingPortionAttributableToNoncontrollingInterest"
    )
    STOCKHOLDERSEQUITYOTHER = "StockholdersEquityOther"
    STOCKISSUEDDURINGPERIODVALUENEWISSUES = "StockIssuedDuringPeriodValueNewIssues"
    STOCKOPTIONPLANEXPENSE = "StockOptionPlanExpense"
    STOCKREDEEMEDORCALLEDDURINGPERIODVALUE = "StockRedeemedOrCalledDuringPeriodValue"
    STOCKREPURCHASEDANDRETIREDDURINGPERIODVALUE = "StockRepurchasedAndRetiredDuringPeriodValue"
    STOCKREPURCHASEDDURINGPERIODVALUE = "StockRepurchasedDuringPeriodValue"
    TAXESPAYABLECURRENT = "TaxesPayableCurrent"
    TRADINGSECURITIESDEBT = "TradingSecuritiesDebt"
    TREASURYSTOCKACQUIREDAVERAGECOSTPERSHARE = "TreasuryStockAcquiredAverageCostPerShare"
    TREASURYSTOCKSHARESACQUIRED = "TreasuryStockSharesAcquired"
    UNREALIZEDGAINLOSSONINVESTMENTS = "UnrealizedGainLossOnInvestments"
    UNRECOGNIZEDTAXBENEFITS = "UnrecognizedTaxBenefits"
    UNSECUREDDEBT = "UnsecuredDebt"
    VARIABLELEASECOST = "VariableLeaseCost"
    WEIGHTEDAVERAGENUMBERDILUTEDSHARESOUTSTANDINGADJUSTMENT = "WeightedAverageNumberDilutedSharesOutstandingAdjustment"
    WEIGHTEDAVERAGENUMBEROFDILUTEDSHARESOUTSTANDING = "WeightedAverageNumberOfDilutedSharesOutstanding"
    WEIGHTEDAVERAGENUMBEROFSHARESOUTSTANDINGBASIC = "WeightedAverageNumberOfSharesOutstandingBasic"

    def __str__(self) -> str:
        return str(self.value)
