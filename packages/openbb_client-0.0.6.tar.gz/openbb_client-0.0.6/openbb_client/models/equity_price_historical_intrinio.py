from enum import Enum


class EquityPriceHistoricalIntrinio(str, Enum):
    DELAYED = "delayed"
    NASDAQ_BASIC = "nasdaq_basic"
    REALTIME = "realtime"

    def __str__(self) -> str:
        return str(self.value)
