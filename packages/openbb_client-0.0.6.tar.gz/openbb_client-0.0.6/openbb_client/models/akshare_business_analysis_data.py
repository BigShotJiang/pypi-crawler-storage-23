from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AkshareBusinessAnalysisData")


@_attrs_define
class AkshareBusinessAnalysisData:
    """Akshare Index Business Analysis Data.

    Attributes:
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        report_date (datetime.datetime | None | Unset): The report date for the financial data, e.g., '2024-09-30'.
        main_composition (None | str | Unset): The main composition or product of the financial data, e.g., '茅台酒'
            (Moutai liquor).
        category_type (None | str | Unset): The category or classification type of the financial data, e.g., '按产品分类' (By
            product classification).
        main_revenue (float | None | Unset): The main revenue for the financial period, e.g., 101126021100.0.
        revenue_ratio (float | None | Unset): The ratio of main revenue to total revenue, e.g., 0.837301.
        main_cost (float | None | Unset): The main cost associated with the product or business, e.g., NaN (Not
            available).
        cost_ratio (float | None | Unset): The ratio of main cost to total cost, e.g., NaN (Not available).
        main_profit (float | None | Unset): The main profit for the financial period, e.g., NaN (Not available).
        profit_ratio (float | None | Unset): The ratio of main profit to total profit, e.g., NaN (Not available).
        gross_margin (float | None | Unset): The gross margin for the financial period, e.g., NaN (Not available).
    """

    symbol: None | str | Unset = UNSET
    report_date: datetime.datetime | None | Unset = UNSET
    main_composition: None | str | Unset = UNSET
    category_type: None | str | Unset = UNSET
    main_revenue: float | None | Unset = UNSET
    revenue_ratio: float | None | Unset = UNSET
    main_cost: float | None | Unset = UNSET
    cost_ratio: float | None | Unset = UNSET
    main_profit: float | None | Unset = UNSET
    profit_ratio: float | None | Unset = UNSET
    gross_margin: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        report_date: None | str | Unset
        if isinstance(self.report_date, Unset):
            report_date = UNSET
        elif isinstance(self.report_date, datetime.datetime):
            report_date = self.report_date.isoformat()
        else:
            report_date = self.report_date

        main_composition: None | str | Unset
        if isinstance(self.main_composition, Unset):
            main_composition = UNSET
        else:
            main_composition = self.main_composition

        category_type: None | str | Unset
        if isinstance(self.category_type, Unset):
            category_type = UNSET
        else:
            category_type = self.category_type

        main_revenue: float | None | Unset
        if isinstance(self.main_revenue, Unset):
            main_revenue = UNSET
        else:
            main_revenue = self.main_revenue

        revenue_ratio: float | None | Unset
        if isinstance(self.revenue_ratio, Unset):
            revenue_ratio = UNSET
        else:
            revenue_ratio = self.revenue_ratio

        main_cost: float | None | Unset
        if isinstance(self.main_cost, Unset):
            main_cost = UNSET
        else:
            main_cost = self.main_cost

        cost_ratio: float | None | Unset
        if isinstance(self.cost_ratio, Unset):
            cost_ratio = UNSET
        else:
            cost_ratio = self.cost_ratio

        main_profit: float | None | Unset
        if isinstance(self.main_profit, Unset):
            main_profit = UNSET
        else:
            main_profit = self.main_profit

        profit_ratio: float | None | Unset
        if isinstance(self.profit_ratio, Unset):
            profit_ratio = UNSET
        else:
            profit_ratio = self.profit_ratio

        gross_margin: float | None | Unset
        if isinstance(self.gross_margin, Unset):
            gross_margin = UNSET
        else:
            gross_margin = self.gross_margin

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if report_date is not UNSET:
            field_dict["report_date"] = report_date
        if main_composition is not UNSET:
            field_dict["main_composition"] = main_composition
        if category_type is not UNSET:
            field_dict["category_type"] = category_type
        if main_revenue is not UNSET:
            field_dict["main_revenue"] = main_revenue
        if revenue_ratio is not UNSET:
            field_dict["revenue_ratio"] = revenue_ratio
        if main_cost is not UNSET:
            field_dict["main_cost"] = main_cost
        if cost_ratio is not UNSET:
            field_dict["cost_ratio"] = cost_ratio
        if main_profit is not UNSET:
            field_dict["main_profit"] = main_profit
        if profit_ratio is not UNSET:
            field_dict["profit_ratio"] = profit_ratio
        if gross_margin is not UNSET:
            field_dict["gross_margin"] = gross_margin

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_report_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                report_date_type_0 = isoparse(data)

                return report_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        report_date = _parse_report_date(d.pop("report_date", UNSET))

        def _parse_main_composition(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        main_composition = _parse_main_composition(d.pop("main_composition", UNSET))

        def _parse_category_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        category_type = _parse_category_type(d.pop("category_type", UNSET))

        def _parse_main_revenue(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        main_revenue = _parse_main_revenue(d.pop("main_revenue", UNSET))

        def _parse_revenue_ratio(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        revenue_ratio = _parse_revenue_ratio(d.pop("revenue_ratio", UNSET))

        def _parse_main_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        main_cost = _parse_main_cost(d.pop("main_cost", UNSET))

        def _parse_cost_ratio(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cost_ratio = _parse_cost_ratio(d.pop("cost_ratio", UNSET))

        def _parse_main_profit(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        main_profit = _parse_main_profit(d.pop("main_profit", UNSET))

        def _parse_profit_ratio(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        profit_ratio = _parse_profit_ratio(d.pop("profit_ratio", UNSET))

        def _parse_gross_margin(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        gross_margin = _parse_gross_margin(d.pop("gross_margin", UNSET))

        akshare_business_analysis_data = cls(
            symbol=symbol,
            report_date=report_date,
            main_composition=main_composition,
            category_type=category_type,
            main_revenue=main_revenue,
            revenue_ratio=revenue_ratio,
            main_cost=main_cost,
            cost_ratio=cost_ratio,
            main_profit=main_profit,
            profit_ratio=profit_ratio,
            gross_margin=gross_margin,
        )

        akshare_business_analysis_data.additional_properties = d
        return akshare_business_analysis_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
