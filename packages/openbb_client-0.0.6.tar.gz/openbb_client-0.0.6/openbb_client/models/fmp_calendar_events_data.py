from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FmpCalendarEventsData")


@_attrs_define
class FmpCalendarEventsData:
    """FMP Company Events Calendar Data.

    Attributes:
        date (datetime.date): The date of the data. The date of the event.
        symbol (str): Symbol representing the entity requested in the data.
        exchange (None | str | Unset): Exchange where the symbol is listed.
        time (None | str | Unset): The estimated time of the event, local to the exchange.
        timing (None | str | Unset): The timing of the event - e.g. before, during, or after market hours.
        description (None | str | Unset): The title of the event.
        url (None | str | Unset): The URL to the press release for the announcement.
        announcement_date (datetime.date | None | Unset): The date when the event was announced.
    """

    date: datetime.date
    symbol: str
    exchange: None | str | Unset = UNSET
    time: None | str | Unset = UNSET
    timing: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    url: None | str | Unset = UNSET
    announcement_date: datetime.date | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        symbol = self.symbol

        exchange: None | str | Unset
        if isinstance(self.exchange, Unset):
            exchange = UNSET
        else:
            exchange = self.exchange

        time: None | str | Unset
        if isinstance(self.time, Unset):
            time = UNSET
        else:
            time = self.time

        timing: None | str | Unset
        if isinstance(self.timing, Unset):
            timing = UNSET
        else:
            timing = self.timing

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        url: None | str | Unset
        if isinstance(self.url, Unset):
            url = UNSET
        else:
            url = self.url

        announcement_date: None | str | Unset
        if isinstance(self.announcement_date, Unset):
            announcement_date = UNSET
        elif isinstance(self.announcement_date, datetime.date):
            announcement_date = self.announcement_date.isoformat()
        else:
            announcement_date = self.announcement_date

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "symbol": symbol,
            }
        )
        if exchange is not UNSET:
            field_dict["exchange"] = exchange
        if time is not UNSET:
            field_dict["time"] = time
        if timing is not UNSET:
            field_dict["timing"] = timing
        if description is not UNSET:
            field_dict["description"] = description
        if url is not UNSET:
            field_dict["url"] = url
        if announcement_date is not UNSET:
            field_dict["announcement_date"] = announcement_date

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        symbol = d.pop("symbol")

        def _parse_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        exchange = _parse_exchange(d.pop("exchange", UNSET))

        def _parse_time(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        time = _parse_time(d.pop("time", UNSET))

        def _parse_timing(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        timing = _parse_timing(d.pop("timing", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        url = _parse_url(d.pop("url", UNSET))

        def _parse_announcement_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                announcement_date_type_0 = isoparse(data).date()

                return announcement_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        announcement_date = _parse_announcement_date(d.pop("announcement_date", UNSET))

        fmp_calendar_events_data = cls(
            date=date,
            symbol=symbol,
            exchange=exchange,
            time=time,
            timing=timing,
            description=description,
            url=url,
            announcement_date=announcement_date,
        )

        fmp_calendar_events_data.additional_properties = d
        return fmp_calendar_events_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
