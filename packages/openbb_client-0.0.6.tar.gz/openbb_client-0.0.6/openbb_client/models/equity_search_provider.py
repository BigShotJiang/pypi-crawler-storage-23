from enum import Enum


class EquitySearchProvider(str, Enum):
    AKSHARE = "akshare"
    INTRINIO = "intrinio"
    SEC = "sec"

    def __str__(self) -> str:
        return str(self.value)
