from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareEquityProfileData")


@_attrs_define
class AKShareEquityProfileData:
    """AKShare Equity Profile Data.

    Attributes:
        symbol (str): Symbol representing the entity requested in the data.
        name (None | str | Unset): Common name of the company.
        cik (None | str | Unset): Central Index Key (CIK) for the requested entity.
        cusip (None | str | Unset): CUSIP identifier for the company.
        isin (None | str | Unset): International Securities Identification Number.
        lei (None | str | Unset): Legal Entity Identifier assigned to the company.
        legal_name (None | str | Unset): Official legal name of the company.
        stock_exchange (None | str | Unset): Stock exchange where the company is traded.
        sic (int | None | Unset): Standard Industrial Classification code for the company.
        short_description (None | str | Unset): Short description of the company.
        long_description (None | str | Unset): Long description of the company.
        ceo (None | str | Unset): Chief Executive Officer of the company.
        company_url (None | str | Unset): URL of the company's website.
        business_address (None | str | Unset): Address of the company's headquarters.
        mailing_address (None | str | Unset): Mailing address of the company.
        business_phone_no (None | str | Unset): Phone number of the company's headquarters.
        hq_address_1 (None | str | Unset): Address of the company's headquarters.
        hq_address_2 (None | str | Unset): Address of the company's headquarters.
        hq_address_city (None | str | Unset): City of the company's headquarters.
        hq_address_postal_code (None | str | Unset): Zip code of the company's headquarters.
        hq_state (None | str | Unset): State of the company's headquarters.
        hq_country (None | str | Unset): Country of the company's headquarters.
        inc_state (None | str | Unset): State in which the company is incorporated.
        inc_country (None | str | Unset): Country in which the company is incorporated.
        employees (int | None | Unset): Number of employees working for the company.
        entity_legal_form (None | str | Unset): Legal form of the company.
        entity_status (None | str | Unset): Status of the company.
        latest_filing_date (datetime.date | None | Unset): Date of the company's latest filing.
        irs_number (None | str | Unset): IRS number assigned to the company.
        sector (None | str | Unset): Sector in which the company operates.
        industry_category (None | str | Unset): Category of industry in which the company operates.
        industry_group (None | str | Unset): Group of industry in which the company operates.
        template (None | str | Unset): Template used to standardize the company's financial statements.
        standardized_active (bool | None | Unset): Whether the company is active or not.
        first_fundamental_date (datetime.date | None | Unset): Date of the company's first fundamental.
        last_fundamental_date (datetime.date | None | Unset): Date of the company's last fundamental.
        first_stock_price_date (datetime.date | None | Unset): Date of the company's first stock price.
        last_stock_price_date (datetime.date | None | Unset): Date of the company's last stock price.
        公司名称 (None | str | Unset): Alias of org_name_cn.
        公司简介 (None | str | Unset): Alias of org_name_cn.
        主要范围 (None | str | Unset): Alias of org_name_cn.
        上市日期 (datetime.date | None | Unset): Date of the establishment.
        org_name_cn (None | str | Unset): Chinese name of the asset.
        org_short_name_cn (None | str | Unset): Short Chinese name of the asset.
        org_short_name_en (None | str | Unset): Short English name of the asset.
        org_id (None | str | Unset): The number of listed shares outstanding.
        established_date (datetime.date | None | Unset): Date of the establishment.
        actual_issue_vol (int | None | Unset): The number of shares in the public float.
        reg_asset (float | None | Unset): 总股本（股）
        issue_price (float | None | Unset): 发行价格.
        currency (None | str | Unset): The currency in which the asset is traded.
    """

    symbol: str
    name: None | str | Unset = UNSET
    cik: None | str | Unset = UNSET
    cusip: None | str | Unset = UNSET
    isin: None | str | Unset = UNSET
    lei: None | str | Unset = UNSET
    legal_name: None | str | Unset = UNSET
    stock_exchange: None | str | Unset = UNSET
    sic: int | None | Unset = UNSET
    short_description: None | str | Unset = UNSET
    long_description: None | str | Unset = UNSET
    ceo: None | str | Unset = UNSET
    company_url: None | str | Unset = UNSET
    business_address: None | str | Unset = UNSET
    mailing_address: None | str | Unset = UNSET
    business_phone_no: None | str | Unset = UNSET
    hq_address_1: None | str | Unset = UNSET
    hq_address_2: None | str | Unset = UNSET
    hq_address_city: None | str | Unset = UNSET
    hq_address_postal_code: None | str | Unset = UNSET
    hq_state: None | str | Unset = UNSET
    hq_country: None | str | Unset = UNSET
    inc_state: None | str | Unset = UNSET
    inc_country: None | str | Unset = UNSET
    employees: int | None | Unset = UNSET
    entity_legal_form: None | str | Unset = UNSET
    entity_status: None | str | Unset = UNSET
    latest_filing_date: datetime.date | None | Unset = UNSET
    irs_number: None | str | Unset = UNSET
    sector: None | str | Unset = UNSET
    industry_category: None | str | Unset = UNSET
    industry_group: None | str | Unset = UNSET
    template: None | str | Unset = UNSET
    standardized_active: bool | None | Unset = UNSET
    first_fundamental_date: datetime.date | None | Unset = UNSET
    last_fundamental_date: datetime.date | None | Unset = UNSET
    first_stock_price_date: datetime.date | None | Unset = UNSET
    last_stock_price_date: datetime.date | None | Unset = UNSET
    公司名称: None | str | Unset = UNSET
    公司简介: None | str | Unset = UNSET
    主要范围: None | str | Unset = UNSET
    上市日期: datetime.date | None | Unset = UNSET
    org_name_cn: None | str | Unset = UNSET
    org_short_name_cn: None | str | Unset = UNSET
    org_short_name_en: None | str | Unset = UNSET
    org_id: None | str | Unset = UNSET
    established_date: datetime.date | None | Unset = UNSET
    actual_issue_vol: int | None | Unset = UNSET
    reg_asset: float | None | Unset = UNSET
    issue_price: float | None | Unset = UNSET
    currency: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol = self.symbol

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        cik: None | str | Unset
        if isinstance(self.cik, Unset):
            cik = UNSET
        else:
            cik = self.cik

        cusip: None | str | Unset
        if isinstance(self.cusip, Unset):
            cusip = UNSET
        else:
            cusip = self.cusip

        isin: None | str | Unset
        if isinstance(self.isin, Unset):
            isin = UNSET
        else:
            isin = self.isin

        lei: None | str | Unset
        if isinstance(self.lei, Unset):
            lei = UNSET
        else:
            lei = self.lei

        legal_name: None | str | Unset
        if isinstance(self.legal_name, Unset):
            legal_name = UNSET
        else:
            legal_name = self.legal_name

        stock_exchange: None | str | Unset
        if isinstance(self.stock_exchange, Unset):
            stock_exchange = UNSET
        else:
            stock_exchange = self.stock_exchange

        sic: int | None | Unset
        if isinstance(self.sic, Unset):
            sic = UNSET
        else:
            sic = self.sic

        short_description: None | str | Unset
        if isinstance(self.short_description, Unset):
            short_description = UNSET
        else:
            short_description = self.short_description

        long_description: None | str | Unset
        if isinstance(self.long_description, Unset):
            long_description = UNSET
        else:
            long_description = self.long_description

        ceo: None | str | Unset
        if isinstance(self.ceo, Unset):
            ceo = UNSET
        else:
            ceo = self.ceo

        company_url: None | str | Unset
        if isinstance(self.company_url, Unset):
            company_url = UNSET
        else:
            company_url = self.company_url

        business_address: None | str | Unset
        if isinstance(self.business_address, Unset):
            business_address = UNSET
        else:
            business_address = self.business_address

        mailing_address: None | str | Unset
        if isinstance(self.mailing_address, Unset):
            mailing_address = UNSET
        else:
            mailing_address = self.mailing_address

        business_phone_no: None | str | Unset
        if isinstance(self.business_phone_no, Unset):
            business_phone_no = UNSET
        else:
            business_phone_no = self.business_phone_no

        hq_address_1: None | str | Unset
        if isinstance(self.hq_address_1, Unset):
            hq_address_1 = UNSET
        else:
            hq_address_1 = self.hq_address_1

        hq_address_2: None | str | Unset
        if isinstance(self.hq_address_2, Unset):
            hq_address_2 = UNSET
        else:
            hq_address_2 = self.hq_address_2

        hq_address_city: None | str | Unset
        if isinstance(self.hq_address_city, Unset):
            hq_address_city = UNSET
        else:
            hq_address_city = self.hq_address_city

        hq_address_postal_code: None | str | Unset
        if isinstance(self.hq_address_postal_code, Unset):
            hq_address_postal_code = UNSET
        else:
            hq_address_postal_code = self.hq_address_postal_code

        hq_state: None | str | Unset
        if isinstance(self.hq_state, Unset):
            hq_state = UNSET
        else:
            hq_state = self.hq_state

        hq_country: None | str | Unset
        if isinstance(self.hq_country, Unset):
            hq_country = UNSET
        else:
            hq_country = self.hq_country

        inc_state: None | str | Unset
        if isinstance(self.inc_state, Unset):
            inc_state = UNSET
        else:
            inc_state = self.inc_state

        inc_country: None | str | Unset
        if isinstance(self.inc_country, Unset):
            inc_country = UNSET
        else:
            inc_country = self.inc_country

        employees: int | None | Unset
        if isinstance(self.employees, Unset):
            employees = UNSET
        else:
            employees = self.employees

        entity_legal_form: None | str | Unset
        if isinstance(self.entity_legal_form, Unset):
            entity_legal_form = UNSET
        else:
            entity_legal_form = self.entity_legal_form

        entity_status: None | str | Unset
        if isinstance(self.entity_status, Unset):
            entity_status = UNSET
        else:
            entity_status = self.entity_status

        latest_filing_date: None | str | Unset
        if isinstance(self.latest_filing_date, Unset):
            latest_filing_date = UNSET
        elif isinstance(self.latest_filing_date, datetime.date):
            latest_filing_date = self.latest_filing_date.isoformat()
        else:
            latest_filing_date = self.latest_filing_date

        irs_number: None | str | Unset
        if isinstance(self.irs_number, Unset):
            irs_number = UNSET
        else:
            irs_number = self.irs_number

        sector: None | str | Unset
        if isinstance(self.sector, Unset):
            sector = UNSET
        else:
            sector = self.sector

        industry_category: None | str | Unset
        if isinstance(self.industry_category, Unset):
            industry_category = UNSET
        else:
            industry_category = self.industry_category

        industry_group: None | str | Unset
        if isinstance(self.industry_group, Unset):
            industry_group = UNSET
        else:
            industry_group = self.industry_group

        template: None | str | Unset
        if isinstance(self.template, Unset):
            template = UNSET
        else:
            template = self.template

        standardized_active: bool | None | Unset
        if isinstance(self.standardized_active, Unset):
            standardized_active = UNSET
        else:
            standardized_active = self.standardized_active

        first_fundamental_date: None | str | Unset
        if isinstance(self.first_fundamental_date, Unset):
            first_fundamental_date = UNSET
        elif isinstance(self.first_fundamental_date, datetime.date):
            first_fundamental_date = self.first_fundamental_date.isoformat()
        else:
            first_fundamental_date = self.first_fundamental_date

        last_fundamental_date: None | str | Unset
        if isinstance(self.last_fundamental_date, Unset):
            last_fundamental_date = UNSET
        elif isinstance(self.last_fundamental_date, datetime.date):
            last_fundamental_date = self.last_fundamental_date.isoformat()
        else:
            last_fundamental_date = self.last_fundamental_date

        first_stock_price_date: None | str | Unset
        if isinstance(self.first_stock_price_date, Unset):
            first_stock_price_date = UNSET
        elif isinstance(self.first_stock_price_date, datetime.date):
            first_stock_price_date = self.first_stock_price_date.isoformat()
        else:
            first_stock_price_date = self.first_stock_price_date

        last_stock_price_date: None | str | Unset
        if isinstance(self.last_stock_price_date, Unset):
            last_stock_price_date = UNSET
        elif isinstance(self.last_stock_price_date, datetime.date):
            last_stock_price_date = self.last_stock_price_date.isoformat()
        else:
            last_stock_price_date = self.last_stock_price_date

        公司名称: None | str | Unset
        if isinstance(self.公司名称, Unset):
            公司名称 = UNSET
        else:
            公司名称 = self.公司名称

        公司简介: None | str | Unset
        if isinstance(self.公司简介, Unset):
            公司简介 = UNSET
        else:
            公司简介 = self.公司简介

        主要范围: None | str | Unset
        if isinstance(self.主要范围, Unset):
            主要范围 = UNSET
        else:
            主要范围 = self.主要范围

        上市日期: None | str | Unset
        if isinstance(self.上市日期, Unset):
            上市日期 = UNSET
        elif isinstance(self.上市日期, datetime.date):
            上市日期 = self.上市日期.isoformat()
        else:
            上市日期 = self.上市日期

        org_name_cn: None | str | Unset
        if isinstance(self.org_name_cn, Unset):
            org_name_cn = UNSET
        else:
            org_name_cn = self.org_name_cn

        org_short_name_cn: None | str | Unset
        if isinstance(self.org_short_name_cn, Unset):
            org_short_name_cn = UNSET
        else:
            org_short_name_cn = self.org_short_name_cn

        org_short_name_en: None | str | Unset
        if isinstance(self.org_short_name_en, Unset):
            org_short_name_en = UNSET
        else:
            org_short_name_en = self.org_short_name_en

        org_id: None | str | Unset
        if isinstance(self.org_id, Unset):
            org_id = UNSET
        else:
            org_id = self.org_id

        established_date: None | str | Unset
        if isinstance(self.established_date, Unset):
            established_date = UNSET
        elif isinstance(self.established_date, datetime.date):
            established_date = self.established_date.isoformat()
        else:
            established_date = self.established_date

        actual_issue_vol: int | None | Unset
        if isinstance(self.actual_issue_vol, Unset):
            actual_issue_vol = UNSET
        else:
            actual_issue_vol = self.actual_issue_vol

        reg_asset: float | None | Unset
        if isinstance(self.reg_asset, Unset):
            reg_asset = UNSET
        else:
            reg_asset = self.reg_asset

        issue_price: float | None | Unset
        if isinstance(self.issue_price, Unset):
            issue_price = UNSET
        else:
            issue_price = self.issue_price

        currency: None | str | Unset
        if isinstance(self.currency, Unset):
            currency = UNSET
        else:
            currency = self.currency

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "symbol": symbol,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if cik is not UNSET:
            field_dict["cik"] = cik
        if cusip is not UNSET:
            field_dict["cusip"] = cusip
        if isin is not UNSET:
            field_dict["isin"] = isin
        if lei is not UNSET:
            field_dict["lei"] = lei
        if legal_name is not UNSET:
            field_dict["legal_name"] = legal_name
        if stock_exchange is not UNSET:
            field_dict["stock_exchange"] = stock_exchange
        if sic is not UNSET:
            field_dict["sic"] = sic
        if short_description is not UNSET:
            field_dict["short_description"] = short_description
        if long_description is not UNSET:
            field_dict["long_description"] = long_description
        if ceo is not UNSET:
            field_dict["ceo"] = ceo
        if company_url is not UNSET:
            field_dict["company_url"] = company_url
        if business_address is not UNSET:
            field_dict["business_address"] = business_address
        if mailing_address is not UNSET:
            field_dict["mailing_address"] = mailing_address
        if business_phone_no is not UNSET:
            field_dict["business_phone_no"] = business_phone_no
        if hq_address_1 is not UNSET:
            field_dict["hq_address_1"] = hq_address_1
        if hq_address_2 is not UNSET:
            field_dict["hq_address_2"] = hq_address_2
        if hq_address_city is not UNSET:
            field_dict["hq_address_city"] = hq_address_city
        if hq_address_postal_code is not UNSET:
            field_dict["hq_address_postal_code"] = hq_address_postal_code
        if hq_state is not UNSET:
            field_dict["hq_state"] = hq_state
        if hq_country is not UNSET:
            field_dict["hq_country"] = hq_country
        if inc_state is not UNSET:
            field_dict["inc_state"] = inc_state
        if inc_country is not UNSET:
            field_dict["inc_country"] = inc_country
        if employees is not UNSET:
            field_dict["employees"] = employees
        if entity_legal_form is not UNSET:
            field_dict["entity_legal_form"] = entity_legal_form
        if entity_status is not UNSET:
            field_dict["entity_status"] = entity_status
        if latest_filing_date is not UNSET:
            field_dict["latest_filing_date"] = latest_filing_date
        if irs_number is not UNSET:
            field_dict["irs_number"] = irs_number
        if sector is not UNSET:
            field_dict["sector"] = sector
        if industry_category is not UNSET:
            field_dict["industry_category"] = industry_category
        if industry_group is not UNSET:
            field_dict["industry_group"] = industry_group
        if template is not UNSET:
            field_dict["template"] = template
        if standardized_active is not UNSET:
            field_dict["standardized_active"] = standardized_active
        if first_fundamental_date is not UNSET:
            field_dict["first_fundamental_date"] = first_fundamental_date
        if last_fundamental_date is not UNSET:
            field_dict["last_fundamental_date"] = last_fundamental_date
        if first_stock_price_date is not UNSET:
            field_dict["first_stock_price_date"] = first_stock_price_date
        if last_stock_price_date is not UNSET:
            field_dict["last_stock_price_date"] = last_stock_price_date
        if 公司名称 is not UNSET:
            field_dict["公司名称"] = 公司名称
        if 公司简介 is not UNSET:
            field_dict["公司简介"] = 公司简介
        if 主要范围 is not UNSET:
            field_dict["主要范围"] = 主要范围
        if 上市日期 is not UNSET:
            field_dict["上市日期"] = 上市日期
        if org_name_cn is not UNSET:
            field_dict["org_name_cn"] = org_name_cn
        if org_short_name_cn is not UNSET:
            field_dict["org_short_name_cn"] = org_short_name_cn
        if org_short_name_en is not UNSET:
            field_dict["org_short_name_en"] = org_short_name_en
        if org_id is not UNSET:
            field_dict["org_id"] = org_id
        if established_date is not UNSET:
            field_dict["established_date"] = established_date
        if actual_issue_vol is not UNSET:
            field_dict["actual_issue_vol"] = actual_issue_vol
        if reg_asset is not UNSET:
            field_dict["reg_asset"] = reg_asset
        if issue_price is not UNSET:
            field_dict["issue_price"] = issue_price
        if currency is not UNSET:
            field_dict["currency"] = currency

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        symbol = d.pop("symbol")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_cik(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cik = _parse_cik(d.pop("cik", UNSET))

        def _parse_cusip(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cusip = _parse_cusip(d.pop("cusip", UNSET))

        def _parse_isin(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        isin = _parse_isin(d.pop("isin", UNSET))

        def _parse_lei(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        lei = _parse_lei(d.pop("lei", UNSET))

        def _parse_legal_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        legal_name = _parse_legal_name(d.pop("legal_name", UNSET))

        def _parse_stock_exchange(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stock_exchange = _parse_stock_exchange(d.pop("stock_exchange", UNSET))

        def _parse_sic(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        sic = _parse_sic(d.pop("sic", UNSET))

        def _parse_short_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        short_description = _parse_short_description(d.pop("short_description", UNSET))

        def _parse_long_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        long_description = _parse_long_description(d.pop("long_description", UNSET))

        def _parse_ceo(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ceo = _parse_ceo(d.pop("ceo", UNSET))

        def _parse_company_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        company_url = _parse_company_url(d.pop("company_url", UNSET))

        def _parse_business_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        business_address = _parse_business_address(d.pop("business_address", UNSET))

        def _parse_mailing_address(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        mailing_address = _parse_mailing_address(d.pop("mailing_address", UNSET))

        def _parse_business_phone_no(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        business_phone_no = _parse_business_phone_no(d.pop("business_phone_no", UNSET))

        def _parse_hq_address_1(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_address_1 = _parse_hq_address_1(d.pop("hq_address_1", UNSET))

        def _parse_hq_address_2(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_address_2 = _parse_hq_address_2(d.pop("hq_address_2", UNSET))

        def _parse_hq_address_city(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_address_city = _parse_hq_address_city(d.pop("hq_address_city", UNSET))

        def _parse_hq_address_postal_code(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_address_postal_code = _parse_hq_address_postal_code(d.pop("hq_address_postal_code", UNSET))

        def _parse_hq_state(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_state = _parse_hq_state(d.pop("hq_state", UNSET))

        def _parse_hq_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hq_country = _parse_hq_country(d.pop("hq_country", UNSET))

        def _parse_inc_state(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        inc_state = _parse_inc_state(d.pop("inc_state", UNSET))

        def _parse_inc_country(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        inc_country = _parse_inc_country(d.pop("inc_country", UNSET))

        def _parse_employees(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        employees = _parse_employees(d.pop("employees", UNSET))

        def _parse_entity_legal_form(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        entity_legal_form = _parse_entity_legal_form(d.pop("entity_legal_form", UNSET))

        def _parse_entity_status(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        entity_status = _parse_entity_status(d.pop("entity_status", UNSET))

        def _parse_latest_filing_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                latest_filing_date_type_0 = isoparse(data).date()

                return latest_filing_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        latest_filing_date = _parse_latest_filing_date(d.pop("latest_filing_date", UNSET))

        def _parse_irs_number(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        irs_number = _parse_irs_number(d.pop("irs_number", UNSET))

        def _parse_sector(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        sector = _parse_sector(d.pop("sector", UNSET))

        def _parse_industry_category(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        industry_category = _parse_industry_category(d.pop("industry_category", UNSET))

        def _parse_industry_group(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        industry_group = _parse_industry_group(d.pop("industry_group", UNSET))

        def _parse_template(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        template = _parse_template(d.pop("template", UNSET))

        def _parse_standardized_active(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        standardized_active = _parse_standardized_active(d.pop("standardized_active", UNSET))

        def _parse_first_fundamental_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                first_fundamental_date_type_0 = isoparse(data).date()

                return first_fundamental_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        first_fundamental_date = _parse_first_fundamental_date(d.pop("first_fundamental_date", UNSET))

        def _parse_last_fundamental_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_fundamental_date_type_0 = isoparse(data).date()

                return last_fundamental_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        last_fundamental_date = _parse_last_fundamental_date(d.pop("last_fundamental_date", UNSET))

        def _parse_first_stock_price_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                first_stock_price_date_type_0 = isoparse(data).date()

                return first_stock_price_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        first_stock_price_date = _parse_first_stock_price_date(d.pop("first_stock_price_date", UNSET))

        def _parse_last_stock_price_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_stock_price_date_type_0 = isoparse(data).date()

                return last_stock_price_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        last_stock_price_date = _parse_last_stock_price_date(d.pop("last_stock_price_date", UNSET))

        def _parse_公司名称(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        公司名称 = _parse_公司名称(d.pop("公司名称", UNSET))

        def _parse_公司简介(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        公司简介 = _parse_公司简介(d.pop("公司简介", UNSET))

        def _parse_主要范围(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        主要范围 = _parse_主要范围(d.pop("主要范围", UNSET))

        def _parse_上市日期(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                上市日期_type_0 = isoparse(data).date()

                return 上市日期_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        上市日期 = _parse_上市日期(d.pop("上市日期", UNSET))

        def _parse_org_name_cn(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        org_name_cn = _parse_org_name_cn(d.pop("org_name_cn", UNSET))

        def _parse_org_short_name_cn(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        org_short_name_cn = _parse_org_short_name_cn(d.pop("org_short_name_cn", UNSET))

        def _parse_org_short_name_en(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        org_short_name_en = _parse_org_short_name_en(d.pop("org_short_name_en", UNSET))

        def _parse_org_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        org_id = _parse_org_id(d.pop("org_id", UNSET))

        def _parse_established_date(data: object) -> datetime.date | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                established_date_type_0 = isoparse(data).date()

                return established_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.date | None | Unset, data)

        established_date = _parse_established_date(d.pop("established_date", UNSET))

        def _parse_actual_issue_vol(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        actual_issue_vol = _parse_actual_issue_vol(d.pop("actual_issue_vol", UNSET))

        def _parse_reg_asset(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        reg_asset = _parse_reg_asset(d.pop("reg_asset", UNSET))

        def _parse_issue_price(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        issue_price = _parse_issue_price(d.pop("issue_price", UNSET))

        def _parse_currency(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        currency = _parse_currency(d.pop("currency", UNSET))

        ak_share_equity_profile_data = cls(
            symbol=symbol,
            name=name,
            cik=cik,
            cusip=cusip,
            isin=isin,
            lei=lei,
            legal_name=legal_name,
            stock_exchange=stock_exchange,
            sic=sic,
            short_description=short_description,
            long_description=long_description,
            ceo=ceo,
            company_url=company_url,
            business_address=business_address,
            mailing_address=mailing_address,
            business_phone_no=business_phone_no,
            hq_address_1=hq_address_1,
            hq_address_2=hq_address_2,
            hq_address_city=hq_address_city,
            hq_address_postal_code=hq_address_postal_code,
            hq_state=hq_state,
            hq_country=hq_country,
            inc_state=inc_state,
            inc_country=inc_country,
            employees=employees,
            entity_legal_form=entity_legal_form,
            entity_status=entity_status,
            latest_filing_date=latest_filing_date,
            irs_number=irs_number,
            sector=sector,
            industry_category=industry_category,
            industry_group=industry_group,
            template=template,
            standardized_active=standardized_active,
            first_fundamental_date=first_fundamental_date,
            last_fundamental_date=last_fundamental_date,
            first_stock_price_date=first_stock_price_date,
            last_stock_price_date=last_stock_price_date,
            公司名称=公司名称,
            公司简介=公司简介,
            主要范围=主要范围,
            上市日期=上市日期,
            org_name_cn=org_name_cn,
            org_short_name_cn=org_short_name_cn,
            org_short_name_en=org_short_name_en,
            org_id=org_id,
            established_date=established_date,
            actual_issue_vol=actual_issue_vol,
            reg_asset=reg_asset,
            issue_price=issue_price,
            currency=currency,
        )

        ak_share_equity_profile_data.additional_properties = d
        return ak_share_equity_profile_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
