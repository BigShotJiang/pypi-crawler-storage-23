from enum import Enum


class EconomySurveyUniversityOfMichiganFrequencyType0(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"

    def __str__(self) -> str:
        return str(self.value)
