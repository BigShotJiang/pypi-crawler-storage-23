from enum import Enum


class EconomyCalendarGroupType0(str, Enum):
    BONDS = "bonds"
    BUSINESS = "business"
    CONSUMER = "consumer"
    GDP = "gdp"
    GOVERNMENT = "government"
    HOUSING = "housing"
    INFLATION = "inflation"
    INTEREST_RATE = "interest_rate"
    LABOUR = "labour"
    MARKETS = "markets"
    MONEY = "money"
    PRICES = "prices"
    TRADE = "trade"

    def __str__(self) -> str:
        return str(self.value)
