from enum import Enum


class EquityPriceHistoricalAdjustmentType0(str, Enum):
    SPLITS_AND_DIVIDENDS = "splits_and_dividends"
    SPLITS_ONLY = "splits_only"
    UNADJUSTED = "unadjusted"

    def __str__(self) -> str:
        return str(self.value)
