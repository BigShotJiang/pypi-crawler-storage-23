from enum import Enum


class FixedincomeCorporateCommercialPaperMaturityType1(str, Enum):
    ALL = "all"
    OVERNIGHT = "overnight"
    VALUE_2 = "7d"
    VALUE_3 = "15d"
    VALUE_4 = "30d"
    VALUE_5 = "60d"
    VALUE_6 = "90d"

    def __str__(self) -> str:
        return str(self.value)
