from enum import Enum


class EquityPriceHistoricalAdjustmentType1(str, Enum):
    SPLITS_ONLY = "splits_only"
    UNADJUSTED = "unadjusted"

    def __str__(self) -> str:
        return str(self.value)
