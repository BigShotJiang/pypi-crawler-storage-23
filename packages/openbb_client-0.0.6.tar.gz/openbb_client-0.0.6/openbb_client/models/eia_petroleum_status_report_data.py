from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="EiaPetroleumStatusReportData")


@_attrs_define
class EiaPetroleumStatusReportData:
    """EIA Petroleum Status Report Data Model.

    Attributes:
        date (datetime.date): The date of the data.
        table (None | str): Table name for the data.
        symbol (str): Symbol representing the entity requested in the data.
        value (float | int): Value of the data.
        order (int | None | Unset): Presented order of the data, relative to the table.
        title (None | str | Unset): Title of the data.
        unit (None | str | Unset): Unit or scale of the data.
    """

    date: datetime.date
    table: None | str
    symbol: str
    value: float | int
    order: int | None | Unset = UNSET
    title: None | str | Unset = UNSET
    unit: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        table: None | str
        table = self.table

        symbol = self.symbol

        value: float | int
        value = self.value

        order: int | None | Unset
        if isinstance(self.order, Unset):
            order = UNSET
        else:
            order = self.order

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        unit: None | str | Unset
        if isinstance(self.unit, Unset):
            unit = UNSET
        else:
            unit = self.unit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "table": table,
                "symbol": symbol,
                "value": value,
            }
        )
        if order is not UNSET:
            field_dict["order"] = order
        if title is not UNSET:
            field_dict["title"] = title
        if unit is not UNSET:
            field_dict["unit"] = unit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_table(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        table = _parse_table(d.pop("table"))

        symbol = d.pop("symbol")

        def _parse_value(data: object) -> float | int:
            return cast(float | int, data)

        value = _parse_value(d.pop("value"))

        def _parse_order(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        order = _parse_order(d.pop("order", UNSET))

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_unit(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        unit = _parse_unit(d.pop("unit", UNSET))

        eia_petroleum_status_report_data = cls(
            date=date,
            table=table,
            symbol=symbol,
            value=value,
            order=order,
            title=title,
            unit=unit,
        )

        eia_petroleum_status_report_data.additional_properties = d
        return eia_petroleum_status_report_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
