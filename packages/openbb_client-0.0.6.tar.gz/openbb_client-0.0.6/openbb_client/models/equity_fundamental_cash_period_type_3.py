from enum import Enum


class EquityFundamentalCashPeriodType3(str, Enum):
    ANNUAL = "annual"
    QUARTER = "quarter"
    TTM = "ttm"

    def __str__(self) -> str:
        return str(self.value)
