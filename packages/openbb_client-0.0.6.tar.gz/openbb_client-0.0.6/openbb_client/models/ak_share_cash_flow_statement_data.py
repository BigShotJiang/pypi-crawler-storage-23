from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareCashFlowStatementData")


@_attrs_define
class AKShareCashFlowStatementData:
    """AKShare Cash Flow Statement Data.

    Attributes:
        period_ending (datetime.date): The end date of the reporting period.
        fiscal_period (None | str | Unset): The fiscal period of the report.
        fiscal_year (int | None | Unset): The fiscal year of the fiscal period.
        营业性现金流 (float | None | Unset): 营业性现金流.
        投资性现金流 (float | None | Unset): 投资性现金流.
        融资性现金流 (float | None | Unset): 融资性现金流.
    """

    period_ending: datetime.date
    fiscal_period: None | str | Unset = UNSET
    fiscal_year: int | None | Unset = UNSET
    营业性现金流: float | None | Unset = UNSET
    投资性现金流: float | None | Unset = UNSET
    融资性现金流: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        period_ending = self.period_ending.isoformat()

        fiscal_period: None | str | Unset
        if isinstance(self.fiscal_period, Unset):
            fiscal_period = UNSET
        else:
            fiscal_period = self.fiscal_period

        fiscal_year: int | None | Unset
        if isinstance(self.fiscal_year, Unset):
            fiscal_year = UNSET
        else:
            fiscal_year = self.fiscal_year

        营业性现金流: float | None | Unset
        if isinstance(self.营业性现金流, Unset):
            营业性现金流 = UNSET
        else:
            营业性现金流 = self.营业性现金流

        投资性现金流: float | None | Unset
        if isinstance(self.投资性现金流, Unset):
            投资性现金流 = UNSET
        else:
            投资性现金流 = self.投资性现金流

        融资性现金流: float | None | Unset
        if isinstance(self.融资性现金流, Unset):
            融资性现金流 = UNSET
        else:
            融资性现金流 = self.融资性现金流

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "period_ending": period_ending,
            }
        )
        if fiscal_period is not UNSET:
            field_dict["fiscal_period"] = fiscal_period
        if fiscal_year is not UNSET:
            field_dict["fiscal_year"] = fiscal_year
        if 营业性现金流 is not UNSET:
            field_dict["营业性现金流"] = 营业性现金流
        if 投资性现金流 is not UNSET:
            field_dict["投资性现金流"] = 投资性现金流
        if 融资性现金流 is not UNSET:
            field_dict["融资性现金流"] = 融资性现金流

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        period_ending = isoparse(d.pop("period_ending")).date()

        def _parse_fiscal_period(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fiscal_period = _parse_fiscal_period(d.pop("fiscal_period", UNSET))

        def _parse_fiscal_year(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        fiscal_year = _parse_fiscal_year(d.pop("fiscal_year", UNSET))

        def _parse_营业性现金流(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        营业性现金流 = _parse_营业性现金流(d.pop("营业性现金流", UNSET))

        def _parse_投资性现金流(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        投资性现金流 = _parse_投资性现金流(d.pop("投资性现金流", UNSET))

        def _parse_融资性现金流(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        融资性现金流 = _parse_融资性现金流(d.pop("融资性现金流", UNSET))

        ak_share_cash_flow_statement_data = cls(
            period_ending=period_ending,
            fiscal_period=fiscal_period,
            fiscal_year=fiscal_year,
            营业性现金流=营业性现金流,
            投资性现金流=投资性现金流,
            融资性现金流=融资性现金流,
        )

        ak_share_cash_flow_statement_data.additional_properties = d
        return ak_share_cash_flow_statement_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
