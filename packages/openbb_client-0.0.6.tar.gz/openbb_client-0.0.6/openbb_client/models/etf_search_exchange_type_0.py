from enum import Enum


class EtfSearchExchangeType0(str, Enum):
    AMEX = "amex"
    EURONEXT = "euronext"
    NASDAQ = "nasdaq"
    NYSE = "nyse"
    TSX = "tsx"

    def __str__(self) -> str:
        return str(self.value)
