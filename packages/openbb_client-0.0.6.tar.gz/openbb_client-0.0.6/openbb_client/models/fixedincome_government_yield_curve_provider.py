from enum import Enum


class FixedincomeGovernmentYieldCurveProvider(str, Enum):
    ECONDB = "econdb"
    FEDERAL_RESERVE = "federal_reserve"
    FMP = "fmp"
    FRED = "fred"

    def __str__(self) -> str:
        return str(self.value)
