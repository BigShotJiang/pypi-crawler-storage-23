from enum import Enum


class CurrencySnapshotsQuoteType(str, Enum):
    DIRECT = "direct"
    INDIRECT = "indirect"

    def __str__(self) -> str:
        return str(self.value)
