from enum import Enum


class CryptoPriceHistoricalProvider(str, Enum):
    FMP = "fmp"
    POLYGON = "polygon"
    TIINGO = "tiingo"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
