from enum import Enum


class EconomySurveyBlsSearchCategoryType0(str, Enum):
    BED = "bed"
    CPI = "cpi"
    CPS = "cps"
    EC = "ec"
    IP = "ip"
    JOLTS = "jolts"
    LFS = "lfs"
    NFP = "nfp"
    PCE = "pce"
    PPI = "ppi"
    SLA = "sla"
    TU = "tu"
    WAGES = "wages"

    def __str__(self) -> str:
        return str(self.value)
