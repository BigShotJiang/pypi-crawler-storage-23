from enum import Enum


class EtfPricePerformanceIntrinio(str, Enum):
    CALENDAR = "calendar"
    TRAILING = "trailing"

    def __str__(self) -> str:
        return str(self.value)
