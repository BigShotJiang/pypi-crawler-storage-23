from enum import Enum


class EtfSearchProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    INTRINIO = "intrinio"

    def __str__(self) -> str:
        return str(self.value)
