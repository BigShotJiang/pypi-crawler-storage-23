from enum import Enum


class DerivativesOptionsUnusualSentimentType0(str, Enum):
    BEARISH = "bearish"
    BULLISH = "bullish"
    NEUTRAL = "neutral"

    def __str__(self) -> str:
        return str(self.value)
