from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKShareCurrencySnapshotsData")


@_attrs_define
class AKShareCurrencySnapshotsData:
    """AKShare Currency Snapshots Data.

    Attributes:
        base_currency (str): The base, or domestic, currency.
        counter_currency (str): The counter, or foreign, currency.
        last_rate (float): The exchange rate, relative to the base currency. Rates are expressed as the amount of
            foreign currency received from selling one unit of the base currency, or the quantity of foreign currency
            required to purchase one unit of the domestic currency. To inverse the perspective, set the 'quote_type'
            parameter as 'direct'.
        open_ (float | None | Unset): The open price.
        high (float | None | Unset): The high price.
        low (float | None | Unset): The low price.
        close (float | None | Unset): The close price.
        volume (int | None | Unset): The trading volume.
        prev_close (float | None | Unset): The previous close price.
        change (float | None | Unset): The change in the price from the previous close.
        change_percent (float | None | Unset): The change in the price from the previous close, as a normalized percent.
    """

    base_currency: str
    counter_currency: str
    last_rate: float
    open_: float | None | Unset = UNSET
    high: float | None | Unset = UNSET
    low: float | None | Unset = UNSET
    close: float | None | Unset = UNSET
    volume: int | None | Unset = UNSET
    prev_close: float | None | Unset = UNSET
    change: float | None | Unset = UNSET
    change_percent: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        base_currency = self.base_currency

        counter_currency = self.counter_currency

        last_rate = self.last_rate

        open_: float | None | Unset
        if isinstance(self.open_, Unset):
            open_ = UNSET
        else:
            open_ = self.open_

        high: float | None | Unset
        if isinstance(self.high, Unset):
            high = UNSET
        else:
            high = self.high

        low: float | None | Unset
        if isinstance(self.low, Unset):
            low = UNSET
        else:
            low = self.low

        close: float | None | Unset
        if isinstance(self.close, Unset):
            close = UNSET
        else:
            close = self.close

        volume: int | None | Unset
        if isinstance(self.volume, Unset):
            volume = UNSET
        else:
            volume = self.volume

        prev_close: float | None | Unset
        if isinstance(self.prev_close, Unset):
            prev_close = UNSET
        else:
            prev_close = self.prev_close

        change: float | None | Unset
        if isinstance(self.change, Unset):
            change = UNSET
        else:
            change = self.change

        change_percent: float | None | Unset
        if isinstance(self.change_percent, Unset):
            change_percent = UNSET
        else:
            change_percent = self.change_percent

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "base_currency": base_currency,
                "counter_currency": counter_currency,
                "last_rate": last_rate,
            }
        )
        if open_ is not UNSET:
            field_dict["open"] = open_
        if high is not UNSET:
            field_dict["high"] = high
        if low is not UNSET:
            field_dict["low"] = low
        if close is not UNSET:
            field_dict["close"] = close
        if volume is not UNSET:
            field_dict["volume"] = volume
        if prev_close is not UNSET:
            field_dict["prev_close"] = prev_close
        if change is not UNSET:
            field_dict["change"] = change
        if change_percent is not UNSET:
            field_dict["change_percent"] = change_percent

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        base_currency = d.pop("base_currency")

        counter_currency = d.pop("counter_currency")

        last_rate = d.pop("last_rate")

        def _parse_open_(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        open_ = _parse_open_(d.pop("open", UNSET))

        def _parse_high(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        high = _parse_high(d.pop("high", UNSET))

        def _parse_low(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        low = _parse_low(d.pop("low", UNSET))

        def _parse_close(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        close = _parse_close(d.pop("close", UNSET))

        def _parse_volume(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        volume = _parse_volume(d.pop("volume", UNSET))

        def _parse_prev_close(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        prev_close = _parse_prev_close(d.pop("prev_close", UNSET))

        def _parse_change(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change = _parse_change(d.pop("change", UNSET))

        def _parse_change_percent(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent = _parse_change_percent(d.pop("change_percent", UNSET))

        ak_share_currency_snapshots_data = cls(
            base_currency=base_currency,
            counter_currency=counter_currency,
            last_rate=last_rate,
            open_=open_,
            high=high,
            low=low,
            close=close,
            volume=volume,
            prev_close=prev_close,
            change=change,
            change_percent=change_percent,
        )

        ak_share_currency_snapshots_data.additional_properties = d
        return ak_share_currency_snapshots_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
