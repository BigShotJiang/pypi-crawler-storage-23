from enum import Enum


class EquityMarketSnapshotsProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"
    POLYGON = "polygon"

    def __str__(self) -> str:
        return str(self.value)
