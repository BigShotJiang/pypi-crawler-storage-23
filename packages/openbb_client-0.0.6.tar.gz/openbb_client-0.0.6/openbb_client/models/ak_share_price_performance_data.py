from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="AKSharePricePerformanceData")


@_attrs_define
class AKSharePricePerformanceData:
    """AKShare Price Performance Data.

    Attributes:
        symbol (None | str | Unset): Symbol representing the entity requested in the data.
        one_day (float | None | Unset): One-day return.
        wtd (float | None | Unset): Week to date return.
        one_week (float | None | Unset): One-week return.
        mtd (float | None | Unset): Month to date return.
        one_month (float | None | Unset): One-month return.
        qtd (float | None | Unset): Quarter to date return.
        three_month (float | None | Unset): Three-month return.
        six_month (float | None | Unset): Six-month return.
        ytd (float | None | Unset): Year to date return.
        one_year (float | None | Unset): One-year return.
        two_year (float | None | Unset): Two-year return.
        three_year (float | None | Unset): Three-year return.
        four_year (float | None | Unset): Four-year
        five_year (float | None | Unset): Five-year return.
        ten_year (float | None | Unset): Ten-year return.
        max_ (float | None | Unset): Return from the beginning of the time series.
    """

    symbol: None | str | Unset = UNSET
    one_day: float | None | Unset = UNSET
    wtd: float | None | Unset = UNSET
    one_week: float | None | Unset = UNSET
    mtd: float | None | Unset = UNSET
    one_month: float | None | Unset = UNSET
    qtd: float | None | Unset = UNSET
    three_month: float | None | Unset = UNSET
    six_month: float | None | Unset = UNSET
    ytd: float | None | Unset = UNSET
    one_year: float | None | Unset = UNSET
    two_year: float | None | Unset = UNSET
    three_year: float | None | Unset = UNSET
    four_year: float | None | Unset = UNSET
    five_year: float | None | Unset = UNSET
    ten_year: float | None | Unset = UNSET
    max_: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        symbol: None | str | Unset
        if isinstance(self.symbol, Unset):
            symbol = UNSET
        else:
            symbol = self.symbol

        one_day: float | None | Unset
        if isinstance(self.one_day, Unset):
            one_day = UNSET
        else:
            one_day = self.one_day

        wtd: float | None | Unset
        if isinstance(self.wtd, Unset):
            wtd = UNSET
        else:
            wtd = self.wtd

        one_week: float | None | Unset
        if isinstance(self.one_week, Unset):
            one_week = UNSET
        else:
            one_week = self.one_week

        mtd: float | None | Unset
        if isinstance(self.mtd, Unset):
            mtd = UNSET
        else:
            mtd = self.mtd

        one_month: float | None | Unset
        if isinstance(self.one_month, Unset):
            one_month = UNSET
        else:
            one_month = self.one_month

        qtd: float | None | Unset
        if isinstance(self.qtd, Unset):
            qtd = UNSET
        else:
            qtd = self.qtd

        three_month: float | None | Unset
        if isinstance(self.three_month, Unset):
            three_month = UNSET
        else:
            three_month = self.three_month

        six_month: float | None | Unset
        if isinstance(self.six_month, Unset):
            six_month = UNSET
        else:
            six_month = self.six_month

        ytd: float | None | Unset
        if isinstance(self.ytd, Unset):
            ytd = UNSET
        else:
            ytd = self.ytd

        one_year: float | None | Unset
        if isinstance(self.one_year, Unset):
            one_year = UNSET
        else:
            one_year = self.one_year

        two_year: float | None | Unset
        if isinstance(self.two_year, Unset):
            two_year = UNSET
        else:
            two_year = self.two_year

        three_year: float | None | Unset
        if isinstance(self.three_year, Unset):
            three_year = UNSET
        else:
            three_year = self.three_year

        four_year: float | None | Unset
        if isinstance(self.four_year, Unset):
            four_year = UNSET
        else:
            four_year = self.four_year

        five_year: float | None | Unset
        if isinstance(self.five_year, Unset):
            five_year = UNSET
        else:
            five_year = self.five_year

        ten_year: float | None | Unset
        if isinstance(self.ten_year, Unset):
            ten_year = UNSET
        else:
            ten_year = self.ten_year

        max_: float | None | Unset
        if isinstance(self.max_, Unset):
            max_ = UNSET
        else:
            max_ = self.max_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if symbol is not UNSET:
            field_dict["symbol"] = symbol
        if one_day is not UNSET:
            field_dict["one_day"] = one_day
        if wtd is not UNSET:
            field_dict["wtd"] = wtd
        if one_week is not UNSET:
            field_dict["one_week"] = one_week
        if mtd is not UNSET:
            field_dict["mtd"] = mtd
        if one_month is not UNSET:
            field_dict["one_month"] = one_month
        if qtd is not UNSET:
            field_dict["qtd"] = qtd
        if three_month is not UNSET:
            field_dict["three_month"] = three_month
        if six_month is not UNSET:
            field_dict["six_month"] = six_month
        if ytd is not UNSET:
            field_dict["ytd"] = ytd
        if one_year is not UNSET:
            field_dict["one_year"] = one_year
        if two_year is not UNSET:
            field_dict["two_year"] = two_year
        if three_year is not UNSET:
            field_dict["three_year"] = three_year
        if four_year is not UNSET:
            field_dict["four_year"] = four_year
        if five_year is not UNSET:
            field_dict["five_year"] = five_year
        if ten_year is not UNSET:
            field_dict["ten_year"] = ten_year
        if max_ is not UNSET:
            field_dict["max"] = max_

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_symbol(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        symbol = _parse_symbol(d.pop("symbol", UNSET))

        def _parse_one_day(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        one_day = _parse_one_day(d.pop("one_day", UNSET))

        def _parse_wtd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        wtd = _parse_wtd(d.pop("wtd", UNSET))

        def _parse_one_week(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        one_week = _parse_one_week(d.pop("one_week", UNSET))

        def _parse_mtd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        mtd = _parse_mtd(d.pop("mtd", UNSET))

        def _parse_one_month(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        one_month = _parse_one_month(d.pop("one_month", UNSET))

        def _parse_qtd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        qtd = _parse_qtd(d.pop("qtd", UNSET))

        def _parse_three_month(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        three_month = _parse_three_month(d.pop("three_month", UNSET))

        def _parse_six_month(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        six_month = _parse_six_month(d.pop("six_month", UNSET))

        def _parse_ytd(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        ytd = _parse_ytd(d.pop("ytd", UNSET))

        def _parse_one_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        one_year = _parse_one_year(d.pop("one_year", UNSET))

        def _parse_two_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        two_year = _parse_two_year(d.pop("two_year", UNSET))

        def _parse_three_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        three_year = _parse_three_year(d.pop("three_year", UNSET))

        def _parse_four_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        four_year = _parse_four_year(d.pop("four_year", UNSET))

        def _parse_five_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        five_year = _parse_five_year(d.pop("five_year", UNSET))

        def _parse_ten_year(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        ten_year = _parse_ten_year(d.pop("ten_year", UNSET))

        def _parse_max_(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        max_ = _parse_max_(d.pop("max", UNSET))

        ak_share_price_performance_data = cls(
            symbol=symbol,
            one_day=one_day,
            wtd=wtd,
            one_week=one_week,
            mtd=mtd,
            one_month=one_month,
            qtd=qtd,
            three_month=three_month,
            six_month=six_month,
            ytd=ytd,
            one_year=one_year,
            two_year=two_year,
            three_year=three_year,
            four_year=four_year,
            five_year=five_year,
            ten_year=ten_year,
            max_=max_,
        )

        ak_share_price_performance_data.additional_properties = d
        return ak_share_price_performance_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
