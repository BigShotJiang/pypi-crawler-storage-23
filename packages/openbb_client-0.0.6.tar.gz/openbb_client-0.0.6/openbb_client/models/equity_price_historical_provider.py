from enum import Enum


class EquityPriceHistoricalProvider(str, Enum):
    AKSHARE = "akshare"
    FMP = "fmp"
    INTRINIO = "intrinio"
    POLYGON = "polygon"
    TIINGO = "tiingo"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
