from enum import Enum


class FixedincomeGovernmentYieldCurveFred(str, Enum):
    BREAKEVEN = "breakeven"
    CORPORATE_PAR = "corporate_par"
    CORPORATE_SPOT = "corporate_spot"
    NOMINAL = "nominal"
    REAL = "real"
    TREASURY_MINUS_FED_FUNDS = "treasury_minus_fed_funds"

    def __str__(self) -> str:
        return str(self.value)
