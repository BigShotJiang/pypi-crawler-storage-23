from enum import Enum


class EquityOwnershipInsiderTradingProvider(str, Enum):
    FMP = "fmp"
    INTRINIO = "intrinio"
    SEC = "sec"

    def __str__(self) -> str:
        return str(self.value)
