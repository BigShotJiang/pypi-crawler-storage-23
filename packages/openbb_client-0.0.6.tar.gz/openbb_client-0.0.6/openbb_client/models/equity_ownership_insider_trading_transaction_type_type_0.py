from enum import Enum


class EquityOwnershipInsiderTradingTransactionTypeType0(str, Enum):
    AWARD = "award"
    CONVERSION = "conversion"
    DISCRETIONARY = "discretionary"
    EXEMPT = "exempt"
    EXPIRE_LONG = "expire_long"
    EXPIRE_SHORT = "expire_short"
    GIFT = "gift"
    IN_KIND = "in_kind"
    ITM = "itm"
    OTHER = "other"
    OTM = "otm"
    PURCHASE = "purchase"
    RETURN = "return"
    SALE = "sale"
    SMALL = "small"
    TENDER = "tender"
    TRUST = "trust"
    WILL = "will"

    def __str__(self) -> str:
        return str(self.value)
