from enum import Enum


class DerivativesOptionsChainsProvider(str, Enum):
    INTRINIO = "intrinio"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
