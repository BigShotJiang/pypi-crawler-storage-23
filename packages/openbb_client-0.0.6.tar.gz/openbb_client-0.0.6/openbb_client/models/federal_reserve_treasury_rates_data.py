from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="FederalReserveTreasuryRatesData")


@_attrs_define
class FederalReserveTreasuryRatesData:
    """FederalReserve Treasury Rates Data.

    Attributes:
        date (datetime.date): The date of the data.
        week_4 (float | None | Unset): 4 week Treasury bills rate (secondary market).
        month_1 (float | None | Unset): 1 month Treasury rate.
        month_2 (float | None | Unset): 2 month Treasury rate.
        month_3 (float | None | Unset): 3 month Treasury rate.
        month_6 (float | None | Unset): 6 month Treasury rate.
        year_1 (float | None | Unset): 1 year Treasury rate.
        year_2 (float | None | Unset): 2 year Treasury rate.
        year_3 (float | None | Unset): 3 year Treasury rate.
        year_5 (float | None | Unset): 5 year Treasury rate.
        year_7 (float | None | Unset): 7 year Treasury rate.
        year_10 (float | None | Unset): 10 year Treasury rate.
        year_20 (float | None | Unset): 20 year Treasury rate.
        year_30 (float | None | Unset): 30 year Treasury rate.
    """

    date: datetime.date
    week_4: float | None | Unset = UNSET
    month_1: float | None | Unset = UNSET
    month_2: float | None | Unset = UNSET
    month_3: float | None | Unset = UNSET
    month_6: float | None | Unset = UNSET
    year_1: float | None | Unset = UNSET
    year_2: float | None | Unset = UNSET
    year_3: float | None | Unset = UNSET
    year_5: float | None | Unset = UNSET
    year_7: float | None | Unset = UNSET
    year_10: float | None | Unset = UNSET
    year_20: float | None | Unset = UNSET
    year_30: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        week_4: float | None | Unset
        if isinstance(self.week_4, Unset):
            week_4 = UNSET
        else:
            week_4 = self.week_4

        month_1: float | None | Unset
        if isinstance(self.month_1, Unset):
            month_1 = UNSET
        else:
            month_1 = self.month_1

        month_2: float | None | Unset
        if isinstance(self.month_2, Unset):
            month_2 = UNSET
        else:
            month_2 = self.month_2

        month_3: float | None | Unset
        if isinstance(self.month_3, Unset):
            month_3 = UNSET
        else:
            month_3 = self.month_3

        month_6: float | None | Unset
        if isinstance(self.month_6, Unset):
            month_6 = UNSET
        else:
            month_6 = self.month_6

        year_1: float | None | Unset
        if isinstance(self.year_1, Unset):
            year_1 = UNSET
        else:
            year_1 = self.year_1

        year_2: float | None | Unset
        if isinstance(self.year_2, Unset):
            year_2 = UNSET
        else:
            year_2 = self.year_2

        year_3: float | None | Unset
        if isinstance(self.year_3, Unset):
            year_3 = UNSET
        else:
            year_3 = self.year_3

        year_5: float | None | Unset
        if isinstance(self.year_5, Unset):
            year_5 = UNSET
        else:
            year_5 = self.year_5

        year_7: float | None | Unset
        if isinstance(self.year_7, Unset):
            year_7 = UNSET
        else:
            year_7 = self.year_7

        year_10: float | None | Unset
        if isinstance(self.year_10, Unset):
            year_10 = UNSET
        else:
            year_10 = self.year_10

        year_20: float | None | Unset
        if isinstance(self.year_20, Unset):
            year_20 = UNSET
        else:
            year_20 = self.year_20

        year_30: float | None | Unset
        if isinstance(self.year_30, Unset):
            year_30 = UNSET
        else:
            year_30 = self.year_30

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
            }
        )
        if week_4 is not UNSET:
            field_dict["week_4"] = week_4
        if month_1 is not UNSET:
            field_dict["month_1"] = month_1
        if month_2 is not UNSET:
            field_dict["month_2"] = month_2
        if month_3 is not UNSET:
            field_dict["month_3"] = month_3
        if month_6 is not UNSET:
            field_dict["month_6"] = month_6
        if year_1 is not UNSET:
            field_dict["year_1"] = year_1
        if year_2 is not UNSET:
            field_dict["year_2"] = year_2
        if year_3 is not UNSET:
            field_dict["year_3"] = year_3
        if year_5 is not UNSET:
            field_dict["year_5"] = year_5
        if year_7 is not UNSET:
            field_dict["year_7"] = year_7
        if year_10 is not UNSET:
            field_dict["year_10"] = year_10
        if year_20 is not UNSET:
            field_dict["year_20"] = year_20
        if year_30 is not UNSET:
            field_dict["year_30"] = year_30

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_week_4(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        week_4 = _parse_week_4(d.pop("week_4", UNSET))

        def _parse_month_1(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        month_1 = _parse_month_1(d.pop("month_1", UNSET))

        def _parse_month_2(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        month_2 = _parse_month_2(d.pop("month_2", UNSET))

        def _parse_month_3(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        month_3 = _parse_month_3(d.pop("month_3", UNSET))

        def _parse_month_6(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        month_6 = _parse_month_6(d.pop("month_6", UNSET))

        def _parse_year_1(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_1 = _parse_year_1(d.pop("year_1", UNSET))

        def _parse_year_2(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_2 = _parse_year_2(d.pop("year_2", UNSET))

        def _parse_year_3(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_3 = _parse_year_3(d.pop("year_3", UNSET))

        def _parse_year_5(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_5 = _parse_year_5(d.pop("year_5", UNSET))

        def _parse_year_7(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_7 = _parse_year_7(d.pop("year_7", UNSET))

        def _parse_year_10(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_10 = _parse_year_10(d.pop("year_10", UNSET))

        def _parse_year_20(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_20 = _parse_year_20(d.pop("year_20", UNSET))

        def _parse_year_30(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        year_30 = _parse_year_30(d.pop("year_30", UNSET))

        federal_reserve_treasury_rates_data = cls(
            date=date,
            week_4=week_4,
            month_1=month_1,
            month_2=month_2,
            month_3=month_3,
            month_6=month_6,
            year_1=year_1,
            year_2=year_2,
            year_3=year_3,
            year_5=year_5,
            year_7=year_7,
            year_10=year_10,
            year_20=year_20,
            year_30=year_30,
        )

        federal_reserve_treasury_rates_data.additional_properties = d
        return federal_reserve_treasury_rates_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
