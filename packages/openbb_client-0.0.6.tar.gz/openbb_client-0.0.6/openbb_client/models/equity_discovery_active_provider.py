from enum import Enum


class EquityDiscoveryActiveProvider(str, Enum):
    FMP = "fmp"
    YFINANCE = "yfinance"

    def __str__(self) -> str:
        return str(self.value)
