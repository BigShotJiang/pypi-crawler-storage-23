from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="BlsSeriesData")


@_attrs_define
class BlsSeriesData:
    """BLS Series Data.

    Attributes:
        date (datetime.date): The date of the data.
        symbol (str): Symbol representing the entity requested in the data.
        title (None | str | Unset): Title of the series.
        value (float | None | Unset): Observation value for the symbol and date.
        change_1_m (float | None | Unset): One month change in value.
        change_3_m (float | None | Unset): Three month change in value.
        change_6_m (float | None | Unset): Six month change in value.
        change_12_m (float | None | Unset): One year change in value.
        change_percent_1_m (float | None | Unset): One month change in percent.
        change_percent_3_m (float | None | Unset): Three month change in percent.
        change_percent_6_m (float | None | Unset): Six month change in percent.
        change_percent_12_m (float | None | Unset): One year change in percent.
        latest (bool | None | Unset): Latest value indicator.
        footnotes (None | str | Unset): Footnotes accompanying the value.
    """

    date: datetime.date
    symbol: str
    title: None | str | Unset = UNSET
    value: float | None | Unset = UNSET
    change_1_m: float | None | Unset = UNSET
    change_3_m: float | None | Unset = UNSET
    change_6_m: float | None | Unset = UNSET
    change_12_m: float | None | Unset = UNSET
    change_percent_1_m: float | None | Unset = UNSET
    change_percent_3_m: float | None | Unset = UNSET
    change_percent_6_m: float | None | Unset = UNSET
    change_percent_12_m: float | None | Unset = UNSET
    latest: bool | None | Unset = UNSET
    footnotes: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        symbol = self.symbol

        title: None | str | Unset
        if isinstance(self.title, Unset):
            title = UNSET
        else:
            title = self.title

        value: float | None | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        change_1_m: float | None | Unset
        if isinstance(self.change_1_m, Unset):
            change_1_m = UNSET
        else:
            change_1_m = self.change_1_m

        change_3_m: float | None | Unset
        if isinstance(self.change_3_m, Unset):
            change_3_m = UNSET
        else:
            change_3_m = self.change_3_m

        change_6_m: float | None | Unset
        if isinstance(self.change_6_m, Unset):
            change_6_m = UNSET
        else:
            change_6_m = self.change_6_m

        change_12_m: float | None | Unset
        if isinstance(self.change_12_m, Unset):
            change_12_m = UNSET
        else:
            change_12_m = self.change_12_m

        change_percent_1_m: float | None | Unset
        if isinstance(self.change_percent_1_m, Unset):
            change_percent_1_m = UNSET
        else:
            change_percent_1_m = self.change_percent_1_m

        change_percent_3_m: float | None | Unset
        if isinstance(self.change_percent_3_m, Unset):
            change_percent_3_m = UNSET
        else:
            change_percent_3_m = self.change_percent_3_m

        change_percent_6_m: float | None | Unset
        if isinstance(self.change_percent_6_m, Unset):
            change_percent_6_m = UNSET
        else:
            change_percent_6_m = self.change_percent_6_m

        change_percent_12_m: float | None | Unset
        if isinstance(self.change_percent_12_m, Unset):
            change_percent_12_m = UNSET
        else:
            change_percent_12_m = self.change_percent_12_m

        latest: bool | None | Unset
        if isinstance(self.latest, Unset):
            latest = UNSET
        else:
            latest = self.latest

        footnotes: None | str | Unset
        if isinstance(self.footnotes, Unset):
            footnotes = UNSET
        else:
            footnotes = self.footnotes

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "symbol": symbol,
            }
        )
        if title is not UNSET:
            field_dict["title"] = title
        if value is not UNSET:
            field_dict["value"] = value
        if change_1_m is not UNSET:
            field_dict["change_1_m"] = change_1_m
        if change_3_m is not UNSET:
            field_dict["change_3_m"] = change_3_m
        if change_6_m is not UNSET:
            field_dict["change_6_m"] = change_6_m
        if change_12_m is not UNSET:
            field_dict["change_12_m"] = change_12_m
        if change_percent_1_m is not UNSET:
            field_dict["change_percent_1_m"] = change_percent_1_m
        if change_percent_3_m is not UNSET:
            field_dict["change_percent_3_m"] = change_percent_3_m
        if change_percent_6_m is not UNSET:
            field_dict["change_percent_6_m"] = change_percent_6_m
        if change_percent_12_m is not UNSET:
            field_dict["change_percent_12_m"] = change_percent_12_m
        if latest is not UNSET:
            field_dict["latest"] = latest
        if footnotes is not UNSET:
            field_dict["footnotes"] = footnotes

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        symbol = d.pop("symbol")

        def _parse_title(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        title = _parse_title(d.pop("title", UNSET))

        def _parse_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        def _parse_change_1_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_1_m = _parse_change_1_m(d.pop("change_1_m", UNSET))

        def _parse_change_3_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_3_m = _parse_change_3_m(d.pop("change_3_m", UNSET))

        def _parse_change_6_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_6_m = _parse_change_6_m(d.pop("change_6_m", UNSET))

        def _parse_change_12_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_12_m = _parse_change_12_m(d.pop("change_12_m", UNSET))

        def _parse_change_percent_1_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent_1_m = _parse_change_percent_1_m(d.pop("change_percent_1_m", UNSET))

        def _parse_change_percent_3_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent_3_m = _parse_change_percent_3_m(d.pop("change_percent_3_m", UNSET))

        def _parse_change_percent_6_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent_6_m = _parse_change_percent_6_m(d.pop("change_percent_6_m", UNSET))

        def _parse_change_percent_12_m(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        change_percent_12_m = _parse_change_percent_12_m(d.pop("change_percent_12_m", UNSET))

        def _parse_latest(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        latest = _parse_latest(d.pop("latest", UNSET))

        def _parse_footnotes(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        footnotes = _parse_footnotes(d.pop("footnotes", UNSET))

        bls_series_data = cls(
            date=date,
            symbol=symbol,
            title=title,
            value=value,
            change_1_m=change_1_m,
            change_3_m=change_3_m,
            change_6_m=change_6_m,
            change_12_m=change_12_m,
            change_percent_1_m=change_percent_1_m,
            change_percent_3_m=change_percent_3_m,
            change_percent_6_m=change_percent_6_m,
            change_percent_12_m=change_percent_12_m,
            latest=latest,
            footnotes=footnotes,
        )

        bls_series_data.additional_properties = d
        return bls_series_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
