from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="EconDbGdpNominalData")


@_attrs_define
class EconDbGdpNominalData:
    """EconDB GDP Nominal Data.

    Attributes:
        date (datetime.date): The date of the data.
        value (float | int): Nominal GDP value for the country and date.
        nominal_growth_qoq (float): Nominal GDP growth rate quarter over quarter.
        nominal_growth_yoy (float): Nominal GDP growth rate year over year.
        country (str | Unset): The country represented by the GDP value.
    """

    date: datetime.date
    value: float | int
    nominal_growth_qoq: float
    nominal_growth_yoy: float
    country: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        date = self.date.isoformat()

        value: float | int
        value = self.value

        nominal_growth_qoq = self.nominal_growth_qoq

        nominal_growth_yoy = self.nominal_growth_yoy

        country = self.country

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "date": date,
                "value": value,
                "nominal_growth_qoq": nominal_growth_qoq,
                "nominal_growth_yoy": nominal_growth_yoy,
            }
        )
        if country is not UNSET:
            field_dict["country"] = country

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        date = isoparse(d.pop("date")).date()

        def _parse_value(data: object) -> float | int:
            return cast(float | int, data)

        value = _parse_value(d.pop("value"))

        nominal_growth_qoq = d.pop("nominal_growth_qoq")

        nominal_growth_yoy = d.pop("nominal_growth_yoy")

        country = d.pop("country", UNSET)

        econ_db_gdp_nominal_data = cls(
            date=date,
            value=value,
            nominal_growth_qoq=nominal_growth_qoq,
            nominal_growth_yoy=nominal_growth_yoy,
            country=country,
        )

        econ_db_gdp_nominal_data.additional_properties = d
        return econ_db_gdp_nominal_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
