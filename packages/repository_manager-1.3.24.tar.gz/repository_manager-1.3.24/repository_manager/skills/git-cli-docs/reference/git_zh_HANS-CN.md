[![Git](https://git-scm.com/images/logo@2x.png)](https://git-scm.com/) --fast-version-control
![](https://git-scm.com/images/dark-mode.svg)
  * [About](https://git-scm.com/about)
    * [Trademark](https://git-scm.com/about/trademark)
  * [Learn](https://git-scm.com/learn)
    * [Book](https://git-scm.com/book)
    * [Cheat Sheet](https://git-scm.com/cheat-sheet)
    * [Videos](https://git-scm.com/videos)
    * [External Links](https://git-scm.com/doc/ext)
  * [Tools](https://git-scm.com/tools)
    * [Command Line](https://git-scm.com/tools/command-line)
    * [GUIs](https://git-scm.com/tools/guis)
    * [Hosting](https://git-scm.com/tools/hosting)
  * [Reference](https://git-scm.com/docs)
  * [Install](https://git-scm.com/install/linux)
  * [Community](https://git-scm.com/community)


  * Table of Contents
    * [名称](https://git-scm.com/docs/git/zh_HANS-CN#_%e5%90%8d%e7%a7%b0)
    * [概述](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%a6%82%e8%bf%b0)
    * [描述](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%8f%8f%e8%bf%b0)
    * [选项](https://git-scm.com/docs/git/zh_HANS-CN#_%e9%80%89%e9%a1%b9)
    * [Git 命令](https://git-scm.com/docs/git/zh_HANS-CN#_git_%e5%91%bd%e4%bb%a4)
    * [上层封装命令（瓷件）](https://git-scm.com/docs/git/zh_HANS-CN#_%e4%b8%8a%e5%b1%82%e5%b0%81%e8%a3%85%e5%91%bd%e4%bb%a4%e7%93%b7%e4%bb%b6)
    * [底层核心命令（管件）](https://git-scm.com/docs/git/zh_HANS-CN#_%e5%ba%95%e5%b1%82%e6%a0%b8%e5%bf%83%e5%91%bd%e4%bb%a4%e7%ae%a1%e4%bb%b6)
    * [指南](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%8c%87%e5%8d%97)
    * [仓库、命令和文件接口](https://git-scm.com/docs/git/zh_HANS-CN#_%e4%bb%93%e5%ba%93%e5%91%bd%e4%bb%a4%e5%92%8c%e6%96%87%e4%bb%b6%e6%8e%a5%e5%8f%a3)
    * [文件格式、协议和其他开发者接口](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%96%87%e4%bb%b6%e6%a0%bc%e5%bc%8f%e5%8d%8f%e8%ae%ae%e5%92%8c%e5%85%b6%e4%bb%96%e5%bc%80%e5%8f%91%e8%80%85%e6%8e%a5%e5%8f%a3)
    * [配置机制](https://git-scm.com/docs/git/zh_HANS-CN#_%e9%85%8d%e7%bd%ae%e6%9c%ba%e5%88%b6)
    * [标识符术语](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%a0%87%e8%af%86%e7%ac%a6%e6%9c%af%e8%af%ad)
    * [符号标识符](https://git-scm.com/docs/git/zh_HANS-CN#_%e7%ac%a6%e5%8f%b7%e6%a0%87%e8%af%86%e7%ac%a6)
    * [文件/目录结构](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%96%87%e4%bb%b6%e7%9b%ae%e5%bd%95%e7%bb%93%e6%9e%84)
    * [术语](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%9c%af%e8%af%ad)
    * [环境变量](https://git-scm.com/docs/git/zh_HANS-CN#_%e7%8e%af%e5%a2%83%e5%8f%98%e9%87%8f)
    * [讨论](https://git-scm.com/docs/git/zh_HANS-CN#_%e8%ae%a8%e8%ae%ba)
    * [安全](https://git-scm.com/docs/git/zh_HANS-CN#_%e5%ae%89%e5%85%a8)
    * [更多文件](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%9b%b4%e5%a4%9a%e6%96%87%e4%bb%b6)
    * [作者](https://git-scm.com/docs/git/zh_HANS-CN#_%e4%bd%9c%e8%80%85)
    * [报告缺陷](https://git-scm.com/docs/git/zh_HANS-CN#_%e6%8a%a5%e5%91%8a%e7%bc%ba%e9%99%b7)
    * [参见](https://git-scm.com/docs/git/zh_HANS-CN#_%e5%8f%82%e8%a7%81)
    * [GIT](https://git-scm.com/docs/git/zh_HANS-CN#_git)


[ 简体中文 ▾](https://git-scm.com/docs/git/zh_HANS-CN)
Localized versions of **git** manual
  1. [English ](https://git-scm.com/docs/git)
  2. [Deutsch ](https://git-scm.com/docs/git/de)
  3. [Español ](https://git-scm.com/docs/git/es)
  4. [Français ](https://git-scm.com/docs/git/fr)
  5. [Português (Brasil) ](https://git-scm.com/docs/git/pt_BR)
  6. [Svenska ](https://git-scm.com/docs/git/sv)
  7. [українська мова ](https://git-scm.com/docs/git/uk)
  8. [简体中文 ](https://git-scm.com/docs/git/zh_HANS-CN)

Want to read in your language or fix typos?
[You can help translate this page](https://github.com/jnavila/git-manpages-l10n).
[Topics ▾](https://git-scm.com/docs/git/zh_HANS-CN)
### Setup and Config
  * [ git ](https://git-scm.com/docs/git/zh_HANS-CN)
  * [ config ](https://git-scm.com/docs/git-config/zh_HANS-CN)
  * [ help ](https://git-scm.com/docs/git-help/zh_HANS-CN)
  * [ bugreport ](https://git-scm.com/docs/git-bugreport/zh_HANS-CN)
  * [ Credential helpers ](https://git-scm.com/doc/credential-helpers)


### Getting and Creating Projects
  * [ init ](https://git-scm.com/docs/git-init/zh_HANS-CN)
  * [ clone ](https://git-scm.com/docs/git-clone/zh_HANS-CN)


### Basic Snapshotting
  * [ add ](https://git-scm.com/docs/git-add/zh_HANS-CN)
  * [ status ](https://git-scm.com/docs/git-status/zh_HANS-CN)
  * [ diff ](https://git-scm.com/docs/git-diff/zh_HANS-CN)
  * [ commit ](https://git-scm.com/docs/git-commit/zh_HANS-CN)
  * [ notes ](https://git-scm.com/docs/git-notes/zh_HANS-CN)
  * [ restore ](https://git-scm.com/docs/git-restore/zh_HANS-CN)
  * [ reset ](https://git-scm.com/docs/git-reset/zh_HANS-CN)
  * [ rm ](https://git-scm.com/docs/git-rm/zh_HANS-CN)
  * [ mv ](https://git-scm.com/docs/git-mv/zh_HANS-CN)


### Branching and Merging
  * [ branch ](https://git-scm.com/docs/git-branch/zh_HANS-CN)
  * [ checkout ](https://git-scm.com/docs/git-checkout/zh_HANS-CN)
  * [ switch ](https://git-scm.com/docs/git-switch/zh_HANS-CN)
  * [ merge ](https://git-scm.com/docs/git-merge/zh_HANS-CN)
  * [ mergetool ](https://git-scm.com/docs/git-mergetool/zh_HANS-CN)
  * [ log ](https://git-scm.com/docs/git-log/zh_HANS-CN)
  * [ stash ](https://git-scm.com/docs/git-stash/zh_HANS-CN)
  * [ tag ](https://git-scm.com/docs/git-tag/zh_HANS-CN)
  * [ worktree ](https://git-scm.com/docs/git-worktree/zh_HANS-CN)


### Sharing and Updating Projects
  * [ fetch ](https://git-scm.com/docs/git-fetch/zh_HANS-CN)
  * [ pull ](https://git-scm.com/docs/git-pull/zh_HANS-CN)
  * [ push ](https://git-scm.com/docs/git-push/zh_HANS-CN)
  * [ remote ](https://git-scm.com/docs/git-remote/zh_HANS-CN)
  * [ submodule ](https://git-scm.com/docs/git-submodule/zh_HANS-CN)


### Inspection and Comparison
  * [ show ](https://git-scm.com/docs/git-show/zh_HANS-CN)
  * [ log ](https://git-scm.com/docs/git-log/zh_HANS-CN)
  * [ diff ](https://git-scm.com/docs/git-diff/zh_HANS-CN)
  * [ difftool ](https://git-scm.com/docs/git-difftool/zh_HANS-CN)
  * [ range-diff ](https://git-scm.com/docs/git-range-diff/zh_HANS-CN)
  * [ shortlog ](https://git-scm.com/docs/git-shortlog/zh_HANS-CN)
  * [ describe ](https://git-scm.com/docs/git-describe/zh_HANS-CN)


### Patching
  * [ apply ](https://git-scm.com/docs/git-apply/zh_HANS-CN)
  * [ cherry-pick ](https://git-scm.com/docs/git-cherry-pick/zh_HANS-CN)
  * [ diff ](https://git-scm.com/docs/git-diff/zh_HANS-CN)
  * [ rebase ](https://git-scm.com/docs/git-rebase/zh_HANS-CN)
  * [ revert ](https://git-scm.com/docs/git-revert/zh_HANS-CN)


### Debugging
  * [ bisect ](https://git-scm.com/docs/git-bisect/zh_HANS-CN)
  * [ blame ](https://git-scm.com/docs/git-blame/zh_HANS-CN)
  * [ grep ](https://git-scm.com/docs/git-grep/zh_HANS-CN)


### Email
  * [ am ](https://git-scm.com/docs/git-am/zh_HANS-CN)
  * [ apply ](https://git-scm.com/docs/git-apply/zh_HANS-CN)
  * [ imap-send ](https://git-scm.com/docs/git-imap-send/zh_HANS-CN)
  * [ format-patch ](https://git-scm.com/docs/git-format-patch/zh_HANS-CN)
  * [ send-email ](https://git-scm.com/docs/git-send-email/zh_HANS-CN)
  * [ request-pull ](https://git-scm.com/docs/git-request-pull/zh_HANS-CN)


### External Systems
  * [ svn ](https://git-scm.com/docs/git-svn/zh_HANS-CN)
  * [ fast-import ](https://git-scm.com/docs/git-fast-import/zh_HANS-CN)


### Server Admin
  * [ daemon ](https://git-scm.com/docs/git-daemon/zh_HANS-CN)
  * [ update-server-info ](https://git-scm.com/docs/git-update-server-info/zh_HANS-CN)


### Guides
  * [ gitattributes ](https://git-scm.com/docs/gitattributes)
  * [ Command-line interface conventions ](https://git-scm.com/docs/gitcli)
  * [ Everyday Git ](https://git-scm.com/docs/giteveryday)
  * [ Frequently Asked Questions (FAQ) ](https://git-scm.com/docs/gitfaq)
  * [ Glossary ](https://git-scm.com/docs/gitglossary/zh_HANS-CN)
  * [ Hooks ](https://git-scm.com/docs/githooks)
  * [ gitignore ](https://git-scm.com/docs/gitignore/zh_HANS-CN)
  * [ gitmodules ](https://git-scm.com/docs/gitmodules)
  * [ Revisions ](https://git-scm.com/docs/gitrevisions)
  * [ Submodules ](https://git-scm.com/docs/gitsubmodules)
  * [ Tutorial ](https://git-scm.com/docs/gittutorial)
  * [ Workflows ](https://git-scm.com/docs/gitworkflows)
  * [ All guides... ](https://git-scm.com/docs/git#_guides)


### Administration
  * [ clean ](https://git-scm.com/docs/git-clean/zh_HANS-CN)
  * [ gc ](https://git-scm.com/docs/git-gc/zh_HANS-CN)
  * [ fsck ](https://git-scm.com/docs/git-fsck/zh_HANS-CN)
  * [ reflog ](https://git-scm.com/docs/git-reflog/zh_HANS-CN)
  * [ filter-branch ](https://git-scm.com/docs/git-filter-branch/zh_HANS-CN)
  * [ instaweb ](https://git-scm.com/docs/git-instaweb/zh_HANS-CN)
  * [ archive ](https://git-scm.com/docs/git-archive/zh_HANS-CN)
  * [ bundle ](https://git-scm.com/docs/git-bundle/zh_HANS-CN)


### Plumbing Commands
  * [ cat-file ](https://git-scm.com/docs/git-cat-file/zh_HANS-CN)
  * [ check-ignore ](https://git-scm.com/docs/git-check-ignore/zh_HANS-CN)
  * [ checkout-index ](https://git-scm.com/docs/git-checkout-index/zh_HANS-CN)
  * [ commit-tree ](https://git-scm.com/docs/git-commit-tree/zh_HANS-CN)
  * [ count-objects ](https://git-scm.com/docs/git-count-objects/zh_HANS-CN)
  * [ diff-index ](https://git-scm.com/docs/git-diff-index/zh_HANS-CN)
  * [ for-each-ref ](https://git-scm.com/docs/git-for-each-ref/zh_HANS-CN)
  * [ hash-object ](https://git-scm.com/docs/git-hash-object/zh_HANS-CN)
  * [ ls-files ](https://git-scm.com/docs/git-ls-files/zh_HANS-CN)
  * [ ls-tree ](https://git-scm.com/docs/git-ls-tree/zh_HANS-CN)
  * [ merge-base ](https://git-scm.com/docs/git-merge-base/zh_HANS-CN)
  * [ read-tree ](https://git-scm.com/docs/git-read-tree/zh_HANS-CN)
  * [ rev-list ](https://git-scm.com/docs/git-rev-list/zh_HANS-CN)
  * [ rev-parse ](https://git-scm.com/docs/git-rev-parse/zh_HANS-CN)
  * [ show-ref ](https://git-scm.com/docs/git-show-ref/zh_HANS-CN)
  * [ symbolic-ref ](https://git-scm.com/docs/git-symbolic-ref/zh_HANS-CN)
  * [ update-index ](https://git-scm.com/docs/git-update-index/zh_HANS-CN)
  * [ update-ref ](https://git-scm.com/docs/git-update-ref/zh_HANS-CN)
  * [ verify-pack ](https://git-scm.com/docs/git-verify-pack/zh_HANS-CN)
  * [ write-tree ](https://git-scm.com/docs/git-write-tree/zh_HANS-CN)


[ Latest version ▾ ](https://git-scm.com/docs/git/zh_HANS-CN) git last updated in 2.53.0
Changes in the **git** manual
  1. [2.53.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2026-02-02_ ](https://git-scm.com/docs/git/2.53.0)
  2. [2.52.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-11-17_ ](https://git-scm.com/docs/git/2.52.0)
  3. 2.51.2 no changes
  4. [2.51.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-10-15_ ](https://git-scm.com/docs/git/2.51.1)
  5. 2.50.1 → 2.51.0 no changes
  6. [2.50.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-06-16_ ](https://git-scm.com/docs/git/2.50.0)
  7. 2.49.1 no changes
  8. [2.49.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-03-14_ ](https://git-scm.com/docs/git/2.49.0)
  9. 2.48.1 → 2.48.2 no changes
  10. [2.48.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-01-10_ ](https://git-scm.com/docs/git/2.48.0)
  11. 2.47.1 → 2.47.3 no changes
  12. [2.47.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-10-06_ ](https://git-scm.com/docs/git/2.47.0)
  13. 2.46.1 → 2.46.4 no changes
  14. [2.46.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-07-29_ ](https://git-scm.com/docs/git/2.46.0)
  15. 2.45.2 → 2.45.4 no changes
  16. [2.45.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-29_ ](https://git-scm.com/docs/git/2.45.1)
  17. [2.45.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-29_ ](https://git-scm.com/docs/git/2.45.0)
  18. 2.44.2 → 2.44.4 no changes
  19. [2.44.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.44.1)
  20. [2.44.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-02-23_ ](https://git-scm.com/docs/git/2.44.0)
  21. 2.43.5 → 2.43.7 no changes
  22. [2.43.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.43.4)
  23. 2.43.2 → 2.43.3 no changes
  24. [2.43.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-02-09_ ](https://git-scm.com/docs/git/2.43.1)
  25. [2.43.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-11-20_ ](https://git-scm.com/docs/git/2.43.0)
  26. 2.42.3 → 2.42.4 no changes
  27. [2.42.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.42.2)
  28. [2.42.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-11-02_ ](https://git-scm.com/docs/git/2.42.1)
  29. [2.42.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-08-21_ ](https://git-scm.com/docs/git/2.42.0)
  30. 2.41.2 → 2.41.3 no changes
  31. [2.41.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.41.1)
  32. [2.41.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-06-01_ ](https://git-scm.com/docs/git/2.41.0)
  33. 2.40.3 → 2.40.4 no changes
  34. [2.40.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.40.2)
  35. 2.40.1 no changes
  36. 2.40.0 no changes
  37. 2.39.5 no changes
  38. [2.39.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-19_ ](https://git-scm.com/docs/git/2.39.4)
  39. 2.39.1 → 2.39.3 no changes
  40. [2.39.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-12-12_ ](https://git-scm.com/docs/git/2.39.0)
  41. 2.38.3 → 2.38.5 no changes
  42. [2.38.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-12-11_ ](https://git-scm.com/docs/git/2.38.2)
  43. 2.38.1 no changes
  44. [2.38.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-10-02_ ](https://git-scm.com/docs/git/2.38.0)
  45. 2.37.3 → 2.37.7 no changes
  46. [2.37.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-08-11_ ](https://git-scm.com/docs/git/2.37.2)
  47. 2.37.1 no changes
  48. [2.37.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-06-27_ ](https://git-scm.com/docs/git/2.37.0)
  49. 2.36.1 → 2.36.6 no changes
  50. [2.36.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-04-18_ ](https://git-scm.com/docs/git/2.36.0)
  51. 2.35.1 → 2.35.8 no changes
  52. [2.35.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-01-24_ ](https://git-scm.com/docs/git/2.35.0)
  53. 2.34.1 → 2.34.8 no changes
  54. [2.34.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-11-15_ ](https://git-scm.com/docs/git/2.34.0)
  55. 2.33.3 → 2.33.8 no changes
  56. [2.33.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-03-23_ ](https://git-scm.com/docs/git/2.33.2)
  57. [2.33.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-10-12_ ](https://git-scm.com/docs/git/2.33.1)
  58. 2.32.1 → 2.33.0 no changes
  59. [2.32.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-06-06_ ](https://git-scm.com/docs/git/2.32.0)
  60. 2.31.1 → 2.31.8 no changes
  61. [2.31.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-03-15_ ](https://git-scm.com/docs/git/2.31.0)
  62. 2.30.1 → 2.30.9 no changes
  63. [2.30.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-12-27_ ](https://git-scm.com/docs/git/2.30.0)
  64. 2.29.1 → 2.29.3 no changes
  65. [2.29.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-10-19_ ](https://git-scm.com/docs/git/2.29.0)
  66. 2.28.1 no changes
  67. [2.28.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-07-27_ ](https://git-scm.com/docs/git/2.28.0)
  68. 2.27.1 no changes
  69. [2.27.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-06-01_ ](https://git-scm.com/docs/git/2.27.0)
  70. 2.26.1 → 2.26.3 no changes
  71. [2.26.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-03-22_ ](https://git-scm.com/docs/git/2.26.0)
  72. 2.25.2 → 2.25.5 no changes
  73. [2.25.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-02-17_ ](https://git-scm.com/docs/git/2.25.1)
  74. [2.25.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-01-13_ ](https://git-scm.com/docs/git/2.25.0)
  75. 2.23.1 → 2.24.4 no changes
  76. [2.23.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-08-16_ ](https://git-scm.com/docs/git/2.23.0)
  77. 2.22.2 → 2.22.5 no changes
  78. [2.22.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-08-11_ ](https://git-scm.com/docs/git/2.22.1)
  79. [2.22.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-06-07_ ](https://git-scm.com/docs/git/2.22.0)
  80. 2.20.1 → 2.21.4 no changes
  81. [2.20.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-12-09_ ](https://git-scm.com/docs/git/2.20.0)
  82. 2.19.3 → 2.19.6 no changes
  83. [2.19.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-11-21_ ](https://git-scm.com/docs/git/2.19.2)
  84. 2.19.1 no changes
  85. [2.19.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-09-10_ ](https://git-scm.com/docs/git/2.19.0)
  86. 2.18.1 → 2.18.5 no changes
  87. [2.18.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-06-21_ ](https://git-scm.com/docs/git/2.18.0)
  88. 2.17.1 → 2.17.6 no changes
  89. [2.17.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-04-02_ ](https://git-scm.com/docs/git/2.17.0)
  90. [2.16.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git/2.16.6)
  91. [2.15.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git/2.15.4)
  92. [2.14.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/git/2.14.6)
  93. 2.13.7 no changes
  94. [2.12.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git/2.12.5)
  95. [2.11.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git/2.11.4)
  96. [2.10.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/git/2.10.5)
  97. [2.9.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git/2.9.5)
  98. [2.8.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git/2.8.6)
  99. [2.7.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/git/2.7.6)
  100. [2.6.7 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git/2.6.7)
  101. [2.5.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git/2.5.6)
  102. [2.4.12 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/git/2.4.12)
  103. [2.3.10 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2015-09-28_ ](https://git-scm.com/docs/git/2.3.10)
  104. [2.2.3 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2015-09-04_ ](https://git-scm.com/docs/git/2.2.3)
  105. [2.1.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/git/2.1.4)
  106. [2.0.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/git/2.0.5)


Check your version of git by running
`git --version`
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%90%8D%E7%A7%B0)名称
git - 简单的内容追踪系统
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%A6%82%E8%BF%B0)概述
```
_git_ [-v | --version] [-h | --help] [-C <path>] [-c <name>=<value>]
    [--exec-path[=<path>]] [--html-path] [--man-path] [--info-path]
    [-p | --paginate | -P | --no-pager] [--no-replace-objects] [--no-lazy-fetch]
    [--no-optional-locks] [--no-advice] [--bare] [--git-dir=<path>]
    [--work-tree=<path>] [--namespace=<name>] [--config-env=<name>=<envvar>]
    <command> [<args>]
```

##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%8F%8F%E8%BF%B0)描述
Git 是一个快速、可扩展的分布式版本控制系统，它拥有异常丰富的命令集，可以提供高级操作和对内部的完全访问。
参阅 [gittutorial[7]](https://git-scm.com/docs/gittutorial/zh_HANS-CN) 开始使用，然后查看 [giteveryday[7]](https://git-scm.com/docs/giteveryday/zh_HANS-CN) 以获取一组有用的基础命令。 [Git 用户手册](https://git-scm.com/docs/user-manual/zh_HANS-CN)中有对 Git 更为深入的介绍。
在掌握了基本概念之后，你可以回到本页了解 Git 提供的命令。 你可以通过 "git help" 命令了解更多关于单个 Git 命令的信息。 [gitcli[7]](https://git-scm.com/docs/gitcli/zh_HANS-CN) 手册页面提供了命令行命令语法的概述。
最新 Git 文档的格式化和超文本副本可以在 <https://git.github.io/htmldocs/git.html> 或 <https://git-scm.com/docs> 上查看。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E9%80%89%E9%A1%B9)选项

[](https://git-scm.com/docs/git/zh_HANS-CN#git--v)-v


[](https://git-scm.com/docs/git/zh_HANS-CN#git---version)--version

打印 _git_ 程序的 Git 套件版本。
此选项在内部转换为 `git` `version` ... 并接受与[git-version[1]](https://git-scm.com/docs/git-version/zh_HANS-CN) 命令相同的选项。如果 `--version` 后接 `--help` 选项，则会优先展示 `--version` 选项的帮助信息。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--h)-h


[](https://git-scm.com/docs/git/zh_HANS-CN#git---help)--help

打印概要和最常用的命令列表。如果给出选项 `--all` 或 `-a`，则打印所有可用的命令。如果给出某个命令，该选项将调出该命令的手册页面。
因为 `git` `--help` ... 会在内部转换为 `git` `help` ...，所以有关其他可以控制手册页面显示方式的选项可以参阅 [git-help[1]](https://git-scm.com/docs/git-help/zh_HANS-CN) 来获得更详细的信息。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--C) [](https://git-scm.com/docs/git/zh_HANS-CN#git--Cltgt)-C <启动路径>

运行时就像 git 命令在 _< 启动路径>_ 而不是在当前工作目录下启动一样。 当给出多个 `-C` 选项时，每个后续的非绝对的 `-C` _< 启动路径>_ 都是相对于前一个 `-C` _< 启动路径>_ 解释的。 如果 _< 启动路径>_ 存在但为空，例如 `-C` `""`，那么命令就在当前工作目录启动。
这个选项会影响到像 `--git-dir` 和 `--work-tree` 这样的需要路径名的选项，因为它们会用 `-C` 选项设置的启动路径进行相对路径的解释。例如，以下的调用是等价的：
```
git --git-dir=a.git --work-tree=b -C c status
git --git-dir=c/a.git --work-tree=c/b status
```


[](https://git-scm.com/docs/git/zh_HANS-CN#git--c) [](https://git-scm.com/docs/git/zh_HANS-CN#git--cltgtltgt)-c <配置名>=<配置值>

向命令传递一个配置参数。给出的值将覆盖配置文件的值。 <配置名> 的格式应与 _git config_ 列出的格式相同（子键由 `.` 分隔）。
注意在 `git` `-c` `foo.bar` ... 中省略 `=` 是允许的，并会将 `foo.bar` 设置为布尔值 true（就像配置文件中的 [`foo`]`bar` 一样）。包括等号但有一个空值（如 `git` `-c` `foo.bar=` ... ）会将 `foo.bar` 设置为空字符串，如果 `git` `config` `--type=bool` 空值会转换为 `false`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---config-env) [](https://git-scm.com/docs/git/zh_HANS-CN#git---config-envltgtltgt)--config-env=<配置名>=<环境变量>

像 `-c` _< 配置名>_`=`_< 配置值>_ 一样，给配置变量 _< 配置名>_ 一个值，其中 <环境变量> 是一个环境变量的名字，可以从中获取该环境变量的值。与 `-c` 选项不同的是，没有直接将值设置为空字符串的快捷方式，除非环境变量本身就设置为空字符串。 如果 _< 环境变量>_ 在环境变量中不存在，则会报错。 _< 环境变量>_ 不应当包含等号，以避免与包含等号的 _< 配置名>_ 产生歧义。
当你想把临时配置选项传递给 Git，但在操作系统上，其他进程可能能读取你的命令行（如 `/proc/self/cmdline`），但不能读取你的环境（如 `/proc/self/environ`）时，这个功能就很有用了。这种行为在 Linux 上是默认的，但在你的系统上可能不是。
请注意，这可能会增加变量的安全性，例如 `http.extraHeader`，因为他的敏感信息包含在值中，但并不会增加例如 _url. <原始 URL 前缀>.insteadOf_ 这种变量的安全性，因为其敏感信息可能会包含在部分键中。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---exec-path) [](https://git-scm.com/docs/git/zh_HANS-CN#git---exec-pathltgt)--exec-path[=<核心程序路径>]

安装 Git 核心程序的路径。 这也可以通过设置 GIT_EXEC_PATH 环境变量来控制。如果没有给出路径， _git_ 会打印当前的设置，然后退出。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---html-path)--html-path

打印 Git 的 HTML 文档的安装路径（尾部不带斜杠）然后退出。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---man-path)--man-path

打印该版本 Git man page 的 manpath（参阅 `man`(`1`)）之后退出。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---info-path)--info-path

打印记录该版本 Git 信息文件的安装路径并退出。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--p)-p


[](https://git-scm.com/docs/git/zh_HANS-CN#git---paginate)--paginate

如果标准输出是一个终端，则将所有的输出输出到 _less（git 默认的分页器）_ （或者是 $PAGER 变量设置的值）中。 这会覆盖 `pager.`_< cmd>_ 配置选项（参阅下面的 "配置机制" 部分）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--P)-P


[](https://git-scm.com/docs/git/zh_HANS-CN#git---no-pager)--no-pager

不使用分页器进行 Git 的输出。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---git-dir) [](https://git-scm.com/docs/git/zh_HANS-CN#git---git-dirltgt)--git-dir=<仓库路径>

设置仓库的路径（".git" 目录）。这也可以通过设置 `GIT_DIR` 环境变量来控制。<仓库路径> 可以是绝对路径或是当前工作目录的相对路径。
使用该选项（或 `GIT_DIR` 环境变量）指定 ".git" 目录的位置，这会关闭对带有 ".git" 子目录仓库的扫描（这是找到仓库和顶级工作区的方式），并告诉 Git 当前在顶级工作区。 如果当前并不在工作区的顶级目录，你应该用 `--work-tree=`_< 工作区路径>_ 选项（或 `GIT_WORK_TREE` 环境变量）告诉 Git 顶级工作区在哪里
如果你只是想在 _< 启动路径>_ 中运行 Git，可以使用 `git` `-C` _< 启动路径>_。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---work-tree) [](https://git-scm.com/docs/git/zh_HANS-CN#git---work-treeltgt)--work-tree=<工作区路径>

设置工作树的路径。<工作区路径> 可以是一个绝对路径或与当前工作目录相对的路径。 这也可以通过设置 GIT_WORK_TREE 环境变量和 core.worktree 配置变量来控制（参阅 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 core.worktree 获取更为详细的论述）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---namespace) [](https://git-scm.com/docs/git/zh_HANS-CN#git---namespaceltgt)--namespace=<路径>

设置 Git 命名空间。 参阅 [gitnamespaces[7]](https://git-scm.com/docs/gitnamespaces/zh_HANS-CN) 以了解更多细节。 这相当于设置 `GIT_NAMESPACE` 环境变量。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---bare)--bare

将该仓库视为裸仓库。 如果没有设置 GIT_DIR 环境变量，它将在当前工作目录生成仓库。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---no-replace-objects)--no-replace-objects

Do not use replacement refs to replace Git objects. This is equivalent to exporting the `GIT_NO_REPLACE_OBJECTS` environment variable with any value. See [git-replace[1]](https://git-scm.com/docs/git-replace/zh_HANS-CN) for more information.

[](https://git-scm.com/docs/git/zh_HANS-CN#git---no-lazy-fetch)--no-lazy-fetch

不要按需从承诺远程获取缺失的对象。与 `git` `cat-file` `-e` _< object>_ 一起使用很有用，以查看对象是否在本地可用。这相当于将 `GIT_NO_LAZY_FETCH` 环境变量设置为 `1`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---no-optional-locks)--no-optional-locks

禁止执行需要文件锁的可选操作。这相当于将 `GIT_OPTIONAL_LOCKS` 设置为 `0`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---no-advice)--no-advice

禁止打印所有建议提示。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---literal-pathspecs)--literal-pathspecs

按字面意思处理路径规格（即不使用通配符，不使用路径规范功能）。 这相当于将 `GIT_LITERAL_PATHSPECS` 环境变量设置为 `1`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---glob-pathspecs)--glob-pathspecs

在所有的路径规范中添加 "glob" 模式匹配功能。这相当于将 `GIT_GLOB_PATHSPECS` 环境变量设置为 `1`。可以用路径规范字符 ":(literal)" 在单个路径规格上禁用 "glob" 模式匹配功能。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---noglob-pathspecs)--noglob-pathspecs

在所有路径规范中添加 "literal" 模式匹配功能。这相当于将 `GIT_NOGLOB_PATHSPECS` 环境变量设为 `1`。可以使用路径规范字符 ":(glob)" 在单个路径规范上启用通配符模式匹配功能。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---icase-pathspecs)--icase-pathspecs

在所有的路径规范中添加 "icase" 模式匹配功能。这相当于将 `GIT_ICASE_PATHSPECS` 环境变量设置为 `1`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git---list-cmds) [](https://git-scm.com/docs/git/zh_HANS-CN#git---list-cmdsltgtltgt82308203)--list-cmds=<命令组>[,<命令组>…​]

List commands by group. This is an internal/experimental option and may change or be removed in the future. Supported groups are: builtins, parseopt (builtin commands that use parse-options), deprecated (deprecated builtins), main (all commands in libexec directory), others (all other commands in `$PATH` that have git- prefix), list-<category> (see categories in command-list.txt), nohelpers (exclude helper commands), alias and config (retrieve command list from config variable completion.commands)

[](https://git-scm.com/docs/git/zh_HANS-CN#git---attr-source) [](https://git-scm.com/docs/git/zh_HANS-CN#git---attr-sourceltgt)--attr-source=<树对象>

从 <树对象> 而不是工作区中读取 gitattributes。参见 [gitattributes[5]](https://git-scm.com/docs/gitattributes/zh_HANS-CN)。这相当于设置 `GIT_ATTR_SOURCE` 环境变量。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_git_%E5%91%BD%E4%BB%A4)Git 命令
我们把 Git 分为上层封装命令（"瓷件"）和底层核心命令（"管件"）。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E4%B8%8A%E5%B1%82%E5%B0%81%E8%A3%85%E5%91%BD%E4%BB%A4%E7%93%B7%E4%BB%B6)上层封装命令（瓷件）
我们将瓷件命令分为主要命令和一些辅助性的用户工具。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E4%B8%BB%E8%A6%81%E7%93%B7%E4%BB%B6%E5%91%BD%E4%BB%A4)主要瓷件命令
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-mainporcelain.adoc` See original version for this content.
---|---
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E8%BE%85%E5%8A%A9%E5%91%BD%E4%BB%A4)辅助命令
操控：
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-ancillarymanipulators.adoc` See original version for this content.
---|---
审阅：
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-ancillaryinterrogators.adoc` See original version for this content.
---|---
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E4%B8%8E%E5%85%B6%E4%BB%96%E5%BA%94%E7%94%A8%E4%BA%A4%E4%BA%92)与其他应用交互
这些命令是为了与外部 SCM（源代码管理工具）以及通过电子邮件与其他人进行交互。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-foreignscminterface.adoc` See original version for this content.
---|---
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E9%87%8D%E7%BD%AE%E6%81%A2%E5%A4%8D%E5%92%8C%E8%BF%98%E5%8E%9F)重置、恢复和还原
包括了三个名称相似的命令：`git` `reset`、`git` `restore` 和 `git` `revert`。
  * [git-revert[1]](https://git-scm.com/docs/git-revert/zh_HANS-CN) 是关于进行新的提交，以还原其他提交所做更改的命令。
  * [git-restore[1]](https://git-scm.com/docs/git-restore/zh_HANS-CN) 是有关从索引或其他提交中恢复工作区中文件的命令。这个命令不会更新你的分支。该命令也可以用来从另一个提交中恢复索引中的文件。
  * [git-reset[1]](https://git-scm.com/docs/git-reset/zh_HANS-CN) 是有关更新分支、移动提示的命令，以便从分支中添加或删除提交。这个操作会修改提交历史。
`git` `reset` 也可以用来恢复索引，这个功能 `git` `restore` 的功能有些重合。


##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%BA%95%E5%B1%82%E6%A0%B8%E5%BF%83%E5%91%BD%E4%BB%A4%E7%AE%A1%E4%BB%B6)底层核心命令（管件）
尽管 Git 包含了它自己的上层封装命令，但它的底层核心命令足以支持替代上层封装命令的开发。 上层封装命令开发者可以从阅读 [git-update-index[1]](https://git-scm.com/docs/git-update-index/zh_HANS-CN) 和 [git-read-tree[1]](https://git-scm.com/docs/git-read-tree/zh_HANS-CN) 开始。
这些底层命令的界面（输入、输出、选项集和语义）要比上层封装命令稳定得多，因为这些命令主要是用于脚本的使用。 另一方面，为了改善终端用户的体验，上层封装命令接口是可以改变的。
下面的描述将底层核心命令分为操作对象（在仓库、索引和工作目录树中）的命令、审阅和比较对象的命令，以及在仓库之间移动对象和引用的命令。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%8E%A7%E5%88%B6%E5%91%BD%E4%BB%A4)控制命令
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-plumbingmanipulators.adoc` See original version for this content.
---|---
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%AE%A1%E9%98%85%E5%91%BD%E4%BB%A4)审阅命令
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-plumbinginterrogators.adoc` See original version for this content.
---|---
一般来说，审阅命令不接触工作区中的文件。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%90%8C%E6%AD%A5%E4%BB%93%E5%BA%93)同步仓库
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-synchingrepositories.adoc` See original version for this content.
---|---
以下是上面使用的辅助命令，终端用户一般不会直接使用这些命令。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-synchelpers.adoc` See original version for this content.
---|---
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%86%85%E9%83%A8%E8%BE%85%E5%8A%A9%E5%91%BD%E4%BB%A4)内部辅助命令
这些是其他命令使用的内部辅助命令；终端用户一般不会直接使用这些命令。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-purehelpers.adoc` See original version for this content.
---|---
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%8C%87%E5%8D%97)指南
以下文档页是关于 Git 概念的指南。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-guide.adoc` See original version for this content.
---|---
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E4%BB%93%E5%BA%93%E5%91%BD%E4%BB%A4%E5%92%8C%E6%96%87%E4%BB%B6%E6%8E%A5%E5%8F%A3)仓库、命令和文件接口
本文档讨论了用户希望直接与之交互的仓库和命令接口。有关标准的更多细节，请参阅 [git-help[1]](https://git-scm.com/docs/git-help/zh_HANS-CN) 中的 `--user-formats`。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-userinterfaces.adoc` See original version for this content.
---|---
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%96%87%E4%BB%B6%E6%A0%BC%E5%BC%8F%E5%8D%8F%E8%AE%AE%E5%92%8C%E5%85%B6%E4%BB%96%E5%BC%80%E5%8F%91%E8%80%85%E6%8E%A5%E5%8F%A3)文件格式、协议和其他开发者接口
本文档讨论了文件格式、线上协议和其他 git 开发者接口。参阅 [git-help[1]](https://git-scm.com/docs/git-help/zh_HANS-CN) 中的 `--developer-interfaces` 。
Warning |  Missing `zh_HANS-CN/{build_dir}/cmds-developerinterfaces.adoc` See original version for this content.
---|---
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E9%85%8D%E7%BD%AE%E6%9C%BA%E5%88%B6)配置机制
Git 使用一种简单的文本格式来存储每个仓库和每个用户的定制内容。 这样的配置文件可能是像这样：
```
#
# 符号 '#' 或是 ';' 表示本行是注释信息
#

; 核心变量
[core]
	; 不信任文件模式
	filemode = false

; 用户身份信息
[user]
	name = "Junio C Hamano"
	email = "gitster@pobox.com"
```

各种命令从配置文件中读取并相应地调整其操作。有关配置机制的列表和更多细节，请参阅 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN)。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%A0%87%E8%AF%86%E7%AC%A6%E6%9C%AF%E8%AF%AD)标识符术语

[](https://git-scm.com/docs/git/zh_HANS-CN#git-) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt)<对象>

表示任何类型的对象的名称。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-blob) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltblobgt)<blob>

表示一个数据对象的名称。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1)<目录树>

表示一个树对象名称。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1-1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1-1)<提交>

表示一个提交对象名称。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-tree-ish) [](https://git-scm.com/docs/git/zh_HANS-CN#git-lttree-ishgt)<tree-ish>

表示一个树、提交或标签对象的名称。 一个需要 <树对象> 参数的命令最终会对 <树> 对象进行操作，但会自动解除对指向 <树> 对象的 <提交> 和 <标签> 对象的引用。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1-1-1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1-1-1)<提交号>

表示一个提交或标记对象的名称。 一个需要 <提交号> 参数的命令最终要对 <提交> 对象进行操作，但会自动解除对指向 <提交> 的 <标签> 对象的引用。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1-1-1-1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1-1-1-1)<类型>

表示需要一个对象类型。 目前是其中之一：`blob`、`tree`、`commit` 或 `tag`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1-1-1-1-1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1-1-1-1-1)<文件>

表示一个文件名——几乎总是相对于 `GIT_INDEX_FILE` 描述的树状结构的根部文件。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E7%AC%A6%E5%8F%B7%E6%A0%87%E8%AF%86%E7%AC%A6)符号标识符
任何接受任意 <对象> 的 Git 命令也可以使用下面的符号表示法：

[](https://git-scm.com/docs/git/zh_HANS-CN#git-HEAD)HEAD

表示当前分支。

[](https://git-scm.com/docs/git/zh_HANS-CN#git--1-1-1-1-1-1) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltgt-1-1-1-1-1-1)<标签>

一个有效的标签 '名称'（即一个 `refs/tags/`_< 标签>_ 引用）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-head) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltheadgt)<head>

一个有效的分支 '名称'（即一个 `refs/heads/`_< head>_ 引用）。
更完整的对象名称列表，请参阅 [gitrevisions[7]](https://git-scm.com/docs/gitrevisions/zh_HANS-CN) 中的 "校正说明" 部分。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%96%87%E4%BB%B6%E7%9B%AE%E5%BD%95%E7%BB%93%E6%9E%84)文件/目录结构
请参阅 [gitrepository-layout[5]](https://git-scm.com/docs/gitrepository-layout/zh_HANS-CN) 文档。
阅读 [githooks[5]](https://git-scm.com/docs/githooks/zh_HANS-CN) 了解关于每个钩子的更多细节。
Higher level SCMs may provide and manage additional information in the `$GIT_DIR`.
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%9C%AF%E8%AF%AD)术语
请参阅 [gitglossary[7]](https://git-scm.com/docs/gitglossary/zh_HANS-CN)。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E7%8E%AF%E5%A2%83%E5%8F%98%E9%87%8F)环境变量
Various Git commands pay attention to environment variables and change their behavior. The environment variables marked as "Boolean" take their values the same way as Boolean valued configuration variables, i.e., "true", "yes", "on" and positive numbers are taken as "yes", while "false", "no", "off", and "0" are taken as "no".
常规变量：
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_system)System

[](https://git-scm.com/docs/git/zh_HANS-CN#git-HOME) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeHOMEcodespan)`HOME`

Specifies the path to the user's home directory. On Windows, if unset, Git will set a process environment variable equal to: `$HOMEDRIVE$HOMEPATH` if both `$HOMEDRIVE` and `$HOMEPATH` exist; otherwise `$USERPROFILE` if `$USERPROFILE` exists.
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_git_%E4%BB%93%E5%BA%93)Git 仓库
这些环境变量适用于 Git 的 '所有' 核心命令。需要注意的是，如果使用位于 Git 之上的版本控制系统（SCMS），这些环境变量可能会被使用或覆盖，所以在使用非 Git 原生的前端界面时要特别小心。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITINDEXFILE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITINDEXFILEcodespan)`GIT_INDEX_FILE`

这个环境变量指定了一个备用的索引文件。如果没有指定，则默认使用 `$GIT_DIR/index`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITINDEXVERSION) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITINDEXVERSIONcodespan)`GIT_INDEX_VERSION`

这个环境变量指定在写出索引文件时使用什么版本。 它不会影响现有的索引文件。 默认情况下，索引文件的版本为 2 或 3。参见 [git-update-index[1]](https://git-scm.com/docs/git-update-index/zh_HANS-CN) 获取更多信息。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITOBJECTDIRECTORY) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITOBJECTDIRECTORYcodespan)`GIT_OBJECT_DIRECTORY`

如果对象存储目录是通过这个环境变量指定的，那么 sha1 目录将在该目录下创建 ， 否则将使用默认的 `$GIT_DIR/objects` 目录。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITALTERNATEOBJECTDIRECTORIES) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITALTERNATEOBJECTDIRECTORIEScodespan)`GIT_ALTERNATE_OBJECT_DIRECTORIES`

由于 Git 对象的不可改变性，旧的对象可以被归档到共享的只读目录中。这个变量指定了一个由 ":" 分隔（在 Windows 下为 ";" 分隔）的 Git 对象目录列表，可以用来搜索 Git 对象。新的对象将不会写入这些目录中。
以 `"`（双引号）开头的条目将被解释为 C 语言风格字符串路径，去掉前导和后导的双引号，并支持反斜杠转义。例如， _"path-with-\"-and-:-in-it":vanilla-path_ 有两个路径：`path-with-"-and-:-in-it` 和 `vanilla-path`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDIR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDIRcodespan)`GIT_DIR`

如果设置了 `GIT_DIR` 环境变量，那么它会指定一个路径来代替默认的 `.git` 作为仓库的基础目录。 `--git-dir` 命令行选项也能够设置这个值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITWORKTREE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITWORKTREEcodespan)`GIT_WORK_TREE`

设置到工作区的根路径。 这也可以由 `--work-tree` 命令行选项和 core.worktree 配置变量设置。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITNAMESPACE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITNAMESPACEcodespan)`GIT_NAMESPACE`

设置 Git 命名空间；详见 [gitnamespaces[7]](https://git-scm.com/docs/gitnamespaces/zh_HANS-CN)。 `--namespace` 命令行选项也可以设置这个值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCEILINGDIRECTORIES) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCEILINGDIRECTORIEScodespan)`GIT_CEILING_DIRECTORIES`

这个变量值应该是一个用冒号分隔的绝对路径列表。 如果设置了这个变量，它是一个 Git 在寻找仓库目录时不会检查的目录列表（对于排除缓慢加载的网络目录很有用）。 它不会排除当前工作目录或在命令行或环境中设置的 GIT_DIR。 通常情况下，Git 需要读取这个列表中的条目，并解析任何可能存在的符号链接，以便将它们与当前目录进行比较。 然而，如果连这个访问都很慢，你可以在列表中添加一个空条目，告诉 Git 后面的条目不是符号链接，不需要解析；例如，`GIT_CEILING_DIRECTORIES=/maybe/symlink::/very/slow/non/symlink`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDISCOVERYACROSSFILESYSTEM) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDISCOVERYACROSSFILESYSTEMcodespan)`GIT_DISCOVERY_ACROSS_FILESYSTEM`

当在一个没有 ".git " 仓库目录的目录下运行时，Git 会尝试在父目录中找到这样的目录来寻找工作区的顶端，但默认情况下它不会跨越文件系统的边界。 这个布尔环境变量可以被设置为 "true"，以告诉 Git 不要在文件系统边界处停止。 和 `GIT_CEILING_DIRECTORIES` 一样，这不会影响通过 `GIT_DIR` 或在命令行中设置的明确的仓库目录。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCOMMONDIR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCOMMONDIRcodespan)`GIT_COMMON_DIR`

如果这个变量被设置为一个路径，通常在 $GIT_DIR 中的非工作区文件将被从这个路径中取出。工作区中特定的文件，如 HEAD 或 index，则从 $GIT_DIR 取出。详情见 [gitrepository-layout[5]](https://git-scm.com/docs/gitrepository-layout/zh_HANS-CN) 和 [git-worktree[1]](https://git-scm.com/docs/git-worktree/zh_HANS-CN)。这个变量的优先级低于其他路径变量，如 GIT_INDEX_FILE、GIT_OBJECT_DIRECTORY…​

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDEFAULTHASH) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDEFAULTHASHcodespan)`GIT_DEFAULT_HASH`

如果设置了该变量，新仓库的默认哈希算法将设置为该值。克隆时将忽略此值，始终使用远程仓库的设置。默认值为 "sha1"。 参见 [git-init[1]](https://git-scm.com/docs/git-init/zh_HANS-CN) 中的 `--object-format`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDEFAULTREFFORMAT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDEFAULTREFFORMATcodespan)`GIT_DEFAULT_REF_FORMAT`

如果设置了该变量，新仓库的默认引用后端格式将设置为该值。默认为 "files"。参见 [git-init[1]](https://git-scm.com/docs/git-init/zh_HANS-CN) 中的 `--ref-format`。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_git_%E6%8F%90%E4%BA%A4)Git 提交

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITAUTHORNAME) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITAUTHORNAMEcodespan)`GIT_AUTHOR_NAME`

在创建提交、标签对象或在编写日志时，作者身份中使用的可读名称。这会覆盖 `user.name` 和 `author.name` 配置的值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITAUTHOREMAIL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITAUTHOREMAILcodespan)`GIT_AUTHOR_EMAIL`

在创建提交、标签对象或在编写引用日志时，用以表明作者身份所使用的电子邮件地址。这会覆盖 `user.email` 和 `author.email` 的配置值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITAUTHORDATE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITAUTHORDATEcodespan)`GIT_AUTHOR_DATE`

在创建提交、标签对象或在编写引用日志时，用于标注作者修改的日期。有效格式见 [git-commit[1]](https://git-scm.com/docs/git-commit/zh_HANS-CN)。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCOMMITTERNAME) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCOMMITTERNAMEcodespan)`GIT_COMMITTER_NAME`

在创建提交、标签对象或在编写引用日志时，提交者身份中使用的可读名称。这会覆盖 `user.name` 和 `committer.name` 的配置值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCOMMITTEREMAIL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCOMMITTEREMAILcodespan)`GIT_COMMITTER_EMAIL`

在创建提交、标签对象或在编写引用日志时，用以表明提交者所使用的电子邮件地址。这会覆盖 `user.email` 和 `committer.email` 的配置值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCOMMITTERDATE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCOMMITTERDATEcodespan)`GIT_COMMITTER_DATE`

在创建提交、标签对象或在编写 reflogs 时，用于标注提交者所作修改的日期。有效格式见 [git-commit[1]](https://git-scm.com/docs/git-commit/zh_HANS-CN)。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-EMAIL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeEMAILcodespan)`EMAIL`

如果没有设置其他相关的环境变量或配置设置，作者和提交者的电子邮件地址会参考该值。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_git_%E5%B7%AE%E5%BC%82%E6%AF%94%E8%BE%83diffs)Git 差异比较（Diffs）

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDIFFOPTS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDIFFOPTScodespan)`GIT_DIFF_OPTS`

唯一有效的设置是 "--unified=??" 或 "-u??"，用于设置创建统一的差异时显示的文本行数。 这优先于 Git diff 命令行中传递的任何 "-U" 或 "--unified" 选项值。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITEXTERNALDIFF) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITEXTERNALDIFFcodespan)`GIT_EXTERNAL_DIFF`

当环境变量 `GIT_EXTERNAL_DIFF` 被设置时，由它命名的程序被调用来生成差异文本，而不使用 Git 内置的差异比较工具。 对于一个被添加、删除或修改的操作， `GIT_EXTERNAL_DIFF` 会被调用，一共接收 7 个参数：
```
path old-file old-hex old-mode new-file new-hex new-mode
```

使用：

[](https://git-scm.com/docs/git/zh_HANS-CN#git-oldnew-file) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltoldnewgt-file)<old|new>-file

是 GIT_EXTERNAL_DIFF 用来读取 <old|new> 内容的文件，

[](https://git-scm.com/docs/git/zh_HANS-CN#git-oldnew-hex) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltoldnewgt-hex)<old|new>-hex

是 40 个十六进制的 SHA-1 哈希值，

[](https://git-scm.com/docs/git/zh_HANS-CN#git-oldnew-mode) [](https://git-scm.com/docs/git/zh_HANS-CN#git-ltoldnewgt-mode)<old|new>-mode

是文件模式的八进制表示法。
文件参数可以指向用户的工作文件（例如 "git-diff-files" 中的 `new-file`），`/dev/null`（例如在添加新文件时的 `old-file`），或一个临时文件（例如索引中的 `old-file`）。 无需担心 `GIT_EXTERNAL_DIFF` 对临时文件的链接是否解除——当 `GIT_EXTERNAL_DIFF` 退出时，工具对临时文件的链接会被删除。
`GIT_EXTERNAL_DIFF` 被调用时，对于未合并的路径可通过 <path> 进行设置。
在调用每个路径 `GIT_EXTERNAL_DIFF` 时，都会设置两个环境变量 `GIT_DIFF_PATH_COUNTER` 和 `GIT_DIFF_PATH_TOTAL`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITEXTERNALDIFFTRUSTEXITCODE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITEXTERNALDIFFTRUSTEXITCODEcodespan)`GIT_EXTERNAL_DIFF_TRUST_EXIT_CODE`

如果这个布尔环境变量设置为 true，那么期望 `GIT_EXTERNAL_DIFF` 命令在认为输入文件相等时返回退出码 0，在认为它们不相等时返回退出码 1，类似于 `diff`(`1`)。如果它设置为 false，这是默认值，那么期望该命令无论文件是否相等都返回退出码 0。任何其他的退出码都会导致 Git 报告一个致命错误。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDIFFPATHCOUNTER) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDIFFPATHCOUNTERcodespan)`GIT_DIFF_PATH_COUNTER`

以 1 为单位的计数器，每条路径递增 1。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITDIFFPATHTOTAL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITDIFFPATHTOTALcodespan)`GIT_DIFF_PATH_TOTAL`

路径总数。
###  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%85%B6%E4%BB%96)其他

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITMERGEVERBOSITY) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITMERGEVERBOSITYcodespan)`GIT_MERGE_VERBOSITY`

一个用于控制递归合并策略输出量的数字。 会覆盖 merge.verbosity 设置。 参见 [git-merge[1]](https://git-scm.com/docs/git-merge/zh_HANS-CN)

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITPAGER) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITPAGERcodespan)`GIT_PAGER`

该环境变量优先于 `$PAGER`。如果设置为空字符串或 "cat"，Git 将不会启动分页器。 参见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 `core.pager` 选项。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITPROGRESSDELAY) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITPROGRESSDELAYcodespan)`GIT_PROGRESS_DELAY`

A number controlling how many seconds to delay before showing optional progress indicators. Defaults to 1.

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITEDITOR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITEDITORcodespan)`GIT_EDITOR`

该环境变量覆盖 `$EDITOR` 和 `$VISUAL`。 有几条 Git 命令在交互模式下启动编辑器时会用到它。参见 [git-var[1]](https://git-scm.com/docs/git-var/zh_HANS-CN) 和 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 `core.editor` 选项。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITSEQUENCEEDITOR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITSEQUENCEEDITORcodespan)`GIT_SEQUENCE_EDITOR`

在编辑交互式变基的待办事项列表时，该环境变量会覆盖配置的 Git 编辑器。参见 [git-rebase[1]](https://git-scm.com/docs/git-rebase/zh_HANS-CN) 和 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 `sequence.editor` 选项。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITSSH) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITSSHcodespan)`GIT_SSH`


[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITSSHCOMMAND) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITSSHCOMMANDcodespan)`GIT_SSH_COMMAND`

如果设置了这两个环境变量中的任何一个， _git fetch_ 和 _git push_ 在连接远程系统时就会使用指定的命令而不是 _ssh_ 。 传递给配置命令的命令行参数由 ssh 变量决定。 详见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 `ssh.variant` 选项。
`$GIT_SSH_COMMAND` 优先于 `$GIT_SSH`，由 shell 解释，允许包含额外参数。 另一方面，`$GIT_SSH` 必须是一个程序的路径（如果程序需要额外参数，可以是一个 shell 脚本）。
通常，通过个人的 `.ssh/config` 文件配置任何所需的选项会更容易。 详情请查阅 ssh 文档。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITSSHVARIANT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITSSHVARIANTcodespan)`GIT_SSH_VARIANT`

如果设置了这个环境变量，Git 会自动检测 `GIT_SSH`/`GIT_SSH_COMMAND`/`core.sshCommand` 是否指向 OpenSSH、plink 或 tortoiseplink。该变量覆盖了具有相同作用的配置设置 `ssh.variant`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITSSLNOVERIFY) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITSSLNOVERIFYcodespan)`GIT_SSL_NO_VERIFY`

将此环境变量设置并导出为任意值，Git 就不会在通过 HTTPS 获取或推送数据时验证 SSL 证书。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITATTRSOURCE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITATTRSOURCEcodespan)`GIT_ATTR_SOURCE`

设置读取 gitattributes 的树状对象。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITASKPASS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITASKPASScodespan)`GIT_ASKPASS`

如果设置了这个环境变量，那么需要获取密码或口令的 Git 命令（例如用于 HTTP 或 IMAP 身份验证）就会调用这个程序，并将合适的提示符作为命令行参数，然后从其 STDOUT 中读取密码。参见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中的 `core.askPass` 选项。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTERMINALPROMPT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTERMINALPROMPTcodespan)`GIT_TERMINAL_PROMPT`

如果将此布尔环境变量设为 false，git 将不会在终端上提示（例如，要求 HTTP 认证时）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCONFIGGLOBAL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCONFIGGLOBALcodespan)`GIT_CONFIG_GLOBAL`


[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCONFIGSYSTEM) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCONFIGSYSTEMcodespan)`GIT_CONFIG_SYSTEM`

从给定文件中获取配置，而不是从全局或系统级配置文件中获取。如果设置了 `GIT_CONFIG_SYSTEM`，则不会读取构建时定义的系统配置文件（通常是 `/etc/gitconfig`）。同样，如果设置了 `GIT_CONFIG_GLOBAL`，则既不会读取 `$HOME/.gitconfig` 也不会读取 `$XDG_CONFIG_HOME/git/config`。可以设置为 `/dev/null`，以跳过读取相应级别的配置文件。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCONFIGNOSYSTEM) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCONFIGNOSYSTEMcodespan)`GIT_CONFIG_NOSYSTEM`

是否跳过从系统范围内的 `$`(`prefix`)`/etc/gitconfig` 文件读取设置。 这个布尔环境变量可以与 `$HOME` 和 `$XDG_CONFIG_HOME` 一起使用，为挑剔的脚本创建一个可预测的环境，也可以设为 true 以暂时避免使用有错误的 `/etc/gitconfig` 文件，等待有足够权限的人来修复它。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITFLUSH) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITFLUSHcodespan)`GIT_FLUSH`

如果该布尔环境变量设置为 true，那么诸如 _git blame_ （增量模式）、 _git rev-list_ 、 _git log_ 、 _git check-attr_ 和 _git check-ignore_ 等命令将会在每条记录被刷新后强制刷新输出流。强制刷新输出流。如果该变量设置为 false，这些命令的输出将使用完全缓冲的 I/O 方式进行使用完全缓冲的 I/O 输出。 如果不设置这个环境变量不设置，Git 将根据标准输出流是否重定向到文件，选择缓冲或面向记录的刷新方式根据标准输出流是否被重定向到文件。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEcodespan)`GIT_TRACE`

启用一般跟踪信息，如别名扩展、内置命令执行和外部命令执行。
如果该变量设置为 "1"、"2" 或 "true"（比较不区分大小写），跟踪信息将被打印到标准错误流。
如果变量设置为大于 2 小于 10（严格意义上）的整数值，那么 Git 会将该值解释为一个打开的文件描述符，并尝试将跟踪信息写入该文件描述符。
另外，如果变量设置为绝对路径（以 _/_ 字符开头），Git 会将其理解为文件路径，并尝试将跟踪信息附加到该路径上。
取消对变量的设置，或将其设置为空、"0" 或 "false"（不区分大小写），将禁用跟踪信息。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEFSMONITOR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEFSMONITORcodespan)`GIT_TRACE_FSMONITOR`

启用文件系统监视器扩展的跟踪信息。 有关可用的跟踪输出选项，请参阅 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEPACKACCESS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEPACKACCESScodespan)`GIT_TRACE_PACK_ACCESS`

启用对所有数据包访问的跟踪信息。每次访问都会记录包文件名和包中的偏移量。这可能有助于排除一些与包相关的性能问题。 有关可用的跟踪输出选项，请参阅 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEPACKET) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEPACKETcodespan)`GIT_TRACE_PACKET`

启用对进出指定程序的所有数据包的跟踪信息。这有助于调试对象协商或其他协议问题。以 "PACK" 开头的数据包会关闭跟踪（但请参阅下文的 `GIT_TRACE_PACKFILE`）。 有关可用的跟踪输出选项，请参见 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEPACKFILE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEPACKFILEcodespan)`GIT_TRACE_PACKFILE`

可跟踪指定程序发送或接收的打包文件。与其他跟踪输出不同，这种跟踪是逐字的：没有标题，也不引用二进制数据。你几乎肯定希望将其直接存入一个文件（例如 `GIT_TRACE_PACKFILE=/tmp/my.pack`），而不是显示在终端上或与其他跟踪输出混在一起。
请注意，目前仅在克隆和获取的客户端实施了这一功能。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEPERFORMANCE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEPERFORMANCEcodespan)`GIT_TRACE_PERFORMANCE`

启用与性能相关的跟踪信息，例如每条 Git 命令的总执行时间。 有关可用的跟踪输出选项，请参见 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEREFS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEREFScodespan)`GIT_TRACE_REFS`

启用引用数据库操作的跟踪信息。 有关可用的跟踪输出选项，请参见 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACESETUP) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACESETUPcodespan)`GIT_TRACE_SETUP`

在 Git 完成设置阶段后，启用打印 .git、工作树和当前工作目录的跟踪信息。 有关可用的跟踪输出选项，请参见 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACESHALLOW) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACESHALLOWcodespan)`GIT_TRACE_SHALLOW`

启用可帮助调试获取/克隆浅仓库的跟踪信息。 有关可用的跟踪输出选项，请参见 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACECURL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACECURLcodespan)`GIT_TRACE_CURL`

启用对 git 传输协议所有传入和传出数据（包括描述性信息）的 curl 完整跟踪转储。 这类似于在命令行上执行 curl `--trace-ascii`。 有关可用的跟踪输出选项，请参阅 `GIT_TRACE`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACECURLNODATA) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACECURLNODATAcodespan)`GIT_TRACE_CURL_NO_DATA`

启用 curl 跟踪时（见上文 `GIT_TRACE_CURL`），不要转储数据（即只转储信息行和头文件）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACE2) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACE2codespan)`GIT_TRACE2`

启用来自 "trace2" 库的更详细的跟踪信息。 `GIT_TRACE2` 的输出是一种简单的文本格式，可读性高。
如果该变量设置为 "1"、"2" 或 "true"（比较不区分大小写），跟踪信息将被打印到标准错误流。
如果变量设置为大于 2 小于 10（严格意义上）的整数值，那么 Git 会将该值解释为一个打开的文件描述符，并尝试将跟踪信息写入该文件描述符。
另外，如果变量设置为绝对路径（以 _/_ 字符开头），Git 会将其理解为文件路径，并尝试将跟踪信息附加到该路径上。 如果路径已经存在且是一个目录，跟踪信息将被写入该目录下的文件（每个进程一个），文件名根据 SID 的最后一个分量和一个可选的计数器命名（以避免文件名冲突）。
此外，如果变量设置为 `af_unix:`[_< 套接字类型>_`:`]_< 绝对文件路径>_，Git 将尝试以 Unix 域套接字的方式打开路径。 套接字类型可以是 `stream` 或 `dgram`。
取消对变量的设置，或将其设置为空、"0" 或 "false"（不区分大小写），将禁用跟踪信息。
详见 [Trace2 文档](https://git-scm.com/docs/api-trace2/zh_HANS-CN)。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACE2EVENT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACE2EVENTcodespan)`GIT_TRACE2_EVENT`

此设置会写入适合机器解释的基于 JSON 的格式。 有关可用的跟踪输出选项，请参阅 `GIT_TRACE2`，以及 [Trace2 文档](https://git-scm.com/docs/api-trace2/zh_HANS-CN) 了解更多详情。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACE2PERF) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACE2PERFcodespan)`GIT_TRACE2_PERF`

除了 `GIT_TRACE2` 中可用的基于文本的信息外，此设置还可写入基于列的格式，以了解嵌套区域。 有关可用的跟踪输出选项，请参阅 `GIT_TRACE2`，以及 [Trace2 文档](https://git-scm.com/docs/api-trace2/zh_HANS-CN) 了解更多详情。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITTRACEREDACT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITTRACEREDACTcodespan)`GIT_TRACE_REDACT`

默认情况下，启动跟踪后，Git 会编辑 cookie、"Authorization:"（授权：）标头、"Proxy-Authorization:"（代理授权：）标头和 packfile URI 的值。将此布尔环境变量设为 false，可阻止这种编辑。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITNOREPLACEOBJECTS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITNOREPLACEOBJECTScodespan)`GIT_NO_REPLACE_OBJECTS`

Setting and exporting this environment variable tells Git to ignore replacement refs and do not replace Git objects.

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITLITERALPATHSPECS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITLITERALPATHSPECScodespan)`GIT_LITERAL_PATHSPECS`

将这个布尔环境变量设为 true 会导致 Git 按字面意思而非通配符模式来处理所有路径规范。例如，运行 `GIT_LITERAL_PATHSPECS=1` `git` `log` `--` `*.c'` 将搜索涉及路径 `*.c` 的提交，而不是任何与通配符 `*.c` 匹配的路径。如果你正在向 Git 输入字面路径（例如，之前由 `git` `ls-tree`、`--raw` 差异输出等提供的路径），你可能需要这样做。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITGLOBPATHSPECS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITGLOBPATHSPECScodespan)`GIT_GLOB_PATHSPECS`

将这个布尔环境变量设置为 true 会导致 Git 将所有路径规范视为通配符模式（又称 "glob" 魔法）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITNOGLOBPATHSPECS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITNOGLOBPATHSPECScodespan)`GIT_NOGLOB_PATHSPECS`

将这个布尔环境变量设置为 true，Git 就会将所有路径规范都视为字面意思（又称 "literal"（字面）魔法）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITICASEPATHSPECS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITICASEPATHSPECScodespan)`GIT_ICASE_PATHSPECS`

将此布尔环境变量设置为 true 会导致 Git 将所有路径规范视为不区分大小写。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITNOLAZYFETCH) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITNOLAZYFETCHcodespan)`GIT_NO_LAZY_FETCH`

Setting this Boolean environment variable to true tells Git not to lazily fetch missing objects from the promisor remote on demand.

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITREFLOGACTION) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITREFLOGACTIONcodespan)`GIT_REFLOG_ACTION`

更新引用时，会创建引用日志条目来记录更新引用的原因（通常是更新引用的高级命令的名称），以及引用的新旧值。 脚本化的上层命令可以使用 `git-sh-setup` 中的 set_reflog_action 辅助函数，在被最终用户作为顶级命令调用时将其名称设置为该变量，并记录在引用日志的正文中。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITREFPARANOIA) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITREFPARANOIAcodespan)`GIT_REF_PARANOIA`

如果将此布尔环境变量设置为 false，则在遍历引用列表时会忽略已损坏或命名不正确的引用。通常情况下，Git 会尝试包含任何此类引用，这可能会导致某些操作失败。这通常是可取的，因为潜在的破坏性操作（例如 [git-prune[1]](https://git-scm.com/docs/git-prune/zh_HANS-CN)）最好是中止，而不是忽略破损的引用（从而认为它们指向的历史不值得保存）。默认值是 `1`（即偏执地检测并终止所有操作）。通常不需要将其设置为 `0`，但在试图从损坏的版本库中挽救数据时可能会有用。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITCOMMITGRAPHPARANOIA) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITCOMMITGRAPHPARANOIAcodespan)`GIT_COMMIT_GRAPH_PARANOIA`

从提交图加载提交对象时，Git 会对对象数据库中的对象执行存在性检查。这样做是为了避免出现陈旧的提交图（其中包含对已删除提交的引用），但同时也会影响性能。
默认值为 "false"，即禁用上述行为。将其设置为 "true" 可启用存在性检查，这样就不会从提交图中返回过时的提交，但这也会影响性能。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITALLOWPROTOCOL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITALLOWPROTOCOLcodespan)`GIT_ALLOW_PROTOCOL`

如果设置为以冒号分隔的协议列表，其行为就好像 `protocol.allow` 被设置为 `never` 而每个列出的协议都被 `protocol.`_< 名称>_`.allow` 设置为 `always`（覆盖任何现有配置）。详见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中关于 `protocol.allow` 的描述。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITPROTOCOLFROMUSER) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITPROTOCOLFROMUSERcodespan)`GIT_PROTOCOL_FROM_USER`

将此布尔环境变量设为 false，以防止 fetch/push/clone 使用配置为 `user` 状态的协议。 这对于限制从不可信任的仓库或向 git 命令提供可能不可信任的 URLS 的程序递归初始化子模块非常有用。 详见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN)。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITPROTOCOL) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITPROTOCOLcodespan)`GIT_PROTOCOL`

For internal use only. Used in handshaking the wire protocol. Contains a colon _:_ separated list of keys with optional values _< key>[=<value>]_. Presence of unknown keys and values must be ignored.
请注意，可能需要对服务器进行配置，以允许该变量通过某些传输方式传递。在访问本地仓库（即 `file://` 或文件系统路径）以及通过 `git://` 协议时，它会自动传播。对于 git-over-http，它在大多数配置中都会自动工作，但请参阅 [git-http-backend[1]](https://git-scm.com/docs/git-http-backend/zh_HANS-CN) 中的讨论。对于 git-over-ssh，可能需要配置 ssh 服务器以允许客户端传递此变量（例如，在 OpenSSH 中使用 `AcceptEnv` `GIT_PROTOCOL`）。
此配置为可选配置。如果不传播该变量，客户端将退回到原始的 "v0" 协议（但可能会错过某些性能改进或功能）。该变量目前只影响克隆和获取，尚未用于推送（但将来可能会）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITOPTIONALLOCKS) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITOPTIONALLOCKScodespan)`GIT_OPTIONAL_LOCKS`

如果把这个布尔环境变量设置为 false，Git 将在不执行任何需要加锁的可选子操作的情况下完成任何请求的操作。 例如，这将防止 `git` `status` 刷新索引的副作用。这对后台运行的进程非常有用，因为它们不希望与仓库中的其他操作造成锁争用。 默认值为 `1`。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITREDIRECTSTDIN) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITREDIRECTSTDINcodespan)`GIT_REDIRECT_STDIN`


[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITREDIRECTSTDOUT) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITREDIRECTSTDOUTcodespan)`GIT_REDIRECT_STDOUT`


[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITREDIRECTSTDERR) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITREDIRECTSTDERRcodespan)`GIT_REDIRECT_STDERR`

仅限 Windows：允许将标准输入/输出/错误句柄重定向到环境变量指定的路径。这在多线程应用程序中特别有用，因为通过 `CreateProcess`() 传递标准句柄的标准方式并不可行，因为这需要将句柄标记为可继承（因此 **每个** 生成的进程都会继承它们，可能会阻塞常规的 Git 操作）。主要的预期用例是使用命名管道进行通信（例如 _\\\\.\pipe\my-git-stdin-123_ ）。
支持两个特殊值： 如果 `GIT_REDIRECT_STDERR` 是 _2 >&1_ ，标准错误将重定向到与标准输出相同的句柄。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITPRINTSHA1ELLIPSIS)GIT_PRINT_SHA1_ELLIPSIS（已弃用）

如果设置为 `yes`，会在 SHA-1 值（缩写）后打印省略号。 这会影响分离 HEAD 的指示（[git-checkout[1]](https://git-scm.com/docs/git-checkout/zh_HANS-CN)）和原始差异输出（[git-diff[1]](https://git-scm.com/docs/git-diff/zh_HANS-CN)）。 在上述情况下打印省略号不再被认为是适当的，在可预见的将来，对它的支持可能会被移除（连同变量）。

[](https://git-scm.com/docs/git/zh_HANS-CN#git-GITADVICE) [](https://git-scm.com/docs/git/zh_HANS-CN#git-spanclasssynopsiscodeGITADVICEcodespan)`GIT_ADVICE`

如果设置为 `0`，则禁用所有建议信息。这些信息旨在为用户提供提示，帮助他们摆脱困境或利用新功能。用户可以使用 `advice.*` 配置键禁用单个信息。这些信息可能会对执行 Git 进程的工具造成干扰，因此可以使用此变量来禁用这些信息。(`--no-advice` 全局选项也可使用，但旧版本的 Git 可能会因为无法理解该选项而失效。不理解该环境变量版本的 Git 会忽略它。）
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E8%AE%A8%E8%AE%BA)讨论
有关以下内容的更多详情，请参阅[用户手册中的 Git 概念章节](https://git-scm.com/docs/user-manual/zh_HANS-CN#git-concepts)和 [gitcore-tutorial[7]](https://git-scm.com/docs/gitcore-tutorial/zh_HANS-CN)。
Git 项目通常由一个工作目录和一个位于顶层的 ".git " 子目录组成。 除其他内容外，.git 目录还包含一个压缩对象数据库，代表项目的完整历史；一个 "index" 文件，将历史记录与当前工作区的内容相链接；以及指向历史记录的命名指针，如标签和分支头。
对象数据库包含三种主要类型的对象：blobs，用于保存文件数据；tree，用于指向 blobs 和其他树，以建立目录层次结构；commits，用于引用单个树和一定数量的父提交。
提交相当于其他系统所说的 "changeset" 或 "version"，代表项目历史中的一个步骤，每个父提交代表紧接着的前一个步骤。 有多个父提交的提交代表独立开发线的合并。
所有对象都以其内容的 SHA-1 哈希值命名，通常写成由 40 个十六进制数字组成的字符串。 这些名称具有全局唯一性。 只需对某个提交进行签名，就能证明该提交之前的整个历史。 为此，我们提供了第四种对象类型——tag（标签）。
首次创建时，对象存储在单个文件中，但为了提高效率，以后可能会压缩成 "pack files"。
被称为引用的已命名指针会标记历史中的有趣点。一个引用可以包含一个对象的 SHA-1 名称或另一个引用的名称（后者称为"符号引用"）。名称以 `refs/head/` 开头的引用包含开发中分支的最新提交（或 "head"）的 SHA-1 名称。相关标记的 SHA-1 名称存储在 `refs/tags/` 下。名为 `HEAD` 的符号引用包含当前已签出分支的名称。
索引文件初始化时包含一个所有路径的列表，以及每个路径的一个二进制对象和一组属性。 二进制对象代表当前分支头部的文件内容。 属性（最后修改时间、大小等）取自工作树中的相应文件。 通过比较这些属性，可以发现工作区的后续更改。 索引可根据新内容进行更新，也可根据索引中存储的内容创建新提交。
索引还能为给定路径名存储多个条目（称为 "stages"（阶段））。 在合并过程中，这些阶段用于保存文件的各种未合并版本。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%AE%89%E5%85%A8)安全
一些配置选项和钩子文件可能会使 Git 运行任意的 shell 命令。因为配置和钩子不会通过 `git` `clone` 被复制，所以通常可以安全地克隆含有不受信任内容的远程仓库，使用 `git` `log` 检查它们等等。
然而，当 `.git` 目录本身来自一个不受信任的源时，在 `.git` 目录（或其周围的工作树）中运行 Git 命令是不安全的。该目录中的配置和钩子中的命令会以通常的方式执行。
默认情况下，当仓库由运行命令的用户以外的其他人拥有时，Git 将拒绝运行。请参见 [git-config[1]](https://git-scm.com/docs/git-config/zh_HANS-CN) 中 `safe.directory` 的条目。虽然这可以在多用户环境中帮助保护您，但请注意，您也可以获取由您拥有的不受信任的仓库（例如，如果您从不受信任的源提取 zip 文件或 tarball）。在这种情况下，您需要先"净化"不受信任的仓库。
如果您有一个不受信任的 `.git` 目录，您应该首先使用 `git` `clone` `--no-local` 来克隆它以获得一个干净的副本。Git 确实限制了由 `upload-pack` 执行的选项和钩子集合，`upload-pack` 处理克隆或提取的服务器端，但请注意，针对 `upload-pack` 的攻击面很大，所以这确实存在一些风险。最安全的方法是以非特权用户身份提供仓库（通过 [git-daemon[1]](https://git-scm.com/docs/git-daemon/zh_HANS-CN)，ssh，或使用其他工具更改用户 ID）。请参见 [git-upload-pack[1]](https://git-scm.com/docs/git-upload-pack/zh_HANS-CN) 的 _安全_ 部分的讨论。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%9B%B4%E5%A4%9A%E6%96%87%E4%BB%B6)更多文件
请参阅 "说明" 部分的参考资料，开始使用 Git。 对于初次使用 Git 的用户来说，以下内容可能过于详细。
[用户手册中的 Git 概念章节](https://git-scm.com/docs/user-manual/zh_HANS-CN#git-concepts)和 [gitcore-tutorial[7]](https://git-scm.com/docs/gitcore-tutorial/zh_HANS-CN) 都介绍了 Git 的底层架构。
请参阅 [gitworkflows[7]](https://git-scm.com/docs/gitworkflows/zh_HANS-CN) 了解推荐的工作流程。
另请参阅 [howto](https://git-scm.com/docs/howto-index/zh_HANS-CN) 文档，了解一些有用的示例。
[Git API 文档](https://git-scm.com/docs/api-index/zh_HANS-CN)中介绍了内部结构。
从 CVS 迁移的用户可能还需要阅读 [gitcvs-migration[7]](https://git-scm.com/docs/gitcvs-migration/zh_HANS-CN)。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E4%BD%9C%E8%80%85)作者
Git 由 Linus Torvalds 发起，目前由 Junio C Hamano 维护。许多贡献来自 Git 邮件列表 <git@vger.kernel.org>。http://www.openhub.net/p/git/contributors/summary 提供了更完整的贡献者名单。
如果克隆了 git.git，[git-shortlog[1]](https://git-scm.com/docs/git-shortlog/zh_HANS-CN) 和 [git-blame[1]](https://git-scm.com/docs/git-blame/zh_HANS-CN) 的输出结果可以显示项目特定部分的作者。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E6%8A%A5%E5%91%8A%E7%BC%BA%E9%99%B7)报告缺陷
向 Git 邮件列表 <git@vger.kernel.org> 报告错误，开发和维护工作主要在此进行。 您无需订阅该列表即可在此发送信息。 有关以前的错误报告和其他讨论，请参阅 <https://lore.kernel.org/git> 的列表档案。
与安全相关的问题应在 Git 安全邮件列表 <git-security@googlegroups.com> 中私下披露。
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_%E5%8F%82%E8%A7%81)参见
[gittutorial[7]](https://git-scm.com/docs/gittutorial/zh_HANS-CN), [gittutorial-2[7]](https://git-scm.com/docs/gittutorial-2/zh_HANS-CN), [giteveryday[7]](https://git-scm.com/docs/giteveryday/zh_HANS-CN), [gitcvs-migration[7]](https://git-scm.com/docs/gitcvs-migration/zh_HANS-CN), [gitglossary[7]](https://git-scm.com/docs/gitglossary/zh_HANS-CN), [gitcore-tutorial[7]](https://git-scm.com/docs/gitcore-tutorial/zh_HANS-CN), [gitcli[7]](https://git-scm.com/docs/gitcli/zh_HANS-CN), [Git 用户手册](https://git-scm.com/docs/user-manual/zh_HANS-CN), [gitworkflows[7]](https://git-scm.com/docs/gitworkflows/zh_HANS-CN)
##  [](https://git-scm.com/docs/git/zh_HANS-CN#_git)GIT
属于 [git[1]](https://git-scm.com/docs/git/zh_HANS-CN) 文档
[About this site](https://git-scm.com/site)
Patches, suggestions, and comments are welcome.
Git is a member of [Software Freedom Conservancy](https://git-scm.com/sfc)
