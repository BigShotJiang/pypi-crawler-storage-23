[![Git](https://git-scm.com/images/logo@2x.png)](https://git-scm.com/) --local-branching-on-the-cheap
![](https://git-scm.com/images/dark-mode.svg)
  * [About](https://git-scm.com/about)
    * [Trademark](https://git-scm.com/about/trademark)
  * [Learn](https://git-scm.com/learn)
    * [Book](https://git-scm.com/book)
    * [Cheat Sheet](https://git-scm.com/cheat-sheet)
    * [Videos](https://git-scm.com/videos)
    * [External Links](https://git-scm.com/doc/ext)
  * [Tools](https://git-scm.com/tools)
    * [Command Line](https://git-scm.com/tools/command-line)
    * [GUIs](https://git-scm.com/tools/guis)
    * [Hosting](https://git-scm.com/tools/hosting)
  * [Reference](https://git-scm.com/docs)
  * [Install](https://git-scm.com/install/linux)
  * [Community](https://git-scm.com/community)


  * Table of Contents
    * [NAME](https://git-scm.com/docs/githooks#_name)
    * [SYNOPSIS](https://git-scm.com/docs/githooks#_synopsis)
    * [DESCRIPTION](https://git-scm.com/docs/githooks#_description)
    * [HOOKS](https://git-scm.com/docs/githooks#_hooks)
    * [SEE ALSO](https://git-scm.com/docs/githooks#_see_also)
    * [GIT](https://git-scm.com/docs/githooks#_git)


[ English ▾](https://git-scm.com/docs/githooks)
Localized versions of **githooks** manual
  1. [English ](https://git-scm.com/docs/githooks)

Want to read in your language or fix typos?
[You can help translate this page](https://github.com/jnavila/git-manpages-l10n).
[Topics ▾](https://git-scm.com/docs/githooks)
### Setup and Config
  * [ git ](https://git-scm.com/docs/git)
  * [ config ](https://git-scm.com/docs/git-config)
  * [ help ](https://git-scm.com/docs/git-help)
  * [ bugreport ](https://git-scm.com/docs/git-bugreport)
  * [ Credential helpers ](https://git-scm.com/doc/credential-helpers)


### Getting and Creating Projects
  * [ init ](https://git-scm.com/docs/git-init)
  * [ clone ](https://git-scm.com/docs/git-clone)


### Basic Snapshotting
  * [ add ](https://git-scm.com/docs/git-add)
  * [ status ](https://git-scm.com/docs/git-status)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ commit ](https://git-scm.com/docs/git-commit)
  * [ notes ](https://git-scm.com/docs/git-notes)
  * [ restore ](https://git-scm.com/docs/git-restore)
  * [ reset ](https://git-scm.com/docs/git-reset)
  * [ rm ](https://git-scm.com/docs/git-rm)
  * [ mv ](https://git-scm.com/docs/git-mv)


### Branching and Merging
  * [ branch ](https://git-scm.com/docs/git-branch)
  * [ checkout ](https://git-scm.com/docs/git-checkout)
  * [ switch ](https://git-scm.com/docs/git-switch)
  * [ merge ](https://git-scm.com/docs/git-merge)
  * [ mergetool ](https://git-scm.com/docs/git-mergetool)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ stash ](https://git-scm.com/docs/git-stash)
  * [ tag ](https://git-scm.com/docs/git-tag)
  * [ worktree ](https://git-scm.com/docs/git-worktree)


### Sharing and Updating Projects
  * [ fetch ](https://git-scm.com/docs/git-fetch)
  * [ pull ](https://git-scm.com/docs/git-pull)
  * [ push ](https://git-scm.com/docs/git-push)
  * [ remote ](https://git-scm.com/docs/git-remote)
  * [ submodule ](https://git-scm.com/docs/git-submodule)


### Inspection and Comparison
  * [ show ](https://git-scm.com/docs/git-show)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ difftool ](https://git-scm.com/docs/git-difftool)
  * [ range-diff ](https://git-scm.com/docs/git-range-diff)
  * [ shortlog ](https://git-scm.com/docs/git-shortlog)
  * [ describe ](https://git-scm.com/docs/git-describe)


### Patching
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ cherry-pick ](https://git-scm.com/docs/git-cherry-pick)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ rebase ](https://git-scm.com/docs/git-rebase)
  * [ revert ](https://git-scm.com/docs/git-revert)


### Debugging
  * [ bisect ](https://git-scm.com/docs/git-bisect)
  * [ blame ](https://git-scm.com/docs/git-blame)
  * [ grep ](https://git-scm.com/docs/git-grep)


### Email
  * [ am ](https://git-scm.com/docs/git-am)
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ imap-send ](https://git-scm.com/docs/git-imap-send)
  * [ format-patch ](https://git-scm.com/docs/git-format-patch)
  * [ send-email ](https://git-scm.com/docs/git-send-email)
  * [ request-pull ](https://git-scm.com/docs/git-request-pull)


### External Systems
  * [ svn ](https://git-scm.com/docs/git-svn)
  * [ fast-import ](https://git-scm.com/docs/git-fast-import)


### Server Admin
  * [ daemon ](https://git-scm.com/docs/git-daemon)
  * [ update-server-info ](https://git-scm.com/docs/git-update-server-info)


### Guides
  * [ gitattributes ](https://git-scm.com/docs/gitattributes)
  * [ Command-line interface conventions ](https://git-scm.com/docs/gitcli)
  * [ Everyday Git ](https://git-scm.com/docs/giteveryday)
  * [ Frequently Asked Questions (FAQ) ](https://git-scm.com/docs/gitfaq)
  * [ Glossary ](https://git-scm.com/docs/gitglossary)
  * [ Hooks ](https://git-scm.com/docs/githooks)
  * [ gitignore ](https://git-scm.com/docs/gitignore)
  * [ gitmodules ](https://git-scm.com/docs/gitmodules)
  * [ Revisions ](https://git-scm.com/docs/gitrevisions)
  * [ Submodules ](https://git-scm.com/docs/gitsubmodules)
  * [ Tutorial ](https://git-scm.com/docs/gittutorial)
  * [ Workflows ](https://git-scm.com/docs/gitworkflows)
  * [ All guides... ](https://git-scm.com/docs/git#_guides)


### Administration
  * [ clean ](https://git-scm.com/docs/git-clean)
  * [ gc ](https://git-scm.com/docs/git-gc)
  * [ fsck ](https://git-scm.com/docs/git-fsck)
  * [ reflog ](https://git-scm.com/docs/git-reflog)
  * [ filter-branch ](https://git-scm.com/docs/git-filter-branch)
  * [ instaweb ](https://git-scm.com/docs/git-instaweb)
  * [ archive ](https://git-scm.com/docs/git-archive)
  * [ bundle ](https://git-scm.com/docs/git-bundle)


### Plumbing Commands
  * [ cat-file ](https://git-scm.com/docs/git-cat-file)
  * [ check-ignore ](https://git-scm.com/docs/git-check-ignore)
  * [ checkout-index ](https://git-scm.com/docs/git-checkout-index)
  * [ commit-tree ](https://git-scm.com/docs/git-commit-tree)
  * [ count-objects ](https://git-scm.com/docs/git-count-objects)
  * [ diff-index ](https://git-scm.com/docs/git-diff-index)
  * [ for-each-ref ](https://git-scm.com/docs/git-for-each-ref)
  * [ hash-object ](https://git-scm.com/docs/git-hash-object)
  * [ ls-files ](https://git-scm.com/docs/git-ls-files)
  * [ ls-tree ](https://git-scm.com/docs/git-ls-tree)
  * [ merge-base ](https://git-scm.com/docs/git-merge-base)
  * [ read-tree ](https://git-scm.com/docs/git-read-tree)
  * [ rev-list ](https://git-scm.com/docs/git-rev-list)
  * [ rev-parse ](https://git-scm.com/docs/git-rev-parse)
  * [ show-ref ](https://git-scm.com/docs/git-show-ref)
  * [ symbolic-ref ](https://git-scm.com/docs/git-symbolic-ref)
  * [ update-index ](https://git-scm.com/docs/git-update-index)
  * [ update-ref ](https://git-scm.com/docs/git-update-ref)
  * [ verify-pack ](https://git-scm.com/docs/git-verify-pack)
  * [ write-tree ](https://git-scm.com/docs/git-write-tree)


[ Latest version ▾ ](https://git-scm.com/docs/githooks) githooks last updated in 2.53.0
Changes in the **githooks** manual
  1. [2.53.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2026-02-02_ ](https://git-scm.com/docs/githooks/2.53.0)
  2. 2.46.2 → 2.52.0 no changes
  3. [2.46.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-09-13_ ](https://git-scm.com/docs/githooks/2.46.1)
  4. [2.46.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-07-29_ ](https://git-scm.com/docs/githooks/2.46.0)
  5. 2.45.1 → 2.45.4 no changes
  6. [2.45.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-04-29_ ](https://git-scm.com/docs/githooks/2.45.0)
  7. 2.44.1 → 2.44.4 no changes
  8. [2.44.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2024-02-23_ ](https://git-scm.com/docs/githooks/2.44.0)
  9. 2.43.1 → 2.43.7 no changes
  10. [2.43.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-11-20_ ](https://git-scm.com/docs/githooks/2.43.0)
  11. 2.41.1 → 2.42.4 no changes
  12. [2.41.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-06-01_ ](https://git-scm.com/docs/githooks/2.41.0)
  13. 2.39.4 → 2.40.4 no changes
  14. [2.39.3 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-04-17_ ](https://git-scm.com/docs/githooks/2.39.3)
  15. 2.36.1 → 2.39.2 no changes
  16. [2.36.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-04-18_ ](https://git-scm.com/docs/githooks/2.36.0)
  17. 2.32.1 → 2.35.8 no changes
  18. [2.32.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-06-06_ ](https://git-scm.com/docs/githooks/2.32.0)
  19. 2.30.2 → 2.31.8 no changes
  20. [2.30.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-02-08_ ](https://git-scm.com/docs/githooks/2.30.1)
  21. [2.30.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-12-27_ ](https://git-scm.com/docs/githooks/2.30.0)
  22. 2.29.1 → 2.29.3 no changes
  23. [2.29.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-10-19_ ](https://git-scm.com/docs/githooks/2.29.0)
  24. 2.28.1 no changes
  25. [2.28.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-07-27_ ](https://git-scm.com/docs/githooks/2.28.0)
  26. 2.27.1 no changes
  27. [2.27.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-06-01_ ](https://git-scm.com/docs/githooks/2.27.0)
  28. 2.26.1 → 2.26.3 no changes
  29. [2.26.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2020-03-22_ ](https://git-scm.com/docs/githooks/2.26.0)
  30. 2.24.1 → 2.25.5 no changes
  31. [2.24.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-11-04_ ](https://git-scm.com/docs/githooks/2.24.0)
  32. 2.23.1 → 2.23.4 no changes
  33. [2.23.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-08-16_ ](https://git-scm.com/docs/githooks/2.23.0)
  34. 2.22.1 → 2.22.5 no changes
  35. [2.22.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-06-07_ ](https://git-scm.com/docs/githooks/2.22.0)
  36. 2.19.1 → 2.21.4 no changes
  37. [2.19.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-09-10_ ](https://git-scm.com/docs/githooks/2.19.0)
  38. 2.18.1 → 2.18.5 no changes
  39. [2.18.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-06-21_ ](https://git-scm.com/docs/githooks/2.18.0)
  40. 2.17.0 → 2.17.6 no changes
  41. [2.16.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/githooks/2.16.6)
  42. [2.15.4 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/githooks/2.15.4)
  43. [2.14.6 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-12-06_ ](https://git-scm.com/docs/githooks/2.14.6)
  44. [2.13.7 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-05-22_ ](https://git-scm.com/docs/githooks/2.13.7)
  45. 2.11.4 → 2.12.5 no changes
  46. [2.10.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-09-22_ ](https://git-scm.com/docs/githooks/2.10.5)
  47. [2.9.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-07-30_ ](https://git-scm.com/docs/githooks/2.9.5)
  48. 2.5.6 → 2.8.6 no changes
  49. [2.4.12 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2017-05-05_ ](https://git-scm.com/docs/githooks/2.4.12)
  50. 2.3.10 no changes
  51. [2.2.3 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2015-09-04_ ](https://git-scm.com/docs/githooks/2.2.3)
  52. 2.1.4 no changes
  53. [2.0.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/githooks/2.0.5)


Check your version of git by running
`git --version`
##  [](https://git-scm.com/docs/githooks#_name)NAME
githooks - Hooks used by Git
##  [](https://git-scm.com/docs/githooks#_synopsis)SYNOPSIS
$GIT_DIR/hooks/* (or `git config core.hooksPath`/*)
##  [](https://git-scm.com/docs/githooks#_description)DESCRIPTION
Hooks are programs you can place in a hooks directory to trigger actions at certain points in git's execution. Hooks that don't have the executable bit set are ignored.
By default the hooks directory is `$GIT_DIR/hooks`, but that can be changed via the `core.hooksPath` configuration variable (see [git-config[1]](https://git-scm.com/docs/git-config)).
Before Git invokes a hook, it changes its working directory to either $GIT_DIR in a bare repository or the root of the working tree in a non-bare repository. An exception are hooks triggered during a push (_pre-receive_ , _update_ , _post-receive_ , _post-update_ , _push-to-checkout_) which are always executed in $GIT_DIR.
Environment variables, such as `GIT_DIR`, `GIT_WORK_TREE`, etc., are exported so that Git commands run by the hook can correctly locate the repository. If your hook needs to invoke Git commands in a foreign repository or in a different working tree of the same repository, then it should clear these environment variables so they do not interfere with Git operations at the foreign location. For example:
```
local_desc=$(git describe)
foreign_desc=$(unset $(git rev-parse --local-env-vars); git -C ../foreign-repo describe)
```

Hooks can get their arguments via the environment, command-line arguments, and stdin. See the documentation for each hook below for details.
`git` `init` may copy hooks to the new repository, depending on its configuration. See the "TEMPLATE DIRECTORY" section in [git-init[1]](https://git-scm.com/docs/git-init) for details. When the rest of this document refers to "default hooks" it's talking about the default template shipped with Git.
The currently supported hooks are described below.
##  [](https://git-scm.com/docs/githooks#_hooks)HOOKS
###  [](https://git-scm.com/docs/githooks#_applypatch_msg)applypatch-msg
This hook is invoked by [git-am[1]](https://git-scm.com/docs/git-am). It takes a single parameter, the name of the file that holds the proposed commit log message. Exiting with a non-zero status causes `git` `am` to abort before applying the patch.
The hook is allowed to edit the message file in place, and can be used to normalize the message into some project standard format. It can also be used to refuse the commit after inspecting the message file.
The default _applypatch-msg_ hook, when enabled, runs the _commit-msg_ hook, if the latter is enabled.
###  [](https://git-scm.com/docs/githooks#_pre_applypatch)pre-applypatch
This hook is invoked by [git-am[1]](https://git-scm.com/docs/git-am). It takes no parameter, and is invoked after the patch is applied, but before a commit is made.
If it exits with non-zero status, then the working tree will not be committed after applying the patch.
It can be used to inspect the current working tree and refuse to make a commit if it does not pass certain tests.
The default _pre-applypatch_ hook, when enabled, runs the _pre-commit_ hook, if the latter is enabled.
###  [](https://git-scm.com/docs/githooks#_post_applypatch)post-applypatch
This hook is invoked by [git-am[1]](https://git-scm.com/docs/git-am). It takes no parameter, and is invoked after the patch is applied and a commit is made.
This hook is meant primarily for notification, and cannot affect the outcome of `git` `am`.
###  [](https://git-scm.com/docs/githooks#_pre_commit)pre-commit
This hook is invoked by [git-commit[1]](https://git-scm.com/docs/git-commit), and can be bypassed with the `--no-verify` option. It takes no parameters, and is invoked before obtaining the proposed commit log message and making a commit. Exiting with a non-zero status from this script causes the `git` `commit` command to abort before creating a commit.
All the `git` `commit` hooks are invoked with the environment variable `GIT_EDITOR=:` if the command will not bring up an editor to modify the commit message.
The default _pre-commit_ hook, when enabled, prevents the introduction of non-ASCII filenames and lines with trailing whitespace. The non-ASCII check can be turned off by setting the `hooks.allownonascii` config option to `true`.
###  [](https://git-scm.com/docs/githooks#_pre_merge_commit)pre-merge-commit
This hook is invoked by [git-merge[1]](https://git-scm.com/docs/git-merge), and can be bypassed with the `--no-verify` option. It takes no parameters, and is invoked after the merge has been carried out successfully and before obtaining the proposed commit log message to make a commit. Exiting with a non-zero status from this script causes the `git` `merge` command to abort before creating a commit.
The default _pre-merge-commit_ hook, when enabled, runs the _pre-commit_ hook, if the latter is enabled.
This hook is invoked with the environment variable `GIT_EDITOR=:` if the command will not bring up an editor to modify the commit message.
If the merge cannot be carried out automatically, the conflicts need to be resolved and the result committed separately (see [git-merge[1]](https://git-scm.com/docs/git-merge)). At that point, this hook will not be executed, but the _pre-commit_ hook will, if it is enabled.
###  [](https://git-scm.com/docs/githooks#_prepare_commit_msg)prepare-commit-msg
This hook is invoked by [git-commit[1]](https://git-scm.com/docs/git-commit) right after preparing the default log message, and before the editor is started.
It takes one to three parameters. The first is the name of the file that contains the commit log message. The second is the source of the commit message, and can be: `message` (if a `-m` or `-F` option was given); `template` (if a `-t` option was given or the configuration option `commit.template` is set); `merge` (if the commit is a merge or a `.git/MERGE_MSG` file exists); `squash` (if a `.git/SQUASH_MSG` file exists); or `commit`, followed by a commit object name (if a `-c`, `-C` or `--amend` option was given).
If the exit status is non-zero, `git` `commit` will abort.
The purpose of the hook is to edit the message file in place, and it is not suppressed by the `--no-verify` option. A non-zero exit means a failure of the hook and aborts the commit. It should not be used as a replacement for the pre-commit hook.
The sample `prepare-commit-msg` hook that comes with Git removes the help message found in the commented portion of the commit template.
###  [](https://git-scm.com/docs/githooks#_commit_msg)commit-msg
This hook is invoked by [git-commit[1]](https://git-scm.com/docs/git-commit) and [git-merge[1]](https://git-scm.com/docs/git-merge), and can be bypassed with the `--no-verify` option. It takes a single parameter, the name of the file that holds the proposed commit log message. Exiting with a non-zero status causes the command to abort.
The hook is allowed to edit the message file in place, and can be used to normalize the message into some project standard format. It can also be used to refuse the commit after inspecting the message file.
The default _commit-msg_ hook, when enabled, detects duplicate `Signed-off-by` trailers, and aborts the commit if one is found.
###  [](https://git-scm.com/docs/githooks#_post_commit)post-commit
This hook is invoked by [git-commit[1]](https://git-scm.com/docs/git-commit). It takes no parameters, and is invoked after a commit is made.
This hook is meant primarily for notification, and cannot affect the outcome of `git` `commit`.
###  [](https://git-scm.com/docs/githooks#_pre_rebase)pre-rebase
This hook is called by [git-rebase[1]](https://git-scm.com/docs/git-rebase) and can be used to prevent a branch from getting rebased. The hook may be called with one or two parameters. The first parameter is the upstream from which the series was forked. The second parameter is the branch being rebased, and is not set when rebasing the current branch.
###  [](https://git-scm.com/docs/githooks#_post_checkout)post-checkout
This hook is invoked when a [git-checkout[1]](https://git-scm.com/docs/git-checkout) or [git-switch[1]](https://git-scm.com/docs/git-switch) is run after having updated the worktree. The hook is given three parameters: the ref of the previous HEAD, the ref of the new HEAD (which may or may not have changed), and a flag indicating whether the checkout was a branch checkout (changing branches, flag=1) or a file checkout (retrieving a file from the index, flag=0). This hook cannot affect the outcome of `git` `switch` or `git` `checkout`, other than that the hook's exit status becomes the exit status of these two commands.
It is also run after [git-clone[1]](https://git-scm.com/docs/git-clone), unless the `--no-checkout` (`-n`) option is used. The first parameter given to the hook is the null-ref, the second the ref of the new HEAD and the flag is always 1. Likewise for `git` `worktree` `add` unless `--no-checkout` is used.
This hook can be used to perform repository validity checks, auto-display differences from the previous HEAD if different, or set working dir metadata properties.
###  [](https://git-scm.com/docs/githooks#_post_merge)post-merge
This hook is invoked by [git-merge[1]](https://git-scm.com/docs/git-merge), which happens when a `git` `pull` is done on a local repository. The hook takes a single parameter, a status flag specifying whether or not the merge being done was a squash merge. This hook cannot affect the outcome of `git` `merge` and is not executed, if the merge failed due to conflicts.
This hook can be used in conjunction with a corresponding pre-commit hook to save and restore any form of metadata associated with the working tree (e.g.: permissions/ownership, ACLS, etc). See contrib/hooks/setgitperms.perl for an example of how to do this.
###  [](https://git-scm.com/docs/githooks#_pre_push)pre-push
This hook is called by [git-push[1]](https://git-scm.com/docs/git-push) and can be used to prevent a push from taking place. The hook is called with two parameters which provide the name and location of the destination remote, if a named remote is not being used both values will be the same.
Information about what is to be pushed is provided on the hook's standard input with lines of the form:
```
<local-ref> SP <local-object-name> SP <remote-ref> SP <remote-object-name> LF
```

For instance, if the command `git` `push` `origin` `master:foreign` were run the hook would receive a line like the following:
```
refs/heads/master 67890 refs/heads/foreign 12345
```

although the full object name would be supplied. If the foreign ref does not yet exist the _< remote-object-name>_ will be the all-zeroes object name. If a ref is to be deleted, the _< local-ref>_ will be supplied as (`delete`) and the _< local-object-name>_ will be the all-zeroes object name. If the local commit was specified by something other than a name which could be expanded (such as `HEAD~`, or an object name) it will be supplied as it was originally given.
If this hook exits with a non-zero status, `git` `push` will abort without pushing anything. Information about why the push is rejected may be sent to the user by writing to standard error.
###  [](https://git-scm.com/docs/githooks#pre-receive)pre-receive
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) when it reacts to `git` `push` and updates reference(s) in its repository. Just before starting to update refs on the remote repository, the pre-receive hook is invoked. Its exit status determines the success or failure of the update.
This hook executes once for the receive operation. It takes no arguments, but for each ref to be updated it receives on standard input a line of the format:
```
<old-oid> SP <new-oid> SP <ref-name> LF
```

where _< old-oid>_ is the old object name stored in the ref, _< new-oid>_ is the new object name to be stored in the ref and _< ref-name>_ is the full name of the ref. When creating a new ref, _< old-oid>_ is the all-zeroes object name.
If the hook exits with non-zero status, none of the refs will be updated. If the hook exits with zero, updating of individual refs can still be prevented by the [_update_](https://git-scm.com/docs/githooks#update) hook.
Both standard output and standard error output are forwarded to `git` `send-pack` on the other end, so you can simply `echo` messages for the user.
The number of push options given on the command line of `git` `push` `--push-option=...` can be read from the environment variable `GIT_PUSH_OPTION_COUNT`, and the options themselves are found in `GIT_PUSH_OPTION_0`, `GIT_PUSH_OPTION_1`,…​ If it is negotiated to not use the push options phase, the environment variables will not be set. If the client selects to use push options, but doesn't transmit any, the count variable will be set to zero, `GIT_PUSH_OPTION_COUNT=0`.
See the section on "Quarantine Environment" in [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) for some caveats.
###  [](https://git-scm.com/docs/githooks#update)update
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) when it reacts to `git` `push` and updates reference(s) in its repository. Just before updating the ref on the remote repository, the update hook is invoked. Its exit status determines the success or failure of the ref update.
The hook executes once for each ref to be updated, and takes three parameters:
  * the name of the ref being updated,
  * the old object name stored in the ref,
  * and the new object name to be stored in the ref.


A zero exit from the update hook allows the ref to be updated. Exiting with a non-zero status prevents `git` `receive-pack` from updating that ref.
This hook can be used to prevent _forced_ update on certain refs by making sure that the object name is a commit object that is a descendant of the commit object named by the old object name. That is, to enforce a "fast-forward only" policy.
It could also be used to log the old..new status. However, it does not know the entire set of branches, so it would end up firing one e-mail per ref when used naively, though. The [_post-receive_](https://git-scm.com/docs/githooks#post-receive) hook is more suited to that.
In an environment that restricts the users' access only to git commands over the wire, this hook can be used to implement access control without relying on filesystem ownership and group membership. See [git-shell[1]](https://git-scm.com/docs/git-shell) for how you might use the login shell to restrict the user's access to only git commands.
Both standard output and standard error output are forwarded to `git` `send-pack` on the other end, so you can simply `echo` messages for the user.
The default _update_ hook, when enabled—​and with `hooks.allowunannotated` config option unset or set to false—​prevents unannotated tags from being pushed.
###  [](https://git-scm.com/docs/githooks#proc-receive)proc-receive
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack). If the server has set the multi-valued config variable `receive.procReceiveRefs`, and the commands sent to _receive-pack_ have matching reference names, these commands will be executed by this hook, instead of by the internal `execute_commands`() function. This hook is responsible for updating the relevant references and reporting the results back to _receive-pack_.
This hook executes once for the receive operation. It takes no arguments, but uses a pkt-line format protocol to communicate with _receive-pack_ to read commands, push-options and send results. In the following example for the protocol, the letter _S_ stands for _receive-pack_ and the letter _H_ stands for this hook.
```
# Version and features negotiation.
S: PKT-LINE(version=1\0push-options atomic...)
S: flush-pkt
H: PKT-LINE(version=1\0push-options...)
H: flush-pkt
```

```
# Send commands from server to the hook.
S: PKT-LINE(<old-oid> <new-oid> <ref>)
S: ... ...
S: flush-pkt
# Send push-options only if the 'push-options' feature is enabled.
S: PKT-LINE(push-option)
S: ... ...
S: flush-pkt
```

```
# Receive results from the hook.
# OK, run this command successfully.
H: PKT-LINE(ok <ref>)
# NO, I reject it.
H: PKT-LINE(ng <ref> <reason>)
# Fall through, let 'receive-pack' execute it.
H: PKT-LINE(ok <ref>)
H: PKT-LINE(option fall-through)
# OK, but has an alternate reference.  The alternate reference name
# and other status can be given in option directives.
H: PKT-LINE(ok <ref>)
H: PKT-LINE(option refname <refname>)
H: PKT-LINE(option old-oid <old-oid>)
H: PKT-LINE(option new-oid <new-oid>)
H: PKT-LINE(option forced-update)
H: ... ...
H: flush-pkt
```

Each command for the _proc-receive_ hook may point to a pseudo-reference and always has a zero-old as its old-oid, while the _proc-receive_ hook may update an alternate reference and the alternate reference may exist already with a non-zero old-oid. For this case, this hook will use "option" directives to report extended attributes for the reference given by the leading "ok" directive.
The report of the commands of this hook should have the same order as the input. The exit status of the _proc-receive_ hook only determines the success or failure of the group of commands sent to it, unless atomic push is in use.
###  [](https://git-scm.com/docs/githooks#post-receive)post-receive
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) when it reacts to `git` `push` and updates reference(s) in its repository. The hook executes on the remote repository once after all the proposed ref updates are processed and if at least one ref is updated as the result.
The hook takes no arguments. It receives one line on standard input for each ref that is successfully updated following the same format as the [_pre-receive_](https://git-scm.com/docs/githooks#pre-receive) hook.
This hook does not affect the outcome of `git` `receive-pack`, as it is called after the real work is done.
This supersedes the [_post-update_](https://git-scm.com/docs/githooks#post-update) hook in that it gets both old and new values of all the refs in addition to their names.
Both standard output and standard error output are forwarded to `git` `send-pack` on the other end, so you can simply `echo` messages for the user.
The default _post-receive_ hook is empty, but there is a sample script `post-receive-email` provided in the `contrib/hooks` directory in Git distribution, which implements sending commit emails.
The number of push options given on the command line of `git` `push` `--push-option=...` can be read from the environment variable `GIT_PUSH_OPTION_COUNT`, and the options themselves are found in `GIT_PUSH_OPTION_0`, `GIT_PUSH_OPTION_1`,…​ If it is negotiated to not use the push options phase, the environment variables will not be set. If the client selects to use push options, but doesn't transmit any, the count variable will be set to zero, `GIT_PUSH_OPTION_COUNT=0`.
See the "post-receive" section in [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) for additional details.
###  [](https://git-scm.com/docs/githooks#post-update)post-update
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) when it reacts to `git` `push` and updates reference(s) in its repository. It executes on the remote repository once after all the refs have been updated.
It takes a variable number of parameters, each of which is the name of ref that was actually updated.
This hook is meant primarily for notification, and cannot affect the outcome of `git` `receive-pack`.
The _post-update_ hook can tell what are the heads that were pushed, but it does not know what their original and updated values are, so it is a poor place to do log old..new. The [_post-receive_](https://git-scm.com/docs/githooks#post-receive) hook does get both original and updated values of the refs. You might consider it instead if you need them.
When enabled, the default _post-update_ hook runs `git` `update-server-info` to keep the information used by dumb transports (e.g., HTTP) up to date. If you are publishing a Git repository that is accessible via HTTP, you should probably enable this hook.
Both standard output and standard error output are forwarded to `git` `send-pack` on the other end, so you can simply `echo` messages for the user.
###  [](https://git-scm.com/docs/githooks#_reference_transaction)reference-transaction
This hook is invoked by any Git command that performs reference updates. It executes whenever a reference transaction is prepared, committed or aborted and may thus get called multiple times. The hook also supports symbolic reference updates.
The hook takes exactly one argument, which is the current state the given reference transaction is in:
  * "prepared": All reference updates have been queued to the transaction and references were locked on disk.
  * "committed": The reference transaction was committed and all references now have their respective new value.
  * "aborted": The reference transaction was aborted, no changes were performed and the locks have been released.


For each reference update that was added to the transaction, the hook receives on standard input a line of the format:
```
<old-value> SP <new-value> SP <ref-name> LF
```

where _< old-value>_ is the old object name passed into the reference transaction, _< new-value>_ is the new object name to be stored in the ref and _< ref-name>_ is the full name of the ref. When force updating the reference regardless of its current value or when the reference is to be created anew, _< old-value>_ is the all-zeroes object name. To distinguish these cases, you can inspect the current value of _< ref-name>_ via `git` `rev-parse`.
For symbolic reference updates the _< old_value>_ and _< new-value>_ fields could denote references instead of objects. A reference will be denoted with a _ref:_ prefix, like `ref:`_< ref-target>_.
The exit status of the hook is ignored for any state except for the "prepared" state. In the "prepared" state, a non-zero exit status will cause the transaction to be aborted. The hook will not be called with "aborted" state in that case.
###  [](https://git-scm.com/docs/githooks#_push_to_checkout)push-to-checkout
This hook is invoked by [git-receive-pack[1]](https://git-scm.com/docs/git-receive-pack) when it reacts to `git` `push` and updates reference(s) in its repository, and when the push tries to update the branch that is currently checked out and the `receive.denyCurrentBranch` configuration variable is set to `updateInstead`. Such a push by default is refused if the working tree and the index of the remote repository has any difference from the currently checked out commit; when both the working tree and the index match the current commit, they are updated to match the newly pushed tip of the branch. This hook is to be used to override the default behaviour.
The hook receives the commit with which the tip of the current branch is going to be updated. It can exit with a non-zero status to refuse the push (when it does so, it must not modify the index or the working tree). Or it can make any necessary changes to the working tree and to the index to bring them to the desired state when the tip of the current branch is updated to the new commit, and exit with a zero status.
For example, the hook can simply run `git` `read-tree` `-u` `-m` `HEAD` `"$1"` in order to emulate `git` `fetch` that is run in the reverse direction with `git` `push`, as the two-tree form of `git` `read-tree` `-u` `-m` is essentially the same as `git` `switch` or `git` `checkout` that switches branches while keeping the local changes in the working tree that do not interfere with the difference between the branches.
###  [](https://git-scm.com/docs/githooks#_pre_auto_gc)pre-auto-gc
This hook is invoked by `git` `gc` `--auto` (see [git-gc[1]](https://git-scm.com/docs/git-gc)). It takes no parameter, and exiting with non-zero status from this script causes the `git` `gc` `--auto` to abort.
###  [](https://git-scm.com/docs/githooks#_post_rewrite)post-rewrite
This hook is invoked by commands that rewrite commits ([git-commit[1]](https://git-scm.com/docs/git-commit) when called with `--amend` and [git-rebase[1]](https://git-scm.com/docs/git-rebase); however, full-history (re)writing tools like [git-fast-import[1]](https://git-scm.com/docs/git-fast-import) or [git-filter-repo](https://github.com/newren/git-filter-repo) typically do not call it!). Its first argument denotes the command it was invoked by: currently one of `amend` or `rebase`. Further command-dependent arguments may be passed in the future.
The hook receives a list of the rewritten commits on stdin, in the format
```
<old-object-name> SP <new-object-name> [ SP <extra-info> ] LF
```

The _extra-info_ is again command-dependent. If it is empty, the preceding SP is also omitted. Currently, no commands pass any _extra-info_.
The hook always runs after the automatic note copying (see "notes.rewrite.<command>" in [git-config[1]](https://git-scm.com/docs/git-config)) has happened, and thus has access to these notes.
The following command-specific comments apply:

[](https://git-scm.com/docs/githooks#Documentation/githooks.txt-rebase)rebase

For the _squash_ and _fixup_ operation, all commits that were squashed are listed as being rewritten to the squashed commit. This means that there will be several lines sharing the same _new-object-name_.
The commits are guaranteed to be listed in the order that they were processed by rebase.
###  [](https://git-scm.com/docs/githooks#_sendemail_validate)sendemail-validate
This hook is invoked by [git-send-email[1]](https://git-scm.com/docs/git-send-email).
It takes these command line arguments. They are, 1. the name of the file which holds the contents of the email to be sent. 2. The name of the file which holds the SMTP headers of the email.
The SMTP headers are passed in the exact same way as they are passed to the user's Mail Transport Agent (MTA). In effect, the email given to the user's MTA, is the contents of $2 followed by the contents of $1.
An example of a few common headers is shown below. Take notice of the capitalization and multi-line tab structure.
```
From: Example <from@example.com>
To: to@example.com
Cc: cc@example.com,
 A <author@example.com>,
 One <one@example.com>,
 two@example.com
Subject: PATCH-STRING
```

Exiting with a non-zero status causes `git` `send-email` to abort before sending any e-mails.
The following environment variables are set when executing the hook.

[](https://git-scm.com/docs/githooks#Documentation/githooks.txt-GITSENDEMAILFILECOUNTER)`GIT_SENDEMAIL_FILE_COUNTER`

A 1-based counter incremented by one for every file holding an e-mail to be sent (excluding any FIFOs). This counter does not follow the patch series counter scheme. It will always start at 1 and will end at GIT_SENDEMAIL_FILE_TOTAL.

[](https://git-scm.com/docs/githooks#Documentation/githooks.txt-GITSENDEMAILFILETOTAL)`GIT_SENDEMAIL_FILE_TOTAL`

The total number of files that will be sent (excluding any FIFOs). This counter does not follow the patch series counter scheme. It will always be equal to the number of files being sent, whether there is a cover letter or not.
These variables may for instance be used to validate patch series.
The sample `sendemail-validate` hook that comes with Git checks that all sent patches (excluding the cover letter) can be applied on top of the upstream repository default branch without conflicts. Some placeholders are left for additional validation steps to be performed after all patches of a given series have been applied.
###  [](https://git-scm.com/docs/githooks#_fsmonitor_watchman)fsmonitor-watchman
This hook is invoked when the configuration option `core.fsmonitor` is set to `.git/hooks/fsmonitor-watchman` or `.git/hooks/fsmonitor-watchmanv2` depending on the version of the hook to use.
Version 1 takes two arguments, a version (1) and the time in elapsed nanoseconds since midnight, January 1, 1970.
Version 2 takes two arguments, a version (2) and a token that is used for identifying changes since the token. For watchman this would be a clock id. This version must output to stdout the new token followed by a NUL before the list of files.
The hook should output to stdout the list of all files in the working directory that may have changed since the requested time. The logic should be inclusive so that it does not miss any potential changes. The paths should be relative to the root of the working directory and be separated by a single NUL.
It is OK to include files which have not actually changed. All changes including newly-created and deleted files should be included. When files are renamed, both the old and the new name should be included.
Git will limit what files it checks for changes as well as which directories are checked for untracked files based on the path names given.
An optimized way to tell git "all files have changed" is to return the filename `/`.
The exit status determines whether git will use the data from the hook to limit its search. On error, it will fall back to verifying all files and folders.
###  [](https://git-scm.com/docs/githooks#_p4_changelist)p4-changelist
This hook is invoked by `git-p4` `submit`.
The `p4-changelist` hook is executed after the changelist message has been edited by the user. It can be bypassed with the `--no-verify` option. It takes a single parameter, the name of the file that holds the proposed changelist text. Exiting with a non-zero status causes the command to abort.
The hook is allowed to edit the changelist file and can be used to normalize the text into some project standard format. It can also be used to refuse the Submit after inspect the message file.
Run `git-p4` `submit` `--help` for details.
###  [](https://git-scm.com/docs/githooks#_p4_prepare_changelist)p4-prepare-changelist
This hook is invoked by `git-p4` `submit`.
The `p4-prepare-changelist` hook is executed right after preparing the default changelist message and before the editor is started. It takes one parameter, the name of the file that contains the changelist text. Exiting with a non-zero status from the script will abort the process.
The purpose of the hook is to edit the message file in place, and it is not suppressed by the `--no-verify` option. This hook is called even if `--prepare-p4-only` is set.
Run `git-p4` `submit` `--help` for details.
###  [](https://git-scm.com/docs/githooks#_p4_post_changelist)p4-post-changelist
This hook is invoked by `git-p4` `submit`.
The `p4-post-changelist` hook is invoked after the submit has successfully occurred in P4. It takes no parameters and is meant primarily for notification and cannot affect the outcome of the git p4 submit action.
Run `git-p4` `submit` `--help` for details.
###  [](https://git-scm.com/docs/githooks#_p4_pre_submit)p4-pre-submit
This hook is invoked by `git-p4` `submit`. It takes no parameters and nothing from standard input. Exiting with non-zero status from this script prevent `git-p4` `submit` from launching. It can be bypassed with the `--no-verify` command line option. Run `git-p4` `submit` `--help` for details.
###  [](https://git-scm.com/docs/githooks#_post_index_change)post-index-change
This hook is invoked when the index is written in read-cache.c do_write_locked_index.
The first parameter passed to the hook is the indicator for the working directory being updated. "1" meaning working directory was updated or "0" when the working directory was not updated.
The second parameter passed to the hook is the indicator for whether or not the index was updated and the skip-worktree bit could have changed. "1" meaning skip-worktree bits could have been updated and "0" meaning they were not.
Only one parameter should be set to "1" when the hook runs. The hook running passing "1", "1" should not be possible.
##  [](https://git-scm.com/docs/githooks#_see_also)SEE ALSO
[git-hook[1]](https://git-scm.com/docs/git-hook)
##  [](https://git-scm.com/docs/githooks#_git)GIT
Part of the [git[1]](https://git-scm.com/docs/git) suite
### githooks
[About this site](https://git-scm.com/site)
Patches, suggestions, and comments are welcome.
Git is a member of [Software Freedom Conservancy](https://git-scm.com/sfc)
