# carrier - parse_log_file

**Toolkit**: `carrier`
**Method**: `parse_log_file`
**Source File**: `excel_reporter.py`
**Class**: `GatlingReportParser`

---

## Method Implementation

```python
    def parse_log_file(self, file_path: str):
        groups = defaultdict(list)
        requests = defaultdict(list)
        users = 0
        date_start = None
        date_end = None
        ramp_start = None
        ramp_end = None
        try:
            with open(file_path, 'r', encoding="utf8") as file:
                for line_number, line in enumerate(file):
                    if not date_start:
                        if 'ASSERTION' in line:
                            continue
                        date_start = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                    try:
                        date_end = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                    except:
                        # TODO: Fix logic
                        pass
                    if line.startswith('REQUEST'):
                        self.parse_request_line(requests, line)
                    elif line.startswith('USER') and 'START' in line:
                        users += 1
                        if "START" in line:
                            if not ramp_start:
                                ramp_start = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))
                            else:
                                ramp_end = self.convert_timestamp_to_datetime(int(line.split('\t')[3]))

                    elif line.startswith('GROUP'):
                        self.parse_group_line(groups, line, self.include_group_pauses)
        except FileNotFoundError as e:
            print(f"File not found: {e}")
            raise
        except Exception as e:
            print(f"Error reading file {file_path}: {e}")
            raise
        return groups, requests, users, date_start, date_end, self.calculate_duration(ramp_start, ramp_end)
```

## Helper Methods

```python
Helper: parse_group_line
    def parse_group_line(groups, line, include_group_pauses):
        parts = line.split('\t')
        if len(parts) >= 6:
            group_name = parts[1]
            if include_group_pauses:
                response_time = int(parts[3]) - int(parts[2])
            else:
                response_time = int(parts[4])
            status = parts[5].strip()
            groups[group_name].append((response_time, status))
```
