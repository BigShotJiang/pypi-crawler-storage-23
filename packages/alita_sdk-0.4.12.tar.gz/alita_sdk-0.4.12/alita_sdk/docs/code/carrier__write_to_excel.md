# carrier - write_to_excel

**Toolkit**: `carrier`
**Method**: `write_to_excel`
**Source File**: `excel_reporter.py`
**Class**: `ExcelReporter`

---

## Method Implementation

```python
    def write_to_excel(self, results, carrier_report, thresholds, report_percentile):
        results["carrier_report"] = carrier_report
        try:
            results["build_status"], results["justification"] = self.get_build_status_and_justification(thresholds,
                                                                                                    report_percentile)
        except Exception as e:
            print(e)
            results["build_status"], results["justification"] = "SUCCESS", ""
        wb = Workbook()
        ws = wb.active
        ws.title = "Test results"

        requests_filtered = results["requests"]

        self.write_title_above_headers(self.title, results, self.header, ws)

        content_start, content_end = None, None
        for i, (header_field_name, header_key) in enumerate(self.header.items()):
            header_cell = ws.cell(row=len(self.title) + 1, column=i + 1,
                                  value=header_field_name)  # i + 1 because excel index starts from 1
            header_cell.alignment = Alignment(horizontal="center")
            border_style = Side(border_style="thin", color="040404")
            header_cell.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
            header_cell.fill = PatternFill("solid", fgColor='007FD5D8')

            if not content_start:
                content_start = get_column_letter(header_cell.column) + str(header_cell.row)

            need_cond_format = header_key in ['min', 'average', '95Pct', 'max', '90Pct']
            start_cell_for_formatting, end_cell_for_formatting = None, None
            for j, req_info in enumerate(requests_filtered.values()):
                if need_cond_format:
                    cur_cell = ws.cell(row=j + len(self.title) + 2, column=i + 1,
                                       value=round(req_info[header_key] / 1000, 3))
                    if start_cell_for_formatting is None:
                        start_cell_for_formatting = cur_cell
                    end_cell_for_formatting = cur_cell
                else:
                    cur_cell = ws.cell(row=j + len(self.title) + 2, column=i + 1, value=req_info[header_key])
                border_style = Side(border_style="thin", color="040404")
                cur_cell.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
                if header_key == 'Error%':
                    cur_cell.number_format = '0.00%'
                content_end = get_column_letter(cur_cell.column) + str(cur_cell.row)

            if need_cond_format:
                start_col = get_column_letter(start_cell_for_formatting.column)
                start_row = start_cell_for_formatting.row
                end_col = get_column_letter(end_cell_for_formatting.column)
                end_row = end_cell_for_formatting.row
                coords = start_col + str(start_row) + ':' + end_col + str(end_row)
                try:
                    rt_threshold = float(self.get_response_threshold(thresholds))
                except Exception as e:
                    print(e)
                    rt_threshold = 0
                if rt_threshold > 1:
                    threshold = rt_threshold/1000
                else:
                    threshold = rt_threshold

                ws.conditional_formatting.add(coords,
                                              CellIsRule(operator='lessThan', formula=[threshold], fill=GREEN_FILL))
                ws.conditional_formatting.add(coords, CellIsRule(operator='greaterThan', formula=[threshold * 1.5],
                                                                 fill=RED_FILL))
                ws.conditional_formatting.add(coords,
                                              CellIsRule(operator='between', formula=[threshold, threshold * 1.5],
                                                         fill=YELLOW_FILL))

                # column width adjusted
        for i, key in enumerate(self.header):
            length = len(str(key))
            ws.column_dimensions[get_column_letter(i + 1)].width = length + 5

        first_column_length = max(len(str(cell.value)) for cell in ws["A"])
        ws.column_dimensions[get_column_letter(1)].width = first_column_length + 5

        ws.auto_filter.ref = content_start + ":" + content_end

        # horizontal and vertical freeze
        freezen_area = ws['B' + str(len(self.title) + 2)]
        ws.freeze_panes = freezen_area
        print(f"Excel path: {self.report_path}")
        wb.save(self.report_path)
```

## Helper Methods

```python
Helper: get_response_threshold
    def get_response_threshold(thresholds):
        for th in thresholds:
            if th["target"] == "response_time":
                return th["threshold"]
```

```python
Helper: write_title_above_headers
    def write_title_above_headers(title, results, header, ws):

        for i, (header_field_name, header_key) in enumerate(title.items()):
            title_name = ws.cell(row=i + 1, column=1, value=header_field_name)
            title_value = ws.cell(row=i + 1, column=2, value=results[header_key])
            title_name.font = Font(b=True, color='00291A75')
            title_name.fill = PatternFill("solid", fgColor='00CDEBEA')
            title_name.alignment = Alignment(horizontal="left", vertical="center")
            title_value.alignment = Alignment(horizontal="center", vertical="center")
            title_value.fill = PatternFill("solid", fgColor='00CDEBEA')
            border_style = Side(border_style="thin", color="040404")
            title_value.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)
            title_name.border = Border(top=border_style, left=border_style, right=border_style, bottom=border_style)

            if header_key == 'error_rate':
                title_value.number_format = '0.00%'
            if header_key == 'carrier_report':
                title_value.hyperlink, title_value.value = title_value.value, "Carrier report"
                title_value.font = Font(b=True, underline="single", color='00291A75')
            if header_key == 'build_status':
                title_value.font = Font(b=True,
                                        color=GREEN_COLOR_FONT if title_value.value == 'SUCCESS'
                                        else RED_COLOR_FONT)
            if header_key == 'justification' and len(title_value.value) > 125:
                title_value.alignment = Alignment(horizontal="center", vertical="justify")
                ws.row_dimensions[i + 1].height = 30

            ws.merge_cells(start_row=i + 1, start_column=2, end_row=i + 1, end_column=len(header.items()))
```
