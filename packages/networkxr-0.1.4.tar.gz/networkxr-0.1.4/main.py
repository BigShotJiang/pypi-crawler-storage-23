def main():
    print("Hello from networkxr!")


if __name__ == "__main__":
    main()
