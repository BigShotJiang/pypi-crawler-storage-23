import hashlib
import struct

import pytest
from pydstl.store import EMBEDDING_DIM
from pydstl.types import SkillDocument


def _deterministic_embed(text: str) -> list[float]:
    h = hashlib.sha256(text.encode()).digest()
    raw = (h * ((EMBEDDING_DIM * 4 // len(h)) + 1))[: EMBEDDING_DIM * 4]
    vec = list(struct.unpack(f"{EMBEDDING_DIM}f", raw))
    mag = sum(v * v for v in vec) ** 0.5
    if mag > 0:
        vec = [v / mag for v in vec]
    return vec


def _mock_distill(evidence_list, topic=None):
    title = topic or "Code Review Patterns"
    body = "\n\n".join(f"- {e.content[:80]}" for e in evidence_list)
    return SkillDocument(title=title, content=body)


def _mock_edit(current_content, instruction):
    return f"{current_content}\n\n## Edit: {instruction}"


def _mock_consolidate(documents, topic=None):
    title = topic or "Consolidated Patterns"
    body = "\n\n".join(f"## {label}\n\n{content[:200]}" for label, content in documents)
    return SkillDocument(title=title, content=body)


@pytest.fixture
def mock_embed():
    return _deterministic_embed


@pytest.fixture
def mock_distill():
    return _mock_distill


@pytest.fixture
def mock_edit():
    return _mock_edit


@pytest.fixture
def mock_consolidate():
    return _mock_consolidate
