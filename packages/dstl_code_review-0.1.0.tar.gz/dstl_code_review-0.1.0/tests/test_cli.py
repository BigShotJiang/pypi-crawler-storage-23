import os

import httpx
import pytest
import respx
from pydstl import Dstl

from dstl_code_review.cli import (
    ReviewComment,
    _fetch_comments,
    _format_evidence,
    _parse_next_url,
    _resolve_token,
    _run,
    is_meaningful_comment,
)

# --- Token resolution ---


class TestResolveToken:
    def test_explicit_token(self):
        assert _resolve_token("my-token") == "my-token"

    def test_env_token(self, monkeypatch):
        monkeypatch.setenv("GITHUB_TOKEN", "env-token")
        assert _resolve_token() == "env-token"

    def test_no_token_raises(self, monkeypatch):
        monkeypatch.delenv("GITHUB_TOKEN", raising=False)
        with pytest.raises(RuntimeError, match="No GitHub token"):
            _resolve_token()


# --- Pagination parsing ---


class TestParseNextUrl:
    def test_with_next(self):
        header = (
            '<https://api.github.com/repos/a/b/pulls/comments?page=2>; rel="next",'
            ' <https://api.github.com/repos/a/b/pulls/comments?page=5>; rel="last"'
        )
        assert _parse_next_url(header) == "https://api.github.com/repos/a/b/pulls/comments?page=2"

    def test_no_next(self):
        assert _parse_next_url('<https://x.com>; rel="last"') is None

    def test_none(self):
        assert _parse_next_url(None) is None


# --- GitHub fetch ---


def _gh_comment(
    id=1,
    body="This is a meaningful code review comment that exceeds min length",
    login="reviewer",
    pr_number=42,
    created_at="2024-06-01T10:00:00Z",
    path="src/main.py",
):
    return {
        "id": id,
        "body": body,
        "user": {"login": login},
        "pull_request_url": f"https://api.github.com/repos/o/r/pulls/{pr_number}",
        "html_url": f"https://github.com/o/r/pull/{pr_number}#discussion_r{id}",
        "created_at": created_at,
        "path": path,
        "diff_hunk": "@@ -10,3 +10,5 @@ def foo():",
    }


class TestFetchComments:
    @respx.mock
    def test_basic(self):
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(200, json=[_gh_comment(id=i) for i in range(3)])
        )
        assert len(_fetch_comments("tok", "o/r", limit=10)) == 3

    @respx.mock
    def test_respects_limit(self):
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(200, json=[_gh_comment(id=i) for i in range(5)])
        )
        assert len(_fetch_comments("tok", "o/r", limit=2)) == 2

    @respx.mock
    def test_pagination(self):
        call_count = 0

        def handler(request):
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return httpx.Response(
                    200,
                    json=[_gh_comment(id=1)],
                    headers={
                        "Link": '<https://api.github.com/repos/o/r/pulls/comments?page=2>; rel="next"'  # noqa: E501
                    },
                )
            return httpx.Response(200, json=[_gh_comment(id=2)])

        respx.get(url__startswith="https://api.github.com/repos/o/r/pulls/comments").mock(
            side_effect=handler
        )
        comments = _fetch_comments("tok", "o/r", limit=10)
        assert len(comments) == 2
        assert call_count == 2

    @respx.mock
    def test_since(self):
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(200, json=[_gh_comment()])
        )
        _fetch_comments("tok", "o/r", limit=10, since="2024-06-01T00:00:00Z")
        assert "since=2024-06-01" in str(respx.calls[0].request.url)

    @respx.mock
    def test_bad_rate_limit_headers_dont_crash(self):
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[_gh_comment()],
                headers={"X-RateLimit-Remaining": "not-a-number", "X-RateLimit-Reset": "garbage"},
            )
        )
        comments = _fetch_comments("tok", "o/r", limit=10)
        assert len(comments) == 1


# --- Filtering ---


class TestFilters:
    def _c(self, **kw):
        defaults = {
            "id": 1,
            "body": "This is a sufficiently long and meaningful review comment",
            "user_login": "reviewer",
            "pr_number": 1,
            "html_url": "https://github.com/a/b/pull/1#r1",
            "created_at": "2024-01-01T00:00:00Z",
        }
        defaults.update(kw)
        return ReviewComment(**defaults)

    def test_meaningful(self):
        assert is_meaningful_comment(self._c()) is True

    def test_bot(self):
        assert is_meaningful_comment(self._c(user_login="dependabot[bot]")) is False

    def test_short(self):
        assert is_meaningful_comment(self._c(body="fix this")) is False

    def test_lgtm(self):
        assert is_meaningful_comment(self._c(body="LGTM!" + " " * 30)) is False

    def test_looks_good(self):
        assert is_meaningful_comment(self._c(body="Looks good to me." + " " * 30)) is False

    def test_custom_min_length(self):
        assert is_meaningful_comment(self._c(body="short"), min_length=3) is True
        assert is_meaningful_comment(self._c(body="sh"), min_length=3) is False


# --- Evidence formatting ---


class TestFormatEvidence:
    def test_with_path(self):
        c = ReviewComment(
            id=1,
            body="Use context manager",
            user_login="alice",
            pr_number=42,
            html_url="x",
            created_at="x",
            path="src/main.py",
            diff_hunk="@@ -10,3 +10,5 @@",
        )
        r = _format_evidence(c)
        assert "[PR #42]" in r and "alice" in r and "`src/main.py`" in r

    def test_no_path(self):
        c = ReviewComment(
            id=1, body="General", user_login="bob", pr_number=10, html_url="x", created_at="x"
        )
        assert "src/" not in _format_evidence(c)


# --- Engine helper ---


def _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate):
    return Dstl(
        db_path=str(tmp_path / "test.db"),
        model="test",
        embed_fn=mock_embed,
        distill_fn=mock_distill,
        edit_fn=mock_edit,
        consolidate_fn=mock_consolidate,
    )


# --- End-to-end ---


class TestSingleRepo:
    @respx.mock
    def test_full_run(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1,
                        body="Consider using a context manager for file handling to ensure cleanup",
                    ),
                    _gh_comment(id=2, body="LGTM", login="reviewer2"),
                    _gh_comment(
                        id=3,
                        body="This function is too long, break it into smaller helpers",
                        login="senior",
                    ),
                    _gh_comment(id=4, body="nit", login="dependabot[bot]"),
                ],
            )
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["o/r"], limit=100, min_length=30, output=output, token="test-token")

        skill_file = os.path.join(output, "SKILL.md")
        assert os.path.exists(skill_file)
        content = open(skill_file).read()
        assert content.startswith("# ")
        assert len(e.list_evidence(source_filter={"repo": "o/r"})) == 2
        e.close()

    @respx.mock
    def test_incremental(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1, body="Always validate input parameters before processing them further"
                    ),
                ],
            )
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["o/r"], limit=100, min_length=30, output=output, token="test-token")

        respx.reset()
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=2,
                        body="Use type annotations for better IDE support and documentation",
                        created_at="2024-07-01T10:00:00Z",
                    ),
                ],
            )
        )
        _run(e, ["o/r"], limit=100, min_length=30, output=output, token="test-token")

        assert len(e.list_evidence(source_filter={"repo": "o/r"})) == 2
        e.close()

    @respx.mock
    def test_incremental_deduplicates_boundary_comments(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        ts = "2024-06-01T10:00:00Z"
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1,
                        body="First comment with enough length to pass filtering",
                        created_at=ts,
                    ),
                    _gh_comment(
                        id=2,
                        body="Second comment with the exact same timestamp value",
                        created_at=ts,
                    ),
                ],
            )
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["o/r"], limit=100, min_length=30, output=output, token="test-token")
        assert len(e.list_evidence(source_filter={"repo": "o/r"})) == 2

        # Second run — API returns the same boundary comments again (since uses >=)
        respx.reset()
        respx.get("https://api.github.com/repos/o/r/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1,
                        body="First comment with enough length to pass filtering",
                        created_at=ts,
                    ),
                    _gh_comment(
                        id=2,
                        body="Second comment with the exact same timestamp value",
                        created_at=ts,
                    ),
                    _gh_comment(
                        id=3,
                        body="A genuinely new comment that should be added to evidence",
                        created_at="2024-07-01T10:00:00Z",
                    ),
                ],
            )
        )
        _run(e, ["o/r"], limit=100, min_length=30, output=output, token="test-token")

        # Should have 3 total — no duplicates of id=1 or id=2
        assert len(e.list_evidence(source_filter={"repo": "o/r"})) == 3
        e.close()


class TestMultiRepo:
    @respx.mock
    def test_consolidation(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        respx.get("https://api.github.com/repos/org/a/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1,
                        body="Always add error handling around network calls to prevent crashes",
                    ),
                    _gh_comment(
                        id=2,
                        body="Use structured logging instead of print statements for production",
                    ),
                ],
            )
        )
        respx.get("https://api.github.com/repos/org/b/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=3,
                        body="Prefer composition over inheritance for more flexible class design",
                    ),
                ],
            )
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["org/a", "org/b"], limit=100, min_length=30, output=output, token="test-token")

        skill_file = os.path.join(output, "SKILL.md")
        assert os.path.exists(skill_file)
        content = open(skill_file).read()
        assert "org/a" in content and "org/b" in content
        assert len(e.list_evidence(source_filter={"repo": "org/a"})) == 2
        assert len(e.list_evidence(source_filter={"repo": "org/b"})) == 1
        e.close()

    @respx.mock
    def test_no_evidence(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        respx.get("https://api.github.com/repos/org/a/pulls/comments").mock(
            return_value=httpx.Response(200, json=[])
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["org/a"], limit=100, min_length=30, output=output, token="test-token")

        assert not os.path.exists(os.path.join(output, "SKILL.md"))
        e.close()

    @respx.mock
    def test_interim_cleanup(
        self, tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate, monkeypatch
    ):
        monkeypatch.setenv("GITHUB_TOKEN", "test-token")
        respx.get("https://api.github.com/repos/org/a/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=1,
                        body="Always add error handling around network calls to prevent crashes",
                    )
                ],
            )
        )
        respx.get("https://api.github.com/repos/org/b/pulls/comments").mock(
            return_value=httpx.Response(
                200,
                json=[
                    _gh_comment(
                        id=2, body="Prefer composition over inheritance for flexible design"
                    )
                ],
            )
        )

        output = str(tmp_path / "skills" / "code-review")
        e = _engine(tmp_path, mock_embed, mock_distill, mock_edit, mock_consolidate)
        _run(e, ["org/a", "org/b"], limit=100, min_length=30, output=output, token="test-token")

        assert not os.path.exists(os.path.join(output, ".interim"))
        e.close()
