# dstl-code-review

CLI tool that distills GitHub PR review comments into reusable skill files for [Claude Code](https://claude.ai/claude-code). Powered by [pydstl](https://github.com/amitpoonia/pydstl).

## The Problem

Your team's best code review feedback is buried across hundreds of PRs. New contributors don't benefit from it, and AI assistants don't know your team's standards.

## The Solution

`dstl-code-review` extracts review comments from your repos, filters out noise (bots, "LGTM", short comments), and distills the meaningful ones into a structured skill file that Claude Code can reference during development.

## Install

You need [uv](https://docs.astral.sh/uv/) — a fast Python package manager. If you don't have it:

```bash
# macOS / Linux
curl -LsSf https://astral.sh/uv/install.sh | sh

# Windows
powershell -ExecutionPolicy ByPass -c "irm https://astral.sh/uv/install.ps1 | iex"
```

That's it. No cloning, no virtual environments — `uvx` handles everything.

## Setup

Before running, export your API keys:

```bash
# GitHub — use a fine-grained token (https://github.com/settings/tokens?type=beta)
# "Public repositories (read-only)" scope is enough for public repos
export GITHUB_TOKEN=ghp_your_token_here

# LLM — set the key for whichever provider you're using
export GEMINI_API_KEY=your_key       # Google Gemini
export OPENAI_API_KEY=your_key       # OpenAI
export ANTHROPIC_API_KEY=your_key    # Anthropic
```

## Usage

Navigate to your project directory and run the command — the skill file will be created relative to where you run it:

```bash
cd ~/projects/my-app
uvx dstl-code-review \
  --repo your-org/your-repo \
  --model google-gla:gemini-3-flash-preview
```

This creates `.claude/skills/code-review/SKILL.md` inside your project, ready for Claude Code to pick up.

### Quick example

Try it with real public repos:

```bash
uvx dstl-code-review \
  --repo encode/httpx \
  --repo Textualize/rich \
  --model google-gla:gemini-3-flash-preview \
  --limit 20
```

### Single repo

```bash
uvx dstl-code-review \
  --repo your-org/your-repo \
  --model google-gla:gemini-3-flash-preview
```

Fetches all PR review comments, filters noise, and distills them into `.claude/skills/code-review/SKILL.md`.

### Multiple repos

Pass `--repo` multiple times to distill comments from several repos into a single consolidated skill file:

```bash
uvx dstl-code-review \
  --repo your-org/frontend \
  --repo your-org/backend \
  --repo your-org/shared-lib \
  --model google-gla:gemini-3-flash-preview
```

Each repo is distilled independently first, then the results are consolidated into one unified document. Patterns from each repo are preserved without being diluted.

### Incremental runs

Re-running the same command only fetches new comments since the last run. Evidence accumulates in a local SQLite DB, so you can run it periodically to keep the skill file up to date:

```bash
# First run — fetches everything
uvx dstl-code-review --repo your-org/api --model google-gla:gemini-3-flash-preview

# Later — only fetches new comments, re-distills with all evidence
uvx dstl-code-review --repo your-org/api --model google-gla:gemini-3-flash-preview
```

### Custom output location

```bash
uvx dstl-code-review \
  --repo your-org/your-repo \
  --model google-gla:gemini-3-flash-preview \
  --output ./my-project/.claude/skills/code-review
```

Output is always `SKILL.md` inside the specified directory.

## How It Works

```
GitHub PRs ──► Fetch comments ──► Filter noise ──► Store as evidence
                                                         │
                                              ┌──────────┴──────────┐
                                              ▼                     ▼
                                        Per-repo distill    Per-repo distill
                                              │                     │
                                              └──────────┬──────────┘
                                                         ▼
                                                   Consolidate
                                                         │
                                                         ▼
                                          .claude/skills/code-review/SKILL.md
```

**Filtering** — automatically drops bot comments (dependabot, copilot, etc.), low-signal phrases ("LGTM", "+1", "looks good"), and comments shorter than 30 characters.

## Options

```
--repo         GitHub repo (owner/name), repeatable [required]
--model        LLM model string [required]
--limit        Max comments per repo (default: 100)
--min-length   Min comment length to keep (default: 30)
--db-path      SQLite database path (default: .claude/dstl-code-review.db)
--output       Output skill directory (default: .claude/skills/code-review)
--token        GitHub token (or set GITHUB_TOKEN env var)
```

### Supported LLM models

Any model supported by [pydantic-ai](https://ai.pydantic.dev):

```bash
--model google-gla:gemini-3-flash-preview    # Google Gemini
--model openai:gpt-4o                         # OpenAI
--model anthropic:claude-sonnet-4-20250514    # Anthropic
```

## Development

```bash
uv sync --all-extras
uv run pytest tests/ -v
```

## License

MIT
