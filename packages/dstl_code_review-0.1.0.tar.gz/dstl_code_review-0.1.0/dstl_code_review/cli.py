from __future__ import annotations

import os
import re
import subprocess
import time
from typing import Annotated

import httpx
import typer
from pydantic import BaseModel
from pydstl import Dstl
from rich.console import Console

app = typer.Typer(
    name="dstl-code-review",
    help="Distill code review patterns from GitHub PRs into a Claude Code skill file.",
    no_args_is_help=True,
)
console = Console()


API_BASE = "https://api.github.com"
BOT_PATTERNS = ["[bot]", "dependabot", "renovate", "codecov", "github-actions", "copilot"]
LOW_SIGNAL_PATTERNS = {
    "lgtm",
    "looks good",
    "looks good to me",
    "+1",
    "ship it",
    "approved",
    "merging",
}


class ReviewComment(BaseModel):
    id: int
    body: str
    user_login: str
    pr_number: int
    html_url: str
    created_at: str
    path: str | None = None
    diff_hunk: str | None = None


def _resolve_token(token: str | None = None) -> str:
    if token:
        return token
    env_token = os.environ.get("GITHUB_TOKEN")
    if env_token:
        return env_token
    try:
        result = subprocess.run(["gh", "auth", "token"], capture_output=True, text=True, check=True)
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        raise RuntimeError(
            "No GitHub token found. Set GITHUB_TOKEN env var or install/authenticate gh CLI."
        )


def _parse_next_url(link_header: str | None) -> str | None:
    if not link_header:
        return None
    match = re.search(r'<([^>]+)>;\s*rel="next"', link_header)
    return match.group(1) if match else None


def _fetch_comments(
    token: str, repo: str, limit: int, since: str | None = None
) -> list[ReviewComment]:
    client = httpx.Client(
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
        timeout=30.0,
    )
    comments: list[ReviewComment] = []
    params: dict[str, str | int] = {
        "sort": "created",
        "direction": "asc",
        "per_page": min(limit, 100),
    }
    if since:
        params["since"] = since

    url: str | None = f"{API_BASE}/repos/{repo}/pulls/comments"
    is_first_page = True

    try:
        while url and len(comments) < limit:
            response = client.get(url, params=params if is_first_page else None)
            response.raise_for_status()
            is_first_page = False

            # Rate limit check
            try:
                remaining = response.headers.get("X-RateLimit-Remaining")
                if remaining is not None and int(remaining) < 10:
                    reset_at = int(response.headers.get("X-RateLimit-Reset", "0"))
                    time.sleep(max(reset_at - int(time.time()), 1))
            except (ValueError, TypeError):
                pass

            for item in response.json():
                if len(comments) >= limit:
                    break
                comments.append(
                    ReviewComment(
                        id=item["id"],
                        body=item.get("body", ""),
                        user_login=item["user"]["login"],
                        pr_number=int(item["pull_request_url"].rstrip("/").split("/")[-1]),
                        html_url=item["html_url"],
                        created_at=item["created_at"],
                        path=item.get("path"),
                        diff_hunk=item.get("diff_hunk"),
                    )
                )

            url = _parse_next_url(response.headers.get("Link"))
    finally:
        client.close()

    return comments


def is_meaningful_comment(comment: ReviewComment, min_length: int = 30) -> bool:
    login = comment.user_login.lower()
    if any(p in login for p in BOT_PATTERNS):
        return False
    body = comment.body.strip()
    if len(body) < min_length:
        return False
    if body.lower().rstrip(".!").strip() in LOW_SIGNAL_PATTERNS:
        return False
    return True


def _format_evidence(c: ReviewComment) -> str:
    header = f"[PR #{c.pr_number}] Review by {c.user_login}"
    if c.path:
        header += f" on `{c.path}`"
    parts = [header + ":"]
    if c.diff_hunk:
        parts.append(f"```\n{c.diff_hunk}\n```")
    parts.append(c.body)
    return "\n\n".join(parts)


@app.command()
def main(
    repo: Annotated[list[str], typer.Option("--repo", help="GitHub repo (owner/name), repeatable")],
    model: Annotated[
        str,
        typer.Option(
            "--model", help="LLM model for distillation (e.g. google-gla:gemini-3-flash-preview)"
        ),
    ],
    limit: Annotated[int, typer.Option("--limit", help="Max comments per repo", min=1)] = 100,
    min_length: Annotated[int, typer.Option("--min-length", help="Min comment length")] = 30,
    db_path: Annotated[
        str, typer.Option("--db-path", help="Path to dstl database")
    ] = ".claude/dstl-code-review.db",
    output: Annotated[
        str, typer.Option("--output", help="Output skill directory path")
    ] = ".claude/skills/code-review",
    token: Annotated[
        str | None, typer.Option("--token", help="GitHub token", envvar="GITHUB_TOKEN")
    ] = None,
) -> None:
    """Fetch PR review comments and distill them into a code review skill file."""
    os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)
    engine = Dstl(db_path=db_path, model=model)
    try:
        _run(engine, repo, limit, min_length, output, token)
    finally:
        engine.close()


def _run(
    engine: Dstl,
    repos: list[str],
    limit: int,
    min_length: int,
    output: str,
    token: str | None,
) -> None:
    resolved_token = _resolve_token(token)
    skill_id = os.path.basename(output.rstrip("/"))
    skill_dir = output
    skill_file = os.path.join(skill_dir, "SKILL.md")
    interim_dir = os.path.join(skill_dir, ".interim")

    # --- Stage 1: Fetch & store evidence per repo ---
    console.rule("[bold]Stage 1: Fetching review comments[/bold]")
    total_new = 0
    for r in repos:
        console.print(f"\n[bold cyan]{r}[/bold cyan]")
        total_new += _fetch_repo(engine, resolved_token, r, limit, min_length)

    if total_new == 0:
        has_any = any(engine.list_evidence(source_filter={"repo": r}) for r in repos)
        if not has_any:
            console.print("\n[yellow]No evidence found. Nothing to distill.[/yellow]")
            return
        console.print("\n[dim]No new comments, re-distilling existing evidence.[/dim]")

    # --- Stage 2: Per-repo distillation ---
    console.rule("[bold]Stage 2: Per-repo distillation[/bold]")
    per_repo_docs: list[tuple[str, str]] = []
    for r in repos:
        evidence = engine.list_evidence(source_filter={"repo": r})
        if not evidence:
            console.print(f"  [yellow]No evidence for {r}, skipping[/yellow]")
            continue
        console.print(f"  [dim]{r}: distilling {len(evidence)} pieces of evidence[/dim]")
        path = engine.distill(
            topic=f"code review patterns from {r}",
            skill_id=f"interim-{r.replace('/', '-')}",
            output_dir=interim_dir,
            evidence=evidence,
        )
        with open(path) as f:
            content = f.read()
            # Strip the title heading — consolidation adds its own
            lines = content.split("\n")
            if lines and lines[0].startswith("# "):
                content = "\n".join(lines[1:]).lstrip("\n")
            per_repo_docs.append((r, content))

    if not per_repo_docs:
        console.print("[yellow]No documents to consolidate.[/yellow]")
        return

    # --- Stage 3: Consolidation ---
    os.makedirs(skill_dir, exist_ok=True)
    if len(per_repo_docs) == 1:
        console.rule("[bold]Stage 3: Writing final skill[/bold]")
        label, body = per_repo_docs[0]
        with open(skill_file, "w") as f:
            f.write(f"# Code Review Patterns: {label}\n\n{body}")
    else:
        console.rule("[bold]Stage 3: Consolidating across repos[/bold]")
        console.print(f"  [dim]Merging {len(per_repo_docs)} repo distillations[/dim]")
        engine.consolidate(
            documents=per_repo_docs,
            topic="code review patterns and guidelines",
            skill_id=skill_id,
            output_dir=skill_dir,
        )
        # Rename the consolidate output to SKILL.md
        consolidated_path = os.path.join(skill_dir, f"{skill_id}.md")
        if os.path.exists(consolidated_path) and consolidated_path != skill_file:
            os.replace(consolidated_path, skill_file)

    # Cleanup interim files
    if os.path.isdir(interim_dir):
        for f in os.listdir(interim_dir):
            os.remove(os.path.join(interim_dir, f))
        os.rmdir(interim_dir)

    console.print(f"\n[bold green]Skill file written to:[/bold green] {skill_file}")
    for r in repos:
        count = len(engine.list_evidence(source_filter={"repo": r}))
        console.print(f"  [dim]{r}: {count} evidence[/dim]")


def _fetch_repo(engine: Dstl, token: str, repo: str, limit: int, min_length: int) -> int:
    existing = engine.list_evidence(source_filter={"repo": repo})
    timestamps = [e.source["created_at"] for e in existing if e.source and "created_at" in e.source]
    seen_ids = {e.source["comment_id"] for e in existing if e.source and "comment_id" in e.source}
    since = max(timestamps) if timestamps else None

    if since:
        console.print(f"  [dim]Incremental — after {since}[/dim]")

    comments = _fetch_comments(token, repo, limit, since)
    console.print(f"  Fetched [bold]{len(comments)}[/bold] comments")

    meaningful = [
        c for c in comments if c.id not in seen_ids and is_meaningful_comment(c, min_length)
    ]
    filtered = len(comments) - len(meaningful)
    console.print(f"  Kept [bold green]{len(meaningful)}[/bold green] (filtered {filtered})")

    for c in meaningful:
        engine.add_evidence(
            _format_evidence(c),
            source={
                "repo": repo,
                "pr": c.pr_number,
                "author": c.user_login,
                "url": c.html_url,
                "created_at": c.created_at,
                "comment_id": c.id,
            },
        )

    return len(meaningful)
