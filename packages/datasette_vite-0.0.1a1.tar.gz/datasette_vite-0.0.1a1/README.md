# datasette-vite

[![PyPI](https://img.shields.io/pypi/v/datasette-vite.svg)](https://pypi.org/project/datasette-vite/)
[![Changelog](https://img.shields.io/github/v/release/datasette/datasette-vite?include_prereleases&label=changelog)](https://github.com/datasette/datasette-vite/releases)
[![Tests](https://github.com/datasette/datasette-vite/actions/workflows/test.yml/badge.svg)](https://github.com/datasette/datasette-vite/actions/workflows/test.yml)
[![License](https://img.shields.io/badge/license-Apache%202.0-blue.svg)](https://github.com/datasette/datasette-vite/blob/main/LICENSE)

Utility for writing frontend plugins for Datasette with Vite

## Installation

Install this plugin in the same environment as Datasette.
```bash
datasette install datasette-vite
```
## Usage

Usage instructions go here.

## Development

To set up this plugin locally, first checkout the code. You can confirm it is available like this:
```bash
cd datasette-vite
# Confirm the plugin is visible
uv run datasette plugins
```
To run the tests:
```bash
uv run pytest
```
