"""Tests for the send_telegram_audio skill."""

import os
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill() -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, "send_telegram_audio"))


def test_send_telegram_audio_schema():
    skill = _load_skill()
    schema = skill.schema()
    assert schema["name"] == "send_telegram_audio"
    assert "chat_id" in schema["parameters"]["properties"]
    assert "audio_file" in schema["parameters"]["properties"]
    assert set(schema["parameters"]["required"]) == {"chat_id", "audio_file"}


async def test_send_telegram_audio_missing_token(monkeypatch, tmp_path):
    monkeypatch.delenv("TELEGRAM_BOT_TOKEN", raising=False)
    skill = _load_skill()
    audio = tmp_path / "test.mp3"
    audio.write_bytes(b"\xff\xfb\x90\x00")
    with pytest.raises(ValueError, match="TELEGRAM_BOT_TOKEN"):
        await skill.execute({"chat_id": "123", "audio_file": str(audio)})


async def test_send_telegram_audio_file_not_found(monkeypatch):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "fake-token")
    skill = _load_skill()
    with pytest.raises(ValueError, match="not found"):
        await skill.execute({"chat_id": "123", "audio_file": "/nonexistent/audio.mp3"})


async def test_send_telegram_audio_success(monkeypatch, tmp_path):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "fake-token")
    skill = _load_skill()

    audio = tmp_path / "test.mp3"
    audio.write_bytes(b"\xff\xfb\x90\x00" * 100)

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.json.return_value = {
        "ok": True,
        "result": {"message_id": 99},
    }

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        result = await skill.execute(
            {"chat_id": "123", "audio_file": str(audio), "caption": "Test audio"}
        )

    assert "sent" in result["status"].lower()
    assert result["message_id"] == 99
    assert not audio.exists()


async def test_send_telegram_audio_api_error(monkeypatch, tmp_path):
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "fake-token")
    skill = _load_skill()

    audio = tmp_path / "test.mp3"
    audio.write_bytes(b"\xff\xfb\x90\x00")

    mock_response = MagicMock()
    mock_response.status_code = 400
    mock_response.json.return_value = {"description": "Bad Request"}
    mock_response.text = "Bad Request"

    with patch("httpx.AsyncClient") as mock_client_cls:
        mock_client = AsyncMock()
        mock_client.post.return_value = mock_response
        mock_client_cls.return_value.__aenter__ = AsyncMock(return_value=mock_client)
        mock_client_cls.return_value.__aexit__ = AsyncMock(return_value=False)
        with pytest.raises(ValueError, match="Telegram API error"):
            await skill.execute({"chat_id": "123", "audio_file": str(audio)})
