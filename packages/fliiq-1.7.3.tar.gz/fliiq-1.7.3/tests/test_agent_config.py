"""Tests for agent configuration."""

import pytest

from fliiq.runtime.agent.config import MODE_CYCLE, AgentConfig, next_mode


def test_mode_cycle_order():
    """MODE_CYCLE has the expected order."""
    assert MODE_CYCLE == ["plan", "supervised", "autonomous"]


def test_next_mode_cycles_through_all():
    """next_mode cycles through all modes correctly."""
    assert next_mode("plan") == "supervised"
    assert next_mode("supervised") == "autonomous"
    assert next_mode("autonomous") == "plan"


def test_next_mode_wraps_around():
    """next_mode wraps from autonomous back to plan."""
    mode = "autonomous"
    mode = next_mode(mode)
    assert mode == "plan"


def test_next_mode_full_cycle():
    """Cycling 3 times returns to the start."""
    mode = "plan"
    for _ in range(3):
        mode = next_mode(mode)
    assert mode == "plan"


def test_next_mode_invalid_defaults_to_first():
    """Invalid mode defaults to first mode in cycle."""
    assert next_mode("invalid_mode") == "plan"
    assert next_mode("") == "plan"


def test_agent_config_defaults():
    """AgentConfig has sensible defaults."""
    config = AgentConfig()
    assert config.mode == "autonomous"
    assert config.max_iterations == 200


def test_agent_config_custom_values():
    """AgentConfig accepts custom values."""
    config = AgentConfig(mode="plan", max_iterations=50)
    assert config.mode == "plan"
    assert config.max_iterations == 50
