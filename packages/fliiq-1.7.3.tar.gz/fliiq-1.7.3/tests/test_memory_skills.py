"""Tests for memory skill handlers (memory_read, memory_write, memory_search)."""

import os

import pytest

from fliiq.runtime.package_data import bundled_skills_dir
from fliiq.runtime.skills.base import SkillBase

SKILLS_DIR = str(bundled_skills_dir())


def _load_skill(name: str) -> SkillBase:
    return SkillBase(os.path.join(SKILLS_DIR, name))


def test_memory_read_skill_loads():
    skill = _load_skill("memory_read")
    assert skill.name == "memory_read"
    schema = skill.schema()
    assert "name" in schema["parameters"]["properties"]


def test_memory_write_skill_loads():
    skill = _load_skill("memory_write")
    assert skill.name == "memory_write"
    schema = skill.schema()
    assert "name" in schema["parameters"]["properties"]
    assert "content" in schema["parameters"]["properties"]


def test_memory_search_skill_loads():
    skill = _load_skill("memory_search")
    assert skill.name == "memory_search"
    schema = skill.schema()
    assert "query" in schema["parameters"]["properties"]


async def test_write_then_read(tmp_path, monkeypatch):
    """Write memory then read it back via skill handlers."""
    monkeypatch.chdir(tmp_path)
    fliiq_dir = tmp_path / ".fliiq" / "memory"
    fliiq_dir.mkdir(parents=True)
    (fliiq_dir / "skills").mkdir()

    from fliiq.data.skills.core.memory_read.main import handler as read_handler
    from fliiq.data.skills.core.memory_write.main import handler as write_handler

    result = await write_handler({"name": "skills/fitness", "content": "## Fitness\n- Lose 15 lbs"})
    assert "Wrote" in result["result"]

    result = await read_handler({"name": "skills/fitness"})
    assert result["exists"] is True
    assert "Fitness" in result["content"]


async def test_read_nonexistent(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fliiq_dir = tmp_path / ".fliiq" / "memory"
    fliiq_dir.mkdir(parents=True)

    from fliiq.data.skills.core.memory_read.main import handler as read_handler

    result = await read_handler({"name": "skills/nonexistent"})
    assert result["exists"] is False
    assert result["content"] == ""


async def test_write_append_mode(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fliiq_dir = tmp_path / ".fliiq" / "memory"
    fliiq_dir.mkdir(parents=True)
    (fliiq_dir / "skills").mkdir()

    from fliiq.data.skills.core.memory_write.main import handler as write_handler

    await write_handler({"name": "2026-02-03", "content": "Morning entry", "mode": "append"})
    await write_handler({"name": "2026-02-03", "content": "Evening entry", "mode": "append"})

    from fliiq.data.skills.core.memory_read.main import handler as read_handler
    result = await read_handler({"name": "2026-02-03"})
    assert "Morning entry" in result["content"]
    assert "Evening entry" in result["content"]


async def test_search_finds_keyword(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fliiq_dir = tmp_path / ".fliiq" / "memory"
    fliiq_dir.mkdir(parents=True)
    (fliiq_dir / "skills").mkdir()

    from fliiq.data.skills.core.memory_search.main import handler as search_handler
    from fliiq.data.skills.core.memory_write.main import handler as write_handler

    await write_handler({"name": "MEMORY", "content": "Andy likes Cantonese food"})
    result = await search_handler({"query": "Cantonese"})
    assert "Cantonese" in result["results"]


async def test_search_list_skills(tmp_path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    fliiq_dir = tmp_path / ".fliiq" / "memory"
    fliiq_dir.mkdir(parents=True)
    (fliiq_dir / "skills").mkdir()

    from fliiq.data.skills.core.memory_search.main import handler as search_handler
    from fliiq.data.skills.core.memory_write.main import handler as write_handler

    await write_handler({"name": "skills/cantonese", "content": "Lesson 1"})
    await write_handler({"name": "skills/fitness", "content": "Workout A"})

    result = await search_handler({"list_skills": True})
    assert "cantonese" in result["results"]
    assert "fitness" in result["results"]
