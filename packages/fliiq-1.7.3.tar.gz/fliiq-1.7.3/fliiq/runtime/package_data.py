"""Helpers for locating bundled package data (skills, soul, playbooks, templates)."""

from importlib.resources import files
from pathlib import Path


def _data_root() -> Path:
    """Return the root of the fliiq.data package as a concrete Path."""
    return Path(str(files("fliiq.data")))


def bundled_skills_dir() -> Path:
    return _data_root() / "skills" / "core"


def bundled_soul_path() -> Path:
    return _data_root() / "soul" / "SOUL.md"


def bundled_playbooks_dir() -> Path:
    return _data_root() / "playbooks"


def bundled_env_template() -> Path:
    return _data_root() / "templates" / "env.template"


def bundled_soul_template() -> Path:
    return _data_root() / "templates" / "soul.template.md"


def bundled_playbook_template() -> Path:
    return _data_root() / "templates" / "playbook.template.md"
