"""Streaming helper — async generator for consuming LLM streams."""

from typing import AsyncIterator

from fliiq.runtime.llm.providers import BaseLLM


async def stream_response(llm: BaseLLM, messages: list[dict], system: str | None = None) -> AsyncIterator[str]:
    """Convenience wrapper: yields text chunks from any BaseLLM."""
    async for chunk in llm.generate_stream(messages, system):
        yield chunk
