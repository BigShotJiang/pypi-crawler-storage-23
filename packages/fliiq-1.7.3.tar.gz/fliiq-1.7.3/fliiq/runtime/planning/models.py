"""Data models for planning — Plan, PlanStep, AuditTrail, AuditEntry.

DEPRECATED: Plan/PlanStep superseded by runtime/agent/todo.py (model-driven TODO tool).
AuditTrail/AuditEntry superseded by runtime/agent/audit.py.
Kept for reference only. Will be removed in a follow-up PR.
"""

from datetime import datetime, timezone
from uuid import uuid4

from pydantic import BaseModel, Field


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _uid() -> str:
    return uuid4().hex[:12]


class PlanStep(BaseModel):
    id: str = Field(default_factory=_uid)
    title: str
    description: str
    skill: str | None = None
    dependencies: list[str] = Field(default_factory=list)
    status: str = "pending"


class Plan(BaseModel):
    id: str = Field(default_factory=_uid)
    prompt: str
    goal: str
    steps: list[PlanStep]
    created_at: datetime = Field(default_factory=_now)
    metadata: dict = Field(default_factory=dict)


class AuditEntry(BaseModel):
    timestamp: datetime = Field(default_factory=_now)
    event: str
    data: dict | None = None


class AuditTrail(BaseModel):
    id: str = Field(default_factory=_uid)
    prompt: str
    plan: Plan | None = None
    entries: list[AuditEntry] = Field(default_factory=list)
    started_at: datetime = Field(default_factory=_now)
    completed_at: datetime | None = None
