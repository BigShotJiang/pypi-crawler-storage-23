"""Assemble system prompt — pure function, no I/O.

DEPRECATED: Superseded by runtime/agent/prompt.py which adds mode instructions + reflection context.
Still used by pre-flight reflection in CLI (for the reflection LLM call's system prompt).
Will be removed once reflection is updated to use agent prompt directly.
"""


def assemble_system_prompt(
    soul: str,
    user_soul: str | None = None,
    playbook: str | None = None,
    skills: list[dict] | None = None,
) -> str:
    """Compose the system prompt from parts. Order: SOUL → user overrides → playbook → skills."""
    parts = [soul.strip()]

    if user_soul:
        parts.append(f"\n\n## User Overrides\n\n{user_soul.strip()}")

    if playbook:
        parts.append(f"\n\n## Domain Playbook\n\n{playbook.strip()}")

    if skills:
        skill_lines = []
        for s in skills:
            skill_lines.append(f"- **{s['name']}**: {s.get('description', 'No description')}")
        skills_section = "\n".join(skill_lines)
        parts.append(f"\n\n## Available Skills\n\n{skills_section}")

    return "\n".join(parts)
