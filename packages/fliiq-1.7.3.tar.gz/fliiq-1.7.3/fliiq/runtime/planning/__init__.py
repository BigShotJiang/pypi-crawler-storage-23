"""Planning runtime — domain detection, playbook loading, reflection.

NOTE: engine.py, models.py, audit.py, prompt_assembly.py are DEPRECATED.
See runtime/agent/ for the active agent loop architecture.
"""

from fliiq.runtime.planning.domain_detector import detect_domain
from fliiq.runtime.planning.playbook_loader import load_playbook, load_soul
from fliiq.runtime.planning.reflection import reflect

__all__ = [
    "detect_domain",
    "load_playbook",
    "load_soul",
    "reflect",
]
