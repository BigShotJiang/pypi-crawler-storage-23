---
name: web_navigate
description: "Navigate websites, extract information, fill forms, and execute multi-step web tasks. Supports headless and visible browser modes with confirmation before irreversible actions like form submissions."
---

Use this tool when you need to interact with a website — clicking links, filling forms, extracting information from dynamic pages, or completing multi-step flows like booking appointments or submitting applications.

For simple page reads (fetching content from a known URL), prefer `web_fetch` instead. Use `web_navigate` when:
- The page requires JavaScript rendering
- You need to click, scroll, or fill forms
- You need to explore a site to find specific information
- The task involves multiple pages or steps

## Setup Required

```bash
pip install fliiq[browser]
playwright install chromium
```

## Parameters

- **task** (required): Natural language description of what to do. Be specific — include names, dates, preferences, and any details needed to fill forms.
- **url** (optional): Starting URL. If omitted, the browser agent will search/navigate to find the right page.
- **browser_visible** (optional, default false): Set to true to open a visible Chromium window so you can watch the agent navigate in real-time.
- **max_steps** (optional, default 50): Maximum browser actions before stopping.

## Confirmation

Before submitting any form, making a payment, creating an account, or taking any irreversible action, the agent pauses and asks the user for confirmation via the terminal.

## Examples

- "Find the phone number and business hours for Hendrick Honda in Cary NC"
- "Go to hendrickhonda.com and schedule an oil change for Tuesday at 10am"
- "Navigate to OpenTable and book a reservation at Poole's Diner for 2 people, Saturday 7pm"
- "Go to the DMV website and find out what documents I need for a license renewal"
