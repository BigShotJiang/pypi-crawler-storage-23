from datetime import datetime
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


async def handler(params: dict) -> dict:
    """
    Returns the current time in the specified timezone.

    params:
      timezone: str (optional) - IANA-compliant timezone name. Defaults to UTC.
    """
    tz_name = params.get("timezone") or "UTC"

    try:
        tz = ZoneInfo(tz_name)
    except ZoneInfoNotFoundError:
        raise ValueError(
            f"Invalid timezone: '{tz_name}'. Use a valid IANA timezone "
            "identifier (e.g. 'America/New_York', 'UTC', 'Europe/London')."
        )

    now = datetime.now(tz)

    return {
        "iso_8601": now.isoformat(),
        "time": now.strftime("%H:%M:%S"),
        "date": now.strftime("%Y-%m-%d"),
        "timezone": str(tz),
    }


# Local debug
if __name__ == "__main__":
    import asyncio

    print(asyncio.run(handler({})))
    print(asyncio.run(handler({"timezone": "America/New_York"})))
