import os

from fliiq.runtime.security import check_path_allowed


async def handler(params: dict) -> dict:
    """Write content to a file, creating parent dirs if needed."""
    path = params["path"]
    check_path_allowed(path)
    content = params["content"]

    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)

    with open(path, "w") as f:
        f.write(content)

    return {"result": f"Wrote {len(content)} bytes to {path}"}
