---
name: find
description: "Find files matching a glob pattern in a directory tree."
---

Use this tool to find files by name pattern. Uses Python's glob matching. Respects .gitignore-style exclusions. Results capped at a configurable limit.
