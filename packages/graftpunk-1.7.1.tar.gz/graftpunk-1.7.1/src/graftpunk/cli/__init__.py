"""graftpunk CLI package.

This package provides the command-line interface for graftpunk using Typer.
"""

from graftpunk.cli.main import app

__all__ = ["app"]
