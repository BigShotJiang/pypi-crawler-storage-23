from sqlalchemy import (
    Integer, String, Numeric, Boolean, Text, DateTime, JSON, func, ForeignKey
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from datetime import datetime
from decimal import Decimal
from typing import Optional


class Base(DeclarativeBase):
    """Base class for all ORM models."""
    pass

class AlembicVersion(Base):
    __tablename__ = "alembic_version"

    version_num: Mapped[str] = mapped_column(String(32), primary_key=True, nullable=False)

class SchemaVersion(Base):
    __tablename__ = "schema_version"
    version: Mapped[str] = mapped_column(primary_key=True)
    applied_at: Mapped[datetime] = mapped_column(server_default=func.now())


class Users(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    email: Mapped[str] = mapped_column(String, nullable=False, unique=True)
    password_hash: Mapped[Optional[str]] = mapped_column(String)
    role: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    alerts = relationship("Alerts", back_populates="user")
    portfolios = relationship("Portfolios", back_populates="user")
    strategies = relationship("Strategies", back_populates="creator")


class Alerts(Base):
    __tablename__ = "alerts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String(9))

    user = relationship("Users", back_populates="alerts")
    assets_alerts = relationship("AssetsAlerts", back_populates="alert", cascade="all, delete-orphan")
    publication_alerts = relationship("PublicationAlerts", back_populates="alert", cascade="all, delete-orphan")


class Assets(Base):
    __tablename__ = "assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    symbol: Mapped[Optional[str]] = mapped_column(String, unique=True)
    name: Mapped[Optional[str]] = mapped_column(String)
    asset_class: Mapped[Optional[str]] = mapped_column(String(11))
    asset_subclass: Mapped[Optional[str]] = mapped_column(String(8))
    currency: Mapped[Optional[str]] = mapped_column(String)
    base_currency: Mapped[Optional[str]] = mapped_column(String)
    quote_currency: Mapped[Optional[str]] = mapped_column(String)
    lot_unit: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    price_tick: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    quantity_step: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    liquidity_profile: Mapped[Optional[str]] = mapped_column(String(9))
    volatility_profile: Mapped[Optional[str]] = mapped_column(String(6))
    trading_hours: Mapped[Optional[str]] = mapped_column(String)
    market: Mapped[Optional[str]] = mapped_column(String(3))

    assets_alerts = relationship("AssetsAlerts", back_populates="asset")
    operations = relationship("Operations", back_populates="asset")
    opportunities = relationship("Opportunities", back_populates="asset")
    analysis_assets = relationship("AnalysisAssets", back_populates="asset")
    asset_specific_exposures = relationship("AssetSpecificExposures", back_populates="asset")
    price_history = relationship("PriceHistory", back_populates="asset")


class AssetsAlerts(Base):
    __tablename__ = "assets_alerts"

    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id"), primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), primary_key=True, nullable=False)
    asset_price: Mapped[Optional[Decimal]] = mapped_column(Numeric)

    alert = relationship("Alerts", back_populates="assets_alerts")
    asset = relationship("Assets", back_populates="assets_alerts")


class EconomicCalendar(Base):
    __tablename__ = "economic_calendar"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    fundamental_indicator_id: Mapped[int] = mapped_column(ForeignKey("fundamental_indicators.id"), nullable=False)
    previous_value: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    forecast_value: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    actual_value: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    event_name: Mapped[Optional[str]] = mapped_column(String)
    country: Mapped[Optional[str]] = mapped_column(String)
    impact_level: Mapped[Optional[str]] = mapped_column(String)
    event_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    fundamental_indicator = relationship("FundamentalIndicators", back_populates="economic_events")
    publication_alerts = relationship("PublicationAlerts", back_populates="publication")
    indicator_scores = relationship("IndicatorScores", back_populates="publication")


class PublicationAlerts(Base):
    __tablename__ = "publication_alerts"

    alert_id: Mapped[int] = mapped_column(ForeignKey("alerts.id"), primary_key=True, nullable=False)
    publication_id: Mapped[int] = mapped_column(ForeignKey("economic_calendar.id"), primary_key=True, nullable=False)
    estimated_date: Mapped[Optional[datetime]] = mapped_column(DateTime)

    alert = relationship("Alerts", back_populates="publication_alerts")
    publication = relationship("EconomicCalendar", back_populates="publication_alerts")


class Portfolios(Base):
    __tablename__ = "portfolios"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(Text)
    base_currency: Mapped[Optional[str]] = mapped_column(String)
    initial_capital: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    current_capital: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    risk_profile: Mapped[Optional[str]] = mapped_column(String)
    benchmark: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    user = relationship("Users", back_populates="portfolios")
    operations = relationship("Operations", back_populates="portfolio")
    objectives = relationship("Objectives", back_populates="portfolio")
    performance_returns = relationship("PerformanceReturns", back_populates="portfolio")
    performance_risk = relationship("PerformanceRisk", back_populates="portfolio")
    execution_stats = relationship("ExecutionStats", back_populates="portfolio")
    behavioral_stats = relationship("BehavioralStats", back_populates="portfolio")
    portfolio_history = relationship("PortfolioHistory", back_populates="portfolio")


class Operations(Base):
    __tablename__ = "operations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[Optional[int]] = mapped_column(ForeignKey("strategies.id"))
    opportunity_id: Mapped[Optional[int]] = mapped_column(ForeignKey("opportunities.id"))
    direction: Mapped[Optional[str]] = mapped_column(String(5))
    operation_type: Mapped[Optional[str]] = mapped_column(String(13))
    time_horizon: Mapped[Optional[str]] = mapped_column(String(8))
    quantity: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    price: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    notional: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    stop_loss: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    take_profit: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    fees: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    slippage: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    status: Mapped[Optional[str]] = mapped_column(String(8))
    executed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="operations")
    asset = relationship("Assets", back_populates="operations")
    strategy = relationship("Strategies", back_populates="operations")
    opportunity = relationship("Opportunities", back_populates="operations")
    operation_history = relationship("OperationHistory", back_populates="operation", cascade="all, delete-orphan")

class Opportunities(Base):
    __tablename__ = "opportunities"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"), nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    direction: Mapped[Optional[str]] = mapped_column(String(5))
    confidence_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    entry_price: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    stop_loss: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    take_profit: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    expected_return: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    risk_reward_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    status: Mapped[Optional[str]] = mapped_column(String(9))
    valid_from: Mapped[Optional[datetime]] = mapped_column(DateTime)
    valid_until: Mapped[Optional[datetime]] = mapped_column(DateTime)
    detected_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    closed_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    asset = relationship("Assets", back_populates="opportunities")
    strategy = relationship("Strategies", back_populates="opportunities")
    analysis = relationship("GeneratedAnalyses", back_populates="opportunities")
    operations = relationship("Operations", back_populates="opportunity")
    opportunity_history = relationship("OpportunityHistory", back_populates="opportunity", cascade="all, delete-orphan")


class Strategies(Base):
    __tablename__ = "strategies"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    asset_class: Mapped[Optional[str]] = mapped_column(String(11))
    strategy_type: Mapped[Optional[str]] = mapped_column(String(13))
    creator_id: Mapped[int] = mapped_column(ForeignKey("users.id"), nullable=False)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    max_position_size: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    expected_return: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    risk_estimate: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    leverage: Mapped[Optional[Decimal]] = mapped_column(Numeric)

    creator = relationship("Users", back_populates="strategies")
    operations = relationship("Operations", back_populates="strategy")
    opportunities = relationship("Opportunities", back_populates="strategy")
    strategy_objectives = relationship("StrategyObjectives", back_populates="strategy")
    strategy_history = relationship("StrategyHistory", back_populates="strategy", cascade="all, delete-orphan")


class Objectives(Base):
    __tablename__ = "objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    type: Mapped[Optional[str]] = mapped_column(String)
    target_return: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    max_drawdown: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    asset_class: Mapped[Optional[str]] = mapped_column(String(11))
    exposure: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    time_horizon: Mapped[Optional[str]] = mapped_column(String(8))
    priority: Mapped[Optional[int]] = mapped_column(Integer)
    status: Mapped[Optional[str]] = mapped_column(String(22))
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="objectives")
    strategy_objectives = relationship("StrategyObjectives", back_populates="objective")
    objective_history = relationship("ObjectiveHistory", back_populates="objective", cascade="all, delete-orphan")


class StrategyObjectives(Base):
    __tablename__ = "strategy_objectives"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[int] = mapped_column(ForeignKey("strategies.id"), nullable=False)
    objective_id: Mapped[int] = mapped_column(ForeignKey("objectives.id"), nullable=False)
    correlation_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)

    strategy = relationship("Strategies", back_populates="strategy_objectives")
    objective = relationship("Objectives", back_populates="strategy_objectives")


class MacroRegimes(Base):
    __tablename__ = "macro_regimes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    description: Mapped[Optional[str]] = mapped_column(Text)
    growth_trend: Mapped[Optional[str]] = mapped_column(String(9))
    inflation_trend: Mapped[Optional[str]] = mapped_column(String(7))
    monetary_policy: Mapped[Optional[str]] = mapped_column(String(10))
    risk_appetite: Mapped[Optional[str]] = mapped_column(String(8))
    expected_volatility: Mapped[Optional[str]] = mapped_column(String(6))
    liquidity_level: Mapped[Optional[str]] = mapped_column(String(6))
    confidence_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    valid_from: Mapped[Optional[datetime]] = mapped_column(DateTime)
    valid_to: Mapped[Optional[datetime]] = mapped_column(DateTime)

    generated_analyses = relationship("GeneratedAnalyses", back_populates="macro_regime")
    macro_asset_class_exposures = relationship("MacroAssetClassExposures", back_populates="macro_regime")
    asset_specific_exposures = relationship("AssetSpecificExposures", back_populates="macro_regime")
    indicator_scores = relationship("IndicatorScores", back_populates="macro_regime")
    indicator_scores_rules = relationship("IndicatorScoresRules", back_populates="macro_regime")


class Agents(Base):
    __tablename__ = "agents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    type: Mapped[Optional[str]] = mapped_column(String)

    generated_analyses = relationship("GeneratedAnalyses", back_populates="agent")
    agents_sources = relationship("AgentsSources", back_populates="agent")


class NewsSources(Base):
    __tablename__ = "news_sources"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    category: Mapped[Optional[str]] = mapped_column(String)
    country_code: Mapped[Optional[str]] = mapped_column(String(3))

    analysis_news_sources = relationship("AnalysisNewsSources", back_populates="source")
    agents_sources = relationship("AgentsSources", back_populates="news_source")


class GeneratedAnalyses(Base):
    __tablename__ = "generated_analyses"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), nullable=False)
    analysis_type: Mapped[Optional[str]] = mapped_column(String(8))
    time_horizon: Mapped[Optional[str]] = mapped_column(String(8))
    global_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    confidence_level: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    bias: Mapped[Optional[str]] = mapped_column(String(7))
    valid_from: Mapped[Optional[datetime]] = mapped_column(DateTime)
    valid_until: Mapped[Optional[datetime]] = mapped_column(DateTime)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    macro_regime = relationship("MacroRegimes", back_populates="generated_analyses")
    agent = relationship("Agents", back_populates="generated_analyses")
    analysis_news_sources = relationship("AnalysisNewsSources", back_populates="analysis")
    analysis_artifacts = relationship("AnalysisArtifacts", back_populates="analysis")
    analysis_assets = relationship("AnalysisAssets", back_populates="analysis")
    analysis_indicators = relationship("AnalysisIndicators", back_populates="analysis")
    opportunities = relationship("Opportunities", back_populates="analysis")
    analysis_history = relationship("AnalysisHistory", back_populates="analysis", cascade="all, delete-orphan")


class AnalysisNewsSources(Base):
    __tablename__ = "analysis_news_sources"

    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), primary_key=True, nullable=False)
    source_id: Mapped[int] = mapped_column(ForeignKey("news_sources.id"), primary_key=True, nullable=False)

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_news_sources")
    source = relationship("NewsSources", back_populates="analysis_news_sources")


class AnalysisArtifacts(Base):
    __tablename__ = "analysis_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    artifact_type: Mapped[Optional[str]] = mapped_column(String(8))
    uri: Mapped[Optional[str]] = mapped_column(String)
    checksum: Mapped[Optional[str]] = mapped_column(String)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_artifacts")


class AnalysisAssets(Base):
    __tablename__ = "analysis_assets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    bias: Mapped[Optional[str]] = mapped_column(String(7))
    expected_move_pct: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    expected_price_low: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    expected_price_high: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    expected_volatility: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    confidence_level: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_assets")
    asset = relationship("Assets", back_populates="analysis_assets")


class FundamentalIndicators(Base):
    __tablename__ = "fundamental_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    name: Mapped[Optional[str]] = mapped_column(String)
    code: Mapped[Optional[str]] = mapped_column(String, unique=True)
    description: Mapped[Optional[str]] = mapped_column(Text)
    category: Mapped[Optional[str]] = mapped_column(String)
    sub_category: Mapped[Optional[str]] = mapped_column(String)
    unit: Mapped[Optional[str]] = mapped_column(String)
    value_type: Mapped[Optional[str]] = mapped_column(String(6))
    directionality: Mapped[Optional[str]] = mapped_column(String(5))
    typical_frequency: Mapped[Optional[str]] = mapped_column(String(9))
    leading_status: Mapped[Optional[str]] = mapped_column(String(7))
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    economic_events = relationship("EconomicCalendar", back_populates="fundamental_indicator")
    analysis_indicators = relationship("AnalysisIndicators", back_populates="indicator")
    indicator_scores = relationship("IndicatorScores", back_populates="indicator")
    indicator_scores_rules = relationship("IndicatorScoresRules", back_populates="indicator")

class AnalysisIndicators(Base):
    __tablename__ = "analysis_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[int] = mapped_column(ForeignKey("generated_analyses.id"), nullable=False)
    indicator_id: Mapped[int] = mapped_column(ForeignKey("fundamental_indicators.id"), nullable=False)
    raw_value: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    normalized_value: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    weight: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    signal: Mapped[Optional[str]] = mapped_column(String(8))
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_indicators")
    indicator = relationship("FundamentalIndicators", back_populates="analysis_indicators")


class AgentsSources(Base):
    __tablename__ = "agents_sources"

    agent_id: Mapped[int] = mapped_column(ForeignKey("agents.id"), primary_key=True, nullable=False)
    news_source_id: Mapped[int] = mapped_column(ForeignKey("news_sources.id"), primary_key=True, nullable=False)
    reliability_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)

    agent = relationship("Agents", back_populates="agents_sources")
    news_source = relationship("NewsSources", back_populates="agents_sources")


class IndicatorScores(Base):
    __tablename__ = "indicator_scores"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(ForeignKey("fundamental_indicators.id"), nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    publication_id: Mapped[int] = mapped_column(ForeignKey("economic_calendar.id"), nullable=False)
    country_code: Mapped[Optional[str]] = mapped_column(String)
    score_naive: Mapped[Optional[int]] = mapped_column(Integer)
    score_weighted: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    signal_direction: Mapped[Optional[str]] = mapped_column(String(5))
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    indicator = relationship("FundamentalIndicators", back_populates="indicator_scores")
    macro_regime = relationship("MacroRegimes", back_populates="indicator_scores")
    publication = relationship("EconomicCalendar", back_populates="indicator_scores")


class IndicatorScoresRules(Base):
    __tablename__ = "indicator_scores_rules"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    indicator_id: Mapped[int] = mapped_column(ForeignKey("fundamental_indicators.id"), nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    score_naive: Mapped[Optional[int]] = mapped_column(Integer)
    threshold_low: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    threshold_high: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    weight: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    indicator = relationship("FundamentalIndicators", back_populates="indicator_scores_rules")
    macro_regime = relationship("MacroRegimes", back_populates="indicator_scores_rules")


class MacroAssetClassExposures(Base):
    __tablename__ = "macro_asset_class_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    asset_class: Mapped[Optional[str]] = mapped_column(String(11))
    default_exposure: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    macro_regime = relationship("MacroRegimes", back_populates="macro_asset_class_exposures")


class AssetSpecificExposures(Base):
    __tablename__ = "asset_specific_exposures"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    macro_regime_id: Mapped[int] = mapped_column(ForeignKey("macro_regimes.id"), nullable=False)
    asset_id: Mapped[int] = mapped_column(ForeignKey("assets.id"), nullable=False)
    exposure: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    override: Mapped[Optional[bool]] = mapped_column(Boolean)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    updated_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    macro_regime = relationship("MacroRegimes", back_populates="asset_specific_exposures")
    asset = relationship("Assets", back_populates="asset_specific_exposures")


class PerformanceReturns(Base):
    __tablename__ = "performance_returns"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    period: Mapped[Optional[str]] = mapped_column(String(8))
    total_return: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    win_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_win: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_loss: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="performance_returns")


class PerformanceRisk(Base):
    __tablename__ = "performance_risk"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    volatility: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    max_drawdown: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_drawdown: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    drawdown_duration: Mapped[Optional[int]] = mapped_column(Integer)
    sharpe_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    sortino_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    calmar_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    tail_risk: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="performance_risk")


class ExecutionStats(Base):
    __tablename__ = "execution_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    avg_slippage: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_fees: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    slippage_ratio: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    fill_rate: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_time_to_execution: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="execution_stats")


class BehavioralStats(Base):
    __tablename__ = "behavioral_stats"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[int] = mapped_column(ForeignKey("portfolios.id"), nullable=False)
    trade_frequency: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    overtrading_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    avg_holding_time: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    deviation_from_expected_horizon: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    revenge_trading_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    consistency_score: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="behavioral_stats")


class PriceHistory(Base):
    __tablename__ = "price_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    asset_id: Mapped[Optional[int]] = mapped_column(ForeignKey("assets.id"))
    high: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    low: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    open: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    close: Mapped[Optional[Decimal]] = mapped_column(Numeric)
    created_at: Mapped[Optional[datetime]] = mapped_column(DateTime)
    time_unit: Mapped[Optional[str]] = mapped_column(String)

    asset = relationship("Assets", back_populates="price_history")


class StrategyHistory(Base):
    __tablename__ = "strategy_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    strategy_id: Mapped[Optional[int]] = mapped_column(ForeignKey("strategies.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    strategy = relationship("Strategies", back_populates="strategy_history")


class OperationHistory(Base):
    __tablename__ = "operation_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    operation_id: Mapped[Optional[int]] = mapped_column(ForeignKey("operations.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    operation = relationship("Operations", back_populates="operation_history")


class ObjectiveHistory(Base):
    __tablename__ = "objective_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    objective_id: Mapped[Optional[int]] = mapped_column(ForeignKey("objectives.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    objective = relationship("Objectives", back_populates="objective_history")


class PortfolioHistory(Base):
    __tablename__ = "portfolio_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    portfolio_id: Mapped[Optional[int]] = mapped_column(ForeignKey("portfolios.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    portfolio = relationship("Portfolios", back_populates="portfolio_history")


class AnalysisHistory(Base):
    __tablename__ = "analysis_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    analysis_id: Mapped[Optional[int]] = mapped_column(ForeignKey("generated_analyses.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    analysis = relationship("GeneratedAnalyses", back_populates="analysis_history")


class OpportunityHistory(Base):
    __tablename__ = "opportunity_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, nullable=False)
    opportunity_id: Mapped[Optional[int]] = mapped_column(ForeignKey("opportunities.id"))
    snapshot: Mapped[Optional[dict]] = mapped_column(JSON)
    recorded_at: Mapped[Optional[datetime]] = mapped_column(DateTime)

    opportunity = relationship("Opportunities", back_populates="opportunity_history")
