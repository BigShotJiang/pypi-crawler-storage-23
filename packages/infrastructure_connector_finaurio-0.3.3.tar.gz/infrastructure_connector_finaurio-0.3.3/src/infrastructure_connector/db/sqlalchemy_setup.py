"""SQLAlchemy setup and session management for Alembic integration."""

from typing import Optional
from sqlalchemy import create_engine, MetaData, Engine
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.pool import QueuePool
from infrastructure_connector.db.schema_management import initialize_schema_version, verify_schema_compatibility
from infrastructure_connector.db.config import DatabaseConfig

# Import the Base from models to ensure single instance
from infrastructure_connector.models.models import Base

# Global engine and session factory
_engine: Optional[Engine] = None
_SessionLocal: Optional[sessionmaker[Session]] = None
_metadata: Optional[MetaData] = None


def bootstrap_database() -> None:
    """
    Initialize database tables and verify schema compatibility.
    """
    create_all_tables()

    session = get_session()
    try:
        initialize_schema_version(session)
        verify_schema_compatibility(session)
    finally:
        session.close()

def initialize_engine(config: Optional[DatabaseConfig] = None) -> Engine:
    """Initialize SQLAlchemy engine and session factory.
    
    Args:
        config: DatabaseConfig instance. If None, creates a default one from environment.
        
    Returns:
        Initialized SQLAlchemy Engine
    """
    global _engine, _SessionLocal, _metadata
    
    if config is None:
        config = DatabaseConfig()
    
    connection_string = config.get_connection_string()
    _engine = create_engine(
        connection_string,
        echo=False,  # Set to True for SQL debugging
        pool_pre_ping=True,  # Verify connections before using them
        poolclass=QueuePool,
        pool_size=10,
        max_overflow=20,
    )
    
    _SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)
    
    return _engine


def get_engine() -> Engine:
    """Get the SQLAlchemy engine. Initialize if not already done.
    
    Returns:
        SQLAlchemy Engine instance
    """
    global _engine
    if _engine is None:
        initialize_engine()
    return _engine  # type: ignore


def get_session() -> Session:
    """Get a new SQLAlchemy session.
    
    Returns:
        New SQLAlchemy Session instance
    """
    if _SessionLocal is None:
        initialize_engine()
    return _SessionLocal()  # type: ignore


def get_metadata() -> MetaData:
    """Get the SQLAlchemy metadata object.
    
    Returns:
        SQLAlchemy MetaData instance
    """
    if _metadata is None:
        initialize_engine()
    return _metadata  # type: ignore


def reflect_database(config: Optional[DatabaseConfig] = None) -> MetaData:
    """Reflect the database schema into SQLAlchemy metadata.
    
    Args:
        config: DatabaseConfig instance. If None, creates a default one from environment.
        
    Returns:
        MetaData object containing the reflected schema.
    """
    if config is None:
        config = DatabaseConfig()
    
    connection_string = config.get_connection_string()
    temp_engine = create_engine(connection_string)
    reflected_metadata = MetaData()
    reflected_metadata.reflect(bind=temp_engine)
    
    return reflected_metadata

def create_all_tables() -> None:
    """Create all tables defined in SQLAlchemy models if they do not exist."""
    engine = get_engine()
    Base.metadata.create_all(bind=engine)

if __name__ == "__main__":
    bootstrap_database()