"""
cellitac.cli
============
Command-line interface for the cellitac package.

Installed entry points (pyproject.toml):
  cellitac            → run full pipeline (preprocessing + ML)
  cellitac-preprocess → run preprocessing only (R steps)
  cellitac-model      → run ML model only (on existing python_ready_data)

Examples
--------
  # Full pipeline
  cellitac --input ~/singlecell/ATAC --output results/

  # Preprocessing only
  cellitac-preprocess --input ~/singlecell/ATAC --output results/

  # ML only (after preprocessing)
  cellitac-model --data results/python_ready_data --output results/ml_results
"""

import argparse
import sys

from cellitac import config as cfg
from cellitac.pipeline import run_full_pipeline, run_preprocessing, run_model


# ============================================================================
# Full pipeline CLI
# ============================================================================
def main():
    parser = argparse.ArgumentParser(
        prog="cellitac",
        description="scATAC + RNA Multiome Processing & ML Classification Pipeline",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cellitac --input ~/singlecell/ATAC --output my_results
  cellitac --input /data/pbmc10k
        """,
    )
    parser.add_argument(
        "--input", "-i",
        default=cfg.INPUT_DIR,
        metavar="DIR",
        help=f"Raw 10x data directory  (default: {cfg.INPUT_DIR})",
    )
    parser.add_argument(
        "--output", "-o",
        default="cellitac_results",
        metavar="DIR",
        help="Base output directory  (default: cellitac_results)",
    )
    parser.add_argument(
        "--version", "-v",
        action="version",
        version="cellitac 1.0.0",
    )

    args = parser.parse_args()
    try:
        success = run_full_pipeline(input_dir=args.input, output_dir=args.output)
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)


# ============================================================================
# Preprocessing-only CLI
# ============================================================================
def run_preprocess():
    parser = argparse.ArgumentParser(
        prog="cellitac-preprocess",
        description="Run preprocessing only: RNA (Seurat) + ATAC (Signac) + Integration",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cellitac-preprocess --input ~/singlecell/ATAC
  cellitac-preprocess --input /data --output custom_results/
        """,
    )
    parser.add_argument("--input",  "-i", default=cfg.INPUT_DIR,
                        metavar="DIR", help="Raw data directory")
    parser.add_argument("--output", "-o", default="cellitac_results",
                        metavar="DIR", help="Base output directory")
    parser.add_argument("--version", action="version", version="cellitac 1.0.0")

    args = parser.parse_args()

    import os
    team1_dir  = os.path.join(args.output, "team1_rna_output")
    team2_dir  = os.path.join(args.output, "team2_atac_output")
    python_dir = os.path.join(args.output, "python_ready_data")

    try:
        run_preprocessing(
            input_dir=args.input,
            output_dir_team1=team1_dir,
            output_dir_team2=team2_dir,
            output_dir_python=python_dir,
        )
        print(f"\nPreprocessing complete. ML-ready data in: {python_dir}")
        sys.exit(0)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)


# ============================================================================
# ML-only CLI
# ============================================================================
def run_model_cli():
    parser = argparse.ArgumentParser(
        prog="cellitac-model",
        description="Run ML classification on existing python_ready_data",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  cellitac-model --data python_ready_data --output ml_results
  cellitac-model --data cellitac_results/python_ready_data
        """,
    )
    parser.add_argument("--data",   "-d", default=cfg.OUTPUT_DIR_PYTHON,
                        metavar="DIR", help="python_ready_data directory")
    parser.add_argument("--output", "-o", default=cfg.OUTPUT_DIR_ML,
                        metavar="DIR", help="ML results output directory")
    parser.add_argument("--version", action="version", version="cellitac 1.0.0")

    args = parser.parse_args()
    try:
        success = run_model(data_dir=args.data, output_dir=args.output)
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\nInterrupted.", file=sys.stderr)
        sys.exit(1)
    except Exception as exc:
        print(f"[ERROR] {exc}", file=sys.stderr)
        sys.exit(1)
