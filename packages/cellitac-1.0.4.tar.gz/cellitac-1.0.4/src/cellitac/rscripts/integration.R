# ================================================================================
# INTEGRATION: Combine Team 1 & Team 2 outputs for Python ML
# This is the EXACT combine_for_python() function from Part2.r
# Paths are injected by Python via rpy2 before this script runs:
#   PBMC_OUT_TEAM1  (team1_rna_output/)
#   PBMC_OUT_TEAM2  (team2_atac_output/)
#   PBMC_OUT_PYTHON (python_ready_data/)
#   PBMC_TRAIN_FRAC (0.7)
#   PBMC_SEED       (42)
# ================================================================================

combine_for_python <- function(output_dir_team1, output_dir_team2,
                               output_dir_python, train_frac, seed) {

  cat(" COMBINING TEAM OUTPUTS FOR PYTHON ML ..\n")

  if (!dir.exists(output_dir_python)) dir.create(output_dir_python, recursive = TRUE)

  # ----------------------------------------
  # LOAD TEAMS OUTPUTS
  # ----------------------------------------

  # Load RNA features from Team 1
  rna_features <- read.csv(file.path(output_dir_team1, "rna_features_2000.csv"),
                            row.names = 1)
  rna_metadata <- read.csv(file.path(output_dir_team1, "rna_metadata.csv"),
                            row.names = 1)
  cell_labels  <- read.csv(file.path(output_dir_team1, "cell_type_labels.csv"))

  # Load ATAC features from Team 2
  atac_features <- read.csv(file.path(output_dir_team2, "atac_features_5000.csv"),
                             row.names = 1)
  atac_metadata <- read.csv(file.path(output_dir_team2, "atac_metadata.csv"),
                             row.names = 1)

  # ----------------------------------------
  # MATCH CELLS BETWEEN MODALITIES
  # ----------------------------------------

  # Find common cells between RNA and ATAC
  common_cells <- intersect(rownames(rna_features), rownames(atac_features))
  cat("Common cells between RNA and ATAC:", length(common_cells), "\n")

  # Subset to common cells
  rna_features_matched  <- rna_features[common_cells, ]
  atac_features_matched <- atac_features[common_cells, ]

  # ----------------------------------------
  # CREATE COMBINED FEATURE MATRIX
  # ----------------------------------------

  combined_features <- cbind(rna_features_matched, atac_features_matched)
  cat("Combined feature matrix dimensions:", nrow(combined_features),
      "cells x", ncol(combined_features), "features\n")

  # ----------------------------------------
  # PREPARE LABELS AND METADATA
  # ----------------------------------------

  # Match cell labels to common cells
  cell_labels_matched <- cell_labels[cell_labels$cell_id %in% common_cells, ]

  # Create final labels dataframe
  final_labels <- data.frame(
    cell_id   = common_cells,
    cell_type = cell_labels_matched$cell_type[
                  match(common_cells, cell_labels_matched$cell_id)]
  )

  # Remove any cells with missing labels
  complete_cases <- complete.cases(final_labels$cell_type)
  final_labels   <- final_labels[complete_cases, ]
  combined_features <- combined_features[final_labels$cell_id, ]

  # ----------------------------------------
  # CREATE TRAIN/TEST SPLITS  (70/30 stratified, R RNG)
  # ----------------------------------------

  set.seed(seed)

  # Stratified sampling to ensure balanced representation of cell types
  train_indices <- c()
  for (cell_type in unique(final_labels$cell_type)) {
    type_indices  <- which(final_labels$cell_type == cell_type)
    n_train       <- floor(length(type_indices) * train_frac)
    train_indices <- c(train_indices, sample(type_indices, n_train))
  }

  test_indices <- setdiff(1:nrow(final_labels), train_indices)

  # Create split labels
  data_splits <- data.frame(
    cell_id = final_labels$cell_id,
    split   = ifelse(1:nrow(final_labels) %in% train_indices, "train", "test")
  )

  # ----------------------------------------
  # EXPORT FILES FOR PYTHON
  # ----------------------------------------

  cat("Exporting Python-ready files...\n")

  # Main feature matrices
  write.csv(combined_features,
            file.path(output_dir_python, "combined_features.csv"))
  write.csv(rna_features_matched,
            file.path(output_dir_python, "rna_features_2000.csv"))
  write.csv(atac_features_matched,
            file.path(output_dir_python, "atac_features_5000.csv"))

  # Labels and splits
  write.csv(final_labels,  file.path(output_dir_python, "cell_labels.csv"),
            row.names = FALSE)
  write.csv(data_splits,   file.path(output_dir_python, "data_splits.csv"),
            row.names = FALSE)

  # Feature information
  feature_info <- data.frame(
    feature_name  = colnames(combined_features),
    feature_type  = c(rep("RNA",  ncol(rna_features_matched)),
                      rep("ATAC", ncol(atac_features_matched))),
    feature_index = 1:ncol(combined_features)
  )
  write.csv(feature_info, file.path(output_dir_python, "feature_info.csv"),
            row.names = FALSE)

  # Summary statistics
  summary_stats <- data.frame(
    metric = c("total_cells","total_features","rna_features","atac_features",
               "train_cells","test_cells","cell_types"),
    value  = c(nrow(combined_features), ncol(combined_features),
               ncol(rna_features_matched), ncol(atac_features_matched),
               sum(data_splits$split == "train"),
               sum(data_splits$split == "test"),
               length(unique(final_labels$cell_type)))
  )
  write.csv(summary_stats, file.path(output_dir_python, "data_summary.csv"),
            row.names = FALSE)

  # Cell type distribution
  cell_type_dist <- table(final_labels$cell_type)
  write.csv(as.data.frame(cell_type_dist),
            file.path(output_dir_python, "cell_type_distribution.csv"))

  cat("=== PYTHON-READY DATA PREPARATION COMPLETED ===\n")
  cat("Files saved in:", output_dir_python, "\n")
  cat("Ready for Python ML pipeline!\n")
}

# Entry point – called by Python via rpy2
combine_for_python(
  output_dir_team1  = PBMC_OUT_TEAM1,
  output_dir_team2  = PBMC_OUT_TEAM2,
  output_dir_python = PBMC_OUT_PYTHON,
  train_frac        = PBMC_TRAIN_FRAC,
  seed              = PBMC_SEED
)
