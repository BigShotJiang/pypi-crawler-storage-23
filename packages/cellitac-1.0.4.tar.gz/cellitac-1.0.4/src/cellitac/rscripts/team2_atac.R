# ================================================================================
# TEAM 2: ATAC Data Processing & Feature Engineering
# ================================================================================

suppressPackageStartupMessages({
  library(Signac)
  library(Seurat)
  library(GenomicRanges)
  library(data.table)
  library(EnsDb.Hsapiens.v75)
  library(biovizBase)
  library(ggplot2)
  library(Matrix)
})

atac_processing_team2 <- function(input_dir, input_dir_team1, output_dir_team2,
                                   fragments_file, peaks_file) {

  cat("=== ATAC Data Processing Started ===\n")
  cat("  Fragments:", fragments_file, "\n")
  cat("  Peaks    :", peaks_file, "\n")

  if (!dir.exists(output_dir_team2)) dir.create(output_dir_team2, recursive = TRUE)

  rds_file <- file.path(input_dir_team1, "pbmc_rna_processed.rds")
  if (!file.exists(rds_file)) stop("RNA processed RDS not found: ", rds_file)
  if (!file.exists(fragments_file)) stop("Fragments file not found: ", fragments_file)
  if (!file.exists(peaks_file))     stop("Peaks file not found: ", peaks_file)

  data_10x <- readRDS(rds_file)

  peaks   <- read.table(file = peaks_file, col.names = c("chr", "start", "end"))
  granges <- makeGRangesFromDataFrame(peaks)

  fragments <- CreateFragmentObject(path = fragments_file)

  atac_counts <- FeatureMatrix(
    fragments = fragments,
    features  = granges,
    cells     = NULL
  )
  cat("ATAC data dimensions:", nrow(atac_counts), "peaks x", ncol(atac_counts), "cells\n")

  annotations <- GetGRangesFromEnsDb(ensdb = EnsDb.Hsapiens.v75)
  seqlevelsStyle(annotations) <- "UCSC"

  cat("Creating ChromatinAssay object...\n")
  chrom_assay <- CreateChromatinAssay(
    counts       = atac_counts,
    sep          = c(":", "-"),
    annotation   = annotations,
    fragments    = fragments_file,
    genome       = "hg19",
    min.cells    = 10,
    min.features = 200
  )

  pbmc_atac <- CreateSeuratObject(
    counts  = chrom_assay,
    assay   = "ATAC",
    project = "PBMC_ATAC"
  )
  cat("ChromatinAssay created with", ncol(pbmc_atac), "cells\n")

  # ----------------------------------------
  # ATAC QC — safe version
  # ----------------------------------------
  cat("Calculating ATAC QC metrics...\n")

  pbmc_atac <- NucleosomeSignal(object = pbmc_atac)
  pbmc_atac <- TSSEnrichment(object = pbmc_atac, fast = TRUE)

  # Only filter on metrics that actually exist
  filter_expr <- quote(TSS.enrichment > 2 & nucleosome_signal < 4)

  # Add peak_region_fragments filter only if column exists
  if ("peak_region_fragments" %in% colnames(pbmc_atac@meta.data)) {
    cat("  Using peak_region_fragments for filtering\n")
    pbmc_atac <- subset(pbmc_atac,
      subset = peak_region_fragments > 1000   &
               peak_region_fragments < 100000 &
               TSS.enrichment        > 2      &
               nucleosome_signal     < 4)
  } else {
    cat("  peak_region_fragments not found - filtering on TSS + nucleosome only\n")
    pbmc_atac <- subset(pbmc_atac,
      subset = TSS.enrichment   > 2 &
               nucleosome_signal < 4)
  }

  cat("After ATAC QC:", ncol(pbmc_atac), "cells remain\n")

  # ----------------------------------------
  # NORMALIZATION & DIMENSIONALITY REDUCTION
  # ----------------------------------------
  cat("Normalizing ATAC data (TF-IDF + LSI)...\n")

  pbmc_atac <- RunTFIDF(pbmc_atac)
  pbmc_atac <- FindTopFeatures(pbmc_atac, min.cutoff = "q0")
  pbmc_atac <- RunSVD(pbmc_atac)
  pbmc_atac <- RunUMAP(pbmc_atac, reduction = "lsi", dims = 2:30)
  pbmc_atac <- FindNeighbors(pbmc_atac, reduction = "lsi", dims = 2:30)
  pbmc_atac <- FindClusters(pbmc_atac, algorithm = 3, resolution = 0.5)

  # ----------------------------------------
  # EXPORT
  # ----------------------------------------
  cat("Exporting ATAC features...\n")

  top_peaks   <- head(VariableFeatures(pbmc_atac), 5000)
  atac_matrix <- LayerData(pbmc_atac, assay = "ATAC", layer = "data")
  top_peaks   <- intersect(top_peaks, rownames(atac_matrix))

  atac_features <- as.data.frame(as.matrix(t(atac_matrix[top_peaks, ])))

  write.csv(atac_features,       file.path(output_dir_team2, "atac_features_5000.csv"))
  write.csv(pbmc_atac@meta.data, file.path(output_dir_team2, "atac_metadata.csv"))

  peak_info <- data.frame(
    peak                = top_peaks,
    accessibility_score = rowMeans(atac_matrix[top_peaks, ])
  )
  write.csv(peak_info, file.path(output_dir_team2, "top_peaks_info.csv"), row.names = FALSE)

  tryCatch({
    p1 <- VlnPlot(pbmc_atac,
      features = c("TSS.enrichment", "nucleosome_signal"), ncol = 2)
    p2 <- DimPlot(pbmc_atac, reduction = "umap", label = TRUE)
    ggsave(file.path(output_dir_team2, "atac_qc_plots.png"),      p1, width=10, height=6)
    ggsave(file.path(output_dir_team2, "atac_clusters_umap.png"), p2, width=10, height=8)
  }, error = function(e) cat("Warning: plots failed:", conditionMessage(e), "\n"))

  saveRDS(pbmc_atac, file.path(output_dir_team2, "pbmc_atac_processed.rds"))

  cat("=== TEAM 2 ATAC PROCESSING COMPLETED ===\n")
  return(pbmc_atac)
}

atac_processing_team2(
  input_dir        = PBMC_INPUT_DIR,
  input_dir_team1  = PBMC_OUT_TEAM1,
  output_dir_team2 = PBMC_OUT_TEAM2,
  fragments_file   = PBMC_FRAGMENTS_FILE,
  peaks_file       = PBMC_PEAKS_FILE
)
