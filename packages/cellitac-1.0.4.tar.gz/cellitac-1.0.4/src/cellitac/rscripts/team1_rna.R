# ================================================================================
# TEAM 1: RNA Data Processing & Cell Type Annotation
# ================================================================================

library(Seurat)
library(hdf5r)
library(dplyr)
library(ggplot2)
library(patchwork)
library(celldex)
library(SingleR)
library(SingleCellExperiment)

rna_processing_team1 <- function(input_dir, output_dir_team1, h5_file, qc_file) {

  cat("=== RNA Data Processing Started ===\n")
  if (!dir.exists(output_dir_team1)) dir.create(output_dir_team1, recursive = TRUE)

  cat("Loading main data matrix...\n")
  cat("  H5 file:", h5_file, "\n")
  if (!file.exists(h5_file)) stop("Main data file not found: ", h5_file)

  data_10x <- Read10X_h5(h5_file)
  if (is.list(data_10x)) {
    rna_counts <- data_10x$`Gene Expression`
    cat("Multiome data detected - extracted RNA portion\n")
  } else {
    rna_counts <- data_10x
    cat("Single modality data detected\n")
  }
  cat("RNA data dimensions:", nrow(rna_counts), "genes x", ncol(rna_counts), "cells\n")

  cat("Loading per-cell QC metrics...\n")
  qc_metrics <- NULL
  if (!is.null(qc_file) && nchar(qc_file) > 0 && file.exists(qc_file)) {
    qc_metrics <- read.csv(qc_file, row.names = 1)
    cat("Loaded QC metrics for", nrow(qc_metrics), "cells\n")
  } else {
    cat("No QC file - skipping\n")
  }

  cat("Creating Seurat object...\n")
  pbmc_rna <- CreateSeuratObject(
    counts = rna_counts, project = "PBMC_RNA",
    min.cells = 3, min.features = 200)

  if (!is.null(qc_metrics)) {
    common_cells <- intersect(colnames(pbmc_rna), rownames(qc_metrics))
    pbmc_rna <- subset(pbmc_rna, cells = common_cells)
  }

  pbmc_rna[["percent.mt"]]   <- PercentageFeatureSet(pbmc_rna, pattern = "^MT-")
  pbmc_rna[["percent.ribo"]] <- PercentageFeatureSet(pbmc_rna, pattern = "^RP[SL]")
  cat("Seurat object created with", ncol(pbmc_rna), "cells and", nrow(pbmc_rna), "genes\n")

  cat("Applying quality control filters...\n")
  n_before <- ncol(pbmc_rna)
  pbmc_rna <- subset(pbmc_rna,
    subset = nFeature_RNA > 500 & nFeature_RNA < 7000 &
             nCount_RNA > 1000 & percent.mt < 20)
  cat("After QC: cells", n_before, "->", ncol(pbmc_rna), "\n")

  cat("Normalizing data...\n")
  pbmc_rna <- NormalizeData(pbmc_rna, normalization.method = "LogNormalize", scale.factor = 10000)
  pbmc_rna <- FindVariableFeatures(pbmc_rna, selection.method = "vst", nfeatures = 2000)
  pbmc_rna <- ScaleData(pbmc_rna, features = rownames(pbmc_rna))

  cat("Dimensionality reduction and clustering...\n")
  pbmc_rna <- RunPCA(pbmc_rna, features = VariableFeatures(pbmc_rna))
  pbmc_rna <- FindNeighbors(pbmc_rna, dims = 1:15)
  pbmc_rna <- FindClusters(pbmc_rna, resolution = 0.5)
  pbmc_rna <- RunTSNE(pbmc_rna, dims = 1:15)
  pbmc_rna <- RunUMAP(pbmc_rna, dims = 1:15)

  cat("Performing cell type annotation...\n")
  ref   <- celldex::HumanPrimaryCellAtlasData()
  sce   <- as.SingleCellExperiment(pbmc_rna)
  preds <- SingleR(test = sce, ref = ref, labels = ref$label.main)
  pbmc_rna$cell_type <- preds$labels[match(colnames(pbmc_rna), rownames(preds))]
  cat("Cell type annotation completed:\n")
  print(table(pbmc_rna$cell_type))

  cat("Exporting results...\n")
  variable_genes <- head(VariableFeatures(pbmc_rna), 2000)

  # Seurat 5 compatible export
  rna_mat <- LayerData(pbmc_rna, assay = "RNA", layer = "data")
  variable_genes <- intersect(variable_genes, rownames(rna_mat))
  rna_features   <- as.data.frame(as.matrix(t(rna_mat[variable_genes, ])))

  write.csv(rna_features,       file.path(output_dir_team1, "rna_features_2000.csv"))
  write.csv(pbmc_rna@meta.data, file.path(output_dir_team1, "rna_metadata.csv"))

  cell_labels <- data.frame(
    cell_id   = colnames(pbmc_rna),
    cell_type = pbmc_rna$cell_type,
    cluster   = as.character(pbmc_rna$seurat_clusters))
  write.csv(cell_labels, file.path(output_dir_team1, "cell_type_labels.csv"), row.names = FALSE)
  write.csv(data.frame(gene = variable_genes),
    file.path(output_dir_team1, "variable_genes_list.csv"), row.names = FALSE)

  tryCatch({
    p1 <- VlnPlot(pbmc_rna, features = c("nFeature_RNA","nCount_RNA","percent.mt"), ncol=3)
    p2 <- DimPlot(pbmc_rna, reduction="umap", label=TRUE, group.by="cell_type")
    ggsave(file.path(output_dir_team1, "rna_qc_plots.png"),        p1, width=12, height=6)
    ggsave(file.path(output_dir_team1, "rna_cell_types_umap.png"), p2, width=10, height=8)
  }, error = function(e) cat("Warning: plots failed:", conditionMessage(e), "\n"))

  saveRDS(pbmc_rna, file.path(output_dir_team1, "pbmc_rna_processed.rds"))
  cat("=== TEAM 1 RNA PROCESSING COMPLETED ===\n")
  return(pbmc_rna)
}

rna_processing_team1(
  input_dir        = PBMC_INPUT_DIR,
  output_dir_team1 = PBMC_OUT_TEAM1,
  h5_file          = PBMC_H5_FILE,
  qc_file          = if (exists("PBMC_QC_FILE")) PBMC_QC_FILE else ""
)
