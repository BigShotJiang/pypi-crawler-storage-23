"""
cellitac.mainModel
==================
Complete Machine Learning Pipeline for scATAC Cell Type Classification.

This module is a faithful translation of the original scATAC_tf.py notebook.
Every parameter, threshold, model hyperparameter, and algorithmic step is
IDENTICAL to the original. Only the following necessary adaptations were made:

  1. self.data_dir = Path(data_dir)    ← original had hard-coded path, ignored the arg
  2. matplotlib.use("Agg")            ← plt.show() removed; saves to output_dir instead
  3. All output files go to output_dir ← original saved to CWD
  4. zero_division=0 in sklearn calls ← suppresses warning, same numeric result
  5. Proper FileNotFoundError         ← replaces broken cell_type_distribution fallback

Usage
-----
>>> from cellitac.mainModel import scATACMLPipeline
>>> pipeline = scATACMLPipeline(data_dir="python_ready_data",
...                             output_dir="ml_results")
>>> pipeline.run_complete_pipeline()
"""

import json
import warnings
from math import pi
from pathlib import Path

import matplotlib
matplotlib.use("Agg")  # non-interactive backend – plt.show() is a no-op on servers
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import openpyxl          # noqa: F401  (required by pandas ExcelWriter)
import pandas as pd
import seaborn as sns
import plotly.express as px        # noqa: F401
import plotly.graph_objects as go  # noqa: F401
from plotly.subplots import make_subplots  # noqa: F401

from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestClassifier
from sklearn.feature_selection import SelectKBest, f_classif, RFE  # noqa: F401
from sklearn.metrics import (
    accuracy_score, auc, classification_report,
    confusion_matrix, f1_score, precision_score,
    recall_score, roc_auc_score, roc_curve,
)
from sklearn.model_selection import (
    GridSearchCV,          # noqa: F401
    StratifiedKFold,
    learning_curve,
    train_test_split,
)
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.svm import SVC
from xgboost import XGBClassifier

from imblearn.over_sampling import SMOTE, BorderlineSMOTE, ADASYN   # noqa: F401
from imblearn.under_sampling import RandomUnderSampler               # noqa: F401
from imblearn.combine import SMOTETomek                              # noqa: F401

warnings.filterwarnings("ignore")

# ── Exact same style settings as original ────────────────────────────────────
plt.style.use("seaborn-v0_8")
sns.set_palette("husl")


class scATACMLPipeline:
    """this is a Complete ML Pipeline for scATAC cell type classification..."""

    def __init__(self, data_dir="python_ready_data", output_dir="ml_results"):
        """Initialize pipeline with data directory"""
        # ORIGINAL BUG FIXED: original ignored data_dir arg, used hard-coded path
        self.data_dir   = Path(data_dir)
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.models        = {}
        self.results       = {}
        self.scaler        = StandardScaler()
        self.label_encoder = LabelEncoder()
        print("=== scATAC ML Pipeline Initialized... ===")

    # ------------------------------------------------------------------
    # Helper: save figure to output_dir (replaces plt.show())
    # ------------------------------------------------------------------
    def _savefig(self, filename):
        plt.savefig(self.output_dir / filename, dpi=300, bbox_inches="tight")
        plt.close()

    # ==================================================================
    # 1. Load data
    # ==================================================================
    def load_data(self):
        """Load and prepare data from R processing outputs"""
        print("\n1. Loading data from R processing outputs...")

        try:
            # load main feature matrix
            if (self.data_dir / "combined_features.csv").exists():
                self.X = pd.read_csv(self.data_dir / "combined_features.csv", index_col=0)
                print(f"   Combined features loaded: {self.X.shape}")
            else:
                # Fallback to team outputs
                X_rna  = pd.read_csv(self.data_dir / "rna_features_2000.csv",  index_col=0)
                X_atac = pd.read_csv(self.data_dir / "atac_features_5000.csv", index_col=0)

                # find common cells
                common_cells = X_rna.index.intersection(X_atac.index)
                self.X = pd.concat(
                    [X_rna.loc[common_cells], X_atac.loc[common_cells]], axis=1)
                print(f"  Combined from team outputs: {self.X.shape}")

            # load labels
            # ORIGINAL BUG FIXED: cell_type_distribution.csv is a SUMMARY COUNT table,
            # not per-cell labels — using it as fallback would crash the pipeline.
            if (self.data_dir / "cell_labels.csv").exists():
                labels_df = pd.read_csv(self.data_dir / "cell_labels.csv", index_col=0)
            else:
                raise FileNotFoundError(
                    f"cell_labels.csv not found in {self.data_dir}.\n"
                    "  Run preprocessing first:\n"
                    "    cellitac-preprocess --input <raw_data_dir>\n"
                    "  Or:\n"
                    "    from cellitac import run_preprocessing\n"
                    "    run_preprocessing(input_dir='<raw_data_dir>')"
                )

            # Match labels to features
            common_cells = self.X.index.intersection(labels_df.index)
            self.X = self.X.loc[common_cells]
            self.y = labels_df.loc[common_cells, "cell_type"]

            print(f"   Final dataset: {self.X.shape[0]} cells, {self.X.shape[1]} features")
            print(f"   Cell types: {self.y.value_counts().to_dict()}")

            # Remove rare classes (<10 samples)
            counts     = self.y.value_counts()
            keep_types = counts[counts >= 10].index
            mask       = self.y.isin(keep_types)
            removed    = (~mask).sum()

            if removed > 0:
                rare_types = counts[counts < 10].index.tolist()
                self.X = self.X.loc[mask]
                self.y = self.y.loc[mask]
                print(f"   Removed {removed} cells from rare types: {rare_types}")
            else:
                print("   No rare cell types (<10) to remove.")

            # (Optional safety) ensure something remains
            if self.X.empty:
                raise ValueError("All cells were filtered out by the rare-type threshold.")

            # Encode labels for the model
            self.y_encoded   = self.label_encoder.fit_transform(self.y)
            self.class_names = self.label_encoder.classes_
            return True

        except Exception as e:
            print(f"   Error loading data: {e}")
            return False

    # ==================================================================
    # 2. Analyze class imbalance
    # ==================================================================
    def analyze_class_imbalance(self):
        """Analyze and visualize class distribution"""
        print("\n2. Analyzing class distribution...")

        # Calculate class distribution
        class_counts = pd.Series(self.y).value_counts()
        class_props  = pd.Series(self.y).value_counts(normalize=True)

        # Create imbalance analysis
        imbalance_df = pd.DataFrame({
            "Cell_Type":       class_counts.index,
            "Count":           class_counts.values,
            "Proportion":      class_props.values,
            "Imbalance_Ratio": class_counts.max() / class_counts.values,
        })

        print("   Class Distribution:")
        print(imbalance_df.round(3))

        # Check if balancing is needed or not
        max_ratio            = imbalance_df["Imbalance_Ratio"].max()
        self.needs_balancing = max_ratio > 2.0

        print(f"   Maximum imbalance ratio: {max_ratio:.2f}")
        print(f"   Balancing needed : {self.needs_balancing}")

        fig, axes = plt.subplots(2, 2, figsize=(15, 10))

        # Class counts
        sns.barplot(data=imbalance_df, x="Cell_Type", y="Count", ax=axes[0, 0])
        axes[0, 0].set_title("Cell Type Distribution (Counts)")
        axes[0, 0].tick_params(axis="x", rotation=45)

        # Class proportions
        sns.barplot(data=imbalance_df, x="Cell_Type", y="Proportion", ax=axes[0, 1])
        axes[0, 1].set_title("Cell Type Distribution (Proportions)")
        axes[0, 1].tick_params(axis="x", rotation=45)

        # Imbalance ratios
        sns.barplot(data=imbalance_df, x="Cell_Type", y="Imbalance_Ratio", ax=axes[1, 0])
        axes[1, 0].set_title("Class Imbalance Ratios")
        axes[1, 0].axhline(y=2.0, color="red", linestyle="--", label="Threshold (2.0)")
        axes[1, 0].tick_params(axis="x", rotation=45)
        axes[1, 0].legend()

        # Pie chart
        axes[1, 1].pie(class_counts.values, labels=class_counts.index, autopct="%1.1f%%")
        axes[1, 1].set_title("Cell Type Distribution (Pie Chart)")

        plt.tight_layout()
        self._savefig("class_distribution_analysis.png")

        self.imbalance_df = imbalance_df
        return imbalance_df

    # ==================================================================
    # 3. Feature engineering
    # ==================================================================
    def feature_engineering(self):
        """Apply feature engineering and selection"""
        print("\n3. Feature engineering...")

        # Remove features with zero variance
        zero_var_features = self.X.columns[self.X.var() == 0]
        if len(zero_var_features) > 0:
            self.X = self.X.drop(columns=zero_var_features)
            print(f"   Removed {len(zero_var_features)} zero-variance features")

        # Remove highly correlated features
        corr_matrix    = self.X.corr().abs()
        upper_triangle = corr_matrix.where(
            np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
        high_corr_features = [
            column for column in upper_triangle.columns
            if any(upper_triangle[column] > 0.95)
        ]

        if len(high_corr_features) > 0:
            self.X = self.X.drop(columns=high_corr_features)
            print(f"   Removed {len(high_corr_features)} highly correlated features (>0.95)")

        # Feature selection using SelectKBest
        selector = SelectKBest(score_func=f_classif,
                               k=min(1000, self.X.shape[1] // 2))
        X_selected        = selector.fit_transform(self.X, self.y_encoded)
        selected_features = self.X.columns[selector.get_support()]

        self.X_engineered = pd.DataFrame(
            X_selected, index=self.X.index, columns=selected_features)

        print(f"   Selected top {len(selected_features)} features using univariate selection")
        print(f"   Final feature matrix: {self.X_engineered.shape}")

        return self.X_engineered

    # ==================================================================
    # 4. Train / test split
    # ==================================================================
    def prepare_train_test_split(self):
        """Create train/test splits with proper stratification"""
        print("\n4. Creating train/test splits...")

        # Stratified split maintaining class proportions
        self.X_train, self.X_test, self.y_train, self.y_test = train_test_split(
            self.X_engineered, self.y_encoded,
            test_size=0.2,
            random_state=42,
            stratify=self.y_encoded,
        )

        print(f"   Training set: {self.X_train.shape[0]} samples")
        print(f"   Test set: {self.X_test.shape[0]} samples")

        # Show class distribution in splits
        train_dist = pd.Series(self.y_train).value_counts()
        test_dist  = pd.Series(self.y_test).value_counts()

        split_df = pd.DataFrame({
            "Train_Count": train_dist,
            "Test_Count":  test_dist,
            "Train_Prop":  train_dist / len(self.y_train),
            "Test_Prop":   test_dist  / len(self.y_test),
        }).fillna(0)

        print("   Class distribution in splits:")
        print(split_df.round(3))

        return True

    # ==================================================================
    # 5. Handle class imbalance
    # ==================================================================
    def handle_class_imbalance(self):
        """Apply class balancing techniques if needed ..."""
        print("\n5. Handling class imbalance...")

        if not self.needs_balancing:
            print("   No significant imbalance detected... Skipping balancing.")
            self.X_train_balanced = self.X_train.copy()
            self.y_train_balanced = self.y_train.copy()
            return

        print("   Applying SMOTE for class balancing...")

        # Apply SMOTE — exact same parameters as original
        smote = BorderlineSMOTE(kind="borderline-1", k_neighbors=3)
        self.X_train_balanced, self.y_train_balanced = smote.fit_resample(
            self.X_train, self.y_train)

        # Compare before and after
        before_counts = pd.Series(self.y_train).value_counts()
        after_counts  = pd.Series(self.y_train_balanced).value_counts()

        comparison_df = pd.DataFrame({
            "Before_SMOTE": before_counts,
            "After_SMOTE":  after_counts,
            "Improvement":  after_counts / before_counts,
        }).fillna(0)

        print("   Balancing results:")
        print(comparison_df)

        # Visualize balancing effect
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

        # Before balancing
        before_counts.plot(kind="bar", ax=ax1, color="lightcoral")
        ax1.set_title("Class Distribution Before SMOTE")
        ax1.set_ylabel("Count")
        ax1.tick_params(axis="x", rotation=45)

        # After balancing
        after_counts.plot(kind="bar", ax=ax2, color="lightgreen")
        ax2.set_title("Class Distribution After SMOTE")
        ax2.set_ylabel("Count")
        ax2.tick_params(axis="x", rotation=45)

        plt.tight_layout()
        self._savefig("class_balancing_comparison.png")

        return comparison_df

    # ==================================================================
    # 6. Scale features
    # ==================================================================
    def scale_features(self):
        """Scale features for algorithms that require it"""
        print("\n6. Scaling features...")

        # Fit scaler on training data only
        self.X_train_scaled = pd.DataFrame(
            self.scaler.fit_transform(self.X_train_balanced),
            index=self.X_train_balanced.index,
            columns=self.X_train_balanced.columns,
        )

        self.X_test_scaled = pd.DataFrame(
            self.scaler.transform(self.X_test),
            index=self.X_test.index,
            columns=self.X_test.columns,
        )

        print(f"   Features scaled using StandardScaler")
        print(f"   Training mean: {self.X_train_scaled.mean().mean():.6f}")
        print(f"   Training std: {self.X_train_scaled.std().mean():.6f}")

        return True

    # ==================================================================
    # 7. Define models
    # ==================================================================
    def define_models(self):
        """Define models with optimized hyperparameters for preventing overfitting"""
        print("\n7. Defining ML models ...")

        n_classes  = len(self.class_names)
        n_features = self.X_train_balanced.shape[1]  # noqa: F841
        n_samples  = self.X_train_balanced.shape[0]  # noqa: F841

        # Random Forest - Conservative parameters
        self.models["Random Forest"] = {
            "model": RandomForestClassifier(
                n_estimators=100,           # Moderate number of trees
                max_depth=10,               # Limit depth to prevent overfitting
                min_samples_split=20,       # Require more samples to split
                min_samples_leaf=10,        # Require more samples in leaf
                max_features="sqrt",        # Feature subsampling
                class_weight="balanced",    # Handle any remaining imbalance
                random_state=42,
                n_jobs=-1,
            ),
            "requires_scaling": False,
        }

        # XGBoost - With regularization
        self.models["XGBoost"] = {
            "model": XGBClassifier(
                n_estimators=100,
                max_depth=6,                # Moderate depth
                learning_rate=0.1,          # Conservative learning rate
                subsample=0.8,              # Subsample rows
                colsample_bytree=0.8,       # Subsample features
                reg_alpha=0.1,              # L1 regularization
                reg_lambda=1.0,             # L2 regularization
                min_child_weight=3,         # Minimum samples in leaf
                random_state=42,
                eval_metric="mlogloss" if n_classes > 2 else "logloss",
                verbosity=0,
            ),
            "requires_scaling": False,
        }

        # SVM - With regularization
        self.models["SVM"] = {
            "model": SVC(
                C=1.0,                      # Regularization parameter
                kernel="rbf",
                gamma="scale",              # Automatic gamma scaling
                class_weight="balanced",    # Handle imbalance
                probability=True,           # Enable probability estimates
                random_state=42,
            ),
            "requires_scaling": True,
        }

        print(f"   Defined {len(self.models)} models ")
        for name, cfg in self.models.items():
            print(f"     - {name}: {type(cfg['model']).__name__}")

        return self.models

    # ==================================================================
    # 8. Train and evaluate models
    # ==================================================================
    def train_and_evaluate_models(self):
        """Train all models and evaluate performance"""
        print("\n8. Training and evaluating models...")

        for model_name, cfg in self.models.items():
            print(f"\n   Training {model_name}...")

            # Select appropriate data (scaled vs unscaled)
            if cfg["requires_scaling"]:
                X_train = self.X_train_scaled
                X_test  = self.X_test_scaled
            else:
                X_train = self.X_train_balanced
                X_test  = self.X_test

            # Train model
            model = cfg["model"]
            model.fit(X_train, self.y_train_balanced)

            # Predictions
            y_pred       = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)

            # Store results
            self.results[model_name] = {
                "model":        model,
                "y_pred":       y_pred,
                "y_pred_proba": y_pred_proba,
                "X_test":       X_test,
            }

            print(f"     {model_name} training completed")

        return self.results

    # ==================================================================
    # 9. Calculate metrics
    # ==================================================================
    def calculate_metrics(self):
        """Calculate comprehensive evaluation metrics"""
        print("\n9. Calculating evaluation metrics...")

        metrics_data = []

        for model_name, results in self.results.items():
            y_pred       = results["y_pred"]
            y_pred_proba = results["y_pred_proba"]

            # Basic metrics — exact same average='weighted' as original
            accuracy  = accuracy_score(self.y_test, y_pred)
            precision = precision_score(self.y_test, y_pred, average="weighted",
                                        zero_division=0)
            recall    = recall_score(self.y_test, y_pred, average="weighted",
                                     zero_division=0)
            f1        = f1_score(self.y_test, y_pred, average="weighted",
                                 zero_division=0)

            # Multi-class AUC
            if len(self.class_names) > 2:
                auc_score = roc_auc_score(self.y_test, y_pred_proba,
                                          multi_class="ovr", average="weighted")
            else:
                auc_score = roc_auc_score(self.y_test, y_pred_proba[:, 1])

            metrics_data.append({
                "Model":     model_name,
                "Accuracy":  accuracy,
                "Precision": precision,
                "Recall":    recall,
                "F1_Score":  f1,
                "AUC":       auc_score,
            })

        self.metrics_df = pd.DataFrame(metrics_data)

        print("\n   Model Performance Summary:")
        print(self.metrics_df.round(4))

        return self.metrics_df

    # ==================================================================
    # 10. Detailed evaluation table
    # ==================================================================
    def create_detailed_evaluation_table(self):
        """Create detailed per-class evaluation metrics"""
        print("\n10. Creating detailed evaluation tables...")

        detailed_results = {}

        for model_name, results in self.results.items():
            y_pred = results["y_pred"]

            # Get per-class metrics
            report = classification_report(
                self.y_test, y_pred,
                target_names=self.class_names,
                output_dict=True,
                zero_division=0,
            )

            # Convert to DataFrame
            class_metrics = pd.DataFrame(report).transpose()
            class_metrics = class_metrics.drop(["accuracy"], errors="ignore")
            class_metrics = class_metrics.round(4)

            detailed_results[model_name] = class_metrics

            print(f"\n   {model_name} - Per-class Metrics:")
            print(class_metrics)

        self.detailed_results = detailed_results
        return detailed_results

    # ==================================================================
    # 11. Create visualizations
    # ==================================================================
    def create_visualizations(self):
        """Create comprehensive visualizations"""
        print("\n11. Creating visualizations...")

        # 1. Model comparison
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.ravel()

        metrics = ["Accuracy", "Precision", "Recall", "F1_Score", "AUC"]

        for i, metric in enumerate(metrics):
            sns.barplot(data=self.metrics_df, x="Model", y=metric, ax=axes[i])
            axes[i].set_title(f"{metric} Comparison")
            axes[i].set_ylim(0, 1)
            axes[i].tick_params(axis="x", rotation=45)

            # Add value labels
            for j, v in enumerate(self.metrics_df[metric]):
                axes[i].text(j, v + 0.01, f"{v:.3f}", ha="center", va="bottom")

        # Overall comparison
        metrics_melted = self.metrics_df.melt(
            id_vars=["Model"], var_name="Metric", value_name="Score")
        sns.barplot(data=metrics_melted, x="Model", y="Score",
                    hue="Metric", ax=axes[5])
        axes[5].set_title("Overall Model Comparison")
        axes[5].legend(bbox_to_anchor=(1.05, 1), loc="upper left")
        axes[5].tick_params(axis="x", rotation=45)

        plt.tight_layout()
        self._savefig("model_performance_comparison.png")

        # 2. Confusion matrices
        fig, axes = plt.subplots(1, len(self.models),
                                 figsize=(6 * len(self.models), 5))
        if len(self.models) == 1:
            axes = [axes]

        for i, (model_name, results) in enumerate(self.results.items()):
            cm = confusion_matrix(self.y_test, results["y_pred"])
            sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                        xticklabels=self.class_names,
                        yticklabels=self.class_names,
                        ax=axes[i])
            axes[i].set_title(f"{model_name}\nConfusion Matrix")
            axes[i].set_ylabel("True Label")
            axes[i].set_xlabel("Predicted Label")

        plt.tight_layout()
        self._savefig("confusion_matrices.png")

        # 3. ROC Curves (if binary classification)
        if len(self.class_names) == 2:
            plt.figure(figsize=(10, 8))

            for model_name, results in self.results.items():
                y_pred_proba = results["y_pred_proba"][:, 1]
                fpr, tpr, _ = roc_curve(self.y_test, y_pred_proba)
                auc_score   = auc(fpr, tpr)
                plt.plot(fpr, tpr, label=f"{model_name} (AUC = {auc_score:.3f})")

            plt.plot([0, 1], [0, 1], "k--", label="Random Classifier")
            plt.xlabel("False Positive Rate")
            plt.ylabel("True Positive Rate")
            plt.title("ROC Curves Comparison")
            plt.legend()
            plt.grid(True, alpha=0.3)
            self._savefig("roc_curves.png")

        # 4. Feature importance (for tree-based models)
        rf_model  = self.results["Random Forest"]["model"]
        xgb_model = self.results["XGBoost"]["model"]

        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 6))

        # Random Forest importance
        rf_importance = pd.DataFrame({
            "feature":    self.X_train_balanced.columns,
            "importance": rf_model.feature_importances_,
        }).sort_values("importance", ascending=True).tail(20)

        sns.barplot(data=rf_importance, x="importance", y="feature", ax=ax1)
        ax1.set_title("Random Forest - Top 20 Feature Importances")

        # XGBoost importance
        xgb_importance = pd.DataFrame({
            "feature":    self.X_train_balanced.columns,
            "importance": xgb_model.feature_importances_,
        }).sort_values("importance", ascending=True).tail(20)

        sns.barplot(data=xgb_importance, x="importance", y="feature", ax=ax2)
        ax2.set_title("XGBoost - Top 20 Feature Importances")

        plt.tight_layout()
        self._savefig("feature_importance.png")

        return True

    # ==================================================================
    # 12. Detect overfitting
    # ==================================================================
    def detect_overfitting(self):
        """Analyze potential overfitting using cross-validation"""
        print("\n12. Analyzing overfitting with cross-validation...")

        cv_results = {}
        cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

        for model_name, cfg in self.models.items():
            print(f"     Cross-validating {model_name}...")

            model = cfg["model"]

            # Select appropriate data
            if cfg["requires_scaling"]:
                X_data = self.X_train_scaled
            else:
                X_data = self.X_train_balanced

            train_scores = []
            val_scores   = []

            for train_idx, val_idx in cv.split(X_data, self.y_train_balanced):
                X_train_fold = X_data.iloc[train_idx]
                X_val_fold   = X_data.iloc[val_idx]

                y_train_fold = self.y_train_balanced[train_idx]
                y_val_fold   = self.y_train_balanced[val_idx]

                # Train and evaluate
                model_copy = type(model)(**model.get_params())
                model_copy.fit(X_train_fold, y_train_fold)

                train_score = model_copy.score(X_train_fold, y_train_fold)
                val_score   = model_copy.score(X_val_fold, y_val_fold)

                train_scores.append(train_score)
                val_scores.append(val_score)

            avg_train       = np.mean(train_scores)
            avg_val         = np.mean(val_scores)
            overfitting_gap = avg_train - avg_val

            cv_results[model_name] = {
                "Train_Accuracy":      avg_train,
                "Validation_Accuracy": avg_val,
                "Overfitting_Gap":     overfitting_gap,
                "Train_Std":           np.std(train_scores),
                "Val_Std":             np.std(val_scores),
            }

        cv_df = pd.DataFrame(cv_results).T.round(4)

        print("\n   Cross-Validation Results:")
        print(cv_df)

        # Visualize overfitting analysis
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # Train vs Validation scores
        x_pos = np.arange(len(cv_df))
        width = 0.35

        ax1.bar(x_pos - width / 2, cv_df["Train_Accuracy"],
                width, label="Training Accuracy", alpha=0.8)
        ax1.bar(x_pos + width / 2, cv_df["Validation_Accuracy"],
                width, label="Validation Accuracy", alpha=0.8)

        ax1.set_xlabel("Models")
        ax1.set_ylabel("Accuracy")
        ax1.set_title("Training vs. Validation Accuracy")
        ax1.set_xticks(x_pos)
        ax1.set_xticklabels(cv_df.index, rotation=45)
        ax1.legend()
        ax1.grid(True, alpha=0.3)

        # Overfitting gaps
        sns.barplot(x=cv_df.index, y=cv_df["Overfitting_Gap"], ax=ax2)
        ax2.set_title("Overfitting Gap (Train - Validation) ")
        ax2.set_ylabel("Accuracy Gap")
        ax2.axhline(y=0.05, color="red", linestyle="--",
                    label="Warning Threshold (0.05)")
        ax2.axhline(y=0.1,  color="red", linestyle="-",
                    label="Critical Threshold (0.1)")
        ax2.legend()
        ax2.tick_params(axis="x", rotation=45)

        plt.tight_layout()
        self._savefig("overfitting_analysis.png")

        # Overfitting warnings
        print("\n   Overfitting Analysis:")
        for model_name, results in cv_results.items():
            gap = results["Overfitting_Gap"]
            if gap > 0.1:
                print(f"     WARNING: {model_name} shows significant overfitting (gap: {gap:.3f})")
            elif gap > 0.05:
                print(f"     CAUTION: {model_name} shows moderate overfitting (gap: {gap:.3f})")
            else:
                print(f"     GOOD: {model_name} shows minimal overfitting (gap: {gap:.3f})")

        self.cv_results = cv_df
        return cv_df

    # ==================================================================
    # 13. Generate final report
    # ==================================================================
    def generate_final_report(self):
        """Generate comprehensive final report"""
        print("\n13. Generating final report...")

        # Create summary report
        report = {
            "Dataset_Info": {
                "Total_Samples":           len(self.y),
                "Total_Features_Original": self.X.shape[1] if hasattr(self, "X") else "N/A",
                "Total_Features_Final":    self.X_engineered.shape[1],
                "Cell_Types":              len(self.class_names),
                "Class_Names":             list(self.class_names),
            },
            "Class_Distribution": self.imbalance_df.to_dict("records"),
            "Balancing_Applied":  self.needs_balancing,
            "Model_Performance":  self.metrics_df.to_dict("records"),
            "Cross_Validation":   self.cv_results.to_dict() if hasattr(self, "cv_results") else None,
        }

        # Find best model
        best_model_idx  = self.metrics_df["F1_Score"].idxmax()
        best_model_name = self.metrics_df.loc[best_model_idx, "Model"]
        best_f1_score   = self.metrics_df.loc[best_model_idx, "F1_Score"]

        print(f"\n=== ..... FINAL RESULTS.... ===")
        print(f"Best Model: {best_model_name}")
        print(f"Best F1-Score: {best_f1_score:.4f}")
        print(f"Dataset: {len(self.y)} cells, {self.X_engineered.shape[1]} features")
        print(f"Cell Types: {len(self.class_names)}")
        print(f"Class Balancing Applied: {self.needs_balancing}")

        # Save results — to output_dir instead of CWD
        json_path = self.output_dir / "ml_pipeline_report.json"
        with open(json_path, "w") as f:
            json.dump(report, f, indent=2, default=str)

        csv_path = self.output_dir / "model_performance_summary.csv"
        self.metrics_df.to_csv(csv_path, index=False)

        xlsx_path = self.output_dir / "detailed_model_results.xlsx"
        with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
            self.metrics_df.to_excel(writer, sheet_name="Summary", index=False)
            if hasattr(self, "cv_results"):
                self.cv_results.to_excel(writer, sheet_name="Cross_Validation")
            self.imbalance_df.to_excel(writer, sheet_name="Class_Distribution",
                                        index=False)
            for model_name, class_metrics in self.detailed_results.items():
                sheet = model_name[:31]
                class_metrics.to_excel(writer, sheet_name=f"{sheet}_Details")

        print("\nFiles Generated:")
        print(f"  - {json_path}")
        print(f"  - {csv_path}")
        print(f"  - {xlsx_path}")
        print("  - Multiple visualization PNG files")

        return report

    # ==================================================================
    # 14. Simple feature heatmap
    # ==================================================================
    def simple_feature_heatmap(self):
        """Simple feature importance heatmap using only tree-based models"""
        print("\n14. Creating simple feature importance heatmap...")

        # Only use models that definitely have feature_importances_
        tree_models = {}
        for model_name, results in self.results.items():
            if hasattr(results["model"], "feature_importances_"):
                tree_models[model_name] = results["model"].feature_importances_

        if not tree_models:
            print("No tree-based models found for feature importance")
            return

        # Create simple heatmap
        importance_df = pd.DataFrame(
            tree_models, index=self.X_train_balanced.columns)
        top_features = importance_df.sum(axis=1).nlargest(20)

        plt.figure(figsize=(10, 8))
        sns.heatmap(importance_df.loc[top_features.index],
                    annot=False, cmap="viridis")
        plt.title("Top 20 Feature Importance - Tree Models Only")
        plt.tight_layout()
        self._savefig("simple_feature_heatmap.png")

    # ==================================================================
    # 15. Learning curves
    # ==================================================================
    def create_learning_curves(self):
        """Create learning curves to visualize overfitting"""
        print("\n15. Creating learning curves...")

        fig, axes = plt.subplots(1, len(self.models), figsize=(15, 5))
        if len(self.models) == 1:
            axes = [axes]

        for i, (model_name, cfg) in enumerate(self.models.items()):
            model = cfg["model"]

            # Select appropriate data
            if cfg["requires_scaling"]:
                X_data = self.X_train_scaled
            else:
                X_data = self.X_train_balanced

            # Generate learning curves
            train_sizes, train_scores, val_scores = learning_curve(
                model, X_data, self.y_train_balanced,
                cv=3, n_jobs=-1,
                train_sizes=np.linspace(0.1, 1.0, 8),
                scoring="accuracy",
            )

            train_mean = np.mean(train_scores, axis=1)
            train_std  = np.std(train_scores, axis=1)
            val_mean   = np.mean(val_scores, axis=1)
            val_std    = np.std(val_scores, axis=1)

            axes[i].plot(train_sizes, train_mean, "o-", color="blue", label="Training")
            axes[i].fill_between(
                train_sizes, train_mean - train_std, train_mean + train_std,
                alpha=0.1, color="blue")

            axes[i].plot(train_sizes, val_mean, "o-", color="red", label="Validation")
            axes[i].fill_between(
                train_sizes, val_mean - val_std, val_mean + val_std,
                alpha=0.1, color="red")

            axes[i].set_title(f"{model_name}")
            axes[i].set_xlabel("Training Set Size")
            axes[i].set_ylabel("Accuracy")
            axes[i].legend()
            axes[i].grid(True, alpha=0.3)

        plt.tight_layout()
        self._savefig("learning_curves.png")

    # ==================================================================
    # 16. Performance radar chart
    # ==================================================================
    def create_performance_radar(self):
        """Create radar chart comparing all models"""
        print("\n16. Creating performance radar chart...")

        # Prepare data
        metrics = ["Accuracy", "Precision", "Recall", "F1_Score", "AUC"]
        models  = self.metrics_df["Model"].tolist()

        # Number of variables
        N      = len(metrics)
        angles = [n / float(N) * 2 * pi for n in range(N)]
        angles += angles[:1]  # Complete the circle

        fig, ax = plt.subplots(figsize=(10, 10),
                               subplot_kw=dict(projection="polar"))

        colors = ["red", "blue", "green", "orange", "purple"]

        for i, model in enumerate(models):
            model_data = self.metrics_df[self.metrics_df["Model"] == model]
            values     = [model_data[metric].iloc[0] for metric in metrics]
            values    += values[:1]  # Complete the circle

            ax.plot(angles, values, "o-", linewidth=2,
                    label=model, color=colors[i % len(colors)])
            ax.fill(angles, values, alpha=0.25, color=colors[i % len(colors)])

        ax.set_xticks(angles[:-1])
        ax.set_xticklabels(metrics)
        ax.set_ylim(0, 1)
        ax.set_title("Model Performance Comparison (Radar Chart)", size=16, pad=20)
        ax.legend(loc="upper right", bbox_to_anchor=(0.1, 0.1))
        ax.grid(True)

        self._savefig("performance_radar.png")

    # ==================================================================
    # 17. Feature distributions
    # ==================================================================
    def analyze_feature_distributions(self):
        """Analyze feature value distributions across cell types"""
        print("\n17. Creating feature distribution analysis...")

        # Get top features from Random Forest
        rf_model         = self.results["Random Forest"]["model"]
        top_features_idx = np.argsort(rf_model.feature_importances_)[-6:]  # Top 6 features
        top_features     = self.X_train_balanced.columns[top_features_idx]

        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        axes = axes.flatten()

        for i, feature in enumerate(top_features):
            # Create DataFrame for plotting
            plot_data = pd.DataFrame({
                "Feature_Value": self.X_train_balanced[feature],
                "Cell_Type":     [self.class_names[y] for y in self.y_train_balanced],
            })

            # Create violin plot
            sns.violinplot(data=plot_data, x="Cell_Type",
                           y="Feature_Value", ax=axes[i])
            axes[i].set_title(f"{feature}")
            axes[i].tick_params(axis="x", rotation=45)

        plt.tight_layout()
        self._savefig("feature_distributions.png")

    # ==================================================================
    # 18. Class separation plot  (original prints "19." — kept identical)
    # ==================================================================
    def create_class_separation_plot(self):
        """Create PCA plot showing class separation"""
        print("\n19. Creating class separation visualization...")

        from sklearn.decomposition import PCA

        # Apply PCA
        pca   = PCA(n_components=2)
        X_pca = pca.fit_transform(self.X_train_balanced)

        # Create DataFrame for plotting
        pca_df = pd.DataFrame({
            "PC1":       X_pca[:, 0],
            "PC2":       X_pca[:, 1],
            "Cell_Type": [self.class_names[y] for y in self.y_train_balanced],
        })

        plt.figure(figsize=(12, 8))

        # Create scatter plot
        for cell_type in self.class_names:
            mask = pca_df["Cell_Type"] == cell_type
            plt.scatter(pca_df[mask]["PC1"], pca_df[mask]["PC2"],
                        label=cell_type, alpha=0.6, s=50)

        plt.xlabel(f"PC1 ({pca.explained_variance_ratio_[0]:.1%} variance)")
        plt.ylabel(f"PC2 ({pca.explained_variance_ratio_[1]:.1%} variance)")
        plt.title("Cell Type Separation in PCA Space")
        plt.legend(bbox_to_anchor=(1.05, 1), loc="upper left")
        plt.grid(True, alpha=0.3)

        plt.tight_layout()
        self._savefig("class_separation_pca.png")

    # ==================================================================
    # 19. TF network  (original prints "20." — kept identical)
    # ==================================================================
    def create_basic_tf_network(self):
        """Create a basic transcription factor network using feature importance"""
        print("\n20. Creating basic TF network...")

        # Get top features from Random Forest (assuming these might be TFs)
        rf_model         = self.results["Random Forest"]["model"]
        top_features_idx = np.argsort(rf_model.feature_importances_)[-15:]  # Top 15 features
        top_features     = self.X_train_balanced.columns[top_features_idx].tolist()

        # Calculate correlations between top features
        feature_data       = self.X_train_balanced[top_features]
        correlation_matrix = feature_data.corr()

        # Create network graph
        G = nx.Graph()

        # Add nodes (features as potential TFs)
        for feature in top_features:
            G.add_node(feature, node_type="feature")

        # Add cell type nodes
        for cell_type in self.class_names:
            G.add_node(cell_type, node_type="cell_type")

        # Add edges between highly correlated features (correlation > 0.5)
        for i, feature1 in enumerate(top_features):
            for j, feature2 in enumerate(top_features):
                if i < j:  # Avoid duplicate edges
                    corr = correlation_matrix.loc[feature1, feature2]
                    if abs(corr) > 0.5:  # Strong correlation
                        G.add_edge(feature1, feature2,
                                   weight=abs(corr), edge_type="feature-feature")

        # Add edges between features and cell types based on mean expression
        for feature in top_features:
            for class_idx, cell_type in enumerate(self.class_names):
                # Calculate mean expression of this feature in this cell type
                cell_mask = self.y_train_balanced == class_idx
                if cell_mask.sum() > 0:  # Make sure we have cells of this type
                    mean_expr    = self.X_train_balanced.loc[cell_mask, feature].mean()
                    overall_mean = self.X_train_balanced[feature].mean()

                    # If expression is significantly higher than average, add edge
                    if mean_expr > overall_mean + self.X_train_balanced[feature].std():
                        G.add_edge(feature, cell_type,
                                   weight=mean_expr, edge_type="feature-celltype")

        # Create visualization
        plt.figure(figsize=(14, 10))

        # Position nodes using spring layout
        pos = nx.spring_layout(G, k=2, iterations=50)

        # Draw nodes
        feature_nodes  = [node for node, data in G.nodes(data=True)
                          if data["node_type"] == "feature"]
        celltype_nodes = [node for node, data in G.nodes(data=True)
                          if data["node_type"] == "cell_type"]

        nx.draw_networkx_nodes(G, pos, nodelist=feature_nodes,
                               node_color="lightblue", node_size=300,
                               alpha=0.8, label="Features")
        nx.draw_networkx_nodes(G, pos, nodelist=celltype_nodes,
                               node_color="lightcoral", node_size=500,
                               alpha=0.8, label="Cell Types")

        # Draw edges
        feature_edges  = [(u, v) for u, v, data in G.edges(data=True)
                          if data["edge_type"] == "feature-feature"]
        celltype_edges = [(u, v) for u, v, data in G.edges(data=True)
                          if data["edge_type"] == "feature-celltype"]

        nx.draw_networkx_edges(G, pos, edgelist=feature_edges,
                               edge_color="gray", alpha=0.5,
                               width=1, style="dashed")
        nx.draw_networkx_edges(G, pos, edgelist=celltype_edges,
                               edge_color="red", alpha=0.7, width=2)

        # Draw labels
        labels = {}
        for node in G.nodes():
            if len(node) > 10:
                labels[node] = node[:10] + "..."
            else:
                labels[node] = node

        nx.draw_networkx_labels(G, pos, labels, font_size=8)

        plt.title("Feature-Cell Type Network")
        plt.legend()
        plt.axis("off")
        plt.tight_layout()
        self._savefig("basic_tf_network.png")

        # Print network statistics
        print(f"  Network created with {G.number_of_nodes()} nodes and {G.number_of_edges()} edges")
        print(f"  Features: {len(feature_nodes)}")
        print(f"  Cell types: {len(celltype_nodes)}")

        return G

    # ==================================================================
    # Master runner — exact same steps order as original
    # ==================================================================
    def run_complete_pipeline(self):
        """Execute the pipeline  .."""
        print("=== Starting Complete ML Pipeline ===")

        # Execute all steps — exact same order as original
        steps = [
            self.load_data,
            self.analyze_class_imbalance,
            self.feature_engineering,
            self.prepare_train_test_split,
            self.handle_class_imbalance,
            self.scale_features,
            self.define_models,
            self.train_and_evaluate_models,
            self.calculate_metrics,
            self.create_detailed_evaluation_table,
            self.create_visualizations,
            self.detect_overfitting,
            self.generate_final_report,
            self.simple_feature_heatmap,
            self.create_learning_curves,
            self.create_performance_radar,
            self.analyze_feature_distributions,
            self.create_class_separation_plot,
            self.create_basic_tf_network,
        ]

        for i, step in enumerate(steps, 1):
            try:
                step()
                print(f" Step {i}/{len(steps)} completed successfully")
            except Exception as e:
                print(f" Step {i}/{len(steps)} failed: {e}")
                return False

        print("\n Pipeline Completed Successfully ...! ===")
        return True
