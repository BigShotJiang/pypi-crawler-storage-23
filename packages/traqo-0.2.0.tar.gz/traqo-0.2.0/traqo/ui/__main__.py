"""Allow running as: python -m traqo.ui [traces_dir] [--port PORT]"""

from traqo.ui.server import main

main()
