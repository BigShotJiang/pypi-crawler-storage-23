"""
GenomeMCP CLI - Research-Grade Genomic Intelligence Interface

A beautiful command-line interface for GenomeMCP's genomic analysis tools.
"""

__version__ = "0.1.0"
