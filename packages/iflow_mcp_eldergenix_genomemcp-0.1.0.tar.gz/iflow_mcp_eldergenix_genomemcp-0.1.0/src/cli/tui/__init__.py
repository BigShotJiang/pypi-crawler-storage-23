"""Textual TUI application for GenomeMCP."""
