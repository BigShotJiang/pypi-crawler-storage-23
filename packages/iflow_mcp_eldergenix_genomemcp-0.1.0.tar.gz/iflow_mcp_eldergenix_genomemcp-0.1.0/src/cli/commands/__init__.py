"""Command groups for GenomeMCP CLI."""
