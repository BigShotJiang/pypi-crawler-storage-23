import pandas as pd
from scipy import stats
from metrics_miscellany import tests
import numpy as np

def main():

    labels = ['a','b']
    D = pd.DataFrame([[2,1],[2,2]],index=labels,columns=labels)
    D.index.name = 'Variable'
    D.columns.name = 'Variable'

    V = D.T@D

    b = pd.DataFrame(stats.multivariate_normal(cov=V).rvs(),index=labels)
    b.index.name = 'Variable'

    return tests.chi2_test(b,V,"Variable in ['a']")

def test_chi2():
    p = []
    m = 1000
    for i in range(m):
        p.append(main()[1])

    p = pd.Series([x[0][0] for x in p]).squeeze()

    X = np.linspace(.05,.95,10)
    assert np.linalg.norm(p.quantile(X) - X)/len(X) < 1e-1

if __name__ == '__main__':
    test_chi2()
