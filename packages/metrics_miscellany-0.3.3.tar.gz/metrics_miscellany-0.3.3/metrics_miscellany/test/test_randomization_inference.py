import pandas as pd
import scipy.stats.distributions as dists
from metrics_miscellany import estimators, tests
import matplotlib.pyplot as plt

n=1000
p = 0.5
# Generate contextual variables; probability of being female is p
C = pd.DataFrame({'Female':dists.binom(1,p).rvs(size=n)})
C['Male'] = 1-C

delta = pd.Series({"Female":1.,"Male":0.5})

T1 = pd.Series(dists.norm.rvs(size=n),name='Treatment1')
T2 = pd.Series(dists.norm.rvs(size=n),name='Treatment2')

# Interactions:
TC = C.multiply(T1,axis=0)
TC.columns = ['TxFemale','TxMale']

# Construct RHS matrix
X = pd.concat([T1,T2,C,TC],axis=1).iloc[:,:-1]
dC = C@delta

# Generate outcome y with *no* treatment effect, to look for Type I errors
epsilon= pd.Series(dists.norm.rvs(size=n),name='epsilon')

Y = dC + epsilon
Y.name = 'outcome'

p_i = tests.randomization_inference(['Treatment1'],X,Y,VERBOSE=False)

# Generate outcome y with uniform treatment effect, to look for Type II errors
epsilon= pd.Series(dists.norm.rvs(size=n),name='epsilon')

Y = T1 + T2 + dC + epsilon
Y.name = 'outcome'

p_ii = tests.randomization_inference(['Treatment1'],X,Y,VERBOSE=False)

# Test Treatment1 == Treatment2
R = pd.DataFrame({'Coefficients':[1,-1]},index=['Treatment1','Treatment2'])

p_iii = tests.randomization_inference(['Treatment1','Treatment2'],X.drop('TxFemale',axis=1),Y,R=R,VERBOSE=True)
