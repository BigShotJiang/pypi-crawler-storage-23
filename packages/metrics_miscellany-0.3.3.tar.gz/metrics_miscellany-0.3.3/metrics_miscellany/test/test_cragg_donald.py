"""Check size of cragg_donald reduced rank test.
"""
import datamat as dm
from metrics_miscellany.tests import cragg_donald
from scipy.stats.distributions import norm, chi2
import numpy as np

def test_size(n=1000,m=8,l=10,tol=1e-4):
    Pi = norm.rvs(size=(l,m))
    Z = dm.DataMat(norm.rvs(size=(n,l)))

    its = 0
    laststat = -1
    stat = 0
    Stats = []
    Ps = []
    while its<=30 or np.abs(stat-laststat)>tol:
        its += 1
        laststat = stat
        U = dm.DataMat(norm.rvs(size=(n,m)))
        X = Z@Pi + U
        s,p = cragg_donald(X,Z)
        Stats.append(s)
        Ps.append(p)
        stat = p/its + stat*(its-1)/its
        if its % 12 == 1:
            print(f"Iteration {its}, alpha={stat:4.4f}")
