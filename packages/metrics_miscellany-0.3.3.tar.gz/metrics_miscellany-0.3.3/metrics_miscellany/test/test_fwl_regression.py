import datamat as dm
from metrics_miscellany.estimators import fwl_regression
import numpy as np

N = 100

D = {}
D['Constant'] = dm.DataMat(np.ones(N))
D['a'] = dm.DataMat(np.random.randn(N,2))
D['b'] = D['a']*2 + np.random.randn(N,2)
D['y'] = dm.DataMat(D['a']@np.array((1,1)) + + D['b']@np.array((2,2)) + np.random.randn(N,)/1000,name='y')

# Reverse order of dict
D = dict([D.popitem() for i in range(len(D))])

U,B = fwl_regression(D)
