from metrics_miscellany.utils import dummies, use_indices
import pandas as pd

def test_dummies():
    idx = pd.MultiIndex.from_tuples([(i,) for i in range(4)],names=['i'])
    foo = pd.DataFrame({'cat':['a','b','b','c']},index=idx)

    assert dummies(foo,['i']).shape == (4,4)
    assert dummies(foo,['cat']).shape == (4,3)

if __name__=='__main__':
    test_dummies()
