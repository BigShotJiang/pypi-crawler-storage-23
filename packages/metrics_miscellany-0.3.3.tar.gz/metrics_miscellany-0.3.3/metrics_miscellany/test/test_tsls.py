import pandas as pd
from metrics_miscellany.estimators import tsls, ols, restricted_tsls
from datamat import DataMat, DataVec
import numpy as np

def test_tsls(N=500000,tol=1e-2):

    z = DataMat({'z':np.random.standard_normal((N,))})
    u = DataVec(np.random.standard_normal((N,)))
    x = DataMat({'x':z.squeeze() + u})

    x['Constant'] = 1
    z['Constant'] = 1

    beta = DataMat({'Coefficients':[1,0]},index=['x','Constant'])

    y = (x@beta).squeeze() + u

    b,Omega,V = restricted_tsls(y,x,Z=z)
    b_,V_ = tsls(x,y,z)
    #b,V = ols(x,y)

    assert np.allclose(b,beta.squeeze(),atol=tol)

    #return b,V,b_,V_

if __name__=='__main__':
    test_tsls()
