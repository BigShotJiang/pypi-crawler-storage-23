import numpy as np
import pandas as pd
from metrics_miscellany import random

T = pd.Series(np.random.rand(10)>.5)

df = pd.DataFrame({'a':T,'b':T}).stack()
df = df + 0
df.index.names = ['i','t']

p = random.permutation(df,permute_levels=['i'])

assert np.all(p.unstack('t').std(axis=1)==0)
