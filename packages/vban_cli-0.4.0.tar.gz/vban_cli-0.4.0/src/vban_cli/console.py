from rich.console import Console

out = Console()
err = Console(stderr=True)
