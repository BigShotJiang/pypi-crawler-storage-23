# SeverityType


## Enum

* `CRITICAL` (value: `'CRITICAL'`)

* `HIGH` (value: `'HIGH'`)

* `MEDIUM` (value: `'MEDIUM'`)

* `LOW` (value: `'LOW'`)

* `INFO` (value: `'INFO'`)

* `NONE` (value: `'NONE'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


