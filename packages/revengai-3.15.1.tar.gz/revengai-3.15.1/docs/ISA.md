# ISA


## Enum

* `X86` (value: `'x86'`)

* `X86_64` (value: `'x86_64'`)

* `ARM` (value: `'arm'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


