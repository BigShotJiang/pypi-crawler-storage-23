# AppApiRestV2CollectionsEnumsOrderBy


## Enum

* `CREATED` (value: `'created'`)

* `COLLECTION` (value: `'collection'`)

* `MODEL` (value: `'model'`)

* `OWNER` (value: `'owner'`)

* `COLLECTION_SIZE` (value: `'collection_size'`)

* `UPDATED` (value: `'updated'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


