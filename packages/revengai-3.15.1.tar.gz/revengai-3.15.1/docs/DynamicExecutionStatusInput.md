# DynamicExecutionStatusInput

Custom enum for the dynamic execution status

## Enum

* `PENDING` (value: `'PENDING'`)

* `ERROR` (value: `'ERROR'`)

* `SUCCESS` (value: `'SUCCESS'`)

* `ALL` (value: `'ALL'`)

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


