# Addr


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------

## Example

```python
from revengai.models.addr import Addr

# TODO update the JSON string below
json = "{}"
# create an instance of Addr from a JSON string
addr_instance = Addr.from_json(json)
# print the JSON string representation of the object
print(Addr.to_json())

# convert the object into a dict
addr_dict = addr_instance.to_dict()
# create an instance of Addr from a dict
addr_from_dict = Addr.from_dict(addr_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


