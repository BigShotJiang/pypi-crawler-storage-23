"""Prediction adapters for behavior prediction I/O."""

from jabs.io.internal.prediction.hdf5 import PredictionHDF5Adapter

__all__ = ["PredictionHDF5Adapter"]
