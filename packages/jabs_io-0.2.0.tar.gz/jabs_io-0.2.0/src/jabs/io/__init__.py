"""The root of the jabs.io package."""

from jabs.io import internal
from jabs.io.api import load, save

__all__ = [
    "load",
    "save",
]
