# jupyterlab_env_kernel

A JupyterLab extension to create env and kernel.

This extension is composed of a Python package named `jupyterlab_env_kernel`
for the server extension and a NPM package named `jupyterlab-env-kernel`
for the frontend extension.

## Requirements

- JupyterLab >= 4.0.0

## Install

To install the extension, execute:

```bash
pip install jupyterlab-env-kernel
```

## Uninstall

To remove the extension, execute:

```bash
pip uninstall jupyterlab_env_kernel
```

## Usage

### Opening the Panel

Click the `Conda Environments` icon in the left sidebar to open the **Conda Environment Manager** panel.

### Creating a Conda Environment and Kernel

1. **Environment Name** — Enter a unique name for your environment (e.g. `my-analysis`)
2. **Python Version** — Select the Python version from the dropdown (3.9, 3.10, 3.11, 3.12)
3. **Extra Packages** — Optionally enter comma-separated packages to install (e.g. `numpy, pandas, scikit-learn`)
4. Click **+ Create Environment & Kernel**

The extension will:

- Create a new conda environment using `mamba`
- Install `ipykernel` into the environment
- Register it as a Jupyter kernel automatically

⏳ Creation typically takes 1–2 minutes depending on the number of packages.

### Using the New Kernel

Once created, the kernel is immediately available:

1. Open a notebook (or create a new one)
2. Click the kernel selector in the top right
3. Select **Python (your-env-name)** from the list

> 💡 If you don't see the kernel yet, refresh the page or restart the kernel picker.

### Error Messages

| Message                             | Cause                                | Fix                                      |
| ----------------------------------- | ------------------------------------ | ---------------------------------------- |
| ⚠️ Environment 'x' already exists   | An env with that name already exists | Choose a different name                  |
| ❌ Please enter an environment name | Name field is empty                  | Enter a name before clicking create      |
| ❌ Error: ...                       | mamba failed                         | Check JupyterLab server logs for details |

### Checking Available Environments

You can verify your environments were created correctly from a terminal:

```bash
mamba env list
jupyter kernelspec list
```

## Troubleshoot

If you are seeing the frontend extension, but it is not working, check
that the server extension is enabled:

```bash
jupyter server extension list
```

If the server extension is installed and enabled, but you are not seeing
the frontend extension, check the frontend extension is installed:

```bash
jupyter labextension list
```

## Contributing

### Development install

Note: You will need NodeJS to build the extension package.

The `jlpm` command is JupyterLab's pinned version of
[yarn](https://yarnpkg.com/) that is installed with JupyterLab. You may use
`yarn` or `npm` in lieu of `jlpm` below.

```bash
# Clone the repo to your local environment
# Change directory to the jupyterlab_env_kernel directory

# Set up a virtual environment and install package in development mode
python -m venv .venv
source .venv/bin/activate
pip install --editable ".[dev,test]"

# Link your development version of the extension with JupyterLab
jupyter labextension develop . --overwrite
# Server extension must be manually installed in develop mode
jupyter server extension enable jupyterlab_env_kernel

# Rebuild extension Typescript source after making changes
# IMPORTANT: Unlike the steps above which are performed only once, do this step
# every time you make a change.
jlpm build
```

You can watch the source directory and run JupyterLab at the same time in different terminals to watch for changes in the extension's source and automatically rebuild the extension.

```bash
# Watch the source directory in one terminal, automatically rebuilding when needed
jlpm watch
# Run JupyterLab in another terminal
jupyter lab
```

With the watch command running, every saved change will immediately be built locally and available in your running JupyterLab. Refresh JupyterLab to load the change in your browser (you may need to wait several seconds for the extension to be rebuilt).

By default, the `jlpm build` command generates the source maps for this extension to make it easier to debug using the browser dev tools. To also generate source maps for the JupyterLab core extensions, you can run the following command:

```bash
jupyter lab build --minimize=False
```

### Development uninstall

```bash
# Server extension must be manually disabled in develop mode
jupyter server extension disable jupyterlab_env_kernel
pip uninstall jupyterlab_env_kernel
```

In development mode, you will also need to remove the symlink created by `jupyter labextension develop`
command. To find its location, you can run `jupyter labextension list` to figure out where the `labextensions`
folder is located. Then you can remove the symlink named `jupyterlab-env-kernel` within that folder.

### Testing the extension

#### Server tests

This extension is using [Pytest](https://docs.pytest.org/) for Python code testing.

Install test dependencies (needed only once):

```sh
pip install -e ".[test]"
# Each time you install the Python package, you need to restore the front-end extension link
jupyter labextension develop . --overwrite
```

To execute them, run:

```sh
pytest -vv -r ap --cov jupyterlab_env_kernel
```

#### Frontend tests

This extension is using [Jest](https://jestjs.io/) for JavaScript code testing.

To execute them, execute:

```sh
jlpm
jlpm test
```

#### Integration tests

This extension uses [Playwright](https://playwright.dev/docs/intro) for the integration tests (aka user level tests).
More precisely, the JupyterLab helper [Galata](https://github.com/jupyterlab/jupyterlab/tree/master/galata) is used to handle testing the extension in JupyterLab.

More information are provided within the [ui-tests](./ui-tests/README.md) README.

### Packaging the extension

See [RELEASE](RELEASE.md)
