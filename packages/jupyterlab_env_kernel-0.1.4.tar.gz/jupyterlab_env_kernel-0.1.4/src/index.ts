import {
  JupyterFrontEnd,
  JupyterFrontEndPlugin,
  ILayoutRestorer
} from '@jupyterlab/application';
import { ICommandPalette } from '@jupyterlab/apputils';

import { CondaPanel } from './panel';

const plugin: JupyterFrontEndPlugin<void> = {
  id: 'jupyterlab-env-kernel:plugin',
  autoStart: true,
  requires: [ICommandPalette, ILayoutRestorer],

  activate: (
    app: JupyterFrontEnd,
    palette: ICommandPalette,
    restorer: ILayoutRestorer
  ) => {
    console.log('JupyterLab extension jupyterlab-env-kernel is activated!');
    const panel = new CondaPanel();
    panel.id = 'conda-panel';
    panel.title.iconClass = 'jp-CondaIcon jp-SideBar-tabIcon';
    panel.title.caption = 'Conda Environments';

    // Add to left sidebar
    app.shell.add(panel, 'left', { rank: 200 });

    // Restore on page reload
    restorer.add(panel, 'conda-panel');

    // Add command palette entry
    app.commands.addCommand('conda-panel:open', {
      label: 'Open Conda Panel',
      execute: () => app.shell.activateById(panel.id)
    });
    palette.addItem({ command: 'conda-panel:open', category: 'Conda' });
  }
};

export default plugin;
