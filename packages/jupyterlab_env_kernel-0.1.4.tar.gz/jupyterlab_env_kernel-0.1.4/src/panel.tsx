import React, { useState } from 'react';
import { ReactWidget } from '@jupyterlab/apputils';
import { createEnv } from './api';

function CondaWidget(): JSX.Element {
  const [envName, setEnvName] = useState('');
  const [pythonVersion, setPythonVersion] = useState('3.10');
  const [packages, setPackages] = useState('');
  const [status, setStatus] = useState('');
  const [loading, setLoading] = useState(false);

  const handleCreate = async () => {
    if (!envName) {
      setStatus('❌ Please enter an environment name.');
      return;
    }
    setLoading(true);
    setStatus('⏳ Creating environment...');
    try {
      const pkgList = packages
        .split(',')
        .map(p => p.trim())
        .filter(Boolean);
      const result = await createEnv(envName, pythonVersion, pkgList);
      setStatus(
        `✅ Created env "${result.env_name}" with kernel "${result.kernel_name}"`
      );
    } catch (err: any) {
      setStatus(`❌ Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="jp-CondaPanel" style={{ padding: '16px' }}>
      <h2 style={{ fontSize: '14px', fontWeight: 600 }}>
        Create Conda Environment
      </h2>

      <label>Environment Name</label>
      <input
        className="jp-mod-styled"
        value={envName}
        onChange={e => setEnvName(e.target.value)}
        placeholder="my-env"
        style={{ width: '100%', marginBottom: '8px' }}
      />

      <label>Python Version</label>
      <select
        className="jp-mod-styled"
        value={pythonVersion}
        onChange={e => setPythonVersion(e.target.value)}
        style={{ width: '100%', marginBottom: '8px' }}
      >
        <option value="3.9">3.9</option>
        <option value="3.10">3.10</option>
        <option value="3.11">3.11</option>
        <option value="3.12">3.12</option>
      </select>

      <label>Extra Packages (comma-separated)</label>
      <input
        className="jp-mod-styled"
        value={packages}
        onChange={e => setPackages(e.target.value)}
        placeholder="numpy, pandas, scikit-learn"
        style={{ width: '100%', marginBottom: '12px' }}
      />

      <button
        className="jp-mod-accept jp-Button"
        onClick={handleCreate}
        disabled={loading}
        style={{ width: '100%' }}
      >
        {loading ? 'Creating...' : '+ Create Environment & Kernel'}
      </button>

      {status && (
        <p
          style={{
            marginTop: '12px',
            fontSize: '12px',
            wordBreak: 'break-word'
          }}
        >
          {status}
        </p>
      )}
    </div>
  );
}

export class CondaPanel extends ReactWidget {
  render(): JSX.Element {
    return <CondaWidget />;
  }
}
