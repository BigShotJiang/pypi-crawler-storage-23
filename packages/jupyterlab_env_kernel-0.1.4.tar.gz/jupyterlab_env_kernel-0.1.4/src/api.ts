//import { requestAPI } from '@jupyterlab/services';

// If using JupyterLab 4.x, use fetch directly:
const BASE = '/jupyterlab-env-kernel';

export async function createEnv(
  env_name: string,
  python_version: string,
  packages: string[]
): Promise<{ env_name: string; kernel_name: string }> {
  // Get XSRF token from cookie — required for POST requests
  const xsrfToken =
    document.cookie
      .split('; ')
      .find(row => row.startsWith('_xsrf='))
      ?.split('=')[1] ?? '';

  const response = await fetch(`${BASE}/create-env`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-XSRFToken': xsrfToken // <-- this is the key fix
    },
    body: JSON.stringify({ env_name, python_version, packages })
  });
  if (!response.ok) {
    const err = await response.json();
    throw new Error(err.error || 'Unknown error');
  }
  return response.json();
}

export async function listEnvs(): Promise<string[]> {
  const response = await fetch(`${BASE}/list-envs`);
  const data = await response.json();
  return data.envs;
}
