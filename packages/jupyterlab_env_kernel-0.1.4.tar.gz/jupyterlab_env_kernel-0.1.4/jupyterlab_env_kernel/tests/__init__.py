"""Python unit tests for jupyterlab_env_kernel."""
