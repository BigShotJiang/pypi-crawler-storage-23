import json
from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
import tornado
import asyncio


async def run_command(cmd: list[str]) -> tuple[int, str, str]:
    """Run a command asynchronously without blocking the event loop."""
    process = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    stdout, stderr = await process.communicate()
    return process.returncode, stdout.decode(), stderr.decode()


class CreateEnvHandler(APIHandler):
    @tornado.web.authenticated
    async def post(self):
        body = self.get_json_body()
        env_name = body.get("env_name", "").strip()
        python_version = body.get("python_version", "3.10")
        packages = body.get("packages", [])

        self.log.info(
            f"[create-env] Request received: env_name={env_name}, python={python_version}, packages={packages}"
        )

        if not env_name:
            self.log.warning("[create-env] Rejected: env_name is empty")
            self.set_status(400)
            self.finish(json.dumps({"error": "env_name is required"}))
            return

        # Check if env already exists
        self.log.info(f"[create-env] Checking if env '{env_name}' already exists")
        rc, stdout, stderr = await run_command(["mamba", "env", "list", "--json"])
        if rc != 0:
            self.log.error(f"[create-env] Failed to list envs: {stderr}")
            self.set_status(500)
            self.finish(json.dumps({"error": f"Failed to list environments: {stderr}"}))
            return

        existing_envs = [
            env.split("/")[-1] for env in json.loads(stdout).get("envs", [])
        ]
        self.log.info(f"[create-env] Existing envs: {existing_envs}")

        if env_name in existing_envs:
            self.log.warning(f"[create-env] Env '{env_name}' already exists")
            self.set_status(409)
            self.finish(
                json.dumps({"error": f"Environment '{env_name}' already exists"})
            )
            return

        try:
            # Step 1: Create mamba environment
            mamba_cmd = [
                "mamba",
                "create",
                "-n",
                env_name,
                f"python={python_version}",
                "ipykernel",
                "-y",
            ] + packages

            self.log.info(f"[create-env] Running: {' '.join(mamba_cmd)}")
            rc, stdout, stderr = await run_command(mamba_cmd)
            self.log.debug(f"[create-env] mamba stdout: {stdout}")
            self.log.debug(f"[create-env] mamba stderr: {stderr}")

            if rc != 0:
                self.log.error(f"[create-env] mamba create failed (rc={rc}): {stderr}")
                raise RuntimeError(stderr)

            self.log.info(f"[create-env] mamba env '{env_name}' created successfully")

            # Step 2: Register the kernel with Jupyter
            kernel_cmd = [
                "mamba",
                "run",
                "-n",
                env_name,
                "python",
                "-m",
                "ipykernel",
                "install",
                "--user",
                "--name",
                env_name,
                "--display-name",
                f"Python ({env_name})",
            ]

            self.log.info(f"[create-env] Registering kernel: {' '.join(kernel_cmd)}")
            rc2, stdout2, stderr2 = await run_command(kernel_cmd)
            self.log.debug(f"[create-env] ipykernel stdout: {stdout2}")
            self.log.debug(f"[create-env] ipykernel stderr: {stderr2}")

            if rc2 != 0:
                self.log.error(
                    f"[create-env] ipykernel install failed (rc={rc2}): {stderr2}"
                )
                raise RuntimeError(stderr2)

            self.log.info(f"[create-env] Kernel '{env_name}' registered successfully")
            self.finish(
                json.dumps(
                    {"status": "ok", "env_name": env_name, "kernel_name": env_name}
                )
            )

        except Exception as e:
            self.log.exception(f"[create-env] Unexpected error: {e}")
            self.set_status(500)
            self.finish(json.dumps({"error": str(e)}))


class ListEnvsHandler(APIHandler):
    @tornado.web.authenticated
    async def get(self):
        self.log.info("[list-envs] Request received")
        rc, stdout, stderr = await run_command(["mamba", "env", "list", "--json"])
        self.log.debug(f"[list-envs] Output: {stdout}")
        data = json.loads(stdout)
        envs = [env.split("/")[-1] for env in data.get("envs", [])]
        self.log.info(f"[list-envs] Found {len(envs)} environments: {envs}")
        self.finish(json.dumps({"envs": envs}))


def setup_handlers(web_app):
    host_pattern = ".*$"
    base_url = web_app.settings["base_url"]
    route_pattern_create = url_path_join(
        base_url, "jupyterlab-env-kernel", "create-env"
    )
    route_pattern_list = url_path_join(base_url, "jupyterlab-env-kernel", "list-envs")
    handlers = [
        (route_pattern_create, CreateEnvHandler),
        (route_pattern_list, ListEnvsHandler),
    ]
    web_app.add_handlers(host_pattern, handlers)
