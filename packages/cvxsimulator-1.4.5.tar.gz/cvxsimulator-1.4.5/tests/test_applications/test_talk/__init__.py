"""Test the implementation of notebooks from the CS repository.

This package contains tests for the notebook implementations found in
the CS repository at https://github.com/tschm/cs.
"""
