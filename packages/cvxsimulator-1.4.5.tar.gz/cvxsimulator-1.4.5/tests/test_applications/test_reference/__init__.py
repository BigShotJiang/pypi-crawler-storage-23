"""Test the Markowitz reference implementation.

This package contains tests for the Markowitz portfolio optimization reference
implementation found at https://github.com/cvxgrp/markowitz-reference.
"""
