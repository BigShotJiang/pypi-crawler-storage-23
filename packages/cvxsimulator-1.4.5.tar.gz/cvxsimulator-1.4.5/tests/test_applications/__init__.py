"""Test applications for the talk and reference implementations.

This package contains test modules for the talk and reference implementations
of various portfolio optimization strategies and applications.
"""
