"""dtu-env: DTU course environment manager."""

__version__ = "1.1.1"
