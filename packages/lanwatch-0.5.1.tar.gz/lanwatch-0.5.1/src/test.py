import curses

def scrolling_pad_example(stdscr):
    curses.curs_set(0)
    stdscr.clear()
    stdscr.nodelay(0)  # Blocking input
    
    max_y, max_x = stdscr.getmaxyx()
    
    # Create a large pad
    pad_height = 200
    pad_width = max_x - 10
    pad = curses.newpad(pad_height, pad_width)
    
    # Fill with numbered lines
    for i in range(pad_height):
        line = f"{i:3d}: " + "X" * (pad_width - 10) + "END"
        pad.addstr(i, 0, line)
    
    # Scrolling variables
    scroll_pos = 0
    visible_height = max_y - 4
    
    while True:
        # Clear and show instructions
        stdscr.clear()
        stdscr.addstr(0, 0, "SCROLLING PAD EXAMPLE")
        stdscr.addstr(1, 0, f"Showing lines {scroll_pos+1}-{scroll_pos+visible_height}")
        stdscr.addstr(2, 0, "↑/↓ to scroll • q to quit")
        stdscr.refresh()
        
        # Show pad portion
        pad.refresh(scroll_pos, 0, 3, 2, visible_height, pad_width)
        
        # Handle input
        key = stdscr.getch()
        if key == ord('q'):
            break
        elif key == curses.KEY_UP and scroll_pos > 0:
            scroll_pos -= 1
        elif key == curses.KEY_DOWN and scroll_pos < pad_height - visible_height:
            scroll_pos += 1

curses.wrapper(scrolling_pad_example)