import subprocess, shlex, re, datetime

import sql_client

def scan_lan() -> list:
    """Scan lan and return extracted ips and hosts"""
    nmap_command = "nmap -sn 192.168.1.0/24"
    #nmap_command = ["nmap", "--noninteractive", "-s", "-n", "192.168.1.0/24"]

    args = shlex.split(nmap_command)
    stdout = subprocess.check_output(args, text=True)

    extract_expression = r"Nmap scan report for ([a-zA-Z.]+) \(([\d.]+)\)"
    result = re.findall(extract_expression, stdout)

    return result

def scan_store_db() -> list:
    """Scan lan and store output to database"""
    result = scan_lan()

    date_now = datetime.datetime.now().strftime("%H:%M-%d/%m/%Y")

    for element in result:
        host = element[0]
        ip = element[1]
        sql_client.store_registry(ip, host, date_now)

    return result


if __name__ == "__main__":
    res = scan_lan()
    print(res)
