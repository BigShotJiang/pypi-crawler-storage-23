#!/bin/bash
exec cloak hook session-end
