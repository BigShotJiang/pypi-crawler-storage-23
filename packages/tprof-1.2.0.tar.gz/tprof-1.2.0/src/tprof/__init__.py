from __future__ import annotations

from tprof.api import tprof

__all__ = ("tprof",)
