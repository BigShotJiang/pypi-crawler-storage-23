from __future__ import annotations

from tprof.main import main

if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
