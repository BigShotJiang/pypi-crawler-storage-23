/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: SPART_C_data.h
 *
 * MATLAB Coder version            : 25.1
 * C/C++ source code generated on  : 24-Feb-2026 15:36:29
 */

#ifndef SPART_C_DATA_H
#define SPART_C_DATA_H

/* Include Files */
#include "rtwtypes.h"
#include "omp.h"
#include <stddef.h>
#include <stdlib.h>

/* Variable Declarations */
extern omp_nest_lock_t SPART_C_nestLockGlobal;
extern const signed char iv[9];
extern boolean_T isInitialized_SPART_C;

#endif
/*
 * File trailer for SPART_C_data.h
 *
 * [EOF]
 */
