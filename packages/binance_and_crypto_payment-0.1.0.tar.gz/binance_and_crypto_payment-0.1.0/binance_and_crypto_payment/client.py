from .request import CryptoPaymentRequest

class CryptoPaymentClient(CryptoPaymentRequest):
    pass
