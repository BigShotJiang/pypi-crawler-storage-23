"""Package entrypoint for `python -m crabpath`."""

from .cli import main
import sys

if __name__ == "__main__":
    sys.exit(main())
