//! Persistent list backed by crate::collections::Vector
//!
//! Provides a list-shaped API for Clojure compatibility, but internally uses
//! a persistent vector for storage and traversal.

use crate::collections::Vector;

use crate::Value;

/// A persistent list backed by an immutable vector
#[derive(Debug, Clone, Default)]
pub struct List(Vector<Value>);

impl List {
    /// Create a new list by cons-ing a head onto a tail.
    pub fn cons(head: Value, mut tail: List) -> Self {
        tail.0.push_front(head);
        tail
    }

    /// Create from an iterator
    pub fn from_iter(iter: impl IntoIterator<Item = Value>) -> Self {
        List(iter.into_iter().collect())
    }

    /// Get the first element
    pub fn first(&self) -> Option<&Value> {
        self.0.front()
    }

    /// Get the rest of the list (tail)
    pub fn rest(&self) -> List {
        if self.0.is_empty() {
            return List::default();
        }
        let mut vec = self.0.clone();
        let tail = vec.split_off(1);
        List(tail)
    }

    /// Return the tail as a vector for internal consumers.
    pub fn tail_vector(&self) -> Vector<Value> {
        if self.0.is_empty() {
            return Vector::new();
        }
        let mut vec = self.0.clone();
        vec.split_off(1)
    }

    /// Check if empty
    pub fn is_empty(&self) -> bool {
        self.0.is_empty()
    }

    /// Count elements (O(1))
    pub fn len(&self) -> usize {
        self.0.len()
    }

    /// Iterate over elements
    pub fn iter(&self) -> impl Iterator<Item = &Value> {
        self.0.iter()
    }

    /// Get the underlying vector (for efficient access without copying)
    pub fn as_vector(&self) -> &Vector<Value> {
        &self.0
    }

    /// Get args (everything after the first element) as a Vec
    /// This is O(n) but only done once per list evaluation
    pub fn args_vec(&self) -> Vec<Value> {
        if self.0.len() <= 1 {
            Vec::new()
        } else {
            self.0.iter().skip(1).cloned().collect()
        }
    }
}
