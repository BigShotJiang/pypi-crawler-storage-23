//! Source location tracking for error reporting
//!
//! Every Value can optionally carry a Span indicating where it came from
//! in the source. This enables ariadne to show precise error locations.

use lasso::Spur;

/// A span in source code (byte offsets + line/column + optional source identifier)
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Span {
    pub start: usize,
    pub end: usize,
    /// 0-indexed line number of start position
    pub line: usize,
    /// 0-indexed column number of start position
    pub col: usize,
    /// Interned source file name or identifier (e.g., "foo.clj", "<repl>", "<eval>")
    pub source_id: Option<Spur>,
}

impl Span {
    pub fn new(start: usize, end: usize) -> Self {
        Self {
            start,
            end,
            line: 0,
            col: 0,
            source_id: None,
        }
    }

    pub fn with_location(start: usize, end: usize, line: usize, col: usize) -> Self {
        Self {
            start,
            end,
            line,
            col,
            source_id: None,
        }
    }

    pub fn with_source(
        start: usize,
        end: usize,
        line: usize,
        col: usize,
        source_id: Option<Spur>,
    ) -> Self {
        Self {
            start,
            end,
            line,
            col,
            source_id,
        }
    }

    pub fn point(pos: usize) -> Self {
        Self {
            start: pos,
            end: pos,
            line: 0,
            col: 0,
            source_id: None,
        }
    }

    pub fn merge(self, other: Span) -> Span {
        // Keep the line/col and source_id of the earlier span
        if self.start <= other.start {
            Span {
                start: self.start,
                end: self.end.max(other.end),
                line: self.line,
                col: self.col,
                source_id: self.source_id,
            }
        } else {
            Span {
                start: other.start,
                end: self.end.max(other.end),
                line: other.line,
                col: other.col,
                source_id: other.source_id,
            }
        }
    }
}

// ariadne integration - SourceId is Spur (or empty string key for None)
impl ariadne::Span for Span {
    type SourceId = Spur;

    fn source(&self) -> &Self::SourceId {
        // We need a static default Spur for when source_id is None.
        // Spur::default() gives us the key for the empty string.
        static DEFAULT: std::sync::OnceLock<Spur> = std::sync::OnceLock::new();
        self.source_id
            .as_ref()
            .unwrap_or_else(|| DEFAULT.get_or_init(Spur::default))
    }

    fn start(&self) -> usize {
        self.start
    }

    fn end(&self) -> usize {
        self.end
    }
}

/// A value with optional source span attached
#[derive(Debug, Clone)]
pub struct Spanned<T> {
    pub value: T,
    pub span: Option<Span>,
}

impl<T> Spanned<T> {
    pub fn new(value: T, span: Span) -> Self {
        Self {
            value,
            span: Some(span),
        }
    }

    pub fn bare(value: T) -> Self {
        Self { value, span: None }
    }
}
