//! XPath-style reader syntax for optics.
//!
//! Parses strings like "/users/*/name" into Optic values.
//! See docs/SPEC_LENS.md Section 4 for the grammar.

use std::sync::Arc;

use crate::optic::Optic;
use crate::{Error, Value};

/// Parse an XPath string into an Optic
pub fn parse(input: &str) -> Result<Optic, Error> {
    let mut parser = XPathParser::new(input);
    parser.parse()
}

struct XPathParser<'a> {
    input: &'a str,
    pos: usize,
}

impl<'a> XPathParser<'a> {
    fn new(input: &'a str) -> Self {
        Self { input, pos: 0 }
    }

    fn parse(&mut self) -> Result<Optic, Error> {
        // Expect leading /
        if self.peek() != Some('/') {
            return Err(Error::reader("xpath must start with /", None));
        }
        self.advance();

        if self.pos >= self.input.len() {
            // Just "/" means identity
            return Ok(Optic::Compose(vec![].into()));
        }

        let mut segments = vec![];
        loop {
            if self.pos >= self.input.len() {
                break;
            }
            segments.push(self.parse_segment()?);
            if self.peek() == Some('/') {
                self.advance();
            } else {
                break;
            }
        }

        Ok(if segments.len() == 1 {
            segments.pop().unwrap()
        } else {
            Optic::Compose(segments.into())
        })
    }

    fn parse_segment(&mut self) -> Result<Optic, Error> {
        let step = self.parse_step()?;

        // Check for predicate [...]
        if self.peek() == Some('[') {
            self.advance(); // consume '['
            let pred = self.parse_predicate()?;
            self.expect(']')?;
            Ok(Optic::Compose(vec![step, pred].into()))
        } else {
            Ok(step)
        }
    }

    fn parse_step(&mut self) -> Result<Optic, Error> {
        match self.peek() {
            Some('*') => {
                self.advance();
                if self.peek() == Some('*') {
                    self.advance();
                    Ok(Optic::Deep)
                } else {
                    Ok(Optic::Each)
                }
            }
            Some('@') => {
                self.advance();
                if self.match_str("keys") {
                    Ok(Optic::Keys)
                } else {
                    Ok(Optic::Vals)
                }
            }
            Some(':') => {
                // Slice starting with :N
                self.advance();
                if self.peek().is_some_and(|c| c.is_ascii_digit() || c == '-') {
                    let to = self.parse_int()?;
                    Ok(Optic::Slice {
                        from: Some(0),
                        to: Some(to),
                    })
                } else {
                    Err(Error::reader("expected number after :", None))
                }
            }
            Some(c) if c.is_ascii_digit() || c == '-' => self.parse_index_or_slice(),
            Some(c) if c.is_alphabetic() || c == '_' => {
                let ident = self.parse_identifier();
                Ok(Optic::Key(Value::keyword(ident)))
            }
            Some('#') => {
                // #ident=value → DEEP + filtered comparison (by :ident value)
                self.advance();
                let ident = self.parse_identifier();
                if self.peek() != Some('=') {
                    return Err(Error::reader(
                        "expected '=' after #identifier in xpath",
                        None,
                    ));
                }
                self.advance();
                let value = self.parse_literal()?;
                Ok(Optic::Compose(
                    vec![
                        Optic::Deep,
                        Optic::Filtered(Arc::new(make_compare_fn(&ident, CompareOp::Eq, value))),
                    ]
                    .into(),
                ))
            }
            Some('"') => {
                let s = self.parse_string()?;
                Ok(Optic::Key(Value::String(s.into())))
            }
            Some(c) => Err(Error::reader(
                format!("unexpected character in xpath: '{}'", c),
                None,
            )),
            None => Err(Error::reader("unexpected end of xpath", None)),
        }
    }

    fn parse_index_or_slice(&mut self) -> Result<Optic, Error> {
        let first = self.parse_int()?;

        if self.peek() == Some(':') {
            self.advance();
            let second = if self.peek().is_some_and(|c| c.is_ascii_digit() || c == '-') {
                Some(self.parse_int()?)
            } else {
                None
            };
            Ok(Optic::Slice {
                from: Some(first),
                to: second,
            })
        } else {
            Ok(Optic::Index(first))
        }
    }

    fn parse_predicate(&mut self) -> Result<Optic, Error> {
        self.skip_whitespace();

        match self.peek() {
            // [:key] - truthy check on key
            Some(':') => {
                self.advance();
                let key = self.parse_identifier();
                Ok(Optic::Filtered(Arc::new(Value::keyword(key))))
            }
            // [!:key] - falsy check
            Some('!') => {
                self.advance();
                if self.peek() != Some(':') {
                    return Err(Error::reader("expected : after !", None));
                }
                self.advance();
                let key = self.parse_identifier();
                // Create (comp not :key) as a NativeFn
                let kw = Value::keyword(key);
                Ok(Optic::Filtered(Arc::new(make_not_key_fn(kw))))
            }
            // [.key op value] - comparison
            Some('.') => {
                self.advance();
                let key = self.parse_identifier();
                self.skip_whitespace();
                let op = self.parse_op()?;
                self.skip_whitespace();
                let value = self.parse_literal()?;
                Ok(Optic::Filtered(Arc::new(make_compare_fn(&key, op, value))))
            }
            // [pred?] or [pred] - function predicate
            Some(c) if c.is_alphabetic() || c == '_' => {
                let name = self.parse_identifier();
                // Consume optional ? at end
                if self.peek() == Some('?') {
                    self.advance();
                }
                // Create a symbol reference - will be resolved at runtime
                Ok(Optic::Filtered(Arc::new(Value::symbol(name))))
            }
            _ => Err(Error::reader("invalid predicate syntax", None)),
        }
    }

    fn parse_op(&mut self) -> Result<CompareOp, Error> {
        match self.peek() {
            Some('>') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Gte)
                } else {
                    Ok(CompareOp::Gt)
                }
            }
            Some('<') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Lte)
                } else {
                    Ok(CompareOp::Lt)
                }
            }
            Some('=') => {
                self.advance();
                Ok(CompareOp::Eq)
            }
            Some('!') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Neq)
                } else {
                    Err(Error::reader("expected = after !", None))
                }
            }
            _ => Err(Error::reader("expected comparison operator", None)),
        }
    }

    fn parse_literal(&mut self) -> Result<Value, Error> {
        match self.peek() {
            Some('"') => {
                let s = self.parse_string()?;
                Ok(Value::String(s.into()))
            }
            Some(c) if c.is_ascii_digit() || c == '-' => {
                let start = self.pos;
                if self.peek() == Some('-') {
                    self.advance();
                }
                while self.peek().is_some_and(|c| c.is_ascii_digit()) {
                    self.advance();
                }
                // Check for float
                if self.peek() == Some('.') {
                    self.advance();
                    while self.peek().is_some_and(|c| c.is_ascii_digit()) {
                        self.advance();
                    }
                    let s = &self.input[start..self.pos];
                    let f: f64 = s
                        .parse()
                        .map_err(|_| Error::reader("invalid float", None))?;
                    Ok(Value::Float(f))
                } else {
                    let s = &self.input[start..self.pos];
                    let i: i64 = s
                        .parse()
                        .map_err(|_| Error::reader("invalid integer", None))?;
                    Ok(Value::Int(i))
                }
            }
            Some(':') => {
                self.advance();
                let name = self.parse_identifier();
                Ok(Value::keyword(name))
            }
            Some(c) if c.is_alphabetic() || c == '_' => {
                // Bare identifier treated as string literal
                let s = self.parse_identifier();
                Ok(Value::String(s.into()))
            }
            _ => Err(Error::reader("expected literal value", None)),
        }
    }

    fn parse_int(&mut self) -> Result<i64, Error> {
        let start = self.pos;
        if self.peek() == Some('-') {
            self.advance();
        }
        if !self.peek().is_some_and(|c| c.is_ascii_digit()) {
            return Err(Error::reader("expected integer", None));
        }
        while self.peek().is_some_and(|c| c.is_ascii_digit()) {
            self.advance();
        }
        let s = &self.input[start..self.pos];
        s.parse()
            .map_err(|_| Error::reader("invalid integer", None))
    }

    fn parse_identifier(&mut self) -> String {
        let start = self.pos;
        while self
            .peek()
            .is_some_and(|c| c.is_alphanumeric() || c == '_' || c == '-' || c == '?')
        {
            self.advance();
        }
        self.input[start..self.pos].to_string()
    }

    fn parse_string(&mut self) -> Result<String, Error> {
        self.expect('"')?;
        let mut result = String::new();
        loop {
            match self.peek() {
                Some('"') => {
                    self.advance();
                    break;
                }
                Some('\\') => {
                    self.advance();
                    match self.peek() {
                        Some('n') => {
                            result.push('\n');
                            self.advance();
                        }
                        Some('t') => {
                            result.push('\t');
                            self.advance();
                        }
                        Some('\\') => {
                            result.push('\\');
                            self.advance();
                        }
                        Some('"') => {
                            result.push('"');
                            self.advance();
                        }
                        _ => return Err(Error::reader("invalid escape sequence", None)),
                    }
                }
                Some(c) => {
                    result.push(c);
                    self.advance();
                }
                None => return Err(Error::reader("unterminated string", None)),
            }
        }
        Ok(result)
    }

    fn peek(&self) -> Option<char> {
        self.input[self.pos..].chars().next()
    }

    fn advance(&mut self) {
        if let Some(c) = self.peek() {
            self.pos += c.len_utf8();
        }
    }

    fn expect(&mut self, expected: char) -> Result<(), Error> {
        if self.peek() == Some(expected) {
            self.advance();
            Ok(())
        } else {
            Err(Error::reader(
                format!("expected '{}' in xpath", expected),
                None,
            ))
        }
    }

    fn match_str(&mut self, s: &str) -> bool {
        if self.input[self.pos..].starts_with(s) {
            self.pos += s.len();
            true
        } else {
            false
        }
    }

    fn skip_whitespace(&mut self) {
        while self.peek().is_some_and(|c| c.is_whitespace()) {
            self.advance();
        }
    }
}

#[derive(Clone, Copy)]
enum CompareOp {
    Gt,
    Lt,
    Gte,
    Lte,
    Eq,
    Neq,
}

/// Create a predicate function that negates a keyword lookup
fn make_not_key_fn(kw: Value) -> Value {
    Value::NativeFn {
        name: "not-key",
        func: Arc::new(move |args| {
            if args.is_empty() {
                return Err(Error::arity("1", 0));
            }
            let data = &args[0];
            // Get the value at the keyword
            let val = match data.strip_meta() {
                Value::Map(m) => m.get(&kw).cloned().unwrap_or(Value::Nil),
                _ => Value::Nil,
            };
            // Return !truthy
            Ok(crate::done(Value::Bool(!val.is_truthy())))
        }),
    }
}

/// Create a predicate function for comparisons
fn make_compare_fn(key: &str, op: CompareOp, value: Value) -> Value {
    let key = Value::keyword(key);
    Value::NativeFn {
        name: "compare",
        func: Arc::new(move |args| {
            if args.is_empty() {
                return Err(Error::arity("1", 0));
            }
            let data = &args[0];
            // Get the value at the keyword
            let val = match data.strip_meta() {
                Value::Map(m) => m.get(&key).cloned().unwrap_or(Value::Nil),
                _ => Value::Nil,
            };
            // Compare
            let result = compare_values(&val, &value, op);
            Ok(crate::done(Value::Bool(result)))
        }),
    }
}

fn compare_values(a: &Value, b: &Value, op: CompareOp) -> bool {
    // Extract numbers for comparison
    let (a_num, b_num) = match (a.strip_meta(), b.strip_meta()) {
        (Value::Int(a), Value::Int(b)) => (Some(*a as f64), Some(*b as f64)),
        (Value::Int(a), Value::Float(b)) => (Some(*a as f64), Some(*b)),
        (Value::Float(a), Value::Int(b)) => (Some(*a), Some(*b as f64)),
        (Value::Float(a), Value::Float(b)) => (Some(*a), Some(*b)),
        _ => (None, None),
    };

    match op {
        CompareOp::Eq => a == b,
        CompareOp::Neq => a != b,
        CompareOp::Gt => a_num.zip(b_num).is_some_and(|(a, b)| a > b),
        CompareOp::Lt => a_num.zip(b_num).is_some_and(|(a, b)| a < b),
        CompareOp::Gte => a_num.zip(b_num).is_some_and(|(a, b)| a >= b),
        CompareOp::Lte => a_num.zip(b_num).is_some_and(|(a, b)| a <= b),
    }
}
