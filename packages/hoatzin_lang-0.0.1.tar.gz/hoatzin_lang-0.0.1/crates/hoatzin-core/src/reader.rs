//! Hand-written recursive descent reader for s-expressions
//!
//! ## Design Notes
//!
//! The reader is intentionally hand-written (not using parser combinators) because:
//! 1. S-expression grammar is trivial
//! 2. Full control over reader macros (', `, ~, @, #_, etc.)
//! 3. Precise span tracking for ariadne error messages
//! 4. No external parser dependencies
//!
//! ## Supported Syntax (Stage 1)
//!
//! - Atoms: nil, true, false, integers, floats, strings, symbols, keywords
//! - Collections: () lists, [] vectors, {} maps, #{} sets
//! - Reader macros: ' (quote), ; (comment), #_ (discard)
//!
//! ## Example
//!
//! ```ignore
//! let mut reader = Reader::new("(+ 1 2)");
//! let forms = reader.read_all()?;
//! ```

use std::sync::Arc;

use lasso::Spur;

use crate::span::Span;
use crate::{Error, Result, Value};

pub struct Reader<'a> {
    source: &'a str,
    pos: usize,
    line: usize, // 0-indexed
    col: usize,  // 0-indexed
    /// Optional source identifier (file name, "<repl>", etc.)
    source_id: Option<Spur>,
}

impl<'a> Reader<'a> {
    pub fn new(source: &'a str) -> Self {
        Self {
            source,
            pos: 0,
            line: 0,
            col: 0,
            source_id: None,
        }
    }

    /// Create a reader with a source identifier for error reporting
    pub fn with_source_id(source: &'a str, source_id: Spur) -> Self {
        Self {
            source,
            pos: 0,
            line: 0,
            col: 0,
            source_id: Some(source_id),
        }
    }

    /// Read all forms from input
    pub fn read_all(&mut self) -> Result<Vec<Value>> {
        let mut forms = Vec::new();
        loop {
            self.skip_whitespace_and_comments();
            if self.peek().is_none() {
                break;
            }
            let form = self.read_form()?;
            forms.push(form);
        }
        Ok(forms)
    }

    /// Read a single form
    pub fn read_form(&mut self) -> Result<Value> {
        self.skip_whitespace_and_comments();
        let start = self.pos;
        let start_line = self.line;
        let start_col = self.col;
        let ch = match self.peek() {
            Some(ch) => ch,
            None => return Err(self.error_here("Unexpected EOF")),
        };

        let value = match ch {
            '(' => self.read_list(),
            '[' => self.read_vector(),
            '{' => self.read_map(),
            '"' => self.read_string(),
            '\'' => self.read_quote(),
            '`' => self.read_syntax_quote(),
            '~' => self.read_unquote(),
            '@' => self.read_deref(),
            ':' => self.read_keyword(),
            '#' => self.read_dispatch(),
            _ => self.read_atom(),
        }?;
        let end = self.pos;
        Ok(Value::Meta {
            value: Box::new(value),
            span: Span::with_source(start, end, start_line, start_col, self.source_id),
        })
    }

    fn peek(&self) -> Option<char> {
        self.source[self.pos..].chars().next()
    }

    fn advance(&mut self) -> Option<char> {
        let ch = self.peek()?;
        self.pos += ch.len_utf8();
        if ch == '\n' {
            self.line += 1;
            self.col = 0;
        } else {
            self.col += 1;
        }
        Some(ch)
    }

    fn skip_whitespace_and_comments(&mut self) {
        loop {
            let rest = &self.source[self.pos..];
            let mut iter = rest.chars();
            let Some(ch) = iter.next() else {
                return;
            };
            if ch == ';' {
                while let Some(next) = self.advance() {
                    if next == '\n' {
                        break;
                    }
                }
                continue;
            }
            if ch.is_whitespace() || ch == ',' {
                self.advance();
                continue;
            }
            break;
        }
    }

    fn read_list(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('(')?;
        let mut items = Vec::new();
        loop {
            self.skip_whitespace_and_comments();
            match self.peek() {
                Some(')') => {
                    self.advance();
                    break;
                }
                Some(_) => items.push(self.read_form()?),
                None => return Err(self.error_span("Unclosed list", start, self.pos)),
            }
        }
        Ok(Value::list_from_iter(items))
    }

    fn read_vector(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('[')?;
        let mut items = crate::collections::Vector::new();
        loop {
            self.skip_whitespace_and_comments();
            match self.peek() {
                Some(']') => {
                    self.advance();
                    break;
                }
                Some(_) => items.push_back(self.read_form()?),
                None => return Err(self.error_span("Unclosed vector", start, self.pos)),
            }
        }
        Ok(Value::Vector(items))
    }

    fn read_map(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('{')?;
        let mut items = Vec::new();
        loop {
            self.skip_whitespace_and_comments();
            match self.peek() {
                Some('}') => {
                    self.advance();
                    break;
                }
                Some(_) => items.push(self.read_form()?),
                None => return Err(self.error_span("Unclosed map", start, self.pos)),
            }
        }
        if items.len() % 2 != 0 {
            return Err(self.error_span(
                "Map literal requires even number of forms",
                start,
                self.pos,
            ));
        }
        let mut map = crate::collections::HashMap::new();
        let mut iter = items.into_iter();
        while let (Some(k), Some(v)) = (iter.next(), iter.next()) {
            map.insert(k, v);
        }
        Ok(Value::Map(map))
    }

    fn read_set(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('{')?;
        let mut set = crate::collections::HashSet::new();
        loop {
            self.skip_whitespace_and_comments();
            match self.peek() {
                Some('}') => {
                    self.advance();
                    break;
                }
                Some(_) => {
                    let value = self.read_form()?;
                    set.insert(value);
                }
                None => return Err(self.error_span("Unclosed set", start, self.pos)),
            }
        }
        Ok(Value::Set(set))
    }

    fn read_string(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('"')?;
        let mut out = String::new();
        while let Some(ch) = self.advance() {
            match ch {
                '"' => return Ok(Value::String(out.into())),
                '\\' => {
                    let esc = self
                        .advance()
                        .ok_or_else(|| self.error_span("Invalid escape", start, self.pos))?;
                    match esc {
                        'n' => out.push('\n'),
                        't' => out.push('\t'),
                        'r' => out.push('\r'),
                        '\\' => out.push('\\'),
                        '"' => out.push('"'),
                        'u' => {
                            // Unicode escape: \uXXXX
                            let mut hex = String::new();
                            for _ in 0..4 {
                                match self.advance() {
                                    Some(c) if c.is_ascii_hexdigit() => hex.push(c),
                                    _ => {
                                        return Err(self.error_span(
                                            "Invalid unicode escape",
                                            start,
                                            self.pos,
                                        ));
                                    }
                                }
                            }
                            let code = u32::from_str_radix(&hex, 16).map_err(|_| {
                                self.error_span("Invalid unicode escape", start, self.pos)
                            })?;
                            let c = char::from_u32(code).ok_or_else(|| {
                                self.error_span("Invalid unicode code point", start, self.pos)
                            })?;
                            out.push(c);
                        }
                        _ => return Err(self.error_span("Unsupported escape", start, self.pos)),
                    }
                }
                _ => out.push(ch),
            }
        }
        Err(self.error_span("Unclosed string", start, self.pos))
    }

    fn read_keyword(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char(':')?;
        let token = self.read_token();
        if token.is_empty() {
            return Err(self.error_span("Invalid keyword", start, self.pos));
        }
        let (namespace, name) = split_namespace(&token);
        Ok(match namespace {
            Some(ns) => Value::keyword_ns(ns, name),
            None => Value::keyword(name),
        })
    }

    fn read_atom(&mut self) -> Result<Value> {
        let start = self.pos;
        let token = self.read_token();
        if token.is_empty() {
            return Err(self.error_span("Unexpected token", start, self.pos));
        }
        match token.as_str() {
            "nil" => return Ok(Value::Nil),
            "true" => return Ok(Value::Bool(true)),
            "false" => return Ok(Value::Bool(false)),
            _ => {}
        }

        match parse_number(&token) {
            Ok(Some(value)) => return Ok(value),
            Ok(None) => {} // Not a number, continue to symbol
            Err(msg) => return Err(self.error_span(msg, start, self.pos)),
        }

        let (namespace, name) = split_namespace(&token);
        Ok(match namespace {
            Some(ns) => Value::symbol_ns(ns, name),
            None => Value::symbol(name),
        })
    }

    fn read_quote(&mut self) -> Result<Value> {
        self.expect_char('\'')?;
        let form = self.read_form()?;
        let quote_sym = Value::symbol("quote");
        Ok(Value::list_from_iter([quote_sym, form]))
    }

    fn read_syntax_quote(&mut self) -> Result<Value> {
        self.expect_char('`')?;
        let form = self.read_form()?;
        let sym = Value::symbol("syntax-quote");
        Ok(Value::list_from_iter([sym, form]))
    }

    fn read_unquote(&mut self) -> Result<Value> {
        self.expect_char('~')?;
        let sym = if self.peek() == Some('@') {
            self.advance();
            Value::symbol("unquote-splicing")
        } else {
            Value::symbol("unquote")
        };
        let form = self.read_form()?;
        Ok(Value::list_from_iter([sym, form]))
    }

    fn read_deref(&mut self) -> Result<Value> {
        self.expect_char('@')?;
        let form = self.read_form()?;
        let deref_sym = Value::symbol("deref");
        Ok(Value::list_from_iter([deref_sym, form]))
    }

    fn read_discard(&mut self) -> Result<()> {
        self.skip_whitespace_and_comments();
        self.read_form().map(|_| ())
    }

    fn read_dispatch(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('#')?;
        match self.peek() {
            Some('{') => self.read_set(),
            Some('_') => {
                self.advance();
                self.read_discard()?;
                self.read_form()
            }
            Some('(') => self.read_anon_fn(),
            Some('x') => {
                self.advance();
                self.read_xpath()
            }
            Some('"') => self.read_regex(),
            _ => Err(self.error_span("Unsupported reader macro", start, self.pos)),
        }
    }

    fn read_xpath(&mut self) -> Result<Value> {
        let start = self.pos;
        if self.peek() != Some('"') {
            return Err(self.error_span("Expected string after #x", start, self.pos));
        }
        let xpath_str = self.read_string()?;

        // Emit (xpath "<string>") form instead of constructing optic at read time.
        // This allows xpath to work properly in macros (syntax produces syntax, not values).
        let xpath_sym = Value::symbol("xpath");
        let list = crate::List::from_iter(vec![xpath_sym, xpath_str]);
        Ok(Value::List(Arc::new(list)))
    }

    /// Read a regex literal: #"pattern"
    /// Unlike strings, backslashes are literal (for regex escapes like \d, \w).
    /// Only \" is treated as an escape for the closing quote.
    fn read_regex(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('"')?;
        let mut pattern = String::new();
        while let Some(ch) = self.advance() {
            match ch {
                '"' => {
                    // Compile the regex
                    let re = regex::Regex::new(&pattern).map_err(|e| {
                        self.error_span(format!("Invalid regex: {}", e), start, self.pos)
                    })?;
                    return Ok(Value::Regex(Arc::new(re)));
                }
                '\\' => {
                    // Only \" escapes the quote, everything else is literal
                    if self.peek() == Some('"') {
                        self.advance();
                        pattern.push('"');
                    } else {
                        pattern.push('\\');
                    }
                }
                _ => pattern.push(ch),
            }
        }
        Err(self.error_span("Unclosed regex", start, self.pos))
    }

    fn read_anon_fn(&mut self) -> Result<Value> {
        let start = self.pos;
        self.expect_char('(')?;
        let mut items = Vec::new();
        loop {
            self.skip_whitespace_and_comments();
            match self.peek() {
                Some(')') => {
                    self.advance();
                    break;
                }
                Some(_) => items.push(self.read_form()?),
                None => return Err(self.error_span("Unclosed anonymous fn", start, self.pos)),
            }
        }
        let body = Value::list_from_iter(items);
        Ok(desugar_anon_fn(body))
    }

    fn read_token(&mut self) -> String {
        let mut token = String::new();
        while let Some(ch) = self.peek() {
            if ch.is_whitespace()
                || ch == ','
                || matches!(
                    ch,
                    '(' | ')' | '[' | ']' | '{' | '}' | '"' | ';' | '`' | '~'
                )
            {
                break;
            }
            token.push(ch);
            self.advance();
        }
        token
    }

    fn expect_char(&mut self, expected: char) -> Result<()> {
        match self.advance() {
            Some(ch) if ch == expected => Ok(()),
            _ => Err(self.error_here(format!("Expected '{}'", expected))),
        }
    }

    fn error_here(&self, message: impl Into<String>) -> Error {
        let mut span = Span::point(self.pos);
        span.source_id = self.source_id;
        Error::reader(message, Some(span))
    }

    fn error_span(&self, message: impl Into<String>, start: usize, end: usize) -> Error {
        let mut span = Span::new(start, end);
        span.source_id = self.source_id;
        Error::reader(message, Some(span))
    }
}

/// Convenience function to read source without a source identifier
pub fn read_str(source: &str) -> Result<Vec<Value>> {
    Reader::new(source).read_all()
}

/// Read source with a source identifier for error reporting
pub fn read_str_with_source(source: &str, source_id: Spur) -> Result<Vec<Value>> {
    Reader::with_source_id(source, source_id).read_all()
}

fn split_namespace(token: &str) -> (Option<Arc<str>>, Arc<str>) {
    if let Some((ns, name)) = token.split_once('/') {
        if !ns.is_empty() && !name.is_empty() {
            return (Some(ns.into()), name.into());
        }
    }
    (None, token.into())
}

/// Parse a number token. Returns:
/// - Ok(Some(value)) for a valid number
/// - Ok(None) if not a number (treat as symbol)
/// - Err(msg) for invalid number literal (like 1/0)
fn parse_number(token: &str) -> std::result::Result<Option<Value>, &'static str> {
    // Try ratio first
    if let Some((num, denom)) = token.split_once('/') {
        if let (Ok(n), Ok(d)) = (num.parse::<i64>(), denom.parse::<i64>()) {
            if d == 0 {
                return Err("Division by zero in ratio literal");
            }
            let (n, d) = reduce_ratio(n, d);
            return Ok(Some(Value::Ratio { numer: n, denom: d }));
        }
    }

    // Hex literal: 0x...
    if let Some(rest) = token
        .strip_prefix("0x")
        .or_else(|| token.strip_prefix("0X"))
    {
        if let Ok(value) = i64::from_str_radix(rest, 16) {
            return Ok(Some(Value::Int(value)));
        }
        return Err("Invalid hex literal");
    }

    // Radix literal: NrDIGITS (e.g., 2r1010, 16rFF)
    if let Some(r_pos) = token.find('r') {
        let (radix_str, digits) = token.split_at(r_pos);
        let digits = &digits[1..]; // skip 'r'
        if let Ok(radix) = radix_str.parse::<u32>() {
            if (2..=36).contains(&radix) {
                if let Ok(value) = i64::from_str_radix(digits, radix) {
                    return Ok(Some(Value::Int(value)));
                }
                return Err("Invalid radix literal");
            }
        }
    }

    // Float
    if token.contains('.') || token.contains('e') || token.contains('E') {
        if let Ok(value) = token.parse::<f64>() {
            return Ok(Some(Value::Float(value)));
        }
    }

    // Integer
    if let Ok(value) = token.parse::<i64>() {
        return Ok(Some(Value::Int(value)));
    }

    Ok(None)
}

fn reduce_ratio(numer: i64, denom: i64) -> (i64, i64) {
    let mut n = numer;
    let mut d = denom;
    if d < 0 {
        n = -n;
        d = -d;
    }
    let gcd = gcd_i64(n.abs(), d.abs());
    (n / gcd, d / gcd)
}

fn gcd_i64(mut a: i64, mut b: i64) -> i64 {
    while b != 0 {
        let r = a % b;
        a = b;
        b = r;
    }
    a.abs()
}

fn desugar_anon_fn(body: Value) -> Value {
    let mut state = AnonFnState::default();
    let rewritten = rewrite_anon_args(&body, &mut state);
    let max_index = state.max_index.max(if state.used_percent { 1 } else { 0 });
    let mut params = crate::collections::Vector::new();
    for idx in 1..=max_index {
        params.push_back(Value::symbol(format!("%{}", idx)));
    }
    if state.used_rest {
        params.push_back(Value::symbol("&"));
        params.push_back(Value::symbol("%&"));
    }
    let params = Value::Vector(params);
    Value::list_from_iter([Value::symbol("fn"), params, rewritten])
}

#[derive(Default)]
struct AnonFnState {
    max_index: usize,
    used_percent: bool,
    used_rest: bool,
}

fn rewrite_anon_args(value: &Value, state: &mut AnonFnState) -> Value {
    match value {
        Value::Meta { value: inner, span } => {
            // Recursively rewrite the inner value, preserving the span
            let rewritten = rewrite_anon_args(inner, state);
            Value::Meta {
                value: Box::new(rewritten),
                span: *span,
            }
        }
        Value::Symbol(sym) => {
            let name = sym.name.as_ref();
            if name == "%" {
                state.used_percent = true;
                return Value::symbol("%1");
            }
            if name == "%&" {
                state.used_rest = true;
                return value.clone();
            }
            if let Some(idx) = parse_percent_index(name) {
                state.max_index = state.max_index.max(idx);
            }
            value.clone()
        }
        Value::List(list) => {
            let mut out = Vec::new();
            for item in list.iter() {
                out.push(rewrite_anon_args(item, state));
            }
            Value::list_from_iter(out)
        }
        Value::Vector(vec) => {
            let mut out = crate::collections::Vector::new();
            for item in vec.iter() {
                out.push_back(rewrite_anon_args(item, state));
            }
            Value::Vector(out)
        }
        Value::Map(map) => {
            let mut out = crate::collections::HashMap::new();
            for (k, v) in map.iter() {
                out.insert(rewrite_anon_args(k, state), rewrite_anon_args(v, state));
            }
            Value::Map(out)
        }
        Value::Set(set) => {
            let mut out = crate::collections::HashSet::new();
            for item in set.iter() {
                out.insert(rewrite_anon_args(item, state));
            }
            Value::Set(out)
        }
        _ => value.clone(),
    }
}

fn parse_percent_index(name: &str) -> Option<usize> {
    if let Some(rest) = name.strip_prefix('%') {
        if rest.is_empty() {
            return None;
        }
        if rest.chars().all(|ch| ch.is_ascii_digit()) {
            return rest.parse::<usize>().ok();
        }
    }
    None
}
