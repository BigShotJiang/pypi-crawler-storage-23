//! Evaluation utilities for native functions.
//!
//! This module provides types that allow native functions to request
//! effect-aware evaluation from the runtime.

use std::sync::Arc;

use crate::{Result, Value};

/// Request from native function to evaluate something with full effect support
#[derive(Debug, Clone)]
pub enum EvalRequest {
    /// Apply a function to arguments
    Apply { func: Value, args: Vec<Value> },
}

/// Result that can either be a value or a request for evaluation
pub enum NativeResult {
    /// Computation complete with this value
    Done(Value),
    /// Need to evaluate something, then call back with result
    Request {
        request: EvalRequest,
        /// Callback receives the result of the request
        callback: Arc<dyn Fn(Value) -> Result<NativeResult>>,
    },
}

impl std::fmt::Debug for NativeResult {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            NativeResult::Done(v) => write!(f, "Done({:?})", v),
            NativeResult::Request { request, .. } => {
                write!(f, "Request({:?}, <callback>)", request)
            }
        }
    }
}

impl Clone for NativeResult {
    fn clone(&self) -> Self {
        match self {
            NativeResult::Done(v) => NativeResult::Done(v.clone()),
            NativeResult::Request { request, callback } => NativeResult::Request {
                request: request.clone(),
                callback: callback.clone(),
            },
        }
    }
}

/// Apply a function and pass result to callback (for use in HOFs)
pub fn apply_then<F>(func: Value, args: Vec<Value>, callback: F) -> NativeResult
where
    F: Fn(Value) -> Result<NativeResult> + 'static,
{
    NativeResult::Request {
        request: EvalRequest::Apply { func, args },
        callback: Arc::new(callback),
    }
}

/// Simple value result
pub fn done(v: Value) -> NativeResult {
    NativeResult::Done(v)
}
