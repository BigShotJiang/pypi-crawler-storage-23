//! First-class optics for immutable data manipulation.
//!
//! Provides lenses, traversals, and prisms as first-class values.
//! See docs/SPEC_LENS.md for the full specification.
//!
//! Note: The optic operations (view, view_all, over, set) are implemented
//! in the VM's native functions (vm/natives.rs) rather than here, as they
//! require effect-aware evaluation.

use std::sync::Arc;

use crate::{Error, Result, Value};

/// First-class optic representation using Data/AST encoding.
#[derive(Clone, Debug)]
pub enum Optic {
    // ─── Primitives ───────────────────────────────────────────
    /// Focus on a key in a map: :foo, "key"
    Key(Value),

    /// Focus on an index in a sequence: 0, -1 (negative = from end)
    Index(i64),

    // ─── Composition ──────────────────────────────────────────
    /// Sequential composition: (*> a b c)
    Compose(Arc<[Optic]>),

    // ─── Traversals (multiple foci) ───────────────────────────
    /// All elements in a sequence
    Each,

    /// All values in a map
    Vals,

    /// All keys in a map
    Keys,

    /// Recursive descent into all nested collections
    Deep,

    // ─── Filtering ────────────────────────────────────────────
    /// Filter by predicate function
    Filtered(Arc<Value>),

    /// Slice of sequence [from, to)
    Slice { from: Option<i64>, to: Option<i64> },

    // ─── Prisms (0-or-1 focus) ────────────────────────────────
    /// Focus only if value is not nil
    Some,

    /// Focus only if predicate returns true (identity lens)
    When(Arc<Value>),

    // ─── User-Defined ─────────────────────────────────────────
    /// Custom lens from getter/setter pair
    Custom { get: Arc<Value>, set: Arc<Value> },
}

impl PartialEq for Optic {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Optic::Key(a), Optic::Key(b)) => a == b,
            (Optic::Index(a), Optic::Index(b)) => a == b,
            (Optic::Compose(a), Optic::Compose(b)) => a == b,
            (Optic::Each, Optic::Each) => true,
            (Optic::Vals, Optic::Vals) => true,
            (Optic::Keys, Optic::Keys) => true,
            (Optic::Deep, Optic::Deep) => true,
            (Optic::Filtered(a), Optic::Filtered(b)) => Arc::ptr_eq(a, b),
            (Optic::Slice { from: a1, to: a2 }, Optic::Slice { from: b1, to: b2 }) => {
                a1 == b1 && a2 == b2
            }
            (Optic::Some, Optic::Some) => true,
            (Optic::When(a), Optic::When(b)) => Arc::ptr_eq(a, b),
            (Optic::Custom { get: g1, set: s1 }, Optic::Custom { get: g2, set: s2 }) => {
                Arc::ptr_eq(g1, g2) && Arc::ptr_eq(s1, s2)
            }
            _ => false,
        }
    }
}

impl Optic {
    /// Returns true if this optic is a traversal (can have multiple foci).
    /// view() will fail on traversals - use view-all instead.
    pub fn is_traversal(&self) -> bool {
        match self {
            // Single-focus optics (lenses)
            Optic::Key(_) | Optic::Index(_) | Optic::Custom { .. } => false,
            // Prisms (0 or 1 focus) - still usable with view
            Optic::Some | Optic::When(_) | Optic::Filtered(_) => false,
            // Traversals (potentially multiple foci)
            Optic::Each | Optic::Vals | Optic::Keys | Optic::Deep | Optic::Slice { .. } => true,
            // Composition: traversal if any component is a traversal
            Optic::Compose(ops) => ops.iter().any(|op| op.is_traversal()),
        }
    }
}

// ============================================================================
// Auto-lifting: coerce Value to Optic
// ============================================================================

/// Try to coerce a Value to an Optic
pub fn as_optic(v: &Value) -> Result<Optic> {
    match v.strip_meta() {
        Value::Optic(o) => Ok((**o).clone()),
        Value::Keyword(_) | Value::String(_) => Ok(Optic::Key(v.clone())),
        Value::Int(i) => Ok(Optic::Index(*i)),
        Value::Vector(vec) => {
            let ops: Vec<Optic> = vec.iter().map(as_optic).collect::<Result<_>>()?;
            if ops.len() == 1 {
                Ok(ops.into_iter().next().unwrap())
            } else {
                Ok(Optic::Compose(ops.into()))
            }
        }
        Value::List(list) => {
            let ops: Vec<Optic> = list.iter().map(as_optic).collect::<Result<_>>()?;
            if ops.len() == 1 {
                Ok(ops.into_iter().next().unwrap())
            } else {
                Ok(Optic::Compose(ops.into()))
            }
        }
        Value::NativeFn { .. } => {
            // Function used as predicate filter
            Ok(Optic::Filtered(Arc::new(v.clone())))
        }
        _ => Err(Error::type_error("optic", v.type_name())),
    }
}

// ============================================================================
// Display
// ============================================================================

impl std::fmt::Display for Optic {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Optic::Key(v) => write!(f, "{}", crate::printer::pr_str(v)),
            Optic::Index(i) => write!(f, "{}", i),
            Optic::Compose(ops) => {
                write!(f, "(*>")?;
                for op in ops.iter() {
                    write!(f, " {}", op)?;
                }
                write!(f, ")")
            }
            Optic::Each => write!(f, "each"),
            Optic::Vals => write!(f, "_vals"),
            Optic::Keys => write!(f, "_keys"),
            Optic::Deep => write!(f, "DEEP"),
            Optic::Filtered(pred) => write!(f, "(filtered {})", crate::printer::pr_str(pred)),
            Optic::Slice { from, to } => {
                write!(
                    f,
                    "(slice {} {})",
                    from.map(|i| i.to_string()).unwrap_or_else(|| "nil".into()),
                    to.map(|i| i.to_string()).unwrap_or_else(|| "nil".into())
                )
            }
            Optic::Some => write!(f, "_some"),
            Optic::When(pred) => write!(f, "(when {})", crate::printer::pr_str(pred)),
            Optic::Custom { .. } => write!(f, "#<lens>"),
        }
    }
}
