//! Rc-backed persistent collections (non-thread-safe, faster than Arc).

use imbl::shared_ptr::RcK;
use std::collections::hash_map::RandomState;

pub type Vector<A> = imbl::vector::GenericVector<A, RcK>;
pub type HashMap<K, V> = imbl::hashmap::GenericHashMap<K, V, RandomState, RcK>;
pub type HashSet<A> = imbl::hashset::GenericHashSet<A, RandomState, RcK>;
