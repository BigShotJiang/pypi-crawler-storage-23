//! Built-in effects for Hoatzin.
//!
//! Provides standard effects:
//! - `exn`: Exception handling (raise)
//! - `console`: Console I/O (print, println, read-line)
//!   - print/println have default handlers
//!   - read-line requires a user-provided handler
//! - `random`: Random number generation (rand, rand-int)

use std::sync::Arc;

use crate::Value;
use crate::value::{EffectId, OpSignature};

/// Global effect ID counter for built-in effects.
/// Using high numbers to avoid collision with user-created effects.
const BUILTIN_EXN_ID: u64 = 0xFFFF_0001;
const BUILTIN_CONSOLE_ID: u64 = 0xFFFF_0002;
const BUILTIN_RANDOM_ID: u64 = 0xFFFF_0004;

/// Create the `exn` effect.
///
/// Operations:
/// - `raise [msg]`: Raise an exception with the given message
pub fn exn_effect() -> Value {
    let mut ops = crate::collections::HashMap::new();
    ops.insert(
        Arc::from("raise"),
        OpSignature {
            name: Arc::from("raise"),
            params: vec![Arc::from("msg")],
        },
    );

    Value::Effect {
        id: EffectId(BUILTIN_EXN_ID),
        name: Some(Arc::from("exn")),
        ops,
    }
}

/// Create the `console` effect.
///
/// Operations:
/// - `print [v]`: Print a value without newline (has default handler)
/// - `println [v]`: Print a value with newline (has default handler)
/// - `read-line []`: Read a line from input (NO default handler - host must provide)
pub fn console_effect() -> Value {
    let mut ops = crate::collections::HashMap::new();
    ops.insert(
        Arc::from("print"),
        OpSignature {
            name: Arc::from("print"),
            params: vec![Arc::from("v")],
        },
    );
    ops.insert(
        Arc::from("println"),
        OpSignature {
            name: Arc::from("println"),
            params: vec![Arc::from("v")],
        },
    );
    ops.insert(
        Arc::from("read-line"),
        OpSignature {
            name: Arc::from("read-line"),
            params: vec![],
        },
    );

    Value::Effect {
        id: EffectId(BUILTIN_CONSOLE_ID),
        name: Some(Arc::from("console")),
        ops,
    }
}

/// Create the `random` effect.
///
/// Operations:
/// - `rand []`: Generate a random float in [0, 1)
/// - `rand-int [n]`: Generate a random integer in [0, n)
pub fn random_effect() -> Value {
    let mut ops = crate::collections::HashMap::new();
    ops.insert(
        Arc::from("rand"),
        OpSignature {
            name: Arc::from("rand"),
            params: vec![],
        },
    );
    ops.insert(
        Arc::from("rand-int"),
        OpSignature {
            name: Arc::from("rand-int"),
            params: vec![Arc::from("n")],
        },
    );

    Value::Effect {
        id: EffectId(BUILTIN_RANDOM_ID),
        name: Some(Arc::from("random")),
        ops,
    }
}

/// Get the effect ID for the built-in exn effect.
pub fn exn_effect_id() -> EffectId {
    EffectId(BUILTIN_EXN_ID)
}

/// Get the effect ID for the built-in console effect.
pub fn console_effect_id() -> EffectId {
    EffectId(BUILTIN_CONSOLE_ID)
}

/// Get the effect ID for the built-in random effect.
pub fn random_effect_id() -> EffectId {
    EffectId(BUILTIN_RANDOM_ID)
}

/// Protected effect names that cannot be redefined at global level.
pub const PROTECTED_EFFECT_NAMES: &[&str] = &["exn", "console", "random"];

/// Check if a name is a protected effect name.
pub fn is_protected_effect_name(name: &str) -> bool {
    PROTECTED_EFFECT_NAMES.contains(&name)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_exn_effect() {
        let exn = exn_effect();
        if let Value::Effect { id, name, ops } = exn {
            assert_eq!(id, EffectId(BUILTIN_EXN_ID));
            assert_eq!(name, Some(Arc::from("exn")));
            assert!(ops.contains_key(&Arc::from("raise")));
        } else {
            panic!("Expected Effect value");
        }
    }

    #[test]
    fn test_console_effect() {
        let console = console_effect();
        if let Value::Effect { ops, .. } = console {
            assert!(ops.contains_key(&Arc::from("print")));
            assert!(ops.contains_key(&Arc::from("println")));
            assert!(ops.contains_key(&Arc::from("read-line")));
        } else {
            panic!("Expected Effect value");
        }
    }

    #[test]
    fn test_protected_names() {
        assert!(is_protected_effect_name("exn"));
        assert!(is_protected_effect_name("console"));
        assert!(!is_protected_effect_name("my-effect"));
    }
}
