//! Error types with ariadne integration for rich diagnostics

use crate::span::Span;
use crate::value::{CallFrame, CallFrameKind};
use ariadne::{Color, Label, Report, ReportKind};

pub type Result<T> = std::result::Result<T, Error>;

/// Role of a related span in error reporting
#[derive(Debug, Clone, PartialEq)]
pub enum SpanRole {
    /// Where a fn/var was defined
    Definition,
    /// For "used twice" errors
    PreviousUse,
    /// Source of type expectation
    Expected,
    /// Where a binding was introduced
    Binding,
}

/// A related location attached to an error
#[derive(Debug, Clone, PartialEq)]
pub struct RelatedSpan {
    pub span: Span,
    pub role: SpanRole,
    pub message: Option<String>,
}

/// Suggested fix for an error
#[derive(Debug, Clone, PartialEq)]
pub enum Hint {
    /// "Did you mean X?"
    DidYouMean(String),
    /// Missing argument with parameter name
    MissingArgument(String),
    /// Called with too many arguments
    ExtraArgument { expected: usize },
    /// Use a different function/syntax
    UseInstead(String),
}

/// The kind of error that occurred
#[derive(Debug, Clone, PartialEq)]
pub enum ErrorKind {
    Reader {
        message: String,
    },
    Eval {
        message: String,
    },
    /// User-raised exception via exn/raise - displays message directly
    Exception {
        message: String,
    },
    Arity {
        expected: String,
        got: usize,
    },
    Type {
        expected: String,
        got: String,
    },
    IndexOutOfBounds {
        index: i64,
        len: usize,
    },
    Recur {
        values: Vec<crate::Value>,
    },
    /// Continuation was resumed more than once (one-shot violation)
    ContinuationUsedTwice {
        first_span: Option<Span>,
    },
}

/// An error with rich diagnostic information
#[derive(Debug, Clone)]
pub struct Error {
    pub kind: ErrorKind,
    pub span: Option<Span>,
    pub call_stack: Vec<CallFrame>,
    pub related: Vec<RelatedSpan>,
    pub hint: Option<Hint>,
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match &self.kind {
            ErrorKind::Reader { message } => write!(f, "Reader error: {}", message),
            ErrorKind::Eval { message } => write!(f, "{}", message),
            ErrorKind::Exception { message } => write!(f, "{}", message),
            ErrorKind::Arity { expected, got } => {
                write!(f, "Arity error: expected {}, got {}", expected, got)
            }
            ErrorKind::Type { expected, got } => {
                write!(f, "Type error: expected {}, got {}", expected, got)
            }
            ErrorKind::IndexOutOfBounds { index, len } => {
                write!(f, "Index {} out of bounds for length {}", index, len)
            }
            ErrorKind::Recur { .. } => write!(f, "Internal recur signal"),
            ErrorKind::ContinuationUsedTwice { .. } => {
                write!(
                    f,
                    "Continuation resumed more than once (one-shot violation)"
                )
            }
        }
    }
}

impl std::error::Error for Error {}

impl Error {
    fn new(kind: ErrorKind) -> Self {
        Error {
            kind,
            span: None,
            call_stack: Vec::new(),
            related: Vec::new(),
            hint: None,
        }
    }

    pub fn reader(message: impl Into<String>, span: Option<Span>) -> Self {
        Error {
            kind: ErrorKind::Reader {
                message: message.into(),
            },
            span,
            call_stack: Vec::new(),
            related: Vec::new(),
            hint: None,
        }
    }

    pub fn eval(message: impl Into<String>) -> Self {
        Error::new(ErrorKind::Eval {
            message: message.into(),
        })
    }

    /// Create a user exception (from exn/raise) - displays message directly without prefix
    pub fn exception(message: impl Into<String>) -> Self {
        Error::new(ErrorKind::Exception {
            message: message.into(),
        })
    }

    pub fn arity(expected: impl Into<String>, got: usize) -> Self {
        Error::new(ErrorKind::Arity {
            expected: expected.into(),
            got,
        })
    }

    pub fn type_error(expected: impl Into<String>, got: impl Into<String>) -> Self {
        Error::new(ErrorKind::Type {
            expected: expected.into(),
            got: got.into(),
        })
    }

    pub fn type_error_value(expected: impl Into<String>, value: &crate::Value) -> Self {
        let (inner, span) = value.split_meta();
        Error::type_error(expected, format!("{} ({})", inner.type_name(), inner)).with_span(span)
    }

    pub fn continuation_used_twice(first_span: Option<Span>, second_span: Option<Span>) -> Self {
        Error {
            kind: ErrorKind::ContinuationUsedTwice { first_span },
            span: second_span,
            call_stack: Vec::new(),
            related: if let Some(span) = first_span {
                vec![RelatedSpan {
                    span,
                    role: SpanRole::PreviousUse,
                    message: Some("first call was here".to_string()),
                }]
            } else {
                Vec::new()
            },
            hint: Some(Hint::UseInstead(
                "Continuations are one-shot; call `k` at most once".to_string(),
            )),
        }
    }

    pub fn index_out_of_bounds(index: i64, len: usize) -> Self {
        Error::new(ErrorKind::IndexOutOfBounds { index, len })
    }

    pub fn recur(values: Vec<crate::Value>) -> Self {
        Error::new(ErrorKind::Recur { values })
    }

    /// Check if this error is a Recur signal
    pub fn is_recur(&self) -> bool {
        matches!(self.kind, ErrorKind::Recur { .. })
    }

    /// Extract recur values if this is a Recur error
    pub fn into_recur(self) -> Option<Vec<crate::Value>> {
        match self.kind {
            ErrorKind::Recur { values } => Some(values),
            _ => None,
        }
    }

    pub fn with_span(mut self, span: Option<Span>) -> Self {
        if span.is_some() && self.span.is_none() {
            self.span = span;
        }
        self
    }

    pub fn with_call_span(mut self, span: Option<Span>) -> Self {
        if span.is_some() {
            self.span = span;
        }
        self
    }

    pub fn with_call_stack(mut self, call_stack: Vec<CallFrame>) -> Self {
        self.call_stack = call_stack;
        self
    }

    pub fn with_related(mut self, related: RelatedSpan) -> Self {
        self.related.push(related);
        self
    }

    pub fn with_hint(mut self, hint: Hint) -> Self {
        self.hint = Some(hint);
        self
    }
}

/// Format a call frame kind for display
fn format_call_frame_kind(kind: &CallFrameKind) -> String {
    match kind {
        CallFrameKind::UserFn(name) => name.to_string(),
        CallFrameKind::Anonymous => "<anonymous>".to_string(),
        CallFrameKind::Native(name) => name.to_string(),
        CallFrameKind::Effect { effect, op } => format!("{}/{}", effect, op),
        CallFrameKind::Handler { effect, op } => format!("<handler {}/{}>", effect, op),
    }
}

/// Format the call stack for display
pub fn format_call_stack(call_stack: &[CallFrame]) -> String {
    if call_stack.is_empty() {
        return String::new();
    }

    let mut output = String::from("\nCall stack (most recent last):\n");
    let max_frames = 30;
    let total = call_stack.len();

    let (frames_to_show, skipped) = if total > max_frames {
        let skip = total - max_frames;
        (&call_stack[skip..], skip)
    } else {
        (call_stack, 0)
    };

    if skipped > 0 {
        output.push_str(&format!("  ... {} more frames ...\n", skipped));
    }

    for (i, frame) in frames_to_show.iter().enumerate() {
        let name = format_call_frame_kind(&frame.kind);
        let location = match frame.span {
            // Display as 1-indexed line:col for user-friendliness
            Some(span) => format!("{}:{}", span.line + 1, span.col + 1),
            None => "?:?".to_string(),
        };
        let marker = if i == frames_to_show.len() - 1 {
            "  ← here"
        } else {
            ""
        };
        output.push_str(&format!("  {:16} {}{}\n", name, location, marker));
    }

    output
}

/// Format a hint for display
pub fn format_hint(hint: &Hint) -> String {
    match hint {
        Hint::DidYouMean(suggestion) => format!("Hint: Did you mean `{}`?", suggestion),
        Hint::MissingArgument(param) => {
            format!("Hint: Perhaps you forgot the `{}` argument?", param)
        }
        Hint::ExtraArgument { expected } => {
            format!("Hint: This function takes {} argument(s)", expected)
        }
        Hint::UseInstead(msg) => format!("Hint: {}", msg),
    }
}

pub fn report(error: &Error) -> Option<Report<'_, Span>> {
    let span = error.span?;

    let mut builder = Report::build(ReportKind::Error, span)
        .with_message(error.to_string())
        .with_label(
            Label::new(span)
                .with_message(error.to_string())
                .with_color(Color::Red),
        );

    // Add related spans
    for related in &error.related {
        let msg = related
            .message
            .clone()
            .unwrap_or_else(|| match related.role {
                SpanRole::Definition => "defined here".to_string(),
                SpanRole::PreviousUse => "first used here".to_string(),
                SpanRole::Expected => "expected type from here".to_string(),
                SpanRole::Binding => "bound here".to_string(),
            });
        builder = builder.with_label(
            Label::new(related.span)
                .with_message(msg)
                .with_color(Color::Blue),
        );
    }

    // Add call stack frames as labels (excluding the last one which is the error site)
    // Show up to 5 frames to avoid cluttering
    let max_stack_labels = 5;
    let stack_len = error.call_stack.len();
    if stack_len > 1 {
        // Skip the last frame (it's the error site, already shown)
        let frames_to_show: Vec<_> = error
            .call_stack
            .iter()
            .take(stack_len.saturating_sub(1))
            .rev() // Show from outermost to innermost
            .take(max_stack_labels)
            .collect();

        for (i, frame) in frames_to_show.iter().rev().enumerate() {
            if let Some(frame_span) = frame.span {
                let name = format_call_frame_kind(&frame.kind);
                let msg = if i == 0 && stack_len > max_stack_labels + 1 {
                    format!(
                        "...called from {} (and {} more)",
                        name,
                        stack_len - max_stack_labels - 1
                    )
                } else {
                    format!("called from {}", name)
                };
                builder = builder.with_label(
                    Label::new(frame_span)
                        .with_message(msg)
                        .with_color(Color::Yellow)
                        .with_order(-(i as i32) - 1), // Order so they appear above error
                );
            }
        }
    }

    // Add hint as a note
    if let Some(hint) = &error.hint {
        builder = builder.with_note(format_hint(hint));
    }

    Some(builder.finish())
}

impl PartialEq for Error {
    fn eq(&self, other: &Self) -> bool {
        self.kind == other.kind && self.span == other.span
    }
}
