//! Disassembler — human-readable dump of a `CompilationUnit`.

use std::fmt::Write;

use lasso::Rodeo;

use super::compilation_unit::{CompilationUnit, DefKind};
use super::heap::{Heap, HeapObject, SeqKind};
use super::opcode::{OpCode, arg_i16, arg_u16, decode};
use super::value::{HeapKey, VMValue};

/// Produce a human-readable disassembly of a compilation unit.
pub fn disassemble(unit: &CompilationUnit, interner: &Rodeo) -> String {
    let mut out = String::new();

    // --- Doc map ---
    if !unit.docs.is_empty() {
        writeln!(out, "=== Documentation ===").unwrap();
        let mut entries: Vec<_> = unit.docs.iter().collect();
        entries.sort_by_key(|(spur, _)| interner.resolve(spur).to_string());
        for (spur, entry) in &entries {
            let name = interner.resolve(spur);
            let kind = match entry.kind {
                DefKind::Def => "def",
                DefKind::Defn => "defn",
                DefKind::Defmacro => "defmacro",
                DefKind::Native => "native",
            };
            writeln!(out, "  {} ({}) — {:?}", name, kind, entry.docstring).unwrap();
        }
        writeln!(out).unwrap();
    }

    // --- Heap ---
    if !unit.heap.objects.is_empty() {
        writeln!(out, "=== Heap ===").unwrap();
        for (i, (_key, cell)) in unit.heap.objects.iter().enumerate() {
            let desc = format_heap_object(&cell.obj, &unit.heap, interner);
            writeln!(out, "  [{}] {}", i, desc).unwrap();
        }
        writeln!(out).unwrap();
    }

    // --- Prototypes ---
    for (idx, proto) in unit.prototypes.iter().enumerate() {
        let name = proto
            .name
            .map(|s| interner.resolve(&s).to_string())
            .unwrap_or_else(|| "<anonymous>".to_string());

        writeln!(out, "=== Prototype {} '{}' ===", idx, name).unwrap();
        writeln!(
            out,
            "  arity: {}{}  locals: {}  upvalues: {}",
            proto.arity,
            if proto.is_variadic { "+" } else { "" },
            proto.locals,
            proto.upvalues,
        )
        .unwrap();

        // Constants
        if !proto.constants.is_empty() {
            writeln!(out, "  constants:").unwrap();
            for (i, c) in proto.constants.iter().enumerate() {
                writeln!(
                    out,
                    "    [{}] {}",
                    i,
                    format_constant(c, &unit.heap, interner)
                )
                .unwrap();
            }
        }

        // Upvalue descriptors
        if !proto.upvalue_desc.is_empty() {
            writeln!(out, "  upvalue_desc:").unwrap();
            for (i, uv) in proto.upvalue_desc.iter().enumerate() {
                writeln!(out, "    [{}] {:?}", i, uv).unwrap();
            }
        }

        // Bytecode
        writeln!(out, "  code:").unwrap();
        let code = &proto.code;
        let mut ip = 0usize;
        while ip < code.len() {
            let instr = code[ip];
            let (op_byte, a1, a2, a3) = decode(instr);
            let op_name = match OpCode::from_u8(op_byte) {
                Some(op) => format!("{:?}", op),
                None => format!("UNKNOWN({})", op_byte),
            };

            let comment =
                instruction_comment(op_byte, a1, a2, a3, &proto.constants, &unit.heap, interner);
            if comment.is_empty() {
                writeln!(out, "    {:04}  {} {} {} {}", ip, op_name, a1, a2, a3).unwrap();
            } else {
                writeln!(
                    out,
                    "    {:04}  {} {} {} {}  ; {}",
                    ip, op_name, a1, a2, a3, comment
                )
                .unwrap();
            }
            ip += 1;
        }

        writeln!(out).unwrap();
    }

    out
}

fn format_constant(val: &VMValue, heap: &Heap, interner: &Rodeo) -> String {
    match val {
        VMValue::Nil => "nil".into(),
        VMValue::Bool(b) => b.to_string(),
        VMValue::Int(n) => n.to_string(),
        VMValue::Float(f) => format!("{}", f),
        VMValue::Ratio { numer, denom } => format!("{}/{}", numer, denom),
        VMValue::Symbol(s) => format!("'{}", interner.resolve(s)),
        VMValue::Keyword(k) => format!(":{}", interner.resolve(k)),
        VMValue::NativeFn(idx) => format!("#<native {}>", idx),
        VMValue::HeapRef(key) => format_heap_ref(*key, heap, interner),
    }
}

fn format_heap_ref(key: HeapKey, heap: &Heap, interner: &Rodeo) -> String {
    match heap.get(key) {
        Some(obj) => format_heap_object(obj, heap, interner),
        None => "#<invalid-ref>".into(),
    }
}

fn format_heap_object(obj: &HeapObject, heap: &Heap, interner: &Rodeo) -> String {
    match obj {
        HeapObject::String(s) => format!("{:?}", s.as_str()),
        HeapObject::Seq(seq) => {
            let items: Vec<String> = seq
                .data
                .iter()
                .map(|v| format_constant(v, heap, interner))
                .collect();
            match seq.kind {
                SeqKind::List => format!("({})", items.join(" ")),
                SeqKind::Vector => format!("[{}]", items.join(" ")),
            }
        }
        HeapObject::Set(set) => {
            let items: Vec<String> = set
                .iter()
                .map(|v| format_constant(v, heap, interner))
                .collect();
            format!("#{{{}}}", items.join(" "))
        }
        HeapObject::Map(map) => {
            let pairs: Vec<String> = map
                .iter()
                .map(|(k, v)| {
                    format!(
                        "{} {}",
                        format_constant(k, heap, interner),
                        format_constant(v, heap, interner)
                    )
                })
                .collect();
            format!("{{{}}}", pairs.join(", "))
        }
        HeapObject::Closure(c) => {
            format!(
                "#<closure clauses={} upvalues={}>",
                c.clauses.len(),
                c.upvalues.len()
            )
        }
        HeapObject::ClosureTemplate(ct) => {
            format!("#<closure-template clauses={}>", ct.clauses.len())
        }
        HeapObject::Continuation(_) => "#<continuation>".into(),
        HeapObject::Atom(a) => format!("#<atom {}>", format_constant(&a.value, heap, interner)),
        HeapObject::Optic(_) => "#<optic>".into(),
        HeapObject::KeyBox(v) => format!("#<keybox {}>", format_constant(v, heap, interner)),
        HeapObject::Regex(r) => format!("#\"{}\"", r.as_str()),
        HeapObject::Effect(e) => {
            let name = e
                .name
                .map(|s| interner.resolve(&s).to_string())
                .unwrap_or_else(|| format!("{:?}", e.id));
            let ops: Vec<String> = e
                .ops
                .iter()
                .map(|(s, arity)| format!("{}({})", interner.resolve(s), arity))
                .collect();
            format!("#<effect {} [{}]>", name, ops.join(", "))
        }
        HeapObject::Variant(inst) => {
            format!("#<variant tag={}>", inst.tag)
        }
    }
}

fn instruction_comment(
    op: u8,
    a1: u8,
    a2: u8,
    _a3: u8,
    constants: &[VMValue],
    heap: &Heap,
    interner: &Rodeo,
) -> String {
    let opcode = OpCode::from_u8(op);
    match opcode {
        Some(OpCode::Const) => {
            let idx = arg_u16(a1, a2) as usize;
            constants
                .get(idx)
                .map(|c| format_constant(c, heap, interner))
                .unwrap_or_default()
        }
        Some(OpCode::GetGlobal | OpCode::SetGlobal | OpCode::DefGlobal) => {
            let idx = arg_u16(a1, a2) as usize;
            constants
                .get(idx)
                .map(|c| format_constant(c, heap, interner))
                .unwrap_or_default()
        }
        Some(OpCode::Jump | OpCode::JumpIfFalse | OpCode::JumpIfTrue) => {
            let offset = arg_i16(a1, a2);
            format!("offset {}", offset)
        }
        Some(OpCode::MakeClosure) => {
            let proto_idx = arg_u16(a1, a2);
            format!("proto {}", proto_idx)
        }
        Some(OpCode::GetGlobalSlot) => {
            let slot = arg_u16(a1, a2);
            format!("slot {}", slot)
        }
        Some(OpCode::CallNative) => {
            let native_idx = arg_u16(a1, a2);
            format!("native {} nargs={}", native_idx, _a3)
        }
        _ => String::new(),
    }
}
