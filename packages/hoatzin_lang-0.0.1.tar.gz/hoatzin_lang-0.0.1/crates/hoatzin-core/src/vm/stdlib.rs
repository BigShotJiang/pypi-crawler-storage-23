//! VM Standard Library - Macros defined in Hoatzin source
//!
//! These macros are compiled and executed in the VM during compilation.

/// Macro definitions as Hoatzin source code.
/// These are loaded into the Runtime at initialization.
pub const MACROS: &str = include_str!("stdlib.clj");
