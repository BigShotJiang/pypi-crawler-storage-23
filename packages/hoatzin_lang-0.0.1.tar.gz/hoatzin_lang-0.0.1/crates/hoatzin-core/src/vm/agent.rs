//! Agent mode: append-only revision tracking for REPL sessions
//!
//! When agent mode is enabled, top-level `def` and updater forms automatically
//! create numbered revisions (e.g. `meow@1`, `meow@2`) so prior states remain
//! inspectable. This is a REPL-layer extension — core evaluator semantics are
//! unchanged.

use std::collections::HashMap;

use super::value::VMValue;
use crate::Value;

/// A single revision in a symbol's history.
#[derive(Debug, Clone)]
pub struct Revision {
    pub index: u32,
    pub value: VMValue,
    pub parent: Option<u32>,
}

/// Per-root-symbol revision journal.
#[derive(Debug)]
pub struct SymbolJournal {
    pub root: String,
    pub next_index: u32,
    pub revisions: Vec<Revision>,
}

impl SymbolJournal {
    fn new(root: String) -> Self {
        SymbolJournal {
            root,
            next_index: 1,
            revisions: Vec::new(),
        }
    }

    fn latest(&self) -> Option<&Revision> {
        self.revisions.last()
    }
}

/// Top-level journal tracking all symbol revisions.
#[derive(Debug, Default)]
pub struct AgentJournal {
    pub journals: HashMap<String, SymbolJournal>,
}

impl AgentJournal {
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a new revision for `root_name`. Returns `(index, parent_index)` if
    /// a revision was created, or `None` if skipped (no-op dedup or `@` in name).
    pub fn record(
        &mut self,
        root_name: &str,
        value: VMValue,
        parent: Option<u32>,
    ) -> Option<(u32, Option<u32>)> {
        // Skip if root name contains @ (prevents s@1@1)
        if root_name.contains('@') {
            return None;
        }

        let journal = self
            .journals
            .entry(root_name.to_string())
            .or_insert_with(|| SymbolJournal::new(root_name.to_string()));

        let index = journal.next_index;
        journal.next_index += 1;
        let parent_for_rev = parent.or_else(|| journal.latest().map(|r| r.index));
        journal.revisions.push(Revision {
            index,
            value,
            parent: parent_for_rev,
        });

        Some((index, parent_for_rev))
    }

    /// Get the latest revision index for a root symbol.
    pub fn latest_index(&self, root_name: &str) -> Option<u32> {
        self.journals
            .get(root_name)
            .and_then(|j| j.latest().map(|r| r.index))
    }

    /// Get all revisions for a root symbol.
    pub fn revisions(&self, root_name: &str) -> Option<&[Revision]> {
        self.journals.get(root_name).map(|j| j.revisions.as_slice())
    }
}

/// Result of evaluating an expression in agent mode.
#[derive(Debug)]
pub struct AgentEvalResult {
    pub value: VMValue,
    pub lineage_message: Option<String>,
}

// ---------------------------------------------------------------------------
// AST classification
// ---------------------------------------------------------------------------

/// What kind of top-level form is this?
#[derive(Debug, PartialEq, Eq)]
pub enum FormKind {
    /// `(def name ...)` or `(defn name ...)`
    Def { name: String },
    /// A whitelisted updater whose first data arg is a bare symbol
    Updater { root: String },
    /// `(-> s (assoc ...) ...)` where last step is whitelisted
    /// or `(+>> optic ops... s)` where s (last arg) is a bare symbol
    ThreadedUpdater { root: String },
    /// `(revisions 'sym)` introspection query
    RevisionsQuery { symbol: String },
    /// Everything else — no revision tracking
    Other,
}

/// Data-first updaters: `(fn data ...args)` — root is `args[1]`.
const UPDATER_DATA_FIRST: &[&str] = &[
    "assoc",
    "assoc-in",
    "update",
    "update-in",
    "dissoc",
    "merge",
    "merge-with",
    "conj",
    "disj",
    "pop",
    "into",
];

/// Data-last updaters: `(fn optic/args... data)` — root is last arg.
const UPDATER_DATA_LAST: &[&str] = &["over", "sett"];

fn is_whitelisted_updater(name: &str) -> bool {
    UPDATER_DATA_FIRST.contains(&name) || UPDATER_DATA_LAST.contains(&name)
}

fn is_data_last_updater(name: &str) -> bool {
    UPDATER_DATA_LAST.contains(&name)
}

/// Extract the unqualified symbol name from a `Value`, stripping any `Meta` wrappers.
fn symbol_name(v: &Value) -> Option<&str> {
    match v.strip_meta() {
        Value::Symbol(sym) if sym.namespace.is_none() => Some(&sym.name),
        _ => None,
    }
}

/// Classify a top-level AST form for agent-mode revision tracking.
pub fn classify_form(expr: &Value) -> FormKind {
    let expr = expr.strip_meta();

    let list = match expr {
        Value::List(l) if !l.is_empty() => l,
        _ => return FormKind::Other,
    };

    let head = match list.first() {
        Some(v) => v,
        None => return FormKind::Other,
    };

    let head_name = match symbol_name(head) {
        Some(n) => n,
        None => return FormKind::Other,
    };

    match head_name {
        // (def name ...) or (defn name ...)
        "def" | "defn" => {
            // Second element should be the name
            let args: Vec<_> = list.iter().collect();
            if args.len() >= 2
                && let Some(name) = symbol_name(args[1])
            {
                return FormKind::Def {
                    name: name.to_string(),
                };
            }
            FormKind::Other
        }

        // (revisions 'sym) — quoted symbol
        "revisions" => {
            let args: Vec<_> = list.iter().collect();
            if args.len() == 2 {
                // The argument should be a quoted symbol: (quote sym)
                let arg = args[1].strip_meta();
                if let Value::List(inner) = arg {
                    let inner_items: Vec<_> = inner.iter().collect();
                    if inner_items.len() == 2
                        && symbol_name(inner_items[0]) == Some("quote")
                        && let Some(sym) = symbol_name(inner_items[1])
                    {
                        return FormKind::RevisionsQuery {
                            symbol: sym.to_string(),
                        };
                    }
                }
            }
            FormKind::Other
        }

        // (-> s ...) or (->> s ...)
        "->" | "->>" => {
            let args: Vec<_> = list.iter().collect();
            if args.len() < 3 {
                return FormKind::Other;
            }
            // Second element (seed) must be a bare symbol
            let root = match symbol_name(args[1]) {
                Some(n) => n.to_string(),
                None => return FormKind::Other,
            };
            // Last threaded step must be a whitelisted updater
            let last_step = args[args.len() - 1].strip_meta();
            let last_step_name = match last_step {
                Value::List(l) => l.first().and_then(symbol_name),
                Value::Symbol(sym) if sym.namespace.is_none() => Some(sym.name.as_ref()),
                _ => None,
            };
            match last_step_name {
                Some(n) if is_whitelisted_updater(n) => FormKind::ThreadedUpdater { root },
                _ => FormKind::Other,
            }
        }

        // (+>> optic ops... s) — last arg is the data (bare symbol)
        "+>>" => {
            let args: Vec<_> = list.iter().collect();
            if args.len() < 3 {
                return FormKind::Other;
            }
            // Last argument is the data root
            let last = args[args.len() - 1];
            match symbol_name(last) {
                Some(n) => FormKind::ThreadedUpdater {
                    root: n.to_string(),
                },
                None => FormKind::Other,
            }
        }

        // Direct updater call: data-first (assoc s ...) or data-last (sett optic val s)
        name if is_whitelisted_updater(name) => {
            let args: Vec<_> = list.iter().collect();
            if args.len() < 2 {
                return FormKind::Other;
            }
            let root_pos = if is_data_last_updater(name) {
                args.len() - 1
            } else {
                1
            };
            if let Some(root) = symbol_name(args[root_pos]) {
                return FormKind::Updater {
                    root: root.to_string(),
                };
            }
            FormKind::Other
        }

        _ => FormKind::Other,
    }
}

/// Build a lineage message for display after recording a revision.
pub fn lineage_message(root: &str, index: u32, parent: Option<u32>) -> String {
    match parent {
        Some(p) => format!("Recorded as {}@{} (from {}@{}).", root, index, root, p),
        None => format!("Recorded as {}@{}.", root, index),
    }
}

// ---------------------------------------------------------------------------
// Tests
// ---------------------------------------------------------------------------

#[cfg(test)]
mod tests {
    use super::*;
    use crate::Value;

    fn sym(name: &str) -> Value {
        Value::symbol(name)
    }

    fn list(items: Vec<Value>) -> Value {
        Value::list_from_iter(items)
    }

    fn kw(name: &str) -> Value {
        Value::keyword(name)
    }

    #[test]
    fn test_classify_def() {
        let expr = list(vec![sym("def"), sym("meow"), Value::Int(42)]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Def {
                name: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_defn() {
        // (defn add1 [x] (+ x 1))
        let expr = list(vec![
            sym("defn"),
            sym("add1"),
            Value::Vector(crate::collections::Vector::from(vec![sym("x")])),
            list(vec![sym("+"), sym("x"), Value::Int(1)]),
        ]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Def {
                name: "add1".to_string()
            }
        );
    }

    #[test]
    fn test_classify_updater() {
        // (assoc meow :a 1)
        let expr = list(vec![sym("assoc"), sym("meow"), kw("a"), Value::Int(1)]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Updater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_updater_update_in() {
        // (update-in meow [:x :y] inc)
        let expr = list(vec![
            sym("update-in"),
            sym("meow"),
            Value::Vector(crate::collections::Vector::from(vec![kw("x"), kw("y")])),
            sym("inc"),
        ]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Updater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_updater_data_last_sett() {
        // (sett :foo 1 meow) — data-last, root is last arg
        let expr = list(vec![sym("sett"), kw("foo"), Value::Int(1), sym("meow")]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Updater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_updater_data_last_over() {
        // (over :foo inc meow) — data-last, root is last arg
        let expr = list(vec![sym("over"), kw("foo"), sym("inc"), sym("meow")]);
        assert_eq!(
            classify_form(&expr),
            FormKind::Updater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_updater_non_symbol_root() {
        // (assoc (f x) :a 1) — root is not a bare symbol
        let expr = list(vec![
            sym("assoc"),
            list(vec![sym("f"), sym("x")]),
            kw("a"),
            Value::Int(1),
        ]);
        assert_eq!(classify_form(&expr), FormKind::Other);
    }

    #[test]
    fn test_classify_threading_updater_last() {
        // (-> meow (assoc :a 1))
        let expr = list(vec![
            sym("->"),
            sym("meow"),
            list(vec![sym("assoc"), kw("a"), Value::Int(1)]),
        ]);
        assert_eq!(
            classify_form(&expr),
            FormKind::ThreadedUpdater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_threading_non_updater_last() {
        // (-> meow (assoc :a 1) count) — last step is not whitelisted
        let expr = list(vec![
            sym("->"),
            sym("meow"),
            list(vec![sym("assoc"), kw("a"), Value::Int(1)]),
            sym("count"),
        ]);
        assert_eq!(classify_form(&expr), FormKind::Other);
    }

    #[test]
    fn test_classify_read_only() {
        // (get meow :a) — not whitelisted
        let expr = list(vec![sym("get"), sym("meow"), kw("a")]);
        assert_eq!(classify_form(&expr), FormKind::Other);
    }

    #[test]
    fn test_classify_revisions_query() {
        // (revisions 'meow)
        let expr = list(vec![
            sym("revisions"),
            list(vec![sym("quote"), sym("meow")]),
        ]);
        assert_eq!(
            classify_form(&expr),
            FormKind::RevisionsQuery {
                symbol: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_plus_thread_updater() {
        // (+>> :x (assoc :a 1) meow) — last arg is bare symbol
        let expr = list(vec![
            sym("+>>"),
            kw("x"),
            list(vec![sym("assoc"), kw("a"), Value::Int(1)]),
            sym("meow"),
        ]);
        assert_eq!(
            classify_form(&expr),
            FormKind::ThreadedUpdater {
                root: "meow".to_string()
            }
        );
    }

    #[test]
    fn test_classify_plus_thread_non_symbol() {
        // (+>> :x (assoc :a 1) (f x)) — last arg is not a bare symbol
        let expr = list(vec![
            sym("+>>"),
            kw("x"),
            list(vec![sym("assoc"), kw("a"), Value::Int(1)]),
            list(vec![sym("f"), sym("x")]),
        ]);
        assert_eq!(classify_form(&expr), FormKind::Other);
    }

    #[test]
    fn test_journal_basic() {
        let mut journal = AgentJournal::new();
        let result = journal.record("meow", VMValue::Int(42), None);
        assert!(result.is_some());
        let (idx, parent) = result.unwrap();
        assert_eq!(idx, 1);
        assert_eq!(parent, None);
    }

    #[test]
    fn test_journal_sequential() {
        let mut journal = AgentJournal::new();
        journal.record("meow", VMValue::Int(1), None);
        let result = journal.record("meow", VMValue::Int(2), None);
        let (idx, parent) = result.unwrap();
        assert_eq!(idx, 2);
        assert_eq!(parent, Some(1));
    }

    #[test]
    fn test_journal_at_sign_skip() {
        let mut journal = AgentJournal::new();
        let result = journal.record("meow@1", VMValue::Int(42), None);
        assert!(result.is_none());
    }

    #[test]
    fn test_lineage_message_no_parent() {
        let msg = lineage_message("meow", 1, None);
        assert_eq!(msg, "Recorded as meow@1.");
    }

    #[test]
    fn test_lineage_message_with_parent() {
        let msg = lineage_message("meow", 2, Some(1));
        assert_eq!(msg, "Recorded as meow@2 (from meow@1).");
    }
}
