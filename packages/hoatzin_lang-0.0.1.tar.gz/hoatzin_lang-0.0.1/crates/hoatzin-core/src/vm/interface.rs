//! High-level VM interface
//!
//! Combines parsing, compilation, and execution into a simple API.

use lasso::{Rodeo, Spur};
use rustc_hash::FxHashMap;

use super::agent::{self, AgentEvalResult, AgentJournal, FormKind};
use super::compilation_unit::CompilationUnit;
use super::compiler::{CompileError, Compiler};
use super::error::RichVMError;
use super::heap::{SeqData, SeqKind};
use super::value::VMValue;
use super::{HeapKey, VM};

use crate::{Reader, Value};

/// Combined error type
#[derive(Debug)]
pub enum EvalError {
    Parse(crate::Error),
    Compile(CompileError),
    Runtime(RichVMError),
}

impl std::fmt::Display for EvalError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            EvalError::Parse(e) => write!(f, "{}", e),
            EvalError::Compile(e) => write!(f, "compile error: {}", e),
            EvalError::Runtime(e) => write!(f, "{}", e),
        }
    }
}

impl std::error::Error for EvalError {}

impl From<CompileError> for EvalError {
    fn from(e: CompileError) -> Self {
        EvalError::Compile(e)
    }
}

impl From<RichVMError> for EvalError {
    fn from(e: RichVMError) -> Self {
        EvalError::Runtime(e)
    }
}

/// Runtime environment - the VM owns the interner
pub struct Runtime {
    vm: VM,
    /// Macros defined in this runtime (name -> closure key in VM heap)
    macros: FxHashMap<Spur, HeapKey>,
}

impl Runtime {
    /// Create a new runtime
    pub fn new() -> Self {
        // VM::new() creates the interner and registers natives
        Runtime {
            vm: VM::new(),
            macros: FxHashMap::default(),
        }
    }

    /// Create a new runtime with standard library loaded
    pub fn with_stdlib() -> Result<Self, EvalError> {
        let mut rt = Self::new();
        rt.load_stdlib()?;
        Ok(rt)
    }

    /// Load the standard library macros and functions
    pub fn load_stdlib(&mut self) -> Result<(), EvalError> {
        let source_id = self.vm.interner_mut().get_or_intern("<stdlib>");
        self.eval_str_with_source(super::stdlib::MACROS, source_id)?;

        // Cache the ReduceSignal/Reduced tag for fast checking in native_reduce
        let reduced_spur = self.vm.interner_mut().get_or_intern("ReduceSignal");
        if let Some((type_id, _)) = self.vm.type_registry().get_by_name(reduced_spur) {
            // Reduced is variant index 0 in ReduceSignal
            self.vm.reduced_tag = Some((type_id.0 as u32) << 8 | 0);
        }

        Ok(())
    }

    /// Evaluate source code string
    pub fn eval_str(&mut self, source: &str) -> Result<VMValue, EvalError> {
        // Create a default source_id for error reporting
        let source_id = self.vm.interner_mut().get_or_intern("<eval>");
        self.eval_str_with_source(source, source_id)
    }

    /// Compile source code string to a CompilationUnit without executing it.
    /// This still performs macro expansion using the current runtime macros.
    pub fn compile_str(&mut self, source: &str) -> Result<CompilationUnit, EvalError> {
        let source_id = self.vm.interner_mut().get_or_intern("<compile>");
        self.compile_str_with_source(source, source_id)
    }

    /// Evaluate source code string with a specific source identifier for error reporting
    pub fn eval_str_with_source(
        &mut self,
        source: &str,
        source_id: Spur,
    ) -> Result<VMValue, EvalError> {
        // Parse with source_id so spans have the correct source identifier
        let exprs =
            crate::reader::read_str_with_source(source, source_id).map_err(EvalError::Parse)?;

        if exprs.is_empty() {
            return Ok(VMValue::Nil);
        }

        // Compile and run each expression
        let mut result = VMValue::Nil;
        for expr in &exprs {
            result = self.eval_expr(expr)?;
        }

        Ok(result)
    }

    /// Evaluate source code in agent mode, tracking revisions for `def` and updater forms.
    pub fn eval_str_agent(
        &mut self,
        source: &str,
        source_id: Spur,
        journal: &mut AgentJournal,
    ) -> Result<Vec<AgentEvalResult>, EvalError> {
        let exprs =
            crate::reader::read_str_with_source(source, source_id).map_err(EvalError::Parse)?;

        if exprs.is_empty() {
            return Ok(vec![AgentEvalResult {
                value: VMValue::Nil,
                lineage_message: None,
            }]);
        }

        let mut results = Vec::new();
        for expr in &exprs {
            let kind = agent::classify_form(expr);

            // Handle revisions query without eval
            if let FormKind::RevisionsQuery { ref symbol } = kind {
                let result = self.build_revisions_result(journal, symbol);
                results.push(AgentEvalResult {
                    value: result,
                    lineage_message: None,
                });
                continue;
            }

            let value = self.eval_expr(expr)?;

            let lineage_message = match kind {
                FormKind::Def { ref name } => {
                    self.maybe_record_revision(journal, name, value, None)
                }
                FormKind::Updater { ref root } | FormKind::ThreadedUpdater { ref root } => {
                    let parent = journal.latest_index(root);
                    self.maybe_record_revision(journal, root, value, parent)
                }
                FormKind::RevisionsQuery { .. } => unreachable!(),
                FormKind::Other => None,
            };

            results.push(AgentEvalResult {
                value,
                lineage_message,
            });
        }

        Ok(results)
    }

    /// Record a revision and bind `root@N` as a global. Returns a lineage message
    /// if a revision was created.
    fn maybe_record_revision(
        &mut self,
        journal: &mut AgentJournal,
        root_name: &str,
        value: VMValue,
        parent: Option<u32>,
    ) -> Option<String> {
        // No-op dedup: skip if value equals latest revision
        if let Some(revisions) = journal.revisions(root_name)
            && let Some(latest) = revisions.last()
            && self.vm.values_equal(latest.value, value)
        {
            return None;
        }

        let (index, parent_idx) = journal.record(root_name, value, parent)?;

        // Bind root@N as a global
        let binding_name = format!("{}@{}", root_name, index);
        self.define(&binding_name, value);

        Some(agent::lineage_message(root_name, index, parent_idx))
    }

    /// Build the result of `(revisions 'sym)` — a vector of maps.
    fn build_revisions_result(&mut self, journal: &AgentJournal, symbol: &str) -> VMValue {
        let revisions = match journal.revisions(symbol) {
            Some(r) => r,
            None => return VMValue::Nil,
        };

        let mut items = crate::collections::Vector::new();
        for rev in revisions {
            let mut map = crate::collections::HashMap::new();

            // :index
            let index_key = VMValue::Keyword(self.vm.interner_mut().get_or_intern("index"));
            let index_val = VMValue::Int(rev.index as i64);
            map = self.vm.map_insert(&map, index_key, index_val);

            // :name
            let name_key = VMValue::Keyword(self.vm.interner_mut().get_or_intern("name"));
            let name_str = format!("{}@{}", symbol, rev.index);
            let name_val = self.vm.alloc_string(name_str);
            map = self.vm.map_insert(&map, name_key, name_val);

            // :value
            let value_key = VMValue::Keyword(self.vm.interner_mut().get_or_intern("value"));
            map = self.vm.map_insert(&map, value_key, rev.value);

            let map_key = self.vm.intern_map(map);
            items.push_back(VMValue::HeapRef(map_key));
        }

        let seq = SeqData {
            data: items,
            kind: SeqKind::Vector,
        };
        let key = self.vm.intern_seq(seq);
        VMValue::HeapRef(key)
    }

    /// Compile source code string with a specific source identifier.
    /// Returns a CompilationUnit suitable for disassembly.
    pub fn compile_str_with_source(
        &mut self,
        source: &str,
        source_id: Spur,
    ) -> Result<CompilationUnit, EvalError> {
        let exprs =
            crate::reader::read_str_with_source(source, source_id).map_err(EvalError::Parse)?;

        let mut compiler = Compiler::with_vm(&mut self.vm);
        compiler.set_macros(self.macros.clone());

        for expr in &exprs {
            compiler.compile(expr)?;
        }

        let new_macros = compiler.macros().clone();
        let unit = compiler.finish();

        // Keep macro closures alive across compilations.
        self.macros = new_macros;
        let macro_roots: Vec<HeapKey> = self.macros.values().copied().collect();
        self.vm.set_external_roots(macro_roots);

        Ok(unit)
    }

    /// Evaluate a single AST expression
    pub fn eval_expr(&mut self, expr: &Value) -> Result<VMValue, EvalError> {
        // Use with_vm() for macro support.
        // The compiler gets access to the VM for macro expansion.
        let (mut protos, heap, proto_idx, new_macros, docs) = {
            let mut compiler = Compiler::with_vm(&mut self.vm);

            // Transfer existing macros to the compiler
            compiler.set_macros(self.macros.clone());

            let proto_idx = compiler.compile(expr)?;

            // Capture any new macros defined during compilation
            let new_macros = compiler.macros().clone();

            let unit = compiler.finish();
            (unit.prototypes, unit.heap, proto_idx, new_macros, unit.docs)
        };

        // Merge documentation from this compilation unit into the VM
        self.vm.merge_docs(docs);

        // Offset proto_idx by VM's current prototype count
        let proto_offset = self.vm.prototype_count();

        // Import compiler heap into VM heap and get key remapping
        let key_map = self.vm.heap_mut().import_from(heap);
        let imported_keys: Vec<HeapKey> = key_map.values().copied().collect();

        // Remap HeapKey references in prototype constants and offset proto refs
        for proto in protos.iter_mut() {
            proto.remap_heap_keys(&key_map);
            proto.offset_proto_refs(proto_offset);
        }
        self.vm
            .heap_mut()
            .offset_proto_refs(proto_offset, imported_keys);

        // Macros are compiled into (and allocated within) the VM directly during compilation,
        // so their HeapKeys are already valid in `self.vm` and must not be remapped via `key_map`.
        self.macros = new_macros;

        // Register macro closures as external GC roots so they survive collection
        let macro_roots: Vec<HeapKey> = self.macros.values().copied().collect();
        self.vm.set_external_roots(macro_roots);

        // Transfer prototypes to VM
        for proto in protos {
            self.vm.add_prototype(proto);
        }

        // Run with offset-adjusted index
        let actual_proto_idx = proto_offset + proto_idx;
        let result = self.vm.run(actual_proto_idx, &[])?;
        Ok(result)
    }

    /// Get the underlying VM
    pub fn vm(&self) -> &VM {
        &self.vm
    }

    /// Get mutable VM
    pub fn vm_mut(&mut self) -> &mut VM {
        &mut self.vm
    }

    /// Define a global value
    pub fn define(&mut self, name: &str, value: VMValue) {
        let spur = self.vm.interner_mut().get_or_intern(name);
        self.vm.set_global(spur, value);
    }

    /// Define a host callback function callable from Hoatzin code.
    ///
    /// The callback receives a mutable VM reference and a slice of arguments,
    /// and returns a `Result<VMValue, VMError>`. It is registered as a global
    /// binding and can be called like any native function.
    pub fn define_fn(
        &mut self,
        name: &str,
        func: std::rc::Rc<dyn Fn(&mut super::VM, &[super::value::VMValue]) -> Result<super::value::VMValue, super::VMError>>,
    ) {
        self.vm.register_dynamic_native(name, func);
    }

    /// Get reference to the string interner
    pub fn interner(&self) -> &Rodeo {
        self.vm.interner()
    }

    /// Get the accumulated documentation map
    pub fn docs(&self) -> &FxHashMap<Spur, super::DocEntry> {
        self.vm.docs()
    }

    /// Register a native handler for an effect by name.
    /// Returns Ok(()) if the effect exists, Err if not found.
    pub fn register_native_handler_by_name(
        &mut self,
        effect_name: &str,
        handler: super::NativeHandler,
    ) -> Result<(), EvalError> {
        let effect_id = self.vm.get_effect_id(effect_name).ok_or_else(|| {
            EvalError::Runtime(RichVMError {
                kind: super::VMError::TypeError("effect not found"),
                span: None,
                stack_trace: Vec::new(),
            })
        })?;
        self.vm.register_native_handler(effect_id, handler);
        Ok(())
    }

    /// Register a native handler for an effect by EffectId.
    pub fn register_native_handler(
        &mut self,
        effect_id: super::EffectId,
        handler: super::NativeHandler,
    ) {
        self.vm.register_native_handler(effect_id, handler);
    }

    /// Get the EffectId for an effect by name.
    pub fn get_effect_id(&self, name: &str) -> Option<super::EffectId> {
        self.vm.get_effect_id(name)
    }
}

impl Default for Runtime {
    fn default() -> Self {
        Self::new()
    }
}

/// One-shot evaluation (creates fresh runtime)
pub fn eval(source: &str) -> Result<VMValue, EvalError> {
    let mut rt = Runtime::new();
    rt.eval_str(source)
}

/// Compile source to prototypes without running
pub fn compile(source: &str) -> Result<CompilationUnit, EvalError> {
    let mut reader = Reader::new(source);
    let exprs = reader.read_all().map_err(EvalError::Parse)?;

    // Create a temporary VM just for its interner
    let mut vm = VM::new();
    let mut compiler = Compiler::new(vm.interner_mut());
    for expr in &exprs {
        compiler.compile(expr)?;
    }

    Ok(compiler.finish())
}

#[cfg(test)]
mod tests {
    use super::super::HeapObject;
    use super::*;

    fn assert_vm_string(rt: &Runtime, value: VMValue, expected: &str) {
        match value {
            VMValue::HeapRef(key) => match rt.vm().heap().get(key) {
                Some(HeapObject::String(s)) => assert_eq!(s.as_str(), expected),
                other => panic!(
                    "expected heap string, got {:?}",
                    other.map(|_| "<non-string>")
                ),
            },
            other => panic!("expected string, got {:?}", other),
        }
    }

    #[test]
    fn test_runtime_creation() {
        let rt = Runtime::new();
        assert!(rt.vm().heap().objects.is_empty() == false); // optic singletons
    }

    #[test]
    fn test_literal() {
        let result = eval("42").unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_if_true() {
        let result = eval("(if true 1 2)").unwrap();
        assert_eq!(result, VMValue::Int(1));
    }

    #[test]
    fn test_name_and_namespace() {
        let mut rt = Runtime::with_stdlib().unwrap();

        let result = rt.eval_str("(name 'foo)").unwrap();
        assert_vm_string(&rt, result, "foo");

        let result = rt.eval_str("(name :a/b)").unwrap();
        assert_vm_string(&rt, result, "b");

        let result = rt.eval_str("(namespace :a/b)").unwrap();
        assert_vm_string(&rt, result, "a");

        let result = rt.eval_str("(namespace 'foo)").unwrap();
        assert_eq!(result, VMValue::Nil);

        let result = rt.eval_str("(name \"bar\")").unwrap();
        assert_vm_string(&rt, result, "bar");
    }

    #[test]
    fn test_if_false() {
        let result = eval("(if false 1 2)").unwrap();
        assert_eq!(result, VMValue::Int(2));
    }

    #[test]
    fn test_if_no_else() {
        let result = eval("(if false 1)").unwrap();
        assert_eq!(result, VMValue::Nil);
    }

    #[test]
    fn test_comparison() {
        assert_eq!(eval("(<= 5 10)").unwrap(), VMValue::Bool(true));
        assert_eq!(eval("(<= 10 5)").unwrap(), VMValue::Bool(false));
        assert_eq!(eval("(< 5 10)").unwrap(), VMValue::Bool(true));
        assert_eq!(eval("(> 10 5)").unwrap(), VMValue::Bool(true));
        assert_eq!(eval("(>= 10 10)").unwrap(), VMValue::Bool(true));
    }

    #[test]
    fn test_simple_fn() {
        let result = eval("((fn [x] x) 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_fn_arithmetic() {
        let result = eval("((fn [x y] (+ x y)) 3 4)").unwrap();
        assert_eq!(result, VMValue::Int(7));
    }

    #[test]
    fn test_def_and_call() {
        let mut rt = Runtime::new();
        rt.eval_str("(def add1 (fn [x] (+ x 1)))").unwrap();
        let result = rt.eval_str("(add1 5)").unwrap();
        assert_eq!(result, VMValue::Int(6));
    }

    #[test]
    fn test_recursive_fn() {
        let mut rt = Runtime::new();
        rt.eval_str("(def fib (fn [n] (if (<= n 1) n (+ (fib (- n 1)) (fib (- n 2))))))")
            .unwrap();
        let result = rt.eval_str("(fib 10)").unwrap();
        assert_eq!(result, VMValue::Int(55));
    }

    #[test]
    fn test_fib_20() {
        let mut rt = Runtime::new();
        rt.eval_str("(def fib (fn [n] (if (<= n 1) n (+ (fib (- n 1)) (fib (- n 2))))))")
            .unwrap();

        // Measure time for fib(20)
        let start = std::time::Instant::now();
        let result = rt.eval_str("(fib 20)").unwrap();
        let elapsed = start.elapsed();

        assert_eq!(result, VMValue::Int(6765));
        println!("fib(20) = 6765, elapsed: {:?}", elapsed);

        // Target: < 1ms (currently tree-walker takes 166ms)
        // This is an informational check - may vary by machine
    }

    // --- Phase 2: Closures and Let ---

    #[test]
    fn test_let_simple() {
        let result = eval("(let [x 1 y 2] (+ x y))").unwrap();
        assert_eq!(result, VMValue::Int(3));
    }

    #[test]
    fn test_let_nested() {
        let result = eval("(let [x 1] (let [y 2] (+ x y)))").unwrap();
        assert_eq!(result, VMValue::Int(3));
    }

    #[test]
    fn test_let_shadowing() {
        let result = eval("(let [x 1] (let [x 2] x))").unwrap();
        assert_eq!(result, VMValue::Int(2));
    }

    #[test]
    fn test_closure_capture() {
        let mut rt = Runtime::new();
        rt.eval_str("(def make-adder (fn [x] (fn [y] (+ x y))))")
            .unwrap();
        rt.eval_str("(def add5 (make-adder 5))").unwrap();
        let result = rt.eval_str("(add5 10)").unwrap();
        assert_eq!(result, VMValue::Int(15));
    }

    #[test]
    fn test_closure_multiple_captures() {
        let mut rt = Runtime::new();
        rt.eval_str("(def make-pair-fn (fn [a b] (fn [] (+ a b))))")
            .unwrap();
        rt.eval_str("(def sum-3-4 (make-pair-fn 3 4))").unwrap();
        let result = rt.eval_str("(sum-3-4)").unwrap();
        assert_eq!(result, VMValue::Int(7));
    }

    // --- Phase 3: Collections ---

    #[test]
    fn test_vector_literal() {
        let mut rt = Runtime::new();
        // Vector literals are compiled and created on the heap
        let _result = rt.eval_str("[1 2 3]").unwrap();
        // Just verify it doesn't crash - we can't easily compare heap values
    }

    #[test]
    fn test_empty_list() {
        let result = eval("()").unwrap();
        // Empty list literal compiles to MakeList 0
        assert!(matches!(result, VMValue::HeapRef(_)));
    }

    // --- Phase 4: Loop/Recur ---

    #[test]
    fn test_loop_simple() {
        let result = eval("(loop [n 0] (if (>= n 5) n (recur (+ n 1))))").unwrap();
        assert_eq!(result, VMValue::Int(5));
    }

    #[test]
    fn test_loop_sum() {
        let result =
            eval("(loop [sum 0 i 0] (if (> i 10) sum (recur (+ sum i) (+ i 1))))").unwrap();
        assert_eq!(result, VMValue::Int(55)); // 0+1+2+...+10 = 55
    }

    #[test]
    fn test_fib_tail_recursive() {
        let mut rt = Runtime::new();
        rt.eval_str(
            "(def fib-tail (fn [n] (loop [a 0 b 1 i n] (if (= i 0) a (recur b (+ a b) (- i 1))))))",
        )
        .unwrap();
        let result = rt.eval_str("(fib-tail 20)").unwrap();
        assert_eq!(result, VMValue::Int(6765));
    }

    #[test]
    fn test_fib_tail_recursive_perf() {
        let mut rt = Runtime::new();
        rt.eval_str(
            "(def fib-tail (fn [n] (loop [a 0 b 1 i n] (if (= i 0) a (recur b (+ a b) (- i 1))))))",
        )
        .unwrap();

        let start = std::time::Instant::now();
        let result = rt.eval_str("(fib-tail 90)").unwrap();
        let elapsed = start.elapsed();

        // fib(90) = 2880067194370816120
        assert_eq!(result, VMValue::Int(2880067194370816120));
        println!("fib-tail(90) elapsed: {:?}", elapsed);
    }

    // --- Regex tests ---

    #[test]
    fn test_re_find() {
        let mut rt = Runtime::new();
        // Find first match
        let result = rt
            .eval_str(r#"(re-find (re-pattern "\\d+") "abc123def456")"#)
            .unwrap();
        // Should find "123"
        assert_vm_string(&rt, result, "123");
    }

    #[test]
    fn test_re_find_no_match() {
        let result = eval(r#"(re-find (re-pattern "\\d+") "abc")"#).unwrap();
        assert_eq!(result, VMValue::Nil);
    }

    #[test]
    fn test_re_matches() {
        let mut rt = Runtime::new();
        // Full match
        let result = rt
            .eval_str(r#"(re-matches (re-pattern "\\d+") "123")"#)
            .unwrap();
        assert_vm_string(&rt, result, "123");
    }

    #[test]
    fn test_re_matches_no_match() {
        let result = eval(r#"(re-matches (re-pattern "\\d+") "abc123")"#).unwrap();
        // Should be nil because "abc123" doesn't fully match \\d+
        assert_eq!(result, VMValue::Nil);
    }

    #[test]
    fn test_re_seq() {
        let mut rt = Runtime::new();
        // Find all matches
        let result = rt
            .eval_str(r#"(count (re-seq (re-pattern "\\d+") "a1b22c333"))"#)
            .unwrap();
        // Should find 3 matches: "1", "22", "333"
        assert_eq!(result, VMValue::Int(3));
    }

    // --- Effects Tests ---

    #[test]
    fn test_effect_creation() {
        let mut rt = Runtime::new();
        // Create an effect with a yield operation
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Check that it's an effect
        let result = rt.eval_str("(effect? gen)").unwrap();
        assert_eq!(result, VMValue::Bool(true));
    }

    #[test]
    fn test_effect_unique_ids() {
        let mut rt = Runtime::new();
        // Create two effects
        rt.eval_str("(def eff1 (effect (op1 [])))").unwrap();
        rt.eval_str("(def eff2 (effect (op2 [])))").unwrap();
        // They should both be effects
        let result1 = rt.eval_str("(effect? eff1)").unwrap();
        let result2 = rt.eval_str("(effect? eff2)").unwrap();
        assert_eq!(result1, VMValue::Bool(true));
        assert_eq!(result2, VMValue::Bool(true));
    }

    #[test]
    fn test_qualified_symbol_compiles() {
        let mut rt = Runtime::new();
        // Create an effect with yield operation
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Define a handler for the effect (simplified form)
        rt.eval_str("(with-handler gen (fn [v k] v) (gen/yield 42))")
            .unwrap();
        // This should compile successfully - the result is 42 (from the handler returning v)
    }

    #[test]
    fn test_basic_effect_handler_simple() {
        let mut rt = Runtime::new();
        // Create effect and test old-style perform
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // Use old-style perform to test handler
        let result = rt
            .eval_str("(with-handler exn (fn [msg k] msg) (perform exn 42))")
            .unwrap();
        // Debug: print what we got
        println!("Result: {:?}", result);
        // The handler returns the message directly (42)
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_effect_handler_with_constant() {
        let mut rt = Runtime::new();
        // Create effect and handler that returns a constant
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // Handler returns 99 regardless of input
        let result = rt
            .eval_str("(with-handler exn (fn [msg k] 99) (perform exn 42))")
            .unwrap();
        assert_eq!(result, VMValue::Int(99));
    }

    #[test]
    fn test_basic_effect_handler_qualified() {
        let mut rt = Runtime::new();
        // Create effect and handler with qualified symbol
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        let result = rt
            .eval_str("(with-handler exn (fn [msg k] msg) (exn/raise 42))")
            .unwrap();
        // The handler returns the message directly (42)
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_full_with_handler_syntax() {
        let mut rt = Runtime::new();
        // Create effect with multiple operations
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Use full syntax with :handle clause
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (gen/yield 42)
              :handle (yield [v k] v))
        "#,
            )
            .unwrap();
        // Handler returns the yielded value (42)
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_full_with_handler_body_value() {
        let mut rt = Runtime::new();
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // Body returns normally (no effect performed), returns 99
        let result = rt
            .eval_str(
                r#"
            (with-handler [exn]
              99
              :handle (raise [msg k] msg))
        "#,
            )
            .unwrap();
        assert_eq!(result, VMValue::Int(99));
    }

    #[test]
    fn test_full_with_handler_multiple_body_exprs() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Multiple body expressions, last one is returned
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (+ 1 2)
              (+ 3 4)
              :handle (yield [v k] v))
        "#,
            )
            .unwrap();
        // Body returns 7 (last expr: 3+4)
        assert_eq!(result, VMValue::Int(7));
    }

    #[test]
    fn test_abort_handler_no_resume_simple() {
        let mut rt = Runtime::new();
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // Handler does NOT call k (abort semantics)
        // Use simple syntax first to test abort mechanism
        let result = rt
            .eval_str(
                r#"
            (with-handler exn (fn [e k] :caught) (exn/raise :error))
        "#,
            )
            .unwrap();
        // Check that we got a keyword and it's "caught"
        match result {
            VMValue::Keyword(spur) => {
                let s = rt.interner().resolve(&spur);
                assert_eq!(s, "caught", "expected :caught but got :{}", s);
            }
            _ => panic!("expected keyword, got {:?}", result),
        }
    }

    #[test]
    fn test_abort_handler_no_resume_full_syntax() {
        let mut rt = Runtime::new();
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // Handler does NOT call k (abort semantics)
        // Full syntax with :handle clause
        let result = rt
            .eval_str(
                r#"
            (with-handler [exn]
              (exn/raise :error)
              :handle (raise [e k] :caught))
        "#,
            )
            .unwrap();
        // Check that we got a keyword and it's "caught"
        match result {
            VMValue::Keyword(spur) => {
                let s = rt.interner().resolve(&spur);
                assert_eq!(s, "caught", "expected :caught but got :{}", s);
            }
            _ => panic!("expected keyword, got {:?}", result),
        }
    }

    #[test]
    fn test_abort_skips_remaining_body() {
        let mut rt = Runtime::new();
        rt.eval_str("(def exn (effect (raise [msg])))").unwrap();
        // When handler aborts (doesn't call k), the remaining body code
        // should NOT execute. The handler's result should be returned.
        let result = rt
            .eval_str(
                r#"
            (with-handler [exn]
              (exn/raise :error)
              :never-reached
              :handle (raise [e k] :caught))
        "#,
            )
            .unwrap();
        // Should return :caught, not :never-reached
        match result {
            VMValue::Keyword(spur) => {
                let s = rt.interner().resolve(&spur);
                assert_eq!(s, "caught", "expected :caught but got :{}", s);
            }
            _ => panic!("expected keyword, got {:?}", result),
        }
    }

    #[test]
    fn test_abort_with_body_value() {
        let mut rt = Runtime::new();
        rt.eval_str("(def exn (effect (throw [msg])))").unwrap();
        // Handler returns the error message without calling continuation
        let result = rt
            .eval_str(
                r#"
            (with-handler [exn]
              (exn/throw "oops")
              :handle (throw [e k] e))
        "#,
            )
            .unwrap();
        // Should return the string "oops"
        assert_vm_string(&rt, result, "oops");
    }

    #[test]
    fn test_continuation_is_callable() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Just check that the continuation is a valid value
        let result = rt
            .eval_str(
                r#"
            (with-handler gen (fn [v k] k) (gen/yield 10))
        "#,
            )
            .unwrap();
        // k should be a continuation (HeapRef)
        match result {
            VMValue::HeapRef(_) => (), // OK
            other => panic!("expected HeapRef for continuation, got {:?}", other),
        }
    }

    #[test]
    fn test_resume_simple_value() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Just resume with a fixed value
        let result = rt
            .eval_str(
                r#"
            (with-handler gen (fn [v k] (k 42)) (gen/yield 10))
        "#,
            )
            .unwrap();
        // Should return 42 (the resumed value)
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_resume_add_after() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Resume then add 5
        let result = rt
            .eval_str(
                r#"
            (with-handler gen (fn [v k] (k 20)) (+ (gen/yield 10) 5))
        "#,
            )
            .unwrap();
        // (gen/yield 10) → handler calls (k 20) → continuation: 20 + 5 = 25
        assert_eq!(result, VMValue::Int(25));
    }

    #[test]
    fn test_resume_then_normal_return_simple() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Handler resumes with a value (simple syntax)
        let result = rt
            .eval_str(
                r#"
            (with-handler gen (fn [v k] (k (* v 2))) (+ (gen/yield 10) 5))
        "#,
            )
            .unwrap();
        // (gen/yield 10) → handler gets 10, calls (k 20) → continuation: 20 + 5 = 25
        assert_eq!(result, VMValue::Int(25));
    }

    #[test]
    fn test_resume_then_normal_return_full() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Handler resumes with a value (full syntax)
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (+ (gen/yield 10) 5)
              :handle (yield [v k] (k (* v 2))))
        "#,
            )
            .unwrap();
        // (gen/yield 10) → handler gets 10, calls (k 20) → continuation: 20 + 5 = 25
        assert_eq!(result, VMValue::Int(25));
    }

    #[test]
    fn test_one_shot_enforcement() {
        let mut rt = Runtime::new();
        rt.eval_str("(def eff (effect (get-k [])))").unwrap();
        rt.eval_str("(def k-ref (atom nil))").unwrap();
        // Capture continuation in an atom
        rt.eval_str(
            r#"
            (with-handler eff (fn [k] (reset! k-ref k)) (eff/get-k))
        "#,
        )
        .unwrap();
        // First call should succeed
        let first = rt.eval_str("(@k-ref :first)").unwrap();
        assert_eq!(first, VMValue::Keyword(rt.interner().get("first").unwrap()));
        // Second call should fail (one-shot)
        let second = rt.eval_str("(@k-ref :second)");
        assert!(
            second.is_err(),
            "Expected error on second resume, but got {:?}",
            second
        );
    }

    #[test]
    fn test_nested_handlers_inner_wins() {
        let mut rt = Runtime::new();
        rt.eval_str("(def outer-eff (effect (op [])))").unwrap();
        rt.eval_str("(def inner-eff (effect (op [])))").unwrap();
        // Inner handler should handle inner effect
        let result = rt
            .eval_str(
                r#"
            (with-handler outer-eff (fn [k] :outer)
              (with-handler inner-eff (fn [k] :inner)
                (inner-eff/op)))
        "#,
            )
            .unwrap();
        assert_eq!(
            result,
            VMValue::Keyword(rt.interner().get("inner").unwrap())
        );
    }

    #[test]
    fn test_nested_handlers_outer_wins() {
        let mut rt = Runtime::new();
        rt.eval_str("(def outer-eff (effect (op [])))").unwrap();
        rt.eval_str("(def inner-eff (effect (op [])))").unwrap();
        // Outer effect is unhandled by inner handler, should reach outer
        let result = rt
            .eval_str(
                r#"
            (with-handler outer-eff (fn [k] :outer)
              (with-handler inner-eff (fn [k] :inner)
                (outer-eff/op)))
        "#,
            )
            .unwrap();
        assert_eq!(
            result,
            VMValue::Keyword(rt.interner().get("outer").unwrap())
        );
    }

    #[test]
    fn test_generator_single_yield() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Single yield, cons with nil
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (gen/yield 1)
              nil
              :handle (yield [v k]
                (cons v (k nil))))
        "#,
            )
            .unwrap();
        // Should produce (1)
        match result {
            VMValue::HeapRef(key) => match rt.vm().heap().get(key) {
                Some(HeapObject::Seq(seq)) => {
                    assert_eq!(seq.data.len(), 1);
                    assert_eq!(seq.data[0], VMValue::Int(1));
                }
                _ => panic!("expected list"),
            },
            _ => panic!("expected heap ref, got {:?}", result),
        }
    }

    #[test]
    fn test_generator_pattern() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Generator that yields 1, 2, 3 and collects into a list
        // Handler builds the list by consing each yielded value
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (gen/yield 1)
              (gen/yield 2)
              (gen/yield 3)
              nil
              :handle (yield [v k]
                (cons v (k nil))))
        "#,
            )
            .unwrap();
        // Should produce (1 2 3)
        match result {
            VMValue::HeapRef(key) => match rt.vm().heap().get(key) {
                Some(HeapObject::Seq(seq)) => {
                    assert_eq!(seq.data.len(), 3);
                    assert_eq!(seq.data[0], VMValue::Int(1));
                    assert_eq!(seq.data[1], VMValue::Int(2));
                    assert_eq!(seq.data[2], VMValue::Int(3));
                }
                _ => panic!("expected list"),
            },
            _ => panic!("expected heap ref, got {:?}", result),
        }
    }

    #[test]
    fn test_generator_completion_returns_handler_body_value() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Regression: when a handler resumes with (k nil) and the handled computation
        // completes, (k nil) should return the handler body's completion value (the
        // last body expression), not the generator's return value.
        let result = rt
            .eval_str(
                r#"
            (defn gen1 []
              (gen/yield 1)
              :done)
            (with-handler [gen]
              (gen1)
              []
              :handle (yield [v k]
                (cons v (k nil))))
        "#,
            )
            .unwrap();

        match result {
            VMValue::HeapRef(key) => match rt.vm().heap().get(key) {
                Some(HeapObject::Seq(seq)) => {
                    assert_eq!(seq.data.len(), 1);
                    assert_eq!(seq.data[0], VMValue::Int(1));
                }
                _ => panic!("expected sequential result"),
            },
            other => panic!("expected heap ref, got {:?}", other),
        }
    }

    #[test]
    fn test_deep_handler_multiple_yields() {
        let mut rt = Runtime::new();
        rt.eval_str("(def gen (effect (yield [v])))").unwrap();
        // Deep handler semantics: handler stays installed for subsequent effects
        let result = rt
            .eval_str(
                r#"
            (with-handler [gen]
              (+ (gen/yield 1) (gen/yield 2))
              :handle (yield [v k] (k (* v 10))))
        "#,
            )
            .unwrap();
        // First yield: 1 → 10, second yield: 2 → 20, total: 10 + 20 = 30
        assert_eq!(result, VMValue::Int(30));
    }

    // --- Built-in Effects Tests ---

    #[test]
    fn test_builtin_exn_effect_exists() {
        let mut rt = Runtime::new();
        // exn should be defined and be an effect
        let result = rt.eval_str("(effect? exn)").unwrap();
        assert_eq!(result, VMValue::Bool(true));
    }

    #[test]
    fn test_builtin_exn_raise() {
        let mut rt = Runtime::new();
        // Test that exn/raise can be handled
        let result = rt
            .eval_str(
                r#"
            (with-handler [exn]
              (exn/raise "oops")
              :handle (raise [msg k] msg))
        "#,
            )
            .unwrap();
        assert_vm_string(&rt, result, "oops");
    }

    #[test]
    fn test_builtin_console_effect_exists() {
        let mut rt = Runtime::new();
        // console should be defined and be an effect
        let result = rt.eval_str("(effect? console)").unwrap();
        assert_eq!(result, VMValue::Bool(true));
    }

    #[test]
    fn test_builtin_console_println_handled() {
        let mut rt = Runtime::new();
        // Test that console/println can be handled
        let result = rt
            .eval_str(
                r#"
            (with-handler [console]
              (console/println "hello")
              :done
              :handle (println [v k] (k :printed)))
        "#,
            )
            .unwrap();
        assert_eq!(
            result,
            VMValue::Keyword(rt.vm().interner().get("done").unwrap())
        );
    }

    #[test]
    fn test_builtin_random_effect_exists() {
        let mut rt = Runtime::new();
        // random should be defined and be an effect
        let result = rt.eval_str("(effect? random)").unwrap();
        assert_eq!(result, VMValue::Bool(true));
    }

    #[test]
    fn test_builtin_random_rand_int_handled() {
        let mut rt = Runtime::new();
        // Test that random/rand-int can be handled with a mock
        let result = rt
            .eval_str(
                r#"
            (with-handler [random]
              (random/rand-int 100)
              :handle (rand-int [n k] (k 42)))
        "#,
            )
            .unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    // --- Macro Tests ---

    #[test]
    fn test_defmacro_identity() {
        let mut rt = Runtime::new();
        // Simple identity macro
        rt.eval_str("(defmacro identity [x] x)").unwrap();
        let result = rt.eval_str("(identity 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_defmacro_when() {
        let mut rt = Runtime::new();
        // when macro: (when test body) => (if test body nil)
        rt.eval_str("(defmacro when [test body] (list 'if test body nil))")
            .unwrap();
        let result = rt.eval_str("(when true 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
        let result2 = rt.eval_str("(when false 42)").unwrap();
        assert_eq!(result2, VMValue::Nil);
    }

    #[test]
    fn test_defmacro_unless() {
        let mut rt = Runtime::new();
        // unless macro: opposite of when
        rt.eval_str("(defmacro unless [test body] (list 'if test nil body))")
            .unwrap();
        let result = rt.eval_str("(unless false 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
        let result2 = rt.eval_str("(unless true 42)").unwrap();
        assert_eq!(result2, VMValue::Nil);
    }

    #[test]
    fn test_defmacro_twice() {
        let mut rt = Runtime::new();
        // Macro that duplicates its argument
        rt.eval_str("(defmacro twice [x] (list '+ x x))").unwrap();
        // twice 5 should be (+ 5 5) = 10
        let result = rt.eval_str("(twice 5)").unwrap();
        assert_eq!(result, VMValue::Int(10));
    }

    #[test]
    fn test_macro_used_in_expr() {
        let mut rt = Runtime::new();
        // Macro used as part of a larger expression
        rt.eval_str("(defmacro add1 [x] (list '+ x 1))").unwrap();
        let result = rt.eval_str("(* 2 (add1 5))").unwrap();
        assert_eq!(result, VMValue::Int(12)); // 2 * (5 + 1) = 12
    }

    #[test]
    fn test_nested_macro_in_body() {
        let mut rt = Runtime::new();
        // Macro expansion used in another expression
        rt.eval_str("(defmacro add1 [x] (list '+ x 1))").unwrap();
        // Nested use: (+ (add1 5) (add1 3)) => (+ (+ 5 1) (+ 3 1)) => (+ 6 4) => 10
        let result = rt.eval_str("(+ (add1 5) (add1 3))").unwrap();
        assert_eq!(result, VMValue::Int(10));
    }

    #[test]
    fn test_list_native() {
        let mut rt = Runtime::new();
        // Test the list native function used by macros
        let result = rt.eval_str("(count (list 1 2 3))").unwrap();
        assert_eq!(result, VMValue::Int(3));
    }

    #[test]
    fn test_assert_passes() {
        let mut rt = Runtime::new();
        // Assert that passes should return nil
        let result = rt.eval_str("(assert true)").unwrap();
        assert_eq!(result, VMValue::Nil);
    }

    #[test]
    fn test_assert_fails() {
        let mut rt = Runtime::new();
        // Assert that fails should return an error
        let result = rt.eval_str("(assert false)");
        assert!(result.is_err());
    }

    #[test]
    fn test_defn_simple() {
        let mut rt = Runtime::new();
        // Test defn shorthand
        rt.eval_str("(defn add1 [x] (+ x 1))").unwrap();
        let result = rt.eval_str("(add1 5)").unwrap();
        assert_eq!(result, VMValue::Int(6));
    }

    #[test]
    fn test_defn_recursive() {
        let mut rt = Runtime::new();
        // Test defn with recursion
        rt.eval_str("(defn fact [n] (if (<= n 1) 1 (* n (fact (- n 1)))))")
            .unwrap();
        let result = rt.eval_str("(fact 5)").unwrap();
        assert_eq!(result, VMValue::Int(120));
    }

    // --- Stdlib Tests ---

    #[test]
    fn test_stdlib_loads() {
        let rt = Runtime::with_stdlib();
        if let Err(e) = &rt {
            println!("Error loading stdlib: {:?}", e);
        }
        assert!(rt.is_ok());
    }

    #[test]
    fn test_stdlib_when() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(when true 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
        let result2 = rt.eval_str("(when false 42)").unwrap();
        assert_eq!(result2, VMValue::Nil);
    }

    #[test]
    fn test_stdlib_when_not() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(when-not false 42)").unwrap();
        assert_eq!(result, VMValue::Int(42));
        let result2 = rt.eval_str("(when-not true 42)").unwrap();
        assert_eq!(result2, VMValue::Nil);
    }

    #[test]
    fn test_stdlib_and_or() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(rt.eval_str("(and true true)").unwrap(), VMValue::Bool(true));
        assert_eq!(
            rt.eval_str("(and true false)").unwrap(),
            VMValue::Bool(false)
        );
        assert_eq!(rt.eval_str("(or false true)").unwrap(), VMValue::Bool(true));
        assert_eq!(
            rt.eval_str("(or false false)").unwrap(),
            VMValue::Bool(false)
        );
    }

    #[test]
    fn test_stdlib_not() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(rt.eval_str("(not true)").unwrap(), VMValue::Bool(false));
        assert_eq!(rt.eval_str("(not false)").unwrap(), VMValue::Bool(true));
        assert_eq!(rt.eval_str("(not nil)").unwrap(), VMValue::Bool(true));
    }

    #[test]
    fn test_stdlib_inc_dec() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(rt.eval_str("(inc 5)").unwrap(), VMValue::Int(6));
        assert_eq!(rt.eval_str("(dec 5)").unwrap(), VMValue::Int(4));
    }

    #[test]
    fn test_stdlib_second() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(second [1 2 3])").unwrap();
        assert_eq!(result, VMValue::Int(2));
    }

    #[test]
    fn test_stdlib_range() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(count (range 5))").unwrap();
        assert_eq!(result, VMValue::Int(5));
    }

    #[test]
    fn test_stdlib_identity() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(rt.eval_str("(identity 42)").unwrap(), VMValue::Int(42));
    }

    #[test]
    fn test_stdlib_comp() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("((comp inc inc) 5)").unwrap();
        assert_eq!(result, VMValue::Int(7));
    }

    #[test]
    fn test_stdlib_partial() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("((partial + 10) 5)").unwrap();
        assert_eq!(result, VMValue::Int(15));
    }

    #[test]
    fn test_stdlib_get_in() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(get-in {:a {:b 42}} [:a :b])").unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_stdlib_update() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(get (update {:x 1} :x inc) :x)").unwrap();
        assert_eq!(result, VMValue::Int(2));
    }

    #[test]
    fn test_stdlib_frequencies() {
        let mut rt = Runtime::with_stdlib().unwrap();
        let result = rt.eval_str("(get (frequencies [1 1 2 1 2 3]) 1)").unwrap();
        assert_eq!(result, VMValue::Int(3));
    }

    #[test]
    fn test_stdlib_every() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(
            rt.eval_str("(every? pos? [1 2 3])").unwrap(),
            VMValue::Bool(true)
        );
        assert_eq!(
            rt.eval_str("(every? pos? [1 -2 3])").unwrap(),
            VMValue::Bool(false)
        );
    }

    #[test]
    fn test_stdlib_some() {
        let mut rt = Runtime::with_stdlib().unwrap();
        assert_eq!(
            rt.eval_str("(some pos? [-1 -2 3])").unwrap(),
            VMValue::Int(3)
        );
        assert_eq!(rt.eval_str("(some pos? [-1 -2 -3])").unwrap(), VMValue::Nil);
    }

    // --- Agent Mode Integration Tests ---

    mod agent_tests {
        use super::*;
        use crate::vm::agent::AgentJournal;

        fn agent_rt() -> Runtime {
            Runtime::with_stdlib().unwrap()
        }

        fn source_id(rt: &mut Runtime) -> Spur {
            rt.vm_mut().interner_mut().get_or_intern("<test>")
        }

        #[test]
        fn test_def_creates_revision() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);
            let results = rt
                .eval_str_agent("(def meow 42)", sid, &mut journal)
                .unwrap();
            assert_eq!(results.len(), 1);
            assert_eq!(results[0].value, VMValue::Int(42));
            assert!(results[0].lineage_message.is_some());
            let msg = results[0].lineage_message.as_ref().unwrap();
            assert!(msg.contains("meow@1"), "got: {}", msg);

            // meow@1 should be bound as a global
            let val = rt.eval_str("meow@1").unwrap();
            assert_eq!(val, VMValue::Int(42));
        }

        #[test]
        fn test_updater_creates_revision_with_parent() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            // Seed
            rt.eval_str_agent("(def meow {:a 1})", sid, &mut journal)
                .unwrap();

            // Updater
            let results = rt
                .eval_str_agent("(assoc meow :b 2)", sid, &mut journal)
                .unwrap();
            assert_eq!(results.len(), 1);
            let msg = results[0].lineage_message.as_ref().unwrap();
            assert!(msg.contains("meow@2"), "got: {}", msg);
            assert!(msg.contains("from meow@1"), "got: {}", msg);
        }

        #[test]
        fn test_noop_dedup() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def meow 42)", sid, &mut journal)
                .unwrap();
            // Redefine with same value
            let results = rt
                .eval_str_agent("(def meow 42)", sid, &mut journal)
                .unwrap();
            assert!(
                results[0].lineage_message.is_none(),
                "expected no-op dedup, got: {:?}",
                results[0].lineage_message
            );
        }

        #[test]
        fn test_failure_atomicity() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def meow 42)", sid, &mut journal)
                .unwrap();

            // This should fail (undefined function)
            let result = rt.eval_str_agent("(def meow (undefined-fn 1))", sid, &mut journal);
            assert!(result.is_err());

            // Should still only have 1 revision
            assert_eq!(journal.latest_index("meow"), Some(1));
        }

        #[test]
        fn test_at_sign_in_name_skip() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            let results = rt
                .eval_str_agent("(def meow@1 42)", sid, &mut journal)
                .unwrap();
            assert!(
                results[0].lineage_message.is_none(),
                "expected skip for @ in name"
            );
        }

        #[test]
        fn test_revisions_query() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def meow 1)", sid, &mut journal)
                .unwrap();
            rt.eval_str_agent("(def meow 2)", sid, &mut journal)
                .unwrap();

            let results = rt
                .eval_str_agent("(revisions 'meow)", sid, &mut journal)
                .unwrap();
            assert_eq!(results.len(), 1);
            // Result should be a vector (HeapRef)
            assert!(matches!(results[0].value, VMValue::HeapRef(_)));
        }

        #[test]
        fn test_threading_form() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def meow {:x 1})", sid, &mut journal)
                .unwrap();

            let results = rt
                .eval_str_agent("(-> meow (assoc :y 2))", sid, &mut journal)
                .unwrap();
            let msg = results[0].lineage_message.as_ref().unwrap();
            assert!(msg.contains("meow@2"), "got: {}", msg);
        }

        #[test]
        fn test_data_last_updater_sett() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def b {:foo :bar})", sid, &mut journal)
                .unwrap();

            // sett is data-last: (sett optic val data)
            let results = rt
                .eval_str_agent("(sett :foo 1 b)", sid, &mut journal)
                .unwrap();
            let msg = results[0].lineage_message.as_ref().unwrap();
            assert!(msg.contains("b@2"), "got: {}", msg);
            assert!(msg.contains("from b@1"), "got: {}", msg);

            // b@2 should be bound
            let val = rt.eval_str("b@2").unwrap();
            // Should be {:foo 1}
            assert!(matches!(val, VMValue::HeapRef(_)));
        }

        #[test]
        fn test_threading_non_updater_last() {
            let mut rt = agent_rt();
            let mut journal = AgentJournal::new();
            let sid = source_id(&mut rt);

            rt.eval_str_agent("(def meow {:x 1})", sid, &mut journal)
                .unwrap();

            // count is not whitelisted — should be FormKind::Other
            let results = rt
                .eval_str_agent("(-> meow (assoc :y 2) count)", sid, &mut journal)
                .unwrap();
            assert!(
                results[0].lineage_message.is_none(),
                "expected no revision for non-updater last step"
            );
        }
    }

    // --- Closure-based NativeHandler tests ---

    #[test]
    fn test_closure_native_handler() {
        use std::cell::RefCell;
        use std::rc::Rc;
        use super::super::{HandlerAction, VMError};

        let counter = Rc::new(RefCell::new(0u32));
        let counter_clone = counter.clone();
        let mut rt = Runtime::with_stdlib().unwrap();
        rt.register_native_handler_by_name(
            "console",
            Rc::new(move |_vm: &mut super::super::VM, _op, _args| {
                *counter_clone.borrow_mut() += 1;
                Ok(HandlerAction::Resume(super::super::value::VMValue::Nil))
            }),
        )
        .unwrap();
        rt.eval_str(r#"(console/println "hello")"#).unwrap();
        rt.eval_str(r#"(console/println "world")"#).unwrap();
        assert_eq!(*counter.borrow(), 2);
    }

    // --- Dynamic native (define_fn) tests ---

    #[test]
    fn test_define_fn_basic() {
        use std::rc::Rc;

        let mut rt = Runtime::with_stdlib().unwrap();
        rt.define_fn(
            "double",
            Rc::new(|_vm: &mut super::super::VM, args: &[VMValue]| {
                match args[0] {
                    VMValue::Int(n) => Ok(VMValue::Int(n * 2)),
                    _ => Err(super::super::VMError::TypeError("expected int")),
                }
            }),
        );
        let result = rt.eval_str("(double 21)").unwrap();
        assert_eq!(result, VMValue::Int(42));
    }

    #[test]
    fn test_define_fn_closure_state() {
        use std::cell::RefCell;
        use std::rc::Rc;

        let call_log = Rc::new(RefCell::new(Vec::<i64>::new()));
        let log_clone = call_log.clone();
        let mut rt = Runtime::with_stdlib().unwrap();
        rt.define_fn(
            "log-and-double",
            Rc::new(move |_vm: &mut super::super::VM, args: &[VMValue]| {
                if let VMValue::Int(n) = args[0] {
                    log_clone.borrow_mut().push(n);
                    Ok(VMValue::Int(n * 2))
                } else {
                    Err(super::super::VMError::TypeError("expected int"))
                }
            }),
        );
        rt.eval_str("(log-and-double 5)").unwrap();
        rt.eval_str("(log-and-double 10)").unwrap();
        assert_eq!(*call_log.borrow(), vec![5, 10]);
    }

    #[test]
    fn test_define_fn_used_in_higher_order() {
        use std::rc::Rc;

        let mut rt = Runtime::with_stdlib().unwrap();
        rt.define_fn(
            "triple",
            Rc::new(|_vm: &mut super::super::VM, args: &[VMValue]| {
                match args[0] {
                    VMValue::Int(n) => Ok(VMValue::Int(n * 3)),
                    _ => Err(super::super::VMError::TypeError("expected int")),
                }
            }),
        );
        let result = rt.eval_str("(map triple [1 2 3])").unwrap();
        // Result should be a vector [3 6 9]; check via count and nth
        let count = rt.eval_str("(count (map triple [1 2 3]))").unwrap();
        assert_eq!(count, VMValue::Int(3));
        let first = rt.eval_str("(first (map triple [1 2 3]))").unwrap();
        assert_eq!(first, VMValue::Int(3));
    }
}
