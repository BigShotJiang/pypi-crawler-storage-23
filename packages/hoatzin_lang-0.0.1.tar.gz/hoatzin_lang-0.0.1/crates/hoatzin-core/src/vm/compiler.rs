//! Bytecode compiler - AST to Prototype
//!
//! Compiles interpreter Value (AST) to VM bytecode.

use std::collections::HashMap;
use std::rc::Rc;

use lasso::{Rodeo, Spur};
use rustc_hash::FxHashMap;

use super::compilation_unit::{CompilationUnit, DefKind, DocEntry};
use super::heap::{
    ClauseInfo, ClosureTemplate, CompiledPattern, Heap, HeapObject, VariantInstance,
};
use super::opcode::{OpCode, encode};
use super::prototype::{HandlerInfo, Prototype, Span, UpvalueDesc};
use super::type_registry::{TypeId, VariantDef};
use super::value::VMValue;
use super::{HeapKey, VM};

use crate::Value;

// Native function indices for direct CallNative optimization
// Must match the order in natives.rs build_native_table()
const NATIVE_NTH: u16 = 0;
const NATIVE_GET: u16 = 8;
const NATIVE_DROP: u16 = 67;

/// Compiler state
pub struct Compiler<'a> {
    /// String interner (shared with VM)
    interner: &'a mut Rodeo,

    /// Heap for constant allocation
    heap: Heap,

    /// Function being compiled (stack for nested fns)
    functions: Vec<FunctionBuilder>,

    /// Compiled prototypes
    prototypes: Vec<Prototype>,

    /// Registered macros: name -> closure key in VM heap
    macros: FxHashMap<Spur, HeapKey>,

    /// VM for macro expansion (None for non-macro compilation)
    vm: Option<&'a mut VM>,

    /// Documentation entries collected during compilation
    docs: FxHashMap<Spur, DocEntry>,

    /// Known native function indices: symbol -> native table index
    native_names: FxHashMap<Spur, u16>,

    /// Known global slots: symbol -> global slot index
    global_slots: FxHashMap<Spur, u32>,

    /// Next predicted global slot (mirrors VM's sequential assignment)
    next_global_slot: u32,

    /// Known variant constructors: symbol -> (type_id, variant_idx, field_count)
    variant_constructors: FxHashMap<Spur, (TypeId, u8, usize)>,
}

/// Builder for a single function/prototype
struct FunctionBuilder {
    name: Option<Spur>,
    arity: u8,
    is_variadic: bool,
    code: Vec<u32>,
    constants: Vec<VMValue>,
    spans: Vec<(u32, Span)>,
    handlers: Vec<HandlerInfo>,
    upvalues: Vec<UpvalueDesc>,

    /// Scope stack
    scopes: Vec<Scope>,

    /// Current local count
    local_count: u8,

    /// Loop context for break/recur
    loops: Vec<LoopInfo>,

    /// Whether current expression is in tail position (for recur validation)
    in_tail_position: bool,
}

struct Scope {
    locals: Vec<Local>,
    depth: usize,
}

struct Local {
    name: Spur,
    slot: u8,
    depth: usize,
    captured: bool,
    span: Option<crate::span::Span>,
}

struct LoopInfo {
    start_ip: u32,
    local_count: u8,
    param_count: u8,
}

struct ClauseCompile {
    proto: Prototype,
    guard_proto: Option<Prototype>,
    patterns: Box<[CompiledPattern]>,
    arity: u8,
    is_variadic: bool,
    upvalues: Vec<UpvalueDesc>,
    guard_upvalues: Vec<UpvalueDesc>,
}

/// How a symbol resolved
enum Resolution {
    Local(u8),
    Upvalue(u8),
    Global(Spur),
}

impl<'a> Compiler<'a> {
    pub fn new(interner: &'a mut Rodeo) -> Self {
        Compiler {
            interner,
            heap: Heap::new(),
            functions: Vec::new(),
            prototypes: Vec::new(),
            macros: FxHashMap::default(),
            vm: None,
            docs: FxHashMap::default(),
            native_names: FxHashMap::default(),
            global_slots: FxHashMap::default(),
            next_global_slot: 0,
            variant_constructors: FxHashMap::default(),
        }
    }

    /// Create a compiler with access to a VM for macro expansion.
    ///
    /// This uses a raw pointer to get the interner from the VM while holding
    /// a mutable reference to the VM. This is safe because:
    /// 1. The interner is a field of VM that won't move while we hold the ref
    /// 2. We only use the interner for interning strings, not for VM operations
    /// 3. The VM ref is only used for macro expansion which happens after interning
    pub fn with_vm(vm: &'a mut VM) -> Self {
        // SAFETY: We need to get the interner from VM while holding a mut ref to VM.
        // The interner is a field of VM and won't be invalidated during compilation.
        // We use a raw pointer to break the borrow, then immediately create a new ref.
        let interner = unsafe { &mut *(vm.interner_mut() as *mut Rodeo) };

        // Build native_names from the VM's native table
        let mut native_names = FxHashMap::default();
        for (idx, entry) in vm.native_table().iter().enumerate() {
            if let Some(spur) = interner.get(entry.name) {
                native_names.insert(spur, idx as u16);
            }
        }

        // Copy global slot index from VM
        let global_slots: FxHashMap<Spur, u32> =
            vm.global_slots().iter().map(|(&k, &v)| (k, v)).collect();
        let next_global_slot = vm.global_count() as u32;

        // Seed variant_constructors from existing type registry
        let mut variant_constructors = FxHashMap::default();
        for (type_id, variant_idx, name_spur, field_count) in vm.type_registry().iter_variants() {
            variant_constructors.insert(name_spur, (type_id, variant_idx, field_count));
        }

        Compiler {
            interner,
            heap: Heap::new(),
            functions: Vec::new(),
            prototypes: Vec::new(),
            macros: FxHashMap::default(),
            vm: Some(vm),
            docs: FxHashMap::default(),
            native_names,
            global_slots,
            next_global_slot,
            variant_constructors,
        }
    }

    /// Get macros map (for transferring to another compiler)
    pub fn macros(&self) -> &FxHashMap<Spur, HeapKey> {
        &self.macros
    }

    /// Set macros from another source
    pub fn set_macros(&mut self, macros: FxHashMap<Spur, HeapKey>) {
        self.macros = macros;
    }

    /// Compile a top-level expression, returns prototype index
    pub fn compile(&mut self, expr: &Value) -> Result<u32, CompileError> {
        // Start a new function builder for top-level
        self.functions.push(FunctionBuilder::new(None, 0));

        // Compile the expression
        self.compile_expr(expr)?;

        // Emit return
        self.emit(OpCode::Return, 0, 0, 0);

        // Finalize
        let proto = self.finish_function()?;
        let idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);

        Ok(idx)
    }

    /// Compile a function definition, returns prototype index
    pub fn compile_fn(
        &mut self,
        name: Option<&str>,
        params: &[Spur],
        body: &[Value],
    ) -> Result<u32, CompileError> {
        let name_spur = name.map(|n| self.interner.get_or_intern(n));

        self.functions
            .push(FunctionBuilder::new(name_spur, params.len() as u8));

        // Bind params as locals (params occupy slots 0..arity-1)
        self.begin_scope();
        for param in params.iter() {
            let _ = self.declare_local(*param)?;
        }

        // Compile body (implicit do)
        self.compile_do(body)?;

        // Emit return
        self.emit(OpCode::Return, 0, 0, 0);

        let proto = self.finish_function()?;
        let idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);

        Ok(idx)
    }

    // --- Expression compilation ---

    fn compile_expr(&mut self, expr: &Value) -> Result<(), CompileError> {
        // Extract span before stripping meta (for error reporting)
        let expr_span = expr.meta_span();

        match expr.strip_meta() {
            // Literals
            Value::Nil => {
                let idx = self.add_constant(VMValue::Nil);
                self.emit_const(idx);
            }
            Value::Bool(b) => {
                let idx = self.add_constant(VMValue::Bool(*b));
                self.emit_const(idx);
            }
            Value::Int(i) => {
                let idx = self.add_constant(VMValue::Int(*i));
                self.emit_const(idx);
            }
            Value::Float(f) => {
                let idx = self.add_constant(VMValue::Float(*f));
                self.emit_const(idx);
            }
            Value::Ratio { numer, denom } => {
                let idx = self.add_constant(VMValue::Ratio {
                    numer: *numer,
                    denom: *denom,
                });
                self.emit_const(idx);
            }
            Value::String(s) => {
                // Allocate string on heap as constant
                let hip = hipstr::HipStr::from(s.as_ref().to_owned());
                let key = self.heap.insert_constant(HeapObject::String(hip));
                let idx = self.add_constant(VMValue::HeapRef(key));
                self.emit_const(idx);
            }
            Value::Keyword(kw) => {
                // Preserve namespace: :a/b becomes "a/b", :foo becomes "foo"
                let full_name = if let Some(ns) = &kw.namespace {
                    format!("{}/{}", ns, kw.name)
                } else {
                    kw.name.to_string()
                };
                let spur = self.interner.get_or_intern(&full_name);
                let idx = self.add_constant(VMValue::Keyword(spur));
                self.emit_const(idx);
            }
            Value::Symbol(sym) => {
                self.compile_symbol_with_span(sym, expr_span)?;
            }

            // Collections
            Value::Vector(vec) => {
                self.compile_vector(vec, expr_span)?;
            }
            Value::List(list) if list.is_empty() => {
                // Empty list literal
                self.emit(OpCode::MakeList, 0, 0, 0);
            }
            Value::List(list) => {
                self.compile_list_with_span(list, expr_span)?;
            }
            Value::Map(map) => {
                self.compile_map(map, expr_span)?;
            }
            Value::Set(set) => {
                self.compile_set(set, expr_span)?;
            }
            Value::Regex(re) => {
                // Compile regex literal
                let key = self
                    .heap
                    .insert_constant(HeapObject::Regex(re.as_ref().clone()));
                let idx = self.add_constant(VMValue::HeapRef(key));
                self.emit_const(idx);
            }

            // Other value types
            _ => {
                return Err(CompileError::new(CompileErrorKind::UnsupportedExpression(
                    expr.type_name(),
                ))
                .with_span(expr_span));
            }
        }

        Ok(())
    }

    fn compile_symbol(&mut self, sym: &crate::Symbol) -> Result<(), CompileError> {
        self.compile_symbol_with_span(sym, None)
    }

    fn compile_symbol_with_span(
        &mut self,
        sym: &crate::Symbol,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Get the symbol name as a Spur
        let name = self.interner.get_or_intern(sym.name.as_ref());

        // Resolve: local, upvalue, or global
        match self.resolve_symbol(name) {
            Resolution::Local(slot) => {
                self.emit(OpCode::GetLocal, slot, 0, 0);
            }
            Resolution::Upvalue(slot) => {
                self.emit(OpCode::GetUpvalue, slot, 0, 0);
            }
            Resolution::Global(spur) => {
                if let Some(&slot) = self.global_slots.get(&spur) {
                    self.emit(OpCode::GetGlobalSlot, slot as u8, (slot >> 8) as u8, 0);
                } else {
                    let idx = self.add_constant(VMValue::Symbol(spur));
                    // Record span for undefined global errors
                    self.record_span(span);
                    self.emit(OpCode::GetGlobal, idx as u8, (idx >> 8) as u8, 0);
                }
            }
        }
        Ok(())
    }

    fn compile_vector(
        &mut self,
        vec: &crate::collections::Vector<Value>,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Vector elements are never in tail position
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;

        // Compile all elements
        for elem in vec.iter() {
            self.compile_expr(elem)?;
        }

        self.current_fn_mut().in_tail_position = was_tail;

        // Emit MakeVector instruction
        let n = vec.len();
        if n > u16::MAX as usize {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "vector too large".to_string(),
            ))
            .with_span(span));
        }
        self.emit(OpCode::MakeVector, n as u8, (n >> 8) as u8, 0);
        Ok(())
    }

    fn compile_list(&mut self, list: &crate::List) -> Result<(), CompileError> {
        self.compile_list_with_span(list, None)
    }

    fn compile_list_with_span(
        &mut self,
        list: &crate::List,
        call_span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Check if it's a special form or function call
        let first = list
            .first()
            .ok_or_else(|| CompileError::new(CompileErrorKind::EmptyList).with_span(call_span))?;

        if let Value::Symbol(sym) = first.strip_meta() {
            match sym.name.as_ref() {
                "if" => return self.compile_if(list),
                "do" => return self.compile_do(&list.args_vec()),
                "let" => return self.compile_let(list),
                "fn" => return self.compile_fn_expr(list),
                "def" => return self.compile_def(list),
                "defn" => return self.compile_defn(list),
                "defmacro" => return self.compile_defmacro(list),
                "quote" => return self.compile_quote(list),
                "syntax-quote" => return self.compile_syntax_quote(list),
                "unquote" => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "unquote outside of syntax-quote".to_string(),
                    ))
                    .with_span(first.meta_span()));
                }
                "unquote-splicing" => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "unquote-splicing outside of syntax-quote".to_string(),
                    ))
                    .with_span(first.meta_span()));
                }
                "assert" => return self.compile_assert_with_span(list, call_span),
                "loop" => return self.compile_loop(list),
                "recur" => return self.compile_recur(list),
                "and" => return self.compile_and(list),
                "or" => return self.compile_or(list),
                "with-handler" => return self.compile_with_handler(list),
                "perform" => return self.compile_perform(list),
                "effect" => return self.compile_effect(list),
                "macroexpand-1" => return self.compile_macroexpand(list, call_span, false),
                "macroexpand" => return self.compile_macroexpand(list, call_span, true),
                "defdata" => return self.compile_defdata(list),
                "match" => return self.compile_match(list),
                _ => {}
            }

            // Check if callee is a registered macro
            if sym.namespace.is_none() {
                let name_spur = self.interner.get_or_intern(&sym.name);
                if self.macros.contains_key(&name_spur) {
                    let args = list.args_vec();
                    let span = first.meta_span();
                    let expanded = self.expand_macro(name_spur, &args, span)?;
                    return self.compile_expr(&expanded);
                }
            }
        }

        // Function call
        self.compile_call_with_span(list, call_span)
    }

    fn compile_map(
        &mut self,
        map: &crate::collections::HashMap<Value, Value>,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Map elements are never in tail position
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;

        // Compile all key-value pairs
        for (k, v) in map.iter() {
            self.compile_expr(k)?;
            self.compile_expr(v)?;
        }

        self.current_fn_mut().in_tail_position = was_tail;

        // Emit MakeMap instruction
        let n_pairs = map.len();
        if n_pairs > u16::MAX as usize {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "map too large".to_string(),
            ))
            .with_span(span));
        }
        self.emit(OpCode::MakeMap, n_pairs as u8, (n_pairs >> 8) as u8, 0);
        Ok(())
    }

    fn compile_set(
        &mut self,
        set: &crate::collections::HashSet<Value>,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Set elements are never in tail position
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;

        // Compile all elements
        for elem in set.iter() {
            self.compile_expr(elem)?;
        }

        self.current_fn_mut().in_tail_position = was_tail;

        // Emit MakeSet instruction
        let n = set.len();
        if n > u16::MAX as usize {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "set too large".to_string(),
            ))
            .with_span(span));
        }
        self.emit(OpCode::MakeSet, n as u8, (n >> 8) as u8, 0);
        Ok(())
    }

    // --- Special forms ---

    fn compile_if(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "if requires a test expression".to_string(),
            ))
            .with_span(list.first().and_then(|v| v.meta_span())));
        }

        // Save tail position - branches inherit it, but test does not
        let was_tail = self.current_fn().in_tail_position;

        // Compile test expression (NOT in tail position)
        self.current_fn_mut().in_tail_position = false;
        self.compile_expr(&args[0])?;

        // Emit JumpIfFalse with placeholder
        let jump_to_else = self.emit_jump(OpCode::JumpIfFalse);

        // Compile then branch (or nil if missing) - inherits tail position
        self.current_fn_mut().in_tail_position = was_tail;
        if args.len() > 1 {
            self.compile_expr(&args[1])?;
        } else {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        }

        if args.len() > 2 {
            // Has else branch: jump over it
            let jump_to_end = self.emit_jump(OpCode::Jump);

            // Patch jump-to-else to land here
            self.patch_jump(jump_to_else);

            // Compile else branch - inherits tail position
            self.current_fn_mut().in_tail_position = was_tail;
            self.compile_expr(&args[2])?;

            // Patch jump-to-end to land here
            self.patch_jump(jump_to_end);
        } else {
            // No else branch: patch to land here, then handle the nil case
            // When test is true: we have then-value on stack, jump over nil push
            let jump_over_nil = self.emit_jump(OpCode::Jump);

            // When test is false: jump here, push nil
            self.patch_jump(jump_to_else);
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);

            // Both paths converge here
            self.patch_jump(jump_over_nil);
        }

        // Restore tail position
        self.current_fn_mut().in_tail_position = was_tail;

        Ok(())
    }

    fn compile_do(&mut self, exprs: &[Value]) -> Result<(), CompileError> {
        if exprs.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
            return Ok(());
        }

        // Save the original tail position - only the last expr inherits it
        let was_tail = self.current_fn().in_tail_position;

        for (i, expr) in exprs.iter().enumerate() {
            let is_last = i == exprs.len() - 1;
            // Only the last expression is in tail position
            self.current_fn_mut().in_tail_position = was_tail && is_last;
            self.compile_expr(expr)?;
            if !is_last {
                self.emit(OpCode::Pop, 0, 0, 0);
            }
        }

        // Restore tail position
        self.current_fn_mut().in_tail_position = was_tail;

        Ok(())
    }

    fn compile_let(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "let requires bindings vector".to_string(),
            ))
            .with_span(list_span));
        }

        // Get bindings vector
        let bindings = match args[0].strip_meta() {
            Value::Vector(v) => v.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "let bindings must be a vector".to_string(),
                ))
                .with_span(args[0].meta_span())
                .with_hint(crate::error::Hint::UseInstead(
                    "use [name value ...] form".to_string(),
                )));
            }
        };

        // Validate even binding count
        if bindings.len() % 2 != 0 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "let bindings must have even count".to_string(),
            ))
            .with_span(args[0].meta_span()));
        }

        let body = &args[1..];

        // Save tail position - bindings are NOT in tail, body inherits it
        let was_tail = self.current_fn().in_tail_position;

        // Begin new scope
        self.begin_scope();

        // Compile bindings: [pattern expr pattern expr ...]
        // Binding expressions are NOT in tail position
        self.current_fn_mut().in_tail_position = false;
        let mut i = 0;
        while i < bindings.len() {
            let pattern = &bindings[i];
            let expr = &bindings[i + 1];

            // Compile the init expression
            self.compile_expr(expr)?;

            // Bind the pattern (declares local, pops value from stack)
            self.compile_pattern_binding(pattern)?;

            i += 2;
        }

        // Restore tail position for body
        self.current_fn_mut().in_tail_position = was_tail;

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // End scope (locals go out of scope)
        // Note: the result value is still on the stack
        self.end_scope();

        Ok(())
    }

    fn compile_pattern_binding(&mut self, pattern: &Value) -> Result<(), CompileError> {
        match pattern.strip_meta() {
            // Simple symbol: allocate local, set from top of stack
            Value::Symbol(sym) if sym.namespace.is_none() => {
                if sym.name.as_ref() == "_" {
                    // Wildcard: just pop
                    self.emit(OpCode::Pop, 0, 0, 0);
                } else {
                    let name = self.interner.get_or_intern(sym.name.as_ref());
                    let slot = self.declare_local(name)?;
                    self.emit(OpCode::SetLocal, slot, 0, 0);
                }
            }
            // Vector destructuring: [a b c], [a b & rest], [a :as whole]
            Value::Vector(vec) => {
                self.compile_vector_binding(vec, pattern.meta_span())?;
            }
            // Map destructuring: {:keys [a b]}, {x :x}, {:as m}
            Value::Map(map) => {
                self.compile_map_binding(map, pattern.meta_span())?;
            }
            Value::List(list) if !list.is_empty() => {
                let first = list.first().unwrap();
                if let Value::Symbol(sym) = first.strip_meta() {
                    if sym.namespace.is_none() {
                        let name_spur = self.interner.get_or_intern(&sym.name);
                        if self.variant_constructors.contains_key(&name_spur)
                            && !self.is_local(name_spur)
                        {
                            let (_type_id, _variant_idx, field_count) =
                                self.variant_constructors[&name_spur];
                            let field_patterns: Vec<_> = list.iter().skip(1).collect();
                            if field_patterns.len() != field_count {
                                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                    format!(
                                        "variant {} expects {} fields, got {}",
                                        sym.name,
                                        field_count,
                                        field_patterns.len()
                                    ),
                                ))
                                .with_span(pattern.meta_span()));
                            }
                            return self.compile_variant_destructure(
                                &name_spur,
                                &field_patterns,
                                pattern.meta_span(),
                            );
                        }
                    }
                }
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "list patterns in let bindings are only supported for ADT variant destructuring".to_string(),
                ))
                .with_span(pattern.meta_span()));
            }
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "only simple symbol patterns supported in let bindings".to_string(),
                ))
                .with_span(pattern.meta_span()));
            }
        }
        Ok(())
    }

    /// Compile vector destructuring pattern binding.
    /// Stack: [value] -> []
    /// Emits bytecode to destructure a vector/list and bind elements to locals.
    fn compile_vector_binding(
        &mut self,
        vec: &crate::collections::Vector<Value>,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Parse the vector pattern to extract required elements, rest, and :as binding
        let mut required: Vec<Value> = Vec::new();
        let mut rest_pattern: Option<Value> = None;
        let mut as_binding: Option<String> = None;
        let mut iter = vec.iter().peekable();
        let mut saw_amp = false;

        while let Some(elem) = iter.next() {
            let elem_stripped = elem.strip_meta();

            // Check for :as keyword
            if matches!(elem_stripped, Value::Keyword(k) if k.namespace.is_none() && k.name.as_ref() == "as")
            {
                let name = iter.next().ok_or_else(|| {
                    CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol after :as".to_string(),
                    ))
                    .with_span(span)
                })?;
                if let Value::Symbol(sym) = name.strip_meta() {
                    as_binding = Some(sym.name.to_string());
                } else {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol after :as".to_string(),
                    ))
                    .with_span(name.meta_span()));
                }
                continue;
            }

            // Check for & (rest)
            if matches!(elem_stripped, Value::Symbol(sym) if sym.namespace.is_none() && sym.name.as_ref() == "&")
            {
                if saw_amp {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "multiple & in pattern".to_string(),
                    ))
                    .with_span(elem.meta_span()));
                }
                saw_amp = true;
                let rest = iter.next().ok_or_else(|| {
                    CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected pattern after &".to_string(),
                    ))
                    .with_span(elem.meta_span())
                })?;
                rest_pattern = Some(rest.clone());
                continue;
            }

            if saw_amp {
                // After &, only :as is allowed
                if !matches!(elem_stripped, Value::Keyword(k) if k.namespace.is_none() && k.name.as_ref() == "as")
                {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "only :as allowed after rest parameter".to_string(),
                    ))
                    .with_span(elem.meta_span()));
                }
            }

            required.push(elem.clone());
        }

        // Stack: [coll]
        // Save coll to a temp local so we can access it throughout destructuring
        // Dup + SetLocal leaves one copy on stack (SetLocal pops, so Dup ensures one remains)
        let temp_name = self.interner.get_or_intern("__destruct_coll__");
        let temp_slot = self.declare_local(temp_name)?;
        self.emit(OpCode::Dup, 0, 0, 0);
        self.emit(OpCode::SetLocal, temp_slot, 0, 0);
        // Stack: [coll], temp_slot has coll

        // Handle :as binding (bind the whole collection)
        if let Some(as_name) = &as_binding {
            self.emit(OpCode::GetLocal, temp_slot, 0, 0);
            let name = self.interner.get_or_intern(as_name);
            let slot = self.declare_local(name)?;
            self.emit(OpCode::SetLocal, slot, 0, 0);
            // SetLocal already popped; no additional Pop needed
        }

        // Destructure required elements
        for (i, elem) in required.iter().enumerate() {
            // Push coll, then index, then call nth directly via CallNative
            self.emit(OpCode::GetLocal, temp_slot, 0, 0);
            let idx_const = self.add_constant(VMValue::Int(i as i64));
            self.emit_const(idx_const);
            // Use CallNative for nth - avoids GetGlobal lookup overhead
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_NTH as u8,
                (NATIVE_NTH >> 8) as u8,
                2, // n_args
            );
            // Stack: [coll, elem_i]

            // Bind the element (may be nested destructuring)
            self.compile_pattern_binding(elem)?;
        }

        // Handle rest pattern
        if let Some(rest) = rest_pattern {
            // Call (drop n coll) to get the rest - push n first, then coll
            let n_const = self.add_constant(VMValue::Int(required.len() as i64));
            self.emit_const(n_const);
            self.emit(OpCode::GetLocal, temp_slot, 0, 0);
            // Use CallNative for drop - avoids GetGlobal lookup
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_DROP as u8,
                (NATIVE_DROP >> 8) as u8,
                2, // n_args
            );
            // Stack: [coll, rest_seq]

            // Bind the rest pattern
            self.compile_pattern_binding(&rest)?;
        }

        // Pop the original collection
        self.emit(OpCode::Pop, 0, 0, 0);

        Ok(())
    }
    /// Compile map destructuring pattern binding.
    /// Stack: [map_value] -> []
    fn compile_map_binding(
        &mut self,
        map: &crate::collections::HashMap<Value, Value>,
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Parse the map pattern: extract :keys, :strs, :syms, :or, :as
        let mut keys_bindings: Vec<String> = Vec::new();
        let mut strs_bindings: Vec<String> = Vec::new();
        let mut syms_bindings: Vec<String> = Vec::new();
        let mut or_defaults: Vec<(Value, Value)> = Vec::new();
        let mut as_binding: Option<String> = None;
        let mut regular_bindings: Vec<(Value, Value)> = Vec::new();

        for (k, v) in map.iter() {
            match k.strip_meta() {
                Value::Keyword(kw) if kw.namespace.is_none() => match kw.name.as_ref() {
                    "keys" => {
                        keys_bindings = self.extract_symbol_names_for_binding(v)?;
                    }
                    "strs" => {
                        strs_bindings = self.extract_symbol_names_for_binding(v)?;
                    }
                    "syms" => {
                        syms_bindings = self.extract_symbol_names_for_binding(v)?;
                    }
                    "or" => {
                        or_defaults = self.extract_defaults_for_binding(v)?;
                    }
                    "as" => {
                        if let Value::Symbol(sym) = v.strip_meta() {
                            as_binding = Some(sym.name.to_string());
                        } else {
                            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                "expected symbol after :as".to_string(),
                            ))
                            .with_span(v.meta_span()));
                        }
                    }
                    _ => {
                        regular_bindings.push((k.clone(), v.clone()));
                    }
                },
                _ => {
                    regular_bindings.push((k.clone(), v.clone()));
                }
            }
        }

        // Handle :as first (bind whole map)
        if let Some(as_name) = &as_binding {
            self.emit(OpCode::Dup, 0, 0, 0);
            let name = self.interner.get_or_intern(as_name);
            let slot = self.declare_local(name)?;
            self.emit(OpCode::SetLocal, slot, 0, 0);
            // SetLocal already popped; no additional Pop needed
        }

        // Helper to check if a name has a default in :or
        let get_default = |name: &str| -> Option<&Value> {
            for (k, v) in &or_defaults {
                if let Value::Symbol(sym) = k.strip_meta() {
                    if sym.name.as_ref() == name {
                        return Some(v);
                    }
                }
            }
            None
        };

        // Process :keys bindings - lookup by keyword
        for name in &keys_bindings {
            self.emit(OpCode::Dup, 0, 0, 0); // Dup the map

            // Push keyword :name
            let kw_spur = self.interner.get_or_intern(name);
            let kw_const = self.add_constant(VMValue::Keyword(kw_spur));
            self.emit_const(kw_const);

            // Push default value if present (before function, as args come before callee)
            let has_default = get_default(name).is_some();
            if let Some(default_val) = get_default(name) {
                self.compile_expr(default_val)?;
            }

            // Call get directly via CallNative - avoids GetGlobal lookup
            let n_args = if has_default { 3 } else { 2 };
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_GET as u8,
                (NATIVE_GET >> 8) as u8,
                n_args,
            );

            // Bind to local
            let local_name = self.interner.get_or_intern(name);
            let slot = self.declare_local(local_name)?;
            self.emit(OpCode::SetLocal, slot, 0, 0);
            // SetLocal already popped; map remains on stack for next binding
        }

        // Process :strs bindings - lookup by string
        for name in &strs_bindings {
            self.emit(OpCode::Dup, 0, 0, 0);

            let hip = hipstr::HipStr::from(name.to_owned());
            let key = self.heap.insert_constant(HeapObject::String(hip));
            let str_const = self.add_constant(VMValue::HeapRef(key));
            self.emit_const(str_const);

            // Push default value if present (before function)
            let has_default = get_default(name).is_some();
            if let Some(default_val) = get_default(name) {
                self.compile_expr(default_val)?;
            }

            // Call get directly via CallNative
            let n_args = if has_default { 3 } else { 2 };
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_GET as u8,
                (NATIVE_GET >> 8) as u8,
                n_args,
            );

            let local_name = self.interner.get_or_intern(name);
            let slot = self.declare_local(local_name)?;
            self.emit(OpCode::SetLocal, slot, 0, 0);
            // SetLocal already popped; map remains on stack
        }

        // Process :syms bindings - lookup by symbol
        for name in &syms_bindings {
            self.emit(OpCode::Dup, 0, 0, 0);

            let sym_spur = self.interner.get_or_intern(name);
            let sym_const = self.add_constant(VMValue::Symbol(sym_spur));
            self.emit_const(sym_const);

            // Push default value if present (before function)
            let has_default = get_default(name).is_some();
            if let Some(default_val) = get_default(name) {
                self.compile_expr(default_val)?;
            }

            // Call get directly via CallNative
            let n_args = if has_default { 3 } else { 2 };
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_GET as u8,
                (NATIVE_GET >> 8) as u8,
                n_args,
            );

            let local_name = self.interner.get_or_intern(name);
            let slot = self.declare_local(local_name)?;
            self.emit(OpCode::SetLocal, slot, 0, 0);
            // SetLocal already popped; map remains on stack
        }

        // Process regular bindings: {local_pattern key}
        for (pattern_value, key_value) in regular_bindings {
            self.emit(OpCode::Dup, 0, 0, 0);

            // Emit the key
            let key_const = self.value_to_constant(&key_value)?;
            let key_idx = self.add_constant(key_const);
            self.emit_const(key_idx);

            // Call get directly via CallNative
            self.emit(
                OpCode::CallNative,
                NATIVE_GET as u8,
                (NATIVE_GET >> 8) as u8,
                2, // n_args
            );

            // Bind the pattern
            self.compile_pattern_binding(&pattern_value)?;
        }

        // Pop the original map
        self.emit(OpCode::Pop, 0, 0, 0);

        Ok(())
    }

    /// Extract symbol names from a vector for :keys/:strs/:syms binding
    fn extract_symbol_names_for_binding(&self, value: &Value) -> Result<Vec<String>, CompileError> {
        let vec = match value.strip_meta() {
            Value::Vector(v) => v,
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "expected vector of symbols".to_string(),
                ))
                .with_span(value.meta_span()));
            }
        };
        let mut names = Vec::new();
        for item in vec.iter() {
            match item.strip_meta() {
                Value::Symbol(sym) if sym.namespace.is_none() => {
                    names.push(sym.name.to_string());
                }
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol in binding list".to_string(),
                    ))
                    .with_span(item.meta_span()));
                }
            }
        }
        Ok(names)
    }

    /// Compile variant destructuring in let bindings.
    /// Stack: [variant_value] -> []
    /// Emits bytecode to destructure an ADT variant and bind fields to locals.
    fn compile_variant_destructure(
        &mut self,
        name_spur: &Spur,
        field_patterns: &[&Value],
        span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        let (_type_id, _variant_idx, _field_count) = self.variant_constructors[name_spur];

        // Get field names from type registry
        let vm = self.vm.as_ref().ok_or_else(|| {
            CompileError::new(CompileErrorKind::InvalidSyntax(
                "variant destructuring requires runtime type information".to_string(),
            ))
            .with_span(span)
        })?;

        let typedef = vm.type_registry().get(_type_id).ok_or_else(|| {
            CompileError::new(CompileErrorKind::InvalidSyntax(
                "unknown type in variant destructuring".to_string(),
            ))
            .with_span(span)
        })?;
        let vdef = &typedef.variants[_variant_idx as usize];
        let field_names: Vec<Spur> = vdef.field_names.iter().copied().collect();

        // Save variant to temp local
        let temp_name = self.interner.get_or_intern("__destruct_variant__");
        let temp_slot = self.declare_local(temp_name)?;
        self.emit(OpCode::Dup, 0, 0, 0);
        self.emit(OpCode::SetLocal, temp_slot, 0, 0);
        // Stack: [variant], temp_slot has variant

        // For each field: get by keyword, then bind
        for (i, field_pat) in field_patterns.iter().enumerate() {
            self.emit(OpCode::GetLocal, temp_slot, 0, 0);
            let kw_idx = self.add_constant(VMValue::Keyword(field_names[i]));
            self.emit_const(kw_idx);
            self.record_span(span);
            self.emit(
                OpCode::CallNative,
                NATIVE_GET as u8,
                (NATIVE_GET >> 8) as u8,
                2,
            );
            // Stack: [variant, field_value]
            self.compile_pattern_binding(field_pat)?;
        }

        // Pop the original variant
        self.emit(OpCode::Pop, 0, 0, 0);

        Ok(())
    }

    /// Extract defaults map for :or
    fn extract_defaults_for_binding(
        &self,
        value: &Value,
    ) -> Result<Vec<(Value, Value)>, CompileError> {
        let map = match value.strip_meta() {
            Value::Map(m) => m,
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "expected map after :or".to_string(),
                ))
                .with_span(value.meta_span()));
            }
        };
        Ok(map.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
    }

    fn compile_pattern(
        &mut self,
        pattern: &Value,
        bindings: &mut Vec<(Spur, Option<crate::span::Span>)>,
    ) -> Result<CompiledPattern, CompileError> {
        match pattern.strip_meta() {
            Value::Symbol(sym) if sym.namespace.is_none() => {
                if sym.name.as_ref() == "_" {
                    Ok(CompiledPattern::Wildcard)
                } else {
                    let spur = self.interner.get_or_intern(&sym.name);
                    let param_span = pattern.meta_span();

                    // Check for duplicate parameter
                    if let Some((_, first_span)) = bindings.iter().find(|(s, _)| *s == spur) {
                        let mut err = CompileError::new(CompileErrorKind::DuplicateParameter(
                            sym.name.to_string(),
                        ))
                        .with_span(param_span);

                        if let Some(first) = first_span {
                            err = err.with_related(crate::error::RelatedSpan {
                                span: *first,
                                role: crate::error::SpanRole::PreviousUse,
                                message: Some("first defined here".to_string()),
                            });
                        }

                        return Err(err);
                    }

                    let slot = self.declare_local_with_span(spur, param_span)?;
                    bindings.push((spur, param_span));
                    Ok(CompiledPattern::Bind { slot })
                }
            }
            Value::Symbol(sym) => {
                let spur = self.interner.get_or_intern(&sym.name);
                let idx = self.add_constant(VMValue::Symbol(spur));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Nil => {
                let idx = self.add_constant(VMValue::Nil);
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Bool(b) => {
                let idx = self.add_constant(VMValue::Bool(*b));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Int(n) => {
                let idx = self.add_constant(VMValue::Int(*n));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Float(f) => {
                let idx = self.add_constant(VMValue::Float(*f));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Ratio { numer, denom } => {
                let idx = self.add_constant(VMValue::Ratio {
                    numer: *numer,
                    denom: *denom,
                });
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Keyword(k) => {
                // Preserve namespace: :a/b becomes "a/b", :foo becomes "foo"
                let full_name = if let Some(ns) = &k.namespace {
                    format!("{}/{}", ns, k.name)
                } else {
                    k.name.to_string()
                };
                let spur = self.interner.get_or_intern(&full_name);
                let idx = self.add_constant(VMValue::Keyword(spur));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::String(s) => {
                let hip = hipstr::HipStr::from(s.as_ref().to_owned());
                let key = self.heap.insert_constant(HeapObject::String(hip));
                let idx = self.add_constant(VMValue::HeapRef(key));
                Ok(CompiledPattern::Literal { const_idx: idx })
            }
            Value::Vector(vec) => self.compile_sequential_pattern(vec, bindings),
            Value::Map(map) => self.compile_associative_pattern(map, bindings),
            Value::List(l) if !l.is_empty() => {
                // Check for variant pattern in fn params
                let first = l.first().unwrap();
                if let Value::Symbol(sym) = first.strip_meta() {
                    if sym.namespace.is_none() {
                        let name_spur = self.interner.get_or_intern(&sym.name);
                        if self.variant_constructors.contains_key(&name_spur)
                            && !self.is_local(name_spur)
                        {
                            let (type_id, variant_idx, field_count) =
                                self.variant_constructors[&name_spur];
                            let sub_patterns: Vec<_> = l.iter().skip(1).collect();
                            if sub_patterns.len() != field_count {
                                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                    format!(
                                        "variant {} expects {} fields, got {}",
                                        sym.name,
                                        field_count,
                                        sub_patterns.len()
                                    ),
                                ))
                                .with_span(pattern.meta_span()));
                            }
                            let mut field_patterns = Vec::new();
                            for sp in sub_patterns {
                                field_patterns.push(self.compile_pattern(sp, bindings)?);
                            }
                            return Ok(CompiledPattern::Variant {
                                type_id,
                                variant_idx,
                                field_patterns: field_patterns.into_boxed_slice(),
                            });
                        }
                    }
                }
                let hint_msg = if let Value::Symbol(sym) = first.strip_meta() {
                    format!(
                        "`{}` is not a known variant constructor — define it with (defdata Type ({} [...]))",
                        sym.name, sym.name
                    )
                } else {
                    "list patterns like (Foo x) require Foo to be a variant constructor defined via defdata".to_string()
                };
                Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "list patterns require a variant constructor".to_string(),
                ))
                .with_span(pattern.meta_span())
                .with_hint(crate::error::Hint::UseInstead(hint_msg)))
            }
            _ => Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "invalid pattern".to_string(),
            ))
            .with_span(pattern.meta_span())),
        }
    }

    fn compile_sequential_pattern(
        &mut self,
        vec: &crate::collections::Vector<Value>,
        bindings: &mut Vec<(Spur, Option<crate::span::Span>)>,
    ) -> Result<CompiledPattern, CompileError> {
        let mut required = Vec::new();
        let mut rest = None;
        let mut as_slot = None;
        let mut iter = vec.iter().peekable();
        let mut saw_amp = false;

        while let Some(elem) = iter.next() {
            let elem = elem.strip_meta();

            if matches!(elem, Value::Keyword(k) if k.namespace.is_none() && k.name.as_ref() == "as")
            {
                let name = iter.next().ok_or_else(|| {
                    CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol after :as".to_string(),
                    ))
                    .with_span(elem.meta_span())
                })?;
                if let Value::Symbol(sym) = name.strip_meta() {
                    let spur = self.interner.get_or_intern(&sym.name);
                    let name_span = name.meta_span();
                    let slot = self.declare_local_with_span(spur, name_span)?;
                    bindings.push((spur, name_span));
                    as_slot = Some(slot);
                } else {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol after :as".to_string(),
                    ))
                    .with_span(name.meta_span()));
                }
                continue;
            }

            if matches!(elem, Value::Symbol(sym) if sym.namespace.is_none() && sym.name.as_ref() == "&")
            {
                if saw_amp {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "multiple & in pattern".to_string(),
                    ))
                    .with_span(elem.meta_span()));
                }
                saw_amp = true;
                let rest_pattern = iter.next().ok_or_else(|| {
                    CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected pattern after &".to_string(),
                    ))
                    .with_span(elem.meta_span())
                })?;
                rest = Some(Box::new(self.compile_pattern(rest_pattern, bindings)?));
                continue;
            }

            if saw_amp {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "only :as allowed after rest parameter".to_string(),
                ))
                .with_span(elem.meta_span()));
            }

            required.push(self.compile_pattern(elem, bindings)?);
        }

        Ok(CompiledPattern::Sequential {
            required: required.into_boxed_slice(),
            rest,
            as_slot,
        })
    }

    fn compile_associative_pattern(
        &mut self,
        map: &crate::collections::HashMap<Value, Value>,
        bindings: &mut Vec<(Spur, Option<crate::span::Span>)>,
    ) -> Result<CompiledPattern, CompileError> {
        let mut keys: Vec<(u16, CompiledPattern)> = Vec::new();
        let mut defaults: Vec<(u16, u16)> = Vec::new();
        let mut as_slot = None;

        let mut or_defaults: Vec<(Value, Value)> = Vec::new();
        let mut keys_bindings: Vec<String> = Vec::new();
        let mut strs_bindings: Vec<String> = Vec::new();
        let mut syms_bindings: Vec<String> = Vec::new();
        let mut regular_bindings: Vec<(Value, Value)> = Vec::new();

        for (k, v) in map.iter() {
            let key = k.strip_meta();
            match key {
                Value::Keyword(kw) if kw.namespace.is_none() => match kw.name.as_ref() {
                    "keys" => {
                        keys_bindings = self.extract_symbol_names(v)?;
                    }
                    "strs" => {
                        strs_bindings = self.extract_symbol_names(v)?;
                    }
                    "syms" => {
                        syms_bindings = self.extract_symbol_names(v)?;
                    }
                    "or" => {
                        or_defaults = self.extract_defaults(v)?;
                    }
                    "as" => {
                        if let Value::Symbol(sym) = v.strip_meta() {
                            let spur = self.interner.get_or_intern(&sym.name);
                            let v_span = v.meta_span();
                            let slot = self.declare_local_with_span(spur, v_span)?;
                            bindings.push((spur, v_span));
                            as_slot = Some(slot);
                        } else {
                            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                "expected symbol after :as".to_string(),
                            ))
                            .with_span(v.meta_span()));
                        }
                    }
                    _ => {
                        regular_bindings.push((k.clone(), v.clone()));
                    }
                },
                _ => {
                    regular_bindings.push((k.clone(), v.clone()));
                }
            }
        }

        for name in &keys_bindings {
            let spur = self.interner.get_or_intern(name);
            let key_idx = self.add_constant(VMValue::Keyword(spur));
            let slot = self.declare_local(spur)?;
            bindings.push((spur, None));
            keys.push((key_idx, CompiledPattern::Bind { slot }));
        }

        for name in &strs_bindings {
            let spur = self.interner.get_or_intern(name);
            let hip = hipstr::HipStr::from(name.to_owned());
            let str_key = self.heap.insert_constant(HeapObject::String(hip));
            let key_idx = self.add_constant(VMValue::HeapRef(str_key));
            let slot = self.declare_local(spur)?;
            bindings.push((spur, None));
            keys.push((key_idx, CompiledPattern::Bind { slot }));
        }

        for name in &syms_bindings {
            let spur = self.interner.get_or_intern(name);
            let key_idx = self.add_constant(VMValue::Symbol(spur));
            let slot = self.declare_local(spur)?;
            bindings.push((spur, None));
            keys.push((key_idx, CompiledPattern::Bind { slot }));
        }

        for (binding_pattern, key) in regular_bindings {
            let key_const = self.value_to_constant(&key)?;
            let key_idx = self.add_constant(key_const);
            let pattern = self.compile_pattern(&binding_pattern, bindings)?;
            keys.push((key_idx, pattern));
        }

        for (k, v) in or_defaults {
            let key_const = if let Value::Symbol(sym) = k.strip_meta() {
                let name = sym.name.as_ref();
                let spur = self.interner.get_or_intern(name);
                if keys_bindings.iter().any(|n| n == name) {
                    VMValue::Keyword(spur)
                } else if strs_bindings.iter().any(|n| n == name) {
                    let hip = hipstr::HipStr::from(name.to_owned());
                    let str_key = self.heap.insert_constant(HeapObject::String(hip));
                    VMValue::HeapRef(str_key)
                } else if syms_bindings.iter().any(|n| n == name) {
                    VMValue::Symbol(spur)
                } else {
                    self.value_to_constant(&k)?
                }
            } else {
                self.value_to_constant(&k)?
            };
            let key_idx = self.add_constant(key_const);
            let default_const = self.value_to_constant(&v)?;
            let default_idx = self.add_constant(default_const);
            defaults.push((key_idx, default_idx));
        }

        Ok(CompiledPattern::Associative {
            keys: keys.into_boxed_slice(),
            defaults: defaults.into_boxed_slice(),
            as_slot,
        })
    }

    fn extract_symbol_names(&self, value: &Value) -> Result<Vec<String>, CompileError> {
        let vec = match value.strip_meta() {
            Value::Vector(v) => v,
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "expected vector of symbols".to_string(),
                ))
                .with_span(value.meta_span()));
            }
        };
        let mut names = Vec::new();
        for item in vec.iter() {
            match item.strip_meta() {
                Value::Symbol(sym) if sym.namespace.is_none() => {
                    names.push(sym.name.to_string());
                }
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "expected symbol in binding list".to_string(),
                    ))
                    .with_span(item.meta_span()));
                }
            }
        }
        Ok(names)
    }

    fn extract_defaults(&self, value: &Value) -> Result<Vec<(Value, Value)>, CompileError> {
        let map = match value.strip_meta() {
            Value::Map(m) => m,
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "expected map after :or".to_string(),
                ))
                .with_span(value.meta_span()));
            }
        };
        Ok(map.iter().map(|(k, v)| (k.clone(), v.clone())).collect())
    }

    fn compile_fn_expr(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "fn requires parameters".to_string(),
            ))
            .with_span(list_span));
        }

        let (name, clauses) = if let Value::Symbol(sym) = args[0].strip_meta() {
            if args.len() < 2 {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "fn requires parameters".to_string(),
                ))
                .with_span(list_span));
            }
            let name = Some(sym.name.as_ref());
            if matches!(args[1].strip_meta(), Value::List(_)) {
                (name, args[1..].to_vec())
            } else {
                let clause = Value::list_from_iter(args[1..].to_vec());
                (name, vec![clause])
            }
        } else if matches!(args[0].strip_meta(), Value::List(_)) {
            (None, args.to_vec())
        } else {
            let clause = Value::list_from_iter(args.to_vec());
            (None, vec![clause])
        };

        let name_spur = name.map(|n| self.interner.get_or_intern(n));

        let mut clause_compiles = Vec::new();
        for clause in &clauses {
            let clause_list = match clause.strip_meta() {
                Value::List(list) => list,
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "fn clause must be a list".to_string(),
                    ))
                    .with_span(clause.meta_span()));
                }
            };
            if clause_list.is_empty() {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "fn clause is empty".to_string(),
                ))
                .with_span(clause.meta_span()));
            }
            clause_compiles.push(self.compile_fn_clause(name_spur, clause_list)?);
        }

        let mut union_upvalues: Vec<UpvalueDesc> = Vec::new();
        for clause in &clause_compiles {
            for up in clause.upvalues.iter().chain(clause.guard_upvalues.iter()) {
                if !union_upvalues.iter().any(|existing| existing == up) {
                    union_upvalues.push(*up);
                }
            }
        }

        for clause in clause_compiles.iter_mut() {
            clause.remap_upvalues(&union_upvalues)?;
        }

        let base_idx = self.prototypes.len() as u32;

        let mut clause_infos = Vec::with_capacity(clause_compiles.len());
        let mut proto_idx = base_idx;
        for clause in clause_compiles.iter() {
            let body_idx = proto_idx;
            proto_idx += 1;
            let guard_idx = if clause.guard_proto.is_some() {
                let idx = proto_idx;
                proto_idx += 1;
                Some(idx)
            } else {
                None
            };
            clause_infos.push(ClauseInfo {
                proto_idx: body_idx,
                arity: clause.arity,
                is_variadic: clause.is_variadic,
                patterns: clause.patterns.clone(),
                guard_proto_idx: guard_idx,
            });
        }

        for clause in clause_compiles {
            self.prototypes.push(clause.proto);
            if let Some(guard_proto) = clause.guard_proto {
                self.prototypes.push(guard_proto);
            }
        }

        // Fast path: single-clause, simple-param, non-variadic, no guard → MakeClosure
        if clause_infos.len() == 1
            && clause_infos[0].guard_proto_idx.is_none()
            && !clause_infos[0].is_variadic
            && (clause_infos[0].patterns.is_empty()
                || clause_infos[0].patterns.iter().enumerate().all(
                    |(i, p)| matches!(p, CompiledPattern::Bind { slot } if *slot as usize == i),
                ))
        {
            let proto_idx = clause_infos[0].proto_idx;
            for upval in &union_upvalues {
                match upval {
                    UpvalueDesc::Local(slot) => {
                        self.emit(OpCode::GetLocal, *slot, 0, 0);
                    }
                    UpvalueDesc::Upvalue(slot) => {
                        self.emit(OpCode::GetUpvalue, *slot, 0, 0);
                    }
                }
            }
            self.emit(
                OpCode::MakeClosure,
                proto_idx as u8,
                (proto_idx >> 8) as u8,
                union_upvalues.len() as u8,
            );
            return Ok(());
        }

        let template = ClosureTemplate {
            clauses: Rc::from(clause_infos),
        };
        let template_key = self
            .heap
            .insert_constant(HeapObject::ClosureTemplate(template));
        let template_idx = self.add_constant(VMValue::HeapRef(template_key));

        for upval in &union_upvalues {
            match upval {
                UpvalueDesc::Local(slot) => {
                    self.emit(OpCode::GetLocal, *slot, 0, 0);
                }
                UpvalueDesc::Upvalue(slot) => {
                    self.emit(OpCode::GetUpvalue, *slot, 0, 0);
                }
            }
        }

        self.emit(
            OpCode::MakeMultiClosure,
            template_idx as u8,
            (template_idx >> 8) as u8,
            union_upvalues.len() as u8,
        );

        Ok(())
    }

    fn compile_fn_clause(
        &mut self,
        name: Option<Spur>,
        clause: &crate::List,
    ) -> Result<ClauseCompile, CompileError> {
        // Use as_vector() instead of args_vec() since the clause list
        // starts directly with the param vector, not with a function name
        let items: Vec<Value> = clause.as_vector().iter().cloned().collect();
        let clause_span = clause.first().and_then(|v| v.meta_span());
        if items.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "fn clause is empty".to_string(),
            ))
            .with_span(clause_span));
        }
        let params_vec = match items[0].strip_meta() {
            Value::Vector(v) => v.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "fn clause requires a parameter vector".to_string(),
                ))
                .with_span(items[0].meta_span()));
            }
        };
        let body = &items[1..];

        let (params, rest, guard) = self.parse_params_with_guard(&params_vec)?;
        let arity = params.len() as u8;
        let is_variadic = rest.is_some();

        let mut bindings: Vec<(Spur, Option<crate::span::Span>)> = Vec::new();
        let mut patterns = Vec::new();

        let mut fb = FunctionBuilder::new(name, arity);
        fb.is_variadic = is_variadic;
        self.functions.push(fb);

        self.begin_scope();

        for param in params.iter() {
            patterns.push(self.compile_pattern(param, &mut bindings)?);
        }
        if let Some(rest_pattern) = &rest {
            patterns.push(self.compile_pattern(rest_pattern, &mut bindings)?);
        }

        let total_params = params.len() + if rest.is_some() { 1 } else { 0 };
        let loop_start = self.current_fn().code.len() as u32;
        self.current_fn_mut().loops.push(LoopInfo {
            start_ip: loop_start,
            local_count: 0,
            param_count: total_params as u8,
        });

        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        self.current_fn_mut().loops.pop();
        self.emit(OpCode::Return, 0, 0, 0);

        let upvalues = self.current_fn().upvalues.clone();
        let proto = self.finish_function()?;

        let (guard_proto, guard_upvalues) = if let Some(guard_expr) = guard {
            let mut guard_fb = FunctionBuilder::new(name, 0);
            guard_fb.is_variadic = false;
            self.functions.push(guard_fb);

            self.begin_scope();
            for (binding, _) in &bindings {
                let _ = self.declare_local(*binding)?;
            }

            self.compile_expr(&guard_expr)?;
            self.emit(OpCode::Return, 0, 0, 0);

            let upvalues = self.current_fn().upvalues.clone();
            let proto = self.finish_function()?;
            (Some(proto), upvalues)
        } else {
            (None, Vec::new())
        };

        Ok(ClauseCompile {
            proto,
            guard_proto,
            patterns: patterns.into_boxed_slice(),
            arity,
            is_variadic,
            upvalues,
            guard_upvalues,
        })
    }

    fn parse_params_with_guard(
        &self,
        vec: &crate::collections::Vector<Value>,
    ) -> Result<(Vec<Value>, Option<Value>, Option<Value>), CompileError> {
        let items: Vec<Value> = vec.iter().cloned().collect();

        let when_idx = items.iter().position(|v| {
            matches!(
                v.strip_meta(),
                Value::Keyword(k) if k.namespace.is_none() && k.name.as_ref() == "when"
            )
        });

        let (param_items, guard) = if let Some(idx) = when_idx {
            let guard_expr = if idx + 1 < items.len() {
                Some(items[idx + 1].clone())
            } else {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    ":when requires an expression".to_string(),
                ))
                .with_span(items[idx].meta_span()));
            };
            (items[..idx].to_vec(), guard_expr)
        } else {
            (items, None)
        };

        let mut params = Vec::new();
        let mut rest = None;
        let mut saw_amp = false;

        for item in param_items {
            if let Value::Symbol(sym) = item.strip_meta() {
                if sym.namespace.is_none() && sym.name.as_ref() == "&" {
                    saw_amp = true;
                    continue;
                }
            }
            if saw_amp {
                if rest.is_some() {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "multiple rest parameters".to_string(),
                    ))
                    .with_span(item.meta_span()));
                }
                rest = Some(item);
            } else {
                params.push(item);
            }
        }

        if saw_amp && rest.is_none() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "missing rest parameter after &".to_string(),
            )));
        }

        Ok((params, rest, guard))
    }

    fn compile_def(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() < 2 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "def requires a name and value".to_string(),
            ))
            .with_span(list_span));
        }

        // Get the name
        let name = match args[0].strip_meta() {
            Value::Symbol(sym) => sym,
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "def name must be a symbol".to_string(),
                ))
                .with_span(args[0].meta_span())
                .with_hint(crate::error::Hint::UseInstead(
                    "def expects (def name value)".to_string(),
                )));
            }
        };

        // Check for optional docstring: (def name "doc" value)
        let value_idx = if args.len() >= 3 {
            if let Value::String(doc) = args[1].strip_meta() {
                let name_spur = self.interner.get_or_intern(name.name.as_ref());
                self.docs.insert(
                    name_spur,
                    DocEntry {
                        docstring: doc.to_string(),
                        kind: DefKind::Def,
                        span: list_span.as_ref().map(Span::from_ast_span),
                    },
                );
                2
            } else {
                1
            }
        } else {
            1
        };

        // Compile the value expression
        self.compile_expr(&args[value_idx])?;

        // Duplicate the value (def returns the value)
        self.emit(OpCode::Dup, 0, 0, 0);

        // Emit DefGlobal with the symbol constant (pops one copy)
        let name_spur = self.interner.get_or_intern(name.name.as_ref());
        let idx = self.add_constant(VMValue::Symbol(name_spur));
        self.emit(OpCode::DefGlobal, idx as u8, (idx >> 8) as u8, 0);

        // Predict the global slot the VM will assign
        if !self.global_slots.contains_key(&name_spur) {
            self.global_slots.insert(name_spur, self.next_global_slot);
            self.next_global_slot += 1;
        }

        // The duplicated value remains on stack as result
        Ok(())
    }

    fn compile_defn(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() < 2 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "defn requires a name and parameter vector".to_string(),
            ))
            .with_span(list_span));
        }

        let name = match args[0].strip_meta() {
            Value::Symbol(sym) => sym.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "defn name must be a symbol".to_string(),
                ))
                .with_span(args[0].meta_span())
                .with_hint(crate::error::Hint::UseInstead(
                    "defn expects (defn name [params] body)".to_string(),
                )));
            }
        };

        // Skip docstring if present (defn name "docstring" [params] body)
        let fn_args = if let Some(Value::String(doc)) = args.get(1).map(|v| v.strip_meta()) {
            let name_spur = self.interner.get_or_intern(name.name.as_ref());
            self.docs.insert(
                name_spur,
                DocEntry {
                    docstring: doc.to_string(),
                    kind: DefKind::Defn,
                    span: list_span.as_ref().map(Span::from_ast_span),
                },
            );
            &args[2..]
        } else {
            &args[1..]
        };

        // Predict the global slot before compiling the body so self-recursive
        // references inside the function can use GetGlobalSlot.
        let name_spur = self.interner.get_or_intern(name.name.as_ref());
        if !self.global_slots.contains_key(&name_spur) {
            self.global_slots.insert(name_spur, self.next_global_slot);
            self.next_global_slot += 1;
        }

        let mut fn_items = Vec::with_capacity(fn_args.len() + 2);
        fn_items.push(Value::symbol("fn"));
        fn_items.push(args[0].clone()); // name
        fn_items.extend(fn_args.iter().cloned());
        let fn_list = crate::List::from_iter(fn_items);

        self.compile_fn_expr(&fn_list)?;

        self.emit(OpCode::Dup, 0, 0, 0);

        let idx = self.add_constant(VMValue::Symbol(name_spur));
        self.emit(OpCode::DefGlobal, idx as u8, (idx >> 8) as u8, 0);

        Ok(())
    }

    fn compile_defmacro(&mut self, list: &crate::List) -> Result<(), CompileError> {
        // (defmacro name [params] body...)
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() < 2 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "defmacro requires a name and parameter vector".to_string(),
            ))
            .with_span(list_span));
        }

        // Get the name
        let name = match args[0].strip_meta() {
            Value::Symbol(sym) => sym.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "defmacro name must be a symbol".to_string(),
                ))
                .with_span(args[0].meta_span()));
            }
        };

        // Skip optional docstring: (defmacro name "doc" [params] body...)
        let params_idx = if let Some(Value::String(doc)) = args.get(1).map(|v| v.strip_meta()) {
            let name_spur = self.interner.get_or_intern(name.name.as_ref());
            self.docs.insert(
                name_spur,
                DocEntry {
                    docstring: doc.to_string(),
                    kind: DefKind::Defmacro,
                    span: list_span.as_ref().map(Span::from_ast_span),
                },
            );
            2
        } else {
            1
        };

        // Get params
        let params = match args.get(params_idx).map(|v| v.strip_meta()) {
            Some(Value::Vector(v)) => v.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "defmacro parameters must be a vector".to_string(),
                ))
                .with_span(args.get(params_idx).and_then(|v| v.meta_span())));
            }
        };

        let body = &args[params_idx + 1..];

        // defmacro requires a VM for expansion
        if self.vm.is_none() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "defmacro requires VM context".to_string(),
            ))
            .with_span(list_span));
        }

        let (param_items, rest) = {
            let mut required = Vec::new();
            let mut rest_param = None;
            let mut saw_amp = false;
            for p in params.iter() {
                match p.strip_meta() {
                    Value::Symbol(sym) if sym.namespace.is_none() && sym.name.as_ref() == "&" => {
                        if saw_amp {
                            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                "multiple & in parameters".to_string(),
                            ))
                            .with_span(p.meta_span()));
                        }
                        saw_amp = true;
                    }
                    Value::Symbol(sym) if sym.namespace.is_none() => {
                        let spur = self.interner.get_or_intern(sym.name.as_ref());
                        if saw_amp {
                            if rest_param.is_some() {
                                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                    "only one rest parameter allowed".to_string(),
                                ))
                                .with_span(p.meta_span()));
                            }
                            rest_param = Some(spur);
                        } else {
                            required.push(spur);
                        }
                    }
                    _ => {
                        return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                            "defmacro parameter must be a symbol".to_string(),
                        ))
                        .with_span(p.meta_span()));
                    }
                }
            }
            if saw_amp && rest_param.is_none() {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "missing rest parameter after &".to_string(),
                ))
                .with_span(args[1].meta_span()));
            }
            (required, rest_param)
        };

        let name_spur = self.interner.get_or_intern(name.name.as_ref());
        let mut fb = FunctionBuilder::new(Some(name_spur), param_items.len() as u8);
        fb.is_variadic = rest.is_some();
        self.functions.push(fb);

        self.begin_scope();
        for param in &param_items {
            let _ = self.declare_local(*param)?;
        }
        if let Some(rest_param) = rest {
            let _ = self.declare_local(rest_param)?;
        }

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // Emit return
        self.emit(OpCode::Return, 0, 0, 0);

        // Get upvalue descriptors (macros shouldn't capture upvalues, but handle it anyway)
        let upvalue_descs = self.current_fn().upvalues.clone();

        // Finalize function and get prototype
        let proto = self.finish_function()?;

        // Transfer prototype to VM and create closure
        let vm = self.vm.as_mut().unwrap();
        let vm_proto_idx = vm.add_prototype(proto);

        // Create closure in VM heap (no upvalues for macros typically)
        let upvalues: Vec<VMValue> = upvalue_descs.iter().map(|_| VMValue::Nil).collect();
        let clause = ClauseInfo {
            proto_idx: vm_proto_idx,
            arity: param_items.len() as u8,
            is_variadic: rest.is_some(),
            patterns: Box::new([]),
            guard_proto_idx: None,
        };
        let closure = super::heap::Closure {
            clauses: Rc::from(vec![clause]),
            upvalues: upvalues.into_boxed_slice(),
        };
        let roots: Vec<HeapKey> = Vec::new();
        let closure_key = vm.heap_mut().alloc(HeapObject::Closure(closure), roots);

        // Register the macro
        self.macros.insert(name_spur, closure_key);

        // defmacro returns nil at runtime (the macro is only used at compile time)
        let idx = self.add_constant(VMValue::Nil);
        self.emit_const(idx);

        Ok(())
    }

    fn expand_macro(
        &mut self,
        name: Spur,
        args: &[Value],
        span: Option<crate::span::Span>,
    ) -> Result<Value, CompileError> {
        let closure_key = *self.macros.get(&name).ok_or_else(|| {
            CompileError::new(CompileErrorKind::UndefinedMacro(
                self.interner.resolve(&name).to_string(),
            ))
            .with_span(span)
        })?;

        // Get mutable reference to VM for storing macro args directly in VM heap
        let vm = self.vm.as_mut().ok_or_else(|| {
            CompileError::new(CompileErrorKind::InvalidSyntax(
                "macro expansion requires VM".to_string(),
            ))
            .with_span(span)
        })?;

        // Convert AST args to VMValue, storing heap objects directly in VM heap
        let vm_args: Vec<VMValue> = args
            .iter()
            .map(|v| Self::value_to_vm_constant(self.interner, vm, v))
            .collect::<Result<_, _>>()?;

        let result = vm
            .apply(VMValue::HeapRef(closure_key), &vm_args)
            .map_err(|e| {
                CompileError::new(CompileErrorKind::MacroExpansionError(e.to_string()))
                    .with_span(span)
            })?;

        // Convert result back to AST
        let mut expanded = self
            .vmvalue_to_value(result)
            .map_err(|e| e.with_span(span))?;

        // Attach call span if expanded code lacks spans
        if expanded.meta_span().is_none() {
            if let Some(s) = span {
                expanded = Value::Meta {
                    value: Box::new(expanded),
                    span: s,
                };
            }
        }

        Ok(expanded)
    }

    /// Convert an AST Value to a VMValue constant, storing in VM heap.
    /// Used for macro expansion where values must be accessible by the running VM.
    fn value_to_vm_constant(
        interner: &mut Rodeo,
        vm: &mut VM,
        value: &Value,
    ) -> Result<VMValue, CompileError> {
        match value.strip_meta() {
            Value::Nil => Ok(VMValue::Nil),
            Value::Bool(b) => Ok(VMValue::Bool(*b)),
            Value::Int(n) => Ok(VMValue::Int(*n)),
            Value::Float(f) => Ok(VMValue::Float(*f)),
            Value::Ratio { numer, denom } => Ok(VMValue::Ratio {
                numer: *numer,
                denom: *denom,
            }),
            Value::String(s) => {
                // Allocate string on heap
                Ok(vm.alloc_string_constant(s.as_ref()))
            }
            Value::Symbol(s) => {
                // Preserve namespace: a/b becomes "a/b", foo becomes "foo"
                let full_name = if let Some(ns) = &s.namespace {
                    format!("{}/{}", ns, s.name)
                } else {
                    s.name.to_string()
                };
                let spur = interner.get_or_intern(&full_name);
                Ok(VMValue::Symbol(spur))
            }
            Value::Keyword(k) => {
                // Preserve namespace: :a/b becomes "a/b", :foo becomes "foo"
                let full_name = if let Some(ns) = &k.namespace {
                    format!("{}/{}", ns, k.name)
                } else {
                    k.name.to_string()
                };
                let spur = interner.get_or_intern(&full_name);
                Ok(VMValue::Keyword(spur))
            }
            Value::Vector(v) => {
                let elements: Result<crate::collections::Vector<VMValue>, _> = v
                    .iter()
                    .map(|e| Self::value_to_vm_constant(interner, vm, e))
                    .collect();
                let seq = super::heap::SeqData {
                    data: elements?,
                    kind: super::heap::SeqKind::Vector,
                };
                if vm.heap().needs_gc() {
                    let roots: Vec<HeapKey> = vm.roots().collect();
                    vm.heap_mut().collect(roots);
                }
                let key = vm.heap_mut().alloc_no_gc(HeapObject::Seq(seq));
                Ok(VMValue::HeapRef(key))
            }
            Value::List(l) => {
                let elements: Result<crate::collections::Vector<VMValue>, _> = l
                    .iter()
                    .map(|e| Self::value_to_vm_constant(interner, vm, e))
                    .collect();
                let seq = super::heap::SeqData {
                    data: elements?,
                    kind: super::heap::SeqKind::List,
                };
                if vm.heap().needs_gc() {
                    let roots: Vec<HeapKey> = vm.roots().collect();
                    vm.heap_mut().collect(roots);
                }
                let key = vm.heap_mut().alloc_no_gc(HeapObject::Seq(seq));
                Ok(VMValue::HeapRef(key))
            }
            Value::Map(m) => {
                let mut map = crate::collections::HashMap::new();
                for (k, v) in m.iter() {
                    let k_vm = Self::value_to_vm_constant(interner, vm, k)?;
                    let v_vm = Self::value_to_vm_constant(interner, vm, v)?;
                    map.insert(k_vm, v_vm);
                }
                if vm.heap().needs_gc() {
                    let roots: Vec<HeapKey> = vm.roots().collect();
                    vm.heap_mut().collect(roots);
                }
                let key = vm.heap_mut().alloc_no_gc(HeapObject::Map(map));
                Ok(VMValue::HeapRef(key))
            }
            Value::Set(s) => {
                let mut set = crate::collections::HashSet::new();
                for e in s.iter() {
                    set.insert(Self::value_to_vm_constant(interner, vm, e)?);
                }
                if vm.heap().needs_gc() {
                    let roots: Vec<HeapKey> = vm.roots().collect();
                    vm.heap_mut().collect(roots);
                }
                let key = vm.heap_mut().alloc_no_gc(HeapObject::Set(set));
                Ok(VMValue::HeapRef(key))
            }
            Value::Regex(re) => {
                if vm.heap().needs_gc() {
                    let roots: Vec<HeapKey> = vm.roots().collect();
                    vm.heap_mut().collect(roots);
                }
                let key = vm
                    .heap_mut()
                    .alloc_no_gc(HeapObject::Regex(re.as_ref().clone()));
                Ok(VMValue::HeapRef(key))
            }
            _ => Err(CompileError::new(CompileErrorKind::UnsupportedExpression(
                "cannot quote this value",
            ))
            .with_span(value.meta_span())),
        }
    }

    /// Convert a VMValue back to an AST Value (reverse of value_to_constant).
    /// Used to convert macro expansion results back to compilable AST.
    fn vmvalue_to_value(&self, value: VMValue) -> Result<Value, CompileError> {
        match value {
            VMValue::Nil => Ok(Value::Nil),
            VMValue::Bool(b) => Ok(Value::Bool(b)),
            VMValue::Int(n) => Ok(Value::Int(n)),
            VMValue::Float(f) => Ok(Value::Float(f)),
            VMValue::Ratio { numer, denom } => Ok(Value::Ratio { numer, denom }),
            VMValue::Symbol(spur) => {
                let resolved = self.interner.resolve(&spur);
                // Special case: "/" is the division symbol with no namespace
                if resolved == "/" {
                    return Ok(Value::Symbol(crate::Symbol {
                        namespace: None,
                        name: "/".into(),
                    }));
                }
                let (namespace, name) = match resolved.split_once('/') {
                    Some((ns, nm)) => (Some(ns.into()), nm.into()),
                    None => (None, resolved.into()),
                };
                Ok(Value::Symbol(crate::Symbol { namespace, name }))
            }
            VMValue::Keyword(spur) => {
                let resolved = self.interner.resolve(&spur);
                // Special case: ":" followed by "/" would be ":/" keyword
                if resolved == "/" {
                    return Ok(Value::Keyword(crate::Keyword {
                        namespace: None,
                        name: "/".into(),
                    }));
                }
                let (namespace, name) = match resolved.split_once('/') {
                    Some((ns, nm)) => (Some(ns.into()), nm.into()),
                    None => (None, resolved.into()),
                };
                Ok(Value::Keyword(crate::Keyword { namespace, name }))
            }
            VMValue::HeapRef(key) => self.heap_ref_to_value(key),
            VMValue::NativeFn(_) => Err(CompileError::new(CompileErrorKind::InvalidMacroResult(
                "cannot convert native function to AST".to_string(),
            ))),
        }
    }

    /// Convert a heap object to an AST Value
    fn heap_ref_to_value(&self, key: HeapKey) -> Result<Value, CompileError> {
        // Use VM heap if available, otherwise use compiler heap
        let heap = self.vm.as_ref().map(|v| v.heap()).unwrap_or(&self.heap);

        match heap.get(key) {
            Some(HeapObject::String(s)) => Ok(Value::String(s.to_string().into())),
            Some(HeapObject::Seq(seq)) => {
                let elements: Result<crate::collections::Vector<Value>, _> =
                    seq.data.iter().map(|v| self.vmvalue_to_value(*v)).collect();
                let elements = elements?;
                match seq.kind {
                    super::heap::SeqKind::List => {
                        let list = crate::list::List::from_iter(elements);
                        Ok(Value::List(std::sync::Arc::new(list)))
                    }
                    super::heap::SeqKind::Vector => Ok(Value::Vector(elements)),
                }
            }
            Some(HeapObject::Map(map)) => {
                let mut result = crate::collections::HashMap::new();
                for (k, v) in map.iter() {
                    let key_val = self.vmvalue_to_value(*k)?;
                    let val_val = self.vmvalue_to_value(*v)?;
                    result.insert(key_val, val_val);
                }
                Ok(Value::Map(result))
            }
            Some(HeapObject::Set(set)) => {
                let mut result = crate::collections::HashSet::new();
                for v in set.iter() {
                    result.insert(self.vmvalue_to_value(*v)?);
                }
                Ok(Value::Set(result))
            }
            Some(HeapObject::Closure(_)) => Err(CompileError::new(
                CompileErrorKind::InvalidMacroResult("cannot convert closure to AST".to_string()),
            )),
            Some(HeapObject::ClosureTemplate(_)) => {
                Err(CompileError::new(CompileErrorKind::InvalidMacroResult(
                    "cannot convert closure template to AST".to_string(),
                )))
            }
            Some(HeapObject::Continuation(_)) => {
                Err(CompileError::new(CompileErrorKind::InvalidMacroResult(
                    "cannot convert continuation to AST".to_string(),
                )))
            }
            Some(HeapObject::Effect(_)) => Err(CompileError::new(
                CompileErrorKind::InvalidMacroResult("cannot convert effect to AST".to_string()),
            )),
            Some(HeapObject::Atom(_)) => Err(CompileError::new(
                CompileErrorKind::InvalidMacroResult("cannot convert atom to AST".to_string()),
            )),
            Some(HeapObject::Optic(_)) => Err(CompileError::new(
                CompileErrorKind::InvalidMacroResult("cannot convert optic to AST".to_string()),
            )),
            Some(HeapObject::Regex(re)) => Ok(Value::Regex(std::sync::Arc::new(re.clone()))),
            Some(HeapObject::KeyBox(v)) => self.vmvalue_to_value(*v),
            Some(HeapObject::Variant(_)) => Err(CompileError::new(
                CompileErrorKind::InvalidMacroResult("cannot convert variant to AST".to_string()),
            )),
            None => Err(CompileError::new(CompileErrorKind::InvalidMacroResult(
                "invalid heap reference".to_string(),
            ))),
        }
    }

    fn compile_assert(&mut self, list: &crate::List) -> Result<(), CompileError> {
        self.compile_assert_with_span(list, None)
    }

    fn compile_assert_with_span(
        &mut self,
        list: &crate::List,
        call_span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // (assert expr) or (assert expr msg)
        let list_span = call_span.or_else(|| list.first().and_then(|v| v.meta_span()));
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "assert requires an expression".to_string(),
            ))
            .with_span(list_span));
        }

        // Compile the test expression
        self.compile_expr(&args[0])?;

        // JumpIfTrue over the error
        let jump_over_error = self.emit_jump(OpCode::JumpIfTrue);

        // If we're here, assertion failed
        // Compile the message or use default
        if args.len() > 1 {
            self.compile_expr(&args[1])?;
        } else {
            let msg = "assertion failed";
            let hip = hipstr::HipStr::from(msg.to_owned());
            let key = self.heap.insert_constant(HeapObject::String(hip));
            let idx = self.add_constant(VMValue::HeapRef(key));
            self.emit_const(idx);
        }

        // Call assert-failed native (which will be registered in natives)
        // For now, we'll emit a call to a global 'assert-failed' function
        let assert_failed_sym = self.interner.get_or_intern("assert-failed");
        let idx = self.add_constant(VMValue::Symbol(assert_failed_sym));
        self.emit(OpCode::GetGlobal, idx as u8, (idx >> 8) as u8, 0);
        // Record span for assertion failure
        self.record_span(call_span);
        self.emit(OpCode::Call, 1, 0, 0);

        // Jump over nil (for when assertion passes)
        let jump_to_end = self.emit_jump(OpCode::Jump);

        // Patch jump to here (assertion passed)
        self.patch_jump(jump_over_error);

        // Assertion passed, return nil
        let nil_idx = self.add_constant(VMValue::Nil);
        self.emit_const(nil_idx);

        // End of assert
        self.patch_jump(jump_to_end);

        Ok(())
    }

    fn compile_quote(&mut self, list: &crate::List) -> Result<(), CompileError> {
        // Get the quoted expression (second element of the list)
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() != 1 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "quote expects exactly 1 argument".to_string(),
            ))
            .with_span(list_span));
        }

        // Convert AST Value to VMValue constant
        let vm_value = self.value_to_constant(&args[0])?;
        let idx = self.add_constant(vm_value);
        self.emit_const(idx);
        Ok(())
    }

    fn compile_macroexpand(
        &mut self,
        list: &crate::List,
        call_span: Option<crate::span::Span>,
        recursive: bool,
    ) -> Result<(), CompileError> {
        let args = list.args_vec();
        if args.len() != 1 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "macroexpand expects exactly 1 argument".to_string(),
            ))
            .with_span(call_span));
        }

        // Extract the form: if it's (quote inner), use inner; otherwise use as-is
        let form = match args[0].strip_meta() {
            Value::List(inner) => {
                if let Some(Value::Symbol(s)) = inner.first().map(|v| v.strip_meta()) {
                    if s.name.as_ref() == "quote" {
                        let inner_args = inner.args_vec();
                        if inner_args.len() == 1 {
                            inner_args.into_iter().next().unwrap()
                        } else {
                            args[0].clone()
                        }
                    } else {
                        args[0].clone()
                    }
                } else {
                    args[0].clone()
                }
            }
            _ => args[0].clone(),
        };

        // Expand macros
        let expanded = self.do_macroexpand(form, call_span, recursive)?;

        // Convert to constant and emit
        let vm_value = self.value_to_constant(&expanded)?;
        let idx = self.add_constant(vm_value);
        self.emit_const(idx);
        Ok(())
    }

    fn do_macroexpand(
        &mut self,
        form: Value,
        span: Option<crate::span::Span>,
        recursive: bool,
    ) -> Result<Value, CompileError> {
        let mut current = form;
        loop {
            match current.strip_meta() {
                Value::List(l) => {
                    if let Some(Value::Symbol(sym)) = l.first().map(|v| v.strip_meta()) {
                        if sym.namespace.is_none() {
                            let name_spur = self.interner.get_or_intern(&sym.name);
                            if self.macros.contains_key(&name_spur) {
                                let args = l.args_vec();
                                let expanded = self.expand_macro(name_spur, &args, span)?;
                                if recursive {
                                    current = expanded;
                                    continue;
                                } else {
                                    return Ok(expanded);
                                }
                            }
                        }
                    }
                    return Ok(current);
                }
                _ => return Ok(current),
            }
        }
    }

    /// Convert an AST Value to a VMValue constant for quote
    fn value_to_constant(&mut self, value: &Value) -> Result<VMValue, CompileError> {
        match value.strip_meta() {
            Value::Nil => Ok(VMValue::Nil),
            Value::Bool(b) => Ok(VMValue::Bool(*b)),
            Value::Int(n) => Ok(VMValue::Int(*n)),
            Value::Float(f) => Ok(VMValue::Float(*f)),
            Value::Ratio { numer, denom } => Ok(VMValue::Ratio {
                numer: *numer,
                denom: *denom,
            }),
            Value::String(s) => {
                let hip = hipstr::HipStr::from(s.as_ref().to_owned());
                let key = self.heap.insert_constant(HeapObject::String(hip));
                Ok(VMValue::HeapRef(key))
            }
            Value::Symbol(s) => {
                // Preserve namespace: a/b becomes "a/b", foo becomes "foo"
                let full_name = if let Some(ns) = &s.namespace {
                    format!("{}/{}", ns, s.name)
                } else {
                    s.name.to_string()
                };
                let spur = self.interner.get_or_intern(&full_name);
                Ok(VMValue::Symbol(spur))
            }
            Value::Keyword(k) => {
                // Preserve namespace: :a/b becomes "a/b", :foo becomes "foo"
                let full_name = if let Some(ns) = &k.namespace {
                    format!("{}/{}", ns, k.name)
                } else {
                    k.name.to_string()
                };
                let spur = self.interner.get_or_intern(&full_name);
                Ok(VMValue::Keyword(spur))
            }
            Value::Vector(v) => {
                // Recursively convert elements
                let elements: Result<crate::collections::Vector<VMValue>, _> =
                    v.iter().map(|e| self.value_to_constant(e)).collect();
                let seq = super::heap::SeqData {
                    data: elements?,
                    kind: super::heap::SeqKind::Vector,
                };
                let key = self.heap.intern_seq_constant(seq);
                Ok(VMValue::HeapRef(key))
            }
            Value::List(l) => {
                // Recursively convert elements
                let elements: Result<crate::collections::Vector<VMValue>, _> =
                    l.iter().map(|e| self.value_to_constant(e)).collect();
                let seq = super::heap::SeqData {
                    data: elements?,
                    kind: super::heap::SeqKind::List,
                };
                let key = self.heap.intern_seq_constant(seq);
                Ok(VMValue::HeapRef(key))
            }
            Value::Map(m) => {
                // Recursively convert key-value pairs
                let mut map = crate::collections::HashMap::new();
                for (k, v) in m.iter() {
                    let k_vm = self.value_to_constant(k)?;
                    let v_vm = self.value_to_constant(v)?;
                    map.insert(k_vm, v_vm);
                }
                let key = self.heap.intern_map_constant(map);
                Ok(VMValue::HeapRef(key))
            }
            Value::Set(s) => {
                // Recursively convert elements
                let mut set = crate::collections::HashSet::new();
                for e in s.iter() {
                    set.insert(self.value_to_constant(e)?);
                }
                let key = self.heap.intern_set_constant(set);
                Ok(VMValue::HeapRef(key))
            }
            Value::Regex(re) => {
                let key = self
                    .heap
                    .insert_constant(HeapObject::Regex(re.as_ref().clone()));
                Ok(VMValue::HeapRef(key))
            }
            _ => Err(CompileError::new(CompileErrorKind::UnsupportedExpression(
                "cannot quote this value",
            ))
            .with_span(value.meta_span())),
        }
    }

    /// Compile syntax-quote (backtick).
    ///
    /// Syntax-quote builds code at compile time, handling:
    /// - unquote (~x) - evaluate x and splice result
    /// - unquote-splicing (~@xs) - evaluate xs and splice elements
    /// - auto-gensym (foo#) - generate unique symbols
    fn compile_syntax_quote(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() != 1 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "syntax-quote expects exactly 1 argument".to_string(),
            ))
            .with_span(list_span));
        }

        // Create a fresh gensym counter for this syntax-quote
        let mut gensym_counter = 0u32;
        let mut gensym_map: HashMap<String, String> = HashMap::new();

        self.compile_syntax_quote_expr(&args[0], &mut gensym_counter, &mut gensym_map)
    }

    fn compile_syntax_quote_expr(
        &mut self,
        value: &Value,
        gensym_counter: &mut u32,
        gensym_map: &mut HashMap<String, String>,
    ) -> Result<(), CompileError> {
        match value.strip_meta() {
            // Handle unquote: ~x evaluates x
            Value::List(l) if self.is_unquote(l) => {
                let args = l.args_vec();
                if args.len() != 1 {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "unquote expects 1 argument".to_string(),
                    ))
                    .with_span(value.meta_span()));
                }
                // Compile the unquoted expression normally
                self.compile_expr(&args[0])
            }

            // Handle unquote-splicing at top level (error)
            Value::List(l) if self.is_unquote_splicing(l) => Err(CompileError::new(
                CompileErrorKind::InvalidSyntax("unquote-splicing not in list context".to_string()),
            )
            .with_span(value.meta_span())),

            // Lists need special handling for unquote-splicing
            Value::List(l) => self.compile_syntax_quote_list(l, gensym_counter, gensym_map),

            // Vectors
            Value::Vector(v) => self.compile_syntax_quote_vector(v, gensym_counter, gensym_map),

            // Symbols with auto-gensym (foo#)
            Value::Symbol(s) if s.name.ends_with('#') => {
                let base = &s.name[..s.name.len() - 1];
                let generated = gensym_map.entry(base.to_string()).or_insert_with(|| {
                    *gensym_counter += 1;
                    format!("{}__{}__auto", base, gensym_counter)
                });
                let spur = self.interner.get_or_intern(generated);
                let idx = self.add_constant(VMValue::Symbol(spur));
                self.emit_const(idx);
                Ok(())
            }

            // Regular values - quote them as constants
            _ => {
                let vm_value = self.value_to_constant(value)?;
                let idx = self.add_constant(vm_value);
                self.emit_const(idx);
                Ok(())
            }
        }
    }

    fn compile_syntax_quote_list(
        &mut self,
        list: &crate::List,
        gensym_counter: &mut u32,
        gensym_map: &mut HashMap<String, String>,
    ) -> Result<(), CompileError> {
        if list.is_empty() {
            // Empty list - just quote it
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
            // Create empty list
            self.emit(OpCode::MakeList, 0, 0, 0);
            return Ok(());
        }

        // We need to build the list at runtime because of potential unquote-splicing
        // Strategy: compile each element, handling splicing, then MakeList

        // Check if any element is unquote-splicing
        let has_splicing = list.iter().any(|e| {
            if let Value::List(l) = e.strip_meta() {
                self.is_unquote_splicing(l)
            } else {
                false
            }
        });

        if has_splicing {
            // Use concat approach: build list of segments, concat them
            // Start with empty list
            self.compile_syntax_quote_list_with_splicing(list, gensym_counter, gensym_map)
        } else {
            // No splicing - simple case, compile each element and MakeList
            let mut count = 0;
            for elem in list.iter() {
                self.compile_syntax_quote_expr(elem, gensym_counter, gensym_map)?;
                count += 1;
            }
            self.emit(OpCode::MakeList, count as u8, (count >> 8) as u8, 0);
            Ok(())
        }
    }

    fn compile_syntax_quote_list_with_splicing(
        &mut self,
        list: &crate::List,
        gensym_counter: &mut u32,
        gensym_map: &mut HashMap<String, String>,
    ) -> Result<(), CompileError> {
        // For lists with unquote-splicing, we need to:
        // 1. Build segments (single elements as 1-element lists, spliced as-is)
        // 2. Concat all segments together

        // We'll emit code that builds segments and concats them
        // Start with empty list
        self.emit(OpCode::MakeList, 0, 0, 0);

        for elem in list.iter() {
            if let Value::List(l) = elem.strip_meta() {
                if self.is_unquote_splicing(l) {
                    // ~@xs: evaluate xs and concat
                    let args = l.args_vec();
                    if args.len() != 1 {
                        return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                            "unquote-splicing expects 1 argument".to_string(),
                        ))
                        .with_span(elem.meta_span()));
                    }
                    self.compile_expr(&args[0])?;
                    // Call concat native: (concat acc xs)
                    let concat_sym = self.interner.get_or_intern("concat");
                    let concat_idx = self.add_constant(VMValue::Symbol(concat_sym));
                    self.emit(
                        OpCode::GetGlobal,
                        concat_idx as u8,
                        (concat_idx >> 8) as u8,
                        0,
                    );
                    self.emit(OpCode::Call, 2, 0, 0);
                    continue;
                }
            }

            // Regular element - wrap in list and concat
            self.compile_syntax_quote_expr(elem, gensym_counter, gensym_map)?;
            self.emit(OpCode::MakeList, 1, 0, 0);
            // concat
            let concat_sym = self.interner.get_or_intern("concat");
            let concat_idx = self.add_constant(VMValue::Symbol(concat_sym));
            self.emit(
                OpCode::GetGlobal,
                concat_idx as u8,
                (concat_idx >> 8) as u8,
                0,
            );
            self.emit(OpCode::Call, 2, 0, 0);
        }

        Ok(())
    }

    fn compile_syntax_quote_vector(
        &mut self,
        vec: &crate::collections::Vector<Value>,
        gensym_counter: &mut u32,
        gensym_map: &mut HashMap<String, String>,
    ) -> Result<(), CompileError> {
        // Check for splicing
        let has_splicing = vec.iter().any(|e| {
            if let Value::List(l) = e.strip_meta() {
                self.is_unquote_splicing(l)
            } else {
                false
            }
        });

        if has_splicing {
            // Build as list first, then convert to vector using vec native
            // Start with empty list
            self.emit(OpCode::MakeList, 0, 0, 0);

            for elem in vec.iter() {
                if let Value::List(l) = elem.strip_meta() {
                    if self.is_unquote_splicing(l) {
                        let args = l.args_vec();
                        if args.len() != 1 {
                            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                "unquote-splicing expects 1 argument".to_string(),
                            ))
                            .with_span(elem.meta_span()));
                        }
                        self.compile_expr(&args[0])?;
                        let concat_sym = self.interner.get_or_intern("concat");
                        let concat_idx = self.add_constant(VMValue::Symbol(concat_sym));
                        self.emit(
                            OpCode::GetGlobal,
                            concat_idx as u8,
                            (concat_idx >> 8) as u8,
                            0,
                        );
                        self.emit(OpCode::Call, 2, 0, 0);
                        continue;
                    }
                }
                self.compile_syntax_quote_expr(elem, gensym_counter, gensym_map)?;
                self.emit(OpCode::MakeList, 1, 0, 0);
                let concat_sym = self.interner.get_or_intern("concat");
                let concat_idx = self.add_constant(VMValue::Symbol(concat_sym));
                self.emit(
                    OpCode::GetGlobal,
                    concat_idx as u8,
                    (concat_idx >> 8) as u8,
                    0,
                );
                self.emit(OpCode::Call, 2, 0, 0);
            }

            // Convert list to vector
            let vec_sym = self.interner.get_or_intern("vec");
            let vec_idx = self.add_constant(VMValue::Symbol(vec_sym));
            self.emit(OpCode::GetGlobal, vec_idx as u8, (vec_idx >> 8) as u8, 0);
            self.emit(OpCode::Call, 1, 0, 0);
        } else {
            // No splicing - compile elements and MakeVector
            let mut count = 0;
            for elem in vec.iter() {
                self.compile_syntax_quote_expr(elem, gensym_counter, gensym_map)?;
                count += 1;
            }
            self.emit(OpCode::MakeVector, count as u8, (count >> 8) as u8, 0);
        }

        Ok(())
    }

    fn is_unquote(&self, list: &crate::List) -> bool {
        if let Some(first) = list.first() {
            if let Value::Symbol(s) = first.strip_meta() {
                return s.name.as_ref() == "unquote";
            }
        }
        false
    }

    fn is_unquote_splicing(&self, list: &crate::List) -> bool {
        if let Some(first) = list.first() {
            if let Value::Symbol(s) = first.strip_meta() {
                return s.name.as_ref() == "unquote-splicing";
            }
        }
        false
    }

    fn compile_loop(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "loop requires bindings vector".to_string(),
            ))
            .with_span(list_span));
        }

        // Get bindings vector
        let bindings = match args[0].strip_meta() {
            Value::Vector(v) => v.clone(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "loop bindings must be a vector".to_string(),
                ))
                .with_span(args[0].meta_span()));
            }
        };

        // Validate even binding count
        if bindings.len() % 2 != 0 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "loop bindings must have even count".to_string(),
            ))
            .with_span(args[0].meta_span()));
        }

        let body = &args[1..];
        let local_count_before = self.current_fn().local_count;
        let param_count = (bindings.len() / 2) as u8;

        // Save tail position - bindings are NOT in tail, body IS (for recur)
        let was_tail = self.current_fn().in_tail_position;

        // Begin new scope
        self.begin_scope();

        // Compile initial bindings (same as let)
        // Binding expressions are NOT in tail position
        self.current_fn_mut().in_tail_position = false;
        let mut binding_slots = Vec::new();
        let mut i = 0;
        while i < bindings.len() {
            let pattern = &bindings[i];
            let expr = &bindings[i + 1];

            // Compile the init expression
            self.compile_expr(expr)?;

            // For loop, we only support simple symbol patterns for recur
            match pattern.strip_meta() {
                Value::Symbol(sym) if sym.namespace.is_none() => {
                    let name = self.interner.get_or_intern(sym.name.as_ref());
                    let slot = self.declare_local(name)?;
                    self.emit(OpCode::SetLocal, slot, 0, 0);
                    binding_slots.push(slot);
                }
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "only simple symbol patterns supported in loop bindings".to_string(),
                    ))
                    .with_span(pattern.meta_span()));
                }
            }
            i += 2;
        }

        // Record loop start (current IP)
        let loop_start = self.current_fn().code.len() as u32;

        // Push LoopInfo for recur
        self.current_fn_mut().loops.push(LoopInfo {
            start_ip: loop_start,
            local_count: local_count_before,
            param_count,
        });

        // Store binding slots in LoopInfo for recur (we need to extend LoopInfo)
        // For now, store the first slot - recur will reassign slots starting from there
        let first_binding_slot = binding_slots.first().copied().unwrap_or(0);

        // Body is in tail position (for recur to work)
        self.current_fn_mut().in_tail_position = true;

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // Pop LoopInfo
        self.current_fn_mut().loops.pop();

        // Restore tail position
        self.current_fn_mut().in_tail_position = was_tail;

        // End scope
        self.end_scope();

        // Store first_binding_slot for use by recur (hacky but works)
        let _ = first_binding_slot;

        Ok(())
    }

    fn compile_recur(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();

        // recur must be in tail position
        if !self.current_fn().in_tail_position {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "recur must be in tail position".to_string(),
            ))
            .with_span(list_span));
        }

        // Get current loop info - extract values to avoid borrow issues
        let (start_ip, base_slot, param_count) = {
            let loop_info = self.current_fn().loops.last().ok_or_else(|| {
                CompileError::new(CompileErrorKind::InvalidSyntax(
                    "recur outside of loop".to_string(),
                ))
                .with_span(list_span)
            })?;
            (
                loop_info.start_ip,
                loop_info.local_count,
                loop_info.param_count,
            )
        };

        // Validate arity
        if args.len() != param_count as usize {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(format!(
                "recur arity mismatch: expected {}, got {}",
                param_count,
                args.len()
            )))
            .with_span(list_span));
        }

        // Compile all new values first
        for arg in &args {
            self.compile_expr(arg)?;
        }

        // Assign to loop variables in reverse order (so stack pops work correctly)
        // The loop variables are at slots [local_count..local_count + param_count]
        for i in (0..args.len()).rev() {
            self.emit(OpCode::SetLocal, base_slot + i as u8, 0, 0);
        }

        // Jump back to loop start
        let current_ip = self.current_fn().code.len() as i32;
        let offset = start_ip as i32 - current_ip - 1;
        let [a1, a2] = (offset as i16).to_le_bytes();
        self.emit(OpCode::Jump, a1, a2, 0);

        // Push a nil on stack since recur doesn't really return (the jump means this is unreachable)
        // But the type system expects something on the stack
        let idx = self.add_constant(VMValue::Nil);
        self.emit_const(idx);

        Ok(())
    }

    /// Compile (and ...) with short-circuit evaluation
    fn compile_and(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let args = list.args_vec();

        // (and) => true
        if args.is_empty() {
            let idx = self.add_constant(VMValue::Bool(true));
            self.emit_const(idx);
            return Ok(());
        }

        // (and x) => x
        if args.len() == 1 {
            self.compile_expr(&args[0])?;
            return Ok(());
        }

        // (and a b c ...) => short-circuit evaluation
        // For each arg: if falsy, jump to end with that value; else pop and continue
        let mut end_jumps = Vec::new();

        for (i, arg) in args.iter().enumerate() {
            self.compile_expr(arg)?;

            // Last arg: don't add a jump, just leave value on stack
            if i < args.len() - 1 {
                // Duplicate value for the falsy check
                self.emit(OpCode::Dup, 0, 0, 0);
                // If falsy, jump to end
                let jump_offset = self.current_fn().code.len();
                self.emit(OpCode::JumpIfFalse, 0, 0, 0); // placeholder
                end_jumps.push(jump_offset);
                // Pop duplicate (value was truthy, continue)
                self.emit(OpCode::Pop, 0, 0, 0);
            }
        }

        // Patch all end jumps to here
        let end_ip = self.current_fn().code.len();
        for jump_offset in end_jumps {
            let offset = end_ip as i16 - jump_offset as i16 - 1;
            let [a1, a2] = offset.to_le_bytes();
            self.current_fn_mut().code[jump_offset] = encode(OpCode::JumpIfFalse, a1, a2, 0);
        }

        Ok(())
    }

    /// Compile (or ...) with short-circuit evaluation
    fn compile_or(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let args = list.args_vec();

        // (or) => nil
        if args.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
            return Ok(());
        }

        // (or x) => x
        if args.len() == 1 {
            self.compile_expr(&args[0])?;
            return Ok(());
        }

        // (or a b c ...) => short-circuit evaluation
        // For each arg: if truthy, jump to end with that value; else pop and continue
        let mut end_jumps = Vec::new();

        for (i, arg) in args.iter().enumerate() {
            self.compile_expr(arg)?;

            // Last arg: don't add a jump, just leave value on stack
            if i < args.len() - 1 {
                // Duplicate value for the truthy check
                self.emit(OpCode::Dup, 0, 0, 0);
                // If truthy, jump to end
                let jump_offset = self.current_fn().code.len();
                self.emit(OpCode::JumpIfTrue, 0, 0, 0); // placeholder
                end_jumps.push(jump_offset);
                // Pop duplicate (value was falsy, continue)
                self.emit(OpCode::Pop, 0, 0, 0);
            }
        }

        // Patch all end jumps to here
        let end_ip = self.current_fn().code.len();
        for jump_offset in end_jumps {
            let offset = end_ip as i16 - jump_offset as i16 - 1;
            let [a1, a2] = offset.to_le_bytes();
            self.current_fn_mut().code[jump_offset] = encode(OpCode::JumpIfTrue, a1, a2, 0);
        }

        Ok(())
    }

    fn compile_with_handler(&mut self, list: &crate::List) -> Result<(), CompileError> {
        // Support two syntaxes:
        // 1. Simplified: (with-handler effect-symbol handler-fn body...)
        // 2. Full: (with-handler [effect] body... :handle (op [params k] handler-body)...)

        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() < 2 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "with-handler requires at least effect and body".to_string(),
            ))
            .with_span(list_span));
        }

        // Detect which syntax is being used
        let first = args[0].strip_meta();
        if let Value::Vector(effect_vec) = first {
            // Full syntax: (with-handler [effect] body... :handle ...)
            return self.compile_with_handler_full(&args, effect_vec);
        }

        // Simplified syntax: (with-handler effect-symbol handler-fn body...)
        let effect = &args[0];
        let handler_fn = &args[1];
        let body = &args[2..];

        // Get the effect symbol
        let effect_spur = match effect.strip_meta() {
            Value::Symbol(sym) => self.interner.get_or_intern(sym.name.as_ref()),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "with-handler requires a named effect; local effects from let bindings are not supported — use def instead".to_string(),
                ))
                .with_span(effect.meta_span()));
            }
        };

        // Compile handler function (pushes closure onto stack)
        self.compile_expr(handler_fn)?;

        // Emit PushHandler
        let effect_const = self.add_constant(VMValue::Symbol(effect_spur));
        self.emit(
            OpCode::PushHandler,
            effect_const as u8,
            (effect_const >> 8) as u8,
            0,
        );

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // Emit PopHandler
        self.emit(OpCode::PopHandler, 0, 0, 0);

        Ok(())
    }

    fn compile_with_handler_full(
        &mut self,
        args: &[Value],
        effect_vec: &crate::collections::Vector<Value>,
    ) -> Result<(), CompileError> {
        // (with-handler [effect-expr] body... :handle (op [params k] body)...)
        if effect_vec.len() != 1 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "with-handler effect binding must contain exactly one expression".to_string(),
            ))
            .with_span(args[0].meta_span()));
        }

        let effect_expr = &effect_vec[0];

        // Split args at :handle keyword
        let rest = &args[1..];
        let mut body_exprs: Vec<Value> = Vec::new();
        let mut handler_clauses: Vec<Value> = Vec::new();
        let mut in_handlers = false;

        for arg in rest {
            match arg.strip_meta() {
                Value::Keyword(kw) if kw.name.as_ref() == "handle" => {
                    in_handlers = true;
                }
                _ if in_handlers => {
                    handler_clauses.push(arg.clone());
                }
                _ => {
                    body_exprs.push(arg.clone());
                }
            }
        }

        if handler_clauses.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "with-handler requires at least one :handle clause".to_string(),
            ))
            .with_span(args[0].meta_span()));
        }

        // Get the effect symbol from the effect expression
        let effect_spur = match effect_expr.strip_meta() {
            Value::Symbol(sym) => self.interner.get_or_intern(sym.name.as_ref()),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "with-handler requires a named effect; local effects from let bindings are not supported — use def instead".to_string(),
                ))
                .with_span(effect_expr.meta_span()));
            }
        };

        // Compile each handler clause as a closure and build dispatch table
        // Format: (op-name [params k] body...)
        let mut dispatch_entries = Vec::new();

        for clause in &handler_clauses {
            let clause_list = match clause.strip_meta() {
                Value::List(l) => l,
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        ":handle clause must be a list".to_string(),
                    ))
                    .with_span(clause.meta_span()));
                }
            };

            let clause_args = clause_list.args_vec();
            if clause_args.len() < 2 {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    ":handle clause requires (op-name [params] body...)".to_string(),
                ))
                .with_span(clause.meta_span()));
            }

            // Get operation name
            let op_name = match clause_list.first() {
                Some(v) => match v.strip_meta() {
                    Value::Symbol(sym) => self.interner.get_or_intern(sym.name.as_ref()),
                    _ => {
                        return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                            "handler operation name must be a symbol".to_string(),
                        ))
                        .with_span(v.meta_span()));
                    }
                },
                None => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "handler clause is empty".to_string(),
                    ))
                    .with_span(clause.meta_span()));
                }
            };

            // Get params vector
            let params = match clause_args[0].strip_meta() {
                Value::Vector(v) => v.clone(),
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "handler params must be a vector".to_string(),
                    ))
                    .with_span(clause_args[0].meta_span()));
                }
            };

            // Collect param patterns (can be symbols, vectors, or maps for destructuring)
            let param_patterns: Vec<Value> = params.iter().cloned().collect();

            // Compile handler as a function with pattern support
            let handler_body = &clause_args[1..];
            self.compile_handler_fn_with_patterns(&param_patterns, handler_body)?;

            dispatch_entries.push(op_name);
        }

        // Build dispatch table: {op_symbol: closure, ...}
        // Stack now has closures in order, we need to build a map
        // Push op symbols and interleave with closures
        let n_handlers = dispatch_entries.len();

        // Closures are on stack, we need to reorganize for MakeMap
        // MakeMap expects pairs: k1 v1 k2 v2 ...
        // Currently stack has: ... closure1 closure2 ...
        // We need: ... :op1 closure1 :op2 closure2 ...

        // Save closures to locals temporarily (we don't have a good way to do this)
        // Instead, emit symbols before each closure during compilation

        // Actually, let's restructure: emit symbol, then compile closure, for each
        // We need to redo the loop...

        // Pop all the closures we just compiled
        for _ in 0..n_handlers {
            self.emit(OpCode::Pop, 0, 0, 0);
        }

        // Re-compile with interleaved symbols and closures
        for clause in &handler_clauses {
            let clause_list = match clause.strip_meta() {
                Value::List(l) => l,
                _ => unreachable!(),
            };

            let clause_args = clause_list.args_vec();
            let op_name = match clause_list.first().unwrap().strip_meta() {
                Value::Symbol(sym) => self.interner.get_or_intern(sym.name.as_ref()),
                _ => unreachable!(),
            };

            // Push op symbol
            let op_const = self.add_constant(VMValue::Symbol(op_name));
            self.emit_const(op_const);

            // Get params (can be patterns, not just symbols)
            let params = match clause_args[0].strip_meta() {
                Value::Vector(v) => v.clone(),
                _ => unreachable!(),
            };
            let param_patterns: Vec<Value> = params.iter().cloned().collect();

            // Compile handler closure with pattern support
            let handler_body = &clause_args[1..];
            self.compile_handler_fn_with_patterns(&param_patterns, handler_body)?;
        }

        // Build dispatch table map
        self.emit(
            OpCode::MakeMap,
            n_handlers as u8,
            (n_handlers >> 8) as u8,
            0,
        );

        // Emit PushHandler with effect symbol
        let effect_const = self.add_constant(VMValue::Symbol(effect_spur));
        self.emit(
            OpCode::PushHandler,
            effect_const as u8,
            (effect_const >> 8) as u8,
            0,
        );

        // Compile body (implicit do)
        if body_exprs.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            // Pop intermediate results, keep last
            for (i, expr) in body_exprs.iter().enumerate() {
                self.compile_expr(expr)?;
                if i < body_exprs.len() - 1 {
                    self.emit(OpCode::Pop, 0, 0, 0);
                }
            }
        }

        // Emit PopHandler
        self.emit(OpCode::PopHandler, 0, 0, 0);

        Ok(())
    }

    fn compile_handler_fn(
        &mut self,
        params: &[lasso::Spur],
        body: &[Value],
    ) -> Result<(), CompileError> {
        // Compile a handler function: similar to compile_fn_expr but with pre-parsed params
        self.functions
            .push(FunctionBuilder::new(None, params.len() as u8));

        // Bind parameters as locals
        self.begin_scope();
        for param in params.iter() {
            let _ = self.declare_local(*param)?;
        }

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // Emit return
        self.emit(OpCode::Return, 0, 0, 0);

        // Get upvalue descriptors
        let upvalue_descs = self.current_fn().upvalues.clone();
        let n_upvalues = upvalue_descs.len();

        // Finalize function
        let proto = self.finish_function()?;
        let proto_idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);

        // Emit upvalue captures
        for upval in &upvalue_descs {
            match upval {
                UpvalueDesc::Local(slot) => {
                    self.emit(OpCode::GetLocal, *slot, 0, 0);
                }
                UpvalueDesc::Upvalue(slot) => {
                    self.emit(OpCode::GetUpvalue, *slot, 0, 0);
                }
            }
        }

        // Emit MakeClosure
        self.emit(
            OpCode::MakeClosure,
            proto_idx as u8,
            (proto_idx >> 8) as u8,
            n_upvalues as u8,
        );

        Ok(())
    }

    /// Compile a handler function with pattern destructuring support.
    /// Unlike compile_handler_fn, this allows destructuring patterns in parameters.
    fn compile_handler_fn_with_patterns(
        &mut self,
        param_patterns: &[Value],
        body: &[Value],
    ) -> Result<(), CompileError> {
        let n_params = param_patterns.len();
        self.functions
            .push(FunctionBuilder::new(None, n_params as u8));

        self.begin_scope();

        // First pass: allocate slots for raw args
        // For simple symbols, use the symbol name directly
        // For complex patterns, use temp names (args will be at these slots)
        let mut patterns_to_bind: Vec<(u8, Value)> = Vec::new();

        for (i, pattern) in param_patterns.iter().enumerate() {
            match pattern.strip_meta() {
                Value::Symbol(sym) if sym.namespace.is_none() => {
                    // Simple symbol - just declare it as a local
                    let name = self.interner.get_or_intern(sym.name.as_ref());
                    let _ = self.declare_local(name)?;
                }
                _ => {
                    // Complex pattern - declare temp slot, schedule destructuring
                    let temp_name = self.interner.get_or_intern(&format!("__arg{}__", i));
                    let slot = self.declare_local(temp_name)?;
                    patterns_to_bind.push((slot, pattern.clone()));
                }
            }
        }

        // Second pass: emit destructuring code for complex patterns
        for (slot, pattern) in patterns_to_bind {
            self.emit(OpCode::GetLocal, slot, 0, 0);
            self.compile_pattern_binding(&pattern)?;
        }

        // Compile body
        if body.is_empty() {
            let idx = self.add_constant(VMValue::Nil);
            self.emit_const(idx);
        } else {
            self.compile_do(body)?;
        }

        // Emit return
        self.emit(OpCode::Return, 0, 0, 0);

        // Get upvalue descriptors
        let upvalue_descs = self.current_fn().upvalues.clone();
        let n_upvalues = upvalue_descs.len();

        // Finalize function
        let proto = self.finish_function()?;
        let proto_idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);

        // Emit upvalue captures
        for upval in &upvalue_descs {
            match upval {
                UpvalueDesc::Local(slot) => {
                    self.emit(OpCode::GetLocal, *slot, 0, 0);
                }
                UpvalueDesc::Upvalue(slot) => {
                    self.emit(OpCode::GetUpvalue, *slot, 0, 0);
                }
            }
        }

        // Emit MakeClosure
        self.emit(
            OpCode::MakeClosure,
            proto_idx as u8,
            (proto_idx >> 8) as u8,
            n_upvalues as u8,
        );

        Ok(())
    }

    fn compile_perform(&mut self, list: &crate::List) -> Result<(), CompileError> {
        // (perform effect arg1 arg2 ...)
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "perform requires an effect".to_string(),
            ))
            .with_span(list_span));
        }

        // Get the effect symbol
        let effect = &args[0];
        let effect_spur = match effect.strip_meta() {
            Value::Symbol(sym) => self.interner.get_or_intern(sym.name.as_ref()),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "perform effect must be a symbol".to_string(),
                ))
                .with_span(effect.meta_span()));
            }
        };

        // Compile effect args
        for arg in &args[1..] {
            self.compile_expr(arg)?;
        }

        // Emit Perform
        let effect_const = self.add_constant(VMValue::Symbol(effect_spur));
        let n_args = (args.len() - 1) as u8;
        self.record_span(list_span);
        self.emit(
            OpCode::Perform,
            effect_const as u8,
            (effect_const >> 8) as u8,
            n_args,
        );

        Ok(())
    }

    fn compile_effect(&mut self, list: &crate::List) -> Result<(), CompileError> {
        // (effect (op1 [params]) (op2 [params]) ...)
        // Compiles to: push ops vector, call __make_effect__ native
        let args = list.args_vec();

        // Parse operation signatures and build the ops vector
        // Format: [[op_name arity] [op_name arity] ...]
        let mut ops_elements = Vec::new();

        for op in &args {
            let op_list = match op.strip_meta() {
                Value::List(l) => l,
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "effect operation must be a list".to_string(),
                    ))
                    .with_span(op.meta_span()));
                }
            };

            // Get operation name
            let op_name = match op_list.first() {
                Some(n) => match n.strip_meta() {
                    Value::Symbol(sym) if sym.namespace.is_none() => {
                        self.interner.get_or_intern(sym.name.as_ref())
                    }
                    _ => {
                        return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                            "operation name must be an unqualified symbol".to_string(),
                        ))
                        .with_span(n.meta_span()));
                    }
                },
                None => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "empty operation definition".to_string(),
                    ))
                    .with_span(op.meta_span()));
                }
            };

            // Get arity from params vector
            let rest = op_list.rest();
            let arity = if !rest.is_empty() {
                match rest.first() {
                    Some(first_arg) => match first_arg.strip_meta() {
                        Value::Vector(v) => v.len() as u8,
                        _ => 0, // No params vector means 0 arity
                    },
                    None => 0,
                }
            } else {
                0
            };

            // Push [op_name, arity] pair
            let name_const = self.add_constant(VMValue::Symbol(op_name));
            self.emit_const(name_const);
            let arity_const = self.add_constant(VMValue::Int(arity as i64));
            self.emit_const(arity_const);
            ops_elements.push(()); // Just counting
            ops_elements.push(());
        }

        // Build vector of [symbol, int] pairs
        let n_elements = ops_elements.len();
        if n_elements > 0 {
            self.emit(
                OpCode::MakeVector,
                n_elements as u8,
                (n_elements >> 8) as u8,
                0,
            );
        } else {
            self.emit(OpCode::MakeVector, 0, 0, 0);
        }

        // Call __make_effect__ native
        // Look up the native index for __make_effect__
        let make_effect_sym = self.interner.get_or_intern("__make_effect__");
        let sym_const = self.add_constant(VMValue::Symbol(make_effect_sym));
        self.emit(
            OpCode::GetGlobal,
            sym_const as u8,
            (sym_const >> 8) as u8,
            0,
        );

        // Call with 1 argument (the ops vector)
        self.emit(OpCode::Call, 1, 0, 0);

        Ok(())
    }

    fn compile_effect_op_call(
        &mut self,
        effect_ns: &std::sync::Arc<str>,
        op_name: &std::sync::Arc<str>,
        args: &[Value],
        call_span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        // Compile (ns/op arg1 arg2 ...) as an effect operation call
        // This compiles to: PerformOp effect_const op_const n_args
        // where effect_const is the symbol for the effect global,
        // and op_const is the symbol for the operation name

        if args.len() > 255 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "too many arguments (max 255)".to_string(),
            )));
        }

        // Save tail position for arguments
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;

        // Compile arguments first
        for arg in args {
            self.compile_expr(arg)?;
        }

        // Restore tail position
        self.current_fn_mut().in_tail_position = was_tail;

        // Add effect namespace as symbol constant
        let effect_spur = self.interner.get_or_intern(effect_ns.as_ref());
        let effect_const = self.add_constant(VMValue::Symbol(effect_spur));

        // Add operation name as symbol constant
        let op_spur = self.interner.get_or_intern(op_name.as_ref());
        let op_const = self.add_constant(VMValue::Symbol(op_spur));

        // Emit PerformOp opcode
        // Note: effect_const and op_const are limited to 8 bits each (256 constants)
        if effect_const > 255 || op_const > 255 {
            return Err(CompileError::new(CompileErrorKind::TooManyConstants).with_span(call_span));
        }

        self.record_span(call_span);
        self.emit(
            OpCode::PerformOp,
            effect_const as u8,
            op_const as u8,
            args.len() as u8,
        );

        Ok(())
    }

    fn compile_defdata(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.is_empty() {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "defdata requires a type name".to_string(),
            ))
            .with_span(list_span));
        }

        // Parse family name
        let family_name = match args[0].strip_meta() {
            Value::Symbol(sym) => sym.name.to_string(),
            _ => {
                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "defdata name must be a symbol".to_string(),
                ))
                .with_span(args[0].meta_span()));
            }
        };
        let family_spur = self.interner.get_or_intern(&family_name);

        // Parse variant specs
        let mut variant_defs = Vec::new();
        let mut variant_infos: Vec<(String, Spur, Vec<Spur>)> = Vec::new(); // (name_str, name_spur, field_spurs)

        for variant_spec in &args[1..] {
            let (var_name, field_names) = match variant_spec.strip_meta() {
                Value::List(l) => {
                    let items: Vec<_> = l.iter().collect();
                    if items.is_empty() {
                        return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                            "empty variant spec".to_string(),
                        ))
                        .with_span(variant_spec.meta_span()));
                    }
                    let name = match items[0].strip_meta() {
                        Value::Symbol(sym) => sym.name.to_string(),
                        _ => {
                            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                "variant name must be a symbol".to_string(),
                            ))
                            .with_span(items[0].meta_span()));
                        }
                    };
                    let fields = if items.len() > 1 {
                        match items[1].strip_meta() {
                            Value::Vector(v) => v
                                .iter()
                                .map(|f| match f.strip_meta() {
                                    Value::Symbol(sym) => Ok(sym.name.to_string()),
                                    _ => Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                        "field name must be a symbol".to_string(),
                                    ))
                                    .with_span(f.meta_span())),
                                })
                                .collect::<Result<Vec<_>, _>>()?,
                            _ => {
                                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                    "variant fields must be a vector".to_string(),
                                ))
                                .with_span(items[1].meta_span()));
                            }
                        }
                    } else {
                        Vec::new()
                    };
                    (name, fields)
                }
                _ => {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "variant spec must be a list like (Name [field1 field2])".to_string(),
                    ))
                    .with_span(variant_spec.meta_span()));
                }
            };

            let var_spur = self.interner.get_or_intern(&var_name);
            let field_spurs: Vec<Spur> = field_names
                .iter()
                .map(|f| self.interner.get_or_intern(f))
                .collect();

            let mut field_index = FxHashMap::default();
            for (i, &spur) in field_spurs.iter().enumerate() {
                field_index.insert(spur, i as u8);
            }

            variant_defs.push(VariantDef {
                name: var_spur,
                field_names: field_spurs.clone().into_boxed_slice(),
                field_index,
                singleton_key: None, // Will be set below for nullary
            });

            variant_infos.push((var_name, var_spur, field_spurs));
        }

        // Register in type registry (via VM if available)
        let type_id = if let Some(ref mut vm) = self.vm {
            // For zero-field variants, pre-allocate singletons on VM heap
            for (i, vdef) in variant_defs.iter_mut().enumerate() {
                if vdef.field_names.is_empty() {
                    let tid_placeholder = TypeId(vm.type_registry().type_count() as u16);
                    let inst = VariantInstance::new(tid_placeholder, i as u8, Vec::new());
                    let key = vm.heap_mut().alloc_no_gc(HeapObject::Variant(inst));
                    vdef.singleton_key = Some(key);
                }
            }
            vm.type_registry_mut().register(family_spur, variant_defs)
        } else {
            // No VM - allocate singletons on compiler heap
            let tid_placeholder = TypeId(0); // Will be adjusted on import
            for (i, vdef) in variant_defs.iter_mut().enumerate() {
                if vdef.field_names.is_empty() {
                    let inst = VariantInstance::new(tid_placeholder, i as u8, Vec::new());
                    let key = self.heap.insert_constant(HeapObject::Variant(inst));
                    vdef.singleton_key = Some(key);
                }
            }
            // For now, use a dummy TypeId - this path is uncommon
            TypeId(0)
        };

        // Now fix singleton tags if we have the real type_id
        if let Some(ref mut vm) = self.vm {
            for (i, info) in variant_infos.iter().enumerate() {
                if info.2.is_empty() {
                    // Update the singleton's tag with the correct type_id
                    if let Some(typedef) = vm.type_registry().get(type_id) {
                        if let Some(key) = typedef.variants[i].singleton_key {
                            if let Some(HeapObject::Variant(inst)) = vm.heap_mut().get_mut(key) {
                                inst.tag = ((type_id.0 as u32) << 8) | (i as u32);
                            }
                        }
                    }
                }
            }
        }

        // Register variant constructors for pattern matching
        for (i, info) in variant_infos.iter().enumerate() {
            let var_spur = info.1;
            self.variant_constructors
                .insert(var_spur, (type_id, i as u8, info.2.len()));
        }

        // Compile constructor functions for each variant
        for (i, info) in variant_infos.iter().enumerate() {
            let _var_name = &info.0;
            let var_spur = info.1;
            let field_count = info.2.len();

            // Compile a function: (fn [f1 f2 ...] <MakeVariant>)
            let name_spur = Some(var_spur);
            let arity = field_count as u8;

            let fb = FunctionBuilder::new(name_spur, arity);
            self.functions.push(fb);
            self.begin_scope();

            // Declare locals for params
            for (_j, &field_spur) in info.2.iter().enumerate() {
                let _ = self.declare_local(field_spur)?;
            }

            // Emit GetLocal for each field, then MakeVariant
            for j in 0..field_count {
                self.emit(OpCode::GetLocal, j as u8, 0, 0);
            }

            let [tid_lo, tid_hi] = type_id.0.to_le_bytes();
            self.emit(OpCode::MakeVariant, tid_lo, tid_hi, i as u8);
            self.emit(OpCode::Return, 0, 0, 0);

            let proto = self.finish_function()?;
            let proto_idx = self.prototypes.len() as u32;
            self.prototypes.push(proto);

            // Emit MakeClosure + DefGlobal for this constructor
            self.emit(
                OpCode::MakeClosure,
                proto_idx as u8,
                (proto_idx >> 8) as u8,
                0,
            );
            self.emit(OpCode::Dup, 0, 0, 0);
            let sym_idx = self.add_constant(VMValue::Symbol(var_spur));
            self.emit(OpCode::DefGlobal, sym_idx as u8, (sym_idx >> 8) as u8, 0);

            // Track global slot
            if !self.global_slots.contains_key(&var_spur) {
                self.global_slots.insert(var_spur, self.next_global_slot);
                self.next_global_slot += 1;
            }

            // Pop the dup'd value (constructor is defined but we don't need it on stack)
            self.emit(OpCode::Pop, 0, 0, 0);
        }

        // Compile variant predicate functions: VariantName?
        for (i, info) in variant_infos.iter().enumerate() {
            let pred_name = format!("{}?", info.0);
            let pred_spur = self.interner.get_or_intern(&pred_name);

            self.compile_variant_predicate(pred_spur, type_id, i as u8, &info.2)?;

            // Pop the dup'd value
            self.emit(OpCode::Pop, 0, 0, 0);
        }

        // Compile family predicate: FamilyName?
        {
            let pred_name = format!("{}?", family_name);
            let pred_spur = self.interner.get_or_intern(&pred_name);

            self.compile_family_predicate(pred_spur, type_id, &variant_infos)?;

            self.emit(OpCode::Pop, 0, 0, 0);
        }

        // defdata returns nil
        let nil_idx = self.add_constant(VMValue::Nil);
        self.emit_const(nil_idx);

        Ok(())
    }

    /// Compile a variant predicate function (e.g., Ok?) using pattern matching
    fn compile_variant_predicate(
        &mut self,
        pred_spur: Spur,
        type_id: TypeId,
        variant_idx: u8,
        field_spurs: &[Spur],
    ) -> Result<(), CompileError> {
        // Build two clauses: one that matches the variant (returns true), one wildcard (returns false)
        let field_count = field_spurs.len();

        // Clause 1: matches the variant -> return true
        let fb1 = FunctionBuilder::new(Some(pred_spur), 1);
        self.functions.push(fb1);
        self.begin_scope();

        // Declare a throwaway local for the single parameter
        let param_spur = self.interner.get_or_intern("x__match");
        let _ = self.declare_local(param_spur)?;

        // Also declare wildcard locals for each field
        for j in 0..field_count {
            let field_local = self.interner.get_or_intern(&format!("_f{}", j));
            let _ = self.declare_local(field_local)?;
        }

        let true_const = self.add_constant(VMValue::Bool(true));
        self.emit_const(true_const);
        self.emit(OpCode::Return, 0, 0, 0);

        let proto1 = self.finish_function()?;
        let proto1_idx = self.prototypes.len() as u32;
        self.prototypes.push(proto1);

        // Build variant pattern for clause 1
        let field_patterns: Vec<CompiledPattern> = (0..field_count)
            .map(|j| {
                CompiledPattern::Bind {
                    slot: (j + 1) as u8,
                } // slot 0 is the whole arg
            })
            .collect();

        let pattern1 = CompiledPattern::Variant {
            type_id,
            variant_idx,
            field_patterns: field_patterns.into_boxed_slice(),
        };

        let clause1 = ClauseInfo {
            proto_idx: proto1_idx,
            arity: 1,
            is_variadic: false,
            patterns: Box::new([pattern1]),
            guard_proto_idx: None,
        };

        // Clause 2: wildcard -> return false
        let fb2 = FunctionBuilder::new(Some(pred_spur), 1);
        self.functions.push(fb2);
        self.begin_scope();
        let _ = self.declare_local(param_spur)?;

        let false_const = self.add_constant(VMValue::Bool(false));
        self.emit_const(false_const);
        self.emit(OpCode::Return, 0, 0, 0);

        let proto2 = self.finish_function()?;
        let proto2_idx = self.prototypes.len() as u32;
        self.prototypes.push(proto2);

        let clause2 = ClauseInfo {
            proto_idx: proto2_idx,
            arity: 1,
            is_variadic: false,
            patterns: Box::new([CompiledPattern::Wildcard]),
            guard_proto_idx: None,
        };

        // Create closure template
        let template = ClosureTemplate {
            clauses: std::rc::Rc::from(vec![clause1, clause2]),
        };
        let template_key = self
            .heap
            .insert_constant(HeapObject::ClosureTemplate(template));
        let template_idx = self.add_constant(VMValue::HeapRef(template_key));

        self.emit(
            OpCode::MakeMultiClosure,
            template_idx as u8,
            (template_idx >> 8) as u8,
            0,
        );
        self.emit(OpCode::Dup, 0, 0, 0);

        let sym_idx = self.add_constant(VMValue::Symbol(pred_spur));
        self.emit(OpCode::DefGlobal, sym_idx as u8, (sym_idx >> 8) as u8, 0);

        if !self.global_slots.contains_key(&pred_spur) {
            self.global_slots.insert(pred_spur, self.next_global_slot);
            self.next_global_slot += 1;
        }

        Ok(())
    }

    /// Compile a family predicate function (e.g., Result?) that checks type_id
    fn compile_family_predicate(
        &mut self,
        pred_spur: Spur,
        type_id: TypeId,
        variant_infos: &[(String, Spur, Vec<Spur>)],
    ) -> Result<(), CompileError> {
        // Build clauses: one for each variant (returns true), plus wildcard (returns false)
        let param_spur = self.interner.get_or_intern("x__match");
        let mut clause_infos = Vec::new();

        for (i, info) in variant_infos.iter().enumerate() {
            let field_count = info.2.len();

            let fb = FunctionBuilder::new(Some(pred_spur), 1);
            self.functions.push(fb);
            self.begin_scope();
            let _ = self.declare_local(param_spur)?;
            for j in 0..field_count {
                let field_local = self.interner.get_or_intern(&format!("_f{}", j));
                let _ = self.declare_local(field_local)?;
            }

            let true_const = self.add_constant(VMValue::Bool(true));
            self.emit_const(true_const);
            self.emit(OpCode::Return, 0, 0, 0);

            let proto = self.finish_function()?;
            let proto_idx = self.prototypes.len() as u32;
            self.prototypes.push(proto);

            let field_patterns: Vec<CompiledPattern> = (0..field_count)
                .map(|j| CompiledPattern::Bind {
                    slot: (j + 1) as u8,
                })
                .collect();

            let pattern = CompiledPattern::Variant {
                type_id,
                variant_idx: i as u8,
                field_patterns: field_patterns.into_boxed_slice(),
            };

            clause_infos.push(ClauseInfo {
                proto_idx,
                arity: 1,
                is_variadic: false,
                patterns: Box::new([pattern]),
                guard_proto_idx: None,
            });
        }

        // Wildcard clause
        let fb = FunctionBuilder::new(Some(pred_spur), 1);
        self.functions.push(fb);
        self.begin_scope();
        let _ = self.declare_local(param_spur)?;

        let false_const = self.add_constant(VMValue::Bool(false));
        self.emit_const(false_const);
        self.emit(OpCode::Return, 0, 0, 0);

        let proto = self.finish_function()?;
        let proto_idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);

        clause_infos.push(ClauseInfo {
            proto_idx,
            arity: 1,
            is_variadic: false,
            patterns: Box::new([CompiledPattern::Wildcard]),
            guard_proto_idx: None,
        });

        let template = ClosureTemplate {
            clauses: std::rc::Rc::from(clause_infos),
        };
        let template_key = self
            .heap
            .insert_constant(HeapObject::ClosureTemplate(template));
        let template_idx = self.add_constant(VMValue::HeapRef(template_key));

        self.emit(
            OpCode::MakeMultiClosure,
            template_idx as u8,
            (template_idx >> 8) as u8,
            0,
        );
        self.emit(OpCode::Dup, 0, 0, 0);

        let sym_idx = self.add_constant(VMValue::Symbol(pred_spur));
        self.emit(OpCode::DefGlobal, sym_idx as u8, (sym_idx >> 8) as u8, 0);

        if !self.global_slots.contains_key(&pred_spur) {
            self.global_slots.insert(pred_spur, self.next_global_slot);
            self.next_global_slot += 1;
        }

        Ok(())
    }

    fn compile_match(&mut self, list: &crate::List) -> Result<(), CompileError> {
        let list_span = list.first().and_then(|v| v.meta_span());
        let args = list.args_vec();
        if args.len() < 3 || args.len() % 2 == 0 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "match requires a scrutinee and pattern/body pairs".to_string(),
            ))
            .with_span(list_span));
        }

        // Step 1: compile clause prototypes (no bytecode emitted to current function)
        let match_name = self.interner.get_or_intern("match__fn");
        let mut clause_compiles = Vec::new();

        let pairs = &args[1..];
        for chunk in pairs.chunks(2) {
            let pattern_val = &chunk[0];
            let body_val = &chunk[1];

            let mut match_fb = FunctionBuilder::new(Some(match_name), 1);
            match_fb.in_tail_position = true;
            self.functions.push(match_fb);
            self.begin_scope();

            let mut bindings: Vec<(Spur, Option<crate::span::Span>)> = Vec::new();
            let pattern = self.compile_match_pattern(pattern_val, &mut bindings)?;

            self.compile_expr(body_val)?;
            self.emit(OpCode::Return, 0, 0, 0);

            let upvalues = self.current_fn().upvalues.clone();
            let proto = self.finish_function()?;

            clause_compiles.push(ClauseCompile {
                proto,
                guard_proto: None,
                patterns: Box::new([pattern]),
                arity: 1,
                is_variadic: false,
                upvalues,
                guard_upvalues: Vec::new(),
            });
        }

        // Handle upvalues
        let mut union_upvalues: Vec<UpvalueDesc> = Vec::new();
        for clause in &clause_compiles {
            for up in &clause.upvalues {
                if !union_upvalues.iter().any(|existing| existing == up) {
                    union_upvalues.push(*up);
                }
            }
        }
        for clause in clause_compiles.iter_mut() {
            clause.remap_upvalues(&union_upvalues)?;
        }

        let base_idx = self.prototypes.len() as u32;
        let mut clause_infos = Vec::with_capacity(clause_compiles.len());
        let mut pidx = base_idx;
        for clause in clause_compiles.iter() {
            clause_infos.push(ClauseInfo {
                proto_idx: pidx,
                arity: 1,
                is_variadic: false,
                patterns: clause.patterns.clone(),
                guard_proto_idx: None,
            });
            pidx += 1;
        }
        for clause in clause_compiles {
            self.prototypes.push(clause.proto);
        }

        let template = ClosureTemplate {
            clauses: std::rc::Rc::from(clause_infos),
        };
        let template_key = self
            .heap
            .insert_constant(HeapObject::ClosureTemplate(template));
        let template_idx = self.add_constant(VMValue::HeapRef(template_key));

        // Step 2: emit bytecode - scrutinee first (arg), then closure (callee on top)
        // Compile scrutinee as the argument
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;
        self.compile_expr(&args[0])?;
        self.current_fn_mut().in_tail_position = was_tail;

        // Push upvalues for closure capture, then create closure (callee on top of stack)
        for upval in &union_upvalues {
            match upval {
                UpvalueDesc::Local(slot) => {
                    self.emit(OpCode::GetLocal, *slot, 0, 0);
                }
                UpvalueDesc::Upvalue(slot) => {
                    self.emit(OpCode::GetUpvalue, *slot, 0, 0);
                }
            }
        }
        self.emit(
            OpCode::MakeMultiClosure,
            template_idx as u8,
            (template_idx >> 8) as u8,
            union_upvalues.len() as u8,
        );

        // Call the match closure with 1 arg
        self.record_span(list_span);
        if was_tail {
            self.emit(OpCode::TailCall, 1, 0, 0);
        } else {
            self.emit(OpCode::Call, 1, 0, 0);
        }

        Ok(())
    }

    /// Compile a pattern for use in `match` expressions.
    /// This handles variant patterns (list syntax) and delegates to compile_pattern for others.
    fn compile_match_pattern(
        &mut self,
        pattern: &Value,
        bindings: &mut Vec<(Spur, Option<crate::span::Span>)>,
    ) -> Result<CompiledPattern, CompileError> {
        match pattern.strip_meta() {
            // `_` wildcard
            Value::Symbol(sym) if sym.namespace.is_none() && sym.name.as_ref() == "_" => {
                Ok(CompiledPattern::Wildcard)
            }
            // Check if it's a list that starts with a variant constructor
            Value::List(l) if !l.is_empty() => {
                let first = l.first().unwrap();
                if let Value::Symbol(sym) = first.strip_meta() {
                    if sym.namespace.is_none() {
                        let name_spur = self.interner.get_or_intern(&sym.name);
                        // Check if it's a known variant constructor and NOT shadowed by a local
                        if self.variant_constructors.contains_key(&name_spur)
                            && !self.is_local(name_spur)
                        {
                            let (type_id, variant_idx, field_count) =
                                self.variant_constructors[&name_spur];
                            let sub_patterns: Vec<_> = l.iter().skip(1).collect();
                            if sub_patterns.len() != field_count {
                                return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                                    format!(
                                        "variant {} expects {} fields, got {}",
                                        sym.name,
                                        field_count,
                                        sub_patterns.len()
                                    ),
                                ))
                                .with_span(pattern.meta_span()));
                            }
                            let mut field_patterns = Vec::new();
                            for sp in sub_patterns {
                                field_patterns.push(self.compile_match_pattern(sp, bindings)?);
                            }
                            return Ok(CompiledPattern::Variant {
                                type_id,
                                variant_idx,
                                field_patterns: field_patterns.into_boxed_slice(),
                            });
                        }
                    }
                }
                // Not a variant pattern - give a helpful error
                let hint_msg = if let Value::Symbol(sym) = first.strip_meta() {
                    format!(
                        "`{}` is not a known variant constructor — define it with (defdata Type ({} [...]))",
                        sym.name, sym.name
                    )
                } else {
                    "match patterns like (Foo x) require Foo to be a variant constructor defined via defdata".to_string()
                };
                Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                    "list patterns are only supported for variant constructors in match"
                        .to_string(),
                ))
                .with_span(pattern.meta_span())
                .with_hint(crate::error::Hint::UseInstead(hint_msg)))
            }
            // For everything else, delegate to the standard compile_pattern
            _ => self.compile_pattern(pattern, bindings),
        }
    }

    /// Check if a name is bound as a local in the current scope
    fn is_local(&self, name: Spur) -> bool {
        for scope in self.current_fn().scopes.iter().rev() {
            for local in scope.locals.iter().rev() {
                if local.name == name {
                    return true;
                }
            }
        }
        false
    }

    fn compile_call(&mut self, list: &crate::List) -> Result<(), CompileError> {
        self.compile_call_with_span(list, None)
    }

    fn compile_call_with_span(
        &mut self,
        list: &crate::List,
        call_span: Option<crate::span::Span>,
    ) -> Result<(), CompileError> {
        let callee = list
            .first()
            .ok_or_else(|| CompileError::new(CompileErrorKind::EmptyList).with_span(call_span))?;
        let args = list.args_vec();
        let n_args = args.len();

        // Arguments to function calls are never in tail position
        let was_tail = self.current_fn().in_tail_position;
        self.current_fn_mut().in_tail_position = false;

        // Check for qualified symbols (effect operations like gen/yield)
        if let Value::Symbol(sym) = callee.strip_meta() {
            if let Some(ns) = &sym.namespace {
                // Qualified symbol: compile as effect operation
                return self.compile_effect_op_call(ns, &sym.name, &args, call_span);
            }
        }

        // Check for built-in operators that compile to opcodes
        if let Value::Symbol(sym) = callee.strip_meta() {
            if sym.namespace.is_none() {
                match sym.name.as_ref() {
                    // Multi-arg arithmetic: chain binary operations
                    "+" if n_args >= 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        // Record span for type errors on Add
                        self.record_span(call_span);
                        self.emit(OpCode::Add, 0, 0, 0);
                        // Chain remaining args
                        for arg in args.iter().skip(2) {
                            self.compile_expr(arg)?;
                            self.record_span(call_span);
                            self.emit(OpCode::Add, 0, 0, 0);
                        }
                        return Ok(());
                    }
                    "-" if n_args >= 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Sub, 0, 0, 0);
                        // Chain remaining args
                        for arg in args.iter().skip(2) {
                            self.compile_expr(arg)?;
                            self.record_span(call_span);
                            self.emit(OpCode::Sub, 0, 0, 0);
                        }
                        return Ok(());
                    }
                    "*" if n_args >= 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Mul, 0, 0, 0);
                        // Chain remaining args
                        for arg in args.iter().skip(2) {
                            self.compile_expr(arg)?;
                            self.record_span(call_span);
                            self.emit(OpCode::Mul, 0, 0, 0);
                        }
                        return Ok(());
                    }
                    "/" if n_args >= 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        // Record span for division by zero
                        self.record_span(call_span);
                        self.emit(OpCode::Div, 0, 0, 0);
                        // Chain remaining args
                        for arg in args.iter().skip(2) {
                            self.compile_expr(arg)?;
                            self.record_span(call_span);
                            self.emit(OpCode::Div, 0, 0, 0);
                        }
                        return Ok(());
                    }
                    "rem" | "mod" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Rem, 0, 0, 0);
                        return Ok(());
                    }
                    // Unary negation
                    "-" if n_args == 1 => {
                        self.compile_expr(&args[0])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Neg, 0, 0, 0);
                        return Ok(());
                    }
                    // Comparisons
                    "=" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.emit(OpCode::Eq, 0, 0, 0);
                        return Ok(());
                    }
                    "not=" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.emit(OpCode::Ne, 0, 0, 0);
                        return Ok(());
                    }
                    "<" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Lt, 0, 0, 0);
                        return Ok(());
                    }
                    "<=" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Le, 0, 0, 0);
                        return Ok(());
                    }
                    ">" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Gt, 0, 0, 0);
                        return Ok(());
                    }
                    ">=" if n_args == 2 => {
                        self.compile_expr(&args[0])?;
                        self.compile_expr(&args[1])?;
                        self.record_span(call_span);
                        self.emit(OpCode::Ge, 0, 0, 0);
                        return Ok(());
                    }
                    // Logic
                    "not" if n_args == 1 => {
                        self.compile_expr(&args[0])?;
                        self.emit(OpCode::Not, 0, 0, 0);
                        return Ok(());
                    }
                    _ => {
                        // Check for direct native call optimization
                        let name_spur = self.interner.get_or_intern(sym.name.as_ref());
                        if let Some(&native_idx) = self.native_names.get(&name_spur) {
                            // Only optimize if not shadowed by a local or upvalue
                            if matches!(self.resolve_symbol(name_spur), Resolution::Global(_)) {
                                for arg in &args {
                                    self.compile_expr(arg)?;
                                }
                                self.current_fn_mut().in_tail_position = was_tail;
                                self.record_span(call_span);
                                self.emit(
                                    OpCode::CallNative,
                                    native_idx as u8,
                                    (native_idx >> 8) as u8,
                                    n_args as u8,
                                );
                                return Ok(());
                            }
                        }
                    }
                }
            }
        }

        if n_args > 255 {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "too many arguments (max 255)".to_string(),
            ))
            .with_span(call_span));
        }

        // Generic function call: compile arguments first (left-to-right)
        for arg in &args {
            self.compile_expr(arg)?;
        }

        // Compile callee
        self.compile_expr(callee)?;

        // Restore tail position
        self.current_fn_mut().in_tail_position = was_tail;

        // Record span for call errors (arity, not callable, etc.)
        self.record_span(call_span);
        // Emit Call instruction
        self.emit(OpCode::Call, n_args as u8, 0, 0);

        Ok(())
    }

    // --- Scope management ---

    fn begin_scope(&mut self) {
        let depth = self.current_fn().scopes.len();
        self.current_fn_mut().scopes.push(Scope {
            locals: Vec::new(),
            depth,
        });
    }

    fn end_scope(&mut self) {
        self.current_fn_mut().scopes.pop();
    }

    fn declare_local(&mut self, name: Spur) -> Result<u8, CompileError> {
        self.declare_local_with_span(name, None)
    }

    fn declare_local_with_span(
        &mut self,
        name: Spur,
        span: Option<crate::span::Span>,
    ) -> Result<u8, CompileError> {
        let slot = self.current_fn().local_count;
        let depth = self.current_fn().scopes.len();

        self.current_fn_mut().local_count += 1;
        if let Some(scope) = self.current_fn_mut().scopes.last_mut() {
            scope.locals.push(Local {
                name,
                slot,
                depth,
                captured: false,
                span,
            });
        }

        Ok(slot)
    }

    fn resolve_symbol(&mut self, name: Spur) -> Resolution {
        // 1. Check locals in current function (innermost scope first)
        for scope in self.current_fn().scopes.iter().rev() {
            for local in scope.locals.iter().rev() {
                if local.name == name {
                    return Resolution::Local(local.slot);
                }
            }
        }

        // 2. Check for upvalue capture from enclosing functions
        if let Some(upval_idx) = self.resolve_upvalue(name) {
            return Resolution::Upvalue(upval_idx);
        }

        // 3. Fall back to global
        Resolution::Global(name)
    }

    /// Find a local by name in the current function's scopes.
    /// Returns the span where it was defined, if any.
    fn find_local_span(&self, name: Spur) -> Option<crate::span::Span> {
        for scope in self.current_fn().scopes.iter().rev() {
            for local in scope.locals.iter().rev() {
                if local.name == name {
                    return local.span;
                }
            }
        }
        None
    }

    /// Find a similar name in scope for "did you mean" hints.
    /// Uses Levenshtein distance to find close matches.
    fn find_similar_name(&self, name: &str, max_distance: usize) -> Option<String> {
        let mut best: Option<(String, usize)> = None;

        for scope in self.current_fn().scopes.iter().rev() {
            for local in &scope.locals {
                let local_name = self.interner.resolve(&local.name);
                let dist = levenshtein_distance(name, local_name);
                if dist > 0 && dist <= max_distance {
                    if best.is_none() || dist < best.as_ref().unwrap().1 {
                        best = Some((local_name.to_string(), dist));
                    }
                }
            }
        }

        best.map(|(s, _)| s)
    }

    fn resolve_upvalue(&mut self, name: Spur) -> Option<u8> {
        if self.functions.len() < 2 {
            return None;
        }

        let enclosing_idx = self.functions.len() - 2;
        let current_idx = self.functions.len() - 1;

        // First check if enclosing function has it as a local
        // Collect the info we need without holding borrows
        let mut found_local: Option<u8> = None;

        for scope in self.functions[enclosing_idx].scopes.iter().rev() {
            for local in scope.locals.iter().rev() {
                if local.name == name {
                    found_local = Some(local.slot);
                    break;
                }
            }
            if found_local.is_some() {
                break;
            }
        }

        if let Some(local_slot) = found_local {
            // Mark local as captured in enclosing function
            for s in self.functions[enclosing_idx].scopes.iter_mut() {
                for l in s.locals.iter_mut() {
                    if l.name == name {
                        l.captured = true;
                    }
                }
            }

            // Check if we already have this upvalue in current function
            for (idx, upval) in self.functions[current_idx].upvalues.iter().enumerate() {
                if let UpvalueDesc::Local(slot) = upval {
                    if *slot == local_slot {
                        return Some(idx as u8);
                    }
                }
            }

            // Add new upvalue
            let upval_idx = self.functions[current_idx].upvalues.len() as u8;
            self.functions[current_idx]
                .upvalues
                .push(UpvalueDesc::Local(local_slot));
            return Some(upval_idx);
        }

        // Check if enclosing function has it as an upvalue (for multi-level closures)
        // First check if enclosing already has this as an upvalue
        for (idx, upval) in self.functions[enclosing_idx].upvalues.iter().enumerate() {
            // Check if this upvalue ultimately resolves to the name we're looking for
            // We need to check UpvalueDesc::Upvalue entries that chain through
            match upval {
                UpvalueDesc::Local(slot) => {
                    // Check if this local in the grandparent matches our name
                    if enclosing_idx > 0 {
                        let grandparent_idx = enclosing_idx - 1;
                        for scope in self.functions[grandparent_idx].scopes.iter() {
                            for local in scope.locals.iter() {
                                if local.name == name && local.slot == *slot {
                                    // Found it! Add upvalue referencing enclosing's upvalue
                                    // Check if we already have this upvalue
                                    for (cur_idx, cur_upval) in
                                        self.functions[current_idx].upvalues.iter().enumerate()
                                    {
                                        if let UpvalueDesc::Upvalue(up_slot) = cur_upval {
                                            if *up_slot == idx as u8 {
                                                return Some(cur_idx as u8);
                                            }
                                        }
                                    }
                                    let upval_idx =
                                        self.functions[current_idx].upvalues.len() as u8;
                                    self.functions[current_idx]
                                        .upvalues
                                        .push(UpvalueDesc::Upvalue(idx as u8));
                                    return Some(upval_idx);
                                }
                            }
                        }
                    }
                }
                UpvalueDesc::Upvalue(_) => {
                    // This is already a chained upvalue - we'd need to trace it further
                    // For now, skip these (would require more complex tracking)
                }
            }
        }

        // Recursively check grandparent and beyond
        if enclosing_idx > 0 {
            let grandparent_idx = enclosing_idx - 1;

            // Check grandparent's locals
            let mut found_in_grandparent: Option<u8> = None;
            for scope in self.functions[grandparent_idx].scopes.iter().rev() {
                for local in scope.locals.iter().rev() {
                    if local.name == name {
                        found_in_grandparent = Some(local.slot);
                        break;
                    }
                }
                if found_in_grandparent.is_some() {
                    break;
                }
            }

            if let Some(gp_slot) = found_in_grandparent {
                // Mark the local as captured in grandparent
                for s in self.functions[grandparent_idx].scopes.iter_mut() {
                    for l in s.locals.iter_mut() {
                        if l.name == name {
                            l.captured = true;
                        }
                    }
                }

                // Add upvalue to enclosing function (if not already there)
                let enclosing_upval_idx = {
                    let mut existing_idx: Option<u8> = None;
                    for (idx, upval) in self.functions[enclosing_idx].upvalues.iter().enumerate() {
                        if let UpvalueDesc::Local(slot) = upval {
                            if *slot == gp_slot {
                                existing_idx = Some(idx as u8);
                                break;
                            }
                        }
                    }
                    if let Some(idx) = existing_idx {
                        idx
                    } else {
                        let idx = self.functions[enclosing_idx].upvalues.len() as u8;
                        self.functions[enclosing_idx]
                            .upvalues
                            .push(UpvalueDesc::Local(gp_slot));
                        idx
                    }
                };

                // Now add upvalue to current function referencing enclosing's upvalue
                let upval_idx = self.functions[current_idx].upvalues.len() as u8;
                self.functions[current_idx]
                    .upvalues
                    .push(UpvalueDesc::Upvalue(enclosing_upval_idx));
                return Some(upval_idx);
            }
        }

        None
    }

    // --- Code emission ---

    fn emit(&mut self, op: OpCode, a1: u8, a2: u8, a3: u8) {
        self.current_fn_mut().code.push(encode(op, a1, a2, a3));
    }

    fn emit_const(&mut self, idx: u16) {
        self.emit(OpCode::Const, idx as u8, (idx >> 8) as u8, 0);
    }

    /// Record a span at the current bytecode position for error reporting.
    /// The span is associated with the *next* instruction to be emitted.
    fn record_span(&mut self, span: Option<crate::span::Span>) {
        if let Some(s) = span {
            let ip = self.current_fn().code.len() as u32;
            self.current_fn_mut()
                .spans
                .push((ip, Span::from_ast_span(&s)));
        }
    }

    fn emit_jump(&mut self, op: OpCode) -> usize {
        let loc = self.current_fn().code.len();
        self.emit(op, 0, 0, 0);
        loc
    }

    fn patch_jump(&mut self, loc: usize) {
        let current_ip = self.current_fn().code.len();
        let offset = (current_ip as i32 - loc as i32 - 1) as i16;
        let [a1, a2] = offset.to_le_bytes();

        let instr = self.current_fn().code[loc];
        let op = (instr & 0xFF) as u8;
        self.current_fn_mut().code[loc] = encode(OpCode::from_u8(op).unwrap(), a1, a2, 0);
    }

    fn add_constant(&mut self, value: VMValue) -> u16 {
        let constants = &mut self.current_fn_mut().constants;

        // Deduplicate
        for (i, c) in constants.iter().enumerate() {
            if *c == value {
                return i as u16;
            }
        }

        let idx = constants.len() as u16;
        constants.push(value);
        idx
    }

    // --- Helpers ---

    fn current_fn(&self) -> &FunctionBuilder {
        self.functions.last().expect("no function context")
    }

    fn current_fn_mut(&mut self) -> &mut FunctionBuilder {
        self.functions.last_mut().expect("no function context")
    }

    fn finish_function(&mut self) -> Result<Prototype, CompileError> {
        let fb = self.functions.pop().expect("no function to finish");

        Ok(Prototype {
            name: fb.name,
            arity: fb.arity,
            is_variadic: fb.is_variadic,
            locals: fb.local_count,
            upvalues: fb.upvalues.len() as u8,
            code: fb.code.into_boxed_slice(),
            constants: fb.constants.into_boxed_slice(),
            spans: fb.spans.into_boxed_slice(),
            handlers: fb.handlers.into_boxed_slice(),
            upvalue_desc: fb.upvalues.into_boxed_slice(),
        })
    }

    /// Consume compiler, return compilation unit
    pub fn finish(self) -> CompilationUnit {
        CompilationUnit {
            prototypes: self.prototypes,
            heap: self.heap,
            docs: self.docs,
        }
    }
}

impl ClauseCompile {
    fn remap_upvalues(&mut self, union: &[UpvalueDesc]) -> Result<(), CompileError> {
        let map = build_upvalue_map(&self.upvalues, union)?;
        remap_proto_upvalues(&mut self.proto, &map, union)?;

        if let Some(guard_proto) = self.guard_proto.as_mut() {
            let guard_map = build_upvalue_map(&self.guard_upvalues, union)?;
            remap_proto_upvalues(guard_proto, &guard_map, union)?;
        }

        Ok(())
    }
}

fn build_upvalue_map(
    original: &[UpvalueDesc],
    union: &[UpvalueDesc],
) -> Result<Vec<u8>, CompileError> {
    let mut map = Vec::with_capacity(original.len());
    for up in original {
        let idx = union.iter().position(|u| u == up).ok_or_else(|| {
            CompileError::new(CompileErrorKind::InvalidSyntax(
                "missing upvalue in union map".to_string(),
            ))
        })?;
        if idx > u8::MAX as usize {
            return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                "too many upvalues".to_string(),
            )));
        }
        map.push(idx as u8);
    }
    Ok(map)
}

fn remap_proto_upvalues(
    proto: &mut Prototype,
    map: &[u8],
    union: &[UpvalueDesc],
) -> Result<(), CompileError> {
    use super::opcode::{OpCode, decode, encode};

    let mut code: Vec<u32> = proto.code.to_vec();
    for instr in code.iter_mut() {
        let (op, a1, a2, a3) = decode(*instr);
        match OpCode::from_u8(op) {
            Some(OpCode::GetUpvalue) | Some(OpCode::SetUpvalue) => {
                let old = a1 as usize;
                if old >= map.len() {
                    return Err(CompileError::new(CompileErrorKind::InvalidSyntax(
                        "upvalue index out of range".to_string(),
                    )));
                }
                let new = map[old];
                *instr = encode(OpCode::from_u8(op).unwrap(), new, a2, a3);
            }
            _ => {}
        }
    }

    proto.code = code.into_boxed_slice();
    proto.upvalues = union.len() as u8;
    proto.upvalue_desc = union.to_vec().into_boxed_slice();
    Ok(())
}

impl FunctionBuilder {
    fn new(name: Option<Spur>, arity: u8) -> Self {
        FunctionBuilder {
            name,
            arity,
            is_variadic: false,
            code: Vec::new(),
            constants: Vec::new(),
            spans: Vec::new(),
            handlers: Vec::new(),
            upvalues: Vec::new(),
            scopes: Vec::new(),
            local_count: 0,
            loops: Vec::new(),
            in_tail_position: true, // top-level expression is in tail position
        }
    }
}

// --- Errors ---

/// The kind of compile error (without span information)
#[derive(Debug, Clone)]
pub enum CompileErrorKind {
    UnsupportedExpression(&'static str),
    EmptyList,
    InvalidSyntax(String),
    TooManyLocals,
    TooManyConstants,
    UndefinedVariable(String),
    /// Macro not found
    UndefinedMacro(String),
    /// Error during macro expansion
    MacroExpansionError(String),
    /// Macro returned invalid value for AST
    InvalidMacroResult(String),
    /// Duplicate parameter name in function definition
    DuplicateParameter(String),
}

impl std::fmt::Display for CompileErrorKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            CompileErrorKind::UnsupportedExpression(t) => {
                write!(f, "unsupported expression: {}", t)
            }
            CompileErrorKind::EmptyList => write!(f, "empty list"),
            CompileErrorKind::InvalidSyntax(msg) => write!(f, "invalid syntax: {}", msg),
            CompileErrorKind::TooManyLocals => write!(f, "too many locals (max 256)"),
            CompileErrorKind::TooManyConstants => write!(f, "too many constants (max 65536)"),
            CompileErrorKind::UndefinedVariable(name) => {
                write!(f, "undefined variable: {}", name)
            }
            CompileErrorKind::UndefinedMacro(name) => write!(f, "undefined macro: {}", name),
            CompileErrorKind::MacroExpansionError(msg) => {
                write!(f, "macro expansion error: {}", msg)
            }
            CompileErrorKind::InvalidMacroResult(msg) => {
                write!(f, "invalid macro result: {}", msg)
            }
            CompileErrorKind::DuplicateParameter(name) => {
                write!(f, "duplicate parameter: {}", name)
            }
        }
    }
}

/// A compile error with optional source span
#[derive(Debug, Clone)]
pub struct CompileError {
    pub kind: CompileErrorKind,
    pub span: Option<crate::span::Span>,
    pub hint: Option<crate::error::Hint>,
    pub related: Vec<crate::error::RelatedSpan>,
}

impl CompileError {
    /// Create a new compile error without span information
    pub fn new(kind: CompileErrorKind) -> Self {
        Self {
            kind,
            span: None,
            hint: None,
            related: Vec::new(),
        }
    }

    /// Attach a span to this error (only if it doesn't already have one)
    pub fn with_span(mut self, span: Option<crate::span::Span>) -> Self {
        if self.span.is_none() {
            self.span = span;
        }
        self
    }

    /// Attach a hint to this error
    pub fn with_hint(mut self, hint: crate::error::Hint) -> Self {
        self.hint = Some(hint);
        self
    }

    /// Add a related span to this error
    pub fn with_related(mut self, related: crate::error::RelatedSpan) -> Self {
        self.related.push(related);
        self
    }
}

impl std::fmt::Display for CompileError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.kind)
    }
}

impl std::error::Error for CompileError {}

/// Generate an ariadne report for a compile error.
/// Returns None if the error has no span information.
pub fn compile_error_report(
    error: &CompileError,
) -> Option<ariadne::Report<'static, crate::span::Span>> {
    use ariadne::{Color, Label, Report, ReportKind};

    let span = error.span?;

    let mut builder = Report::build(ReportKind::Error, span)
        .with_message(error.kind.to_string())
        .with_label(
            Label::new(span)
                .with_message(error.kind.to_string())
                .with_color(Color::Red),
        );

    // Add related spans as blue labels
    for related in &error.related {
        let msg = related
            .message
            .clone()
            .unwrap_or_else(|| match related.role {
                crate::error::SpanRole::Definition => "defined here".to_string(),
                crate::error::SpanRole::PreviousUse => "first defined here".to_string(),
                crate::error::SpanRole::Expected => "expected type from here".to_string(),
                crate::error::SpanRole::Binding => "bound here".to_string(),
            });
        builder = builder.with_label(
            Label::new(related.span)
                .with_message(msg)
                .with_color(Color::Blue),
        );
    }

    // Add hint as a note
    if let Some(hint) = &error.hint {
        builder = builder.with_note(crate::error::format_hint(hint));
    }

    Some(builder.finish())
}

/// Compute Levenshtein edit distance between two strings
fn levenshtein_distance(a: &str, b: &str) -> usize {
    let a_chars: Vec<char> = a.chars().collect();
    let b_chars: Vec<char> = b.chars().collect();
    let m = a_chars.len();
    let n = b_chars.len();

    if m == 0 {
        return n;
    }
    if n == 0 {
        return m;
    }

    // Use two rows for space efficiency
    let mut prev: Vec<usize> = (0..=n).collect();
    let mut curr = vec![0; n + 1];

    for i in 1..=m {
        curr[0] = i;
        for j in 1..=n {
            let cost = if a_chars[i - 1] == b_chars[j - 1] {
                0
            } else {
                1
            };
            curr[j] = (prev[j] + 1) // deletion
                .min(curr[j - 1] + 1) // insertion
                .min(prev[j - 1] + cost); // substitution
        }
        std::mem::swap(&mut prev, &mut curr);
    }

    prev[n]
}
