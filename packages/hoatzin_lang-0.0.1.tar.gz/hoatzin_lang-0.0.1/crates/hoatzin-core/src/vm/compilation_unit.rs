//! Compilation artifact — prototypes + metadata produced by the compiler.

use lasso::Spur;
use rustc_hash::FxHashMap;

use super::heap::Heap;
use super::prototype::{Prototype, Span};

/// Result of compiling one or more expressions.
pub struct CompilationUnit {
    pub prototypes: Vec<Prototype>,
    pub heap: Heap,
    pub docs: FxHashMap<Spur, DocEntry>,
}

/// Documentation entry for a top-level definition.
pub struct DocEntry {
    pub docstring: String,
    pub kind: DefKind,
    pub span: Option<Span>,
}

/// What kind of definition produced the doc entry.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum DefKind {
    Def,
    Defn,
    Defmacro,
    Native,
}
