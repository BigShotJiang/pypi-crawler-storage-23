//! VM value representation - Copy semantics, no Rc

use lasso::Spur;
use slotmap::new_key_type;

/// Unique identifier for effect types.
/// Each call to (effect ...) generates a new EffectId, enabling lexical shadowing.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct EffectId(pub u64);

new_key_type! {
    /// Reference to a heap-allocated object
    pub struct HeapKey;
}

// Compile-time assertion that HeapKey is Copy
const _: fn() = || {
    fn assert_copy<T: Copy>() {}
    assert_copy::<HeapKey>();
};

/// Stack value - 16 bytes, Copy
///
/// Note: Strings are now stored as HeapRef -> HeapObject::String(HipStr)
/// rather than as an interned Spur. This enables O(1) slicing and avoids
/// the cost of rehashing computed strings.
#[derive(Clone, Copy, PartialEq)]
pub enum VMValue {
    Nil,
    Bool(bool),
    Int(i64),
    Float(f64),
    Ratio { numer: i64, denom: i64 },
    Symbol(Spur),
    Keyword(Spur),
    HeapRef(HeapKey),
    NativeFn(u16),
}

impl std::fmt::Debug for VMValue {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            VMValue::Nil => write!(f, "nil"),
            VMValue::Bool(b) => write!(f, "{}", b),
            VMValue::Int(i) => write!(f, "{}", i),
            VMValue::Float(fl) => write!(f, "{}", fl),
            VMValue::Ratio { numer, denom } => write!(f, "{}/{}", numer, denom),
            VMValue::Symbol(s) => write!(f, "sym({:?})", s),
            VMValue::Keyword(k) => write!(f, ":{:?}", k),
            VMValue::HeapRef(k) => write!(f, "heap({:?})", k),
            VMValue::NativeFn(i) => write!(f, "native({})", i),
        }
    }
}

impl VMValue {
    #[inline(always)]
    pub fn is_truthy(&self) -> bool {
        !matches!(self, VMValue::Nil | VMValue::Bool(false))
    }

    #[inline(always)]
    pub fn is_falsy(&self) -> bool {
        matches!(self, VMValue::Nil | VMValue::Bool(false))
    }

    #[inline(always)]
    pub fn as_int(&self) -> Option<i64> {
        match self {
            VMValue::Int(i) => Some(*i),
            _ => None,
        }
    }

    pub fn as_float(&self) -> Option<f64> {
        match self {
            VMValue::Float(f) => Some(*f),
            VMValue::Int(i) => Some(*i as f64),
            VMValue::Ratio { numer, denom } => Some(*numer as f64 / *denom as f64),
            _ => None,
        }
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            VMValue::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_heap_ref(&self) -> Option<HeapKey> {
        match self {
            VMValue::HeapRef(k) => Some(*k),
            _ => None,
        }
    }
}

impl std::hash::Hash for VMValue {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        std::mem::discriminant(self).hash(state);
        match self {
            VMValue::Nil => {}
            VMValue::Bool(b) => b.hash(state),
            VMValue::Int(i) => i.hash(state),
            VMValue::Float(f) => f.to_bits().hash(state),
            VMValue::Ratio { numer, denom } => {
                numer.hash(state);
                denom.hash(state);
            }
            VMValue::Symbol(s) => s.hash(state),
            VMValue::Keyword(k) => k.hash(state),
            VMValue::HeapRef(k) => k.hash(state),
            VMValue::NativeFn(i) => i.hash(state),
        }
    }
}

impl Eq for VMValue {}
