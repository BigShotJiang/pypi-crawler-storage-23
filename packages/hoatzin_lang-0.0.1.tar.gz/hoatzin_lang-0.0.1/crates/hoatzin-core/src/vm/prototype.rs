//! Function prototype - compiled bytecode unit

use lasso::Spur;

use super::value::VMValue;

/// Compiled function prototype
pub struct Prototype {
    /// Function name (for debugging/errors)
    pub name: Option<Spur>,

    /// Number of parameters (for variadic fns, this is required params, not including rest)
    pub arity: u8,

    /// Is this a variadic function (has & rest param)?
    pub is_variadic: bool,

    /// Number of local slots (including params)
    pub locals: u8,

    /// Number of upvalues
    pub upvalues: u8,

    /// Bytecode instructions
    pub code: Box<[u32]>,

    /// Constant pool
    pub constants: Box<[VMValue]>,

    /// Source spans for error reporting: (ip, span)
    pub spans: Box<[(u32, Span)]>,

    /// Handler info for PushHandler instructions
    pub handlers: Box<[HandlerInfo]>,

    /// Upvalue descriptors (for closure creation)
    pub upvalue_desc: Box<[UpvalueDesc]>,
}

/// Source location (VM-internal representation)
#[derive(Clone, Copy, Debug)]
pub struct Span {
    pub start: u32,
    pub end: u32,
    pub line: u32,
    pub col: u32,
    pub source_id: Option<Spur>,
}

impl Span {
    /// Create from AST span
    pub fn from_ast_span(span: &crate::span::Span) -> Self {
        Self {
            start: span.start as u32,
            end: span.end as u32,
            line: span.line as u32,
            col: span.col as u32,
            source_id: span.source_id,
        }
    }

    /// Convert to AST span for ariadne reporting
    pub fn to_ast_span(&self) -> crate::span::Span {
        crate::span::Span::with_source(
            self.start as usize,
            self.end as usize,
            self.line as usize,
            self.col as usize,
            self.source_id,
        )
    }
}

/// Handler info embedded in prototype
#[derive(Clone, Copy, Debug)]
pub struct HandlerInfo {
    /// Constant pool index of effect symbol
    pub effect_const: u16,
    /// IP of handler code
    pub handler_ip: u32,
}

/// Describes how to capture an upvalue
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum UpvalueDesc {
    /// Capture from enclosing function's local slot
    Local(u8),
    /// Capture from enclosing function's upvalue slot
    Upvalue(u8),
}

impl Prototype {
    /// Look up span for an instruction pointer
    pub fn span_for_ip(&self, ip: u32) -> Option<Span> {
        // Binary search for largest span.0 <= ip
        let idx = self.spans.partition_point(|(span_ip, _)| *span_ip <= ip);
        if idx > 0 {
            Some(self.spans[idx - 1].1)
        } else {
            None
        }
    }

    /// Remap HeapKey references in constants using the provided mapping.
    /// Used when importing compiler heap into VM heap.
    pub fn remap_heap_keys(
        &mut self,
        key_map: &std::collections::HashMap<super::value::HeapKey, super::value::HeapKey>,
    ) {
        // Need to rebuild constants since Box<[T]> is not mutable in place
        let mut constants: Vec<VMValue> = self.constants.to_vec();
        for v in constants.iter_mut() {
            if let VMValue::HeapRef(key) = v {
                if let Some(&new_key) = key_map.get(key) {
                    *key = new_key;
                }
            }
        }
        self.constants = constants.into_boxed_slice();
    }

    /// Offset all prototype references by the given amount.
    /// Used when transferring compiler prototypes to VM.
    pub fn offset_proto_refs(&mut self, offset: u32) {
        use super::opcode::{OpCode, arg_u16, decode, encode};

        let mut code: Vec<u32> = self.code.to_vec();
        for instr in code.iter_mut() {
            let (op, a1, a2, a3) = decode(*instr);
            if let Some(OpCode::MakeClosure) = OpCode::from_u8(op) {
                // MakeClosure proto_lo proto_hi n_upvalues
                let old_proto_idx = arg_u16(a1, a2) as u32;
                let new_proto_idx = old_proto_idx + offset;
                *instr = encode(
                    OpCode::MakeClosure,
                    new_proto_idx as u8,
                    (new_proto_idx >> 8) as u8,
                    a3,
                );
            }
        }
        self.code = code.into_boxed_slice();
    }
}
