//! Call frames and effect handlers

use super::value::{EffectId, HeapKey};

/// Active call frame
#[derive(Clone, Debug)]
pub struct CallFrame {
    /// Instruction pointer
    pub ip: u32,

    /// Frame pointer (base of locals on value stack)
    pub fp: u32,

    /// Prototype index
    pub proto_idx: u32,

    /// Closure (if any) - for upvalue access
    pub closure: Option<HeapKey>,

    /// Number of arguments passed (for error messages)
    pub arg_count: u8,

    /// Handler guard - set when this frame is a handler call.
    /// Used for abort handling: if handler returns without resuming
    /// the continuation, we unwind to the prompt point.
    pub handler_guard: Option<HandlerGuard>,

    /// If set, this frame is a continuation body frame that should
    /// return when IP reaches this value (the PopHandler instruction).
    /// This is used when resuming a continuation that has no captured frames.
    pub return_at_ip: Option<u32>,
    /// If set, truncate the value stack to this FP on return-at-ip.
    /// This is needed for continuation body frames: they may need a different
    /// locals base (`fp`) than the stack cleanup point.
    pub cleanup_fp: Option<u32>,
    /// If set, re-mask the handler at this index when this continuation body frame returns.
    /// This implements "handler clause runs outside the handler" while still allowing deep
    /// handling for the resumed continuation.
    pub remask_handler_idx: Option<usize>,
}

/// Guard for tracking handler abort behavior
#[derive(Clone, Debug)]
pub struct HandlerGuard {
    /// The continuation key to check if resumed
    pub continuation_key: HeapKey,
    /// Stack pointer at the prompt (for abort unwind)
    pub prompt_sp: u32,
    /// Frame index at the prompt (for abort unwind)
    pub prompt_frame: u32,
    /// IP to jump to on abort (instruction after PopHandler)
    pub abort_ip: u32,
}

/// Active effect handler
#[derive(Clone, Debug)]
pub struct Handler {
    /// Effect being handled (unique EffectId for proper matching)
    pub effect_id: EffectId,

    /// IP of handler code in handler_proto
    pub handler_ip: u32,

    /// Prototype containing handler code
    pub handler_proto: u32,

    /// Closure for handler (if any) - for simple single-op handlers
    pub handler_closure: Option<HeapKey>,

    /// Dispatch table for multi-op handlers: Map<Symbol, closure_key>
    pub dispatch_table: Option<HeapKey>,

    /// Stack pointer at handler installation (for capture)
    pub prompt_sp: u32,

    /// Frame index at handler installation
    pub prompt_frame: u32,

    /// Original prompt stack pointer at handler installation.
    /// This is used for abort unwinding (which should always unwind to the
    /// handler installation boundary, not to a resumption site).
    pub install_prompt_sp: u32,

    /// Original prompt frame index at handler installation.
    pub install_prompt_frame: u32,

    /// Whether this handler is currently masked (ignored) for effect dispatch.
    /// While executing a handler clause, the matching handler is masked so that
    /// performing the same effect inside the clause forwards to outer handlers.
    pub masked: bool,

    /// IP to jump to on abort (instruction after PopHandler)
    pub abort_ip: u32,
}

/// Captured call frame (stored in continuation)
#[derive(Clone, Debug)]
pub struct CapturedFrame {
    pub ip: u32,
    /// Offset from continuation's stack_segment base
    pub fp_offset: u32,
    pub proto_idx: u32,
    pub closure: Option<HeapKey>,
    pub arg_count: u8,
    /// If set, this frame should return when IP reaches this value
    pub return_at_ip: Option<u32>,
    pub cleanup_fp_offset: Option<u32>,
}

impl CallFrame {
    pub fn new(proto_idx: u32, fp: u32, closure: Option<HeapKey>, arg_count: u8) -> Self {
        CallFrame {
            ip: 0,
            fp,
            proto_idx,
            closure,
            arg_count,
            handler_guard: None,
            return_at_ip: None,
            cleanup_fp: None,
            remask_handler_idx: None,
        }
    }

    /// Create a handler call frame with abort tracking
    pub fn new_handler(
        proto_idx: u32,
        fp: u32,
        closure: Option<HeapKey>,
        arg_count: u8,
        guard: HandlerGuard,
    ) -> Self {
        CallFrame {
            ip: 0,
            fp,
            proto_idx,
            closure,
            arg_count,
            handler_guard: Some(guard),
            return_at_ip: None,
            cleanup_fp: None,
            remask_handler_idx: None,
        }
    }
}
