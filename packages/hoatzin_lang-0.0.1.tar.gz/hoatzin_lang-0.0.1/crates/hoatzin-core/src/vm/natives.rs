//! Native function table

use super::VM;
use super::error::VMError;
use super::value::VMValue;

/// Native function signature
pub type NativeFn = fn(&mut VM, &[VMValue]) -> Result<VMValue, VMError>;

/// Native function entry
pub struct NativeEntry {
    pub name: &'static str,
    pub doc: &'static str,
    pub func: NativeFn,
}

/// Build the native function table
pub fn build_native_table() -> Vec<NativeEntry> {
    vec![
        // --- Sequences ---
        NativeEntry {
            name: "nth",
            doc: "Coll a × Int -> a\nReturns element at index.",
            func: native_nth,
        },
        NativeEntry {
            name: "first",
            doc: "Coll a -> a | Nil\nReturns the first element.",
            func: native_first,
        },
        NativeEntry {
            name: "rest",
            doc: "Coll a -> Coll a\nReturns all but the first element.",
            func: native_rest,
        },
        NativeEntry {
            name: "cons",
            doc: "a × Coll a -> List a\nPrepends element to collection.",
            func: native_cons,
        },
        NativeEntry {
            name: "conj",
            doc: "Coll a × a -> Coll a\nAdds element to collection.",
            func: native_conj,
        },
        NativeEntry {
            name: "count",
            doc: "Coll a -> Int\nReturns number of elements.",
            func: native_count,
        },
        NativeEntry {
            name: "empty?",
            doc: "Coll a -> Bool\nTrue if collection has no elements.",
            func: native_empty,
        },
        NativeEntry {
            name: "seq",
            doc: "Coll a -> List a | Nil\nCoerces to seq; nil if empty.",
            func: native_seq,
        },
        // --- Maps ---
        NativeEntry {
            name: "get",
            doc: "Coll a × k -> a | Nil\nLooks up key in collection.",
            func: native_get,
        },
        NativeEntry {
            name: "assoc",
            doc: "Map k v × k × v -> Map k v\nAssociates key with value.",
            func: native_assoc,
        },
        NativeEntry {
            name: "dissoc",
            doc: "Map k v × k -> Map k v\nRemoves key from map.",
            func: native_dissoc,
        },
        NativeEntry {
            name: "keys",
            doc: "Map k v -> Vector k\nReturns keys of map.",
            func: native_keys,
        },
        NativeEntry {
            name: "vals",
            doc: "Map k v -> Vector v\nReturns values of map.",
            func: native_vals,
        },
        NativeEntry {
            name: "contains?",
            doc: "Coll a × a -> Bool\nTrue if collection contains key.",
            func: native_contains,
        },
        // --- Atoms ---
        NativeEntry {
            name: "atom",
            doc: "a -> Atom a\nCreates a mutable reference.",
            func: native_atom,
        },
        NativeEntry {
            name: "deref",
            doc: "Atom a -> a\nReturns current value of atom.",
            func: native_deref,
        },
        NativeEntry {
            name: "reset!",
            doc: "Atom a × a -> a\nSets atom to new value.",
            func: native_reset,
        },
        NativeEntry {
            name: "swap!",
            doc: "Atom a × (a -> a) -> a\nApplies f to atom value and sets result.",
            func: native_swap,
        },
        // --- Arithmetic (for completeness, though often inlined) ---
        NativeEntry {
            name: "+",
            doc: "Num ... -> Num\nAddition.",
            func: native_add,
        },
        NativeEntry {
            name: "-",
            doc: "Num ... -> Num\nSubtraction.",
            func: native_sub,
        },
        NativeEntry {
            name: "*",
            doc: "Num ... -> Num\nMultiplication.",
            func: native_mul,
        },
        NativeEntry {
            name: "/",
            doc: "Num × Num -> Num\nDivision.",
            func: native_div,
        },
        // --- Comparison ---
        NativeEntry {
            name: "=",
            doc: "a × a -> Bool\nEquality.",
            func: native_eq,
        },
        NativeEntry {
            name: "<",
            doc: "Num × Num -> Bool\nLess than.",
            func: native_lt,
        },
        NativeEntry {
            name: "<=",
            doc: "Num × Num -> Bool\nLess than or equal.",
            func: native_le,
        },
        NativeEntry {
            name: ">",
            doc: "Num × Num -> Bool\nGreater than.",
            func: native_gt,
        },
        NativeEntry {
            name: ">=",
            doc: "Num × Num -> Bool\nGreater than or equal.",
            func: native_ge,
        },
        // --- Predicates ---
        NativeEntry {
            name: "nil?",
            doc: "a -> Bool\nTrue if nil.",
            func: native_nil,
        },
        NativeEntry {
            name: "number?",
            doc: "a -> Bool\nTrue if number.",
            func: native_number,
        },
        NativeEntry {
            name: "string?",
            doc: "a -> Bool\nTrue if string.",
            func: native_string,
        },
        NativeEntry {
            name: "keyword?",
            doc: "a -> Bool\nTrue if keyword.",
            func: native_keyword,
        },
        NativeEntry {
            name: "symbol?",
            doc: "a -> Bool\nTrue if symbol.",
            func: native_symbol,
        },
        NativeEntry {
            name: "fn?",
            doc: "a -> Bool\nTrue if function.",
            func: native_fn,
        },
        NativeEntry {
            name: "list?",
            doc: "a -> Bool\nTrue if list.",
            func: native_list,
        },
        NativeEntry {
            name: "vector?",
            doc: "a -> Bool\nTrue if vector.",
            func: native_vector,
        },
        NativeEntry {
            name: "map?",
            doc: "a -> Bool\nTrue if map.",
            func: native_map,
        },
        NativeEntry {
            name: "set?",
            doc: "a -> Bool\nTrue if set.",
            func: native_set,
        },
        NativeEntry {
            name: "coll?",
            doc: "a -> Bool\nTrue if collection.",
            func: native_coll,
        },
        NativeEntry {
            name: "seq?",
            doc: "a -> Bool\nTrue if sequential.",
            func: native_seq_pred,
        },
        NativeEntry {
            name: "ratio?",
            doc: "a -> Bool\nTrue if ratio.",
            func: native_ratio_pred,
        },
        // --- Strings ---
        NativeEntry {
            name: "str",
            doc: "a ... -> String\nConcatenates arguments as strings.",
            func: native_str,
        },
        NativeEntry {
            name: "subs",
            doc: "String × Int -> String\nSubstring from index.",
            func: native_subs,
        },
        NativeEntry {
            name: "string-length",
            doc: "String -> Int\nReturns length of string.",
            func: native_string_length,
        },
        NativeEntry {
            name: "pr-str",
            doc: "a ... -> String\nPrint-readable string representation.",
            func: native_pr_str,
        },
        // --- Regex ---
        NativeEntry {
            name: "re-pattern",
            doc: "String -> Regex\nCompiles a regex pattern.",
            func: native_re_pattern,
        },
        NativeEntry {
            name: "re-find",
            doc: "Regex × String -> String | Nil\nFinds first match.",
            func: native_re_find,
        },
        NativeEntry {
            name: "re-matches",
            doc: "Regex × String -> String | Nil\nFull-string match.",
            func: native_re_matches,
        },
        NativeEntry {
            name: "re-seq",
            doc: "Regex × String -> Vector String\nAll matches as vector.",
            func: native_re_seq,
        },
        // --- Optics ---
        NativeEntry {
            name: "view",
            doc: "Optic s a × s -> a\nReads value at optic focus.",
            func: native_view,
        },
        NativeEntry {
            name: "view-all",
            doc: "Optic s a × s -> Vector a\nReads all values at optic foci.",
            func: native_view_all,
        },
        NativeEntry {
            name: "over",
            doc: "Optic s a × (a -> a) × s -> s\nApplies f at optic focus.",
            func: native_over,
        },
        NativeEntry {
            name: "sett",
            doc: "Optic s a × a × s -> s\nSets value at optic focus.",
            func: native_set_optic,
        },
        NativeEntry {
            name: "*>",
            doc: "Optic s a × Optic a b -> Optic s b\nComposes optics left-to-right.",
            func: native_optic_compose,
        },
        NativeEntry {
            name: "<*",
            doc: "Optic a b × Optic s a -> Optic s b\nComposes optics right-to-left.",
            func: native_optic_compose_rev,
        },
        NativeEntry {
            name: "_idx",
            doc: "Int -> Optic (Vector a) a\nFocuses on index in vector.",
            func: native_optic_idx,
        },
        NativeEntry {
            name: "filtered",
            doc: "(a -> Bool) -> Optic (Vector a) a\nTraversal over matching elements.",
            func: native_optic_filtered,
        },
        NativeEntry {
            name: "_slice",
            doc: "Int × Int -> Optic (Vector a) (Vector a)\nFocuses on a sub-range.",
            func: native_optic_slice,
        },
        NativeEntry {
            name: "_when",
            doc: "(a -> Bool) -> Optic a a\nFocuses when predicate holds.",
            func: native_optic_when,
        },
        NativeEntry {
            name: "_first",
            doc: "Optic s a -> Optic s a\nFocuses on first match of traversal.",
            func: native_optic_first,
        },
        NativeEntry {
            name: "lens",
            doc: "(s -> a) × (s × a -> s) -> Optic s a\nCreates a lens from getter and setter.",
            func: native_optic_lens,
        },
        NativeEntry {
            name: "xpath",
            doc: "String -> Optic s a\nCreates optic from XPath-like path.",
            func: native_xpath,
        },
        // --- IO ---
        NativeEntry {
            name: "println",
            doc: "a ... -> <console> Nil\nPrints to console with newline.",
            func: native_println,
        },
        NativeEntry {
            name: "print",
            doc: "a ... -> <console> Nil\nPrints to console.",
            func: native_print,
        },
        // --- Higher-order functions ---
        NativeEntry {
            name: "map",
            doc: "(a -> b) × Coll a -> Vector b\nApplies f to each element.",
            func: native_hof_map,
        },
        NativeEntry {
            name: "filter",
            doc: "(a -> Bool) × Coll a -> Vector a\nElements satisfying pred.",
            func: native_filter,
        },
        NativeEntry {
            name: "reduce",
            doc: "(b × a -> b) × b × Coll a -> b\nReduces collection with f.",
            func: native_reduce,
        },
        NativeEntry {
            name: "take",
            doc: "Int × Coll a -> Vector a\nFirst n elements.",
            func: native_take,
        },
        NativeEntry {
            name: "drop",
            doc: "Int × Coll a -> Vector a\nAll but first n elements.",
            func: native_drop,
        },
        // --- String operations ---
        NativeEntry {
            name: "split",
            doc: "String × String -> Vector String\nSplits string by separator.",
            func: native_split,
        },
        NativeEntry {
            name: "join",
            doc: "String × Coll String -> String\nJoins with separator.",
            func: native_join,
        },
        NativeEntry {
            name: "upper-case",
            doc: "String -> String\nConverts to upper case.",
            func: native_upper_case,
        },
        NativeEntry {
            name: "lower-case",
            doc: "String -> String\nConverts to lower case.",
            func: native_lower_case,
        },
        // --- Compiler intrinsics ---
        NativeEntry {
            name: "__subvec",
            doc: "",
            func: intrinsic_subvec,
        },
        NativeEntry {
            name: "__throw-arity",
            doc: "",
            func: intrinsic_throw_arity,
        },
        // --- Effects ---
        NativeEntry {
            name: "__make_effect__",
            doc: "",
            func: native_make_effect,
        },
        NativeEntry {
            name: "effect?",
            doc: "a -> Bool\nTrue if value is an effect.",
            func: native_effect_pred,
        },
        // --- Macros support ---
        NativeEntry {
            name: "list",
            doc: "a ... -> List a\nCreates a list.",
            func: native_list_constructor,
        },
        NativeEntry {
            name: "assert-failed",
            doc: "",
            func: native_assert_failed,
        },
        NativeEntry {
            name: "symbol",
            doc: "String -> Symbol\nCreates a symbol from string.",
            func: native_symbol_constructor,
        },
        NativeEntry {
            name: "keyword",
            doc: "String -> Keyword\nCreates a keyword from string.",
            func: native_keyword_constructor,
        },
        NativeEntry {
            name: "name",
            doc: "Symbol | Keyword | String -> String\nReturns name part.",
            func: native_name,
        },
        NativeEntry {
            name: "namespace",
            doc: "Symbol | Keyword -> String | Nil\nReturns namespace part.",
            func: native_namespace,
        },
        NativeEntry {
            name: "concat",
            doc: "Coll a ... -> List a\nConcatenates collections.",
            func: native_concat,
        },
        NativeEntry {
            name: "vec",
            doc: "Coll a -> Vector a\nCoerces to vector.",
            func: native_vec,
        },
        NativeEntry {
            name: "vector",
            doc: "a ... -> Vector a\nCreates a vector.",
            func: native_vector_constructor,
        },
        NativeEntry {
            name: "set",
            doc: "Coll a -> Set a\nCreates a set from collection.",
            func: native_set_constructor,
        },
        NativeEntry {
            name: "apply",
            doc: "(a ... -> b) × a ... × Coll a -> b\nApplies f with args spread from collection.",
            func: native_apply,
        },
        NativeEntry {
            name: "type",
            doc: "a -> Keyword\nReturns type tag of value.",
            func: native_type,
        },
        // --- Additional collection functions ---
        NativeEntry {
            name: "hash-map",
            doc: "k × v ... -> Map k v\nCreates a map from key-value pairs.",
            func: native_hash_map,
        },
        NativeEntry {
            name: "hash-set",
            doc: "a ... -> Set a\nCreates a set from arguments.",
            func: native_hash_set,
        },
        NativeEntry {
            name: "empty",
            doc: "Coll a -> Coll a\nReturns empty collection of same type.",
            func: native_empty_coll,
        },
        NativeEntry {
            name: "last",
            doc: "Coll a -> a | Nil\nReturns the last element.",
            func: native_last,
        },
        NativeEntry {
            name: "into",
            doc: "Coll a × Coll a -> Coll a\nAdds all elements of source into target.",
            func: native_into,
        },
        NativeEntry {
            name: "reverse",
            doc: "Coll a -> Vector a\nReverses collection.",
            func: native_reverse,
        },
        NativeEntry {
            name: "drop-last",
            doc: "Coll a -> Vector a\nAll but last element.",
            func: native_drop_last,
        },
        NativeEntry {
            name: "repeat",
            doc: "Int × a -> Vector a\nVector of n copies of value.",
            func: native_repeat,
        },
        NativeEntry {
            name: "range",
            doc: "Int -> Vector Int\nIntegers from 0 to n-1.",
            func: native_range,
        },
        NativeEntry {
            name: "mod",
            doc: "Int × Int -> Int\nModulus.",
            func: native_mod,
        },
        NativeEntry {
            name: "read-string",
            doc: "String -> a\nParses a Hoatzin value from string.",
            func: native_read_string,
        },
        NativeEntry {
            name: "even?",
            doc: "Int -> Bool\nTrue if even.",
            func: native_even,
        },
        NativeEntry {
            name: "odd?",
            doc: "Int -> Bool\nTrue if odd.",
            func: native_odd,
        },
        // --- Math functions ---
        NativeEntry {
            name: "floor",
            doc: "Num -> Int\nFloor.",
            func: native_floor,
        },
        NativeEntry {
            name: "ceil",
            doc: "Num -> Int\nCeiling.",
            func: native_ceil,
        },
        NativeEntry {
            name: "round",
            doc: "Num -> Int\nRounds to nearest integer.",
            func: native_round,
        },
        NativeEntry {
            name: "pow",
            doc: "Num × Num -> Float\nExponentiation.",
            func: native_pow,
        },
        NativeEntry {
            name: "sqrt",
            doc: "Num -> Float\nSquare root.",
            func: native_sqrt,
        },
        NativeEntry {
            name: "exp",
            doc: "Num -> Float\nNatural exponential.",
            func: native_exp,
        },
        NativeEntry {
            name: "log",
            doc: "Num -> Float\nNatural logarithm.",
            func: native_log,
        },
        NativeEntry {
            name: "log2",
            doc: "Num -> Float\nBase-2 logarithm.",
            func: native_log2,
        },
        NativeEntry {
            name: "log10",
            doc: "Num -> Float\nBase-10 logarithm.",
            func: native_log10,
        },
        NativeEntry {
            name: "sin",
            doc: "Num -> Float\nSine.",
            func: native_sin,
        },
        NativeEntry {
            name: "cos",
            doc: "Num -> Float\nCosine.",
            func: native_cos,
        },
        NativeEntry {
            name: "tan",
            doc: "Num -> Float\nTangent.",
            func: native_tan,
        },
        NativeEntry {
            name: "asin",
            doc: "Num -> Float\nArcsine.",
            func: native_asin,
        },
        NativeEntry {
            name: "acos",
            doc: "Num -> Float\nArccosine.",
            func: native_acos,
        },
        NativeEntry {
            name: "atan",
            doc: "Num -> Float\nArctangent.",
            func: native_atan,
        },
        NativeEntry {
            name: "atan2",
            doc: "Num × Num -> Float\nTwo-argument arctangent.",
            func: native_atan2,
        },
        NativeEntry {
            name: "sinh",
            doc: "Num -> Float\nHyperbolic sine.",
            func: native_sinh,
        },
        NativeEntry {
            name: "cosh",
            doc: "Num -> Float\nHyperbolic cosine.",
            func: native_cosh,
        },
        NativeEntry {
            name: "tanh",
            doc: "Num -> Float\nHyperbolic tangent.",
            func: native_tanh,
        },
        NativeEntry {
            name: "asinh",
            doc: "Num -> Float\nInverse hyperbolic sine.",
            func: native_asinh,
        },
        NativeEntry {
            name: "acosh",
            doc: "Num -> Float\nInverse hyperbolic cosine.",
            func: native_acosh,
        },
        NativeEntry {
            name: "atanh",
            doc: "Num -> Float\nInverse hyperbolic tangent.",
            func: native_atanh,
        },
        NativeEntry {
            name: "hypot",
            doc: "Num × Num -> Float\nHypotenuse length.",
            func: native_hypot,
        },
        NativeEntry {
            name: "signum",
            doc: "Num -> Int\nSign: -1, 0, or 1.",
            func: native_signum,
        },
        NativeEntry {
            name: "quot",
            doc: "Int × Int -> Int\nInteger quotient.",
            func: native_quot,
        },
        NativeEntry {
            name: "rem",
            doc: "Int × Int -> Int\nRemainder.",
            func: native_rem,
        },
        NativeEntry {
            name: "gcd",
            doc: "Int × Int -> Int\nGreatest common divisor.",
            func: native_gcd,
        },
        NativeEntry {
            name: "lcm",
            doc: "Int × Int -> Int\nLeast common multiple.",
            func: native_lcm,
        },
        NativeEntry {
            name: "numerator",
            doc: "Ratio -> Int\nNumerator of ratio.",
            func: native_numerator,
        },
        NativeEntry {
            name: "denominator",
            doc: "Ratio -> Int\nDenominator of ratio.",
            func: native_denominator,
        },
        NativeEntry {
            name: "parse-int",
            doc: "String -> Int | Nil\nParses integer from string.",
            func: native_parse_int,
        },
        NativeEntry {
            name: "parse-double",
            doc: "String -> Float | Nil\nParses float from string.",
            func: native_parse_double,
        },
        // --- Bitwise operations ---
        NativeEntry {
            name: "bit-and",
            doc: "Int × Int -> Int\nBitwise AND.",
            func: native_bit_and,
        },
        NativeEntry {
            name: "bit-or",
            doc: "Int × Int -> Int\nBitwise OR.",
            func: native_bit_or,
        },
        NativeEntry {
            name: "bit-xor",
            doc: "Int × Int -> Int\nBitwise XOR.",
            func: native_bit_xor,
        },
        NativeEntry {
            name: "bit-not",
            doc: "Int -> Int\nBitwise NOT.",
            func: native_bit_not,
        },
        NativeEntry {
            name: "bit-shift-left",
            doc: "Int × Int -> Int\nLeft bit shift.",
            func: native_bit_shift_left,
        },
        NativeEntry {
            name: "bit-shift-right",
            doc: "Int × Int -> Int\nRight bit shift.",
            func: native_bit_shift_right,
        },
        // --- Constants ---
        NativeEntry {
            name: "pi",
            doc: "-> Float\nPi constant.",
            func: native_pi,
        },
        NativeEntry {
            name: "e",
            doc: "-> Float\nEuler's number.",
            func: native_e,
        },
        NativeEntry {
            name: "Infinity",
            doc: "-> Float\nPositive infinity.",
            func: native_infinity,
        },
        NativeEntry {
            name: "-Infinity",
            doc: "-> Float\nNegative infinity.",
            func: native_neg_infinity,
        },
        NativeEntry {
            name: "NaN",
            doc: "-> Float\nNot a number.",
            func: native_nan,
        },
        // --- Additional predicates ---
        NativeEntry {
            name: "int?",
            doc: "a -> Bool\nTrue if integer.",
            func: native_int_pred,
        },
        NativeEntry {
            name: "float?",
            doc: "a -> Bool\nTrue if float.",
            func: native_float_pred,
        },
        NativeEntry {
            name: "optic?",
            doc: "a -> Bool\nTrue if optic.",
            func: native_optic_pred,
        },
        // --- String functions ---
        NativeEntry {
            name: "trim",
            doc: "String -> String\nRemoves leading and trailing whitespace.",
            func: native_trim,
        },
        NativeEntry {
            name: "triml",
            doc: "String -> String\nRemoves leading whitespace.",
            func: native_triml,
        },
        NativeEntry {
            name: "trimr",
            doc: "String -> String\nRemoves trailing whitespace.",
            func: native_trimr,
        },
        NativeEntry {
            name: "starts-with?",
            doc: "String × String -> Bool\nTrue if string starts with prefix.",
            func: native_starts_with,
        },
        NativeEntry {
            name: "ends-with?",
            doc: "String × String -> Bool\nTrue if string ends with suffix.",
            func: native_ends_with,
        },
        NativeEntry {
            name: "replace",
            doc: "String × String × String -> String\nReplaces all occurrences.",
            func: native_replace,
        },
        NativeEntry {
            name: "replace-first",
            doc: "String × String × String -> String\nReplaces first occurrence.",
            func: native_replace_first,
        },
        NativeEntry {
            name: "format",
            doc: "String × a ... -> String\nFormats string with arguments.",
            func: native_format,
        },
        NativeEntry {
            name: "prn",
            doc: "a ... -> <console> Nil\nPrints readable representation with newline.",
            func: native_prn,
        },
        // --- Sorting ---
        NativeEntry {
            name: "sort",
            doc: "Coll a -> Vector a\nSorts elements in natural order.",
            func: native_sort,
        },
        NativeEntry {
            name: "sort-by",
            doc: "(a -> b) × Coll a -> Vector a\nSorts by key function.",
            func: native_sort_by,
        },
        // --- Time ---
        NativeEntry {
            name: "nano-time",
            doc: "-> Int\nCurrent time in nanoseconds.",
            func: native_nano_time,
        },
    ]
}

// --- Sequences ---

use super::heap::{SeqData, SeqKind};

// --- Helper functions ---

/// Extract a string from a VMValue
fn get_string(vm: &VM, value: VMValue) -> Result<String, VMError> {
    match value {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => Ok(s.to_string()),
            _ => Err(VMError::TypeError("expected a string")),
        },
        _ => Err(VMError::TypeError("expected a string")),
    }
}

/// Extract a regex from a VMValue (returns a clone since Regex doesn't impl Copy)
fn get_regex(vm: &VM, value: VMValue) -> Result<regex::Regex, VMError> {
    match value {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Regex(re)) => Ok(re.clone()),
            _ => Err(VMError::TypeError("expected a regex")),
        },
        _ => Err(VMError::TypeError("expected a regex")),
    }
}

// --- Native implementations ---

fn native_nth(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let idx = match args[1] {
        VMValue::Int(i) => i,
        _ => return Err(VMError::TypeError("index must be integer")),
    };

    let default = args.get(2).copied().unwrap_or(VMValue::Nil);

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => {
                let chars: Vec<char> = s.chars().collect();
                if idx < 0 || idx as usize >= chars.len() {
                    Ok(default)
                } else {
                    let ch_str = chars[idx as usize].to_string();
                    Ok(vm.alloc_string(ch_str))
                }
            }
            Some(super::HeapObject::Seq(seq)) => {
                if idx < 0 || idx as usize >= seq.data.len() {
                    Ok(default)
                } else {
                    Ok(seq.data[idx as usize])
                }
            }
            _ => Err(VMError::TypeError("nth requires a sequence")),
        },
        VMValue::Nil => Ok(default),
        _ => Err(VMError::TypeError("nth requires a sequence")),
    }
}

fn native_first(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                Ok(seq.data.front().copied().unwrap_or(VMValue::Nil))
            }
            _ => Err(VMError::TypeError("first requires a sequence")),
        },
        VMValue::Nil => Ok(VMValue::Nil),
        _ => Err(VMError::TypeError("first requires a sequence")),
    }
}

fn native_rest(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let rest_data = if seq.data.is_empty() {
                    crate::collections::Vector::new()
                } else {
                    seq.data.clone().split_off(1)
                };
                let new_seq = SeqData {
                    data: rest_data,
                    kind: seq.kind,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            _ => Err(VMError::TypeError("rest requires a sequence")),
        },
        VMValue::Nil => {
            // Return empty list for nil
            let seq = SeqData {
                data: crate::collections::Vector::new(),
                kind: SeqKind::List,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(key))
        }
        _ => Err(VMError::TypeError("rest requires a sequence")),
    }
}

fn native_cons(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let head = args[0];
    let mut data = crate::collections::Vector::new();
    data.push_back(head);

    match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                for item in seq.data.iter() {
                    data.push_back(*item);
                }
            }
            Some(super::HeapObject::String(s)) => {
                let chars: Vec<String> = s.chars().map(|c| c.to_string()).collect();
                for ch in chars {
                    data.push_back(vm.alloc_string(&ch));
                }
            }
            _ => return Err(VMError::TypeError("cons requires a sequence")),
        },
        VMValue::Nil => {}
        _ => return Err(VMError::TypeError("cons requires a sequence")),
    }

    // cons always returns a list
    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_conj(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    // Extract collection type
    enum CollType {
        Seq(crate::collections::Vector<VMValue>, SeqKind),
        Map(crate::collections::HashMap<VMValue, VMValue>),
        Set(crate::collections::HashSet<VMValue>),
    }

    let coll_data = match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => CollType::Seq(seq.data.clone(), seq.kind),
            Some(super::HeapObject::Map(map)) => CollType::Map(map.clone()),
            Some(super::HeapObject::Set(set)) => CollType::Set(set.clone()),
            _ => return Err(VMError::TypeError("conj requires a collection")),
        },
        VMValue::Nil => CollType::Seq(crate::collections::Vector::new(), SeqKind::List),
        _ => return Err(VMError::TypeError("conj requires a collection")),
    };

    match coll_data {
        CollType::Seq(mut data, kind) => {
            match kind {
                SeqKind::Vector => {
                    for item in &args[1..] {
                        data.push_back(*item);
                    }
                }
                SeqKind::List => {
                    for item in args[1..].iter().rev() {
                        data.push_front(*item);
                    }
                }
            }
            let new_seq = SeqData { data, kind };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
            Ok(VMValue::HeapRef(new_key))
        }
        CollType::Map(mut map) => {
            // For maps, conj a [key value] pair
            for item in &args[1..] {
                if let VMValue::HeapRef(pair_key) = item {
                    if let Some(super::HeapObject::Seq(pair)) = vm.heap().get(*pair_key) {
                        if pair.data.len() >= 2 {
                            map.insert(pair.data[0], pair.data[1]);
                        }
                    }
                }
            }
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let new_key = vm.heap_mut().alloc(super::HeapObject::Map(map), roots);
            Ok(VMValue::HeapRef(new_key))
        }
        CollType::Set(mut set) => {
            for item in &args[1..] {
                set.insert(*item);
            }
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let new_key = vm.heap_mut().alloc(super::HeapObject::Set(set), roots);
            Ok(VMValue::HeapRef(new_key))
        }
    }
}

fn native_count(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => Ok(VMValue::Int(seq.data.len() as i64)),
            Some(super::HeapObject::Map(map)) => Ok(VMValue::Int(map.len() as i64)),
            Some(super::HeapObject::Set(set)) => Ok(VMValue::Int(set.len() as i64)),
            Some(super::HeapObject::String(s)) => Ok(VMValue::Int(s.chars().count() as i64)),
            _ => Err(VMError::TypeError("count requires a collection")),
        },
        VMValue::Nil => Ok(VMValue::Int(0)),
        _ => Err(VMError::TypeError("count requires a collection")),
    }
}

fn native_empty(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => Ok(VMValue::Bool(seq.data.is_empty())),
            Some(super::HeapObject::Map(map)) => Ok(VMValue::Bool(map.is_empty())),
            Some(super::HeapObject::Set(set)) => Ok(VMValue::Bool(set.is_empty())),
            Some(super::HeapObject::String(s)) => Ok(VMValue::Bool(s.is_empty())),
            _ => Err(VMError::TypeError("empty? requires a collection")),
        },
        VMValue::Nil => Ok(VMValue::Bool(true)),
        _ => Err(VMError::TypeError("empty? requires a collection")),
    }
}

fn native_seq(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    if seq.data.is_empty() {
                        Ok(VMValue::Nil)
                    } else {
                        // Return as list
                        let new_seq = SeqData {
                            data: seq.data.clone(),
                            kind: SeqKind::List,
                        };
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                        Ok(VMValue::HeapRef(new_key))
                    }
                }
                _ => Err(VMError::TypeError("seq requires a seqable")),
            }
        }
        VMValue::Nil => Ok(VMValue::Nil),
        _ => Err(VMError::TypeError("seq requires a seqable")),
    }
}

// --- Maps ---

fn native_get(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let default = args.get(2).copied().unwrap_or(VMValue::Nil);

    match args[0] {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Map(map)) => {
                    // Use content-based lookup for proper string key equality
                    let map = map.clone();
                    Ok(vm.map_get(&map, args[1]).unwrap_or(default))
                }
                Some(super::HeapObject::Seq(seq)) => {
                    // Get from sequence by index
                    if let VMValue::Int(idx) = args[1] {
                        if idx >= 0 && (idx as usize) < seq.data.len() {
                            Ok(seq.data[idx as usize])
                        } else {
                            Ok(default)
                        }
                    } else {
                        Ok(default)
                    }
                }
                Some(super::HeapObject::Variant(inst)) => {
                    if let VMValue::Keyword(kw) = args[1] {
                        let type_id = inst.type_id();
                        let variant_idx = inst.variant_idx();
                        if let Some(typedef) = vm.type_registry().get(type_id) {
                            let vdef = &typedef.variants[variant_idx as usize];
                            if let Some(&field_idx) = vdef.field_index.get(&kw) {
                                return Ok(inst.fields[field_idx as usize]);
                            }
                        }
                    }
                    Ok(default)
                }
                Some(super::HeapObject::Set(set)) => {
                    // Get from set returns the value if present (for membership)
                    // Use content-based equality check
                    let set = set.clone();
                    if set.iter().any(|v| vm.values_equal(*v, args[1])) {
                        Ok(args[1])
                    } else {
                        Ok(default)
                    }
                }
                _ => Ok(default),
            }
        }
        VMValue::Nil => Ok(default),
        _ => Ok(default),
    }
}

fn native_assoc(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 3 {
        return Err(VMError::ArityMismatch {
            expected: 3,
            got: args.len() as u8,
        });
    }

    // Extract collection type
    enum CollData {
        Map(crate::collections::HashMap<VMValue, VMValue>),
        Vector(crate::collections::Vector<VMValue>),
        Variant(super::heap::VariantInstance),
    }

    let coll_data = match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Map(map)) => CollData::Map(map.clone()),
            Some(super::HeapObject::Seq(seq)) if seq.kind == SeqKind::Vector => {
                CollData::Vector(seq.data.clone())
            }
            Some(super::HeapObject::Variant(inst)) => CollData::Variant(inst.clone()),
            _ => {
                return Err(VMError::TypeError(
                    "assoc requires a map, vector, or variant",
                ));
            }
        },
        VMValue::Nil => CollData::Map(crate::collections::HashMap::new()),
        _ => {
            return Err(VMError::TypeError(
                "assoc requires a map, vector, or variant",
            ));
        }
    };

    match coll_data {
        CollData::Map(mut new_map) => {
            // Handle multiple key-value pairs
            // Use content-based insert for proper string key equality
            let mut i = 1;
            while i + 1 < args.len() {
                new_map = vm.map_insert(&new_map, args[i], args[i + 1]);
                i += 2;
            }
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
            Ok(VMValue::HeapRef(new_key))
        }
        CollData::Vector(mut new_vec) => {
            // Handle multiple index-value pairs
            let mut i = 1;
            while i + 1 < args.len() {
                if let VMValue::Int(idx) = args[i] {
                    if idx >= 0 && (idx as usize) < new_vec.len() {
                        new_vec.set(idx as usize, args[i + 1]);
                    } else {
                        return Err(VMError::ValueError(
                            "vector index out of bounds".to_string(),
                        ));
                    }
                } else {
                    return Err(VMError::TypeError("vector index must be integer"));
                }
                i += 2;
            }
            let seq = SeqData {
                data: new_vec,
                kind: SeqKind::Vector,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(new_key))
        }
        CollData::Variant(inst) => {
            // Handle assoc on variants - update fields by keyword
            // Get the type definition for field_index lookup
            let typedef = vm
                .type_registry()
                .get(inst.type_id())
                .ok_or_else(|| VMError::TypeError("unknown variant type"))?;
            let vdef = &typedef.variants[inst.variant_idx() as usize];

            let mut new_fields = inst.fields.clone();
            let mut modified = false;

            let mut i = 1;
            while i + 1 < args.len() {
                if let VMValue::Keyword(kw) = args[i] {
                    // Only update if field exists (affine: unknown field is no-op)
                    if let Some(&field_idx) = vdef.field_index.get(&kw) {
                        new_fields[field_idx as usize] = args[i + 1];
                        modified = true;
                    }
                    // else: unknown field - silently skip (affine semantics)
                }
                // else: non-keyword key - silently skip (affine semantics)
                i += 2;
            }

            if !modified {
                // No changes, return original to avoid unnecessary allocation
                Ok(args[0])
            } else {
                let new_inst = super::heap::VariantInstance::new(
                    inst.type_id(),
                    inst.variant_idx(),
                    new_fields,
                );
                Ok(VMValue::HeapRef(vm.heap_mut().intern_variant(new_inst)))
            }
        }
    }
}

fn native_dissoc(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Map(map)) => {
                let mut new_map = map.clone();
                for k in &args[1..] {
                    new_map.remove(k);
                }
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            _ => Err(VMError::TypeError("dissoc requires a map")),
        },
        _ => Err(VMError::TypeError("dissoc requires a map")),
    }
}

fn native_keys(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Map(map)) => {
                let keys: crate::collections::Vector<VMValue> = map.keys().copied().collect();
                let seq = SeqData {
                    data: keys,
                    kind: SeqKind::List,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            _ => Err(VMError::TypeError("keys requires a map")),
        },
        VMValue::Nil => Ok(VMValue::Nil),
        _ => Err(VMError::TypeError("keys requires a map")),
    }
}

fn native_vals(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Map(map)) => {
                let vals: crate::collections::Vector<VMValue> = map.values().copied().collect();
                let seq = SeqData {
                    data: vals,
                    kind: SeqKind::List,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            _ => Err(VMError::TypeError("vals requires a map")),
        },
        VMValue::Nil => Ok(VMValue::Nil),
        _ => Err(VMError::TypeError("vals requires a map")),
    }
}

fn native_contains(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Map(map)) => {
                    // Use content-based contains check
                    let map = map.clone();
                    Ok(VMValue::Bool(vm.map_contains(&map, args[1])))
                }
                Some(super::HeapObject::Set(set)) => {
                    // Use content-based contains check
                    let set = set.clone();
                    Ok(VMValue::Bool(
                        set.iter().any(|v| vm.values_equal(*v, args[1])),
                    ))
                }
                Some(super::HeapObject::Seq(seq)) => {
                    // For vectors, contains? checks index presence
                    if let VMValue::Int(idx) = args[1] {
                        Ok(VMValue::Bool(idx >= 0 && (idx as usize) < seq.data.len()))
                    } else {
                        Ok(VMValue::Bool(false))
                    }
                }
                _ => Err(VMError::TypeError(
                    "contains? requires a map, set, or vector",
                )),
            }
        }
        VMValue::Nil => Ok(VMValue::Bool(false)),
        _ => Err(VMError::TypeError(
            "contains? requires a map, set, or vector",
        )),
    }
}

// --- Atoms ---

use super::heap::AtomCell;

fn native_atom(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let value = args.first().copied().unwrap_or(VMValue::Nil);
    let atom = AtomCell { value };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Atom(atom), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_deref(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Atom(atom)) => Ok(atom.value),
            _ => Err(VMError::TypeError("deref requires an atom")),
        },
        _ => Err(VMError::TypeError("deref requires an atom")),
    }
}

fn native_reset(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let new_value = args[1];

    match args[0] {
        VMValue::HeapRef(key) => match vm.heap_mut().get_mut(key) {
            Some(super::HeapObject::Atom(atom)) => {
                atom.value = new_value;
                Ok(new_value)
            }
            _ => Err(VMError::TypeError("reset! requires an atom")),
        },
        _ => Err(VMError::TypeError("reset! requires an atom")),
    }
}

fn native_swap(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (swap! atom f) or (swap! atom f x) or (swap! atom f x y) ...
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let atom_key = match args[0] {
        VMValue::HeapRef(k) => k,
        _ => return Err(VMError::TypeError("swap! expects an atom")),
    };

    // Get current value from atom
    let old_val = match vm.heap().get(atom_key) {
        Some(super::HeapObject::Atom(cell)) => cell.value,
        _ => return Err(VMError::TypeError("swap! expects an atom")),
    };

    // Build args for function call: (f old-val extra-args...)
    let func = args[1];
    let mut call_args = vec![old_val];
    call_args.extend_from_slice(&args[2..]);

    // Apply the function
    let new_val = vm.apply(func, &call_args)?;

    // Update the atom
    match vm.heap_mut().get_mut(atom_key) {
        Some(super::HeapObject::Atom(cell)) => {
            cell.value = new_val;
        }
        _ => return Err(VMError::TypeError("atom was collected during swap!")),
    }

    Ok(new_val)
}

// --- Arithmetic (variadic, for completeness) ---

fn native_add(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Ok(VMValue::Int(0));
    }

    let has_float = args.iter().any(|v| matches!(v, VMValue::Float(_)));
    if has_float {
        let mut sum = 0.0f64;
        for arg in args {
            let val = number_to_f64(*arg).ok_or(VMError::TypeError("+ requires numbers"))?;
            sum += val;
        }
        return Ok(VMValue::Float(sum));
    }

    let mut numer = 0i128;
    let mut denom = 1i128;
    for arg in args {
        let (n, d) = number_to_ratio(*arg).ok_or(VMError::TypeError("+ requires numbers"))?;
        numer = numer * d + n * denom;
        denom *= d;
        let g = gcd_i128(numer.abs(), denom);
        numer /= g;
        denom /= g;
    }
    ratio_from_i128(numer, denom)
}

fn native_sub(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Ok(VMValue::Int(0));
    }

    if args.len() == 1 {
        // Unary negation
        return match args[0] {
            VMValue::Int(i) => Ok(VMValue::Int(-i)),
            VMValue::Float(f) => Ok(VMValue::Float(-f)),
            VMValue::Ratio { numer, denom } => ratio_from_i128(-(numer as i128), denom as i128),
            _ => Err(VMError::TypeError("- requires numbers")),
        };
    }

    let has_float = args.iter().any(|v| matches!(v, VMValue::Float(_)));
    if has_float {
        let mut result = number_to_f64(args[0]).ok_or(VMError::TypeError("- requires numbers"))?;
        for arg in &args[1..] {
            let val = number_to_f64(*arg).ok_or(VMError::TypeError("- requires numbers"))?;
            result -= val;
        }
        return Ok(VMValue::Float(result));
    }

    let (mut numer, mut denom) =
        number_to_ratio(args[0]).ok_or(VMError::TypeError("- requires numbers"))?;
    for arg in &args[1..] {
        let (n, d) = number_to_ratio(*arg).ok_or(VMError::TypeError("- requires numbers"))?;
        numer = numer * d - n * denom;
        denom *= d;
        let g = gcd_i128(numer.abs(), denom);
        numer /= g;
        denom /= g;
    }
    ratio_from_i128(numer, denom)
}

fn native_mul(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Ok(VMValue::Int(1));
    }

    let has_float = args.iter().any(|v| matches!(v, VMValue::Float(_)));
    if has_float {
        let mut product = 1.0f64;
        for arg in args {
            let val = number_to_f64(*arg).ok_or(VMError::TypeError("* requires numbers"))?;
            product *= val;
        }
        return Ok(VMValue::Float(product));
    }

    let mut numer = 1i128;
    let mut denom = 1i128;
    for arg in args {
        let (n, d) = number_to_ratio(*arg).ok_or(VMError::TypeError("* requires numbers"))?;
        numer *= n;
        denom *= d;
        let g = gcd_i128(numer.abs(), denom);
        numer /= g;
        denom /= g;
    }
    ratio_from_i128(numer, denom)
}

fn native_div(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    if args.len() == 1 {
        return divide_one(args[0]);
    }

    let mut result = args[0];
    for arg in &args[1..] {
        result = divide_two(result, *arg)?;
    }
    Ok(result)
}

fn number_to_ratio(value: VMValue) -> Option<(i128, i128)> {
    match value {
        VMValue::Int(i) => Some((i as i128, 1)),
        VMValue::Ratio { numer, denom } => Some((numer as i128, denom as i128)),
        _ => None,
    }
}

fn number_to_f64(value: VMValue) -> Option<f64> {
    match value {
        VMValue::Int(i) => Some(i as f64),
        VMValue::Float(f) => Some(f),
        VMValue::Ratio { numer, denom } => Some(numer as f64 / denom as f64),
        _ => None,
    }
}

fn ratio_from_i128(numer: i128, denom: i128) -> Result<VMValue, VMError> {
    if denom == 0 {
        return Err(VMError::DivisionByZero);
    }
    let mut n = numer;
    let mut d = denom;
    if d < 0 {
        n = -n;
        d = -d;
    }
    let g = gcd_i128(n.abs(), d);
    let n = n / g;
    let d = d / g;
    let n_i64 = i64::try_from(n).map_err(|_| VMError::TypeError("ratio overflow"))?;
    let d_i64 = i64::try_from(d).map_err(|_| VMError::TypeError("ratio overflow"))?;
    if d_i64 == 1 {
        Ok(VMValue::Int(n_i64))
    } else {
        Ok(VMValue::Ratio {
            numer: n_i64,
            denom: d_i64,
        })
    }
}

fn compare_numbers(a: VMValue, b: VMValue) -> Result<std::cmp::Ordering, VMError> {
    match (a, b) {
        (VMValue::Float(a), b) => {
            let bf = number_to_f64(b).ok_or(VMError::TypeError("comparison requires numbers"))?;
            Ok(a.partial_cmp(&bf)
                .ok_or(VMError::TypeError("invalid float"))?)
        }
        (a, VMValue::Float(b)) => {
            let af = number_to_f64(a).ok_or(VMError::TypeError("comparison requires numbers"))?;
            Ok(af
                .partial_cmp(&b)
                .ok_or(VMError::TypeError("invalid float"))?)
        }
        (a, b) => {
            let (an, ad) =
                number_to_ratio(a).ok_or(VMError::TypeError("comparison requires numbers"))?;
            let (bn, bd) =
                number_to_ratio(b).ok_or(VMError::TypeError("comparison requires numbers"))?;
            Ok((an * bd).cmp(&(bn * ad)))
        }
    }
}

fn gcd_i128(mut a: i128, mut b: i128) -> i128 {
    while b != 0 {
        let temp = b;
        b = a % b;
        a = temp;
    }
    a.abs()
}

fn divide_one(value: VMValue) -> Result<VMValue, VMError> {
    match value {
        VMValue::Float(f) => Ok(VMValue::Float(1.0 / f)),
        _ => divide_two(VMValue::Int(1), value),
    }
}

fn divide_two(a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
    let has_float = matches!(a, VMValue::Float(_)) || matches!(b, VMValue::Float(_));
    if has_float {
        let af = number_to_f64(a).ok_or(VMError::TypeError("/ requires numbers"))?;
        let bf = number_to_f64(b).ok_or(VMError::TypeError("/ requires numbers"))?;
        if bf == 0.0 {
            return Err(VMError::DivisionByZero);
        }
        return Ok(VMValue::Float(af / bf));
    }

    let (an, ad) = number_to_ratio(a).ok_or(VMError::TypeError("/ requires numbers"))?;
    let (bn, bd) = number_to_ratio(b).ok_or(VMError::TypeError("/ requires numbers"))?;
    if bn == 0 {
        return Err(VMError::DivisionByZero);
    }
    ratio_from_i128(an * bd, ad * bn)
}

// --- Comparison ---

fn native_eq(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Ok(VMValue::Bool(true));
    }
    for i in 1..args.len() {
        if !vm.values_equal(args[i], args[i - 1]) {
            return Ok(VMValue::Bool(false));
        }
    }
    Ok(VMValue::Bool(true))
}

fn native_lt(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Ok(VMValue::Bool(true));
    }
    for i in 1..args.len() {
        if compare_numbers(args[i - 1], args[i])? != std::cmp::Ordering::Less {
            return Ok(VMValue::Bool(false));
        }
    }
    Ok(VMValue::Bool(true))
}

fn native_le(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Ok(VMValue::Bool(true));
    }
    for i in 1..args.len() {
        if compare_numbers(args[i - 1], args[i])? == std::cmp::Ordering::Greater {
            return Ok(VMValue::Bool(false));
        }
    }
    Ok(VMValue::Bool(true))
}

fn native_gt(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Ok(VMValue::Bool(true));
    }
    for i in 1..args.len() {
        if compare_numbers(args[i - 1], args[i])? != std::cmp::Ordering::Greater {
            return Ok(VMValue::Bool(false));
        }
    }
    Ok(VMValue::Bool(true))
}

fn native_ge(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Ok(VMValue::Bool(true));
    }
    for i in 1..args.len() {
        if compare_numbers(args[i - 1], args[i])? == std::cmp::Ordering::Less {
            return Ok(VMValue::Bool(false));
        }
    }
    Ok(VMValue::Bool(true))
}

// --- Predicates ---

fn native_nil(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Bool(args.first() == Some(&VMValue::Nil)))
}

fn native_number(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Bool(matches!(
        args.first(),
        Some(VMValue::Int(_) | VMValue::Float(_) | VMValue::Ratio { .. })
    )))
}

fn native_string(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let is_string = match args.first() {
        Some(VMValue::HeapRef(key)) => {
            matches!(vm.heap().get(*key), Some(super::HeapObject::String(_)))
        }
        _ => false,
    };
    Ok(VMValue::Bool(is_string))
}

fn native_keyword(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Bool(matches!(
        args.first(),
        Some(VMValue::Keyword(_))
    )))
}

fn native_symbol(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Bool(matches!(
        args.first(),
        Some(VMValue::Symbol(_))
    )))
}

fn native_fn(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(matches!(
            vm.heap().get(*key),
            Some(super::HeapObject::Closure(_))
        ))),
        Some(VMValue::NativeFn(_)) => Ok(VMValue::Bool(true)),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_list(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(
            matches!(vm.heap().get(*key), Some(super::HeapObject::Seq(s)) if s.kind == SeqKind::List),
        )),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_vector(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(
            matches!(vm.heap().get(*key), Some(super::HeapObject::Seq(s)) if s.kind == SeqKind::Vector),
        )),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_map(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(matches!(
            vm.heap().get(*key),
            Some(super::HeapObject::Map(_))
        ))),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_set(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(matches!(
            vm.heap().get(*key),
            Some(super::HeapObject::Set(_))
        ))),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_set_constructor(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let items = seq_items(vm, args[0])?;
    let mut set = crate::collections::HashSet::new();
    for item in items {
        set.insert(item);
    }
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Set(set), roots);
    Ok(VMValue::HeapRef(key))
}

fn seq_items(vm: &mut VM, value: VMValue) -> Result<Vec<VMValue>, VMError> {
    // Intermediate type to hold extracted data before allocation
    enum SeqExtract {
        Items(Vec<VMValue>),
        MapPairs(Vec<(VMValue, VMValue)>),
        Chars(Vec<char>),
    }

    let extracted = match value {
        VMValue::Nil => return Ok(Vec::new()),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                SeqExtract::Items(seq.data.iter().copied().collect())
            }
            Some(super::HeapObject::Set(set)) => SeqExtract::Items(set.iter().copied().collect()),
            Some(super::HeapObject::Map(map)) => {
                SeqExtract::MapPairs(map.iter().map(|(k, v)| (*k, *v)).collect())
            }
            Some(super::HeapObject::String(s)) => SeqExtract::Chars(s.chars().collect()),
            _ => return Err(VMError::TypeError("seqable required")),
        },
        _ => return Err(VMError::TypeError("seqable required")),
    };

    // Now do allocations after releasing the immutable borrow
    match extracted {
        SeqExtract::Items(items) => Ok(items),
        SeqExtract::MapPairs(pairs) => {
            let mut items = Vec::new();
            for (k, v) in pairs {
                let data: crate::collections::Vector<VMValue> = vec![k, v].into_iter().collect();
                let pair = SeqData {
                    data,
                    kind: SeqKind::Vector,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let pair_key = vm.heap_mut().alloc(super::HeapObject::Seq(pair), roots);
                items.push(VMValue::HeapRef(pair_key));
            }
            Ok(items)
        }
        SeqExtract::Chars(chars) => {
            let mut items = Vec::new();
            for ch in chars {
                items.push(vm.alloc_string(&ch.to_string()));
            }
            Ok(items)
        }
    }
}

fn native_coll(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::Nil) => Ok(VMValue::Bool(true)),
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(matches!(
            vm.heap().get(*key),
            Some(super::HeapObject::Seq(_) | super::HeapObject::Map(_) | super::HeapObject::Set(_))
        ))),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_seq_pred(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::HeapRef(key)) => Ok(VMValue::Bool(matches!(
            vm.heap().get(*key),
            Some(super::HeapObject::Seq(seq)) if seq.kind == super::heap::SeqKind::List
        ))),
        _ => Ok(VMValue::Bool(false)),
    }
}

fn native_ratio_pred(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Bool(matches!(
        args.first(),
        Some(VMValue::Ratio { .. })
    )))
}

fn native_even(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::Int(n)) => Ok(VMValue::Bool(n % 2 == 0)),
        _ => Err(VMError::TypeError("even? requires an integer")),
    }
}

fn native_odd(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    match args.first() {
        Some(VMValue::Int(n)) => Ok(VMValue::Bool(n % 2 != 0)),
        _ => Err(VMError::TypeError("odd? requires an integer")),
    }
}

fn native_type(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let type_name = match args[0] {
        VMValue::Nil => "nil",
        VMValue::Bool(_) => "bool",
        VMValue::Int(_) => "int",
        VMValue::Float(_) => "float",
        VMValue::Ratio { .. } => "ratio",
        VMValue::Symbol(_) => "symbol",
        VMValue::Keyword(_) => "keyword",
        VMValue::NativeFn(_) => "fn",
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(_)) => "string",
            Some(super::HeapObject::Seq(seq)) => {
                if seq.kind == super::heap::SeqKind::Vector {
                    "vector"
                } else {
                    "list"
                }
            }
            Some(super::HeapObject::Map(_)) => "map",
            Some(super::HeapObject::Set(_)) => "set",
            Some(super::HeapObject::Closure(_)) => "fn",
            Some(super::HeapObject::Continuation(_)) => "continuation",
            Some(super::HeapObject::Atom(_)) => "atom",
            Some(super::HeapObject::Optic(_)) => "optic",
            Some(super::HeapObject::KeyBox(_)) => "keybox",
            Some(super::HeapObject::Regex(_)) => "regex",
            Some(super::HeapObject::Effect(_)) => "effect",
            Some(super::HeapObject::ClosureTemplate(_)) => "closure-template",
            Some(super::HeapObject::Variant(inst)) => {
                // Return family name as keyword
                let type_id = inst.type_id();
                if let Some(typedef) = vm.type_registry().get(type_id) {
                    let name = vm.interner().resolve(&typedef.name).to_string();
                    let spur = vm.interner_mut().get_or_intern(&name);
                    return Ok(VMValue::Keyword(spur));
                }
                "variant"
            }
            None => "unknown",
        },
    };
    let spur = vm.interner_mut().get_or_intern(type_name);
    Ok(VMValue::Keyword(spur))
}

// --- Strings ---

fn native_str(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let mut result = String::new();
    for arg in args {
        if matches!(arg, VMValue::Nil) {
            continue;
        }
        result.push_str(&value_to_string(vm, *arg));
    }
    Ok(vm.alloc_string(&result))
}

/// Convert a VMValue to a string representation.
fn value_to_string(vm: &VM, v: VMValue) -> String {
    match v {
        VMValue::Nil => "".to_string(),
        VMValue::Bool(b) => b.to_string(),
        VMValue::Int(i) => i.to_string(),
        VMValue::Float(f) => f.to_string(),
        VMValue::Ratio { numer, denom } => format!("{}/{}", numer, denom),
        VMValue::Symbol(spur) => {
            // Resolve symbol name via interner
            vm.interner().resolve(&spur).to_string()
        }
        VMValue::Keyword(spur) => {
            // Resolve keyword name via interner, prefix with ':'
            format!(":{}", vm.interner().resolve(&spur))
        }
        VMValue::NativeFn(_) => "<native-fn>".to_string(),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => s.to_string(),
            Some(super::HeapObject::Seq(_)) => "<seq>".to_string(),
            Some(super::HeapObject::Map(_)) => "<map>".to_string(),
            Some(super::HeapObject::Set(_)) => "<set>".to_string(),
            Some(super::HeapObject::Closure(_)) => "<fn>".to_string(),
            Some(super::HeapObject::Continuation(_)) => "<continuation>".to_string(),
            Some(super::HeapObject::Atom(_)) => "<atom>".to_string(),
            Some(super::HeapObject::Optic(_)) => "<optic>".to_string(),
            Some(super::HeapObject::KeyBox(_)) => "<keybox>".to_string(),
            Some(super::HeapObject::Regex(_)) => "<regex>".to_string(),
            Some(super::HeapObject::Effect(e)) => format!("<effect #{}>", e.id.0),
            Some(super::HeapObject::ClosureTemplate(_)) => "<closure-template>".to_string(),
            Some(super::HeapObject::Variant(inst)) => variant_to_string(vm, inst, false),
            None => "<invalid>".to_string(),
        },
    }
}

fn variant_to_string(vm: &VM, inst: &super::heap::VariantInstance, pr: bool) -> String {
    let type_id = inst.type_id();
    let variant_idx = inst.variant_idx();
    let (family_name, variant_name, field_names) = match vm.type_registry().get(type_id) {
        Some(typedef) => {
            let vdef = &typedef.variants[variant_idx as usize];
            (
                vm.interner().resolve(&typedef.name).to_string(),
                vm.interner().resolve(&vdef.name).to_string(),
                vdef.field_names
                    .iter()
                    .map(|s| vm.interner().resolve(s).to_string())
                    .collect::<Vec<_>>(),
            )
        }
        None => return "<unknown-variant>".to_string(),
    };

    if inst.fields.is_empty() {
        format!("#{}/{}", family_name, variant_name)
    } else {
        let pairs: Vec<String> = field_names
            .iter()
            .zip(inst.fields.iter())
            .map(|(name, val)| {
                let val_str = if pr {
                    value_to_pr_string(vm, *val)
                } else {
                    value_to_string(vm, *val)
                };
                format!("{}: {}", name, val_str)
            })
            .collect();
        format!("#{}/{}{{{}}}", family_name, variant_name, pairs.join(", "))
    }
}

fn native_subs(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    use hipstr::HipStr;

    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let hip = match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => s.clone(),
            _ => return Err(VMError::TypeError("subs requires a string")),
        },
        _ => return Err(VMError::TypeError("subs requires a string")),
    };

    let start = match args[1] {
        VMValue::Int(i) if i >= 0 => i as usize,
        VMValue::Int(_) => return Err(VMError::TypeError("start must be non-negative")),
        _ => return Err(VMError::TypeError("start must be integer")),
    };

    let s = hip.as_str();

    // Fast path for ASCII: char index == byte index
    let is_ascii = s.is_ascii();
    let byte_len = s.len();

    let (start_byte, end_byte) = if is_ascii {
        // O(1) for ASCII
        let end = if args.len() > 2 {
            match args[2] {
                VMValue::Int(i) if i >= 0 => (i as usize).min(byte_len),
                VMValue::Int(_) => return Err(VMError::TypeError("end must be non-negative")),
                _ => return Err(VMError::TypeError("end must be integer")),
            }
        } else {
            byte_len
        };
        (start.min(byte_len), end)
    } else {
        // O(n) fallback for UTF-8 with multi-byte chars
        let char_count = s.chars().count();
        let end = if args.len() > 2 {
            match args[2] {
                VMValue::Int(i) if i >= 0 => (i as usize).min(char_count),
                VMValue::Int(_) => return Err(VMError::TypeError("end must be non-negative")),
                _ => return Err(VMError::TypeError("end must be integer")),
            }
        } else {
            char_count
        };
        let start = start.min(char_count);
        // Convert char indices to byte indices
        let start_byte = s
            .char_indices()
            .nth(start)
            .map(|(i, _)| i)
            .unwrap_or(byte_len);
        let end_byte = s
            .char_indices()
            .nth(end)
            .map(|(i, _)| i)
            .unwrap_or(byte_len);
        (start_byte, end_byte)
    };

    if start_byte >= end_byte {
        return Ok(vm.alloc_string(""));
    }

    // O(1) slice using HipStr
    let sliced: HipStr<'static> = hip.slice(start_byte..end_byte);

    // Allocate the sliced string (shares underlying storage with original)
    let roots: Vec<super::value::HeapKey> = vm.collect_roots();
    let key = vm
        .heap_mut()
        .alloc(super::HeapObject::String(sliced), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_pr_str(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = value_to_pr_string(vm, args[0]);
    Ok(vm.alloc_string(&s))
}

/// Convert a VMValue to its printed representation (for display purposes)
pub fn value_to_pr_string(vm: &VM, v: VMValue) -> String {
    match v {
        VMValue::Nil => "nil".to_string(),
        VMValue::Bool(b) => b.to_string(),
        VMValue::Int(i) => i.to_string(),
        VMValue::Float(f) => f.to_string(),
        VMValue::Ratio { numer, denom } => format!("{}/{}", numer, denom),
        VMValue::Symbol(spur) => vm.interner().resolve(&spur).to_string(),
        VMValue::Keyword(spur) => format!(":{}", vm.interner().resolve(&spur)),
        VMValue::NativeFn(_) => "<native-fn>".to_string(),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => format!("\"{}\"", escape_string(s.as_str())),
            Some(super::HeapObject::Seq(seq)) => {
                let (open, close) = match seq.kind {
                    SeqKind::List => ("(", ")"),
                    SeqKind::Vector => ("[", "]"),
                };
                let parts: Vec<String> = seq
                    .data
                    .iter()
                    .map(|v| value_to_pr_string(vm, *v))
                    .collect();
                format!("{}{}{}", open, parts.join(" "), close)
            }
            Some(super::HeapObject::Map(map)) => {
                let mut parts = Vec::new();
                for (k, v) in map.iter() {
                    parts.push(value_to_pr_string(vm, *k));
                    parts.push(value_to_pr_string(vm, *v));
                }
                format!("{{{}}}", parts.join(" "))
            }
            Some(super::HeapObject::Set(set)) => {
                let parts: Vec<String> = set.iter().map(|v| value_to_pr_string(vm, *v)).collect();
                format!("#{{{}}}", parts.join(" "))
            }
            Some(super::HeapObject::KeyBox(v)) => value_to_pr_string(vm, *v),
            Some(super::HeapObject::Closure(_)) => "<fn>".to_string(),
            Some(super::HeapObject::Continuation(_)) => "<continuation>".to_string(),
            Some(super::HeapObject::Atom(_)) => "<atom>".to_string(),
            Some(super::HeapObject::Optic(_)) => "<optic>".to_string(),
            Some(super::HeapObject::Regex(_)) => "<regex>".to_string(),
            Some(super::HeapObject::Effect(e)) => format!("<effect #{}>", e.id.0),
            Some(super::HeapObject::ClosureTemplate(_)) => "<closure-template>".to_string(),
            Some(super::HeapObject::Variant(inst)) => variant_to_string(vm, inst, true),
            None => "<invalid>".to_string(),
        },
    }
}

fn escape_string(s: &str) -> String {
    s.replace('\\', "\\\\").replace('\"', "\\\"")
}

fn native_read_string(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }

    let s = get_string(vm, args[0])?;

    // Parse the string
    let mut reader = crate::Reader::new(&s);
    let forms = reader
        .read_all()
        .map_err(|e| VMError::ValueError(e.to_string()))?;

    // Return the first form, or nil if empty
    if forms.is_empty() {
        return Ok(VMValue::Nil);
    }

    // Convert Value to VMValue
    value_to_vmvalue(vm, &forms[0])
}

/// Convert a tree-walker Value to a VMValue (for read-string)
fn value_to_vmvalue(vm: &mut VM, value: &crate::Value) -> Result<VMValue, VMError> {
    use crate::Value;
    match value.strip_meta() {
        Value::Nil => Ok(VMValue::Nil),
        Value::Bool(b) => Ok(VMValue::Bool(*b)),
        Value::Int(n) => Ok(VMValue::Int(*n)),
        Value::Float(f) => Ok(VMValue::Float(*f)),
        Value::Ratio { numer, denom } => Ok(VMValue::Ratio {
            numer: *numer,
            denom: *denom,
        }),
        Value::String(s) => Ok(vm.alloc_string(s.as_ref())),
        Value::Symbol(s) => {
            let spur = vm.interner_mut().get_or_intern(&s.name);
            Ok(VMValue::Symbol(spur))
        }
        Value::Keyword(k) => {
            let spur = vm.interner_mut().get_or_intern(&k.name);
            Ok(VMValue::Keyword(spur))
        }
        Value::Vector(v) => {
            let elements: Result<crate::collections::Vector<VMValue>, _> =
                v.iter().map(|e| value_to_vmvalue(vm, e)).collect();
            let seq = super::heap::SeqData {
                data: elements?,
                kind: super::heap::SeqKind::Vector,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(key))
        }
        Value::List(l) => {
            let elements: Result<crate::collections::Vector<VMValue>, _> =
                l.iter().map(|e| value_to_vmvalue(vm, e)).collect();
            let seq = super::heap::SeqData {
                data: elements?,
                kind: super::heap::SeqKind::List,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(key))
        }
        Value::Map(m) => {
            let mut map = crate::collections::HashMap::new();
            for (k, v) in m.iter() {
                let k_vm = value_to_vmvalue(vm, k)?;
                let v_vm = value_to_vmvalue(vm, v)?;
                map = vm.map_insert(&map, k_vm, v_vm);
            }
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Map(map), roots);
            Ok(VMValue::HeapRef(key))
        }
        Value::Set(s) => {
            let mut set = crate::collections::HashSet::new();
            for e in s.iter() {
                let v = value_to_vmvalue(vm, e)?;
                set.insert(vm.canonicalize_key(v));
            }
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Set(set), roots);
            Ok(VMValue::HeapRef(key))
        }
        _ => Err(VMError::TypeError("unsupported value type for read-string")),
    }
}

fn native_string_length(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                // Use char count, not byte count, for Unicode correctness
                Some(super::HeapObject::String(s)) => Ok(VMValue::Int(s.chars().count() as i64)),
                _ => Err(VMError::TypeError("string-length requires a string")),
            }
        }
        _ => Err(VMError::TypeError("string-length requires a string")),
    }
}

// --- Regex ---

fn native_re_pattern(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (re-pattern "pattern") -> compiled regex
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }

    let pattern = get_string(vm, args[0])?;
    let re = regex::Regex::new(&pattern)
        .map_err(|e| VMError::ValueError(format!("invalid regex: {}", e)))?;

    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Regex(re), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_re_find(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (re-find regex string) -> first match or nil
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let re = get_regex(vm, args[0])?;
    let s = get_string(vm, args[1])?;

    match re.find(&s) {
        Some(m) => Ok(vm.alloc_string(m.as_str())),
        None => Ok(VMValue::Nil),
    }
}

fn native_re_matches(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (re-matches regex string) -> match if entire string matches, else nil
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let re = get_regex(vm, args[0])?;
    let s = get_string(vm, args[1])?;

    // Check if the regex matches the entire string
    // We need to anchor the regex to match the full string
    let anchored_pattern = format!("^(?:{})$", re.as_str());
    let anchored_re = regex::Regex::new(&anchored_pattern)
        .map_err(|e| VMError::ValueError(format!("invalid regex: {}", e)))?;

    if anchored_re.is_match(&s) {
        Ok(vm.alloc_string(&s))
    } else {
        Ok(VMValue::Nil)
    }
}

fn native_re_seq(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (re-seq regex string) -> lazy seq of all matches
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let re = get_regex(vm, args[0])?;
    let s = get_string(vm, args[1])?;

    // Collect all matches into a vector
    let match_strs: Vec<String> = re.find_iter(&s).map(|m| m.as_str().to_string()).collect();
    let matches: Vec<VMValue> = match_strs.iter().map(|s| vm.alloc_string(s)).collect();

    let data: crate::collections::Vector<VMValue> = matches.into_iter().collect();
    let seq = super::heap::SeqData {
        data,
        kind: super::heap::SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

// --- Optics ---

use super::heap::OpticKind;
use super::heap::VariantInstance;
use lasso::Spur;

/// Look up a keyword field in a variant. Returns (field_value, field_index) or None.
fn variant_field_lookup(vm: &VM, inst: &VariantInstance, kw: Spur) -> Option<(VMValue, u8)> {
    let typedef = vm.type_registry().get(inst.type_id())?;
    let vdef = &typedef.variants[inst.variant_idx() as usize];
    let &idx = vdef.field_index.get(&kw)?;
    Some((inst.fields[idx as usize], idx))
}

/// Create a new variant with one field updated. Returns interned HeapRef.
fn variant_with_field(
    vm: &mut VM,
    inst: &VariantInstance,
    field_idx: u8,
    new_val: VMValue,
) -> VMValue {
    let mut new_fields = inst.fields.clone();
    new_fields[field_idx as usize] = new_val;
    let new_inst = VariantInstance::new(inst.type_id(), inst.variant_idx(), new_fields);
    VMValue::HeapRef(vm.heap_mut().intern_variant(new_inst))
}

/// Get an optic from a VMValue
fn get_optic(vm: &mut VM, value: VMValue) -> Result<OpticKind, VMError> {
    match value {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Optic(kind)) => Ok(kind.clone()),
            Some(super::HeapObject::Seq(seq)) if seq.kind == super::heap::SeqKind::Vector => {
                let items = seq.data.clone();
                let mut optic_keys = Vec::new();
                for item in items.iter().copied() {
                    let optic = get_optic(vm, item)?;
                    let key = alloc_optic(vm, optic)?;
                    optic_keys.push(key);
                }
                Ok(OpticKind::Compose(optic_keys.into_boxed_slice()))
            }
            Some(super::HeapObject::String(_)) => {
                // String keys for maps with string keys
                let key = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(value),
                    Vec::<super::value::HeapKey>::new(),
                );
                Ok(OpticKind::Key(key))
            }
            _ => Err(VMError::TypeError("expected an optic")),
        },
        VMValue::Keyword(_) | VMValue::Symbol(_) => {
            // Keywords and symbols are auto-lifted to Key optics
            let key = vm.heap_mut().alloc(
                super::HeapObject::KeyBox(value),
                Vec::<super::value::HeapKey>::new(),
            );
            Ok(OpticKind::Key(key))
        }
        VMValue::Int(i) => Ok(OpticKind::Index(i)),
        _ => Err(VMError::TypeError("expected an optic")),
    }
}

fn alloc_optic(vm: &mut VM, optic: OpticKind) -> Result<super::value::HeapKey, VMError> {
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    Ok(vm.heap_mut().alloc(super::HeapObject::Optic(optic), roots))
}

/// Helper to get value from KeyBox
fn get_key_value(vm: &VM, key_box_key: super::value::HeapKey) -> Result<VMValue, VMError> {
    match vm.heap().get(key_box_key) {
        Some(super::HeapObject::KeyBox(v)) => Ok(*v),
        _ => Err(VMError::TypeError("expected a key box")),
    }
}

/// View single focus through an optic
fn optic_view(vm: &mut VM, optic: &OpticKind, data: VMValue) -> Result<VMValue, VMError> {
    match optic {
        OpticKind::Key(key_box_key) => {
            // Get the key value from the KeyBox
            let key = get_key_value(vm, *key_box_key)?;
            // Lookup in map or variant
            match data {
                VMValue::HeapRef(data_key) => {
                    // Map path - clone is O(1) for imbl
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        return Ok(vm.map_get(&m, key).unwrap_or(VMValue::Nil));
                    }
                    // Variant path - no clone needed
                    if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            return Ok(variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil));
                        }
                        return Ok(VMValue::Nil);
                    }
                    Err(VMError::TypeError("key optic requires a map or variant"))
                }
                VMValue::Nil => Ok(VMValue::Nil),
                _ => Err(VMError::TypeError("key optic requires a map or variant")),
            }
        }
        OpticKind::Index(i) => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let idx = if *i < 0 { len + *i } else { *i };
                    if idx < 0 || idx >= len {
                        Ok(VMValue::Nil)
                    } else {
                        Ok(seq.data[idx as usize])
                    }
                }
                _ => Err(VMError::TypeError("index optic requires a sequence")),
            },
            VMValue::Nil => Ok(VMValue::Nil),
            _ => Err(VMError::TypeError("index optic requires a sequence")),
        },
        OpticKind::Each => {
            // For view on Each, return first element
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::Vals => {
            // For view on Vals, return first value
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::Keys => {
            // For view on Keys, return first key
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::Some => {
            if data == VMValue::Nil {
                Ok(VMValue::Nil)
            } else {
                Ok(data)
            }
        }
        OpticKind::Compose(ops) => {
            if ops.is_empty() {
                return Ok(data);
            }
            let mut current = data;
            for op_key in ops.iter() {
                let op = match vm.heap().get(*op_key) {
                    Some(super::HeapObject::Optic(k)) => k.clone(),
                    _ => return Err(VMError::TypeError("compose requires optics")),
                };
                current = optic_view(vm, &op, current)?;
            }
            Ok(current)
        }
        OpticKind::Slice { from: _, to: _ } => {
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::Filtered(pred_key) => {
            // Check if the predicate is a KeyBox (keyword lookup)
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(kw)) => {
                    // Keyword lookup in the data (map or variant)
                    let keyword = *kw;
                    match data {
                        VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                            Some(super::HeapObject::Map(m)) => {
                                m.get(&keyword).copied().unwrap_or(VMValue::Nil)
                            }
                            Some(super::HeapObject::Variant(inst)) => {
                                if let VMValue::Keyword(kw) = keyword {
                                    variant_field_lookup(vm, inst, kw)
                                        .map(|(v, _)| v)
                                        .unwrap_or(VMValue::Nil)
                                } else {
                                    VMValue::Nil
                                }
                            }
                            _ => VMValue::Nil,
                        },
                        _ => VMValue::Nil,
                    }
                }
                _ => {
                    // It's a closure, apply it
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(data)
            } else {
                Ok(VMValue::Nil)
            }
        }
        OpticKind::When(pred_key) => {
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) if matches!(val, VMValue::NativeFn(_)) => {
                    vm.apply(*val, &[data])?
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(data)
            } else {
                Ok(VMValue::Nil)
            }
        }
        OpticKind::Custom { get, .. } => {
            let getter = VMValue::HeapRef(*get);
            vm.apply(getter, &[data])
        }
        OpticKind::Deep => {
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::FalsyKey(_) | OpticKind::Compare { .. } => {
            // These are filter predicates, not lenses - view just passes through if truthy
            let all = optic_view_all(vm, optic, data)?;
            Ok(all.into_iter().next().unwrap_or(VMValue::Nil))
        }
        OpticKind::First(inner_key) => {
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            // Short-circuit: only find the first match
            optic_view_first(vm, &inner, data)
        }
    }
}

/// View the first focus through an optic, short-circuiting after the first match.
/// Returns Nil if no match found.
fn optic_view_first(vm: &mut VM, optic: &OpticKind, data: VMValue) -> Result<VMValue, VMError> {
    match optic {
        // For single-focus optics, just delegate to optic_view
        OpticKind::Key(_) | OpticKind::Index(_) | OpticKind::Custom { .. } | OpticKind::Some => {
            optic_view(vm, optic, data)
        }
        // For predicates, delegate (they're already 0-or-1)
        OpticKind::Filtered(_)
        | OpticKind::When(_)
        | OpticKind::FalsyKey(_)
        | OpticKind::Compare { .. } => optic_view(vm, optic, data),
        OpticKind::First(inner_key) => {
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            optic_view_first(vm, &inner, data)
        }
        OpticKind::Each => {
            // Return first element
            match data {
                VMValue::HeapRef(key) => match vm.heap().get(key) {
                    Some(super::HeapObject::Seq(seq)) => {
                        Ok(seq.data.iter().next().copied().unwrap_or(VMValue::Nil))
                    }
                    Some(super::HeapObject::Set(set)) => {
                        Ok(set.iter().next().copied().unwrap_or(VMValue::Nil))
                    }
                    _ => Err(VMError::TypeError("each requires a sequence or set")),
                },
                VMValue::Nil => Ok(VMValue::Nil),
                _ => Err(VMError::TypeError("each requires a sequence or set")),
            }
        }
        OpticKind::Vals => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Map(m)) => {
                    Ok(m.values().next().copied().unwrap_or(VMValue::Nil))
                }
                _ => Err(VMError::TypeError("vals requires a map")),
            },
            _ => Err(VMError::TypeError("vals requires a map")),
        },
        OpticKind::Keys => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Map(m)) => {
                    Ok(m.keys().next().copied().unwrap_or(VMValue::Nil))
                }
                _ => Err(VMError::TypeError("keys requires a map")),
            },
            _ => Err(VMError::TypeError("keys requires a map")),
        },
        OpticKind::Deep => {
            // Deep includes root as first focus
            Ok(data)
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let start = normalize_slice_bound(*from, len, 0);
                    let end = normalize_slice_bound(*to, len, len as usize).min(seq.data.len());
                    if start >= end {
                        Ok(VMValue::Nil)
                    } else {
                        Ok(seq.data[start])
                    }
                }
                _ => Err(VMError::TypeError("slice requires a sequence")),
            },
            VMValue::Nil => Ok(VMValue::Nil),
            _ => Err(VMError::TypeError("slice requires a sequence")),
        },
        OpticKind::Compose(ops) => {
            if ops.is_empty() {
                return Ok(data);
            }
            // For Compose([Deep, pred, ...rest]), we need to search depth-first
            // and return the first match through the full chain.
            // General approach: for first optic, iterate its foci and for each,
            // try view_first through the rest. Return the first non-Nil result.
            let optics: Vec<OpticKind> = ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;
            optic_view_first_composed(vm, &optics, data)
        }
    }
}

/// View first focus through a composed chain of optics.
fn optic_view_first_composed(
    vm: &mut VM,
    optics: &[OpticKind],
    data: VMValue,
) -> Result<VMValue, VMError> {
    if optics.is_empty() {
        return Ok(data);
    }
    if optics.len() == 1 {
        return optic_view_first(vm, &optics[0], data);
    }

    let first = &optics[0];
    let rest = &optics[1..];

    match first {
        OpticKind::Deep => {
            // Depth-first: try rest on current node, then recurse into children
            // Type mismatch means "no focus here", not an error
            let result = match optic_view_first_composed(vm, rest, data) {
                Ok(v) => v,
                Err(VMError::TypeError(_)) => VMValue::Nil, // type mismatch at this level, keep going
                Err(e) => return Err(e),
            };
            if result != VMValue::Nil {
                return Ok(result);
            }
            // Recurse into children
            match data {
                VMValue::HeapRef(key) => match vm.heap().get(key) {
                    Some(super::HeapObject::Seq(seq)) => {
                        let items: Vec<VMValue> = seq.data.iter().copied().collect();
                        for item in items {
                            let r = optic_view_first_deep_composed(vm, rest, item)?;
                            if r != VMValue::Nil {
                                return Ok(r);
                            }
                        }
                        Ok(VMValue::Nil)
                    }
                    Some(super::HeapObject::Map(m)) => {
                        let vals: Vec<VMValue> = m.values().copied().collect();
                        for v in vals {
                            let r = optic_view_first_deep_composed(vm, rest, v)?;
                            if r != VMValue::Nil {
                                return Ok(r);
                            }
                        }
                        Ok(VMValue::Nil)
                    }
                    Some(super::HeapObject::Variant(inst)) => {
                        let fields: Vec<VMValue> = inst.fields.iter().copied().collect();
                        for field in fields {
                            let r = optic_view_first_deep_composed(vm, rest, field)?;
                            if r != VMValue::Nil {
                                return Ok(r);
                            }
                        }
                        Ok(VMValue::Nil)
                    }
                    _ => Ok(VMValue::Nil),
                },
                _ => Ok(VMValue::Nil),
            }
        }
        OpticKind::Each => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let items: Vec<VMValue> = seq.data.iter().copied().collect();
                    for item in items {
                        let r = optic_view_first_composed(vm, rest, item)?;
                        if r != VMValue::Nil {
                            return Ok(r);
                        }
                    }
                    Ok(VMValue::Nil)
                }
                _ => Ok(VMValue::Nil),
            },
            _ => Ok(VMValue::Nil),
        },
        // For single-focus optics, view through first then continue
        _ => {
            let focused = optic_view(vm, first, data)?;
            if focused == VMValue::Nil {
                return Ok(VMValue::Nil);
            }
            optic_view_first_composed(vm, rest, focused)
        }
    }
}

/// Recursive helper for Deep in view_first: tries rest on node, then recurses into children.
fn optic_view_first_deep_composed(
    vm: &mut VM,
    rest: &[OpticKind],
    data: VMValue,
) -> Result<VMValue, VMError> {
    // Try rest on current node - type mismatch means "no focus here", not an error
    let result = match optic_view_first_composed(vm, rest, data) {
        Ok(v) => v,
        Err(VMError::TypeError(_)) => VMValue::Nil, // type mismatch at this level, keep going
        Err(e) => return Err(e),
    };
    if result != VMValue::Nil {
        return Ok(result);
    }
    // Recurse into children
    match data {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let items: Vec<VMValue> = seq.data.iter().copied().collect();
                for item in items {
                    let r = optic_view_first_deep_composed(vm, rest, item)?;
                    if r != VMValue::Nil {
                        return Ok(r);
                    }
                }
                Ok(VMValue::Nil)
            }
            Some(super::HeapObject::Map(m)) => {
                let vals: Vec<VMValue> = m.values().copied().collect();
                for v in vals {
                    let r = optic_view_first_deep_composed(vm, rest, v)?;
                    if r != VMValue::Nil {
                        return Ok(r);
                    }
                }
                Ok(VMValue::Nil)
            }
            Some(super::HeapObject::Variant(inst)) => {
                let fields: Vec<VMValue> = inst.fields.iter().copied().collect();
                for field in fields {
                    let r = optic_view_first_deep_composed(vm, rest, field)?;
                    if r != VMValue::Nil {
                        return Ok(r);
                    }
                }
                Ok(VMValue::Nil)
            }
            _ => Ok(VMValue::Nil),
        },
        _ => Ok(VMValue::Nil),
    }
}

/// View all foci through an optic (returns Vec of matches)
fn optic_view_all(vm: &mut VM, optic: &OpticKind, data: VMValue) -> Result<Vec<VMValue>, VMError> {
    match optic {
        OpticKind::Key(_) | OpticKind::Index(_) | OpticKind::Custom { .. } => {
            // Single-focus optics
            let v = optic_view(vm, optic, data)?;
            if v == VMValue::Nil {
                Ok(vec![])
            } else {
                Ok(vec![v])
            }
        }
        OpticKind::Each => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => Ok(seq.data.iter().copied().collect()),
                Some(super::HeapObject::Set(set)) => Ok(set.iter().copied().collect()),
                _ => Err(VMError::TypeError("each requires a sequence or set")),
            },
            VMValue::Nil => Ok(vec![]),
            _ => Err(VMError::TypeError("each requires a sequence or set")),
        },
        OpticKind::Vals => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Map(m)) => Ok(m.values().copied().collect()),
                _ => Err(VMError::TypeError("vals requires a map")),
            },
            _ => Err(VMError::TypeError("vals requires a map")),
        },
        OpticKind::Keys => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Map(m)) => Ok(m.keys().copied().collect()),
                _ => Err(VMError::TypeError("keys requires a map")),
            },
            _ => Err(VMError::TypeError("keys requires a map")),
        },
        OpticKind::Compose(ops) => {
            if ops.is_empty() {
                return Ok(vec![data]);
            }
            let mut foci = vec![data];
            for op_key in ops.iter() {
                let op = match vm.heap().get(*op_key) {
                    Some(super::HeapObject::Optic(k)) => k.clone(),
                    _ => return Err(VMError::TypeError("compose requires optics")),
                };
                foci = foci
                    .into_iter()
                    .flat_map(|d| optic_view_all(vm, &op, d).unwrap_or_default())
                    .collect();
            }
            Ok(foci)
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let start = normalize_slice_bound(*from, len, 0);
                    let end = normalize_slice_bound(*to, len, len as usize);
                    let end = end.min(seq.data.len());
                    if start >= end {
                        return Ok(vec![]);
                    }
                    Ok(seq
                        .data
                        .iter()
                        .skip(start)
                        .take(end - start)
                        .copied()
                        .collect())
                }
                _ => Err(VMError::TypeError("slice requires a sequence")),
            },
            VMValue::Nil => Ok(vec![]),
            _ => Err(VMError::TypeError("slice requires a sequence")),
        },
        OpticKind::Some => {
            if data == VMValue::Nil {
                Ok(vec![])
            } else {
                Ok(vec![data])
            }
        }
        OpticKind::Filtered(pred_key) => {
            // Check if the predicate is a KeyBox (keyword or native fn)
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) => {
                    match val {
                        VMValue::Keyword(kw) => {
                            // Keyword lookup in the data (map or variant)
                            let kw = *kw;
                            let keyword = VMValue::Keyword(kw);
                            match data {
                                VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                                    Some(super::HeapObject::Map(m)) => {
                                        m.get(&keyword).copied().unwrap_or(VMValue::Nil)
                                    }
                                    Some(super::HeapObject::Variant(inst)) => {
                                        variant_field_lookup(vm, inst, kw)
                                            .map(|(v, _)| v)
                                            .unwrap_or(VMValue::Nil)
                                    }
                                    _ => VMValue::Nil,
                                },
                                _ => VMValue::Nil,
                            }
                        }
                        VMValue::NativeFn(_) => {
                            // Native function - apply it
                            vm.apply(*val, &[data])?
                        }
                        _ => VMValue::Nil,
                    }
                }
                _ => {
                    // It's a closure, apply it
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(vec![data])
            } else {
                Ok(vec![])
            }
        }
        OpticKind::When(pred_key) => {
            // When is like Filtered but for predicates
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) if matches!(val, VMValue::NativeFn(_)) => {
                    vm.apply(*val, &[data])?
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(vec![data])
            } else {
                Ok(vec![])
            }
        }
        OpticKind::Deep => {
            // Include the root, then all nested values
            let mut results = vec![data];
            collect_deep_vm(vm, data, &mut results);
            Ok(results)
        }
        OpticKind::FalsyKey(key_box_key) => {
            // [!:key] - check if map/variant[key] is falsy
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    // Map path - clone is O(1) for imbl
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    // Variant path - no clone needed
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            // Return data if value is falsy (NOT truthy)
            if !val.is_truthy() {
                Ok(vec![data])
            } else {
                Ok(vec![])
            }
        }
        OpticKind::Compare {
            key: key_box_key,
            op,
            value: compare_val,
        } => {
            // [.key op val] - compare map/variant[key] against value
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            // Compare values
            let result = compare_vm_values(vm, val, *compare_val, *op);
            if result { Ok(vec![data]) } else { Ok(vec![]) }
        }
        OpticKind::First(inner_key) => {
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            let v = optic_view_first(vm, &inner, data)?;
            if v == VMValue::Nil {
                Ok(vec![])
            } else {
                Ok(vec![v])
            }
        }
    }
}

/// Compare two VMValues using the given operator
fn compare_vm_values(vm: &VM, a: VMValue, b: VMValue, op: super::heap::CompareOp) -> bool {
    use super::heap::CompareOp;

    // Extract numeric values for comparison
    let a_num = match a {
        VMValue::Int(i) => Some(i as f64),
        VMValue::Float(f) => Some(f),
        _ => None,
    };
    let b_num = match b {
        VMValue::Int(i) => Some(i as f64),
        VMValue::Float(f) => Some(f),
        _ => None,
    };

    match op {
        CompareOp::Eq => vm.values_equal(a, b),
        CompareOp::Neq => !vm.values_equal(a, b),
        CompareOp::Gt => a_num.zip(b_num).is_some_and(|(a, b)| a > b),
        CompareOp::Lt => a_num.zip(b_num).is_some_and(|(a, b)| a < b),
        CompareOp::Gte => a_num.zip(b_num).is_some_and(|(a, b)| a >= b),
        CompareOp::Lte => a_num.zip(b_num).is_some_and(|(a, b)| a <= b),
    }
}

/// Collect all nested values for Deep optic
fn collect_deep_vm(vm: &VM, data: VMValue, results: &mut Vec<VMValue>) {
    match data {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                for item in seq.data.iter() {
                    results.push(*item);
                    collect_deep_vm(vm, *item, results);
                }
            }
            Some(super::HeapObject::Map(m)) => {
                for v in m.values() {
                    results.push(*v);
                    collect_deep_vm(vm, *v, results);
                }
            }
            Some(super::HeapObject::Set(s)) => {
                for item in s.iter() {
                    results.push(*item);
                    collect_deep_vm(vm, *item, results);
                }
            }
            Some(super::HeapObject::Variant(inst)) => {
                for field in inst.fields.iter() {
                    results.push(*field);
                    collect_deep_vm(vm, *field, results);
                }
            }
            _ => {}
        },
        _ => {}
    }
}

/// Normalize slice bound (Python-like semantics)
fn normalize_slice_bound(bound: Option<i64>, len: i64, default: usize) -> usize {
    match bound {
        None => default,
        Some(i) => {
            let idx = if i < 0 { len + i } else { i };
            idx.max(0) as usize
        }
    }
}

/// Transform all foci through an optic
fn optic_over(
    vm: &mut VM,
    optic: &OpticKind,
    func: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    match optic {
        OpticKind::Key(key_box_key) => {
            let key = get_key_value(vm, *key_box_key)?;
            match data {
                VMValue::HeapRef(data_key) => {
                    // Map path - clone is O(1) for imbl
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        let old = vm.map_get(&m, key).unwrap_or(VMValue::Nil);
                        let new = vm.apply(func, &[old])?;
                        let new_map = vm.map_insert(&m, key, new);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let map_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        return Ok(VMValue::HeapRef(map_key));
                    }
                    // Variant path - clone only the fields we need
                    if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            if let Some((old, idx)) = variant_field_lookup(vm, inst, kw) {
                                let inst = inst.clone();
                                let new = vm.apply(func, &[old])?;
                                return Ok(variant_with_field(vm, &inst, idx, new));
                            }
                        }
                        return Ok(data); // no focus → no-op
                    }
                    Err(VMError::TypeError("key optic requires a map or variant"))
                }
                VMValue::Nil => {
                    // Create new map with key
                    let new = vm.apply(func, &[VMValue::Nil])?;
                    let empty_map = crate::collections::HashMap::new();
                    let new_map = vm.map_insert(&empty_map, key, new);
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let map_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(map_key))
                }
                _ => Err(VMError::TypeError("key optic requires a map or variant")),
            }
        }
        OpticKind::Index(i) => {
            match data {
                VMValue::HeapRef(data_key) => {
                    // Clone the seq data before we borrow vm mutably
                    let (seq_data, seq_kind, idx, old) = match vm.heap().get(data_key) {
                        Some(super::HeapObject::Seq(seq)) => {
                            let len = seq.data.len() as i64;
                            let idx = if *i < 0 { len + *i } else { *i };
                            if idx < 0 || idx >= len {
                                // Out of bounds: no-op
                                return Ok(data);
                            }
                            let idx = idx as usize;
                            let old = seq.data[idx];
                            (seq.data.clone(), seq.kind, idx, old)
                        }
                        _ => return Err(VMError::TypeError("index optic requires a sequence")),
                    };
                    let new = vm.apply(func, &[old])?;
                    let new_data = seq_data.update(idx, new);
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("index optic requires a sequence")),
            }
        }
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut new_data = crate::collections::Vector::new();
                    for item in seq_data.iter() {
                        let new_item = vm.apply(func, &[*item])?;
                        new_data.push_back(new_item);
                    }
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                Some(super::HeapObject::Set(set)) => {
                    let set_data = set.clone();
                    let mut new_set = crate::collections::HashSet::new();
                    for item in set_data.iter() {
                        let new_item = vm.apply(func, &[*item])?;
                        new_set.insert(new_item);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Set(new_set), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("each optic requires a sequence or set")),
            },
            _ => Err(VMError::TypeError("each optic requires a sequence or set")),
        },
        OpticKind::Vals => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Map(m)) => {
                    let map_data = m.clone();
                    let mut new_map = crate::collections::HashMap::new();
                    for (k, v) in map_data.iter() {
                        let new_v = vm.apply(func, &[*v])?;
                        new_map.insert(*k, new_v);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("vals optic requires a map")),
            },
            _ => Err(VMError::TypeError("vals optic requires a map")),
        },
        OpticKind::Compose(ops) => {
            // For over with composed optics, we need to thread through
            // This is complex - for now, implement a simple version
            if ops.is_empty() {
                return vm.apply(func, &[data]);
            }
            // Get all optics
            let optics: Vec<OpticKind> = ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;

            // Recursive over for composition
            optic_over_composed(vm, &optics, func, data)
        }
        OpticKind::Filtered(pred_key) => {
            // Check if the predicate is a KeyBox (keyword or native fn)
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) => {
                    match val {
                        VMValue::Keyword(kw) => {
                            // Keyword lookup in the data (map or variant)
                            let kw = *kw;
                            let keyword = VMValue::Keyword(kw);
                            match data {
                                VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                                    Some(super::HeapObject::Map(m)) => {
                                        m.get(&keyword).copied().unwrap_or(VMValue::Nil)
                                    }
                                    Some(super::HeapObject::Variant(inst)) => {
                                        variant_field_lookup(vm, inst, kw)
                                            .map(|(v, _)| v)
                                            .unwrap_or(VMValue::Nil)
                                    }
                                    _ => VMValue::Nil,
                                },
                                _ => VMValue::Nil,
                            }
                        }
                        VMValue::NativeFn(_) => {
                            // Native function - apply it
                            vm.apply(*val, &[data])?
                        }
                        _ => VMValue::Nil,
                    }
                }
                _ => {
                    // It's a closure, apply it
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                vm.apply(func, &[data])
            } else {
                Ok(data)
            }
        }
        OpticKind::When(pred_key) => {
            // When is like Filtered but for predicates
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) if matches!(val, VMValue::NativeFn(_)) => {
                    vm.apply(*val, &[data])?
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                vm.apply(func, &[data])
            } else {
                Ok(data)
            }
        }
        OpticKind::Some => {
            if data == VMValue::Nil {
                Ok(data)
            } else {
                vm.apply(func, &[data])
            }
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let start = normalize_slice_bound(*from, len, 0);
                    let end = normalize_slice_bound(*to, len, len as usize);
                    let end = end.min(seq.data.len());

                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut new_data = seq_data.clone();
                    for i in start..end {
                        let old = seq_data[i];
                        let new = vm.apply(func, &[old])?;
                        new_data = new_data.update(i, new);
                    }
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("slice optic requires a sequence")),
            },
            _ => Err(VMError::TypeError("slice optic requires a sequence")),
        },
        OpticKind::Custom { get, set } => {
            let getter = VMValue::HeapRef(*get);
            let setter = VMValue::HeapRef(*set);
            let old = vm.apply(getter, &[data])?;
            let new = vm.apply(func, &[old])?;
            vm.apply(setter, &[data, new])
        }
        OpticKind::Deep => {
            // Apply func to every node in the tree
            optic_over_deep_composed(vm, &[], func, data)
        }
        OpticKind::Keys => {
            // Transform keys of a map
            match data {
                VMValue::HeapRef(data_key) => {
                    let map_data = match vm.heap().get(data_key) {
                        Some(super::HeapObject::Map(m)) => m.clone(),
                        _ => return Err(VMError::TypeError("keys optic requires a map")),
                    };
                    let mut new_map = crate::collections::HashMap::new();
                    for (k, v) in map_data.iter() {
                        let new_k = vm.apply(func, &[*k])?;
                        new_map.insert(new_k, *v);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("keys optic requires a map")),
            }
        }
        OpticKind::FalsyKey(key_box_key) => {
            // [!:key] - apply func if map[key] is falsy
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            if !val.is_truthy() {
                vm.apply(func, &[data])
            } else {
                Ok(data)
            }
        }
        OpticKind::Compare {
            key: key_box_key,
            op,
            value: compare_val,
        } => {
            // [.key op val] - apply func if comparison passes
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            let result = compare_vm_values(vm, val, *compare_val, *op);
            if result {
                vm.apply(func, &[data])
            } else {
                Ok(data)
            }
        }
        OpticKind::First(inner_key) => {
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            optic_over_first(vm, &inner, func, data)
        }
    }
}

/// Over for First optic: single-pass find-and-modify of the first matching node.
/// Walks the tree according to the inner optic's structure, applies func to the
/// first match, and rebuilds the path back up. No separate view pass needed.
fn optic_over_first(
    vm: &mut VM,
    inner: &OpticKind,
    func: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    let (result, _) = optic_over_first_inner(vm, inner, func, data)?;
    Ok(result)
}

/// Returns (new_data, did_modify). Short-circuits after first modification.
fn optic_over_first_inner(
    vm: &mut VM,
    optic: &OpticKind,
    func: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    match optic {
        OpticKind::Compose(ops) => {
            let optics: Vec<OpticKind> = ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;
            optic_over_first_composed(vm, &optics, func, data)
        }
        // Multi-focus: modify only the first focus
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    if seq.data.is_empty() {
                        return Ok((data, false));
                    }
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let old = seq_data[0];
                    let new = vm.apply(func, &[old])?;
                    let new_data = seq_data.update(0, new);
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok((VMValue::HeapRef(key), true))
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        OpticKind::Vals => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Map(m)) => {
                    let map_data = m.clone();
                    if let Some((k, v)) = map_data.iter().next() {
                        let new_v = vm.apply(func, &[*v])?;
                        let new_map = map_data.update(*k, new_v);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        Ok((VMValue::HeapRef(key), true))
                    } else {
                        Ok((data, false))
                    }
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        OpticKind::Deep => {
            // Apply func to root (the first focus of Deep)
            let new_val = vm.apply(func, &[data])?;
            Ok((new_val, true))
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let start = normalize_slice_bound(*from, len, 0);
                    let end = normalize_slice_bound(*to, len, len as usize).min(seq.data.len());
                    if start >= end {
                        return Ok((data, false));
                    }
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let old = seq_data[start];
                    let new = vm.apply(func, &[old])?;
                    let new_data = seq_data.update(start, new);
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok((VMValue::HeapRef(key), true))
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        OpticKind::Keys => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Map(m)) => {
                    let map_data = m.clone();
                    if let Some((k, v)) = map_data.iter().next() {
                        let new_k = vm.apply(func, &[*k])?;
                        let mut new_map = map_data.without(k);
                        new_map.insert(new_k, *v);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        Ok((VMValue::HeapRef(key), true))
                    } else {
                        Ok((data, false))
                    }
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        // For single-focus optics, view then set
        _ => {
            let focused = optic_view_first(vm, optic, data)?;
            if focused == VMValue::Nil {
                return Ok((data, false));
            }
            let new_val = vm.apply(func, &[focused])?;
            let result = optic_set(vm, optic, new_val, data)?;
            Ok((result, true))
        }
    }
}

/// Single-pass over for a composed optic chain, modifying only the first match.
/// Returns (new_data, did_modify).
fn optic_over_first_composed(
    vm: &mut VM,
    optics: &[OpticKind],
    func: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    if optics.is_empty() {
        let new_val = vm.apply(func, &[data])?;
        return Ok((new_val, true));
    }
    if optics.len() == 1 {
        return optic_over_first_inner(vm, &optics[0], func, data);
    }

    let first = &optics[0];
    let rest = &optics[1..];

    match first {
        OpticKind::Deep => {
            // Try to modify at current level first, then recurse into children
            optic_over_first_deep(vm, rest, func, data)
        }
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut new_data = seq_data.clone();
                    for (i, item) in seq_data.iter().enumerate() {
                        let (new_item, did) = optic_over_first_composed(vm, rest, func, *item)?;
                        if did {
                            new_data = new_data.update(i, new_item);
                            let new_seq = SeqData {
                                data: new_data,
                                kind: seq_kind,
                            };
                            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                            let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                            return Ok((VMValue::HeapRef(key), true));
                        }
                    }
                    Ok((data, false))
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        // Predicates: check if passes, if so recurse into rest
        OpticKind::Filtered(_)
        | OpticKind::When(_)
        | OpticKind::FalsyKey(_)
        | OpticKind::Compare { .. } => {
            // Check if predicate passes on data
            let passes = {
                let all = optic_view_all(vm, first, data)?;
                !all.is_empty()
            };
            if passes {
                optic_over_first_composed(vm, rest, func, data)
            } else {
                Ok((data, false))
            }
        }
        // Single-focus optics: view through first, recurse into rest, set back
        OpticKind::Key(_) => {
            let nested = optic_view(vm, first, data)?;
            let (new_nested, did) = optic_over_first_composed(vm, rest, func, nested)?;
            if did {
                let result = optic_set(vm, first, new_nested, data)?;
                Ok((result, true))
            } else {
                Ok((data, false))
            }
        }
        OpticKind::Index(_) => {
            let nested = optic_view(vm, first, data)?;
            let (new_nested, did) = optic_over_first_composed(vm, rest, func, nested)?;
            if did {
                let result = optic_set(vm, first, new_nested, data)?;
                Ok((result, true))
            } else {
                Ok((data, false))
            }
        }
        OpticKind::Compose(inner_ops) => {
            // Flatten
            let inner_optics: Vec<OpticKind> = inner_ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;
            let mut all_optics = inner_optics;
            all_optics.extend(rest.iter().cloned());
            optic_over_first_composed(vm, &all_optics, func, data)
        }
        _ => {
            // Fallback for other optics
            let nested = optic_view(vm, first, data)?;
            if nested == VMValue::Nil {
                return Ok((data, false));
            }
            let (new_nested, did) = optic_over_first_composed(vm, rest, func, nested)?;
            if did {
                let result = optic_set(vm, first, new_nested, data)?;
                Ok((result, true))
            } else {
                Ok((data, false))
            }
        }
    }
}

/// Single-pass deep traversal for over-first: try rest at current node, then recurse into children.
/// Returns (new_data, did_modify). Short-circuits after first modification.
fn optic_over_first_deep(
    vm: &mut VM,
    rest: &[OpticKind],
    func: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    // Try to apply rest+func at current level
    let (result, did) = optic_over_first_composed(vm, rest, func, data)?;
    if did {
        return Ok((result, true));
    }

    // Recurse into children
    match data {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let seq_data = seq.data.clone();
                let seq_kind = seq.kind;
                let mut new_data = seq_data.clone();
                for (i, item) in seq_data.iter().enumerate() {
                    let (new_item, did) = optic_over_first_deep(vm, rest, func, *item)?;
                    if did {
                        new_data = new_data.update(i, new_item);
                        let new_seq = SeqData {
                            data: new_data,
                            kind: seq_kind,
                        };
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                        return Ok((VMValue::HeapRef(new_key), true));
                    }
                }
                Ok((data, false))
            }
            Some(super::HeapObject::Map(m)) => {
                let map_data = m.clone();
                let mut new_map = map_data.clone();
                for (k, v) in map_data.iter() {
                    let (new_v, did) = optic_over_first_deep(vm, rest, func, *v)?;
                    if did {
                        new_map = new_map.update(*k, new_v);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        return Ok((VMValue::HeapRef(new_key), true));
                    }
                }
                Ok((data, false))
            }
            Some(super::HeapObject::Variant(inst)) => {
                let fields_clone = inst.fields.clone();
                let type_id = inst.type_id();
                let variant_idx = inst.variant_idx();
                let mut new_fields = fields_clone.clone();
                for (i, field) in fields_clone.iter().enumerate() {
                    let (new_field, did) = optic_over_first_deep(vm, rest, func, *field)?;
                    if did {
                        new_fields[i] = new_field;
                        let new_inst =
                            super::heap::VariantInstance::new(type_id, variant_idx, new_fields);
                        return Ok((
                            VMValue::HeapRef(vm.heap_mut().intern_variant(new_inst)),
                            true,
                        ));
                    }
                }
                Ok((data, false))
            }
            _ => Ok((data, false)),
        },
        _ => Ok((data, false)),
    }
}

/// Single-pass set for First optic: replaces first matching node with new_val.
/// Mirrors optic_over_first_composed but uses a constant value instead of applying a function.
fn optic_set_first_composed(
    vm: &mut VM,
    optics: &[OpticKind],
    new_val: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    if optics.is_empty() {
        return Ok((new_val, true));
    }
    if optics.len() == 1 {
        return optic_set_first_single(vm, &optics[0], new_val, data);
    }

    let first = &optics[0];
    let rest = &optics[1..];

    match first {
        OpticKind::Deep => optic_set_first_deep(vm, rest, new_val, data),
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut nd = seq_data.clone();
                    for (i, item) in seq_data.iter().enumerate() {
                        let (new_item, did) = optic_set_first_composed(vm, rest, new_val, *item)?;
                        if did {
                            nd = nd.update(i, new_item);
                            let new_seq = SeqData {
                                data: nd,
                                kind: seq_kind,
                            };
                            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                            let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                            return Ok((VMValue::HeapRef(key), true));
                        }
                    }
                    Ok((data, false))
                }
                _ => Ok((data, false)),
            },
            _ => Ok((data, false)),
        },
        OpticKind::Filtered(_)
        | OpticKind::When(_)
        | OpticKind::FalsyKey(_)
        | OpticKind::Compare { .. } => {
            let all = optic_view_all(vm, first, data)?;
            if !all.is_empty() {
                optic_set_first_composed(vm, rest, new_val, data)
            } else {
                Ok((data, false))
            }
        }
        OpticKind::Compose(inner_ops) => {
            let inner_optics: Vec<OpticKind> = inner_ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;
            let mut all_optics = inner_optics;
            all_optics.extend(rest.iter().cloned());
            optic_set_first_composed(vm, &all_optics, new_val, data)
        }
        _ => {
            let nested = optic_view(vm, first, data)?;
            if nested == VMValue::Nil {
                return Ok((data, false));
            }
            let (new_nested, did) = optic_set_first_composed(vm, rest, new_val, nested)?;
            if did {
                let result = optic_set(vm, first, new_nested, data)?;
                Ok((result, true))
            } else {
                Ok((data, false))
            }
        }
    }
}

fn optic_set_first_single(
    vm: &mut VM,
    optic: &OpticKind,
    new_val: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    let focused = optic_view_first(vm, optic, data)?;
    if focused == VMValue::Nil {
        return Ok((data, false));
    }
    let result = optic_set(vm, optic, new_val, data)?;
    Ok((result, true))
}

fn optic_set_first_deep(
    vm: &mut VM,
    rest: &[OpticKind],
    new_val: VMValue,
    data: VMValue,
) -> Result<(VMValue, bool), VMError> {
    let (result, did) = optic_set_first_composed(vm, rest, new_val, data)?;
    if did {
        return Ok((result, true));
    }

    match data {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let seq_data = seq.data.clone();
                let seq_kind = seq.kind;
                let mut nd = seq_data.clone();
                for (i, item) in seq_data.iter().enumerate() {
                    let (new_item, did) = optic_set_first_deep(vm, rest, new_val, *item)?;
                    if did {
                        nd = nd.update(i, new_item);
                        let new_seq = SeqData {
                            data: nd,
                            kind: seq_kind,
                        };
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                        return Ok((VMValue::HeapRef(new_key), true));
                    }
                }
                Ok((data, false))
            }
            Some(super::HeapObject::Map(m)) => {
                let map_data = m.clone();
                let mut new_map = map_data.clone();
                for (k, v) in map_data.iter() {
                    let (new_v, did) = optic_set_first_deep(vm, rest, new_val, *v)?;
                    if did {
                        new_map = new_map.update(*k, new_v);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        return Ok((VMValue::HeapRef(new_key), true));
                    }
                }
                Ok((data, false))
            }
            Some(super::HeapObject::Variant(inst)) => {
                let fields_clone = inst.fields.clone();
                let type_id = inst.type_id();
                let variant_idx = inst.variant_idx();
                let mut new_fields = fields_clone.clone();
                for (i, field) in fields_clone.iter().enumerate() {
                    let (new_field, did) = optic_set_first_deep(vm, rest, new_val, *field)?;
                    if did {
                        new_fields[i] = new_field;
                        let new_inst =
                            super::heap::VariantInstance::new(type_id, variant_idx, new_fields);
                        return Ok((
                            VMValue::HeapRef(vm.heap_mut().intern_variant(new_inst)),
                            true,
                        ));
                    }
                }
                Ok((data, false))
            }
            _ => Ok((data, false)),
        },
        _ => Ok((data, false)),
    }
}

/// Helper for composed optic over
fn optic_over_composed(
    vm: &mut VM,
    optics: &[OpticKind],
    func: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    if optics.is_empty() {
        return vm.apply(func, &[data]);
    }
    if optics.len() == 1 {
        return optic_over(vm, &optics[0], func, data);
    }

    // For composed optics: over [a b c] f data = over a (fn [x] (over [b c] f x)) data
    // This requires creating a closure, which is complex in the VM
    // For now, use a simpler approach: view through all but last, then over the last

    let first = &optics[0];
    let rest = &optics[1..];

    // We need to transform at each focus of the first optic
    match first {
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut new_data = crate::collections::Vector::new();
                    for item in seq_data.iter() {
                        let new_item = optic_over_composed(vm, rest, func, *item)?;
                        new_data.push_back(new_item);
                    }
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("each requires sequence")),
            },
            _ => Err(VMError::TypeError("each requires sequence")),
        },
        OpticKind::Key(key_box_key) => {
            let key = get_key_value(vm, *key_box_key)?;
            match data {
                VMValue::HeapRef(data_key) => {
                    // Map path - clone is O(1) for imbl
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        let old = vm.map_get(&m, key).unwrap_or(VMValue::Nil);
                        let new = optic_over_composed(vm, rest, func, old)?;
                        let new_map = vm.map_insert(&m, key, new);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let map_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        return Ok(VMValue::HeapRef(map_key));
                    }
                    // Variant path - clone only when we have a match
                    if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            if let Some((old, idx)) = variant_field_lookup(vm, inst, kw) {
                                let inst = inst.clone();
                                let new = optic_over_composed(vm, rest, func, old)?;
                                return Ok(variant_with_field(vm, &inst, idx, new));
                            }
                        }
                        return Ok(data); // no focus → no-op
                    }
                    Err(VMError::TypeError("key requires map or variant"))
                }
                _ => Err(VMError::TypeError("key requires map or variant")),
            }
        }
        OpticKind::Index(i) => {
            match data {
                VMValue::HeapRef(data_key) => {
                    // Clone the seq data before we borrow vm mutably
                    let (seq_data, seq_kind, idx, old) = match vm.heap().get(data_key) {
                        Some(super::HeapObject::Seq(seq)) => {
                            let len = seq.data.len() as i64;
                            let idx = if *i < 0 { len + *i } else { *i };
                            if idx < 0 || idx >= len {
                                return Ok(data);
                            }
                            let idx = idx as usize;
                            let old = seq.data[idx];
                            (seq.data.clone(), seq.kind, idx, old)
                        }
                        _ => return Err(VMError::TypeError("index requires sequence")),
                    };
                    let new = optic_over_composed(vm, rest, func, old)?;
                    let new_data = seq_data.update(idx, new);
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("index requires sequence")),
            }
        }
        OpticKind::Vals => match data {
            VMValue::HeapRef(data_key) => {
                let map_data = match vm.heap().get(data_key) {
                    Some(super::HeapObject::Map(m)) => m.clone(),
                    _ => return Err(VMError::TypeError("vals requires map")),
                };
                let mut new_map = crate::collections::HashMap::new();
                for (k, old) in map_data.iter() {
                    let new = optic_over_composed(vm, rest, func, *old)?;
                    new_map.insert(*k, new);
                }
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                Ok(VMValue::HeapRef(key))
            }
            _ => Err(VMError::TypeError("vals requires map")),
        },
        OpticKind::Compose(inner_ops) => {
            // Flatten the composed optics and recurse
            let inner_optics: Vec<OpticKind> = inner_ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;

            let mut all_optics = inner_optics;
            all_optics.extend(rest.iter().cloned());
            optic_over_composed(vm, &all_optics, func, data)
        }
        OpticKind::Filtered(pred_key) => {
            // Check if predicate passes; if yes, recurse with rest; else return unchanged
            let pred_key = *pred_key;
            let result = match vm.heap().get(pred_key) {
                Some(super::HeapObject::KeyBox(val)) => {
                    match val {
                        VMValue::Keyword(kw) => {
                            // Keyword lookup in the data (map or variant)
                            let kw = *kw;
                            let keyword = VMValue::Keyword(kw);
                            match data {
                                VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                                    Some(super::HeapObject::Map(m)) => {
                                        m.get(&keyword).copied().unwrap_or(VMValue::Nil)
                                    }
                                    Some(super::HeapObject::Variant(inst)) => {
                                        variant_field_lookup(vm, inst, kw)
                                            .map(|(v, _)| v)
                                            .unwrap_or(VMValue::Nil)
                                    }
                                    _ => VMValue::Nil,
                                },
                                _ => VMValue::Nil,
                            }
                        }
                        VMValue::NativeFn(_) => {
                            // Native function - apply it
                            vm.apply(*val, &[data])?
                        }
                        _ => VMValue::Nil,
                    }
                }
                _ => {
                    // It's a closure, apply it
                    let pred = VMValue::HeapRef(pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                optic_over_composed(vm, rest, func, data)
            } else {
                Ok(data)
            }
        }
        OpticKind::When(pred_key) => {
            // When is like Filtered but for predicates
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) if matches!(val, VMValue::NativeFn(_)) => {
                    vm.apply(*val, &[data])?
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                optic_over_composed(vm, rest, func, data)
            } else {
                Ok(data)
            }
        }
        OpticKind::Some => {
            if data == VMValue::Nil {
                Ok(data)
            } else {
                optic_over_composed(vm, rest, func, data)
            }
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(data_key) => {
                let (seq_data, seq_kind, start, end) = match vm.heap().get(data_key) {
                    Some(super::HeapObject::Seq(seq)) => {
                        let len = seq.data.len() as i64;
                        let start = normalize_slice_bound(*from, len, 0);
                        let end = normalize_slice_bound(*to, len, len as usize);
                        let end = end.min(seq.data.len());
                        (seq.data.clone(), seq.kind, start, end)
                    }
                    _ => return Err(VMError::TypeError("slice optic requires a sequence")),
                };
                let mut new_data = seq_data.clone();
                for i in start..end {
                    let old = seq_data[i];
                    let new = optic_over_composed(vm, rest, func, old)?;
                    new_data = new_data.update(i, new);
                }
                let new_seq = SeqData {
                    data: new_data,
                    kind: seq_kind,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                Ok(VMValue::HeapRef(key))
            }
            _ => Err(VMError::TypeError("slice optic requires a sequence")),
        },
        OpticKind::Keys => {
            // Transform keys of a map (view the keys, update by rebuilding with new keys)
            match data {
                VMValue::HeapRef(data_key) => {
                    let map_data = match vm.heap().get(data_key) {
                        Some(super::HeapObject::Map(m)) => m.clone(),
                        _ => return Err(VMError::TypeError("keys optic requires a map")),
                    };
                    let mut new_map = crate::collections::HashMap::new();
                    for (k, v) in map_data.iter() {
                        let new_k = optic_over_composed(vm, rest, func, *k)?;
                        new_map.insert(new_k, *v);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("keys optic requires a map")),
            }
        }
        OpticKind::Deep => {
            // Recursive descent: apply to all matching foci in tree structure
            // For now, try to apply to current, then recurse into children
            optic_over_deep_composed(vm, rest, func, data)
        }
        OpticKind::Custom { get, set } => {
            let getter = VMValue::HeapRef(*get);
            let setter = VMValue::HeapRef(*set);
            let old = vm.apply(getter, &[data])?;
            let new = optic_over_composed(vm, rest, func, old)?;
            vm.apply(setter, &[data, new])
        }
        OpticKind::FalsyKey(key_box_key) => {
            // [!:key] - if map/variant[key] is falsy, recurse with rest; else return unchanged
            let key_box_key = *key_box_key;
            let key = get_key_value(vm, key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            if !val.is_truthy() {
                optic_over_composed(vm, rest, func, data)
            } else {
                Ok(data)
            }
        }
        OpticKind::Compare {
            key: key_box_key,
            op,
            value: compare_val,
        } => {
            // [.key op val] - if comparison passes, recurse with rest; else return unchanged
            let key_box_key = *key_box_key;
            let op = *op;
            let compare_val = *compare_val;
            let key = get_key_value(vm, key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            let result = compare_vm_values(vm, val, compare_val, op);
            if result {
                optic_over_composed(vm, rest, func, data)
            } else {
                Ok(data)
            }
        }
        OpticKind::First(inner_key) => {
            // First as head of a composition: over [First(inner), ...rest] f data
            // Flatten: treat as over_first through inner optic, with rest appended
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            // Decompose inner and append rest to form a single chain for over_first
            let inner_optics = match &inner {
                OpticKind::Compose(ops) => {
                    let mut v: Vec<OpticKind> = ops
                        .iter()
                        .map(|k| match vm.heap().get(*k) {
                            Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                            _ => Err(VMError::TypeError("compose requires optics")),
                        })
                        .collect::<Result<_, _>>()?;
                    v.extend(rest.iter().cloned());
                    v
                }
                other => {
                    let mut v = vec![other.clone()];
                    v.extend(rest.iter().cloned());
                    v
                }
            };
            let (result, _) = optic_over_first_composed(vm, &inner_optics, func, data)?;
            Ok(result)
        }
    }
}

/// Helper for deep optic over composed
fn optic_over_deep_composed(
    vm: &mut VM,
    rest: &[OpticKind],
    func: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    // Deep applies recursively to all nested structures
    // First apply rest optics to current level (if applicable), then recurse into children

    // Try to apply the rest to current data
    let current_result = if rest.is_empty() {
        vm.apply(func, &[data])?
    } else {
        // Try to apply - if it fails due to type mismatch, just use data unchanged at this level
        match optic_over_composed(vm, rest, func, data) {
            Ok(v) => v,
            Err(VMError::TypeError(_)) => data, // type mismatch at this level, keep going
            Err(e) => return Err(e),
        }
    };

    // Now recurse into children based on data type
    match current_result {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let seq_data = seq.data.clone();
                    let seq_kind = seq.kind;
                    let mut new_data = crate::collections::Vector::new();
                    for item in seq_data.iter() {
                        let new_item = optic_over_deep_composed(vm, rest, func, *item)?;
                        new_data.push_back(new_item);
                    }
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq_kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                Some(super::HeapObject::Map(m)) => {
                    let map_data = m.clone();
                    let mut new_map = crate::collections::HashMap::new();
                    for (k, v) in map_data.iter() {
                        let new_v = optic_over_deep_composed(vm, rest, func, *v)?;
                        new_map.insert(*k, new_v);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                Some(super::HeapObject::Variant(inst)) => {
                    let fields_clone = inst.fields.clone();
                    let type_id = inst.type_id();
                    let variant_idx = inst.variant_idx();
                    let mut new_fields = Vec::with_capacity(fields_clone.len());
                    for field in fields_clone.iter() {
                        new_fields.push(optic_over_deep_composed(vm, rest, func, *field)?);
                    }
                    let new_inst =
                        super::heap::VariantInstance::new(type_id, variant_idx, new_fields);
                    Ok(VMValue::HeapRef(vm.heap_mut().intern_variant(new_inst)))
                }
                _ => Ok(current_result), // Not a container, don't recurse
            }
        }
        _ => Ok(current_result), // Primitives, don't recurse
    }
}

fn native_view(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (view optic data)
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let optic = get_optic(vm, args[0])?;
    let data = args[1];
    optic_view(vm, &optic, data)
}

fn native_view_all(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (view-all optic data) -> vector of all foci
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let optic = get_optic(vm, args[0])?;
    let data = args[1];
    let results = optic_view_all(vm, &optic, data)?;

    let data: crate::collections::Vector<VMValue> = results.into_iter().collect();
    let seq = SeqData {
        data,
        kind: SeqKind::Vector,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_over(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (over optic f data)
    if args.len() != 3 {
        return Err(VMError::ArityMismatch {
            expected: 3,
            got: args.len() as u8,
        });
    }
    let optic = get_optic(vm, args[0])?;
    let func = args[1];
    let data = args[2];
    optic_over(vm, &optic, func, data)
}

fn native_set_optic(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (set optic val data) - set is just over with (constantly val)
    if args.len() != 3 {
        return Err(VMError::ArityMismatch {
            expected: 3,
            got: args.len() as u8,
        });
    }
    let optic = get_optic(vm, args[0])?;
    let new_val = args[1];
    let data = args[2];

    // For set, we implement it directly rather than creating a closure
    optic_set(vm, &optic, new_val, data)
}

fn native_optic_compose(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let mut optic_keys = Vec::with_capacity(args.len());
    for arg in args {
        let optic = get_optic(vm, *arg)?;
        let key = alloc_optic(vm, optic)?;
        optic_keys.push(key);
    }
    let composed = OpticKind::Compose(optic_keys.into_boxed_slice());
    let key = alloc_optic(vm, composed)?;
    Ok(VMValue::HeapRef(key))
}

/// Set operation - replace all foci with a value
fn optic_set(
    vm: &mut VM,
    optic: &OpticKind,
    new_val: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    match optic {
        OpticKind::Key(key_box_key) => {
            let key = get_key_value(vm, *key_box_key)?;
            match data {
                VMValue::HeapRef(data_key) => {
                    // Map path - clone is O(1) for imbl
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        let new_map = vm.map_insert(&m, key, new_val);
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let map_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                        return Ok(VMValue::HeapRef(map_key));
                    }
                    // Variant path - no clone needed for lookup, only if we have a match
                    if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            if let Some((_, idx)) = variant_field_lookup(vm, inst, kw) {
                                let inst = inst.clone();
                                return Ok(variant_with_field(vm, &inst, idx, new_val));
                            }
                        }
                        return Ok(data); // no focus → no-op
                    }
                    Err(VMError::TypeError("key optic requires a map or variant"))
                }
                VMValue::Nil => {
                    let empty_map = crate::collections::HashMap::new();
                    let new_map = vm.map_insert(&empty_map, key, new_val);
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let map_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(map_key))
                }
                _ => Err(VMError::TypeError("key optic requires a map or variant")),
            }
        }
        OpticKind::Index(i) => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let idx = if *i < 0 { len + *i } else { *i };
                    if idx < 0 || idx >= len {
                        return Ok(data);
                    }
                    let idx = idx as usize;
                    let new_data = seq.data.update(idx, new_val);
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq.kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("index optic requires a sequence")),
            },
            _ => Err(VMError::TypeError("index optic requires a sequence")),
        },
        OpticKind::Each => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let new_data: crate::collections::Vector<VMValue> =
                        (0..seq.data.len()).map(|_| new_val).collect();
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq.kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("each optic requires a sequence")),
            },
            _ => Err(VMError::TypeError("each optic requires a sequence")),
        },
        OpticKind::Compose(ops) => {
            if ops.is_empty() {
                return Ok(new_val);
            }
            // Get all optics
            let optics: Vec<OpticKind> = ops
                .iter()
                .map(|k| match vm.heap().get(*k) {
                    Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                    _ => Err(VMError::TypeError("compose requires optics")),
                })
                .collect::<Result<_, _>>()?;

            // Recursive set for composition
            optic_set_composed(vm, &optics, new_val, data)
        }
        OpticKind::Custom { set, .. } => {
            // Custom lens: call setter directly (setter takes [data new_val])
            let setter = VMValue::HeapRef(*set);
            vm.apply(setter, &[data, new_val])
        }
        OpticKind::Filtered(pred_key) => {
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) => {
                    match val {
                        VMValue::Keyword(kw) => {
                            // Keyword lookup in data (map or variant)
                            let kw = *kw;
                            let keyword = VMValue::Keyword(kw);
                            match data {
                                VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                                    Some(super::HeapObject::Map(m)) => {
                                        m.get(&keyword).copied().unwrap_or(VMValue::Nil)
                                    }
                                    Some(super::HeapObject::Variant(inst)) => {
                                        variant_field_lookup(vm, inst, kw)
                                            .map(|(v, _)| v)
                                            .unwrap_or(VMValue::Nil)
                                    }
                                    _ => VMValue::Nil,
                                },
                                _ => VMValue::Nil,
                            }
                        }
                        VMValue::NativeFn(_) => vm.apply(*val, &[data])?,
                        _ => VMValue::Nil,
                    }
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(new_val)
            } else {
                Ok(data)
            }
        }
        OpticKind::When(pred_key) => {
            let result = match vm.heap().get(*pred_key) {
                Some(super::HeapObject::KeyBox(val)) if matches!(val, VMValue::NativeFn(_)) => {
                    vm.apply(*val, &[data])?
                }
                _ => {
                    let pred = VMValue::HeapRef(*pred_key);
                    vm.apply(pred, &[data])?
                }
            };
            if result.is_truthy() {
                Ok(new_val)
            } else {
                Ok(data)
            }
        }
        OpticKind::FalsyKey(key_box_key) => {
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            if !val.is_truthy() {
                Ok(new_val)
            } else {
                Ok(data)
            }
        }
        OpticKind::Compare {
            key: key_box_key,
            op,
            value: compare_val,
        } => {
            let key = get_key_value(vm, *key_box_key)?;
            let val = match data {
                VMValue::HeapRef(data_key) => {
                    if let Some(super::HeapObject::Map(m)) = vm.heap().get(data_key) {
                        let m = m.clone();
                        vm.map_get(&m, key).unwrap_or(VMValue::Nil)
                    } else if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(data_key) {
                        if let VMValue::Keyword(kw) = key {
                            variant_field_lookup(vm, inst, kw)
                                .map(|(v, _)| v)
                                .unwrap_or(VMValue::Nil)
                        } else {
                            VMValue::Nil
                        }
                    } else {
                        VMValue::Nil
                    }
                }
                _ => VMValue::Nil,
            };
            if compare_vm_values(vm, val, *compare_val, *op) {
                Ok(new_val)
            } else {
                Ok(data)
            }
        }
        OpticKind::Deep => {
            // Set every node in tree to new_val (lawful but rarely useful standalone)
            optic_set_deep(vm, new_val, data)
        }
        OpticKind::Vals => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Map(m)) => {
                    let mut new_map = crate::collections::HashMap::new();
                    for (k, _) in m.clone().iter() {
                        new_map.insert(*k, new_val);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("vals optic requires a map")),
            },
            _ => Err(VMError::TypeError("vals optic requires a map")),
        },
        OpticKind::Some => {
            if data == VMValue::Nil {
                Ok(VMValue::Nil)
            } else {
                Ok(new_val)
            }
        }
        OpticKind::Slice { from, to } => match data {
            VMValue::HeapRef(data_key) => match vm.heap().get(data_key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let len = seq.data.len() as i64;
                    let start = normalize_slice_bound(*from, len, 0);
                    let end = normalize_slice_bound(*to, len, len as usize).min(seq.data.len());
                    let mut new_data = seq.data.clone();
                    for i in start..end {
                        new_data = new_data.update(i, new_val);
                    }
                    let new_seq = SeqData {
                        data: new_data,
                        kind: seq.kind,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(key))
                }
                _ => Err(VMError::TypeError("slice optic requires a sequence")),
            },
            _ => Err(VMError::TypeError("slice optic requires a sequence")),
        },
        OpticKind::Keys => Err(VMError::TypeError("set not supported for keys optic")),
        OpticKind::First(inner_key) => {
            let inner = match vm.heap().get(*inner_key) {
                Some(super::HeapObject::Optic(k)) => k.clone(),
                _ => return Err(VMError::TypeError("first requires an optic")),
            };
            // Decompose inner and use single-pass set
            let inner_optics = match &inner {
                OpticKind::Compose(ops) => ops
                    .iter()
                    .map(|k| match vm.heap().get(*k) {
                        Some(super::HeapObject::Optic(op)) => Ok(op.clone()),
                        _ => Err(VMError::TypeError("compose requires optics")),
                    })
                    .collect::<Result<Vec<_>, _>>()?,
                other => vec![other.clone()],
            };
            let (result, _) = optic_set_first_composed(vm, &inner_optics, new_val, data)?;
            Ok(result)
        }
    }
}

/// Set every node in a deep tree to new_val
fn optic_set_deep(vm: &mut VM, new_val: VMValue, data: VMValue) -> Result<VMValue, VMError> {
    match data {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let seq_kind = seq.kind;
                let len = seq.data.len();
                let new_data: crate::collections::Vector<VMValue> =
                    (0..len).map(|_| new_val).collect();
                let new_seq = SeqData {
                    data: new_data,
                    kind: seq_kind,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            Some(super::HeapObject::Map(m)) => {
                let map_data = m.clone();
                let mut new_map = crate::collections::HashMap::new();
                for (k, _) in map_data.iter() {
                    new_map.insert(*k, new_val);
                }
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            _ => Ok(new_val),
        },
        _ => Ok(new_val),
    }
}

/// Set through composed optics
fn optic_set_composed(
    vm: &mut VM,
    optics: &[OpticKind],
    new_val: VMValue,
    data: VMValue,
) -> Result<VMValue, VMError> {
    if optics.is_empty() {
        return Ok(new_val);
    }
    if optics.len() == 1 {
        return optic_set(vm, &optics[0], new_val, data);
    }

    // For set [a b c] v data: set a (set [b c] v (view a data)) data
    let first = &optics[0];
    let rest = &optics[1..];

    // View through first optic to get nested structure
    let nested = optic_view(vm, first, data)?;
    // Recursively set in the nested structure
    let new_nested = optic_set_composed(vm, rest, new_val, nested)?;
    // Set the new nested structure back
    optic_set(vm, first, new_nested, data)
}

// --- Optic constructors ---

fn native_optic_compose_rev(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (<* a b c) = (*> c b a) - right-to-left composition
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let mut reversed: Vec<VMValue> = args.to_vec();
    reversed.reverse();
    let mut optic_keys = Vec::with_capacity(reversed.len());
    for arg in reversed {
        let optic = get_optic(vm, arg)?;
        let key = alloc_optic(vm, optic)?;
        optic_keys.push(key);
    }
    let composed = OpticKind::Compose(optic_keys.into_boxed_slice());
    let key = alloc_optic(vm, composed)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_idx(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (_idx n) - index optic
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let idx = match args[0] {
        VMValue::Int(i) => i,
        _ => return Err(VMError::TypeError("_idx requires an integer")),
    };
    let optic = OpticKind::Index(idx);
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_filtered(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (filtered pred) - predicate filter traversal
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let pred = args[0];
    // Get the HeapKey for the predicate
    let pred_key = match pred {
        VMValue::HeapRef(key) => key,
        // For keywords, store in KeyBox for lookup
        VMValue::Keyword(_) => {
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            vm.heap_mut().alloc(super::HeapObject::KeyBox(pred), roots)
        }
        // For native functions, also store in KeyBox
        VMValue::NativeFn(_) => {
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            vm.heap_mut().alloc(super::HeapObject::KeyBox(pred), roots)
        }
        _ => {
            return Err(VMError::TypeError(
                "filtered requires a predicate function or keyword",
            ));
        }
    };
    let optic = OpticKind::Filtered(pred_key);
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_slice(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (_slice start end) - subsequence traversal
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let from = match args[0] {
        VMValue::Int(i) => Some(i),
        VMValue::Nil => None,
        _ => return Err(VMError::TypeError("_slice start must be integer or nil")),
    };
    let to = match args[1] {
        VMValue::Int(i) => Some(i),
        VMValue::Nil => None,
        _ => return Err(VMError::TypeError("_slice end must be integer or nil")),
    };
    let optic = OpticKind::Slice { from, to };
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_when(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (_when pred) - conditional identity lens
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let pred = args[0];
    let pred_key = match pred {
        VMValue::HeapRef(key) => key,
        // For native functions, store in KeyBox
        VMValue::NativeFn(_) => {
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            vm.heap_mut().alloc(super::HeapObject::KeyBox(pred), roots)
        }
        _ => return Err(VMError::TypeError("_when requires a predicate function")),
    };
    let optic = OpticKind::When(pred_key);
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_first(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (_first optic) - wrap a traversal into an affine (first-match-only)
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let inner = get_optic(vm, args[0])?;
    let inner_key = alloc_optic(vm, inner)?;
    let optic = OpticKind::First(inner_key);
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_optic_lens(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (lens getter setter) - custom lens constructor
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let getter = args[0];
    let setter = args[1];
    let get_key = match getter {
        VMValue::HeapRef(key) => key,
        _ => return Err(VMError::TypeError("lens getter must be a function")),
    };
    let set_key = match setter {
        VMValue::HeapRef(key) => key,
        _ => return Err(VMError::TypeError("lens setter must be a function")),
    };
    let optic = OpticKind::Custom {
        get: get_key,
        set: set_key,
    };
    let key = alloc_optic(vm, optic)?;
    Ok(VMValue::HeapRef(key))
}

fn native_xpath(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (xpath "/path/to/value") - parse XPath string into optic at runtime
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let path_str = match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(s)) => s.to_string(),
            _ => return Err(VMError::TypeError("xpath requires a string")),
        },
        _ => return Err(VMError::TypeError("xpath requires a string")),
    };

    // Use VM-specific XPath parser
    let vm_optic = parse_xpath_for_vm(vm, &path_str)?;
    let key = alloc_optic(vm, vm_optic)?;
    Ok(VMValue::HeapRef(key))
}

// ============================================================================
// VM-specific XPath Parser
// ============================================================================

/// Parse XPath string directly into VM OpticKind (no tree-walker dependency)
fn parse_xpath_for_vm(vm: &mut VM, input: &str) -> Result<OpticKind, VMError> {
    let mut parser = VmXPathParser::new(input);
    parser.parse(vm)
}

struct VmXPathParser<'a> {
    input: &'a str,
    pos: usize,
}

impl<'a> VmXPathParser<'a> {
    fn new(input: &'a str) -> Self {
        Self { input, pos: 0 }
    }

    fn peek(&self) -> Option<char> {
        self.input[self.pos..].chars().next()
    }

    fn advance(&mut self) {
        if let Some(c) = self.peek() {
            self.pos += c.len_utf8();
        }
    }

    fn skip_whitespace(&mut self) {
        while self.peek().is_some_and(|c| c.is_whitespace()) {
            self.advance();
        }
    }

    fn parse(&mut self, vm: &mut VM) -> Result<OpticKind, VMError> {
        self.skip_whitespace();

        // Must start with /
        if self.peek() != Some('/') {
            return Err(VMError::ValueError("xpath must start with /".into()));
        }
        self.advance();

        // Root only case: "/"
        if self.peek().is_none() {
            // Identity optic - just return the data unchanged
            return Ok(OpticKind::Compose(Box::new([])));
        }

        let mut segments = Vec::new();

        loop {
            self.skip_whitespace();

            // Check for ** (recursive descent)
            if self.peek() == Some('*') {
                let start = self.pos;
                self.advance();
                if self.peek() == Some('*') {
                    self.advance();
                    segments.push(OpticKind::Deep);
                } else {
                    // Single * (each)
                    self.pos = start;
                    let seg = self.parse_segment(vm)?;
                    segments.push(seg);
                }
            } else if self.peek().is_some() && self.peek() != Some('/') {
                let seg = self.parse_segment(vm)?;
                segments.push(seg);
            }

            self.skip_whitespace();

            // Check for next segment
            if self.peek() == Some('/') {
                self.advance();
                if self.peek().is_none() {
                    break;
                }
            } else {
                break;
            }
        }

        if segments.is_empty() {
            Ok(OpticKind::Compose(Box::new([])))
        } else if segments.len() == 1 {
            Ok(segments.pop().unwrap())
        } else {
            // Compose multiple segments
            let mut optic_keys = Vec::with_capacity(segments.len());
            for seg in segments {
                let key = alloc_optic(vm, seg)?;
                optic_keys.push(key);
            }
            Ok(OpticKind::Compose(optic_keys.into_boxed_slice()))
        }
    }

    fn parse_segment(&mut self, vm: &mut VM) -> Result<OpticKind, VMError> {
        self.skip_whitespace();

        match self.peek() {
            Some('*') => {
                self.advance();
                // Check for predicate
                if self.peek() == Some('[') {
                    let pred = self.parse_predicate(vm)?;
                    // Compose each + predicate
                    let each_key = alloc_optic(vm, OpticKind::Each)?;
                    let pred_key = alloc_optic(vm, pred)?;
                    Ok(OpticKind::Compose(Box::new([each_key, pred_key])))
                } else {
                    Ok(OpticKind::Each)
                }
            }
            Some('@') => {
                self.advance();
                if self.input[self.pos..].starts_with("keys") {
                    self.pos += 4;
                    Ok(OpticKind::Keys)
                } else {
                    Ok(OpticKind::Vals)
                }
            }
            Some(c) if c.is_ascii_digit() || c == '-' => self.parse_index_or_slice(vm),
            Some(':') => {
                // Slice starting with :n
                self.parse_index_or_slice(vm)
            }
            Some('#') => {
                // #ident=value → DEEP + Compare (by :ident value)
                self.advance();
                let ident = self.parse_identifier();
                if self.peek() != Some('=') {
                    return Err(VMError::ValueError(
                        "expected '=' after #identifier in xpath".into(),
                    ));
                }
                self.advance();
                let value = self.parse_literal(vm)?;
                let kw_spur = vm.interner.get_or_intern(&ident);
                let vm_kw = VMValue::Keyword(kw_spur);
                let key_box = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(vm_kw),
                    Vec::<super::value::HeapKey>::new(),
                );
                let deep_key = alloc_optic(vm, OpticKind::Deep)?;
                let compare_key = alloc_optic(
                    vm,
                    OpticKind::Compare {
                        key: key_box,
                        op: super::heap::CompareOp::Eq,
                        value,
                    },
                )?;
                let inner = OpticKind::Compose(Box::new([deep_key, compare_key]));
                let inner_key = alloc_optic(vm, inner)?;
                Ok(OpticKind::First(inner_key))
            }
            Some(_) => {
                // Key name
                let name = self.parse_identifier();
                let kw_spur = vm.interner.get_or_intern(&name);
                let vm_kw = VMValue::Keyword(kw_spur);
                let key_box = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(vm_kw),
                    Vec::<super::value::HeapKey>::new(),
                );

                // Check for predicate after key
                if self.peek() == Some('[') {
                    let pred = self.parse_predicate(vm)?;
                    let key_optic = alloc_optic(vm, OpticKind::Key(key_box))?;
                    let pred_key = alloc_optic(vm, pred)?;
                    Ok(OpticKind::Compose(Box::new([key_optic, pred_key])))
                } else {
                    Ok(OpticKind::Key(key_box))
                }
            }
            None => Err(VMError::ValueError("unexpected end of xpath".into())),
        }
    }

    fn parse_identifier(&mut self) -> String {
        let start = self.pos;
        while self
            .peek()
            .is_some_and(|c| c.is_alphanumeric() || c == '_' || c == '-' || c == '?')
        {
            self.advance();
        }
        self.input[start..self.pos].to_string()
    }

    fn parse_index_or_slice(&mut self, vm: &mut VM) -> Result<OpticKind, VMError> {
        // Could be: 0, -1, 0:3, :3, 3:, -2:
        let start_num = self.parse_optional_number();

        if self.peek() == Some(':') {
            self.advance();
            let end_num = self.parse_optional_number();

            // Check for predicate
            if self.peek() == Some('[') {
                let pred = self.parse_predicate(vm)?;
                let slice_key = alloc_optic(
                    vm,
                    OpticKind::Slice {
                        from: start_num,
                        to: end_num,
                    },
                )?;
                let pred_key = alloc_optic(vm, pred)?;
                Ok(OpticKind::Compose(Box::new([slice_key, pred_key])))
            } else {
                Ok(OpticKind::Slice {
                    from: start_num,
                    to: end_num,
                })
            }
        } else if let Some(idx) = start_num {
            // Check for predicate
            if self.peek() == Some('[') {
                let pred = self.parse_predicate(vm)?;
                let idx_key = alloc_optic(vm, OpticKind::Index(idx))?;
                let pred_key = alloc_optic(vm, pred)?;
                Ok(OpticKind::Compose(Box::new([idx_key, pred_key])))
            } else {
                Ok(OpticKind::Index(idx))
            }
        } else {
            Err(VMError::ValueError("expected number in xpath".into()))
        }
    }

    fn parse_optional_number(&mut self) -> Option<i64> {
        let start = self.pos;
        if self.peek() == Some('-') {
            self.advance();
        }
        while self.peek().is_some_and(|c| c.is_ascii_digit()) {
            self.advance();
        }
        if self.pos > start {
            self.input[start..self.pos].parse().ok()
        } else {
            None
        }
    }

    fn parse_predicate(&mut self, vm: &mut VM) -> Result<OpticKind, VMError> {
        // Consume [
        if self.peek() != Some('[') {
            return Err(VMError::ValueError("expected [ in predicate".into()));
        }
        self.advance();
        self.skip_whitespace();

        let result = match self.peek() {
            // [:key] - truthy check
            Some(':') => {
                self.advance();
                let key = self.parse_identifier();
                let kw_spur = vm.interner.get_or_intern(&key);
                let vm_kw = VMValue::Keyword(kw_spur);
                let key_box = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(vm_kw),
                    Vec::<super::value::HeapKey>::new(),
                );
                Ok(OpticKind::Filtered(key_box))
            }
            // [!:key] - falsy check
            Some('!') => {
                self.advance();
                if self.peek() != Some(':') {
                    return Err(VMError::ValueError(
                        "expected : after ! in predicate".into(),
                    ));
                }
                self.advance();
                let key = self.parse_identifier();
                let kw_spur = vm.interner.get_or_intern(&key);
                let vm_kw = VMValue::Keyword(kw_spur);
                let key_box = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(vm_kw),
                    Vec::<super::value::HeapKey>::new(),
                );
                Ok(OpticKind::FalsyKey(key_box))
            }
            // [.key op val] - comparison
            Some('.') => {
                self.advance();
                let key = self.parse_identifier();
                self.skip_whitespace();
                let op = self.parse_compare_op()?;
                self.skip_whitespace();
                let value = self.parse_literal(vm)?;

                let kw_spur = vm.interner.get_or_intern(&key);
                let vm_kw = VMValue::Keyword(kw_spur);
                let key_box = vm.heap_mut().alloc(
                    super::HeapObject::KeyBox(vm_kw),
                    Vec::<super::value::HeapKey>::new(),
                );
                Ok(OpticKind::Compare {
                    key: key_box,
                    op,
                    value,
                })
            }
            _ => Err(VMError::ValueError("unsupported predicate syntax".into())),
        };

        self.skip_whitespace();
        if self.peek() != Some(']') {
            return Err(VMError::ValueError("expected ] after predicate".into()));
        }
        self.advance();

        result
    }

    fn parse_compare_op(&mut self) -> Result<super::heap::CompareOp, VMError> {
        use super::heap::CompareOp;

        match self.peek() {
            Some('>') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Gte)
                } else {
                    Ok(CompareOp::Gt)
                }
            }
            Some('<') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Lte)
                } else {
                    Ok(CompareOp::Lt)
                }
            }
            Some('=') => {
                self.advance();
                Ok(CompareOp::Eq)
            }
            Some('!') => {
                self.advance();
                if self.peek() == Some('=') {
                    self.advance();
                    Ok(CompareOp::Neq)
                } else {
                    Err(VMError::ValueError("expected = after !".into()))
                }
            }
            _ => Err(VMError::ValueError("expected comparison operator".into())),
        }
    }

    fn parse_literal(&mut self, vm: &mut VM) -> Result<VMValue, VMError> {
        match self.peek() {
            Some('"') => {
                self.advance();
                let start = self.pos;
                while self.peek().is_some_and(|c| c != '"') {
                    self.advance();
                }
                let s = &self.input[start..self.pos];
                self.advance(); // consume closing "
                Ok(vm.alloc_string(s))
            }
            Some(c) if c.is_ascii_digit() || c == '-' => {
                let start = self.pos;
                if self.peek() == Some('-') {
                    self.advance();
                }
                while self.peek().is_some_and(|c| c.is_ascii_digit()) {
                    self.advance();
                }
                // Check for float
                if self.peek() == Some('.') {
                    self.advance();
                    while self.peek().is_some_and(|c| c.is_ascii_digit()) {
                        self.advance();
                    }
                    let f: f64 = self.input[start..self.pos]
                        .parse()
                        .map_err(|_| VMError::ValueError("invalid float".into()))?;
                    Ok(VMValue::Float(f))
                } else {
                    let i: i64 = self.input[start..self.pos]
                        .parse()
                        .map_err(|_| VMError::ValueError("invalid integer".into()))?;
                    Ok(VMValue::Int(i))
                }
            }
            Some(c) if c.is_alphabetic() || c == '_' => {
                // Bare identifier treated as string literal
                let s = self.parse_identifier();
                Ok(vm.alloc_string(&s))
            }
            _ => Err(VMError::ValueError("expected literal value".into())),
        }
    }
}

/// Convert tree-walker Optic to VM OpticKind
fn convert_optic_to_vm(vm: &mut VM, optic: &crate::optic::Optic) -> Result<OpticKind, VMError> {
    use crate::optic::Optic;

    match optic {
        Optic::Key(value) => {
            // Convert Value to VMValue and box it
            let vm_val = value_to_vmvalue(vm, value)?;
            let key = vm.heap_mut().alloc(
                super::HeapObject::KeyBox(vm_val),
                Vec::<super::value::HeapKey>::new(),
            );
            Ok(OpticKind::Key(key))
        }
        Optic::Index(i) => Ok(OpticKind::Index(*i)),
        Optic::Compose(children) => {
            let mut optic_keys = Vec::with_capacity(children.len());
            for child in children.iter() {
                let child_optic = convert_optic_to_vm(vm, child)?;
                let key = alloc_optic(vm, child_optic)?;
                optic_keys.push(key);
            }
            Ok(OpticKind::Compose(optic_keys.into_boxed_slice()))
        }
        Optic::Each => Ok(OpticKind::Each),
        Optic::Vals => Ok(OpticKind::Vals),
        Optic::Keys => Ok(OpticKind::Keys),
        Optic::Deep => Ok(OpticKind::Deep),
        Optic::Some => Ok(OpticKind::Some),
        Optic::Slice { from, to } => Ok(OpticKind::Slice {
            from: *from,
            to: *to,
        }),
        Optic::Filtered(pred) => {
            // Handle different XPath predicate types
            match pred.as_ref() {
                // [:key] - keyword predicate (truthy check)
                crate::Value::Keyword(kw) => {
                    // Convert keyword to VM keyword
                    let kw_spur = vm.interner.get_or_intern(&kw.name);
                    let vm_kw = VMValue::Keyword(kw_spur);
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let key_box = vm.heap_mut().alloc(super::HeapObject::KeyBox(vm_kw), roots);
                    Ok(OpticKind::Filtered(key_box))
                }
                // [!:key] - falsy check (created by make_not_key_fn)
                crate::Value::NativeFn {
                    name: "not-key", ..
                } => {
                    // We need to extract the keyword from the closure
                    // For now, create a placeholder - this requires parsing the closure
                    Err(VMError::TypeError(
                        "falsy key predicates [!:key] not yet supported in VM xpath",
                    ))
                }
                // [.key op val] - comparison (created by make_compare_fn)
                crate::Value::NativeFn {
                    name: "compare", ..
                } => {
                    // We need to extract key, op, value from the closure
                    // For now, create a placeholder
                    Err(VMError::TypeError(
                        "comparison predicates [.key op val] not yet supported in VM xpath",
                    ))
                }
                // [pred?] - symbol reference
                crate::Value::Symbol(sym) => {
                    // Look up the symbol in globals
                    let sym_spur = vm.interner.get_or_intern(&sym.name);
                    if let Some(val) = vm.get_global(sym_spur) {
                        let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                        let key_box = vm.heap_mut().alloc(super::HeapObject::KeyBox(val), roots);
                        Ok(OpticKind::Filtered(key_box))
                    } else {
                        Err(VMError::UndefinedGlobal(sym.name.to_string()))
                    }
                }
                _ => Err(VMError::TypeError(
                    "unsupported filtered predicate in xpath",
                )),
            }
        }
        Optic::When(_) => Err(VMError::TypeError("when optics not supported in xpath")),
        Optic::Custom { .. } => Err(VMError::TypeError("custom optics not supported in xpath")),
    }
}

// --- Higher-order functions ---

fn native_hof_map(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Args are kept on VM stack during native execution, so func and coll are rooted
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let func = args[0];
    let coll = args[1];

    // Get the sequence data and kind
    let (seq_data, seq_kind) = match coll {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => (seq.data.clone(), seq.kind),
            _ => return Err(VMError::TypeError("map requires a sequence")),
        },
        VMValue::Nil => (crate::collections::Vector::new(), SeqKind::List),
        _ => return Err(VMError::TypeError("map requires a sequence")),
    };

    let mut results = Vec::with_capacity(seq_data.len());
    // Inhibit GC during the loop: intermediate results in `results` are
    // invisible to the collector (they live in Rust-land, not on the VM stack).
    // Without this, a GC triggered by vm.apply() can collect them.
    vm.heap_mut().inhibit_gc();
    for elem in seq_data.iter() {
        let result = vm.apply(func, &[*elem])?;
        results.push(result);
    }
    vm.heap_mut().allow_gc();

    // Preserve input sequence kind
    let data: crate::collections::Vector<VMValue> = results.into_iter().collect();
    let new_seq = SeqData {
        data,
        kind: seq_kind,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_filter(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Args are kept on VM stack during native execution, so pred and coll are rooted
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let pred = args[0];
    let coll = args[1];

    // Get the sequence data and kind
    let (seq_data, seq_kind) = match coll {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => (seq.data.clone(), seq.kind),
            _ => return Err(VMError::TypeError("filter requires a sequence")),
        },
        VMValue::Nil => (crate::collections::Vector::new(), SeqKind::List),
        _ => return Err(VMError::TypeError("filter requires a sequence")),
    };

    let mut results = Vec::new();
    // Inhibit GC: intermediate results in `results` are not GC roots.
    vm.heap_mut().inhibit_gc();
    for elem in seq_data.iter() {
        let keep = vm.apply(pred, &[*elem])?;
        if keep.is_truthy() {
            results.push(*elem);
        }
    }
    vm.heap_mut().allow_gc();

    // Preserve input sequence kind
    let data: crate::collections::Vector<VMValue> = results.into_iter().collect();
    let new_seq = SeqData {
        data,
        kind: seq_kind,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_reduce(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Args are kept on VM stack during native execution, so func and coll are rooted
    // (reduce f coll) or (reduce f init coll)

    // Helper to convert collection to seq of values
    // For maps, convert to seq of [k v] vectors
    fn coll_to_seq(
        vm: &mut VM,
        coll: VMValue,
    ) -> Result<Option<crate::collections::Vector<VMValue>>, VMError> {
        match coll {
            VMValue::HeapRef(key) => {
                match vm.heap().get(key) {
                    Some(super::HeapObject::Seq(seq)) => Ok(Some(seq.data.clone())),
                    Some(super::HeapObject::Map(map)) => {
                        // Convert map to seq of [k v] vectors
                        let pairs: Vec<(VMValue, VMValue)> =
                            map.iter().map(|(k, v)| (*k, *v)).collect();
                        let mut result = crate::collections::Vector::new();
                        // Inhibit GC: kv_key refs in result are not GC roots.
                        vm.heap_mut().inhibit_gc();
                        for (k, v) in pairs {
                            let kv_data: crate::collections::Vector<VMValue> =
                                vec![k, v].into_iter().collect();
                            let kv_seq = SeqData {
                                data: kv_data,
                                kind: SeqKind::Vector,
                            };
                            let roots: Vec<super::HeapKey> = std::iter::empty().collect();
                            let kv_key = vm.heap_mut().alloc(super::HeapObject::Seq(kv_seq), roots);
                            result.push_back(VMValue::HeapRef(kv_key));
                        }
                        vm.heap_mut().allow_gc();
                        Ok(Some(result))
                    }
                    Some(super::HeapObject::Set(set)) => {
                        let items: crate::collections::Vector<VMValue> =
                            set.iter().copied().collect();
                        Ok(Some(items))
                    }
                    _ => Err(VMError::TypeError("reduce requires a sequence")),
                }
            }
            VMValue::Nil => Ok(None),
            _ => Err(VMError::TypeError("reduce requires a sequence")),
        }
    }

    let (func, init, seq_data) = match args.len() {
        2 => {
            let coll = args[1];
            let seq_data = match coll_to_seq(vm, coll)? {
                Some(data) => data,
                None => return vm.apply(args[0], &[]),
            };
            if seq_data.is_empty() {
                return vm.apply(args[0], &[]);
            }
            let first = seq_data[0];
            let rest: crate::collections::Vector<VMValue> =
                seq_data.iter().skip(1).copied().collect();
            (args[0], first, rest)
        }
        3 => {
            let coll = args[2];
            let seq_data = coll_to_seq(vm, coll)?.unwrap_or_else(crate::collections::Vector::new);
            (args[0], args[1], seq_data)
        }
        _ => {
            return Err(VMError::ArityMismatch {
                expected: 2,
                got: args.len() as u8,
            });
        }
    };

    let mut acc = init;
    let reduced_tag = vm.reduced_tag;
    // Inhibit GC: `acc` is not a GC root and could be collected mid-loop.
    vm.heap_mut().inhibit_gc();
    for elem in seq_data.iter() {
        acc = vm.apply(func, &[acc, *elem])?;
        // Check for (Reduced val) early termination
        if let Some(tag) = reduced_tag {
            if let VMValue::HeapRef(key) = acc {
                if let Some(super::HeapObject::Variant(inst)) = vm.heap().get(key) {
                    if inst.tag == tag {
                        acc = inst.fields[0];
                        break;
                    }
                }
            }
        }
    }
    vm.heap_mut().allow_gc();

    Ok(acc)
}

fn native_take(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Args are kept on VM stack during native execution
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let n = match args[0] {
        VMValue::Int(i) if i >= 0 => i as usize,
        VMValue::Int(_) => 0,
        _ => return Err(VMError::TypeError("take requires integer count")),
    };

    let (seq_data, seq_kind) = match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => (seq.data.clone(), seq.kind),
            _ => return Err(VMError::TypeError("take requires a sequence")),
        },
        VMValue::Nil => (crate::collections::Vector::new(), SeqKind::List),
        _ => return Err(VMError::TypeError("take requires a sequence")),
    };

    let taken: crate::collections::Vector<VMValue> = seq_data.iter().take(n).copied().collect();
    let new_seq = SeqData {
        data: taken,
        kind: seq_kind,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_drop(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Args are kept on VM stack during native execution
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let n = match args[0] {
        VMValue::Int(i) if i >= 0 => i as usize,
        VMValue::Int(_) => 0,
        _ => return Err(VMError::TypeError("drop requires integer count")),
    };

    let (seq_data, seq_kind) = match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => (seq.data.clone(), seq.kind),
            Some(super::HeapObject::String(s)) => {
                let char_strs: Vec<String> = s.chars().skip(n).map(|c| c.to_string()).collect();
                let chars: Vec<VMValue> = char_strs.iter().map(|cs| vm.alloc_string(cs)).collect();
                let data: crate::collections::Vector<VMValue> = chars.into_iter().collect();
                (data, SeqKind::List)
            }
            _ => return Err(VMError::TypeError("drop requires a sequence")),
        },
        VMValue::Nil => (crate::collections::Vector::new(), SeqKind::List),
        _ => return Err(VMError::TypeError("drop requires a sequence")),
    };

    let dropped: crate::collections::Vector<VMValue> = seq_data.iter().skip(n).copied().collect();
    let new_seq = SeqData {
        data: dropped,
        kind: seq_kind,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
    Ok(VMValue::HeapRef(key))
}

// --- String operations ---

fn native_split(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // GC is inhibited during native execution, so we can allocate freely
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let s = get_string(vm, args[0])?;
    let delim = get_string(vm, args[1])?;

    let part_strs: Vec<&str> = s.split(delim.as_str()).collect();
    let parts: Vec<VMValue> = part_strs
        .iter()
        .map(|part| vm.alloc_string(*part))
        .collect();

    let data: crate::collections::Vector<VMValue> = parts.into_iter().collect();
    let new_seq = SeqData {
        data,
        kind: SeqKind::Vector,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_join(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let sep = get_string(vm, args[0])?;

    let seq_data = match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.clone(),
            _ => return Err(VMError::TypeError("join requires a sequence")),
        },
        VMValue::Nil => crate::collections::Vector::new(),
        _ => return Err(VMError::TypeError("join requires a sequence")),
    };

    let strings: Vec<String> = seq_data.iter().map(|v| value_to_string(vm, *v)).collect();

    let result = strings.join(&sep);
    Ok(vm.alloc_string(&result))
}

fn native_upper_case(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let s = get_string(vm, args[0])?;
    Ok(vm.alloc_string(&s.to_uppercase()))
}

fn native_lower_case(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let s = get_string(vm, args[0])?;
    Ok(vm.alloc_string(&s.to_lowercase()))
}

// --- IO ---

#[cfg(not(target_arch = "wasm32"))]
fn native_println(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let output: Vec<String> = args.iter().map(|a| value_to_string(vm, *a)).collect();
    println!("{}", output.join(" "));
    Ok(VMValue::Nil)
}

#[cfg(target_arch = "wasm32")]
fn native_println(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    // No-op on WASM - use console effect for I/O
    Ok(VMValue::Nil)
}

#[cfg(not(target_arch = "wasm32"))]
fn native_print(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let output: Vec<String> = args.iter().map(|a| value_to_string(vm, *a)).collect();
    print!("{}", output.join(" "));
    Ok(VMValue::Nil)
}

#[cfg(target_arch = "wasm32")]
fn native_print(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    // No-op on WASM - use console effect for I/O
    Ok(VMValue::Nil)
}

// --- Compiler intrinsics ---

fn intrinsic_subvec(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // (subvec coll start) or (subvec coll start end)
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let start = match args[1] {
        VMValue::Int(i) => i as usize,
        _ => return Err(VMError::TypeError("start must be integer")),
    };

    match args[0] {
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let end = if args.len() > 2 {
                        match args[2] {
                            VMValue::Int(i) => i as usize,
                            _ => return Err(VMError::TypeError("end must be integer")),
                        }
                    } else {
                        seq.data.len()
                    };

                    let start = start.min(seq.data.len());
                    let end = end.min(seq.data.len());
                    let data: crate::collections::Vector<VMValue> = if start >= end {
                        crate::collections::Vector::new()
                    } else {
                        seq.data
                            .iter()
                            .skip(start)
                            .take(end - start)
                            .copied()
                            .collect()
                    };

                    // subvec always returns Vector (for efficient destructuring)
                    let new_seq = SeqData {
                        data,
                        kind: SeqKind::Vector,
                    };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                _ => Err(VMError::TypeError("subvec requires a sequence")),
            }
        }
        VMValue::Nil => {
            // Return empty vector for nil
            let seq = SeqData {
                data: crate::collections::Vector::new(),
                kind: SeqKind::Vector,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(key))
        }
        _ => Err(VMError::TypeError("subvec requires a sequence")),
    }
}

fn intrinsic_throw_arity(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let expected = args.first().and_then(|v| v.as_int()).unwrap_or(0);
    let got = args.get(1).and_then(|v| v.as_int()).unwrap_or(0);
    Err(VMError::ArityMismatch {
        expected: expected as u8,
        got: got as u8,
    })
}

// --- Effects ---

use super::heap::Effect;

/// Create a new effect with a unique ID
/// Args: ops_vector - vector of [symbol, int] pairs describing operations
fn native_make_effect(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    // Parse the ops vector: [[op_name, arity], ...]
    let ops_vec = match args[0] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => &seq.data,
            _ => return Err(VMError::TypeError("expected ops vector")),
        },
        _ => return Err(VMError::TypeError("expected ops vector")),
    };

    // Parse pairs into (Spur, u8)
    let mut ops: Vec<(Spur, u8)> = Vec::new();
    let mut i = 0;
    while i + 1 < ops_vec.len() {
        let name = match ops_vec[i] {
            VMValue::Symbol(s) => s,
            _ => return Err(VMError::TypeError("operation name must be a symbol")),
        };
        let arity = match ops_vec[i + 1] {
            VMValue::Int(n) => n as u8,
            _ => return Err(VMError::TypeError("operation arity must be an integer")),
        };
        ops.push((name, arity));
        i += 2;
    }

    // Generate fresh effect ID
    let effect_id = vm.fresh_effect_id();

    // Create Effect on heap
    let effect = Effect {
        id: effect_id,
        name: None,
        ops: ops.into_boxed_slice(),
    };

    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm
        .heap_mut()
        .alloc(super::HeapObject::Effect(effect), roots);
    Ok(VMValue::HeapRef(key))
}

/// Check if a value is an effect
fn native_effect_pred(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let is_effect = match args[0] {
        VMValue::HeapRef(key) => {
            matches!(vm.heap().get(key), Some(super::HeapObject::Effect(_)))
        }
        _ => false,
    };

    Ok(VMValue::Bool(is_effect))
}

// --- Macro support natives ---

/// Construct a list from arguments: (list 1 2 3) => '(1 2 3)
fn native_list_constructor(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let data: crate::collections::Vector<VMValue> = args.iter().copied().collect();
    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

/// Assert failure - raises a runtime error
fn native_assert_failed(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let msg = if args.is_empty() {
        "assertion failed".to_string()
    } else {
        match args[0] {
            VMValue::HeapRef(key) => match _vm.heap().get(key) {
                Some(super::HeapObject::String(s)) => s.to_string(),
                _ => format!("{:?}", args[0]),
            },
            _ => format!("{:?}", args[0]),
        }
    };
    Err(VMError::AssertionFailed(msg))
}

/// Create a symbol from a string: (symbol "foo") => 'foo
fn native_symbol_constructor(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let name = get_string(vm, args[0])?;
    let spur = vm.interner_mut().get_or_intern(&name);
    Ok(VMValue::Symbol(spur))
}

/// Create a keyword from a string: (keyword "foo") => :foo
fn native_keyword_constructor(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let name = get_string(vm, args[0])?;
    let spur = vm.interner_mut().get_or_intern(&name);
    Ok(VMValue::Keyword(spur))
}

/// Get the name part of a symbol or keyword: (name 'foo) => "foo", (name :a/b) => "b"
fn native_name(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    match args[0] {
        VMValue::Symbol(spur) | VMValue::Keyword(spur) => {
            let full_name = vm.interner().resolve(&spur).to_string();
            // Special case: "/" is its own name (no namespace)
            if full_name == "/" {
                return Ok(vm.alloc_string("/"));
            }
            let name_part = full_name
                .rsplit_once('/')
                .map(|(_, n)| n)
                .unwrap_or(&full_name);
            Ok(vm.alloc_string(name_part))
        }
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::String(_)) => {
                // Return the string itself (it's already allocated on heap)
                Ok(args[0])
            }
            _ => Err(VMError::TypeError(
                "name requires a symbol, keyword, or string",
            )),
        },
        _ => Err(VMError::TypeError(
            "name requires a symbol, keyword, or string",
        )),
    }
}

/// Get the namespace part of a symbol or keyword: (namespace :a/b) => "a", (namespace 'foo) => nil
fn native_namespace(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let full_name = match args[0] {
        VMValue::Symbol(spur) => vm.interner().resolve(&spur).to_string(),
        VMValue::Keyword(spur) => vm.interner().resolve(&spur).to_string(),
        _ => return Err(VMError::TypeError("namespace requires a symbol or keyword")),
    };

    // Special case: "/" has no namespace
    if full_name == "/" {
        return Ok(VMValue::Nil);
    }

    // Extract the namespace part (before the last /)
    // Use rsplit_once to properly handle the namespace/name split
    if let Some((ns_part, _)) = full_name.rsplit_once('/') {
        if ns_part.is_empty() {
            // Edge case: "/foo" has no namespace
            Ok(VMValue::Nil)
        } else {
            Ok(vm.alloc_string(ns_part))
        }
    } else {
        Ok(VMValue::Nil)
    }
}

/// Concatenate sequences: (concat [1 2] [3 4] [5]) => (1 2 3 4 5)
fn native_concat(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    // Collect all elements from all sequences
    let mut all_elements: Vec<VMValue> = Vec::new();

    for arg in args {
        match arg {
            VMValue::Nil => {}
            VMValue::HeapRef(key) => match vm.heap().get(*key) {
                Some(super::HeapObject::Seq(seq)) => {
                    all_elements.extend(seq.data.iter().copied());
                }
                _ => return Err(VMError::TypeError("concat requires sequences")),
            },
            _ => return Err(VMError::TypeError("concat requires sequences")),
        }
    }

    // Return as list
    let result: crate::collections::Vector<VMValue> = all_elements.into_iter().collect();
    let seq = SeqData {
        data: result,
        kind: SeqKind::List,
    };
    let roots: Vec<super::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

/// Convert a sequence to a vector: (vec '(1 2 3)) => [1 2 3]
fn native_vec(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let data = match args[0] {
        VMValue::Nil => crate::collections::Vector::new(),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.clone(),
            _ => return Err(VMError::TypeError("vec requires a sequence")),
        },
        _ => return Err(VMError::TypeError("vec requires a sequence")),
    };

    let seq = SeqData {
        data,
        kind: SeqKind::Vector,
    };
    let roots: Vec<super::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

/// Construct a vector from arguments: (vector 1 2 3) => [1 2 3]
fn native_vector_constructor(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let data: crate::collections::Vector<VMValue> = args.iter().copied().collect();
    let seq = SeqData {
        data,
        kind: SeqKind::Vector,
    };
    let roots: Vec<super::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

/// Apply a function to arguments: (apply f [1 2 3]) => (f 1 2 3)
/// Also supports (apply f arg1 arg2 ... [args]) where middle args are prepended
fn native_apply(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let func = args[0];
    // Last argument must be a sequence; all others are prepended
    let last_arg = args[args.len() - 1];
    let middle_args = &args[1..args.len() - 1];

    // Build call args: middle args + last arg's contents
    let mut call_args: Vec<VMValue> = middle_args.to_vec();

    // Append elements from the last sequence
    match last_arg {
        VMValue::Nil => {} // Empty seq, nothing to add
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                call_args.extend(seq.data.iter().copied());
            }
            _ => {
                return Err(VMError::TypeError(
                    "apply requires a sequence as last argument",
                ));
            }
        },
        _ => {
            return Err(VMError::TypeError(
                "apply requires a sequence as last argument",
            ));
        }
    };

    // Call the function
    vm.apply(func, &call_args)
}

// --- Additional collection functions ---

fn native_hash_map(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() % 2 != 0 {
        return Err(VMError::TypeError(
            "hash-map requires even number of arguments",
        ));
    }
    let mut map = crate::collections::HashMap::new();
    let mut i = 0;
    while i < args.len() {
        map.insert(args[i], args[i + 1]);
        i += 2;
    }
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Map(map), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_hash_set(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let mut set = crate::collections::HashSet::new();
    for arg in args {
        set.insert(*arg);
    }
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Set(set), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_empty_coll(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    match args[0] {
        VMValue::Nil => Ok(VMValue::Nil),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                let empty_seq = SeqData {
                    data: crate::collections::Vector::new(),
                    kind: seq.kind,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm
                    .heap_mut()
                    .alloc(super::HeapObject::Seq(empty_seq), roots);
                Ok(VMValue::HeapRef(new_key))
            }
            Some(super::HeapObject::Map(_)) => {
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(
                    super::HeapObject::Map(crate::collections::HashMap::new()),
                    roots,
                );
                Ok(VMValue::HeapRef(new_key))
            }
            Some(super::HeapObject::Set(_)) => {
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let new_key = vm.heap_mut().alloc(
                    super::HeapObject::Set(crate::collections::HashSet::new()),
                    roots,
                );
                Ok(VMValue::HeapRef(new_key))
            }
            Some(super::HeapObject::String(_)) => Ok(vm.alloc_string("")),
            _ => Err(VMError::TypeError("empty requires a collection")),
        },
        _ => Err(VMError::TypeError("empty requires a collection")),
    }
}

fn native_last(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    match args[0] {
        VMValue::Nil => Ok(VMValue::Nil),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                Ok(seq.data.last().copied().unwrap_or(VMValue::Nil))
            }
            _ => Err(VMError::TypeError("last requires a sequence")),
        },
        _ => Err(VMError::TypeError("last requires a sequence")),
    }
}

fn native_into(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    // Extract source data type
    enum SourceData {
        Items(Vec<VMValue>),
        MapPairs(Vec<(VMValue, VMValue)>),
    }

    // Get source items
    let source_data = match args[1] {
        VMValue::Nil => SourceData::Items(Vec::new()),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => {
                SourceData::Items(seq.data.iter().copied().collect())
            }
            Some(super::HeapObject::Set(set)) => SourceData::Items(set.iter().copied().collect()),
            Some(super::HeapObject::Map(map)) => {
                SourceData::MapPairs(map.iter().map(|(k, v)| (*k, *v)).collect())
            }
            _ => return Err(VMError::TypeError("into requires a seqable source")),
        },
        _ => return Err(VMError::TypeError("into requires a seqable source")),
    };

    // Convert map pairs to items if needed
    let source_items: Vec<VMValue> = match source_data {
        SourceData::Items(items) => items,
        SourceData::MapPairs(pairs) => {
            let mut items = Vec::new();
            for (k, v) in pairs {
                let data: crate::collections::Vector<VMValue> = vec![k, v].into_iter().collect();
                let pair = SeqData {
                    data,
                    kind: SeqKind::Vector,
                };
                let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                let pair_key = vm.heap_mut().alloc(super::HeapObject::Seq(pair), roots);
                items.push(VMValue::HeapRef(pair_key));
            }
            items
        }
    };

    // Conj into target
    match args[0] {
        VMValue::Nil => {
            // into nil creates a list
            let data: crate::collections::Vector<VMValue> =
                source_items.into_iter().rev().collect();
            let seq = SeqData {
                data,
                kind: SeqKind::List,
            };
            let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
            let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
            Ok(VMValue::HeapRef(key))
        }
        VMValue::HeapRef(key) => {
            match vm.heap().get(key) {
                Some(super::HeapObject::Seq(seq)) => {
                    let mut data = seq.data.clone();
                    let kind = seq.kind;
                    match kind {
                        SeqKind::Vector => {
                            for item in source_items {
                                data.push_back(item);
                            }
                        }
                        SeqKind::List => {
                            // conj to list prepends, so natural iteration gives reversal
                            for item in source_items {
                                data.push_front(item);
                            }
                        }
                    }
                    let new_seq = SeqData { data, kind };
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Seq(new_seq), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                Some(super::HeapObject::Set(set)) => {
                    let mut new_set = set.clone();
                    for item in source_items {
                        new_set.insert(item);
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Set(new_set), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                Some(super::HeapObject::Map(map)) => {
                    let mut new_map = map.clone();
                    for item in source_items {
                        // Each item should be a [k v] pair
                        if let VMValue::HeapRef(pair_key) = item {
                            if let Some(super::HeapObject::Seq(pair)) = vm.heap().get(pair_key) {
                                if pair.data.len() >= 2 {
                                    new_map.insert(pair.data[0], pair.data[1]);
                                }
                            }
                        }
                    }
                    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
                    let new_key = vm.heap_mut().alloc(super::HeapObject::Map(new_map), roots);
                    Ok(VMValue::HeapRef(new_key))
                }
                _ => Err(VMError::TypeError("into requires a collection")),
            }
        }
        _ => Err(VMError::TypeError("into requires a collection")),
    }
}

fn native_reverse(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let items: Vec<VMValue> = match args[0] {
        VMValue::Nil => Vec::new(),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.iter().copied().collect(),
            _ => return Err(VMError::TypeError("reverse requires a sequence")),
        },
        _ => return Err(VMError::TypeError("reverse requires a sequence")),
    };

    let reversed: crate::collections::Vector<VMValue> = items.into_iter().rev().collect();
    let seq = SeqData {
        data: reversed,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_drop_last(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }

    let (n, coll) = if args.len() == 1 {
        (1usize, args[0])
    } else {
        let n = match args[0] {
            VMValue::Int(i) => i as usize,
            _ => return Err(VMError::TypeError("drop-last n must be integer")),
        };
        (n, args[1])
    };

    let items: Vec<VMValue> = match coll {
        VMValue::Nil => Vec::new(),
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.iter().copied().collect(),
            _ => return Err(VMError::TypeError("drop-last requires a sequence")),
        },
        _ => return Err(VMError::TypeError("drop-last requires a sequence")),
    };

    let end = if n >= items.len() { 0 } else { items.len() - n };
    let result: crate::collections::Vector<VMValue> = items[..end].iter().copied().collect();
    let seq = SeqData {
        data: result,
        kind: SeqKind::Vector,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_repeat(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() < 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let n = match args[0] {
        VMValue::Int(i) => i as usize,
        _ => return Err(VMError::TypeError("repeat n must be integer")),
    };

    let value = args[1];
    let data: crate::collections::Vector<VMValue> = (0..n).map(|_| value).collect();
    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_range(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let (start, end, step) = match args.len() {
        0 => {
            return Err(VMError::ArityMismatch {
                expected: 1,
                got: 0,
            });
        }
        1 => {
            let n = match args[0] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            (0i64, n, 1i64)
        }
        2 => {
            let start = match args[0] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            let end = match args[1] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            (start, end, 1i64)
        }
        _ => {
            let start = match args[0] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            let end = match args[1] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            let step = match args[2] {
                VMValue::Int(i) => i,
                _ => return Err(VMError::TypeError("range requires integer arguments")),
            };
            (start, end, step)
        }
    };

    let mut data = crate::collections::Vector::new();
    if step > 0 {
        let mut i = start;
        while i < end {
            data.push_back(VMValue::Int(i));
            i += step;
        }
    } else if step < 0 {
        let mut i = start;
        while i > end {
            data.push_back(VMValue::Int(i));
            i += step;
        }
    }

    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_mod(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => {
            if b == 0 {
                return Err(VMError::ValueError("division by zero".to_string()));
            }
            // Clojure mod: result has same sign as divisor
            Ok(VMValue::Int(((a % b) + b) % b))
        }
        _ => Err(VMError::TypeError("mod requires integers")),
    }
}

// =============================================================================
// Math Functions (Phase 1)
// =============================================================================

fn native_floor(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("floor requires a number"))?;
    Ok(VMValue::Float(n.floor()))
}

fn native_ceil(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("ceil requires a number"))?;
    Ok(VMValue::Float(n.ceil()))
}

fn native_round(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("round requires a number"))?;
    Ok(VMValue::Float(n.round()))
}

fn native_pow(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let base = number_to_f64(args[0]).ok_or(VMError::TypeError("pow requires numbers"))?;
    let exp = number_to_f64(args[1]).ok_or(VMError::TypeError("pow requires numbers"))?;
    Ok(VMValue::Float(base.powf(exp)))
}

fn native_sqrt(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("sqrt requires a number"))?;
    Ok(VMValue::Float(n.sqrt()))
}

fn native_exp(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("exp requires a number"))?;
    Ok(VMValue::Float(n.exp()))
}

fn native_log(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("log requires a number"))?;
    Ok(VMValue::Float(n.ln()))
}

fn native_log2(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("log2 requires a number"))?;
    Ok(VMValue::Float(n.log2()))
}

fn native_log10(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("log10 requires a number"))?;
    Ok(VMValue::Float(n.log10()))
}

fn native_sin(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("sin requires a number"))?;
    Ok(VMValue::Float(n.sin()))
}

fn native_cos(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("cos requires a number"))?;
    Ok(VMValue::Float(n.cos()))
}

fn native_tan(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("tan requires a number"))?;
    Ok(VMValue::Float(n.tan()))
}

fn native_asin(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("asin requires a number"))?;
    Ok(VMValue::Float(n.asin()))
}

fn native_acos(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("acos requires a number"))?;
    Ok(VMValue::Float(n.acos()))
}

fn native_atan(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("atan requires a number"))?;
    Ok(VMValue::Float(n.atan()))
}

fn native_atan2(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let y = number_to_f64(args[0]).ok_or(VMError::TypeError("atan2 requires numbers"))?;
    let x = number_to_f64(args[1]).ok_or(VMError::TypeError("atan2 requires numbers"))?;
    Ok(VMValue::Float(y.atan2(x)))
}

fn native_sinh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("sinh requires a number"))?;
    Ok(VMValue::Float(n.sinh()))
}

fn native_cosh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("cosh requires a number"))?;
    Ok(VMValue::Float(n.cosh()))
}

fn native_tanh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("tanh requires a number"))?;
    Ok(VMValue::Float(n.tanh()))
}

fn native_asinh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("asinh requires a number"))?;
    Ok(VMValue::Float(n.asinh()))
}

fn native_acosh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("acosh requires a number"))?;
    Ok(VMValue::Float(n.acosh()))
}

fn native_atanh(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let n = number_to_f64(args[0]).ok_or(VMError::TypeError("atanh requires a number"))?;
    Ok(VMValue::Float(n.atanh()))
}

fn native_hypot(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let x = number_to_f64(args[0]).ok_or(VMError::TypeError("hypot requires numbers"))?;
    let y = number_to_f64(args[1]).ok_or(VMError::TypeError("hypot requires numbers"))?;
    Ok(VMValue::Float(x.hypot(y)))
}

fn native_signum(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    match args[0] {
        VMValue::Int(n) => Ok(VMValue::Int(n.signum())),
        VMValue::Float(n) => Ok(VMValue::Float(n.signum())),
        _ => Err(VMError::TypeError("signum requires a number")),
    }
}

fn native_quot(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => {
            if b == 0 {
                return Err(VMError::ValueError("division by zero".to_string()));
            }
            Ok(VMValue::Int(a / b))
        }
        _ => Err(VMError::TypeError("quot requires integers")),
    }
}

fn native_rem(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => {
            if b == 0 {
                return Err(VMError::ValueError("division by zero".to_string()));
            }
            // Clojure rem: result has same sign as dividend (truncated division)
            Ok(VMValue::Int(a % b))
        }
        _ => Err(VMError::TypeError("rem requires integers")),
    }
}

fn gcd_helper(a: i64, b: i64) -> i64 {
    let mut a = a.abs();
    let mut b = b.abs();
    while b != 0 {
        let t = b;
        b = a % b;
        a = t;
    }
    a
}

fn native_gcd(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(gcd_helper(a, b))),
        _ => Err(VMError::TypeError("gcd requires integers")),
    }
}

fn native_lcm(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => {
            if a == 0 || b == 0 {
                return Ok(VMValue::Int(0));
            }
            let g = gcd_helper(a, b);
            Ok(VMValue::Int((a.abs() / g) * b.abs()))
        }
        _ => Err(VMError::TypeError("lcm requires integers")),
    }
}

fn native_numerator(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    match args[0] {
        VMValue::Ratio { numer, .. } => Ok(VMValue::Int(numer)),
        VMValue::Int(n) => Ok(VMValue::Int(n)),
        _ => Err(VMError::TypeError("numerator requires a ratio or integer")),
    }
}

fn native_denominator(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    match args[0] {
        VMValue::Ratio { denom, .. } => Ok(VMValue::Int(denom)),
        VMValue::Int(_) => Ok(VMValue::Int(1)),
        _ => Err(VMError::TypeError(
            "denominator requires a ratio or integer",
        )),
    }
}

fn native_parse_int(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() || args.len() > 2 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    let radix = if args.len() == 2 {
        match args[1] {
            VMValue::Int(r) => r as u32,
            _ => return Err(VMError::TypeError("radix must be integer")),
        }
    } else {
        10
    };
    match i64::from_str_radix(&s, radix) {
        Ok(n) => Ok(VMValue::Int(n)),
        Err(_) => Ok(VMValue::Nil),
    }
}

fn native_parse_double(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    match s.parse::<f64>() {
        Ok(n) => Ok(VMValue::Float(n)),
        Err(_) => Ok(VMValue::Nil),
    }
}

// =============================================================================
// Bitwise Operations (Phase 2)
// =============================================================================

fn native_bit_and(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a & b)),
        _ => Err(VMError::TypeError("bit-and requires integers")),
    }
}

fn native_bit_or(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a | b)),
        _ => Err(VMError::TypeError("bit-or requires integers")),
    }
}

fn native_bit_xor(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a ^ b)),
        _ => Err(VMError::TypeError("bit-xor requires integers")),
    }
}

fn native_bit_not(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    match args[0] {
        VMValue::Int(a) => Ok(VMValue::Int(!a)),
        _ => Err(VMError::TypeError("bit-not requires an integer")),
    }
}

fn native_bit_shift_left(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a << (b as u32))),
        _ => Err(VMError::TypeError("bit-shift-left requires integers")),
    }
}

fn native_bit_shift_right(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    match (args[0], args[1]) {
        (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a >> (b as u32))),
        _ => Err(VMError::TypeError("bit-shift-right requires integers")),
    }
}

// =============================================================================
// Constants (Phase 3)
// =============================================================================

fn native_pi(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Float(std::f64::consts::PI))
}

fn native_e(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Float(std::f64::consts::E))
}

fn native_infinity(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Float(f64::INFINITY))
}

fn native_neg_infinity(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Float(f64::NEG_INFINITY))
}

fn native_nan(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    Ok(VMValue::Float(f64::NAN))
}

// =============================================================================
// Additional Predicates (Phase 4)
// =============================================================================

fn native_int_pred(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    Ok(VMValue::Bool(matches!(args[0], VMValue::Int(_))))
}

fn native_float_pred(_vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    Ok(VMValue::Bool(matches!(args[0], VMValue::Float(_))))
}

fn native_optic_pred(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let is_optic = match args[0] {
        VMValue::HeapRef(key) => matches!(vm.heap().get(key), Some(super::HeapObject::Optic(_))),
        VMValue::Keyword(_) => true, // Keywords can be used as optics
        _ => false,
    };
    Ok(VMValue::Bool(is_optic))
}

// =============================================================================
// String Functions (Phase 5)
// =============================================================================

fn native_trim(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    Ok(vm.alloc_string(s.trim()))
}

fn native_triml(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    Ok(vm.alloc_string(s.trim_start()))
}

fn native_trimr(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 1 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    Ok(vm.alloc_string(s.trim_end()))
}

fn native_starts_with(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    let prefix = get_string(vm, args[1])?;
    Ok(VMValue::Bool(s.starts_with(&prefix)))
}

fn native_ends_with(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    let suffix = get_string(vm, args[1])?;
    Ok(VMValue::Bool(s.ends_with(&suffix)))
}

fn native_replace(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 3 {
        return Err(VMError::ArityMismatch {
            expected: 3,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    let replacement = get_string(vm, args[2])?;

    // Check if pattern is a regex or string
    let result = match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Regex(re)) => {
                re.replace_all(&s, replacement.as_str()).to_string()
            }
            Some(super::HeapObject::String(pat)) => s.replace(pat.as_str(), &replacement),
            _ => {
                return Err(VMError::TypeError(
                    "replace pattern must be string or regex",
                ));
            }
        },
        _ => {
            return Err(VMError::TypeError(
                "replace pattern must be string or regex",
            ));
        }
    };

    Ok(vm.alloc_string(&result))
}

fn native_replace_first(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 3 {
        return Err(VMError::ArityMismatch {
            expected: 3,
            got: args.len() as u8,
        });
    }
    let s = get_string(vm, args[0])?;
    let replacement = get_string(vm, args[2])?;

    // Check if pattern is a regex or string
    let result = match args[1] {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Regex(re)) => re.replace(&s, replacement.as_str()).to_string(),
            Some(super::HeapObject::String(pat)) => s.replacen(pat.as_str(), &replacement, 1),
            _ => {
                return Err(VMError::TypeError(
                    "replace-first pattern must be string or regex",
                ));
            }
        },
        _ => {
            return Err(VMError::TypeError(
                "replace-first pattern must be string or regex",
            ));
        }
    };

    Ok(vm.alloc_string(&result))
}

fn native_format(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: 0,
        });
    }
    let fmt_str = get_string(vm, args[0])?;
    let format_args = &args[1..];

    // Simple format implementation: replace %s, %d, etc. with args in order
    let mut result = String::new();
    let mut arg_idx = 0;
    let mut chars = fmt_str.chars().peekable();

    while let Some(c) = chars.next() {
        if c == '%' {
            if let Some(&next) = chars.peek() {
                match next {
                    '%' => {
                        result.push('%');
                        chars.next();
                    }
                    's' | 'd' | 'f' => {
                        chars.next();
                        if arg_idx < format_args.len() {
                            result.push_str(&value_to_string(vm, format_args[arg_idx]));
                            arg_idx += 1;
                        }
                    }
                    _ => result.push(c),
                }
            } else {
                result.push(c);
            }
        } else {
            result.push(c);
        }
    }

    Ok(vm.alloc_string(&result))
}

fn native_prn(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    let output: Vec<String> = args.iter().map(|v| value_to_pr_string(vm, *v)).collect();
    println!("{}", output.join(" "));
    Ok(VMValue::Nil)
}

// =============================================================================
// Sorting (Phase 7)
// =============================================================================

fn native_sort(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.is_empty() || args.len() > 2 {
        return Err(VMError::ArityMismatch {
            expected: 1,
            got: args.len() as u8,
        });
    }

    let (coll, comparator) = if args.len() == 2 {
        (args[1], Some(args[0]))
    } else {
        (args[0], None)
    };

    let mut items: Vec<VMValue> = match coll {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.iter().copied().collect(),
            Some(super::HeapObject::Set(set)) => set.iter().copied().collect(),
            _ => return Err(VMError::TypeError("sort requires a collection")),
        },
        VMValue::Nil => vec![],
        _ => return Err(VMError::TypeError("sort requires a collection")),
    };

    if let Some(comp_fn) = comparator {
        // Sort with custom comparator
        let mut error: Option<VMError> = None;
        items.sort_by(|a, b| {
            if error.is_some() {
                return std::cmp::Ordering::Equal;
            }
            match vm.apply(comp_fn, &[*a, *b]) {
                Ok(result) => {
                    match result {
                        VMValue::Int(n) => n.cmp(&0),
                        VMValue::Bool(true) => std::cmp::Ordering::Less,
                        VMValue::Bool(false) => {
                            // For boolean comparators, false could mean >= (greater or equal)
                            // Check the reverse direction to distinguish
                            match vm.apply(comp_fn, &[*b, *a]) {
                                Ok(VMValue::Bool(true)) => std::cmp::Ordering::Greater,
                                Ok(VMValue::Bool(false)) => std::cmp::Ordering::Equal,
                                Ok(VMValue::Int(n)) => 0i64.cmp(&n),
                                _ => std::cmp::Ordering::Equal,
                            }
                        }
                        _ => std::cmp::Ordering::Equal,
                    }
                }
                Err(e) => {
                    error = Some(e);
                    std::cmp::Ordering::Equal
                }
            }
        });
        if let Some(e) = error {
            return Err(e);
        }
    } else {
        // Default sort by numeric comparison
        items.sort_by(|a, b| match (a, b) {
            (VMValue::Int(x), VMValue::Int(y)) => x.cmp(y),
            (VMValue::Float(x), VMValue::Float(y)) => {
                x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal)
            }
            (VMValue::Int(x), VMValue::Float(y)) => (*x as f64)
                .partial_cmp(y)
                .unwrap_or(std::cmp::Ordering::Equal),
            (VMValue::Float(x), VMValue::Int(y)) => x
                .partial_cmp(&(*y as f64))
                .unwrap_or(std::cmp::Ordering::Equal),
            _ => std::cmp::Ordering::Equal,
        });
    }

    let data: crate::collections::Vector<VMValue> = items.into_iter().collect();
    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

fn native_sort_by(vm: &mut VM, args: &[VMValue]) -> Result<VMValue, VMError> {
    if args.len() != 2 {
        return Err(VMError::ArityMismatch {
            expected: 2,
            got: args.len() as u8,
        });
    }

    let keyfn = args[0];
    let coll = args[1];

    let mut items: Vec<VMValue> = match coll {
        VMValue::HeapRef(key) => match vm.heap().get(key) {
            Some(super::HeapObject::Seq(seq)) => seq.data.iter().copied().collect(),
            Some(super::HeapObject::Set(set)) => set.iter().copied().collect(),
            _ => return Err(VMError::TypeError("sort-by requires a collection")),
        },
        VMValue::Nil => vec![],
        _ => return Err(VMError::TypeError("sort-by requires a collection")),
    };

    // Compute keys for all items
    // Inhibit GC: keyed pairs are not GC roots.
    vm.heap_mut().inhibit_gc();
    let mut keyed: Vec<(VMValue, VMValue)> = Vec::with_capacity(items.len());
    for item in items.drain(..) {
        let key = vm.apply(keyfn, &[item])?;
        keyed.push((key, item));
    }
    vm.heap_mut().allow_gc();

    // Sort by keys
    keyed.sort_by(|(ka, _), (kb, _)| match (ka, kb) {
        (VMValue::Int(x), VMValue::Int(y)) => x.cmp(y),
        (VMValue::Float(x), VMValue::Float(y)) => {
            x.partial_cmp(y).unwrap_or(std::cmp::Ordering::Equal)
        }
        (VMValue::Int(x), VMValue::Float(y)) => (*x as f64)
            .partial_cmp(y)
            .unwrap_or(std::cmp::Ordering::Equal),
        (VMValue::Float(x), VMValue::Int(y)) => x
            .partial_cmp(&(*y as f64))
            .unwrap_or(std::cmp::Ordering::Equal),
        _ => std::cmp::Ordering::Equal,
    });

    let data: crate::collections::Vector<VMValue> = keyed.into_iter().map(|(_, v)| v).collect();
    let seq = SeqData {
        data,
        kind: SeqKind::List,
    };
    let roots: Vec<super::value::HeapKey> = std::iter::empty().collect();
    let key = vm.heap_mut().alloc(super::HeapObject::Seq(seq), roots);
    Ok(VMValue::HeapRef(key))
}

// =============================================================================
// Time
// =============================================================================

#[cfg(not(target_arch = "wasm32"))]
fn native_nano_time(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    use std::time::{SystemTime, UNIX_EPOCH};
    let duration = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default();
    Ok(VMValue::Int(duration.as_nanos() as i64))
}

#[cfg(target_arch = "wasm32")]
fn native_nano_time(_vm: &mut VM, _args: &[VMValue]) -> Result<VMValue, VMError> {
    // Return 0 on WASM - SystemTime is not available
    Ok(VMValue::Int(0))
}
