//! VM error types

use super::value::EffectId;
use crate::span::Span;

#[derive(Debug, Clone)]
pub enum VMError {
    TypeError(&'static str),
    ValueError(String),
    StackUnderflow,
    InvalidOpcode(u8),
    UndefinedGlobal(String),
    NotCallable,
    ArityMismatch {
        expected: u8,
        got: u8,
    },
    IndexOutOfBounds {
        index: i64,
        len: usize,
    },
    InvalidContinuation,
    EffectNotHandled {
        id: EffectId,
        name: Option<String>,
    },
    OperationNotHandled {
        effect_id: EffectId,
        effect_name: Option<String>,
        op_name: String,
    },
    DivisionByZero,
    AssertionFailed(String),
    NoMatchingClause,
}

impl std::fmt::Display for VMError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            VMError::TypeError(msg) => write!(f, "Type error: {}", msg),
            VMError::ValueError(msg) => write!(f, "Value error: {}", msg),
            VMError::StackUnderflow => write!(f, "Stack underflow"),
            VMError::InvalidOpcode(op) => write!(f, "Invalid opcode: {}", op),
            VMError::UndefinedGlobal(sym) => write!(f, "Undefined variable: {}", sym),
            VMError::NotCallable => write!(f, "Value is not callable"),
            VMError::ArityMismatch { expected, got } => {
                write!(
                    f,
                    "Wrong number of arguments: expected {}, got {}",
                    expected, got
                )
            }
            VMError::IndexOutOfBounds { index, len } => {
                write!(f, "Index {} out of bounds for length {}", index, len)
            }
            VMError::InvalidContinuation => write!(f, "Invalid continuation"),
            VMError::EffectNotHandled { id, name } => match name {
                Some(n) => write!(f, "Unhandled effect: {}", n),
                None => write!(f, "Unhandled effect: effect #{}", id.0),
            },
            VMError::OperationNotHandled {
                effect_id,
                effect_name,
                op_name,
            } => match effect_name {
                Some(n) => write!(f, "Unhandled operation '{}/{}' ", n, op_name),
                None => write!(
                    f,
                    "Unhandled operation '{}' on effect #{}",
                    op_name, effect_id.0
                ),
            },
            VMError::DivisionByZero => write!(f, "Division by zero"),
            VMError::AssertionFailed(msg) => write!(f, "Assertion failed: {}", msg),
            VMError::NoMatchingClause => write!(f, "No matching clause"),
        }
    }
}

impl std::error::Error for VMError {}

impl VMError {
    /// Returns true if this error should be routed through exn/raise
    /// (i.e., it's a user error that can be caught, not a VM invariant violation)
    pub fn is_catchable(&self) -> bool {
        match self {
            // User errors - catchable
            VMError::TypeError(_) => true,
            VMError::ValueError(_) => true,
            VMError::DivisionByZero => true,
            VMError::ArityMismatch { .. } => true,
            VMError::IndexOutOfBounds { .. } => true,
            VMError::NotCallable => true,
            VMError::AssertionFailed(_) => true,
            VMError::UndefinedGlobal(_) => true,
            VMError::NoMatchingClause => true,

            // VM invariants - not catchable (indicates VM bug or should propagate)
            VMError::StackUnderflow => false,
            VMError::InvalidOpcode(_) => false,
            VMError::InvalidContinuation => false,

            // Effect-related - keep as-is (they have their own semantics)
            VMError::EffectNotHandled { .. } => false,
            VMError::OperationNotHandled { .. } => false,
        }
    }

    /// Returns the error type as a keyword name (without the leading colon)
    pub fn error_type(&self) -> &'static str {
        match self {
            VMError::TypeError(_) => "type-error",
            VMError::ValueError(_) => "value-error",
            VMError::DivisionByZero => "division-by-zero",
            VMError::ArityMismatch { .. } => "arity-error",
            VMError::IndexOutOfBounds { .. } => "index-out-of-bounds",
            VMError::NotCallable => "not-callable",
            VMError::AssertionFailed(_) => "assertion-failed",
            VMError::UndefinedGlobal(_) => "undefined-variable",
            VMError::StackUnderflow => "stack-underflow",
            VMError::InvalidOpcode(_) => "invalid-opcode",
            VMError::InvalidContinuation => "invalid-continuation",
            VMError::EffectNotHandled { .. } => "effect-not-handled",
            VMError::OperationNotHandled { .. } => "operation-not-handled",
            VMError::NoMatchingClause => "no-matching-clause",
        }
    }
}

/// A stack frame in the VM call stack (for error reporting)
#[derive(Debug, Clone)]
pub struct VMStackFrame {
    pub name: Option<String>,
    pub span: Option<Span>,
}

/// Rich VM error with source location and stack trace
#[derive(Debug, Clone)]
pub struct RichVMError {
    pub kind: VMError,
    pub span: Option<Span>,
    pub stack_trace: Vec<VMStackFrame>,
}

impl std::fmt::Display for RichVMError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}", self.kind)
    }
}

impl std::error::Error for RichVMError {}

impl RichVMError {
    /// Convert to core Error type for ariadne reporting
    pub fn to_core_error(&self) -> crate::error::Error {
        let message = self.kind.to_string();

        let mut error = crate::error::Error::eval(message);
        if let Some(span) = self.span {
            error = error.with_span(Some(span));
        }

        // Convert stack trace to call frames
        let call_stack: Vec<crate::value::CallFrame> = self
            .stack_trace
            .iter()
            .map(|frame| crate::value::CallFrame {
                kind: match &frame.name {
                    Some(name) => crate::value::CallFrameKind::UserFn(name.as_str().into()),
                    None => crate::value::CallFrameKind::Anonymous,
                },
                span: frame.span,
            })
            .collect();

        error.with_call_stack(call_stack)
    }
}

/// Generate an ariadne report for a rich VM error.
/// Returns an owned Report that manages its own lifetime.
pub fn report(error: &RichVMError) -> Option<ariadne::Report<'static, Span>> {
    let core_error = error.to_core_error();
    let span = core_error.span?;

    use ariadne::{Color, Label, Report, ReportKind};

    let mut builder = Report::build(ReportKind::Error, span)
        .with_message(core_error.to_string())
        .with_label(
            Label::new(span)
                .with_message(error.kind.to_string())
                .with_color(Color::Red),
        );

    // Add call stack frames as labels (excluding the last one which is the error site)
    let max_stack_labels = 5;
    let stack_len = core_error.call_stack.len();
    if stack_len > 1 {
        let frames_to_show: Vec<_> = core_error
            .call_stack
            .iter()
            .take(stack_len.saturating_sub(1))
            .rev()
            .take(max_stack_labels)
            .collect();

        for (i, frame) in frames_to_show.iter().rev().enumerate() {
            if let Some(frame_span) = frame.span {
                let name = match &frame.kind {
                    crate::value::CallFrameKind::UserFn(name) => name.to_string(),
                    crate::value::CallFrameKind::Anonymous => "<anonymous>".to_string(),
                    crate::value::CallFrameKind::Native(name) => name.to_string(),
                    crate::value::CallFrameKind::Effect { effect, op } => {
                        format!("{}/{}", effect, op)
                    }
                    crate::value::CallFrameKind::Handler { effect, op } => {
                        format!("<handler {}/{}>", effect, op)
                    }
                };
                let msg = if i == 0 && stack_len > max_stack_labels + 1 {
                    format!(
                        "...called from {} (and {} more)",
                        name,
                        stack_len - max_stack_labels - 1
                    )
                } else {
                    format!("called from {}", name)
                };
                builder = builder.with_label(
                    Label::new(frame_span)
                        .with_message(msg)
                        .with_color(Color::Yellow)
                        .with_order(-(i as i32) - 1),
                );
            }
        }
    }

    Some(builder.finish())
}
