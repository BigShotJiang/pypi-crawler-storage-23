//! Bytecode opcodes and encoding

/// VM opcodes - 8-bit opcode + up to 3 byte operands = 32-bit instruction
#[repr(u8)]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum OpCode {
    // --- Stack ---
    Const = 0, // Push constant: Const idx_lo idx_hi _
    Pop = 1,   // Discard top
    Dup = 2,   // Duplicate top

    // --- Locals ---
    GetLocal = 3, // Push local: GetLocal slot _ _
    SetLocal = 4, // Pop to local: SetLocal slot _ _

    // --- Upvalues ---
    GetUpvalue = 5, // Push upvalue: GetUpvalue slot _ _
    SetUpvalue = 6, // Pop to upvalue: SetUpvalue slot _ _

    // --- Globals ---
    GetGlobal = 7, // Push global: GetGlobal const_lo const_hi _ (symbol in constants)
    SetGlobal = 8, // Pop to global: SetGlobal const_lo const_hi _
    DefGlobal = 9, // Define global: DefGlobal const_lo const_hi _

    // --- Arithmetic ---
    Add = 10,
    Sub = 11,
    Mul = 12,
    Div = 13,
    Rem = 14,
    Neg = 15,

    // --- Comparison ---
    Eq = 16,
    Ne = 17,
    Lt = 18,
    Le = 19,
    Gt = 20,
    Ge = 21,

    // --- Logic ---
    Not = 22,

    // --- Control flow ---
    Jump = 23,        // Jump offset_lo offset_hi _ (signed i16)
    JumpIfFalse = 24, // Conditional jump
    JumpIfTrue = 25,  // Conditional jump

    // --- Functions ---
    Call = 26,             // Call n_args _ _
    TailCall = 27,         // Tail call n_args _ _
    Return = 28,           // Return top of stack
    MakeClosure = 29,      // MakeClosure proto_lo proto_hi n_upvalues
    MakeMultiClosure = 30, // MakeMultiClosure const_lo const_hi n_upvalues

    // --- Collections ---
    MakeList = 31,   // MakeList n_lo n_hi _ (build list from n stack values)
    MakeVector = 32, // MakeVector n_lo n_hi _
    MakeMap = 33,    // MakeMap n_pairs_lo n_pairs_hi _
    MakeSet = 34,    // MakeSet n_lo n_hi _

    // --- Effects ---
    PushHandler = 35, // PushHandler effect_const_lo effect_const_hi handler_idx
    PopHandler = 36,  // PopHandler
    Perform = 37,     // Perform effect_const_lo effect_const_hi n_args
    Resume = 38,      // Resume continuation with value
    PerformOp = 39,   // PerformOp effect_const op_const n_args (for qualified symbols)

    // --- Natives ---
    CallNative = 40, // CallNative native_idx_lo native_idx_hi n_args

    // --- Optimized globals ---
    GetGlobalSlot = 41, // GetGlobalSlot slot_lo slot_hi _

    // --- ADT ---
    MakeVariant = 42, // MakeVariant type_id_lo type_id_hi variant_idx
}

impl OpCode {
    pub fn from_u8(b: u8) -> Option<OpCode> {
        if b <= 42 {
            Some(unsafe { std::mem::transmute(b) })
        } else {
            None
        }
    }
}

/// Encode instruction: opcode + 3 byte operands -> u32
pub fn encode(op: OpCode, a1: u8, a2: u8, a3: u8) -> u32 {
    (a3 as u32) << 24 | (a2 as u32) << 16 | (a1 as u32) << 8 | (op as u32)
}

/// Decode instruction: u32 -> (opcode, a1, a2, a3)
#[inline(always)]
pub fn decode(instr: u32) -> (u8, u8, u8, u8) {
    let op = (instr & 0xFF) as u8;
    let a1 = ((instr >> 8) & 0xFF) as u8;
    let a2 = ((instr >> 16) & 0xFF) as u8;
    let a3 = ((instr >> 24) & 0xFF) as u8;
    (op, a1, a2, a3)
}

/// Combine two bytes into u16 (little-endian)
#[inline(always)]
pub fn arg_u16(a1: u8, a2: u8) -> u16 {
    u16::from_le_bytes([a1, a2])
}

/// Combine two bytes into i16 (little-endian, for jump offsets)
#[inline(always)]
pub fn arg_i16(a1: u8, a2: u8) -> i16 {
    i16::from_le_bytes([a1, a2])
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_encode_decode_roundtrip() {
        let instr = encode(OpCode::Const, 0x12, 0x34, 0x56);
        let (op, a1, a2, a3) = decode(instr);
        assert_eq!(op, OpCode::Const as u8);
        assert_eq!(a1, 0x12);
        assert_eq!(a2, 0x34);
        assert_eq!(a3, 0x56);
    }

    #[test]
    fn test_arg_i16_negative() {
        let offset: i16 = -10;
        let [a1, a2] = offset.to_le_bytes();
        assert_eq!(arg_i16(a1, a2), -10);
    }
}
