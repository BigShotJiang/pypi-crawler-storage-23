//! Type registry for algebraic data types (defdata)

use lasso::Spur;
use rustc_hash::FxHashMap;

use super::value::HeapKey;

/// Unique type identifier for algebraic data types.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct TypeId(pub u16);

/// Registry of all algebraic data types.
pub struct TypeRegistry {
    types: Vec<TypeDef>,
    name_to_id: FxHashMap<Spur, TypeId>,
}

/// Definition of an algebraic data type (family).
pub struct TypeDef {
    pub name: Spur,
    pub variants: Box<[VariantDef]>,
}

/// Definition of a single variant within a type family.
pub struct VariantDef {
    pub name: Spur,
    pub field_names: Box<[Spur]>,
    pub field_index: FxHashMap<Spur, u8>,
    /// Pre-allocated singleton key for zero-field variants.
    pub singleton_key: Option<HeapKey>,
}

impl TypeRegistry {
    pub fn new() -> Self {
        TypeRegistry {
            types: Vec::new(),
            name_to_id: FxHashMap::default(),
        }
    }

    /// Register a new type, returning its TypeId.
    pub fn register(&mut self, name: Spur, variants: Vec<VariantDef>) -> TypeId {
        let id = TypeId(self.types.len() as u16);
        self.name_to_id.insert(name, id);
        self.types.push(TypeDef {
            name,
            variants: variants.into_boxed_slice(),
        });
        id
    }

    pub fn get(&self, id: TypeId) -> Option<&TypeDef> {
        self.types.get(id.0 as usize)
    }

    pub fn get_by_name(&self, name: Spur) -> Option<(TypeId, &TypeDef)> {
        let id = self.name_to_id.get(&name)?;
        Some((*id, &self.types[id.0 as usize]))
    }

    pub fn type_count(&self) -> usize {
        self.types.len()
    }

    /// Get all singleton keys (for GC rooting).
    pub fn singleton_keys(&self) -> impl Iterator<Item = HeapKey> + '_ {
        self.types
            .iter()
            .flat_map(|t| t.variants.iter().filter_map(|v| v.singleton_key))
    }

    /// Iterate all types with their IDs and variant definitions.
    /// Used to seed the compiler's variant_constructors map.
    pub fn iter_variants(&self) -> impl Iterator<Item = (TypeId, u8, Spur, usize)> + '_ {
        self.types
            .iter()
            .enumerate()
            .flat_map(|(type_idx, typedef)| {
                typedef
                    .variants
                    .iter()
                    .enumerate()
                    .map(move |(var_idx, vdef)| {
                        (
                            TypeId(type_idx as u16),
                            var_idx as u8,
                            vdef.name,
                            vdef.field_names.len(),
                        )
                    })
            })
    }

    /// Remap heap keys after importing from another heap.
    pub fn remap_heap_refs(&mut self, key_map: &std::collections::HashMap<HeapKey, HeapKey>) {
        for typedef in self.types.iter_mut() {
            for variant in typedef.variants.iter_mut() {
                if let Some(ref mut key) = variant.singleton_key {
                    if let Some(&new_key) = key_map.get(key) {
                        *key = new_key;
                    }
                }
            }
        }
    }
}

impl Default for TypeRegistry {
    fn default() -> Self {
        Self::new()
    }
}
