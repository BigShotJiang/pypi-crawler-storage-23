//! Hoatzin bytecode VM
//!
//! A stack-based VM with:
//! - Copy semantics for stack values (no Rc overhead)
//! - Mark-sweep GC on slotmap
//! - One-shot delimited continuations for algebraic effects

#![allow(dead_code)] // Scaffold - will be filled in

pub mod agent;
mod compilation_unit;
mod compiler;
pub mod disassemble;
mod error;
mod frame;
mod heap;
mod interface;
mod natives;
mod opcode;
mod prototype;
pub mod stdlib;
pub mod type_registry;
mod value;

pub use crate::error::report as parse_error_report;
pub use agent::{AgentEvalResult, AgentJournal};
pub use compilation_unit::{CompilationUnit, DefKind, DocEntry};
pub use compiler::{CompileError, CompileErrorKind, Compiler, compile_error_report};
pub use disassemble::disassemble;
pub use error::{RichVMError, VMError, report as error_report};
pub use heap::{Heap, HeapObject, OpticKind, SeqData, SeqKind, VariantInstance};
pub use interface::{EvalError, Runtime, compile, eval};
pub use natives::value_to_pr_string;
pub use opcode::OpCode;
pub use prototype::{Prototype, Span};
pub use value::{EffectId, HeapKey, VMValue};

use std::collections::HashMap;
use std::rc::Rc;

use rustc_hash::FxHashMap;

use frame::{CallFrame, Handler};

/// Result of a native effect handler
#[derive(Debug, Clone)]
pub enum HandlerAction {
    /// Continue execution with this value (tail-resume)
    Resume(VMValue),
    /// Abort to handler install point, return this value
    Abort(VMValue),
}

/// Native effect handler function signature.
/// Uses `Rc<dyn Fn>` instead of a bare function pointer so handlers
/// can capture state (e.g. for sandboxed I/O buffering).
pub type NativeHandler =
    Rc<dyn Fn(&mut VM, Spur, Vec<VMValue>) -> Result<HandlerAction, VMError>>;

/// A dynamically registered native function (host callback).
pub struct DynamicNative {
    pub name: String,
    pub func: Rc<dyn Fn(&mut VM, &[VMValue]) -> Result<VMValue, VMError>>,
}
use heap::{ClauseInfo, Closure, CompiledPattern};
use lasso::{Rodeo, Spur};
use natives::build_native_table;
use opcode::{arg_i16, arg_u16, decode};
use type_registry::TypeRegistry;

/// The VM state
pub struct VM {
    // Memory
    heap: Heap,
    stack: Vec<VMValue>,

    // Execution
    frames: Vec<CallFrame>,
    handlers: Vec<Handler>,

    // Global environment (indexed for fast access)
    globals: Vec<VMValue>,
    global_index: FxHashMap<Spur, u32>,

    // String interner (shared with compiler)
    interner: Rodeo,

    // Code
    prototypes: Vec<Prototype>,
    natives: Vec<natives::NativeEntry>,

    // Effect ID counter for generating unique effect identifiers
    next_effect_id: u64,

    // Interned optic singletons
    optic_each: HeapKey,
    optic_vals: HeapKey,
    optic_keys: HeapKey,
    optic_deep: HeapKey,
    optic_some: HeapKey,

    // External roots (e.g., macro closures stored outside VM)
    // These must be kept alive by GC
    external_roots: Vec<HeapKey>,

    // Native effect handlers (checked before Hoatzin handlers)
    // Keyed by EffectId for proper lexical scoping semantics
    native_handlers: HashMap<EffectId, NativeHandler>,

    // Algebraic data type registry
    type_registry: TypeRegistry,

    // Cached tag for ReduceSignal/Reduced (for fast check in native_reduce)
    reduced_tag: Option<u32>,

    // Dynamically registered native functions (host callbacks)
    dynamic_natives: Vec<DynamicNative>,

    // Accumulated documentation from natives and compiled units
    docs: FxHashMap<Spur, DocEntry>,
}

/// Result of a single execution step
enum StepResult {
    Continue,
    Return(VMValue),
    Yield {
        effect_id: EffectId,
        op_name: Spur,
        args: Vec<VMValue>,
    },
}

impl VM {
    pub fn new() -> Self {
        let mut heap = Heap::new();
        let mut interner = Rodeo::new();

        // Initialize optic singletons
        let optic_each = heap.insert_constant(HeapObject::Optic(OpticKind::Each));
        let optic_vals = heap.insert_constant(HeapObject::Optic(OpticKind::Vals));
        let optic_keys = heap.insert_constant(HeapObject::Optic(OpticKind::Keys));
        let optic_deep = heap.insert_constant(HeapObject::Optic(OpticKind::Deep));
        let optic_some = heap.insert_constant(HeapObject::Optic(OpticKind::Some));

        // Build native function table
        let natives = build_native_table();

        // Populate docs from native entries
        let mut docs = FxHashMap::default();
        for entry in &natives {
            if !entry.doc.is_empty() {
                let spur = interner.get_or_intern(entry.name);
                docs.insert(
                    spur,
                    DocEntry {
                        docstring: entry.doc.to_string(),
                        kind: DefKind::Native,
                        span: None,
                    },
                );
            }
        }

        let mut vm = VM {
            heap,
            stack: Vec::with_capacity(1024),
            frames: Vec::with_capacity(64),
            handlers: Vec::with_capacity(16),
            globals: Vec::new(),
            global_index: FxHashMap::default(),
            interner,
            prototypes: Vec::new(),
            natives,
            next_effect_id: 1, // Start at 1, reserve 0 for special cases
            optic_each,
            optic_vals,
            optic_keys,
            optic_deep,
            optic_some,
            external_roots: Vec::new(),
            native_handlers: HashMap::new(),
            dynamic_natives: Vec::new(),
            type_registry: TypeRegistry::new(),
            reduced_tag: None,
            docs,
        };

        // Register native functions as globals
        vm.register_natives();

        // Register built-in effects (exn, console, random)
        vm.register_builtin_effects();

        // Register optic singletons as globals
        vm.register_optic_globals();

        vm
    }

    // --- Public API ---

    /// Add a compiled prototype, returns its index
    pub fn add_prototype(&mut self, proto: Prototype) -> u32 {
        let idx = self.prototypes.len() as u32;
        self.prototypes.push(proto);
        idx
    }

    /// Get current prototype count (for offset calculation)
    pub fn prototype_count(&self) -> u32 {
        self.prototypes.len() as u32
    }

    /// Set a global variable
    pub fn set_global(&mut self, name: Spur, value: VMValue) {
        if let Some(&slot) = self.global_index.get(&name) {
            self.globals[slot as usize] = value;
        } else {
            let slot = self.globals.len() as u32;
            self.global_index.insert(name, slot);
            self.globals.push(value);
        }
    }

    /// Get a global variable
    pub fn get_global(&self, name: Spur) -> Option<VMValue> {
        self.global_index
            .get(&name)
            .map(|&slot| self.globals[slot as usize])
    }

    /// Get the global slot index map (for compiler optimization)
    pub fn global_slots(&self) -> &FxHashMap<Spur, u32> {
        &self.global_index
    }

    /// Get the number of globals (for compiler slot prediction)
    pub fn global_count(&self) -> usize {
        self.globals.len()
    }

    /// Get the native function table (for compiler optimization)
    pub fn native_table(&self) -> &[natives::NativeEntry] {
        &self.natives
    }

    /// Merge new documentation entries into the VM's doc map
    pub fn merge_docs(&mut self, new_docs: FxHashMap<Spur, DocEntry>) {
        self.docs.extend(new_docs);
    }

    /// Get the accumulated documentation map
    pub fn docs(&self) -> &FxHashMap<Spur, DocEntry> {
        &self.docs
    }

    /// Set external roots that must survive GC (e.g., macro closures)
    pub fn set_external_roots(&mut self, roots: Vec<HeapKey>) {
        self.external_roots = roots;
    }

    /// Format a stack trace from the current call frames
    pub fn format_stack_trace(&self) -> String {
        let mut trace = String::new();
        trace.push_str(&format!("Stack trace ({} frames):\n", self.frames.len()));
        for (i, frame) in self.frames.iter().rev().enumerate() {
            let proto = &self.prototypes[frame.proto_idx as usize];
            let name = match proto.name {
                Some(spur) => self.interner.resolve(&spur),
                None => "<anonymous>",
            };
            trace.push_str(&format!(
                "  {}: {} (proto #{}, ip {})\n",
                i, name, frame.proto_idx, frame.ip
            ));
        }
        if self.frames.is_empty() {
            trace.push_str("  <no frames>\n");
        }
        trace
    }

    /// Get the source span for the current instruction (for error reporting)
    fn current_span(&self) -> Option<prototype::Span> {
        let frame = self.frames.last()?;
        let proto = &self.prototypes[frame.proto_idx as usize];
        // Use ip - 1 since ip points to the *next* instruction after execution
        proto.span_for_ip(frame.ip.saturating_sub(1))
    }

    /// Build a stack trace with source locations
    fn build_stack_trace(&self) -> Vec<error::VMStackFrame> {
        self.frames
            .iter()
            .rev()
            .map(|frame| {
                let proto = &self.prototypes[frame.proto_idx as usize];
                let name = proto
                    .name
                    .map(|spur| self.interner.resolve(&spur).to_string());
                let span = proto
                    .span_for_ip(frame.ip.saturating_sub(1))
                    .map(|s| s.to_ast_span());
                error::VMStackFrame { name, span }
            })
            .collect()
    }

    /// Create a rich error from a VMError with current location and stack trace
    fn make_error(&self, kind: error::VMError) -> error::RichVMError {
        error::RichVMError {
            kind,
            span: self.current_span().map(|s| s.to_ast_span()),
            stack_trace: self.build_stack_trace(),
        }
    }

    /// The built-in exn effect ID
    const BUILTIN_EXN_ID: EffectId = EffectId(0xFFFF_0001);

    /// Route a catchable error through exn/raise.
    /// Returns Ok(()) if the error was successfully raised (handler will run).
    /// Returns Err with original error if not catchable or no exn handler.
    fn try_raise_error(&mut self, error: VMError) -> Result<(), VMError> {
        if !error.is_catchable() {
            return Err(error);
        }

        // Create error map: {:type :error-type :message "..."}
        let type_kw = self.interner.get_or_intern("type");
        let msg_kw = self.interner.get_or_intern("message");
        let error_type = self.interner.get_or_intern(error.error_type());

        let msg = error.to_string();
        let msg_obj = HeapObject::String(hipstr::HipStr::from(msg));
        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        let msg_key = self.heap.alloc_no_gc(msg_obj);
        let msg_value = VMValue::HeapRef(msg_key);

        // Build the error map
        let mut error_map = crate::collections::HashMap::new();
        error_map.insert(VMValue::Keyword(type_kw), VMValue::Keyword(error_type));
        error_map.insert(VMValue::Keyword(msg_kw), msg_value);

        let map_obj = HeapObject::Map(error_map);
        if self.heap.needs_gc() {
            let mut roots: Vec<HeapKey> = self.roots().collect();
            roots.push(msg_key);
            self.heap.collect(roots);
        }
        let map_key = self.heap.alloc_no_gc(map_obj);
        let error_value = VMValue::HeapRef(map_key);

        // Get the "raise" operation symbol
        let raise_spur = self.interner.get_or_intern("raise");

        // Perform exn/raise - if no handler, return original error (not "Unhandled effect")
        match self.handle_effect(Self::BUILTIN_EXN_ID, raise_spur, vec![error_value]) {
            Ok(()) => Ok(()),
            Err(_) => Err(error), // Return original error, not EffectNotHandled
        }
    }

    /// Run a prototype with arguments
    pub fn run(&mut self, proto_idx: u32, args: &[VMValue]) -> Result<VMValue, error::RichVMError> {
        self.setup_call(proto_idx, None, args)
            .map_err(|e| self.make_error(e))?;
        self.execute_rich()
    }

    /// Execute with rich error reporting
    fn execute_rich(&mut self) -> Result<VMValue, error::RichVMError> {
        loop {
            match self.step() {
                Ok(StepResult::Continue) => {}
                Ok(StepResult::Return(value)) => return Ok(value),
                Ok(StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                }) => {
                    if let Err(e) = self.handle_effect(effect_id, op_name, args) {
                        // Try to route through exn/raise if catchable
                        if let Err(e) = self.try_raise_error(e) {
                            return Err(self.make_error(e));
                        }
                    }
                }
                Err(e) => {
                    // Try to route through exn/raise if catchable
                    if let Err(e) = self.try_raise_error(e) {
                        return Err(self.make_error(e));
                    }
                }
            }
        }
    }

    /// Get heap (for native functions)
    pub fn heap(&self) -> &Heap {
        &self.heap
    }

    /// Get mutable heap
    pub fn heap_mut(&mut self) -> &mut Heap {
        &mut self.heap
    }

    /// Apply a function to arguments (for use by native functions)
    /// This allows native code to call closures and other native functions.
    /// Only executes until the new call frame returns, not the entire VM.
    /// Args are kept on the stack during execution to ensure GC doesn't collect them.
    pub fn apply(&mut self, func: VMValue, args: &[VMValue]) -> Result<VMValue, VMError> {
        match func {
            VMValue::HeapRef(key) => {
                // Set as function: (#{:a :b} :a) => :a
                if matches!(self.heap.get(key), Some(HeapObject::Set(_))) {
                    if args.len() != 1 {
                        return Err(VMError::ArityMismatch {
                            expected: 1,
                            got: args.len() as u8,
                        });
                    }
                    let lookup = args[0];
                    return match self.heap.get(key) {
                        Some(HeapObject::Set(set)) => {
                            if set.contains(&lookup) {
                                Ok(lookup)
                            } else {
                                Ok(VMValue::Nil)
                            }
                        }
                        _ => Ok(VMValue::Nil),
                    };
                }
                // Record frame depth before call
                let target_depth = self.frames.len();
                self.call_closure_with_args(key, args, false)?;
                // Execute only until we return to the original depth
                self.execute_until_depth(target_depth)
            }
            VMValue::NativeFn(idx) => {
                // Inhibit GC during native execution
                self.heap.inhibit_gc();
                let result = self.call_native_by_idx(idx as usize, args);
                self.heap.allow_gc();
                result
            }
            VMValue::Keyword(kw) => {
                // Keyword as function: (:key map) or (:key map default)
                if args.is_empty() || args.len() > 2 {
                    return Err(VMError::ArityMismatch {
                        expected: 1,
                        got: args.len() as u8,
                    });
                }
                let map_arg = args[0];
                let default = args.get(1).copied().unwrap_or(VMValue::Nil);
                let result = match map_arg {
                    VMValue::HeapRef(key) => match self.heap.get(key) {
                        Some(HeapObject::Map(map)) => {
                            map.get(&VMValue::Keyword(kw)).copied().unwrap_or(default)
                        }
                        Some(HeapObject::Variant(inst)) => {
                            let type_id = inst.type_id();
                            let variant_idx = inst.variant_idx();
                            if let Some(typedef) = self.type_registry.get(type_id) {
                                let vdef = &typedef.variants[variant_idx as usize];
                                if let Some(&field_idx) = vdef.field_index.get(&kw) {
                                    inst.fields[field_idx as usize]
                                } else {
                                    default
                                }
                            } else {
                                default
                            }
                        }
                        _ => default,
                    },
                    _ => default,
                };
                Ok(result)
            }
            _ => Err(VMError::NotCallable),
        }
    }

    /// Execute until frame depth returns to target level.
    /// Used by apply() to run only the invoked call, not the rest of the program.
    fn execute_until_depth(&mut self, target_depth: usize) -> Result<VMValue, VMError> {
        loop {
            match self.step() {
                Ok(StepResult::Continue) => {
                    // Check if we've returned from the call
                    if self.frames.len() == target_depth {
                        // The result should be on top of the stack
                        return self.stack.pop().ok_or(VMError::StackUnderflow);
                    }
                }
                Ok(StepResult::Return(value)) => {
                    // Full VM return - should only happen if target_depth was 0
                    return Ok(value);
                }
                Ok(StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                }) => {
                    // Handle effects within the applied function
                    if let Err(e) = self.handle_effect(effect_id, op_name, args) {
                        self.try_raise_error(e)?;
                    }
                }
                Err(e) => {
                    self.try_raise_error(e)?;
                }
            }
        }
    }

    /// Generate a fresh unique effect ID
    pub fn fresh_effect_id(&mut self) -> EffectId {
        let id = EffectId(self.next_effect_id);
        self.next_effect_id += 1;
        id
    }

    /// Look up an effect's name by its ID (scanning the heap)
    fn effect_name_by_id(&self, effect_id: EffectId) -> Option<String> {
        for obj in self.heap.iter_objects() {
            if let HeapObject::Effect(e) = obj {
                if e.id == effect_id {
                    return e.name.map(|spur| self.interner.resolve(&spur).to_string());
                }
            }
        }
        None
    }

    /// Register all native functions as globals
    ///
    /// This allows native functions like `first`, `rest`, `count`, etc. to be
    /// called by name from user code.
    fn register_natives(&mut self) {
        let entries: Vec<(usize, &'static str)> = self
            .natives
            .iter()
            .enumerate()
            .map(|(idx, entry)| (idx, entry.name))
            .collect();
        for (idx, name) in entries {
            let spur = self.interner.get_or_intern(name);
            self.set_global(spur, VMValue::NativeFn(idx as u16));
        }
    }

    /// Register optic singletons as globals
    fn register_optic_globals(&mut self) {
        let each_spur = self.interner.get_or_intern("each");
        let each_val = VMValue::HeapRef(self.optic_each);
        self.set_global(each_spur, each_val);

        let vals_spur = self.interner.get_or_intern("_vals");
        let vals_val = VMValue::HeapRef(self.optic_vals);
        self.set_global(vals_spur, vals_val);

        let keys_spur = self.interner.get_or_intern("_keys");
        let keys_val = VMValue::HeapRef(self.optic_keys);
        self.set_global(keys_spur, keys_val);

        let deep_spur = self.interner.get_or_intern("deep");
        let deep_val = VMValue::HeapRef(self.optic_deep);
        self.set_global(deep_spur, deep_val);

        let deep_upper_spur = self.interner.get_or_intern("DEEP");
        self.set_global(deep_upper_spur, deep_val);

        let some_spur = self.interner.get_or_intern("_some");
        let some_val = VMValue::HeapRef(self.optic_some);
        self.set_global(some_spur, some_val);
    }

    /// Register built-in effects (exn, console, random)
    ///
    /// These use reserved effect IDs (high values) to avoid collision with
    /// user-created effects.
    fn register_builtin_effects(&mut self) {
        use heap::Effect;

        // Reserved effect IDs (matching tree-walker)
        const BUILTIN_EXN_ID: u64 = 0xFFFF_0001;
        const BUILTIN_CONSOLE_ID: u64 = 0xFFFF_0002;
        const BUILTIN_RANDOM_ID: u64 = 0xFFFF_0004;

        // exn effect: (raise [msg])
        let exn_name = self.interner.get_or_intern("exn");
        let raise_op = self.interner.get_or_intern("raise");
        let exn_effect = Effect {
            id: EffectId(BUILTIN_EXN_ID),
            name: Some(exn_name),
            ops: vec![(raise_op, 1)].into_boxed_slice(),
        };
        let exn_key = self.heap.insert_constant(HeapObject::Effect(exn_effect));
        self.set_global(exn_name, VMValue::HeapRef(exn_key));

        // console effect: (print [v]), (println [v]), (read-line [])
        let console_name = self.interner.get_or_intern("console");
        let print_op = self.interner.get_or_intern("print");
        let println_op = self.interner.get_or_intern("println");
        let read_line_op = self.interner.get_or_intern("read-line");
        let console_effect = Effect {
            id: EffectId(BUILTIN_CONSOLE_ID),
            name: Some(console_name),
            ops: vec![(print_op, 1), (println_op, 1), (read_line_op, 0)].into_boxed_slice(),
        };
        let console_key = self
            .heap
            .insert_constant(HeapObject::Effect(console_effect));
        self.set_global(console_name, VMValue::HeapRef(console_key));

        // random effect: (rand []), (rand-int [n])
        let random_name = self.interner.get_or_intern("random");
        let rand_op = self.interner.get_or_intern("rand");
        let rand_int_op = self.interner.get_or_intern("rand-int");
        let random_effect = Effect {
            id: EffectId(BUILTIN_RANDOM_ID),
            name: Some(random_name),
            ops: vec![(rand_op, 0), (rand_int_op, 1)].into_boxed_slice(),
        };
        let random_key = self.heap.insert_constant(HeapObject::Effect(random_effect));
        self.set_global(random_name, VMValue::HeapRef(random_key));
    }

    /// Register a native handler for an effect (by EffectId).
    /// Native handlers act as fallbacks - Hoatzin handlers take precedence.
    pub fn register_native_handler(&mut self, effect_id: EffectId, handler: NativeHandler) {
        self.native_handlers.insert(effect_id, handler);
    }

    /// Register a dynamic native function (host callback).
    /// Returns the native index assigned. The function is immediately
    /// available as a global binding in the VM.
    pub fn register_dynamic_native(
        &mut self,
        name: &str,
        func: Rc<dyn Fn(&mut VM, &[VMValue]) -> Result<VMValue, VMError>>,
    ) -> u16 {
        let idx = (self.natives.len() + self.dynamic_natives.len()) as u16;
        self.dynamic_natives.push(DynamicNative {
            name: name.to_string(),
            func,
        });
        let spur = self.interner.get_or_intern(name);
        self.set_global(spur, VMValue::NativeFn(idx));
        idx
    }

    /// Get the EffectId for a built-in effect by name.
    /// Returns None if the name doesn't resolve to an effect.
    pub fn get_effect_id(&self, name: &str) -> Option<EffectId> {
        let spur = self.interner.get(name)?;
        match self.get_global(spur)? {
            VMValue::HeapRef(key) => {
                if let Some(HeapObject::Effect(e)) = self.heap.get(key) {
                    return Some(e.id);
                }
                None
            }
            _ => None,
        }
    }

    /// Get reference to the string interner
    pub fn interner(&self) -> &Rodeo {
        &self.interner
    }

    /// Get mutable reference to the string interner
    pub fn interner_mut(&mut self) -> &mut Rodeo {
        &mut self.interner
    }

    /// Get the type registry
    pub fn type_registry(&self) -> &TypeRegistry {
        &self.type_registry
    }

    /// Get mutable type registry
    pub fn type_registry_mut(&mut self) -> &mut TypeRegistry {
        &mut self.type_registry
    }

    /// Allocate a string on the heap at runtime (GC-safe).
    /// Use this for computed strings during execution.
    pub fn alloc_string(&mut self, s: impl Into<String>) -> VMValue {
        use hipstr::HipStr;
        let hip = HipStr::from(s.into()); // Force owned to avoid borrowed lifetime issues
        let roots: Vec<HeapKey> = self.collect_roots();
        let key = self.heap.alloc(HeapObject::String(hip), roots);
        VMValue::HeapRef(key)
    }

    /// Allocate a string constant on the heap (no GC check).
    /// Use this for compile-time literals only.
    pub fn alloc_string_constant(&mut self, s: &str) -> VMValue {
        use hipstr::HipStr;
        let hip = HipStr::from(s.to_owned());
        let key = self.heap.insert_constant(HeapObject::String(hip));
        VMValue::HeapRef(key)
    }

    // --- Execution ---

    fn setup_call(
        &mut self,
        proto_idx: u32,
        closure: Option<HeapKey>,
        args: &[VMValue],
    ) -> Result<(), VMError> {
        let proto = &self.prototypes[proto_idx as usize];
        let required = proto.arity as usize;
        let n_args = args.len();

        if proto.is_variadic {
            if n_args < required {
                return Err(VMError::ArityMismatch {
                    expected: required as u8,
                    got: n_args as u8,
                });
            }

            let fp = self.stack.len() as u32;

            // Push required args
            for arg in args.iter().take(required) {
                self.stack.push(*arg);
            }

            // Pack rest args into a list
            let rest_args: crate::collections::Vector<VMValue> =
                args.iter().skip(required).copied().collect();
            let seq = heap::SeqData {
                data: rest_args,
                kind: heap::SeqKind::List,
            };
            if self.heap.needs_gc() {
                let roots: Vec<HeapKey> = self.roots().collect();
                self.heap.collect(roots);
            }
            let rest_key = self.heap.alloc_no_gc(HeapObject::Seq(seq));
            self.stack.push(VMValue::HeapRef(rest_key));

            // Pad remaining locals with nil
            for _ in (required + 1)..proto.locals as usize {
                self.stack.push(VMValue::Nil);
            }

            self.frames
                .push(CallFrame::new(proto_idx, fp, closure, n_args as u8));
        } else {
            let fp = self.stack.len() as u32;

            // Push args as locals
            for arg in args {
                self.stack.push(*arg);
            }

            // Pad remaining locals with nil
            for _ in args.len()..proto.locals as usize {
                self.stack.push(VMValue::Nil);
            }

            self.frames
                .push(CallFrame::new(proto_idx, fp, closure, args.len() as u8));
        }

        Ok(())
    }

    /// Optimized call setup - args are already on stack
    fn setup_call_inplace(
        &mut self,
        proto_idx: u32,
        closure: Option<HeapKey>,
        n_args: usize,
    ) -> Result<(), VMError> {
        let proto = &self.prototypes[proto_idx as usize];
        let required = proto.arity as usize;

        // Handle variadic functions
        if proto.is_variadic {
            if n_args < required {
                return Err(VMError::ArityMismatch {
                    expected: required as u8,
                    got: n_args as u8,
                });
            }

            // Pop all args from stack
            let args_start = self.stack.len() - n_args;
            let args: Vec<VMValue> = self.stack.drain(args_start..).collect();

            // fp points to where args will be pushed
            let fp = self.stack.len() as u32;

            // Push required args
            for arg in args.iter().take(required) {
                self.stack.push(*arg);
            }

            // Pack rest args into a list
            let rest_args: crate::collections::Vector<VMValue> =
                args.iter().skip(required).copied().collect();
            let seq = heap::SeqData {
                data: rest_args,
                kind: heap::SeqKind::List,
            };
            if self.heap.needs_gc() {
                let roots: Vec<HeapKey> = self.roots().collect();
                self.heap.collect(roots);
            }
            let rest_key = self.heap.alloc_no_gc(HeapObject::Seq(seq));
            self.stack.push(VMValue::HeapRef(rest_key));

            // Pad remaining locals (after rest param) with nil
            for _ in (required + 1)..proto.locals as usize {
                self.stack.push(VMValue::Nil);
            }

            self.frames
                .push(CallFrame::new(proto_idx, fp, closure, n_args as u8));
        } else {
            // Non-variadic: args already on stack, fp points to first arg
            let fp = (self.stack.len() - n_args) as u32;

            // Pad remaining locals with nil
            for _ in n_args..proto.locals as usize {
                self.stack.push(VMValue::Nil);
            }

            self.frames
                .push(CallFrame::new(proto_idx, fp, closure, n_args as u8));
        }

        Ok(())
    }

    fn execute(&mut self) -> Result<VMValue, VMError> {
        loop {
            match self.step() {
                Ok(StepResult::Continue) => {}
                Ok(StepResult::Return(value)) => return Ok(value),
                Ok(StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                }) => {
                    if let Err(e) = self.handle_effect(effect_id, op_name, args) {
                        self.try_raise_error(e)?;
                    }
                }
                Err(e) => {
                    self.try_raise_error(e)?;
                }
            }
        }
    }

    #[inline(always)]
    fn step(&mut self) -> Result<StepResult, VMError> {
        let frame = self.frames.last_mut().ok_or(VMError::StackUnderflow)?;

        // Check if this is a continuation body frame that should return at a specific IP
        // This handles the case where a continuation with no captured frames resumes
        // and needs to return to the handler when the body completes (at PopHandler)
        if let Some(return_ip) = frame.return_at_ip {
            if frame.ip == return_ip {
                // Body completed - return the top of stack value
                let result = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let frame = self.frames.pop().ok_or(VMError::StackUnderflow)?;
                let cleanup_fp = frame.cleanup_fp.unwrap_or(frame.fp);
                self.stack.truncate(cleanup_fp as usize);
                if let Some(handler_idx) = frame.remask_handler_idx {
                    if let Some(handler) = self.handlers.get_mut(handler_idx) {
                        handler.masked = true;
                    }
                }

                if self.frames.is_empty() {
                    return Ok(StepResult::Return(result));
                }

                self.stack.push(result);
                return Ok(StepResult::Continue);
            }
        }

        let proto_idx = frame.proto_idx as usize;
        let fp = frame.fp;
        let proto = &self.prototypes[proto_idx];
        let instr = proto.code[frame.ip as usize];
        let (op, a1, a2, a3) = decode(instr);

        frame.ip += 1;

        match OpCode::from_u8(op).ok_or(VMError::InvalidOpcode(op))? {
            // --- Stack ---
            OpCode::Const => {
                let idx = arg_u16(a1, a2) as usize;
                let v = self.prototypes[proto_idx].constants[idx];
                self.stack.push(v);
            }

            OpCode::Pop => {
                self.stack.pop().ok_or(VMError::StackUnderflow)?;
            }

            OpCode::Dup => {
                let v = *self.stack.last().ok_or(VMError::StackUnderflow)?;
                self.stack.push(v);
            }

            // --- Locals ---
            OpCode::GetLocal => {
                let idx = fp as usize + a1 as usize;
                let v = *self
                    .stack
                    .get(idx)
                    .ok_or_else(|| VMError::IndexOutOfBounds {
                        index: idx as i64,
                        len: self.stack.len(),
                    })?;
                self.stack.push(v);
            }

            OpCode::SetLocal => {
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let idx = fp as usize + a1 as usize;
                let stack_len = self.stack.len();
                let slot = self.stack.get_mut(idx).ok_or(VMError::IndexOutOfBounds {
                    index: idx as i64,
                    len: stack_len,
                })?;
                *slot = v;
            }

            // --- Upvalues ---
            OpCode::GetUpvalue => {
                let frame = self.frames.last().ok_or(VMError::StackUnderflow)?;
                let closure_key = frame
                    .closure
                    .ok_or(VMError::TypeError("no closure for upvalue access"))?;
                let upvalue = match self.heap.get(closure_key) {
                    Some(HeapObject::Closure(c)) => c.upvalues[a1 as usize],
                    _ => return Err(VMError::TypeError("expected closure")),
                };
                self.stack.push(upvalue);
            }

            OpCode::SetUpvalue => {
                let frame = self.frames.last().ok_or(VMError::StackUnderflow)?;
                let closure_key = frame
                    .closure
                    .ok_or(VMError::TypeError("no closure for upvalue access"))?;
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                match self.heap.get_mut(closure_key) {
                    Some(HeapObject::Closure(c)) => c.upvalues[a1 as usize] = v,
                    _ => return Err(VMError::TypeError("expected closure")),
                };
            }

            // --- Globals ---
            OpCode::GetGlobal => {
                let idx = arg_u16(a1, a2) as usize;
                let sym = match self.prototypes[proto_idx].constants[idx] {
                    VMValue::Symbol(s) => s,
                    _ => return Err(VMError::TypeError("expected symbol")),
                };
                let v = self.get_global(sym).ok_or_else(|| {
                    VMError::UndefinedGlobal(self.interner.resolve(&sym).to_string())
                })?;
                self.stack.push(v);
            }

            OpCode::GetGlobalSlot => {
                let slot = arg_u16(a1, a2) as usize;
                let v = self.globals[slot];
                self.stack.push(v);
            }

            OpCode::SetGlobal => {
                let idx = arg_u16(a1, a2) as usize;
                let sym = match self.prototypes[proto_idx].constants[idx] {
                    VMValue::Symbol(s) => s,
                    _ => return Err(VMError::TypeError("expected symbol")),
                };
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                self.set_global(sym, v);
                if let VMValue::HeapRef(key) = v {
                    if let Some(HeapObject::Effect(e)) = self.heap.get_mut(key) {
                        if e.name.is_none() {
                            e.name = Some(sym);
                        }
                    }
                }
            }

            OpCode::DefGlobal => {
                let idx = arg_u16(a1, a2) as usize;
                let sym = match self.prototypes[proto_idx].constants[idx] {
                    VMValue::Symbol(s) => s,
                    _ => return Err(VMError::TypeError("expected symbol")),
                };
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                self.set_global(sym, v);
                if let VMValue::HeapRef(key) = v {
                    if let Some(HeapObject::Effect(e)) = self.heap.get_mut(key) {
                        if e.name.is_none() {
                            e.name = Some(sym);
                        }
                    }
                }
            }

            // --- Arithmetic ---
            OpCode::Add => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.binary_add(a, b)?;
                self.stack.push(result);
            }

            OpCode::Sub => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.binary_sub(a, b)?;
                self.stack.push(result);
            }

            OpCode::Mul => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.binary_mul(a, b)?;
                self.stack.push(result);
            }

            OpCode::Div => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.binary_div(a, b)?;
                self.stack.push(result);
            }

            OpCode::Rem => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.binary_rem(a, b)?;
                self.stack.push(result);
            }

            OpCode::Neg => {
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.unary_neg(v)?;
                self.stack.push(result);
            }

            // --- Comparison ---
            OpCode::Eq => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                self.stack.push(VMValue::Bool(self.values_equal(a, b)));
            }

            OpCode::Ne => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                self.stack.push(VMValue::Bool(!self.values_equal(a, b)));
            }

            OpCode::Lt => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.compare_lt(a, b)?;
                self.stack.push(VMValue::Bool(result));
            }

            OpCode::Le => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.compare_le(a, b)?;
                self.stack.push(VMValue::Bool(result));
            }

            OpCode::Gt => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.compare_gt(a, b)?;
                self.stack.push(VMValue::Bool(result));
            }

            OpCode::Ge => {
                let b = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let a = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let result = self.compare_ge(a, b)?;
                self.stack.push(VMValue::Bool(result));
            }

            // --- Logic ---
            OpCode::Not => {
                let v = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                self.stack.push(VMValue::Bool(v.is_falsy()));
            }

            // --- Control flow ---
            OpCode::Jump => {
                let offset = arg_i16(a1, a2);
                let frame = self.frames.last_mut().unwrap();
                frame.ip = (frame.ip as i32 + offset as i32) as u32;
            }

            OpCode::JumpIfFalse => {
                let cond = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                if cond.is_falsy() {
                    let offset = arg_i16(a1, a2);
                    let frame = self.frames.last_mut().unwrap();
                    frame.ip = (frame.ip as i32 + offset as i32) as u32;
                }
            }

            OpCode::JumpIfTrue => {
                let cond = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                if cond.is_truthy() {
                    let offset = arg_i16(a1, a2);
                    let frame = self.frames.last_mut().unwrap();
                    frame.ip = (frame.ip as i32 + offset as i32) as u32;
                }
            }

            // --- Functions ---
            OpCode::Call => {
                let n_args = a1 as usize;
                // Non-tail calls always return None
                let _ = self.do_call(n_args, false)?;
            }

            OpCode::TailCall => {
                let n_args = a1 as usize;
                // do_call returns Some(value) if this was a native tail call
                // in the last frame and we should return immediately
                if let Some(result) = self.do_call(n_args, true)? {
                    return Ok(StepResult::Return(result));
                }
            }

            OpCode::Return => {
                let result = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let frame = self.frames.pop().unwrap();
                if let Some(handler_idx) = frame.remask_handler_idx {
                    if let Some(handler) = self.handlers.get_mut(handler_idx) {
                        handler.masked = true;
                    }
                }

                // Check for handler return
                if let Some(guard) = frame.handler_guard {
                    // Check if continuation was resumed
                    let resumed = match self.heap.get(guard.continuation_key) {
                        Some(HeapObject::Continuation(c)) => c.resumed,
                        _ => true, // If continuation is gone, assume it was used
                    };

                    if !resumed {
                        // Abort case: handler returned without resuming continuation.
                        // The handler's result becomes the with-handler's result.
                        // Truncate to prompt point and jump past the body.
                        self.stack.truncate(guard.prompt_sp as usize);
                        self.frames.truncate(guard.prompt_frame as usize);

                        // Validate remaining frames have valid FPs
                        #[cfg(debug_assertions)]
                        {
                            let stack_len = self.stack.len();
                            for (i, frame) in self.frames.iter().enumerate() {
                                debug_assert!(
                                    (frame.fp as usize) <= stack_len,
                                    "Frame {} has stale fp {} (stack len {})",
                                    i,
                                    frame.fp,
                                    stack_len
                                );
                            }
                        }

                        // Pop the handler
                        self.handlers.pop();

                        if self.frames.is_empty() {
                            return Ok(StepResult::Return(result));
                        }

                        // Jump to after PopHandler to skip remaining body code
                        if let Some(frame) = self.frames.last_mut() {
                            frame.ip = guard.abort_ip;
                        }

                        self.stack.push(result);
                        return Ok(StepResult::Continue);
                    } else {
                        // Resume case: handler called (k val) and then returned.
                        // Check if we're returning to another handler frame (nested handler)
                        // or to a regular frame (outermost handler).
                        let has_parent_handler =
                            self.frames.iter().any(|f| f.handler_guard.is_some());

                        if has_parent_handler {
                            // Nested handler returning after resume.
                            // Result flows back to parent handler's (k val) call.
                            // Don't pop the effect handler (deep handler semantics).
                            if let Some(handler) = self.handlers.last_mut() {
                                handler.masked = false;
                                // Restore the prompt to the parent resumption site. The nested
                                // handler clause may have called `(k v)`, which updates the
                                // prompt to that (inner) resumption site; when the clause
                                // returns, we must revert to the prompt for the surrounding
                                // continuation (stored in the guard).
                                handler.prompt_sp = guard.prompt_sp;
                                handler.prompt_frame = guard.prompt_frame;
                            }
                            // Restore the stack to the handler prompt. Using the returning
                            // frame's fp can truncate below the current prompt in deep
                            // handler scenarios (prompt is updated on resume), which can
                            // break subsequent continuation captures.
                            self.stack.truncate(guard.prompt_sp as usize);

                            if self.frames.is_empty() {
                                return Ok(StepResult::Return(result));
                            }

                            self.stack.push(result);
                            // Force the delimiter (ContinuationReturn/body frame) to return
                            // immediately so the result flows back to the parent `(k v)` call.
                            // Otherwise we'd keep executing the suspended continuation past the
                            // effect site, which is incorrect for deep handler semantics.
                            if let Some(frame) = self.frames.last_mut() {
                                if let Some(return_ip) = frame.return_at_ip {
                                    frame.ip = return_ip;
                                }
                            }
                            return Ok(StepResult::Continue);
                        } else {
                            // Outermost handler returning after resume.
                            // The handler result is the with-handler result.
                            // Pop the handler and jump to abort_ip.
                            self.stack.truncate(guard.prompt_sp as usize);
                            self.frames.truncate(guard.prompt_frame as usize);
                            self.handlers.pop();

                            if self.frames.is_empty() {
                                return Ok(StepResult::Return(result));
                            }

                            if let Some(frame) = self.frames.last_mut() {
                                frame.ip = guard.abort_ip;
                            }

                            self.stack.push(result);
                            return Ok(StepResult::Continue);
                        }
                    }
                }

                // Normal return: pop locals
                self.stack.truncate(frame.fp as usize);

                if self.frames.is_empty() {
                    return Ok(StepResult::Return(result));
                }

                self.stack.push(result);
            }

            OpCode::MakeClosure => {
                let proto_idx = arg_u16(a1, a2) as u32;
                let n_upvalues = a3 as usize;
                let proto = &self.prototypes[proto_idx as usize];

                // Pop upvalues from stack (in reverse order)
                let mut upvalues = Vec::with_capacity(n_upvalues);
                for _ in 0..n_upvalues {
                    upvalues.push(self.stack.pop().ok_or(VMError::StackUnderflow)?);
                }
                upvalues.reverse();

                // Create closure on heap
                let clause = ClauseInfo {
                    proto_idx,
                    arity: proto.arity,
                    is_variadic: proto.is_variadic,
                    patterns: Box::new([]),
                    guard_proto_idx: None,
                };
                let closure = Closure {
                    clauses: Rc::from(vec![clause]),
                    upvalues: upvalues.into_boxed_slice(),
                };
                if self.heap.needs_gc() {
                    let roots: Vec<HeapKey> = self.roots().collect();
                    self.heap.collect(roots);
                }
                let key = self.heap.alloc_no_gc(HeapObject::Closure(closure));
                self.stack.push(VMValue::HeapRef(key));
            }

            OpCode::MakeMultiClosure => {
                let template_idx = arg_u16(a1, a2) as usize;
                let n_upvalues = a3 as usize;

                let template_key = match self.prototypes[proto_idx].constants.get(template_idx) {
                    Some(VMValue::HeapRef(key)) => *key,
                    _ => return Err(VMError::TypeError("expected closure template constant")),
                };

                let template = match self.heap.get(template_key) {
                    Some(HeapObject::ClosureTemplate(t)) => t,
                    _ => return Err(VMError::TypeError("expected closure template")),
                };

                let mut upvalues = Vec::with_capacity(n_upvalues);
                for _ in 0..n_upvalues {
                    upvalues.push(self.stack.pop().ok_or(VMError::StackUnderflow)?);
                }
                upvalues.reverse();

                let closure = Closure {
                    clauses: template.clauses.clone(),
                    upvalues: upvalues.into_boxed_slice(),
                };
                if self.heap.needs_gc() {
                    let roots: Vec<HeapKey> = self.roots().collect();
                    self.heap.collect(roots);
                }
                let key = self.heap.alloc_no_gc(HeapObject::Closure(closure));
                self.stack.push(VMValue::HeapRef(key));
            }

            // --- Collections ---
            // Note: We use regular alloc here (not interning) for performance.
            // Interning happens lazily when collections are used as map keys.
            OpCode::MakeList => {
                let n = arg_u16(a1, a2) as usize;
                let start = self.stack.len().saturating_sub(n);
                let items: crate::collections::Vector<VMValue> =
                    self.stack.drain(start..).collect();
                let seq = SeqData {
                    data: items,
                    kind: SeqKind::List,
                };
                let key = self.heap.alloc_no_gc(HeapObject::Seq(seq));
                self.stack.push(VMValue::HeapRef(key));
            }

            OpCode::MakeVector => {
                let n = arg_u16(a1, a2) as usize;
                let start = self.stack.len().saturating_sub(n);
                let items: crate::collections::Vector<VMValue> =
                    self.stack.drain(start..).collect();
                let seq = SeqData {
                    data: items,
                    kind: SeqKind::Vector,
                };
                let key = self.heap.alloc_no_gc(HeapObject::Seq(seq));
                self.stack.push(VMValue::HeapRef(key));
            }

            OpCode::MakeMap => {
                let n_pairs = arg_u16(a1, a2) as usize;
                let start = self.stack.len().saturating_sub(n_pairs * 2);
                let items: Vec<VMValue> = self.stack.drain(start..).collect();
                let mut map = crate::collections::HashMap::new();
                for chunk in items.chunks(2) {
                    if chunk.len() == 2 {
                        // Canonicalize collection keys for content-based equality
                        let k = self.canonicalize_key(chunk[0]);
                        map.insert(k, chunk[1]);
                    }
                }
                // NOTE: Do NOT trigger GC here — the map's keys/values have been
                // drained from the stack and live only in the local `map` variable,
                // invisible to the GC's root tracing. Use alloc_no_gc instead.
                let key = self.heap.alloc_no_gc(HeapObject::Map(map));
                self.stack.push(VMValue::HeapRef(key));
            }

            OpCode::MakeSet => {
                let n = arg_u16(a1, a2) as usize;
                let start = self.stack.len().saturating_sub(n);
                let items: Vec<VMValue> = self.stack.drain(start..).collect();
                // Canonicalize collection members for content-based equality
                let set: crate::collections::HashSet<VMValue> = items
                    .into_iter()
                    .map(|v| self.canonicalize_key(v))
                    .collect();
                let key = self.heap.alloc_no_gc(HeapObject::Set(set));
                self.stack.push(VMValue::HeapRef(key));
            }

            // --- ADT ---
            OpCode::MakeVariant => {
                let type_id = type_registry::TypeId(arg_u16(a1, a2));
                let variant_idx = a3;
                let field_count = match self.type_registry.get(type_id) {
                    Some(typedef) => {
                        let vdef = &typedef.variants[variant_idx as usize];
                        vdef.field_names.len()
                    }
                    None => return Err(VMError::TypeError("unknown variant type")),
                };

                // For zero-field variants, push pre-allocated singleton
                if field_count == 0 {
                    let singleton_key = self.type_registry.get(type_id).unwrap().variants
                        [variant_idx as usize]
                        .singleton_key
                        .expect("singleton missing for zero-field variant");
                    self.stack.push(VMValue::HeapRef(singleton_key));
                } else {
                    let start = self.stack.len().saturating_sub(field_count);
                    let fields: Vec<VMValue> = self.stack.drain(start..).collect();
                    let inst = VariantInstance::new(type_id, variant_idx, fields);
                    let key = self.heap.alloc_no_gc(HeapObject::Variant(inst));
                    self.stack.push(VMValue::HeapRef(key));
                }
            }

            // --- Effects ---
            OpCode::PushHandler => {
                // PushHandler effect_const_lo effect_const_hi _
                // Stack: [... handler] where handler is either a closure or a dispatch table (map)
                let effect_idx = arg_u16(a1, a2) as usize;
                let current_ip = self.frames.last().unwrap().ip;
                let proto = &self.prototypes[self.frames.last().unwrap().proto_idx as usize];

                // Get effect value - either from stack (new pattern) or from global via symbol (old pattern)
                let effect_const = proto.constants[effect_idx];
                let effect_id = match effect_const {
                    VMValue::HeapRef(key) => {
                        // Effect value directly in constant
                        match self.heap.get(key) {
                            Some(HeapObject::Effect(e)) => e.id,
                            _ => return Err(VMError::TypeError("expected effect")),
                        }
                    }
                    VMValue::Symbol(s) => {
                        // Look up global to get effect value
                        let global = self.get_global(s).ok_or_else(|| {
                            VMError::UndefinedGlobal(self.interner.resolve(&s).to_string())
                        })?;
                        match global {
                            VMValue::HeapRef(key) => match self.heap.get(key) {
                                Some(HeapObject::Effect(e)) => e.id,
                                _ => return Err(VMError::TypeError("expected effect")),
                            },
                            _ => return Err(VMError::TypeError("expected effect")),
                        }
                    }
                    _ => return Err(VMError::TypeError("expected symbol or effect for handler")),
                };

                // Pop handler from stack - can be closure (simple) or map (dispatch table)
                let handler_value = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let (handler_closure, dispatch_table) = match handler_value {
                    VMValue::HeapRef(key) => match self.heap.get(key) {
                        Some(HeapObject::Closure(_)) => (Some(key), None),
                        Some(HeapObject::Map(_)) => (None, Some(key)),
                        _ => return Err(VMError::TypeError("expected closure or map for handler")),
                    },
                    VMValue::Nil => (None, None),
                    _ => {
                        return Err(VMError::TypeError(
                            "expected closure, map, or nil for handler",
                        ));
                    }
                };

                // For simple handlers, get the prototype info from the closure
                let (handler_proto, handler_ip) = if let Some(key) = handler_closure {
                    match self.heap.get(key) {
                        Some(HeapObject::Closure(c)) => {
                            let clause = c.clauses.first().ok_or(VMError::NotCallable)?;
                            (clause.proto_idx, 0u32)
                        }
                        _ => return Err(VMError::TypeError("expected closure")),
                    }
                } else {
                    (0, 0)
                };

                // Find matching PopHandler to compute abort_ip
                // Scan forward from current IP, tracking nesting depth
                let abort_ip = {
                    let mut depth = 1;
                    let mut scan_ip = current_ip;
                    while (scan_ip as usize) < proto.code.len() {
                        let (scan_op, _, _, _) = decode(proto.code[scan_ip as usize]);
                        if let Some(OpCode::PushHandler) = OpCode::from_u8(scan_op) {
                            depth += 1;
                        } else if let Some(OpCode::PopHandler) = OpCode::from_u8(scan_op) {
                            depth -= 1;
                            if depth == 0 {
                                break;
                            }
                        }
                        scan_ip += 1;
                    }
                    let result = scan_ip + 1; // IP after PopHandler
                    debug_assert!(
                        result <= proto.code.len() as u32,
                        "abort_ip {} exceeds code length {}",
                        result,
                        proto.code.len()
                    );
                    result.min(proto.code.len() as u32)
                };

                self.handlers.push(Handler {
                    effect_id,
                    handler_ip,
                    handler_proto,
                    handler_closure,
                    dispatch_table,
                    prompt_sp: self.stack.len() as u32,
                    prompt_frame: self.frames.len() as u32,
                    install_prompt_sp: self.stack.len() as u32,
                    install_prompt_frame: self.frames.len() as u32,
                    masked: false,
                    abort_ip,
                });
            }

            OpCode::PopHandler => {
                self.handlers.pop();
            }

            OpCode::Perform => {
                // Perform effect_const_lo effect_const_hi n_args
                // For old pattern: effect symbol in constant, args on stack
                // For new pattern (Phase 4): effect value on stack, op_name on stack, args on stack
                let effect_idx = arg_u16(a1, a2) as usize;
                let n_args = a3 as usize;
                let proto = &self.prototypes[self.frames.last().unwrap().proto_idx as usize];
                let effect_const = proto.constants[effect_idx];

                // Get effect_id and op_name from the constant
                let (effect_id, op_name) = match effect_const {
                    VMValue::Symbol(s) => {
                        // Old pattern: symbol names both the effect and the operation
                        // Look up global to get effect value
                        let global = self.get_global(s).ok_or_else(|| {
                            VMError::UndefinedGlobal(self.interner.resolve(&s).to_string())
                        })?;
                        match global {
                            VMValue::HeapRef(key) => match self.heap.get(key) {
                                Some(HeapObject::Effect(e)) => (e.id, s), // Use symbol as op_name too
                                _ => return Err(VMError::TypeError("expected effect")),
                            },
                            _ => return Err(VMError::TypeError("expected effect")),
                        }
                    }
                    _ => return Err(VMError::TypeError("expected symbol for effect")),
                };

                // Pop args from stack
                let args_start = self.stack.len().saturating_sub(n_args);
                let args: Vec<VMValue> = self.stack.drain(args_start..).collect();

                return Ok(StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                });
            }

            OpCode::PerformOp => {
                // PerformOp effect_const op_const n_args
                // Used for qualified symbols like gen/yield
                let effect_idx = a1 as usize;
                let op_idx = a2 as usize;
                let n_args = a3 as usize;
                let proto = &self.prototypes[self.frames.last().unwrap().proto_idx as usize];

                // Get effect symbol from constant
                let effect_sym = match proto.constants[effect_idx] {
                    VMValue::Symbol(s) => s,
                    _ => return Err(VMError::TypeError("expected symbol for effect")),
                };

                // Get operation name symbol from constant
                let op_name = match proto.constants[op_idx] {
                    VMValue::Symbol(s) => s,
                    _ => return Err(VMError::TypeError("expected symbol for operation")),
                };

                // Look up effect from global
                let global = self.get_global(effect_sym).ok_or_else(|| {
                    VMError::UndefinedGlobal(self.interner.resolve(&effect_sym).to_string())
                })?;
                let effect_id = match global {
                    VMValue::HeapRef(key) => match self.heap.get(key) {
                        Some(HeapObject::Effect(e)) => e.id,
                        _ => return Err(VMError::TypeError("expected effect")),
                    },
                    _ => return Err(VMError::TypeError("expected effect")),
                };

                // Pop args from stack
                let args_start = self.stack.len().saturating_sub(n_args);
                let args: Vec<VMValue> = self.stack.drain(args_start..).collect();

                return Ok(StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                });
            }

            OpCode::Resume => {
                // Pop resume_value, then continuation
                let resume_value = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                let cont_key = match self.stack.pop().ok_or(VMError::StackUnderflow)? {
                    VMValue::HeapRef(key) => key,
                    _ => return Err(VMError::TypeError("expected continuation")),
                };

                // Share the same continuation resumption logic as calling a continuation as
                // a function, so we consistently respect handler return semantics.
                //
                // In particular, when a resumed continuation completes and reaches the
                // handler's `PopHandler`, the result of resumption should be the handler
                // body's completion value (the `with-handler` return expression), not the
                // thunk's return value.
                let _ = self.resume_continuation(cont_key, resume_value, false)?;
            }

            // --- Natives ---
            OpCode::CallNative => {
                let native_idx = arg_u16(a1, a2) as usize;
                let n_args = a3 as usize;
                self.do_call_native(native_idx, n_args)?;
            }
        }

        Ok(StepResult::Continue)
    }

    // --- Call helpers ---

    /// Execute a function call.
    /// Returns `Ok(None)` to continue execution, or `Ok(Some(value))` if this was
    /// a native tail call in the last frame and the VM should return immediately.
    fn do_call(&mut self, n_args: usize, tail: bool) -> Result<Option<VMValue>, VMError> {
        // Callee is on top of stack, args below it
        let callee = self.stack.pop().ok_or(VMError::StackUnderflow)?;

        match callee {
            VMValue::HeapRef(key) => {
                // Check what type of object this is
                enum HeapCallKind {
                    Continuation,
                    Closure,
                    Vector(crate::collections::Vector<VMValue>), // Vector as function: lookup by index
                    Map(crate::collections::HashMap<VMValue, VMValue>), // Map as function: lookup by key
                    Set(crate::collections::HashSet<VMValue>), // Set as function: membership test
                }

                let kind = match self.heap.get(key) {
                    Some(HeapObject::Continuation(_)) => HeapCallKind::Continuation,
                    Some(HeapObject::Closure(_)) | Some(HeapObject::ClosureTemplate(_)) => {
                        HeapCallKind::Closure
                    }
                    Some(HeapObject::Seq(seq)) if seq.kind == SeqKind::Vector => {
                        HeapCallKind::Vector(seq.data.clone())
                    }
                    Some(HeapObject::Map(map)) => HeapCallKind::Map(map.clone()),
                    Some(HeapObject::Set(set)) => HeapCallKind::Set(set.clone()),
                    _ => return Err(VMError::NotCallable),
                };

                match kind {
                    HeapCallKind::Continuation => {
                        // Calling a continuation: resume it with the provided argument
                        if n_args != 1 {
                            return Err(VMError::ArityMismatch {
                                expected: 1,
                                got: n_args as u8,
                            });
                        }
                        let resume_value = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                        return self.resume_continuation(key, resume_value, tail);
                    }
                    HeapCallKind::Closure => {
                        // Args are on stack: [arg0, arg1, ..., arg_{n-1}]
                        // Call in-place to avoid allocation
                        let args_base = self.stack.len() - n_args;
                        self.call_closure_inplace(key, args_base, n_args, tail)?;
                    }
                    HeapCallKind::Vector(data) => {
                        // Vector as function: (vec idx) returns element at index
                        if n_args != 1 {
                            return Err(VMError::ArityMismatch {
                                expected: 1,
                                got: n_args as u8,
                            });
                        }
                        let idx = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                        let result = match idx {
                            VMValue::Int(i) if i >= 0 => {
                                data.get(i as usize)
                                    .copied()
                                    .ok_or(VMError::IndexOutOfBounds {
                                        index: i,
                                        len: data.len(),
                                    })?
                            }
                            VMValue::Int(i) => {
                                return Err(VMError::IndexOutOfBounds {
                                    index: i,
                                    len: data.len(),
                                });
                            }
                            _ => return Err(VMError::TypeError("vector index must be integer")),
                        };
                        self.stack.push(result);
                    }
                    HeapCallKind::Map(map) => {
                        // Map as function: (map key) or (map key default)
                        if n_args < 1 || n_args > 2 {
                            return Err(VMError::ArityMismatch {
                                expected: 1,
                                got: n_args as u8,
                            });
                        }
                        let args_start = self.stack.len().saturating_sub(n_args);
                        let args: Vec<VMValue> = self.stack.drain(args_start..).collect();
                        let key_arg = args[0];
                        let default = args.get(1).copied().unwrap_or(VMValue::Nil);
                        let result = map.get(&key_arg).copied().unwrap_or(default);
                        self.stack.push(result);
                    }
                    HeapCallKind::Set(set) => {
                        // Set as function: (set val) returns val if present, nil otherwise
                        if n_args != 1 {
                            return Err(VMError::ArityMismatch {
                                expected: 1,
                                got: n_args as u8,
                            });
                        }
                        let val = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                        let result = if set.contains(&val) {
                            val
                        } else {
                            VMValue::Nil
                        };
                        self.stack.push(result);
                    }
                }
            }
            VMValue::NativeFn(idx) => {
                if tail {
                    // For tail calls to natives, we need to pop the current frame
                    // and return the native's result to the caller

                    let args_start = self.stack.len().saturating_sub(n_args);
                    let args: Vec<VMValue> = self.stack.drain(args_start..).collect();

                    // Pop current frame's handlers (same as closure tail call)
                    let current_frame_idx = self.frames.len() as u32;
                    self.handlers.retain(|h| h.prompt_frame < current_frame_idx);

                    // Call the native with GC inhibited
                    self.heap.inhibit_gc();
                    let result = self.call_native_by_idx(idx as usize, &args);
                    self.heap.allow_gc();
                    let result = result?;

                    // Pop current frame (like Return)
                    let frame = self.frames.pop().ok_or(VMError::StackUnderflow)?;
                    self.stack.truncate(frame.fp as usize);

                    // If this was the last frame, signal immediate return
                    if self.frames.is_empty() {
                        return Ok(Some(result));
                    }

                    // Push result for caller
                    self.stack.push(result);
                } else {
                    // Normal call
                    self.do_call_native(idx as usize, n_args)?;
                }
            }
            VMValue::Keyword(kw) => {
                // Keyword as function: (:key map) or (:key map default)
                // Returns (get map key) or (get map key default)
                if n_args < 1 || n_args > 2 {
                    return Err(VMError::ArityMismatch {
                        expected: 1,
                        got: n_args as u8,
                    });
                }
                let args_start = self.stack.len().saturating_sub(n_args);
                let args: Vec<VMValue> = self.stack.drain(args_start..).collect();
                let map_arg = args[0];
                let default = args.get(1).copied().unwrap_or(VMValue::Nil);

                // Look up keyword in the map or variant
                let result = match map_arg {
                    VMValue::HeapRef(key) => {
                        match self.heap.get(key) {
                            Some(HeapObject::Map(map)) => {
                                map.get(&VMValue::Keyword(kw)).copied().unwrap_or(default)
                            }
                            Some(HeapObject::Variant(inst)) => {
                                let type_id = inst.type_id();
                                let variant_idx = inst.variant_idx();
                                if let Some(typedef) = self.type_registry.get(type_id) {
                                    let vdef = &typedef.variants[variant_idx as usize];
                                    if let Some(&field_idx) = vdef.field_index.get(&kw) {
                                        inst.fields[field_idx as usize]
                                    } else {
                                        default
                                    }
                                } else {
                                    default
                                }
                            }
                            _ => default, // Not a map, return default
                        }
                    }
                    _ => default, // Not a HeapRef, return default
                };
                self.stack.push(result);
            }
            _ => return Err(VMError::NotCallable),
        }

        Ok(None)
    }

    fn call_closure_with_args(
        &mut self,
        key: HeapKey,
        args: &[VMValue],
        tail: bool,
    ) -> Result<(), VMError> {
        // Clone the clauses to avoid holding a borrow on the heap
        let clauses = match self.heap.get(key) {
            Some(HeapObject::Closure(c)) => c.clauses.clone(),
            _ => return Err(VMError::NotCallable),
        };
        let (proto_idx, locals) = self.select_clause_from_clauses(&clauses, key, args)?;
        self.setup_call_with_locals(proto_idx, Some(key), locals, args.len(), tail)
    }

    fn setup_call_with_locals(
        &mut self,
        proto_idx: u32,
        closure: Option<HeapKey>,
        locals: Vec<VMValue>,
        arg_count: usize,
        tail: bool,
    ) -> Result<(), VMError> {
        if tail {
            // Get frame info before mutable borrow
            let current_frame_idx = self.frames.len() as u32;
            let fp = self.frames.last().ok_or(VMError::StackUnderflow)?.fp as usize;

            self.handlers.retain(|h| h.prompt_frame < current_frame_idx);

            self.stack.truncate(fp);
            self.stack.extend_from_slice(&locals);

            let frame = self.frames.last_mut().ok_or(VMError::StackUnderflow)?;
            frame.proto_idx = proto_idx;
            frame.ip = 0;
            frame.closure = closure;
            frame.arg_count = arg_count as u8;
        } else {
            let fp = self.stack.len() as u32;
            self.stack.extend_from_slice(&locals);
            self.frames
                .push(CallFrame::new(proto_idx, fp, closure, arg_count as u8));
        }
        Ok(())
    }

    /// Optimized closure call that keeps args on stack to avoid allocation.
    /// Args are at stack[args_base..args_base+n_args].
    fn call_closure_inplace(
        &mut self,
        key: HeapKey,
        args_base: usize,
        n_args: usize,
        tail: bool,
    ) -> Result<(), VMError> {
        // Get clauses (cheap Rc clone)
        let clauses = match self.heap.get(key) {
            Some(HeapObject::Closure(c)) => Rc::clone(&c.clauses),
            _ => {
                self.stack.truncate(args_base);
                return Err(VMError::NotCallable);
            }
        };

        // Try to find a matching clause
        match self.select_clause_inplace(&clauses, key, args_base, n_args)? {
            Some((proto_idx, locals_count)) => {
                // Success - setup call with args already on stack
                self.complete_call_inplace(proto_idx, key, args_base, n_args, locals_count, tail)
            }
            None => {
                // No matching clause - check if it's arity or pattern failure
                self.stack.truncate(args_base);
                let has_arity_match = clauses.iter().any(|c| {
                    if c.is_variadic {
                        n_args >= c.arity as usize
                    } else {
                        n_args == c.arity as usize
                    }
                });
                if has_arity_match {
                    Err(VMError::NoMatchingClause)
                } else {
                    let arities: Vec<String> = clauses
                        .iter()
                        .map(|c| {
                            if c.is_variadic {
                                format!("{}+", c.arity)
                            } else {
                                c.arity.to_string()
                            }
                        })
                        .collect();
                    Err(VMError::ValueError(format!(
                        "Wrong number of arguments ({}), function expects [{}]",
                        n_args,
                        arities.join(", ")
                    )))
                }
            }
        }
    }

    /// Try to select a matching clause without allocating a locals Vec.
    /// Returns Some((proto_idx, locals_count)) on success, None if no clause matches.
    fn select_clause_inplace(
        &mut self,
        clauses: &[ClauseInfo],
        closure_key: HeapKey,
        args_base: usize,
        n_args: usize,
    ) -> Result<Option<(u32, usize)>, VMError> {
        for clause in clauses.iter() {
            let required = clause.arity as usize;

            // Check basic arity
            if clause.is_variadic {
                if n_args < required {
                    continue;
                }
            } else if n_args != required {
                continue;
            }

            let locals_count = self.prototypes[clause.proto_idx as usize].locals as usize;

            // Fast path: simple positional args (no patterns, or all patterns are simple Bind)
            let is_simple_binding =
                clause.patterns.is_empty() || Self::is_simple_sequential_binding(&clause.patterns);

            if is_simple_binding && !clause.is_variadic {
                // For simple functions, args become locals directly at positions 0..n_args
                // Just need to check guard if present
                if let Some(guard_idx) = clause.guard_proto_idx {
                    // Need to create temporary locals for guard evaluation
                    let mut locals = vec![VMValue::Nil; locals_count];
                    for i in 0..n_args.min(locals_count) {
                        locals[i] = self.stack[args_base + i];
                    }
                    let guard_value = self.eval_guard(guard_idx, closure_key, &locals)?;
                    if guard_value.is_falsy() {
                        continue;
                    }
                }
                return Ok(Some((clause.proto_idx, locals_count)));
            }

            // Slow path: complex patterns or variadic - need to allocate locals and bind
            let mut locals = vec![VMValue::Nil; locals_count];
            let args: Vec<VMValue> = (0..n_args).map(|i| self.stack[args_base + i]).collect();

            let matched = if clause.patterns.is_empty() {
                self.bind_positional_args(&mut locals, clause, &args)?
            } else {
                self.bind_pattern_args_for_clause(clause, &args, &mut locals)?
            };

            if !matched {
                continue;
            }

            if let Some(guard_idx) = clause.guard_proto_idx {
                let guard_value = self.eval_guard(guard_idx, closure_key, &locals)?;
                if guard_value.is_falsy() {
                    continue;
                }
            }

            // Match found - copy bound locals to stack (replacing args)
            self.stack.truncate(args_base);
            self.stack.extend_from_slice(&locals);
            return Ok(Some((clause.proto_idx, locals_count)));
        }

        Ok(None)
    }

    /// Check if patterns are simple sequential Bind patterns (slot 0, 1, 2, ...).
    /// This means args can be used directly as locals without pattern matching.
    fn is_simple_sequential_binding(patterns: &[CompiledPattern]) -> bool {
        patterns
            .iter()
            .enumerate()
            .all(|(i, p)| matches!(p, CompiledPattern::Bind { slot } if *slot as usize == i))
    }

    /// Complete a call with args already on stack at args_base.
    /// Pads with Nils and pushes frame (or reuses frame for tail calls).
    fn complete_call_inplace(
        &mut self,
        proto_idx: u32,
        closure_key: HeapKey,
        args_base: usize,
        n_args: usize,
        locals_count: usize,
        tail: bool,
    ) -> Result<(), VMError> {
        if tail {
            // Tail call: reuse current frame
            let current_frame_idx = self.frames.len() as u32;
            let fp = self.frames.last().ok_or(VMError::StackUnderflow)?.fp as usize;

            // Pop handlers for current frame
            self.handlers.retain(|h| h.prompt_frame < current_frame_idx);

            // Move args to fp position, pad with Nils
            if fp != args_base {
                for i in 0..n_args {
                    self.stack[fp + i] = self.stack[args_base + i];
                }
            }
            // Pad remaining locals with Nil
            let locals_end = fp + locals_count;
            for i in (fp + n_args)..locals_end {
                if i < self.stack.len() {
                    self.stack[i] = VMValue::Nil;
                } else {
                    self.stack.push(VMValue::Nil);
                }
            }
            self.stack.truncate(locals_end);

            // Update frame
            let frame = self.frames.last_mut().ok_or(VMError::StackUnderflow)?;
            frame.proto_idx = proto_idx;
            frame.ip = 0;
            frame.closure = Some(closure_key);
            frame.arg_count = n_args as u8;
        } else {
            // Normal call: push new frame
            let fp = args_base as u32;
            // Pad remaining locals with Nil
            for _ in n_args..locals_count {
                self.stack.push(VMValue::Nil);
            }
            self.frames.push(CallFrame::new(
                proto_idx,
                fp,
                Some(closure_key),
                n_args as u8,
            ));
        }
        Ok(())
    }

    fn select_clause_from_clauses(
        &mut self,
        clauses: &[ClauseInfo],
        closure_key: HeapKey,
        args: &[VMValue],
    ) -> Result<(u32, Vec<VMValue>), VMError> {
        for clause in clauses.iter() {
            let required = clause.arity as usize;
            if clause.is_variadic {
                if args.len() < required {
                    continue;
                }
            } else if args.len() != required {
                continue;
            }

            // Get the locals count first to avoid borrowing prototypes during pattern matching
            let locals_count = self.prototypes[clause.proto_idx as usize].locals as usize;
            let mut locals = vec![VMValue::Nil; locals_count];

            let matched = if clause.patterns.is_empty() {
                self.bind_positional_args(&mut locals, clause, args)?
            } else {
                self.bind_pattern_args_for_clause(clause, args, &mut locals)?
            };

            if !matched {
                continue;
            }

            if let Some(guard_idx) = clause.guard_proto_idx {
                let guard_value = self.eval_guard(guard_idx, closure_key, &locals)?;
                if guard_value.is_falsy() {
                    continue;
                }
            }

            return Ok((clause.proto_idx, locals));
        }

        let has_arity_match = clauses.iter().any(|c| {
            if c.is_variadic {
                args.len() >= c.arity as usize
            } else {
                args.len() == c.arity as usize
            }
        });
        if has_arity_match {
            Err(VMError::NoMatchingClause)
        } else {
            let expected = clauses.iter().map(|c| c.arity).min().unwrap_or(0);
            Err(VMError::ArityMismatch {
                expected,
                got: args.len() as u8,
            })
        }
    }

    fn bind_positional_args(
        &mut self,
        locals: &mut [VMValue],
        clause: &ClauseInfo,
        args: &[VMValue],
    ) -> Result<bool, VMError> {
        let required = clause.arity as usize;
        if clause.is_variadic {
            if args.len() < required {
                return Ok(false);
            }
            for (idx, arg) in args.iter().take(required).enumerate() {
                if idx < locals.len() {
                    locals[idx] = *arg;
                }
            }
            if required < locals.len() {
                locals[required] = self.make_list(&args[required..]);
            }
        } else {
            if args.len() != required {
                return Ok(false);
            }
            for (idx, arg) in args.iter().enumerate() {
                if idx < locals.len() {
                    locals[idx] = *arg;
                }
            }
        }
        Ok(true)
    }

    fn bind_pattern_args_for_clause(
        &mut self,
        clause: &ClauseInfo,
        args: &[VMValue],
        locals: &mut [VMValue],
    ) -> Result<bool, VMError> {
        let proto_idx = clause.proto_idx;
        for (idx, pattern) in clause.patterns.iter().enumerate() {
            let value = if clause.is_variadic && idx == clause.patterns.len() - 1 {
                self.make_list(&args[idx..])
            } else {
                args[idx]
            };
            if !self.match_pattern_with_idx(proto_idx, pattern, value, locals)? {
                return Ok(false);
            }
        }
        Ok(true)
    }

    fn eval_guard(
        &mut self,
        guard_proto_idx: u32,
        closure_key: HeapKey,
        locals: &[VMValue],
    ) -> Result<VMValue, VMError> {
        let saved_stack_len = self.stack.len();
        let saved_frames_len = self.frames.len();
        let saved_handlers_len = self.handlers.len();

        let fp = self.stack.len() as u32;
        self.stack.extend_from_slice(locals);
        self.frames
            .push(CallFrame::new(guard_proto_idx, fp, Some(closure_key), 0));

        loop {
            match self.step()? {
                StepResult::Continue => {
                    if self.frames.len() == saved_frames_len {
                        let result = self.stack.pop().ok_or(VMError::StackUnderflow)?;
                        self.stack.truncate(saved_stack_len);
                        self.handlers.truncate(saved_handlers_len);
                        return Ok(result);
                    }
                }
                StepResult::Return(value) => {
                    self.stack.truncate(saved_stack_len);
                    self.handlers.truncate(saved_handlers_len);
                    return Ok(value);
                }
                StepResult::Yield {
                    effect_id,
                    op_name,
                    args,
                } => {
                    self.handle_effect(effect_id, op_name, args)?;
                }
            }
        }
    }

    fn make_list(&mut self, items: &[VMValue]) -> VMValue {
        let data: crate::collections::Vector<VMValue> = items.iter().copied().collect();
        let seq = SeqData {
            data,
            kind: SeqKind::List,
        };
        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        let key = self.heap.alloc_no_gc(HeapObject::Seq(seq));
        VMValue::HeapRef(key)
    }

    // --- Interning Wrappers ---

    /// Intern a sequence, running GC if needed.
    pub fn intern_seq(&mut self, seq: SeqData) -> HeapKey {
        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        self.heap.intern_seq(seq)
    }

    /// Intern a set, running GC if needed.
    pub fn intern_set(&mut self, set: crate::collections::HashSet<VMValue>) -> HeapKey {
        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        self.heap.intern_set(set)
    }

    /// Intern a map, running GC if needed.
    pub fn intern_map(&mut self, map: crate::collections::HashMap<VMValue, VMValue>) -> HeapKey {
        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        self.heap.intern_map(map)
    }

    fn match_pattern_with_idx(
        &mut self,
        proto_idx: u32,
        pattern: &CompiledPattern,
        value: VMValue,
        locals: &mut [VMValue],
    ) -> Result<bool, VMError> {
        match pattern {
            CompiledPattern::Wildcard => Ok(true),
            CompiledPattern::Bind { slot } => {
                if let Some(local) = locals.get_mut(*slot as usize) {
                    *local = value;
                }
                Ok(true)
            }
            CompiledPattern::Literal { const_idx } => {
                let expected = self.prototypes[proto_idx as usize].constants[*const_idx as usize];
                Ok(self.values_equal(expected, value))
            }
            CompiledPattern::Sequential {
                required,
                rest,
                as_slot,
            } => {
                if matches!(value, VMValue::Nil) {
                    return Ok(false);
                }
                let items = self.value_to_seq_items(value)?;
                if rest.is_none() && items.len() != required.len() {
                    return Ok(false);
                }
                if items.len() < required.len() {
                    return Ok(false);
                }
                for (idx, pat) in required.iter().enumerate() {
                    if !self.match_pattern_with_idx(proto_idx, pat, items[idx], locals)? {
                        return Ok(false);
                    }
                }
                if let Some(rest_pat) = rest {
                    let rest_list = self.make_list(&items[required.len()..]);
                    if !self.match_pattern_with_idx(proto_idx, rest_pat, rest_list, locals)? {
                        return Ok(false);
                    }
                }
                if let Some(slot) = as_slot {
                    if let Some(local) = locals.get_mut(*slot as usize) {
                        *local = value;
                    }
                }
                Ok(true)
            }
            CompiledPattern::Variant {
                type_id,
                variant_idx,
                field_patterns,
            } => {
                let expected_tag = ((*type_id).0 as u32) << 8 | (*variant_idx as u32);
                match value {
                    VMValue::HeapRef(key) => match self.heap.get(key) {
                        Some(HeapObject::Variant(inst)) => {
                            if inst.tag != expected_tag {
                                return Ok(false);
                            }
                            if inst.fields.len() != field_patterns.len() {
                                return Ok(false);
                            }
                            let fields: Vec<VMValue> = inst.fields.clone();
                            for (i, pat) in field_patterns.iter().enumerate() {
                                if !self
                                    .match_pattern_with_idx(proto_idx, pat, fields[i], locals)?
                                {
                                    return Ok(false);
                                }
                            }
                            Ok(true)
                        }
                        _ => Ok(false),
                    },
                    _ => Ok(false),
                }
            }
            CompiledPattern::Associative {
                keys,
                defaults,
                as_slot,
            } => {
                if matches!(value, VMValue::Nil) {
                    return Ok(false);
                }
                let map = self.value_to_map(value)?;
                for (key_idx, pat) in keys.iter() {
                    let key = self.prototypes[proto_idx as usize].constants[*key_idx as usize];
                    let mut val = map.get(&key).copied().unwrap_or(VMValue::Nil);
                    if matches!(val, VMValue::Nil) {
                        if let Some((_, default_idx)) =
                            defaults.iter().find(|(k, _)| *k == *key_idx)
                        {
                            val = self.prototypes[proto_idx as usize].constants
                                [*default_idx as usize];
                        }
                    }
                    if !self.match_pattern_with_idx(proto_idx, pat, val, locals)? {
                        return Ok(false);
                    }
                }
                if let Some(slot) = as_slot {
                    if let Some(local) = locals.get_mut(*slot as usize) {
                        *local = value;
                    }
                }
                Ok(true)
            }
        }
    }

    fn value_to_seq_items(&mut self, value: VMValue) -> Result<Vec<VMValue>, VMError> {
        // Extract data without holding borrow, then allocate if needed
        enum SeqExtract {
            Items(Vec<VMValue>),
            Chars(Vec<char>),
        }

        let extracted = match value {
            VMValue::Nil => return Ok(Vec::new()),
            VMValue::HeapRef(key) => match self.heap.get(key) {
                Some(HeapObject::Seq(seq)) => SeqExtract::Items(seq.data.iter().copied().collect()),
                Some(HeapObject::String(s)) => SeqExtract::Chars(s.chars().collect()),
                _ => return Err(VMError::TypeError("expected sequential")),
            },
            _ => return Err(VMError::TypeError("expected sequential")),
        };

        match extracted {
            SeqExtract::Items(items) => Ok(items),
            SeqExtract::Chars(chars) => {
                let mut items = Vec::new();
                for ch in chars {
                    items.push(self.alloc_string(ch.to_string()));
                }
                Ok(items)
            }
        }
    }

    fn value_to_map(
        &self,
        value: VMValue,
    ) -> Result<crate::collections::HashMap<VMValue, VMValue>, VMError> {
        match value {
            VMValue::Nil => Ok(crate::collections::HashMap::new()),
            VMValue::HeapRef(key) => match self.heap.get(key) {
                Some(HeapObject::Map(map)) => Ok(map.clone()),
                _ => Err(VMError::TypeError("expected map")),
            },
            _ => Err(VMError::TypeError("expected map")),
        }
    }

    /// Call a native function by index. Indices below `self.natives.len()` are
    /// static (boot-time) natives; indices at or above are dynamic (host) callbacks.
    fn call_native_by_idx(&mut self, native_idx: usize, args: &[VMValue]) -> Result<VMValue, VMError> {
        if native_idx < self.natives.len() {
            let func = self.natives[native_idx].func;
            func(self, args)
        } else {
            let dyn_idx = native_idx - self.natives.len();
            let func = self.dynamic_natives[dyn_idx].func.clone();
            func(self, args)
        }
    }

    fn do_call_native(&mut self, native_idx: usize, n_args: usize) -> Result<(), VMError> {
        let args_start = self.stack.len() - n_args;
        let args: Vec<VMValue> = self.stack.drain(args_start..).collect();

        // Inhibit GC during native execution - natives can allocate freely
        self.heap.inhibit_gc();
        let result = self.call_native_by_idx(native_idx, &args);
        self.heap.allow_gc();

        self.stack.push(result?);
        Ok(())
    }

    /// Resume a continuation with a value.
    /// This is used when a continuation is called as a function from within a handler.
    /// Unlike the Resume opcode (which is used after handle_effect has truncated),
    /// this preserves the caller's context so the continuation can return to it.
    fn resume_continuation(
        &mut self,
        cont_key: HeapKey,
        resume_value: VMValue,
        _tail: bool,
    ) -> Result<Option<VMValue>, VMError> {
        // Get continuation (and check one-shot)
        let (
            stack_segment,
            frames,
            handlers,
            _resume_ip,
            _resume_proto,
            body_proto,
            body_ip,
            body_fp,
            body_end_ip,
        ): (
            Vec<VMValue>,
            Vec<frame::CapturedFrame>,
            Vec<heap::CapturedHandler>,
            u32,
            u32,
            u32,
            u32,
            u32,
            u32,
        ) = match self.heap.get_mut(cont_key) {
            Some(HeapObject::Continuation(c)) => {
                if c.resumed {
                    return Err(VMError::InvalidContinuation);
                }
                c.resumed = true;
                (
                    c.stack_segment.to_vec(),
                    c.frames.to_vec(),
                    c.handlers.to_vec(),
                    c.resume_ip,
                    c.resume_proto,
                    c.body_proto,
                    c.body_ip,
                    c.body_fp,
                    c.body_end_ip,
                )
            }
            _ => return Err(VMError::TypeError("expected continuation")),
        };

        // While running a resumed continuation, the capturing handler should be unmasked
        // so effects inside the continuation are handled by it (deep handler semantics).
        let capturing_handler_idx = self.handlers.len().checked_sub(1);
        if let Some(idx) = capturing_handler_idx {
            if let Some(handler) = self.handlers.get_mut(idx) {
                handler.masked = false;
            }
        }

        // Don't truncate - we want the continuation to return to the caller (handler)
        // The continuation's stack segment will be pushed on top of the current stack

        // Restore: extend stack with captured segment
        let base_sp = self.stack.len() as u32;
        self.stack.extend(stack_segment.into_iter());

        // Insert a synthetic "body continuation" frame (analogous to the tree-walker
        // `ContinuationReturn` delimiter). This ensures that when a resumed continuation
        // completes, it runs the remainder of the `with-handler` body up to (but not
        // including) the `PopHandler`, and then returns that value back to the caller
        // of `(k v)`.
        //
        // Without this frame, resuming a continuation from inside a handler clause would
        // return the inner computation's return value (e.g. `:done`) instead of the
        // handler body's completion value (e.g. `[]`), because the caller's frame would
        // sit directly under the restored frames and intercept the return.
        let body_frame_idx = self.frames.len() as u32;
        self.frames.push(CallFrame {
            ip: body_ip,
            fp: body_fp,
            proto_idx: body_proto,
            closure: None,
            arg_count: 0,
            handler_guard: None,
            return_at_ip: Some(body_end_ip),
            cleanup_fp: Some(base_sp),
            remask_handler_idx: capturing_handler_idx,
        });

        // Restore captured frames above the synthetic body frame (adjust fp to current base).
        for cf in frames.into_iter() {
            self.frames.push(CallFrame {
                ip: cf.ip,
                fp: base_sp + cf.fp_offset,
                proto_idx: cf.proto_idx,
                closure: cf.closure,
                arg_count: cf.arg_count,
                handler_guard: None,
                return_at_ip: cf.return_at_ip,
                cleanup_fp: cf.cleanup_fp_offset.map(|off| base_sp + off),
                remask_handler_idx: None,
            });
        }

        // Restore handlers (adjust offsets)
        // The capturing handler is the last one in the handlers stack BEFORE we restore.
        // We need to track its index so we can update it after restoring captured handlers.
        // The offsets in captured handlers are relative to the prompt frame index, which
        // is the frame index *after* the delimiter frame. Our delimiter is the synthetic
        // body frame we just pushed, so the prompt frame is `body_frame_idx + 1`.
        let base_frame = body_frame_idx + 1;
        for ch in handlers.into_iter() {
            self.handlers.push(Handler {
                effect_id: ch.effect_id,
                handler_ip: ch.handler_ip,
                handler_proto: ch.handler_proto,
                handler_closure: ch.handler_closure,
                dispatch_table: ch.dispatch_table,
                prompt_sp: base_sp + ch.prompt_sp_offset,
                prompt_frame: base_frame + ch.prompt_frame_offset,
                install_prompt_sp: base_sp + ch.install_prompt_sp_offset,
                install_prompt_frame: base_frame + ch.install_prompt_frame_offset,
                masked: ch.masked,
                abort_ip: ch.abort_ip,
            });
        }

        // Update the capturing handler's prompt to the resumption site.
        // This is crucial for deep handler semantics: when subsequent effects happen
        // inside the resumed continuation (like yield 2 inside (k nil)), they should
        // truncate to the RESUMPTION SITE (base_sp/base_frame), not to the original
        // handler installation point. This preserves the parent handler's call frame.
        //
        // IMPORTANT: We must update the CAPTURING handler, not the last handler.
        // If the effect was performed under non-matching handlers, those handlers
        // are captured and restored above the capturing handler. Using last_mut()
        // would update the wrong handler, leaving the capturing handler's prompt
        // at the original install point and breaking deep-handler semantics.
        //
        // NOTE: We update the prompt BEFORE pushing resume_value to ensure the
        // handler's prompt_sp reflects the stack state at the resumption boundary,
        // not including the value being resumed with.
        if let Some(idx) = capturing_handler_idx {
            if let Some(handler) = self.handlers.get_mut(idx) {
                handler.prompt_sp = base_sp;
                handler.prompt_frame = base_frame;
            }
        }

        // Push resume_value onto stack
        self.stack.push(resume_value);

        Ok(None)
    }

    // --- Effects ---

    fn handle_effect(
        &mut self,
        effect_id: EffectId,
        op_name: Spur,
        args: Vec<VMValue>,
    ) -> Result<(), VMError> {
        use frame::CapturedFrame;
        use heap::{CapturedHandler, Continuation};

        // Check for native handler first (takes precedence as fallback)
        // Native handlers are "default" handlers - Hoatzin handlers override them
        if !self
            .handlers
            .iter()
            .any(|h| h.effect_id == effect_id && !h.masked)
        {
            if let Some(handler_fn) = self.native_handlers.get(&effect_id).cloned() {
                match handler_fn(self, op_name, args)? {
                    HandlerAction::Resume(value) => {
                        self.stack.push(value);
                        return Ok(());
                    }
                    HandlerAction::Abort(value) => {
                        // For native handlers, abort means return the value
                        // (no handler frame to unwind to)
                        self.stack.push(value);
                        return Ok(());
                    }
                }
            }
        }

        // Find handler for this effect by EffectId
        let handler_idx = match self
            .handlers
            .iter()
            .rposition(|h| h.effect_id == effect_id && !h.masked)
        {
            Some(idx) => idx,
            None => {
                let name = self.effect_name_by_id(effect_id);
                return Err(VMError::EffectNotHandled {
                    id: effect_id,
                    name,
                });
            }
        };

        let handler = self.handlers[handler_idx].clone();

        // Determine which closure to call based on handler type
        let handler_closure_key = if let Some(dispatch_table_key) = handler.dispatch_table {
            // Multi-op handler: look up operation in dispatch table
            match self.heap.get(dispatch_table_key) {
                Some(HeapObject::Map(map)) => {
                    let op_symbol = VMValue::Symbol(op_name);
                    match map.get(&op_symbol) {
                        Some(VMValue::HeapRef(key)) => Some(*key),
                        _ => {
                            return Err(VMError::OperationNotHandled {
                                effect_id,
                                effect_name: self.effect_name_by_id(effect_id),
                                op_name: self.interner.resolve(&op_name).to_string(),
                            });
                        }
                    }
                }
                _ => return Err(VMError::TypeError("expected dispatch table map")),
            }
        } else {
            // Simple single-op handler
            handler.handler_closure
        };

        // Capture continuation: stack segment from prompt_sp to current sp
        let stack_segment: Box<[VMValue]> = self.stack[handler.prompt_sp as usize..].into();

        // Capture frames from prompt_frame to current
        let captured_frames: Box<[CapturedFrame]> = self.frames[handler.prompt_frame as usize..]
            .iter()
            .map(|f| {
                debug_assert!(
                    f.fp >= handler.prompt_sp,
                    "Frame fp ({}) below handler prompt_sp ({})",
                    f.fp,
                    handler.prompt_sp
                );
                CapturedFrame {
                    ip: f.ip,
                    fp_offset: f.fp.saturating_sub(handler.prompt_sp),
                    proto_idx: f.proto_idx,
                    closure: f.closure,
                    arg_count: f.arg_count,
                    return_at_ip: f.return_at_ip, // Preserve the return marker
                    cleanup_fp_offset: f.cleanup_fp.map(|fp| fp.saturating_sub(handler.prompt_sp)),
                }
            })
            .collect();

        // Capture handlers between prompt and current
        let captured_handlers: Box<[CapturedHandler]> = self.handlers[handler_idx + 1..]
            .iter()
            .map(|h| CapturedHandler {
                effect_id: h.effect_id,
                op_name: None,
                handler_ip: h.handler_ip,
                handler_proto: h.handler_proto,
                handler_closure: h.handler_closure,
                dispatch_table: h.dispatch_table,
                masked: h.masked,
                prompt_sp_offset: h.prompt_sp.saturating_sub(handler.prompt_sp),
                prompt_frame_offset: h.prompt_frame.saturating_sub(handler.prompt_frame),
                install_prompt_sp_offset: h.install_prompt_sp.saturating_sub(handler.prompt_sp),
                install_prompt_frame_offset: h
                    .install_prompt_frame
                    .saturating_sub(handler.prompt_frame),
                abort_ip: h.abort_ip,
            })
            .collect();

        // Create continuation
        let resume_ip = self.frames.last().map(|f| f.ip).unwrap_or(0);
        let resume_proto = self.frames.last().map(|f| f.proto_idx).unwrap_or(0);
        let (body_proto, body_ip, body_fp) = if handler.prompt_frame > 0 {
            let frame = &self.frames[handler.prompt_frame.saturating_sub(1) as usize];
            (frame.proto_idx, frame.ip, frame.fp)
        } else {
            (resume_proto, resume_ip, handler.prompt_sp)
        };
        // body_end_ip is the PopHandler instruction (abort_ip - 1)
        let body_end_ip = handler.abort_ip.saturating_sub(1);

        let cont = Continuation {
            stack_segment,
            frames: captured_frames,
            handlers: captured_handlers,
            resume_ip,
            resume_proto,
            resumed: false,
            prompt_sp: handler.prompt_sp,
            prompt_frame: handler.prompt_frame,
            body_proto,
            body_ip,
            body_fp,
            body_end_ip,
        };

        if self.heap.needs_gc() {
            let roots: Vec<HeapKey> = self.roots().collect();
            self.heap.collect(roots);
        }
        let cont_key = self.heap.alloc_no_gc(HeapObject::Continuation(cont));

        // Truncate stack and frames to prompt point
        self.stack.truncate(handler.prompt_sp as usize);
        self.frames.truncate(handler.prompt_frame as usize);

        // Pop handlers down to but NOT including the matched handler (deep handler semantics)
        // This keeps the handler installed so subsequent effects from resumed continuations
        // are still handled by the same handler
        self.handlers.truncate(handler_idx + 1);

        // Call the handler closure
        if let Some(closure_key) = handler_closure_key {
            // While running the handler clause, mask the matching handler so that
            // effects performed inside the clause forward to outer handlers.
            if let Some(handler) = self.handlers.last_mut() {
                handler.masked = true;
            }
            let mut call_args = args;
            call_args.push(VMValue::HeapRef(cont_key));
            self.call_closure_with_args(closure_key, &call_args, false)?;

            // Set handler guard for abort detection
            // If this handler returns without resuming the continuation,
            // we'll detect it and properly unwind
            if let Some(frame) = self.frames.last_mut() {
                frame.handler_guard = Some(frame::HandlerGuard {
                    continuation_key: cont_key,
                    prompt_sp: handler.prompt_sp,
                    prompt_frame: handler.prompt_frame,
                    abort_ip: handler.abort_ip,
                });
            }
        } else {
            // No handler closure - this is an error for simple handlers
            // (Only dispatch table handlers can have None for handler_closure)
            return Err(VMError::TypeError("handler closure is None"));
        }

        Ok(())
    }

    // --- Arithmetic helpers ---

    #[inline(always)]
    fn binary_add(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a + b)),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(VMValue::Float(a + b)),
            (VMValue::Int(a), VMValue::Float(b)) => Ok(VMValue::Float(a as f64 + b)),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(VMValue::Float(a + b as f64)),
            (a, b) if matches!(a, VMValue::Float(_)) || matches!(b, VMValue::Float(_)) => {
                let af = a.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                let bf = b.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                Ok(VMValue::Float(af + bf))
            }
            _ => self.binary_ratio_op(a, b, |x, y| x + y),
        }
    }

    #[inline(always)]
    fn binary_sub(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a - b)),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(VMValue::Float(a - b)),
            (VMValue::Int(a), VMValue::Float(b)) => Ok(VMValue::Float(a as f64 - b)),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(VMValue::Float(a - b as f64)),
            (a, b) if matches!(a, VMValue::Float(_)) || matches!(b, VMValue::Float(_)) => {
                let af = a.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                let bf = b.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                Ok(VMValue::Float(af - bf))
            }
            _ => self.binary_ratio_op(a, b, |x, y| x - y),
        }
    }

    #[inline(always)]
    fn compare_le(&self, a: VMValue, b: VMValue) -> Result<bool, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(a <= b),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(a <= b),
            (VMValue::Int(a), VMValue::Float(b)) => Ok((a as f64) <= b),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(a <= b as f64),
            _ => self.compare_ratio(a, b, |ord| ord.is_le()),
        }
    }

    #[inline(always)]
    fn compare_lt(&self, a: VMValue, b: VMValue) -> Result<bool, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(a < b),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(a < b),
            (VMValue::Int(a), VMValue::Float(b)) => Ok((a as f64) < b),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(a < b as f64),
            _ => self.compare_ratio(a, b, |ord| ord.is_lt()),
        }
    }

    #[inline(always)]
    fn compare_gt(&self, a: VMValue, b: VMValue) -> Result<bool, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(a > b),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(a > b),
            (VMValue::Int(a), VMValue::Float(b)) => Ok((a as f64) > b),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(a > b as f64),
            _ => self.compare_ratio(a, b, |ord| ord.is_gt()),
        }
    }

    #[inline(always)]
    fn compare_ge(&self, a: VMValue, b: VMValue) -> Result<bool, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(a >= b),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(a >= b),
            (VMValue::Int(a), VMValue::Float(b)) => Ok((a as f64) >= b),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(a >= b as f64),
            _ => self.compare_ratio(a, b, |ord| ord.is_ge()),
        }
    }

    #[inline(always)]
    fn binary_mul(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => Ok(VMValue::Int(a * b)),
            (VMValue::Float(a), VMValue::Float(b)) => Ok(VMValue::Float(a * b)),
            (VMValue::Int(a), VMValue::Float(b)) => Ok(VMValue::Float(a as f64 * b)),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(VMValue::Float(a * b as f64)),
            (a, b) if matches!(a, VMValue::Float(_)) || matches!(b, VMValue::Float(_)) => {
                let af = a.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                let bf = b.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                Ok(VMValue::Float(af * bf))
            }
            _ => self.binary_ratio_op(a, b, |x, y| x * y),
        }
    }

    fn binary_div(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => {
                if b == 0 {
                    return Err(VMError::DivisionByZero);
                }
                if a % b == 0 {
                    Ok(VMValue::Int(a / b))
                } else {
                    self.ratio_from_i128(a as i128, b as i128)
                }
            }
            (VMValue::Float(a), VMValue::Float(b)) => Ok(VMValue::Float(a / b)),
            (VMValue::Int(a), VMValue::Float(b)) => Ok(VMValue::Float(a as f64 / b)),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(VMValue::Float(a / b as f64)),
            (a, b) if matches!(a, VMValue::Float(_)) || matches!(b, VMValue::Float(_)) => {
                let af = a.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                let bf = b.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                if bf == 0.0 {
                    return Err(VMError::DivisionByZero);
                }
                Ok(VMValue::Float(af / bf))
            }
            _ => self.binary_ratio_div(a, b),
        }
    }

    fn binary_rem(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Int(b)) => {
                if b == 0 {
                    return Err(VMError::DivisionByZero);
                }
                Ok(VMValue::Int(a % b))
            }
            (VMValue::Float(a), VMValue::Float(b)) => Ok(VMValue::Float(a % b)),
            (VMValue::Int(a), VMValue::Float(b)) => Ok(VMValue::Float(a as f64 % b)),
            (VMValue::Float(a), VMValue::Int(b)) => Ok(VMValue::Float(a % b as f64)),
            _ => Err(VMError::TypeError("expected numbers")),
        }
    }

    fn unary_neg(&self, v: VMValue) -> Result<VMValue, VMError> {
        match v {
            VMValue::Int(i) => Ok(VMValue::Int(-i)),
            VMValue::Float(f) => Ok(VMValue::Float(-f)),
            VMValue::Ratio { numer, denom } => {
                self.ratio_from_i128(-(numer as i128), denom as i128)
            }
            _ => Err(VMError::TypeError("expected number")),
        }
    }

    pub(crate) fn values_equal(&self, a: VMValue, b: VMValue) -> bool {
        match (a, b) {
            (VMValue::Nil, VMValue::Nil) => true,
            (VMValue::Bool(a), VMValue::Bool(b)) => a == b,
            (VMValue::Int(a), VMValue::Int(b)) => a == b,
            (VMValue::Float(a), VMValue::Float(b)) => a == b,
            (VMValue::Ratio { numer: a, denom: b }, VMValue::Ratio { numer: c, denom: d }) => {
                a == c && b == d
            }
            (VMValue::Symbol(a), VMValue::Symbol(b)) => a == b,
            (VMValue::Keyword(a), VMValue::Keyword(b)) => a == b,
            (VMValue::HeapRef(a), VMValue::HeapRef(b)) => self.heap_values_equal(a, b),
            (VMValue::NativeFn(a), VMValue::NativeFn(b)) => a == b,
            _ => self.numeric_equals(a, b).unwrap_or(false),
        }
    }

    fn numeric_equals(&self, a: VMValue, b: VMValue) -> Option<bool> {
        match (a, b) {
            (VMValue::Int(a), VMValue::Float(b)) => Some((a as f64) == b),
            (VMValue::Float(a), VMValue::Int(b)) => Some(a == b as f64),
            (VMValue::Ratio { numer, denom }, VMValue::Int(i))
            | (VMValue::Int(i), VMValue::Ratio { numer, denom }) => {
                Some((numer as i128) == (i as i128 * denom as i128))
            }
            (VMValue::Ratio { numer, denom }, VMValue::Float(f))
            | (VMValue::Float(f), VMValue::Ratio { numer, denom }) => {
                Some((numer as f64) / (denom as f64) == f)
            }
            _ => None,
        }
    }

    fn ratio_parts(value: VMValue) -> Option<(i128, i128)> {
        match value {
            VMValue::Int(i) => Some((i as i128, 1)),
            VMValue::Ratio { numer, denom } => Some((numer as i128, denom as i128)),
            _ => None,
        }
    }

    fn binary_ratio_op(
        &self,
        a: VMValue,
        b: VMValue,
        op: fn(i128, i128) -> i128,
    ) -> Result<VMValue, VMError> {
        if let (Some((an, ad)), Some((bn, bd))) = (Self::ratio_parts(a), Self::ratio_parts(b)) {
            let numer = op(an * bd, bn * ad);
            let denom = ad * bd;
            return self.ratio_from_i128(numer, denom);
        }
        Err(VMError::TypeError("expected numbers"))
    }

    fn binary_ratio_div(&self, a: VMValue, b: VMValue) -> Result<VMValue, VMError> {
        match (Self::ratio_parts(a), Self::ratio_parts(b)) {
            (Some((an, ad)), Some((bn, bd))) => {
                if bn == 0 {
                    return Err(VMError::DivisionByZero);
                }
                let numer = an * bd;
                let denom = ad * bn;
                self.ratio_from_i128(numer, denom)
            }
            _ => Err(VMError::TypeError("expected numbers")),
        }
    }

    fn ratio_from_i128(&self, numer: i128, denom: i128) -> Result<VMValue, VMError> {
        if denom == 0 {
            return Err(VMError::DivisionByZero);
        }
        let mut n = numer;
        let mut d = denom;
        if d < 0 {
            n = -n;
            d = -d;
        }
        let gcd = gcd_i128(n.abs(), d);
        let n = n / gcd;
        let d = d / gcd;
        let n_i64 = i64::try_from(n).map_err(|_| VMError::TypeError("ratio overflow"))?;
        let d_i64 = i64::try_from(d).map_err(|_| VMError::TypeError("ratio overflow"))?;
        if d_i64 == 1 {
            Ok(VMValue::Int(n_i64))
        } else {
            Ok(VMValue::Ratio {
                numer: n_i64,
                denom: d_i64,
            })
        }
    }

    fn compare_ratio(
        &self,
        a: VMValue,
        b: VMValue,
        pred: fn(std::cmp::Ordering) -> bool,
    ) -> Result<bool, VMError> {
        match (a, b) {
            (VMValue::Float(a), b) => {
                let b = b.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                Ok(pred(
                    a.partial_cmp(&b)
                        .ok_or(VMError::TypeError("invalid float"))?,
                ))
            }
            (a, VMValue::Float(b)) => {
                let a = a.as_float().ok_or(VMError::TypeError("expected numbers"))?;
                Ok(pred(
                    a.partial_cmp(&b)
                        .ok_or(VMError::TypeError("invalid float"))?,
                ))
            }
            (a, b) => {
                let (an, ad) =
                    Self::ratio_parts(a).ok_or(VMError::TypeError("expected numbers"))?;
                let (bn, bd) =
                    Self::ratio_parts(b).ok_or(VMError::TypeError("expected numbers"))?;
                let left = an * bd;
                let right = bn * ad;
                Ok(pred(left.cmp(&right)))
            }
        }
    }

    pub(crate) fn heap_values_equal(&self, a: HeapKey, b: HeapKey) -> bool {
        // Same key means same object
        if a == b {
            return true;
        }

        let obj_a = match self.heap.get(a) {
            Some(obj) => obj,
            None => return false,
        };
        let obj_b = match self.heap.get(b) {
            Some(obj) => obj,
            None => return false,
        };

        match (obj_a, obj_b) {
            (HeapObject::String(a), HeapObject::String(b)) => a == b,
            (HeapObject::Seq(a), HeapObject::Seq(b)) => {
                // Both must be same kind (list or vector)
                if a.kind != b.kind
                    && !matches!(
                        (a.kind, b.kind),
                        (SeqKind::List, SeqKind::Vector) | (SeqKind::Vector, SeqKind::List)
                    )
                {
                    // Actually, for equality purposes, lists and vectors with same elements are equal
                }
                if a.data.len() != b.data.len() {
                    return false;
                }
                a.data
                    .iter()
                    .zip(b.data.iter())
                    .all(|(x, y)| self.values_equal(*x, *y))
            }
            (HeapObject::Set(a), HeapObject::Set(b)) => {
                if a.len() != b.len() {
                    return false;
                }
                // For sets, each element in a must be in b
                for item in a.iter() {
                    if !b.iter().any(|x| self.values_equal(*item, *x)) {
                        return false;
                    }
                }
                true
            }
            (HeapObject::Map(a), HeapObject::Map(b)) => {
                if a.len() != b.len() {
                    return false;
                }
                // For maps, each key-value pair must match
                for (k, v) in a.iter() {
                    match b.iter().find(|(k2, _)| self.values_equal(*k, **k2)) {
                        Some((_, v2)) if self.values_equal(*v, *v2) => {}
                        _ => return false,
                    }
                }
                true
            }
            (HeapObject::Closure(_), HeapObject::Closure(_)) => {
                // Closures are never equal (identity semantics)
                false
            }
            (HeapObject::Continuation(_), HeapObject::Continuation(_)) => {
                // Continuations are never equal
                false
            }
            (HeapObject::Atom(_), HeapObject::Atom(_)) => {
                // Atoms use identity comparison
                false
            }
            (HeapObject::Optic(_), HeapObject::Optic(_)) => {
                // Optics use identity comparison
                false
            }
            (HeapObject::Variant(a), HeapObject::Variant(b)) => {
                if a.tag != b.tag || a.fields.len() != b.fields.len() {
                    return false;
                }
                a.fields
                    .iter()
                    .zip(b.fields.iter())
                    .all(|(x, y)| self.values_equal(*x, *y))
            }
            (HeapObject::Regex(a), HeapObject::Regex(b)) => a.as_str() == b.as_str(),
            (HeapObject::KeyBox(a), HeapObject::KeyBox(b)) => self.values_equal(*a, *b),
            _ => false,
        }
    }

    /// Compute content-based hash for a VMValue.
    /// For strings, uses the cached content hash.
    /// For other types, uses the standard Hash trait.
    pub fn content_hash(&self, v: VMValue) -> u64 {
        use std::hash::{Hash, Hasher};
        match v {
            VMValue::HeapRef(key) => {
                match self.heap.get(key) {
                    Some(HeapObject::String(s)) => {
                        // Compute hash from string content
                        let mut hasher = std::collections::hash_map::DefaultHasher::new();
                        s.as_str().hash(&mut hasher);
                        hasher.finish()
                    }
                    _ => {
                        // For other heap objects, use key-based hash
                        let mut hasher = std::collections::hash_map::DefaultHasher::new();
                        key.hash(&mut hasher);
                        hasher.finish()
                    }
                }
            }
            _ => {
                let mut hasher = std::collections::hash_map::DefaultHasher::new();
                v.hash(&mut hasher);
                hasher.finish()
            }
        }
    }

    /// Map lookup with content-based equality.
    /// - Scalar keys: O(log n) native lookup
    /// - HeapRef keys: O(log n) if same object, O(n) fallback for content equality
    /// Canonicalize a HeapRef key for map operations.
    /// If the key is a collection, ensures it's interned so that content-equal
    /// collections have the same HeapKey.
    pub fn canonicalize_key(&mut self, key: VMValue) -> VMValue {
        match key {
            VMValue::HeapRef(heap_key) => {
                // Check if already interned (has content_hash)
                if let Some(cell) = self.heap.objects.get(heap_key) {
                    if cell.content_hash.is_some() {
                        return key; // Already interned
                    }
                }

                // Try to intern this collection
                match self.heap.get(heap_key).cloned() {
                    Some(HeapObject::Seq(seq)) => {
                        let canonical = self.intern_seq(seq);
                        VMValue::HeapRef(canonical)
                    }
                    Some(HeapObject::Set(set)) => {
                        let canonical = self.intern_set(set);
                        VMValue::HeapRef(canonical)
                    }
                    Some(HeapObject::Map(map)) => {
                        let canonical = self.intern_map(map);
                        VMValue::HeapRef(canonical)
                    }
                    Some(HeapObject::Variant(inst)) => {
                        if self.heap.needs_gc() {
                            let roots: Vec<HeapKey> = self.roots().collect();
                            self.heap.collect(roots);
                        }
                        let canonical = self.heap.intern_variant(inst);
                        VMValue::HeapRef(canonical)
                    }
                    Some(HeapObject::String(s)) => {
                        if self.heap.needs_gc() {
                            let roots: Vec<HeapKey> = self.roots().collect();
                            self.heap.collect(roots);
                        }
                        let canonical = self.heap.intern_string(s);
                        VMValue::HeapRef(canonical)
                    }
                    _ => key, // Non-internable HeapRef (closure, etc.) - use as-is
                }
            }
            _ => key, // Scalar keys - already canonical
        }
    }

    /// Map lookup - O(log n) with lazy canonicalization.
    /// HeapRef keys are canonicalized on first use to ensure content equality.
    pub fn map_get(
        &mut self,
        map: &crate::collections::HashMap<VMValue, VMValue>,
        key: VMValue,
    ) -> Option<VMValue> {
        let canonical_key = self.canonicalize_key(key);
        map.get(&canonical_key).copied()
    }

    /// Map insert - O(log n) with lazy canonicalization.
    /// HeapRef keys are canonicalized on first use to ensure content equality.
    pub fn map_insert(
        &mut self,
        map: &crate::collections::HashMap<VMValue, VMValue>,
        key: VMValue,
        value: VMValue,
    ) -> crate::collections::HashMap<VMValue, VMValue> {
        let canonical_key = self.canonicalize_key(key);
        map.update(canonical_key, value)
    }

    /// Map contains check - O(log n) with lazy canonicalization.
    pub fn map_contains(
        &mut self,
        map: &crate::collections::HashMap<VMValue, VMValue>,
        key: VMValue,
    ) -> bool {
        let canonical_key = self.canonicalize_key(key);
        map.contains_key(&canonical_key)
    }

    // --- GC ---

    /// Collect all roots for GC as a Vec (for use in allocation)
    fn collect_roots(&self) -> Vec<HeapKey> {
        self.roots().collect()
    }

    /// Collect all roots for GC
    fn roots(&self) -> impl Iterator<Item = HeapKey> + '_ {
        let stack_roots = self.stack.iter().filter_map(|v| v.as_heap_ref());
        let global_roots = self.globals.iter().filter_map(|v| v.as_heap_ref());
        let frame_roots = self.frames.iter().filter_map(|f| f.closure);
        let handler_closure_roots = self.handlers.iter().filter_map(|h| h.handler_closure);
        // IMPORTANT: Also root dispatch tables - they're heap-allocated Maps!
        let handler_dispatch_roots = self.handlers.iter().filter_map(|h| h.dispatch_table);
        let optic_roots = [
            self.optic_each,
            self.optic_vals,
            self.optic_keys,
            self.optic_deep,
            self.optic_some,
        ]
        .into_iter();

        // Prototype constants are roots - they contain ClosureTemplates, strings, etc.
        // that must not be collected while the prototype is in use.
        let proto_roots = self
            .prototypes
            .iter()
            .flat_map(|p| p.constants.iter())
            .filter_map(|v| v.as_heap_ref());

        // External roots (e.g., macro closures stored in Runtime)
        let external = self.external_roots.iter().copied();

        // Type registry singleton roots
        let singleton_roots: Vec<HeapKey> = self.type_registry.singleton_keys().collect();
        let singleton_iter = singleton_roots.into_iter();

        stack_roots
            .chain(global_roots)
            .chain(frame_roots)
            .chain(handler_closure_roots)
            .chain(handler_dispatch_roots)
            .chain(optic_roots)
            .chain(proto_roots)
            .chain(external)
            .chain(singleton_iter)
    }
}

fn gcd_i128(mut a: i128, mut b: i128) -> i128 {
    while b != 0 {
        let temp = b;
        b = a % b;
        a = temp;
    }
    a.abs()
}

impl Default for VM {
    fn default() -> Self {
        Self::new()
    }
}

// --- Tests ---

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_vm_creation() {
        let vm = VM::new();
        assert!(vm.stack.is_empty());
        assert!(vm.frames.is_empty());
    }

    // The fib benchmark from the old mod.rs can be restored here
    // once the full implementation is complete
}
