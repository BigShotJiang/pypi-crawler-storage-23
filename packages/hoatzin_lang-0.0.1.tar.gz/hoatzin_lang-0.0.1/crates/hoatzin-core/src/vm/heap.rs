//! GC heap - mark-sweep on slotmap

use hipstr::HipStr;
use lasso::Spur;
use slotmap::SlotMap;
use std::rc::Rc;

use super::frame::CapturedFrame;
use super::type_registry::TypeId;
use super::value::{EffectId, HeapKey, VMValue};

/// GC-managed cell
pub struct GcCell {
    pub marked: bool,
    pub obj: HeapObject,
    /// Cached content hash for Seq/Set/Map (None for non-internable objects)
    pub content_hash: Option<u64>,
}

/// Algebraic data type variant instance
#[derive(Clone)]
pub struct VariantInstance {
    /// Packed tag: (type_id << 8) | variant_idx
    pub tag: u32,
    /// Field values
    pub fields: Vec<VMValue>,
}

impl VariantInstance {
    pub fn new(type_id: TypeId, variant_idx: u8, fields: Vec<VMValue>) -> Self {
        VariantInstance {
            tag: ((type_id.0 as u32) << 8) | (variant_idx as u32),
            fields,
        }
    }

    pub fn type_id(&self) -> TypeId {
        TypeId((self.tag >> 8) as u16)
    }

    pub fn variant_idx(&self) -> u8 {
        (self.tag & 0xFF) as u8
    }
}

/// All heap-allocated objects
#[derive(Clone)]
pub enum HeapObject {
    String(HipStr<'static>),
    Seq(SeqData),
    Set(crate::collections::HashSet<VMValue>),
    Map(crate::collections::HashMap<VMValue, VMValue>),
    Closure(Closure),
    ClosureTemplate(ClosureTemplate),
    Continuation(Continuation),
    Atom(AtomCell),
    Optic(OpticKind),
    KeyBox(VMValue),
    Regex(regex::Regex),
    Effect(Effect),
    Variant(VariantInstance),
}

/// Effect definition with unique ID and operation signatures
#[derive(Clone)]
pub struct Effect {
    /// Globally unique effect identifier
    pub id: EffectId,
    /// Optional effect name (for debugging/display)
    pub name: Option<Spur>,
    /// Operations: (op_name, arity)
    pub ops: Box<[(Spur, u8)]>,
}

/// Unified sequence representation
#[derive(Clone)]
pub struct SeqData {
    pub data: crate::collections::Vector<VMValue>,
    pub kind: SeqKind,
}

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum SeqKind {
    List,
    Vector,
}

/// Compiled pattern for function parameter matching
#[derive(Clone)]
pub enum CompiledPattern {
    Bind {
        slot: u8,
    },
    Wildcard,
    Literal {
        const_idx: u16,
    },
    Sequential {
        required: Box<[CompiledPattern]>,
        rest: Option<Box<CompiledPattern>>,
        as_slot: Option<u8>,
    },
    Associative {
        keys: Box<[(u16, CompiledPattern)]>,
        defaults: Box<[(u16, u16)]>,
        as_slot: Option<u8>,
    },
    Variant {
        type_id: TypeId,
        variant_idx: u8,
        field_patterns: Box<[CompiledPattern]>,
    },
}

/// Function clause metadata
#[derive(Clone)]
pub struct ClauseInfo {
    pub proto_idx: u32,
    pub arity: u8,
    pub is_variadic: bool,
    pub patterns: Box<[CompiledPattern]>,
    pub guard_proto_idx: Option<u32>,
}

/// Heap-stored closure template for multi-arity functions
#[derive(Clone)]
pub struct ClosureTemplate {
    pub clauses: Rc<[ClauseInfo]>,
}

///// Closure: clause list + captured upvalues
#[derive(Clone)]
pub struct Closure {
    pub clauses: Rc<[ClauseInfo]>,
    pub upvalues: Box<[VMValue]>,
}

/// One-shot delimited continuation
#[derive(Clone)]
pub struct Continuation {
    pub stack_segment: Box<[VMValue]>,
    pub frames: Box<[CapturedFrame]>,
    pub handlers: Box<[CapturedHandler]>,
    pub resume_ip: u32,
    pub resume_proto: u32,
    pub resumed: bool,
    /// Stack pointer at the prompt (for proper stack truncation on resume)
    pub prompt_sp: u32,
    /// Frame index at the prompt (for proper frame truncation on resume)
    pub prompt_frame: u32,
    /// Prototype to execute for the with-handler body continuation.
    /// This is the prototype containing the `PopHandler` instruction for the prompt.
    pub body_proto: u32,
    /// IP to start executing the with-handler body continuation.
    /// This is typically the instruction immediately after the suspended call
    /// in the with-handler body (e.g., the `Pop` after `(thunk)`).
    pub body_ip: u32,
    /// Frame pointer for the body continuation frame. This is needed so the
    /// synthetic body frame can access local variables from the enclosing function.
    pub body_fp: u32,
    /// IP where the body ends (PopHandler). When resuming a continuation with no
    /// captured frames, the synthetic body frame should return when IP reaches this.
    pub body_end_ip: u32,
}

#[derive(Clone)]
pub struct CapturedHandler {
    pub effect_id: EffectId,
    pub op_name: Option<Spur>, // For dispatching to specific operation handler
    pub handler_ip: u32,
    pub handler_proto: u32,
    pub handler_closure: Option<HeapKey>,
    pub dispatch_table: Option<HeapKey>, // Map<Symbol, closure_key> for multi-op handlers
    /// Whether the handler was masked at capture time.
    /// This is needed so that forwarding effects from inside a handler clause
    /// (which temporarily masks the current handler) remains correct across
    /// nested handler resumption.
    pub masked: bool,
    pub prompt_sp_offset: u32,
    pub prompt_frame_offset: u32,
    /// Offset for the original handler installation stack pointer.
    /// Used for abort unwinding to the correct boundary.
    pub install_prompt_sp_offset: u32,
    /// Offset for the original handler installation frame index.
    pub install_prompt_frame_offset: u32,
    pub abort_ip: u32, // IP to jump to on abort (instruction after PopHandler)
}

/// Mutable cell
#[derive(Clone)]
pub struct AtomCell {
    pub value: VMValue,
}

/// Optic kinds
#[derive(Clone)]
pub enum OpticKind {
    // Focused (parameterized)
    Key(HeapKey),
    Index(i64),
    Slice {
        from: Option<i64>,
        to: Option<i64>,
    },

    // Traversals (singletons)
    Each,
    Vals,
    Keys,
    Deep,
    Some,

    // Composition
    Compose(Box<[HeapKey]>),

    // Predicated (closure refs)
    Filtered(HeapKey),
    When(HeapKey),

    // Affine (first-match-only wrapper around a traversal)
    First(HeapKey),

    // User-defined
    Custom {
        get: HeapKey,
        set: HeapKey,
    },

    // XPath-specific predicates (don't require closures)
    /// [!:key] - check if map[key] is falsy
    FalsyKey(HeapKey),
    /// [.key op val] - compare map[key] against value
    Compare {
        key: HeapKey,
        op: CompareOp,
        value: VMValue,
    },
}

/// Comparison operators for XPath predicates
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CompareOp {
    Gt,
    Lt,
    Gte,
    Lte,
    Eq,
    Neq,
}

/// The GC heap
pub struct Heap {
    pub objects: SlotMap<HeapKey, GcCell>,

    // GC policy (tunable)
    gc_threshold: usize,
    bytes_allocated: usize,

    // GC inhibit depth: when > 0, GC is deferred (we're in native code)
    gc_inhibit_depth: u32,

    // Intern tables: content_hash -> HeapKey (for hash-consing)
    seq_intern: rustc_hash::FxHashMap<u64, HeapKey>,
    set_intern: rustc_hash::FxHashMap<u64, HeapKey>,
    map_intern: rustc_hash::FxHashMap<u64, HeapKey>,
    variant_intern: rustc_hash::FxHashMap<u64, HeapKey>,
    string_intern: rustc_hash::FxHashMap<u64, HeapKey>,
}

impl Heap {
    pub fn new() -> Self {
        Heap {
            objects: SlotMap::with_key(),
            gc_threshold: 1024,
            bytes_allocated: 0,
            gc_inhibit_depth: 0,
            seq_intern: rustc_hash::FxHashMap::default(),
            set_intern: rustc_hash::FxHashMap::default(),
            map_intern: rustc_hash::FxHashMap::default(),
            variant_intern: rustc_hash::FxHashMap::default(),
            string_intern: rustc_hash::FxHashMap::default(),
        }
    }

    /// Inhibit GC (call before entering native code).
    /// Can be nested - GC resumes when depth returns to 0.
    pub fn inhibit_gc(&mut self) {
        self.gc_inhibit_depth += 1;
    }

    /// Allow GC again (call after exiting native code).
    pub fn allow_gc(&mut self) {
        self.gc_inhibit_depth = self.gc_inhibit_depth.saturating_sub(1);
    }

    /// Check if GC should run (threshold reached and not inhibited)
    pub fn needs_gc(&self) -> bool {
        self.gc_inhibit_depth == 0 && self.objects.len() >= self.gc_threshold
    }

    /// Allocate without triggering GC. Caller is responsible for running GC beforehand if needed.
    pub fn alloc_no_gc(&mut self, obj: HeapObject) -> HeapKey {
        self.objects.insert(GcCell {
            marked: false,
            obj,
            content_hash: None,
        })
    }

    /// Allocate at runtime - may trigger GC (unless inhibited)
    pub fn alloc(&mut self, obj: HeapObject, roots: impl IntoIterator<Item = HeapKey>) -> HeapKey {
        if self.gc_inhibit_depth == 0 {
            self.maybe_collect(roots);
        }
        self.objects.insert(GcCell {
            marked: false,
            obj,
            content_hash: None,
        })
    }

    /// Allocate constant at compile time - no GC check
    pub fn insert_constant(&mut self, obj: HeapObject) -> HeapKey {
        self.objects.insert(GcCell {
            marked: false,
            obj,
            content_hash: None,
        })
    }

    /// Get object by key
    pub fn get(&self, key: HeapKey) -> Option<&HeapObject> {
        self.objects.get(key).map(|c| &c.obj)
    }

    /// Get mutable object by key
    pub fn get_mut(&mut self, key: HeapKey) -> Option<&mut HeapObject> {
        self.objects.get_mut(key).map(|c| &mut c.obj)
    }

    /// Iterate over all heap objects
    pub fn iter_objects(&self) -> impl Iterator<Item = &HeapObject> {
        self.objects.values().map(|c| &c.obj)
    }

    /// Import all objects from another heap, returning old_key -> new_key mapping.
    /// Used when merging compiler heap into VM heap.
    pub fn import_from(&mut self, other: Heap) -> std::collections::HashMap<HeapKey, HeapKey> {
        use std::collections::HashMap;
        let mut key_map: HashMap<HeapKey, HeapKey> = HashMap::new();

        // First pass: import all objects and build key mapping
        for (old_key, cell) in other.objects {
            let new_key = self.objects.insert(cell);
            key_map.insert(old_key, new_key);
        }

        // Second pass: remap internal HeapKey references
        let keys_to_remap: Vec<HeapKey> = key_map.values().copied().collect();
        for new_key in keys_to_remap {
            if let Some(cell) = self.objects.get_mut(new_key) {
                Self::remap_heap_refs(&mut cell.obj, &key_map);
            }
        }

        // Rebuild intern tables to include imported objects
        self.rebuild_intern_tables();

        key_map
    }

    /// Offset prototype references stored in heap objects.
    pub fn offset_proto_refs(&mut self, offset: u32, keys: impl IntoIterator<Item = HeapKey>) {
        for key in keys {
            if let Some(cell) = self.objects.get_mut(key) {
                if let HeapObject::ClosureTemplate(template) = &mut cell.obj {
                    for clause in Rc::make_mut(&mut template.clauses).iter_mut() {
                        clause.proto_idx += offset;
                        if let Some(guard_idx) = clause.guard_proto_idx.as_mut() {
                            *guard_idx += offset;
                        }
                    }
                }
            }
        }
    }

    /// Remap HeapKey references inside a HeapObject using the provided mapping.
    fn remap_heap_refs(
        obj: &mut HeapObject,
        key_map: &std::collections::HashMap<HeapKey, HeapKey>,
    ) {
        match obj {
            HeapObject::String(_) => {}
            HeapObject::Regex(_) => {}
            HeapObject::Seq(seq) => {
                for v in seq.data.iter_mut() {
                    Self::remap_value(v, key_map);
                }
            }
            HeapObject::Set(set) => {
                // crate::collections::HashSet is immutable, rebuild with remapped keys
                let remapped: crate::collections::HashSet<VMValue> = set
                    .iter()
                    .map(|v| {
                        let mut v = *v;
                        Self::remap_value(&mut v, key_map);
                        v
                    })
                    .collect();
                *set = remapped;
            }
            HeapObject::Map(map) => {
                // crate::collections::HashMap is immutable, rebuild with remapped keys
                let remapped: crate::collections::HashMap<VMValue, VMValue> = map
                    .iter()
                    .map(|(k, v)| {
                        let mut k = *k;
                        let mut v = *v;
                        Self::remap_value(&mut k, key_map);
                        Self::remap_value(&mut v, key_map);
                        (k, v)
                    })
                    .collect();
                *map = remapped;
            }
            HeapObject::Closure(c) => {
                for v in c.upvalues.iter_mut() {
                    Self::remap_value(v, key_map);
                }
            }
            HeapObject::ClosureTemplate(_) => {
                // Closure templates contain no heap references
            }
            HeapObject::Continuation(cont) => {
                for v in cont.stack_segment.iter_mut() {
                    Self::remap_value(v, key_map);
                }
                for frame in cont.frames.iter_mut() {
                    if let Some(ref mut key) = frame.closure {
                        if let Some(&new_key) = key_map.get(key) {
                            *key = new_key;
                        }
                    }
                }
                for handler in cont.handlers.iter_mut() {
                    if let Some(ref mut key) = handler.handler_closure {
                        if let Some(&new_key) = key_map.get(key) {
                            *key = new_key;
                        }
                    }
                    if let Some(ref mut key) = handler.dispatch_table {
                        if let Some(&new_key) = key_map.get(key) {
                            *key = new_key;
                        }
                    }
                }
            }
            HeapObject::Effect(_) => {
                // Effects have no heap references to remap
            }
            HeapObject::Atom(cell) => {
                Self::remap_value(&mut cell.value, key_map);
            }
            HeapObject::Optic(kind) => {
                match kind {
                    OpticKind::Key(k) => {
                        if let Some(&new_key) = key_map.get(k) {
                            *k = new_key;
                        }
                    }
                    OpticKind::Compose(keys) => {
                        for k in keys.iter_mut() {
                            if let Some(&new_key) = key_map.get(k) {
                                *k = new_key;
                            }
                        }
                    }
                    OpticKind::Filtered(k) | OpticKind::When(k) | OpticKind::First(k) => {
                        if let Some(&new_key) = key_map.get(k) {
                            *k = new_key;
                        }
                    }
                    OpticKind::Custom { get, set } => {
                        if let Some(&new_key) = key_map.get(get) {
                            *get = new_key;
                        }
                        if let Some(&new_key) = key_map.get(set) {
                            *set = new_key;
                        }
                    }
                    OpticKind::FalsyKey(k) => {
                        if let Some(&new_key) = key_map.get(k) {
                            *k = new_key;
                        }
                    }
                    OpticKind::Compare { key, value, .. } => {
                        if let Some(&new_key) = key_map.get(key) {
                            *key = new_key;
                        }
                        Self::remap_value(value, key_map);
                    }
                    _ => {} // Index, Slice, singletons have no heap refs
                }
            }
            HeapObject::KeyBox(v) => {
                Self::remap_value(v, key_map);
            }
            HeapObject::Variant(inst) => {
                for v in inst.fields.iter_mut() {
                    Self::remap_value(v, key_map);
                }
            }
        }
    }

    /// Remap a single VMValue if it's a HeapRef
    fn remap_value(v: &mut VMValue, key_map: &std::collections::HashMap<HeapKey, HeapKey>) {
        if let VMValue::HeapRef(key) = v {
            if let Some(&new_key) = key_map.get(key) {
                *key = new_key;
            }
        }
    }

    // --- Hash-Consing ---

    /// Compute content hash for a VMValue.
    /// Returns None for non-hashable values (closures, continuations, etc.)
    pub fn hash_vmvalue(&self, v: VMValue) -> Option<u64> {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();

        match v {
            VMValue::Nil => {
                0u8.hash(&mut hasher);
            }
            VMValue::Bool(b) => {
                1u8.hash(&mut hasher);
                b.hash(&mut hasher);
            }
            VMValue::Int(i) => {
                2u8.hash(&mut hasher);
                i.hash(&mut hasher);
            }
            VMValue::Float(f) => {
                3u8.hash(&mut hasher);
                f.to_bits().hash(&mut hasher);
            }
            VMValue::Ratio { numer, denom } => {
                4u8.hash(&mut hasher);
                numer.hash(&mut hasher);
                denom.hash(&mut hasher);
            }
            VMValue::Symbol(s) => {
                5u8.hash(&mut hasher);
                s.hash(&mut hasher);
            }
            VMValue::Keyword(k) => {
                6u8.hash(&mut hasher);
                k.hash(&mut hasher);
            }
            VMValue::NativeFn(i) => {
                7u8.hash(&mut hasher);
                i.hash(&mut hasher);
            }
            VMValue::HeapRef(key) => {
                match self.get(key) {
                    Some(HeapObject::String(s)) => {
                        // Use tag 8 for all strings (same tag for unified string type)
                        8u8.hash(&mut hasher);
                        s.as_str().hash(&mut hasher);
                    }
                    Some(HeapObject::Seq(seq)) => {
                        // Hash already computed and stored in cell
                        if let Some(cell) = self.objects.get(key) {
                            if let Some(h) = cell.content_hash {
                                return Some(h);
                            }
                        }
                        // Compute recursively
                        10u8.hash(&mut hasher);
                        (seq.kind as u8).hash(&mut hasher);
                        seq.data.len().hash(&mut hasher);
                        for elem in seq.data.iter() {
                            let elem_hash = self.hash_vmvalue(*elem)?;
                            elem_hash.hash(&mut hasher);
                        }
                    }
                    Some(HeapObject::Set(set)) => {
                        if let Some(cell) = self.objects.get(key) {
                            if let Some(h) = cell.content_hash {
                                return Some(h);
                            }
                        }
                        11u8.hash(&mut hasher);
                        set.len().hash(&mut hasher);
                        // For sets, use XOR to make hash order-independent
                        let mut combined: u64 = 0;
                        for elem in set.iter() {
                            let elem_hash = self.hash_vmvalue(*elem)?;
                            combined ^= elem_hash;
                        }
                        combined.hash(&mut hasher);
                    }
                    Some(HeapObject::Map(map)) => {
                        if let Some(cell) = self.objects.get(key) {
                            if let Some(h) = cell.content_hash {
                                return Some(h);
                            }
                        }
                        12u8.hash(&mut hasher);
                        map.len().hash(&mut hasher);
                        // For maps, use XOR of (k_hash ^ v_hash) to make order-independent
                        let mut combined: u64 = 0;
                        for (k, v) in map.iter() {
                            let k_hash = self.hash_vmvalue(*k)?;
                            let v_hash = self.hash_vmvalue(*v)?;
                            combined ^= k_hash.wrapping_mul(31).wrapping_add(v_hash);
                        }
                        combined.hash(&mut hasher);
                    }
                    Some(HeapObject::Variant(inst)) => {
                        13u8.hash(&mut hasher);
                        inst.tag.hash(&mut hasher);
                        for field in inst.fields.iter() {
                            let field_hash = self.hash_vmvalue(*field)?;
                            field_hash.hash(&mut hasher);
                        }
                    }
                    // Non-internable heap objects
                    _ => return None,
                }
            }
        }
        Some(hasher.finish())
    }

    /// Compute content hash for a HeapObject.
    /// Returns None for non-internable objects (closures, continuations, etc.)
    pub fn compute_collection_hash(&self, obj: &HeapObject) -> Option<u64> {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();

        match obj {
            HeapObject::Seq(seq) => {
                10u8.hash(&mut hasher);
                (seq.kind as u8).hash(&mut hasher);
                seq.data.len().hash(&mut hasher);
                for elem in seq.data.iter() {
                    let elem_hash = self.hash_vmvalue(*elem)?;
                    elem_hash.hash(&mut hasher);
                }
                Some(hasher.finish())
            }
            HeapObject::Set(set) => {
                11u8.hash(&mut hasher);
                set.len().hash(&mut hasher);
                let mut combined: u64 = 0;
                for elem in set.iter() {
                    let elem_hash = self.hash_vmvalue(*elem)?;
                    combined ^= elem_hash;
                }
                combined.hash(&mut hasher);
                Some(hasher.finish())
            }
            HeapObject::Map(map) => {
                12u8.hash(&mut hasher);
                map.len().hash(&mut hasher);
                let mut combined: u64 = 0;
                for (k, v) in map.iter() {
                    let k_hash = self.hash_vmvalue(*k)?;
                    let v_hash = self.hash_vmvalue(*v)?;
                    combined ^= k_hash.wrapping_mul(31).wrapping_add(v_hash);
                }
                combined.hash(&mut hasher);
                Some(hasher.finish())
            }
            HeapObject::Variant(inst) => {
                13u8.hash(&mut hasher);
                inst.tag.hash(&mut hasher);
                for field in inst.fields.iter() {
                    let field_hash = self.hash_vmvalue(*field)?;
                    field_hash.hash(&mut hasher);
                }
                Some(hasher.finish())
            }
            // Non-internable
            _ => None,
        }
    }

    /// Check if two HeapObjects are structurally equal.
    /// Used for hash collision detection in intern tables.
    pub fn structurally_equal(&self, a: &HeapObject, b: &HeapObject) -> bool {
        match (a, b) {
            (HeapObject::String(a), HeapObject::String(b)) => a == b,
            (HeapObject::Seq(a), HeapObject::Seq(b)) => {
                if a.kind != b.kind || a.data.len() != b.data.len() {
                    return false;
                }
                a.data
                    .iter()
                    .zip(b.data.iter())
                    .all(|(x, y)| self.values_equal(*x, *y))
            }
            (HeapObject::Set(a), HeapObject::Set(b)) => {
                if a.len() != b.len() {
                    return false;
                }
                for item in a.iter() {
                    if !b.iter().any(|x| self.values_equal(*item, *x)) {
                        return false;
                    }
                }
                true
            }
            (HeapObject::Map(a), HeapObject::Map(b)) => {
                if a.len() != b.len() {
                    return false;
                }
                for (k, v) in a.iter() {
                    match b.iter().find(|(k2, _)| self.values_equal(*k, **k2)) {
                        Some((_, v2)) if self.values_equal(*v, *v2) => {}
                        _ => return false,
                    }
                }
                true
            }
            (HeapObject::Variant(a), HeapObject::Variant(b)) => {
                if a.tag != b.tag || a.fields.len() != b.fields.len() {
                    return false;
                }
                a.fields
                    .iter()
                    .zip(b.fields.iter())
                    .all(|(x, y)| self.values_equal(*x, *y))
            }
            _ => false,
        }
    }

    /// Check if two VMValues are equal (for intern structural equality check).
    fn values_equal(&self, a: VMValue, b: VMValue) -> bool {
        match (a, b) {
            (VMValue::Nil, VMValue::Nil) => true,
            (VMValue::Bool(a), VMValue::Bool(b)) => a == b,
            (VMValue::Int(a), VMValue::Int(b)) => a == b,
            (VMValue::Float(a), VMValue::Float(b)) => a == b,
            (
                VMValue::Ratio {
                    numer: an,
                    denom: ad,
                },
                VMValue::Ratio {
                    numer: bn,
                    denom: bd,
                },
            ) => an == bn && ad == bd,
            (VMValue::Symbol(a), VMValue::Symbol(b)) => a == b,
            (VMValue::Keyword(a), VMValue::Keyword(b)) => a == b,
            (VMValue::NativeFn(a), VMValue::NativeFn(b)) => a == b,
            (VMValue::HeapRef(a), VMValue::HeapRef(b)) => {
                // Same key means same interned object
                if a == b {
                    return true;
                }
                // Fall back to structural comparison (handles strings and collections)
                match (self.get(a), self.get(b)) {
                    (Some(obj_a), Some(obj_b)) => self.structurally_equal(obj_a, obj_b),
                    _ => false,
                }
            }
            _ => false,
        }
    }

    // --- Interning Methods ---

    /// Intern a sequence. If an identical sequence already exists, return its key.
    /// Caller is responsible for running GC beforehand if needed.
    pub fn intern_seq(&mut self, seq: SeqData) -> HeapKey {
        // Compute content hash
        let hash = match self.compute_collection_hash(&HeapObject::Seq(seq.clone())) {
            Some(h) => h,
            None => {
                // Contains non-internable elements (closures, etc.) - just allocate
                return self.alloc_no_gc(HeapObject::Seq(seq));
            }
        };

        // Check intern table
        if let Some(&existing_key) = self.seq_intern.get(&hash) {
            // Verify structural equality (handle hash collisions)
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Seq(seq.clone()), existing) {
                    return existing_key;
                }
            }
        }

        // Not found - allocate and register
        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Seq(seq),
            content_hash: Some(hash),
        });
        self.seq_intern.insert(hash, key);
        key
    }

    /// Intern a set. If an identical set already exists, return its key.
    /// Caller is responsible for running GC beforehand if needed.
    pub fn intern_set(&mut self, set: crate::collections::HashSet<VMValue>) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Set(set.clone())) {
            Some(h) => h,
            None => {
                return self.alloc_no_gc(HeapObject::Set(set));
            }
        };

        if let Some(&existing_key) = self.set_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Set(set.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Set(set),
            content_hash: Some(hash),
        });
        self.set_intern.insert(hash, key);
        key
    }

    /// Intern a map. If an identical map already exists, return its key.
    /// Caller is responsible for running GC beforehand if needed.
    pub fn intern_map(&mut self, map: crate::collections::HashMap<VMValue, VMValue>) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Map(map.clone())) {
            Some(h) => h,
            None => {
                return self.alloc_no_gc(HeapObject::Map(map));
            }
        };

        if let Some(&existing_key) = self.map_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Map(map.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Map(map),
            content_hash: Some(hash),
        });
        self.map_intern.insert(hash, key);
        key
    }

    /// Intern a string. If an identical string already exists, return its key.
    /// Caller is responsible for running GC beforehand if needed.
    pub fn intern_string(&mut self, s: HipStr<'static>) -> HeapKey {
        use std::collections::hash_map::DefaultHasher;
        use std::hash::{Hash, Hasher};

        // Compute content hash
        let mut hasher = DefaultHasher::new();
        7u8.hash(&mut hasher); // Tag for strings
        s.as_str().hash(&mut hasher);
        let hash = hasher.finish();

        // Check intern table
        if let Some(&existing_key) = self.string_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if let HeapObject::String(existing_s) = existing {
                    if s.as_str() == existing_s.as_str() {
                        return existing_key;
                    }
                }
            }
        }

        // Not found - allocate and register
        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::String(s),
            content_hash: Some(hash),
        });
        self.string_intern.insert(hash, key);
        key
    }

    /// Intern a constant sequence at compile time (no GC check).
    pub fn intern_seq_constant(&mut self, seq: SeqData) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Seq(seq.clone())) {
            Some(h) => h,
            None => {
                return self.insert_constant(HeapObject::Seq(seq));
            }
        };

        if let Some(&existing_key) = self.seq_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Seq(seq.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Seq(seq),
            content_hash: Some(hash),
        });
        self.seq_intern.insert(hash, key);
        key
    }

    /// Intern a constant set at compile time (no GC check).
    pub fn intern_set_constant(&mut self, set: crate::collections::HashSet<VMValue>) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Set(set.clone())) {
            Some(h) => h,
            None => {
                return self.insert_constant(HeapObject::Set(set));
            }
        };

        if let Some(&existing_key) = self.set_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Set(set.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Set(set),
            content_hash: Some(hash),
        });
        self.set_intern.insert(hash, key);
        key
    }

    /// Intern a constant map at compile time (no GC check).
    pub fn intern_map_constant(
        &mut self,
        map: crate::collections::HashMap<VMValue, VMValue>,
    ) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Map(map.clone())) {
            Some(h) => h,
            None => {
                return self.insert_constant(HeapObject::Map(map));
            }
        };

        if let Some(&existing_key) = self.map_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Map(map.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Map(map),
            content_hash: Some(hash),
        });
        self.map_intern.insert(hash, key);
        key
    }

    /// Intern a variant instance. If an identical one exists, return its key.
    pub fn intern_variant(&mut self, inst: VariantInstance) -> HeapKey {
        let hash = match self.compute_collection_hash(&HeapObject::Variant(inst.clone())) {
            Some(h) => h,
            None => {
                return self.alloc_no_gc(HeapObject::Variant(inst));
            }
        };

        if let Some(&existing_key) = self.variant_intern.get(&hash) {
            if let Some(existing) = self.get(existing_key) {
                if self.structurally_equal(&HeapObject::Variant(inst.clone()), existing) {
                    return existing_key;
                }
            }
        }

        let key = self.objects.insert(GcCell {
            marked: false,
            obj: HeapObject::Variant(inst),
            content_hash: Some(hash),
        });
        self.variant_intern.insert(hash, key);
        key
    }

    /// Rebuild intern tables after GC (called from sweep).
    fn rebuild_intern_tables(&mut self) {
        self.seq_intern.clear();
        self.set_intern.clear();
        self.map_intern.clear();
        self.variant_intern.clear();
        self.string_intern.clear();

        for (key, cell) in self.objects.iter() {
            if let Some(hash) = cell.content_hash {
                match &cell.obj {
                    HeapObject::Seq(_) => {
                        self.seq_intern.insert(hash, key);
                    }
                    HeapObject::Set(_) => {
                        self.set_intern.insert(hash, key);
                    }
                    HeapObject::Map(_) => {
                        self.map_intern.insert(hash, key);
                    }
                    HeapObject::Variant(_) => {
                        self.variant_intern.insert(hash, key);
                    }
                    HeapObject::String(_) => {
                        self.string_intern.insert(hash, key);
                    }
                    _ => {}
                }
            }
        }
    }

    // --- GC ---

    fn maybe_collect(&mut self, roots: impl IntoIterator<Item = HeapKey>) {
        if self.objects.len() >= self.gc_threshold {
            self.collect(roots);
        }
    }

    pub fn collect(&mut self, roots: impl IntoIterator<Item = HeapKey>) {
        self.mark(roots);
        self.sweep();
    }

    fn mark(&mut self, roots: impl IntoIterator<Item = HeapKey>) {
        let mut worklist: Vec<HeapKey> = roots.into_iter().collect();

        while let Some(key) = worklist.pop() {
            if let Some(cell) = self.objects.get_mut(key) {
                if !cell.marked {
                    cell.marked = true;
                    Self::trace_object(&cell.obj, &mut worklist);
                }
            }
        }
    }

    fn trace_object(obj: &HeapObject, worklist: &mut Vec<HeapKey>) {
        match obj {
            HeapObject::String(_) => {}
            HeapObject::Seq(seq) => {
                for v in seq.data.iter() {
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
            }
            HeapObject::Set(set) => {
                for v in set.iter() {
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
            }
            HeapObject::Map(map) => {
                for (k, v) in map.iter() {
                    if let VMValue::HeapRef(key) = k {
                        worklist.push(*key);
                    }
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
            }
            HeapObject::Closure(c) => {
                for v in c.upvalues.iter() {
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
            }
            HeapObject::ClosureTemplate(_) => {
                // Closure templates contain no heap references
            }
            HeapObject::Continuation(cont) => {
                for v in cont.stack_segment.iter() {
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
                for frame in cont.frames.iter() {
                    if let Some(key) = frame.closure {
                        worklist.push(key);
                    }
                }
                for handler in cont.handlers.iter() {
                    if let Some(key) = handler.handler_closure {
                        worklist.push(key);
                    }
                    if let Some(key) = handler.dispatch_table {
                        worklist.push(key);
                    }
                }
            }
            HeapObject::Effect(_) => {
                // Effects have no heap references (only Spurs)
            }
            HeapObject::Atom(cell) => {
                if let VMValue::HeapRef(key) = cell.value {
                    worklist.push(key);
                }
            }
            HeapObject::Optic(kind) => {
                match kind {
                    OpticKind::Key(k) => worklist.push(*k),
                    OpticKind::Compose(keys) => worklist.extend(keys.iter().copied()),
                    OpticKind::Filtered(k)
                    | OpticKind::When(k)
                    | OpticKind::FalsyKey(k)
                    | OpticKind::First(k) => worklist.push(*k),
                    OpticKind::Custom { get, set } => {
                        worklist.push(*get);
                        worklist.push(*set);
                    }
                    OpticKind::Compare { key, value, .. } => {
                        worklist.push(*key);
                        if let VMValue::HeapRef(k) = value {
                            worklist.push(*k);
                        }
                    }
                    _ => {} // Index, Slice, singletons have no heap refs
                }
            }
            HeapObject::KeyBox(v) => {
                if let VMValue::HeapRef(key) = v {
                    worklist.push(*key);
                }
            }
            HeapObject::Regex(_) => {} // No heap refs
            HeapObject::Variant(inst) => {
                for v in inst.fields.iter() {
                    if let VMValue::HeapRef(key) = v {
                        worklist.push(*key);
                    }
                }
            }
        }
    }

    fn sweep(&mut self) {
        self.objects.retain(|_, cell| {
            if cell.marked {
                cell.marked = false;
                true
            } else {
                false
            }
        });

        // Rebuild intern tables to remove stale entries
        self.rebuild_intern_tables();

        // Grow threshold
        self.gc_threshold = (self.objects.len() * 2).max(1024);
    }
}

impl Default for Heap {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_intern_same_seq_same_key() {
        let mut heap = Heap::new();
        let seq1 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(1), VMValue::Int(2)]),
            kind: SeqKind::Vector,
        };
        let seq2 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(1), VMValue::Int(2)]),
            kind: SeqKind::Vector,
        };
        let k1 = heap.intern_seq(seq1);
        let k2 = heap.intern_seq(seq2);
        assert_eq!(k1, k2, "Same content sequences should have same key");
    }

    #[test]
    fn test_intern_different_seq_different_key() {
        let mut heap = Heap::new();
        let seq1 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(1), VMValue::Int(2)]),
            kind: SeqKind::Vector,
        };
        let seq2 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(3), VMValue::Int(4)]),
            kind: SeqKind::Vector,
        };
        let k1 = heap.intern_seq(seq1);
        let k2 = heap.intern_seq(seq2);
        assert_ne!(
            k1, k2,
            "Different content sequences should have different keys"
        );
    }

    #[test]
    fn test_intern_same_map_same_key() {
        let mut heap = Heap::new();
        let mut map1 = crate::collections::HashMap::new();
        map1.insert(VMValue::Int(1), VMValue::Int(10));
        map1.insert(VMValue::Int(2), VMValue::Int(20));
        let mut map2 = crate::collections::HashMap::new();
        map2.insert(VMValue::Int(1), VMValue::Int(10));
        map2.insert(VMValue::Int(2), VMValue::Int(20));

        let k1 = heap.intern_map(map1);
        let k2 = heap.intern_map(map2);
        assert_eq!(k1, k2, "Same content maps should have same key");
    }

    #[test]
    fn test_intern_same_set_same_key() {
        let mut heap = Heap::new();
        let mut set1 = crate::collections::HashSet::new();
        set1.insert(VMValue::Int(1));
        set1.insert(VMValue::Int(2));
        let mut set2 = crate::collections::HashSet::new();
        set2.insert(VMValue::Int(1));
        set2.insert(VMValue::Int(2));

        let k1 = heap.intern_set(set1);
        let k2 = heap.intern_set(set2);
        assert_eq!(k1, k2, "Same content sets should have same key");
    }

    #[test]
    fn test_intern_nested_collections() {
        let mut heap = Heap::new();

        // Create inner vectors
        let inner1 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(1)]),
            kind: SeqKind::Vector,
        };
        let inner_key1 = heap.intern_seq(inner1);

        let inner2 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(2)]),
            kind: SeqKind::Vector,
        };
        let inner_key2 = heap.intern_seq(inner2);

        // Create outer vectors containing inner vectors
        let outer1 = SeqData {
            data: crate::collections::Vector::from(vec![
                VMValue::HeapRef(inner_key1),
                VMValue::HeapRef(inner_key2),
            ]),
            kind: SeqKind::Vector,
        };
        let outer_k1 = heap.intern_seq(outer1);

        // Create same structure again
        let inner1b = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(1)]),
            kind: SeqKind::Vector,
        };
        let inner_key1b = heap.intern_seq(inner1b);
        assert_eq!(inner_key1, inner_key1b, "Inner vectors should be interned");

        let inner2b = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(2)]),
            kind: SeqKind::Vector,
        };
        let inner_key2b = heap.intern_seq(inner2b);
        assert_eq!(inner_key2, inner_key2b, "Inner vectors should be interned");

        let outer2 = SeqData {
            data: crate::collections::Vector::from(vec![
                VMValue::HeapRef(inner_key1b),
                VMValue::HeapRef(inner_key2b),
            ]),
            kind: SeqKind::Vector,
        };
        let outer_k2 = heap.intern_seq(outer2);

        assert_eq!(
            outer_k1, outer_k2,
            "Nested vectors with same content should have same key"
        );
    }

    #[test]
    fn test_intern_preserves_after_gc() {
        let mut heap = Heap::new();

        // Create and intern a sequence
        let seq1 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(42)]),
            kind: SeqKind::Vector,
        };
        let k1 = heap.intern_seq(seq1);

        // Run GC with the key as a root
        heap.collect(vec![k1]);

        // Intern same content again
        let seq2 = SeqData {
            data: crate::collections::Vector::from(vec![VMValue::Int(42)]),
            kind: SeqKind::Vector,
        };
        let k2 = heap.intern_seq(seq2);

        assert_eq!(k1, k2, "Interning should work after GC");
    }
}
