;; --- Algebraic Data Types ---

(defdata ReduceSignal (Reduced [value]))
(defn reduced?
  "a -> Bool
  True if value is a Reduced wrapper."
  [x] (ReduceSignal? x))
(defn unreduced
  "Reduced a -> a
  Extracts value from Reduced wrapper."
  [x] (:value x))

;; --- Testing ---

(defmacro is
  "a -> Nil
  Asserts test is truthy."
  [test]
  `(assert ~test))

;; --- Console I/O ---
;; These functions perform the console effect.
;; A native handler must be registered for them to work.

(defn print
  "a ... -> <console> Nil
  Prints arguments to console."
  [& args]
  (console/print (apply str args)))

(defn println
  "a ... -> <console> Nil
  Prints arguments with newline."
  [& args]
  (console/println (apply str args)))

(defn prn
  "a ... -> <console> Nil
  Prints readable representation with newline."
  [& args]
  (console/println (apply pr-str args)))

;; --- Timing ---

(defmacro time
  "a -> <console> a
  Evaluates expr, prints elapsed time, returns result."
  [expr]
  `(let [start# (nano-time)
         result# ~expr
         elapsed# (/ (- (nano-time) start#) 1000000.0)]
     (println (str "Elapsed time: " elapsed# " msecs"))
     result#))

;; --- Conditionals ---

(defmacro when
  "Bool × a ... -> a | Nil
  Evaluates body when test is truthy."
  [test & body]
  `(if ~test (do ~@body) nil))

(defmacro when-not
  "Bool × a ... -> a | Nil
  Evaluates body when test is falsy."
  [test & body]
  `(if ~test nil (do ~@body)))

(defmacro if-not
  "Bool × a × a -> a
  Reversed if: then on false, else on true."
  [test then else]
  `(if ~test ~else ~then))

;; --- Boolean operators ---
;; Note: and/or are now special forms for proper short-circuit evaluation

(defn not
  "a -> Bool
  Logical complement."
  [x]
  (if x false true))

(defn not=
  "a × a -> Bool
  True if not equal."
  [a b]
  (not (= a b)))

(defn some?
  "a -> Bool
  True if not nil."
  [x]
  (not (nil? x)))

(defn true?
  "a -> Bool
  True if value is true."
  [x]
  (= x true))

(defn false?
  "a -> Bool
  True if value is false."
  [x]
  (= x false))

;; --- Arithmetic ---

(defn inc
  "Num -> Num
  Increments by one."
  [n] (+ n 1))
(defn dec
  "Num -> Num
  Decrements by one."
  [n] (- n 1))
(defn pos?
  "Num -> Bool
  True if positive."
  [n] (> n 0))
(defn neg?
  "Num -> Bool
  True if negative."
  [n] (< n 0))
(defn zero?
  "Num -> Bool
  True if zero."
  [n] (= n 0))
(defn abs
  "Num -> Num
  Absolute value."
  [n] (if (< n 0) (- 0 n) n))

;; Variadic min/max
(defn min
  "Num ... -> Num
  Returns the smallest argument."
  ([a] a)
  ([a b] (if (< a b) a b))
  ([a b & more] (reduce min (min a b) more)))

(defn max
  "Num ... -> Num
  Returns the largest argument."
  ([a] a)
  ([a b] (if (> a b) a b))
  ([a b & more] (reduce max (max a b) more)))

;; --- Collection helpers ---

(defn second
  "Coll a -> a | Nil
  Returns the second element."
  [coll]
  (first (rest coll)))

(defn identity
  "a -> a
  Returns its argument."
  [x] x)

(defn constantly
  "a -> (b ... -> a)
  Returns a function that always returns x."
  [x]
  (fn [& _] x))

;; Multi-arity comp
(defn comp
  "(b -> c) × (a -> b) -> (a -> c)
  Composes functions right-to-left."
  ([] identity)
  ([f] f)
  ([f g] (fn [x] (f (g x))))
  ([f g & more]
   (reduce comp (cons f (cons g more)))))

;; Multi-arity partial
(defn partial
  "(a ... -> b) × a ... -> (a ... -> b)
  Partially applies f with leading arguments."
  ([f] f)
  ([f a] (fn [& args] (apply f a args)))
  ([f a b] (fn [& args] (apply f a b args)))
  ([f a b c & more]
   (fn [& args] (apply f a b c (concat more args)))))

;; Threading macros
(defmacro ->
  "a × Form ... -> b
  Threads value through forms as first argument."
  [x & forms]
  (loop [acc x forms forms]
    (if (empty? forms)
      acc
      (let [form (first forms)
            threaded (if (list? form)
                       (cons (first form) (cons acc (rest form)))
                       (list form acc))]
        (recur threaded (rest forms))))))

(defmacro ->>
  "a × Form ... -> b
  Threads value through forms as last argument."
  [x & forms]
  (loop [acc x forms forms]
    (if (empty? forms)
      acc
      (let [form (first forms)
            threaded (if (list? form)
                       (concat form (list acc))
                       (list form acc))]
        (recur threaded (rest forms))))))

;; cond macro
(defmacro cond
  "(Bool × a) ... -> a | Nil
  Evaluates test-expr pairs, returns first truthy branch."
  [& clauses]
  (if (empty? clauses)
    nil
    (list 'if (first clauses)
          (second clauses)
          (cons 'cond (rest (rest clauses))))))

;; case macro - matches value against literal keys
(defmacro case
  "a × (a × b) ... -> b | Nil
  Matches value against literal keys."
  [expr & clauses]
  (let [v '__case_val__
        clauses-vec (vec clauses)
        ;; Check if we have a default (odd number of clauses)
        has-default (odd? (count clauses-vec))
        default-val (if has-default (last clauses-vec) nil)
        pairs (if has-default (drop-last clauses-vec) clauses-vec)]
    ;; Build nested if from pairs
    (list 'let [v expr]
      (loop [result default-val
             remaining (reverse pairs)]
        (if (empty? remaining)
          result
          (let [body (first remaining)
                test-val (second remaining)]
            (recur (list 'if (list '= v test-val) body result)
                   (drop 2 remaining))))))))

;; --- Map operations ---

(defn get-in
  "Map k v × Vector k -> v | Nil
  Looks up nested key path."
  ([m ks] (reduce get m ks))
  ([m ks not-found]
   (loop [cur m remaining ks]
     (if (empty? remaining)
       cur
       (let [v (get cur (first remaining))]
         (if (nil? v)
           not-found
           (recur v (rest remaining))))))))

(defn update
  "Map k v × k × (v -> v) -> Map k v
  Updates value at key by applying f."
  [m k f]
  (assoc m k (f (get m k))))

(defn update-in
  "Map k v × Vector k × (v -> v) -> Map k v
  Updates value at nested key path."
  [m ks f]
  (if (empty? ks)
    (f m)
    (assoc m (first ks) (update-in (get m (first ks)) (rest ks) f))))

(defn merge
  "Map k v ... -> Map k v
  Merges maps left-to-right."
  [& maps]
  (reduce (fn [acc m]
            (if (nil? m)
              acc
              (reduce (fn [a kv] (assoc a (first kv) (second kv))) acc m)))
          {}
          maps))

;; --- Sequence operations ---

(defn some
  "(a -> Bool) × Coll a -> a | Nil
  First element satisfying pred, or nil."
  [pred coll]
  (if (empty? coll)
    nil
    (if (pred (first coll))
      (first coll)
      (some pred (rest coll)))))

(defn every?
  "(a -> Bool) × Coll a -> Bool
  True if all elements satisfy pred."
  [pred coll]
  (if (empty? coll)
    true
    (if (pred (first coll))
      (every? pred (rest coll))
      false)))

;; range is now a native function that supports 1-3 arity

(defn frequencies
  "Coll a -> Map a Int
  Counts occurrences of each element."
  [coll]
  (reduce (fn [acc x]
            (assoc acc x (+ 1 (get acc x 0))))
          {}
          coll))

(defn partition
  "Int × Coll a -> Vector (Vector a)
  Partitions into groups of n (drops incomplete)."
  [n coll]
  (loop [result [] remaining (vec coll)]
    (if (< (count remaining) n)
      result
      (recur (conj result (take n remaining)) (vec (drop n remaining))))))

(defn partition-all
  "Int × Coll a -> Vector (Vector a)
  Partitions into groups of n (keeps incomplete)."
  [n coll]
  (loop [result [] remaining (vec coll)]
    (if (empty? remaining)
      result
      (recur (conj result (take n remaining)) (vec (drop n remaining))))))

(defn interpose
  "a × Coll a -> Vector a
  Inserts separator between elements."
  [sep coll]
  (drop 1 (reduce (fn [acc x] (conj (conj acc sep) x)) [] coll)))

(defn interleave
  "Coll a ... -> Vector a
  Interleaves elements from collections."
  [& colls]
  (loop [result [] cs (vec (map vec colls))]
    (if (some empty? cs)
      result
      (recur (vec (concat result (map first cs))) (vec (map rest cs))))))

(defn flatten
  "Coll a -> Vector a
  Recursively flattens nested collections."
  [coll]
  (reduce (fn [acc x]
            (if (coll? x)
              (vec (concat acc (flatten x)))
              (conj acc x)))
          []
          coll))

(defn distinct
  "Coll a -> Vector a
  Removes duplicates, preserving order."
  [coll]
  (loop [seen #{} result [] remaining (vec coll)]
    (if (empty? remaining)
      result
      (let [x (first remaining)]
        (if (contains? seen x)
          (recur seen result (vec (rest remaining)))
          (recur (conj seen x) (conj result x) (vec (rest remaining))))))))

(defn group-by
  "(a -> k) × Coll a -> Map k (Vector a)
  Groups elements by the value of f."
  [f coll]
  (reduce (fn [acc x]
            (let [k (f x)]
              (assoc acc k (conj (get acc k []) x))))
          {}
          coll))

;; --- Optics: Curried update operators (following coarse pattern) ---

;; Helper to create curried update operators
;; (op-curry f) returns a function that:
;;   - with 3 args (l n s): applies (over l (partial f n) s)
;;   - with 2 args (l n): returns a function waiting for s
(defn op-curry [f]
  (fn
    ([l n s] (over l (partial f n) s))
    ([l n] (fn [s] (over l (partial f n) s)))))

(def +=
  "Optic s Num × Num × s -> s
  Adds n at optic focus."
  (op-curry +))
(def -=
  "Optic s Num × Num × s -> s
  Subtracts n at optic focus."
  (op-curry (fn [a b] (- b a))))
(def *=
  "Optic s Num × Num × s -> s
  Multiplies by n at optic focus."
  (op-curry *))

;; set= is special - it uses sett, not over
(defn set=
  "Optic s a × a × s -> s
  Sets value at optic focus."
  ([l v s] (sett l v s))
  ([l v] (fn [s] (sett l v s))))

;; ++= for concatenation
(def ++=
  "Optic s Coll × Coll × s -> s
  Concatenates at optic focus."
  (op-curry (fn [a b] (concat b a))))

;; conj= for appending element(s)
(def conj=
  "Optic s Coll × a × s -> s
  Conjoins element at optic focus."
  (op-curry (fn [a b] (conj b a))))

;; +>> zooming macro (following coarse pattern)
(defmacro +>>
  "Optic × Form ... × s -> s
  Threads data through ops at optic focus."
  [lns & forms]
  (let [data (last forms)
        ops (drop-last forms)]
    (list 'over lns
          (list 'fn ['x]
                (cons '->> (cons 'x ops)))
          data)))

;; --- Optics: deflens macro ---

(defmacro deflens
  "Symbol × (Vector | :get × Fn × :set × Fn) -> Optic
  Defines a named lens from path or getter/setter."
  [name & args]
  (if (and (= (count args) 1) (vector? (first args)))
    ;; Path shorthand: (deflens name [:a :b :c])
    (list 'def name (first args))
    ;; Check for :get/:set form
    (if (and (>= (count args) 4)
             (= (first args) :get)
             (= (nth args 2) :set))
      ;; Full form: (deflens name :get getter :set setter)
      (list 'def name (list 'lens (second args) (nth args 3)))
      ;; Otherwise treat first arg as path
      (list 'def name (first args)))))

;; --- Collection Functions (Phase 6) ---

(defn butlast
  "Coll a -> Vector a | Nil
  All but the last element."
  [coll]
  (let [v (vec coll)]
    (if (empty? v)
      nil
      (vec (take (dec (count v)) v)))))

(defn assoc-in
  "Map k v × Vector k × v -> Map k v
  Associates value at nested key path."
  [m ks v]
  (if (= (count ks) 1)
    (assoc m (first ks) v)
    (assoc m (first ks) (assoc-in (get m (first ks) {}) (rest ks) v))))

(defn select-keys
  "Map k v × Coll k -> Map k v
  Returns map with only specified keys."
  [m keyseq]
  (reduce (fn [acc k]
            (if (contains? m k)
              (assoc acc k (get m k))
              acc))
          {}
          keyseq))

(defn zipmap
  "Coll k × Coll v -> Map k v
  Creates map from keys and values."
  [keys vals]
  (loop [m {} ks (seq keys) vs (seq vals)]
    (if (or (empty? ks) (empty? vs))
      m
      (recur (assoc m (first ks) (first vs)) (rest ks) (rest vs)))))

(defn update-keys
  "Map k v × (k -> k2) -> Map k2 v
  Applies f to each key."
  [m f]
  (reduce (fn [acc kv]
            (assoc acc (f (first kv)) (second kv)))
          {}
          m))

(defn update-vals
  "Map k v × (v -> v2) -> Map k v2
  Applies f to each value."
  [m f]
  (reduce (fn [acc kv]
            (assoc acc (first kv) (f (second kv))))
          {}
          m))

;; --- Sequence Functions (Phase 7) ---

(defn mapcat
  "(a -> Coll b) × Coll a -> Vector b
  Maps f then concatenates results."
  [f coll]
  (reduce (fn [acc x] (vec (concat acc (f x)))) [] coll))

(defn complement
  "(a -> Bool) -> (a -> Bool)
  Returns negation of predicate."
  [f]
  (fn [& args] (not (apply f args))))

(defn remove
  "(a -> Bool) × Coll a -> Vector a
  Elements not satisfying pred."
  [pred coll]
  (filter (complement pred) coll))

(defn keep
  "(a -> b | Nil) × Coll a -> Vector b
  Maps f, keeps non-nil results."
  [f coll]
  (filter some? (map f coll)))

(defn take-while
  "(a -> Bool) × Coll a -> Vector a
  Takes elements while pred holds."
  [pred coll]
  (loop [result [] remaining (seq coll)]
    (if (or (empty? remaining) (not (pred (first remaining))))
      result
      (recur (conj result (first remaining)) (rest remaining)))))

(defn drop-while
  "(a -> Bool) × Coll a -> Vector a
  Drops elements while pred holds."
  [pred coll]
  (loop [remaining (seq coll)]
    (if (or (empty? remaining) (not (pred (first remaining))))
      (vec remaining)
      (recur (rest remaining)))))

(defn partition-by
  "(a -> k) × Coll a -> Vector (Vector a)
  Splits when f returns a new value."
  [f coll]
  (if (empty? coll)
    []
    (loop [result [] current [(first coll)]
           current-key (f (first coll)) remaining (rest coll)]
      (if (empty? remaining)
        (conj result current)
        (let [x (first remaining)
              k (f x)]
          (if (= k current-key)
            (recur result (conj current x) current-key (rest remaining))
            (recur (conj result current) [x] k (rest remaining))))))))

(defn includes?
  "Coll a × a -> Bool
  True if collection contains element."
  [coll x]
  (some? (some #(= % x) coll)))

(defn not-any?
  "(a -> Bool) × Coll a -> Bool
  True if no element satisfies pred."
  [pred coll]
  (not (some pred coll)))

;; --- Math helpers (Phase 7) ---

(defn clamp
  "Num × Num × Num -> Num
  Clamps value between min and max."
  [x min-val max-val]
  (min (max x min-val) max-val))

(defn degrees
  "Num -> Float
  Converts radians to degrees."
  [radians]
  (* radians (/ 180 (pi))))

(defn radians
  "Num -> Float
  Converts degrees to radians."
  [degrees]
  (* degrees (/ (pi) 180)))

;; --- Function Combinators (Phase 8) ---

(defn juxt
  "(a -> b) ... -> (a -> Vector b)
  Applies each fn, returns vector of results."
  [& fns]
  (fn [& args]
    (vec (map (fn [f] (apply f args)) fns))))

;; --- Predicates (Phase 4 - stdlib) ---

(defn blank?
  "String | Nil -> Bool
  True if nil, empty, or all whitespace."
  [s]
  (or (nil? s) (= s "") (= (trim s) "")))

;; --- Additional Macros (Phase 9) ---

(defmacro as->
  "a × Symbol × Form ... -> b
  Threads through forms, binding to name."
  [expr name & forms]
  (if (empty? forms)
    expr
    (let [first-form (first forms)
          rest-forms (rest forms)]
      `(let [~name ~expr]
         ~(if (empty? rest-forms)
            first-form
            `(as-> ~first-form ~name ~@rest-forms))))))

(defmacro if-let
  "[Symbol × a] × b × b -> b
  Binds test result; then if truthy, else otherwise."
  [bindings then else]
  (let [binding (first bindings)
        test (second bindings)]
    `(let [temp# ~test]
       (if temp#
         (let [~binding temp#] ~then)
         ~else))))

(defmacro when-let
  "[Symbol × a] × b ... -> b | Nil
  Binds test result; evaluates body if truthy."
  [bindings & body]
  (let [binding (first bindings)
        test (second bindings)]
    `(let [temp# ~test]
       (when temp#
         (let [~binding temp#] ~@body)))))

(defmacro condp
  "(a × b -> Bool) × b × (a × c) ... -> c | Nil
  Matches using a shared predicate and expression."
  [pred expr & clauses]
  (let [v '__condp_val__
        clauses-vec (vec clauses)
        has-default (odd? (count clauses-vec))
        default-val (if has-default (last clauses-vec) nil)
        pairs (if has-default (drop-last clauses-vec) clauses-vec)]
    (list 'let [v expr]
      (loop [result default-val
             remaining (reverse pairs)]
        (if (empty? remaining)
          result
          (let [body (first remaining)
                test-val (second remaining)]
            (recur (list 'if (list pred test-val v) body result)
                   (drop 2 remaining))))))))

(defmacro doseq
  "[Symbol × Coll] × a ... -> Nil
  Iterates over collection for side effects."
  [bindings & body]
  (let [binding (first bindings)
        coll (second bindings)]
    `(do
       (reduce (fn [_ ~binding] ~@body nil) nil ~coll)
       nil)))

(defmacro dotimes
  "[Symbol × Int] × a ... -> Nil
  Executes body n times."
  [bindings & body]
  (let [binding (first bindings)
        n (second bindings)]
    `(do
       (reduce (fn [_ ~binding] ~@body nil) nil (range ~n))
       nil)))

(defmacro for
  "[Symbol × Coll] × a -> Vector a
  List comprehension."
  [bindings body]
  (let [binding (first bindings)
        coll (second bindings)]
    `(vec (map (fn [~binding] ~body) ~coll))))

(defn nthnext
  "Coll a × Int -> List a | Nil
  Drops first n elements as seq."
  [coll n]
  (loop [remaining (seq coll) i n]
    (if (or (empty? remaining) (<= i 0))
      remaining
      (recur (rest remaining) (dec i)))))

(defn nthrest
  "Coll a × Int -> Vector a
  Drops first n elements as vector."
  [coll n]
  (vec (nthnext coll n)))

(defn take-last
  "Int × Coll a -> Vector a
  Returns last n elements."
  [n coll]
  (let [v (vec coll)
        len (count v)]
    (if (<= len n)
      v
      (vec (drop (- len n) v)))))

(defn split-at
  "Int × Coll a -> [Vector a, Vector a]
  Splits collection at index n."
  [n coll]
  [(vec (take n coll)) (vec (drop n coll))])

(defn split-with
  "(a -> Bool) × Coll a -> [Vector a, Vector a]
  Splits where predicate first fails."
  [pred coll]
  [(vec (take-while pred coll)) (vec (drop-while pred coll))])

(defn iterate
  "(a -> a) × a -> Vector a
  Repeatedly applies f, collecting results."
  ([f x] (iterate f x 1000))
  ([f x n]
   (loop [result [x] current x i 1]
     (if (>= i n)
       result
       (let [next (f current)]
         (recur (conj result next) next (inc i)))))))

(defn repeatedly
  "Int × (-> a) -> Vector a
  Calls f n times, collects results."
  [n f]
  (vec (map (fn [_] (f)) (range n))))

(defn cycle
  "Coll a × Int -> Vector a
  Repeats collection n times."
  [coll n]
  (vec (reduce (fn [acc _] (concat acc coll)) [] (range n))))

(defn mapv
  "(a -> b) × Coll a -> Vector b
  Maps f, returns vector."
  [f coll]
  (vec (map f coll)))

(defn filterv
  "(a -> Bool) × Coll a -> Vector a
  Filters, returns vector."
  [pred coll]
  (vec (filter pred coll)))

(defn reduce-kv
  "(b × k × v -> b) × b × Map k v -> b
  Reduces over map entries with key and value."
  [f init m]
  (reduce (fn [acc kv] (f acc (first kv) (second kv))) init m))

(defn map-indexed
  "(Int × a -> b) × Coll a -> Vector b
  Maps with index."
  [f coll]
  (map-indexed-helper f (seq coll) 0))

(defn map-indexed-helper [f coll idx]
  (if (empty? coll)
    []
    (cons (f idx (first coll))
          (map-indexed-helper f (rest coll) (inc idx)))))

(defn keep-indexed
  "(Int × a -> b | Nil) × Coll a -> Vector b
  Maps with index, keeps non-nil."
  [f coll]
  (filter some? (map-indexed f coll)))

(defn find
  "Map k v × k -> [k, v] | Nil
  Returns key-value pair if key exists."
  [m k]
  (if (contains? m k)
    [k (get m k)]
    nil))

(defn not-empty
  "Coll a -> Coll a | Nil
  Returns nil if empty, otherwise coll."
  [coll]
  (if (empty? coll) nil coll))

(defn bounded-count
  "Int × Coll a -> Int
  Returns count capped at n."
  [n coll]
  (min n (count coll)))

(defn rand-nth
  "Coll a -> <random> a | Nil
  Random element from collection."
  [coll]
  (let [v (vec coll)
        n (count v)]
    (if (zero? n)
      nil
      (nth v (random/rand-int n)))))

;; --- Optic helpers ---
(defn by-all
  "Keyword × a -> Optic s s
  Traversal over all elements where key equals value."
  [k v] (*> DEEP (_when #(= (k %) v))))
(defn by-all-id
  "a -> Optic s s
  Traversal by :id."
  [v] (by-all :id v))
(defn by
  "Keyword × a -> Optic s s
  Focuses first element where key equals value."
  [k v] (_first (*> DEEP (_when #(= (k %) v)))))
(defn by-id
  "a -> Optic s s
  Focuses first element by :id."
  [v] (by :id v))

(defn shuffle
  "Coll a -> <random> Vector a
  Randomly shuffles collection."
  [coll]
  (let [v (vec coll)
        n (count v)]
    (loop [result v i (dec n)]
      (if (<= i 0)
        result
        (let [j (random/rand-int (inc i))
              vi (nth result i)
              vj (nth result j)]
          (recur (assoc (assoc result i vj) j vi) (dec i)))))))
