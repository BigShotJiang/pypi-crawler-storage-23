//! Destructuring support for let, fn, and loop bindings.
//!
//! Supports:
//! - Sequential destructuring: `[a b & rest :as all]`
//! - Associative destructuring: `{:keys [a b] :or {b 10} :as m}`
//! - Nested destructuring: `[[a b] {:keys [x]}]`

use crate::{Error, Result, Value};

/// Destructure a pattern against a value, returning a list of (name, value) bindings.
///
/// The pattern can be:
/// - A symbol: simple binding
/// - A vector: sequential destructuring
/// - A map: associative destructuring
pub fn destructure(pattern: &Value, value: &Value) -> Result<Vec<(String, Value)>> {
    let mut bindings = Vec::new();
    destructure_into(pattern, value, &mut bindings)?;
    Ok(bindings)
}

fn destructure_into(
    pattern: &Value,
    value: &Value,
    bindings: &mut Vec<(String, Value)>,
) -> Result<()> {
    match pattern.strip_meta() {
        Value::Symbol(sym) => {
            // Simple binding - just bind the whole value
            // Skip underscore bindings (convention for ignored values)
            if sym.name.as_ref() != "_" {
                bindings.push((sym.name.to_string(), value.clone()));
            }
            Ok(())
        }
        Value::Vector(pat_vec) => {
            // Sequential destructuring
            destructure_sequential(pat_vec, value, bindings)
        }
        Value::Map(pat_map) => {
            // Associative destructuring
            destructure_associative(pat_map, value, bindings)
        }
        other => Err(Error::eval(format!(
            "Invalid binding form: expected symbol, vector, or map, got {}",
            other.type_name()
        ))),
    }
}

/// Sequential destructuring: `[a b & rest :as all]`
fn destructure_sequential(
    pattern: &crate::collections::Vector<Value>,
    value: &Value,
    bindings: &mut Vec<(String, Value)>,
) -> Result<()> {
    // Convert value to a sequence of items
    let items = seq_to_vec(value)?;

    let mut i = 0;
    let mut pat_iter = pattern.iter().peekable();

    while let Some(pat_elem) = pat_iter.next() {
        let pat_elem = pat_elem.strip_meta();

        // Check for :as keyword
        if is_keyword(pat_elem, "as") {
            let name_elem = pat_iter
                .next()
                .ok_or_else(|| Error::eval("Expected symbol after :as"))?;
            let name = expect_symbol(name_elem)?;
            bindings.push((name, value.clone()));
            continue;
        }

        // Check for & rest
        if is_symbol(pat_elem, "&") {
            let rest_elem = pat_iter
                .next()
                .ok_or_else(|| Error::eval("Expected symbol after &"))?;

            // The rest might be a destructuring pattern itself
            let rest_value = if i < items.len() {
                Value::list_from_iter(items[i..].to_vec())
            } else {
                Value::Nil
            };

            destructure_into(rest_elem, &rest_value, bindings)?;

            // After rest, only :as is allowed
            if let Some(next) = pat_iter.next() {
                if is_keyword(next.strip_meta(), "as") {
                    let name_elem = pat_iter
                        .next()
                        .ok_or_else(|| Error::eval("Expected symbol after :as"))?;
                    let name = expect_symbol(name_elem)?;
                    bindings.push((name, value.clone()));
                } else {
                    return Err(Error::eval("Only :as allowed after rest parameter"));
                }
            }
            return Ok(());
        }

        // Regular positional binding (possibly nested)
        let item_value = items.get(i).cloned().unwrap_or(Value::Nil);
        destructure_into(pat_elem, &item_value, bindings)?;
        i += 1;
    }

    Ok(())
}

/// Associative destructuring: `{a :a :keys [b c] :or {b 10} :as m}`
fn destructure_associative(
    pattern: &crate::collections::HashMap<Value, Value>,
    value: &Value,
    bindings: &mut Vec<(String, Value)>,
) -> Result<()> {
    // Get the map to destructure (nil treated as empty map)
    let map = match value.strip_meta() {
        Value::Map(m) => m.clone(),
        Value::Nil => crate::collections::HashMap::new(),
        other => {
            return Err(Error::type_error("map", other.type_name()));
        }
    };

    // First pass: extract special keys (:keys, :strs, :syms, :or, :as)
    let mut or_defaults: crate::collections::HashMap<Value, Value> =
        crate::collections::HashMap::new();
    let mut as_binding: Option<String> = None;
    let mut keys_bindings: Vec<String> = Vec::new();
    let mut strs_bindings: Vec<String> = Vec::new();
    let mut syms_bindings: Vec<String> = Vec::new();
    let mut regular_bindings: Vec<(Value, Value)> = Vec::new(); // (binding-pattern, key)

    for (k, v) in pattern.iter() {
        let key = k.strip_meta();
        match key {
            Value::Keyword(kw) if kw.namespace.is_none() => {
                match kw.name.as_ref() {
                    "keys" => {
                        // :keys [a b c] - bind a from :a, b from :b, etc.
                        keys_bindings = extract_symbol_names(v)?;
                    }
                    "strs" => {
                        // :strs [a b c] - bind a from "a", b from "b", etc.
                        strs_bindings = extract_symbol_names(v)?;
                    }
                    "syms" => {
                        // :syms [a b c] - bind a from 'a, b from 'b, etc.
                        syms_bindings = extract_symbol_names(v)?;
                    }
                    "or" => {
                        // :or {a 10 b 20} - defaults
                        or_defaults = extract_defaults(v)?;
                    }
                    "as" => {
                        // :as m - bind the whole map
                        as_binding = Some(expect_symbol(v)?);
                    }
                    _ => {
                        // Regular keyword like :foo used as key
                        // This shouldn't happen in standard destructuring
                        // but we handle it as a key lookup
                    }
                }
            }
            _ => {
                // Regular binding: pattern is the binding form, v is the key
                // e.g., {a :a} means bind 'a' to (get map :a)
                regular_bindings.push((k.clone(), v.clone()));
            }
        }
    }

    // Process :keys bindings
    for name in keys_bindings {
        let key = Value::keyword(name.clone());
        let default = or_defaults.get(&key).cloned();
        let val = get_with_default(&map, &key, default);
        bindings.push((name, val));
    }

    // Process :strs bindings
    for name in strs_bindings {
        let key = Value::String(name.clone().into());
        let default = or_defaults.get(&key).cloned();
        let val = get_with_default(&map, &key, default);
        bindings.push((name, val));
    }

    // Process :syms bindings
    for name in syms_bindings {
        let key = Value::symbol(name.clone());
        let default = or_defaults.get(&key).cloned();
        let val = get_with_default(&map, &key, default);
        bindings.push((name, val));
    }

    // Process regular bindings: {binding-form key}
    for (binding_pattern, key) in regular_bindings {
        let default = or_defaults.get(&key).cloned();
        let val = get_with_default(&map, &key, default);
        destructure_into(&binding_pattern, &val, bindings)?;
    }

    // Process :as binding
    if let Some(name) = as_binding {
        bindings.push((name, value.clone()));
    }

    Ok(())
}

// --- Helper functions ---

fn seq_to_vec(value: &Value) -> Result<Vec<Value>> {
    match value.strip_meta() {
        Value::Nil => Ok(Vec::new()),
        Value::List(list) => Ok(list.iter().cloned().collect()),
        Value::Vector(vec) => Ok(vec.iter().cloned().collect()),
        Value::String(s) => {
            // Strings can be destructured as sequences of characters
            Ok(s.chars()
                .map(|c| Value::String(c.to_string().into()))
                .collect())
        }
        other => Err(Error::type_error("sequential", other.type_name())),
    }
}

fn is_symbol(value: &Value, name: &str) -> bool {
    matches!(value, Value::Symbol(sym) if sym.namespace.is_none() && sym.name.as_ref() == name)
}

fn is_keyword(value: &Value, name: &str) -> bool {
    matches!(value, Value::Keyword(kw) if kw.namespace.is_none() && kw.name.as_ref() == name)
}

fn expect_symbol(value: &Value) -> Result<String> {
    match value.strip_meta() {
        Value::Symbol(sym) => Ok(sym.name.to_string()),
        other => Err(Error::type_error("symbol", other.type_name())),
    }
}

fn extract_symbol_names(value: &Value) -> Result<Vec<String>> {
    match value.strip_meta() {
        Value::Vector(vec) => {
            let mut names = Vec::new();
            for item in vec.iter() {
                names.push(expect_symbol(item)?);
            }
            Ok(names)
        }
        other => Err(Error::type_error("vector", other.type_name())),
    }
}

fn extract_defaults(value: &Value) -> Result<crate::collections::HashMap<Value, Value>> {
    match value.strip_meta() {
        Value::Map(map) => {
            // The keys in :or are symbols, but they map to keyword/string/symbol keys
            // based on how they're used. We need to handle this carefully.
            // In Clojure, :or {a 10} means if :a is missing, use 10.
            // The key 'a' (symbol) in :or corresponds to keyword :a in :keys.
            // We'll store both the symbol and keyword versions.
            let mut defaults = crate::collections::HashMap::new();
            for (k, v) in map.iter() {
                // Store as keyword (for :keys)
                if let Value::Symbol(sym) = k.strip_meta() {
                    defaults.insert(Value::keyword(sym.name.as_ref()), v.clone());
                    defaults.insert(Value::String(sym.name.to_string().into()), v.clone());
                    defaults.insert(Value::symbol(sym.name.as_ref()), v.clone());
                }
                // Also store the original key
                defaults.insert(k.clone(), v.clone());
            }
            Ok(defaults)
        }
        other => Err(Error::type_error("map", other.type_name())),
    }
}

fn get_with_default(
    map: &crate::collections::HashMap<Value, Value>,
    key: &Value,
    default: Option<Value>,
) -> Value {
    map.get(key)
        .cloned()
        .unwrap_or_else(|| default.unwrap_or(Value::Nil))
}

#[cfg(test)]
mod tests {
    use super::*;

    fn sym(name: &str) -> Value {
        Value::symbol(name)
    }

    fn kw(name: &str) -> Value {
        Value::keyword(name)
    }

    fn vec_of(items: Vec<Value>) -> Value {
        Value::Vector(items.into_iter().collect())
    }

    fn map_of(pairs: Vec<(Value, Value)>) -> Value {
        Value::Map(pairs.into_iter().collect())
    }

    #[test]
    fn test_simple_binding() {
        let bindings = destructure(&sym("x"), &Value::Int(42)).unwrap();
        assert_eq!(bindings.len(), 1);
        assert_eq!(bindings[0].0, "x");
        assert_eq!(bindings[0].1, Value::Int(42));
    }

    #[test]
    fn test_underscore_ignored() {
        let bindings = destructure(&sym("_"), &Value::Int(42)).unwrap();
        assert_eq!(bindings.len(), 0);
    }

    #[test]
    fn test_sequential_basic() {
        let pattern = vec_of(vec![sym("a"), sym("b")]);
        let value = vec_of(vec![Value::Int(1), Value::Int(2)]);
        let bindings = destructure(&pattern, &value).unwrap();
        assert_eq!(bindings.len(), 2);
        assert_eq!(bindings[0], ("a".to_string(), Value::Int(1)));
        assert_eq!(bindings[1], ("b".to_string(), Value::Int(2)));
    }

    #[test]
    fn test_sequential_rest() {
        let pattern = vec_of(vec![sym("a"), sym("&"), sym("rest")]);
        let value = vec_of(vec![Value::Int(1), Value::Int(2), Value::Int(3)]);
        let bindings = destructure(&pattern, &value).unwrap();
        assert_eq!(bindings.len(), 2);
        assert_eq!(bindings[0], ("a".to_string(), Value::Int(1)));
        // rest should be a list of [2, 3]
        if let Value::List(list) = &bindings[1].1 {
            let items: Vec<_> = list.iter().cloned().collect();
            assert_eq!(items.len(), 2);
        } else {
            panic!("Expected list for rest");
        }
    }

    #[test]
    fn test_sequential_as() {
        let pattern = vec_of(vec![sym("a"), kw("as"), sym("all")]);
        let value = vec_of(vec![Value::Int(1), Value::Int(2)]);
        let bindings = destructure(&pattern, &value).unwrap();
        assert_eq!(bindings.len(), 2);
        assert_eq!(bindings[0], ("a".to_string(), Value::Int(1)));
        assert_eq!(bindings[1].0, "all");
        // 'all' should be the original vector
        assert_eq!(bindings[1].1, value);
    }

    #[test]
    fn test_map_keys() {
        let pattern = map_of(vec![(kw("keys"), vec_of(vec![sym("a"), sym("b")]))]);
        let value = map_of(vec![(kw("a"), Value::Int(1)), (kw("b"), Value::Int(2))]);
        let bindings = destructure(&pattern, &value).unwrap();
        assert_eq!(bindings.len(), 2);
        // Order may vary, so check by name
        let a = bindings.iter().find(|(n, _)| n == "a").unwrap();
        let b = bindings.iter().find(|(n, _)| n == "b").unwrap();
        assert_eq!(a.1, Value::Int(1));
        assert_eq!(b.1, Value::Int(2));
    }

    #[test]
    fn test_map_or_defaults() {
        let pattern = map_of(vec![
            (kw("keys"), vec_of(vec![sym("a"), sym("b")])),
            (kw("or"), map_of(vec![(sym("b"), Value::Int(99))])),
        ]);
        let value = map_of(vec![(kw("a"), Value::Int(1))]);
        let bindings = destructure(&pattern, &value).unwrap();
        let a = bindings.iter().find(|(n, _)| n == "a").unwrap();
        let b = bindings.iter().find(|(n, _)| n == "b").unwrap();
        assert_eq!(a.1, Value::Int(1));
        assert_eq!(b.1, Value::Int(99)); // default
    }

    #[test]
    fn test_nested() {
        let pattern = vec_of(vec![vec_of(vec![sym("a"), sym("b")]), sym("c")]);
        let value = vec_of(vec![
            vec_of(vec![Value::Int(1), Value::Int(2)]),
            Value::Int(3),
        ]);
        let bindings = destructure(&pattern, &value).unwrap();
        assert_eq!(bindings.len(), 3);
        assert_eq!(bindings[0], ("a".to_string(), Value::Int(1)));
        assert_eq!(bindings[1], ("b".to_string(), Value::Int(2)));
        assert_eq!(bindings[2], ("c".to_string(), Value::Int(3)));
    }
}
