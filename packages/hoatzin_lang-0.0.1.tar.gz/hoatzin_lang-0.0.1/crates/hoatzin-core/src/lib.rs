//! Hoatzin Core - Language primitives for a micro-Clojure
//!
//! ## Modules
//! - [`value`] - Clojure value types (nil, bool, int, list, vector, map, etc.)
//! - [`list`] - Persistent cons-cell list with tail sharing
//! - [`reader`] - Hand-written recursive descent s-expression parser
//! - [`span`] - Source location tracking for ariadne error reporting
//! - [`printer`] - Value pretty-printing
//! - [`eval`] - Native function evaluation utilities
//! - [`error`] - Error types with rich diagnostics
//! - [`vm`] - Bytecode VM execution engine

pub mod builtin_effects;
pub mod collections;
pub mod destructure;
pub mod error;
pub mod eval;
pub mod formatter;
pub mod list;
pub mod optic;
pub mod printer;
pub mod reader;
pub mod span;
pub mod value;
pub mod vm;
pub mod xpath;

pub use error::{Error, ErrorKind, Hint, RelatedSpan, Result, SpanRole, format_call_stack};
pub use eval::{EvalRequest, NativeResult, apply_then, done};
pub use lasso::Spur;
pub use list::List;
pub use optic::Optic;
pub use reader::Reader;
pub use value::{CallFrame, CallFrameKind, EffectId, Keyword, OpSignature, Symbol, Value};
