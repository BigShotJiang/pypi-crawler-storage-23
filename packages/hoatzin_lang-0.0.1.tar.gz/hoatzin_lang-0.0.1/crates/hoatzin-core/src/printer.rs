//! Pretty-printing for Hoatzin values
//!
//! Implements Display for Value to produce readable Clojure syntax.

use crate::Value;
use std::fmt::{self, Display, Formatter};

impl Display for Value {
    fn fmt(&self, f: &mut Formatter<'_>) -> fmt::Result {
        match self {
            Value::Nil => write!(f, "nil"),
            Value::Bool(true) => write!(f, "true"),
            Value::Bool(false) => write!(f, "false"),
            Value::Int(i) => write!(f, "{}", i),
            Value::Ratio { numer, denom } => write!(f, "{}/{}", numer, denom),
            Value::Float(x) => write!(f, "{}", x),
            Value::String(s) => write!(f, "\"{}\"", escape_string(s)),
            Value::Symbol(sym) => {
                if let Some(ns) = &sym.namespace {
                    write!(f, "{}/{}", ns, sym.name)
                } else {
                    write!(f, "{}", sym.name)
                }
            }
            Value::Keyword(kw) => {
                if let Some(ns) = &kw.namespace {
                    write!(f, ":{}/{}", ns, kw.name)
                } else {
                    write!(f, ":{}", kw.name)
                }
            }
            Value::List(list) => {
                write!(f, "(")?;
                let mut first = true;
                for item in list.iter() {
                    if !first {
                        write!(f, " ")?;
                    }
                    first = false;
                    write!(f, "{}", item)?;
                }
                write!(f, ")")
            }
            Value::Vector(vec) => {
                write!(f, "[")?;
                for (idx, item) in vec.iter().enumerate() {
                    if idx > 0 {
                        write!(f, " ")?;
                    }
                    write!(f, "{}", item)?;
                }
                write!(f, "]")
            }
            Value::Map(map) => {
                write!(f, "{{")?;
                let mut first = true;
                for (k, v) in map.iter() {
                    if !first {
                        write!(f, " ")?;
                    }
                    first = false;
                    write!(f, "{} {}", k, v)?;
                }
                write!(f, "}}")
            }
            Value::Set(set) => {
                write!(f, "#{{")?;
                let mut first = true;
                for item in set.iter() {
                    if !first {
                        write!(f, " ")?;
                    }
                    first = false;
                    write!(f, "{}", item)?;
                }
                write!(f, "}}")
            }
            Value::NativeFn { name, .. } => write!(f, "#<fn {}>", name),
            Value::Meta { value, .. } => write!(f, "{}", value),
            Value::Optic(o) => write!(f, "#<optic {}>", o),
            Value::Regex(r) => write!(f, "#\"{}\"", r.as_str()),
            Value::Effect { name, ops, .. } => {
                if let Some(name) = name {
                    write!(f, "#<effect {} ({} ops)>", name, ops.len())
                } else {
                    write!(f, "#<effect ({} ops)>", ops.len())
                }
            }
            Value::Atom(a) => write!(f, "#<atom {}>", **a.load()),
        }
    }
}

/// Print value for REPL display (like Clojure's `pr`)
pub fn pr_str(value: &Value) -> String {
    format!("{}", value)
}

fn escape_string(input: &str) -> String {
    let mut out = String::with_capacity(input.len());
    for ch in input.chars() {
        match ch {
            '\\' => out.push_str("\\\\"),
            '"' => out.push_str("\\\""),
            '\n' => out.push_str("\\n"),
            '\t' => out.push_str("\\t"),
            '\r' => out.push_str("\\r"),
            _ => out.push(ch),
        }
    }
    out
}
