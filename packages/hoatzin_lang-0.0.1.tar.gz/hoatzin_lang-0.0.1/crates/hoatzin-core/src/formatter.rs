//! S-expression formatter with fractured formatting modes
//!
//! Inspired by FracturedJson - instead of binary "inline vs expanded",
//! we cascade through formatting modes based on complexity and line width.

/// Formatting configuration
#[derive(Debug, Clone)]
pub struct FormatConfig {
    /// Target maximum line length
    pub max_line_length: usize,
    /// Spaces per indentation level
    pub indent_size: usize,
    /// Maximum complexity to inline a form (0 = atoms only, 1 = flat lists, 2 = one level nesting)
    pub max_inline_complexity: usize,
    /// Maximum complexity for compact multiline mode
    pub max_compact_complexity: usize,
    /// Minimum items to use compact mode
    pub min_compact_items: usize,
    /// Align values in maps
    pub align_map_values: bool,
    /// Align bindings in let forms
    pub align_let_bindings: bool,
}

impl Default for FormatConfig {
    fn default() -> Self {
        Self {
            max_line_length: 100,
            indent_size: 2,
            max_inline_complexity: 4, // Allow deeper nesting for short forms
            max_compact_complexity: 1,
            min_compact_items: 4,
            align_map_values: true,
            align_let_bindings: true,
        }
    }
}

/// A token in the source
#[derive(Debug, Clone, PartialEq)]
pub enum Token {
    /// Opening delimiter: ( [ { #{
    Open(Delimiter),
    /// Closing delimiter: ) ] }
    Close(Delimiter),
    /// Atom: symbol, keyword, number, string, etc.
    Atom(String),
    /// Line comment starting with ;
    Comment(String),
    /// Whitespace (preserved for comment handling)
    Whitespace(String),
    /// Reader macro prefix: ' ` ~ ~@ @ #' #_ #x
    ReaderMacro(String),
}

/// Type of delimiter
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Delimiter {
    Paren,   // ()
    Bracket, // []
    Brace,   // {}
    Set,     // #{}
}

impl Delimiter {
    fn open_str(self) -> &'static str {
        match self {
            Delimiter::Paren => "(",
            Delimiter::Bracket => "[",
            Delimiter::Brace => "{",
            Delimiter::Set => "#{",
        }
    }

    fn close_str(self) -> &'static str {
        match self {
            Delimiter::Paren => ")",
            Delimiter::Bracket => "]",
            Delimiter::Brace | Delimiter::Set => "}",
        }
    }
}

/// Tokenize source code preserving comments
pub fn tokenize(source: &str) -> Vec<Token> {
    let mut tokens = Vec::new();
    let mut chars = source.chars().peekable();

    while let Some(&ch) = chars.peek() {
        match ch {
            // Whitespace
            ' ' | '\t' | '\n' | '\r' | ',' => {
                let mut ws = String::new();
                while let Some(&c) = chars.peek() {
                    if c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == ',' {
                        ws.push(c);
                        chars.next();
                    } else {
                        break;
                    }
                }
                tokens.push(Token::Whitespace(ws));
            }

            // Comments
            ';' => {
                let mut comment = String::new();
                while let Some(&c) = chars.peek() {
                    if c == '\n' {
                        break;
                    }
                    comment.push(c);
                    chars.next();
                }
                tokens.push(Token::Comment(comment));
            }

            // Delimiters
            '(' => {
                chars.next();
                tokens.push(Token::Open(Delimiter::Paren));
            }
            ')' => {
                chars.next();
                tokens.push(Token::Close(Delimiter::Paren));
            }
            '[' => {
                chars.next();
                tokens.push(Token::Open(Delimiter::Bracket));
            }
            ']' => {
                chars.next();
                tokens.push(Token::Close(Delimiter::Bracket));
            }
            '{' => {
                chars.next();
                tokens.push(Token::Open(Delimiter::Brace));
            }
            '}' => {
                chars.next();
                tokens.push(Token::Close(Delimiter::Brace));
            }

            // Reader macros and special
            '#' => {
                chars.next();
                match chars.peek() {
                    Some('{') => {
                        chars.next();
                        tokens.push(Token::Open(Delimiter::Set));
                    }
                    Some('_') => {
                        chars.next();
                        tokens.push(Token::ReaderMacro("#_".into()));
                    }
                    Some('\'') => {
                        chars.next();
                        tokens.push(Token::ReaderMacro("#'".into()));
                    }
                    Some('"') => {
                        // Regex literal #"..."
                        let mut s = String::from("#\"");
                        chars.next(); // consume "
                        let mut escape = false;
                        while let Some(&c) = chars.peek() {
                            s.push(c);
                            chars.next();
                            if escape {
                                escape = false;
                            } else if c == '\\' {
                                escape = true;
                            } else if c == '"' {
                                break;
                            }
                        }
                        tokens.push(Token::Atom(s));
                    }
                    Some('x') => {
                        // XPath optic #x"..."
                        chars.next();
                        if chars.peek() == Some(&'"') {
                            let mut s = String::from("#x\"");
                            chars.next(); // consume "
                            let mut escape = false;
                            while let Some(&c) = chars.peek() {
                                s.push(c);
                                chars.next();
                                if escape {
                                    escape = false;
                                } else if c == '\\' {
                                    escape = true;
                                } else if c == '"' {
                                    break;
                                }
                            }
                            tokens.push(Token::Atom(s));
                        } else {
                            tokens.push(Token::ReaderMacro("#x".into()));
                        }
                    }
                    _ => {
                        tokens.push(Token::ReaderMacro("#".into()));
                    }
                }
            }

            '\'' => {
                chars.next();
                tokens.push(Token::ReaderMacro("'".into()));
            }
            '`' => {
                chars.next();
                tokens.push(Token::ReaderMacro("`".into()));
            }
            '~' => {
                chars.next();
                if chars.peek() == Some(&'@') {
                    chars.next();
                    tokens.push(Token::ReaderMacro("~@".into()));
                } else {
                    tokens.push(Token::ReaderMacro("~".into()));
                }
            }
            '@' => {
                chars.next();
                tokens.push(Token::ReaderMacro("@".into()));
            }
            '^' => {
                chars.next();
                tokens.push(Token::ReaderMacro("^".into()));
            }

            // String
            '"' => {
                let mut s = String::new();
                s.push(ch);
                chars.next();
                let mut escape = false;
                while let Some(&c) = chars.peek() {
                    s.push(c);
                    chars.next();
                    if escape {
                        escape = false;
                    } else if c == '\\' {
                        escape = true;
                    } else if c == '"' {
                        break;
                    }
                }
                tokens.push(Token::Atom(s));
            }

            // Everything else is an atom
            _ => {
                let mut atom = String::new();
                while let Some(&c) = chars.peek() {
                    if is_delimiter(c) || c.is_whitespace() || c == ',' || c == ';' {
                        break;
                    }
                    atom.push(c);
                    chars.next();
                }
                if !atom.is_empty() {
                    tokens.push(Token::Atom(atom));
                }
            }
        }
    }

    tokens
}

fn is_delimiter(c: char) -> bool {
    matches!(c, '(' | ')' | '[' | ']' | '{' | '}')
}

/// A node in the formatting tree
#[derive(Debug, Clone)]
pub enum FmtNode {
    /// An atom (symbol, keyword, number, string, etc.)
    Atom(String),
    /// A comment
    Comment(String),
    /// A reader macro applied to the next node
    ReaderMacro { prefix: String, inner: Box<FmtNode> },
    /// A collection (list, vector, map, set)
    Collection {
        delimiter: Delimiter,
        children: Vec<FmtNode>,
        /// Trailing comment on the closing delimiter line
        trailing_comment: Option<String>,
    },
}

impl FmtNode {
    /// Compute complexity: 0 for atoms, 1 for flat collections, +1 for each nesting level
    pub fn complexity(&self) -> usize {
        match self {
            FmtNode::Atom(_) | FmtNode::Comment(_) => 0,
            FmtNode::ReaderMacro { inner, .. } => inner.complexity(),
            FmtNode::Collection { children, .. } => {
                if children.is_empty() {
                    0
                } else {
                    let max_child = children.iter().map(|c| c.complexity()).max().unwrap_or(0);
                    max_child + 1
                }
            }
        }
    }

    /// Compute minimum inline length (without considering line breaks)
    pub fn inline_len(&self) -> usize {
        match self {
            FmtNode::Atom(s) => s.len(),
            FmtNode::Comment(s) => s.len(),
            FmtNode::ReaderMacro { prefix, inner } => prefix.len() + inner.inline_len(),
            FmtNode::Collection {
                delimiter,
                children,
                ..
            } => {
                let open_len = delimiter.open_str().len();
                let close_len = delimiter.close_str().len();
                let content_len: usize = children
                    .iter()
                    .filter(|c| !matches!(c, FmtNode::Comment(_)))
                    .map(|c| c.inline_len())
                    .sum();
                let spaces = children
                    .iter()
                    .filter(|c| !matches!(c, FmtNode::Comment(_)))
                    .count()
                    .saturating_sub(1);
                open_len + content_len + spaces + close_len
            }
        }
    }

    /// Check if this is a "special form" that has custom formatting rules
    fn special_form_name(&self) -> Option<&str> {
        if let FmtNode::Collection {
            delimiter: Delimiter::Paren,
            children,
            ..
        } = self
        {
            if let Some(FmtNode::Atom(name)) = children.first() {
                match name.as_str() {
                    "def" | "defn" | "defn-" | "defmacro" | "fn" | "let" | "loop" | "if"
                    | "when" | "when-not" | "when-let" | "if-let" | "cond" | "case" | "condp"
                    | "match" | "->" | "->>" | "as->" | "some->" | "some->>" | "+>>"
                    | "with-handler" | "do" | "try" | "catch" | "finally" | "ns" | "require"
                    | "import" | "binding" | "doseq" | "for" | "dotimes" => {
                        return Some(name.as_str());
                    }
                    _ => {}
                }
            }
        }
        None
    }
}

/// Parse tokens into formatting tree
pub fn parse_fmt(tokens: &[Token]) -> Vec<FmtNode> {
    let mut nodes = Vec::new();
    let mut idx = 0;

    while idx < tokens.len() {
        if let Some((node, new_idx)) = parse_one(tokens, idx) {
            nodes.push(node);
            idx = new_idx;
        } else {
            idx += 1;
        }
    }

    nodes
}

fn parse_one(tokens: &[Token], mut idx: usize) -> Option<(FmtNode, usize)> {
    // Skip whitespace
    while idx < tokens.len() && matches!(tokens[idx], Token::Whitespace(_)) {
        idx += 1;
    }

    if idx >= tokens.len() {
        return None;
    }

    match &tokens[idx] {
        Token::Atom(s) => Some((FmtNode::Atom(s.clone()), idx + 1)),

        Token::Comment(s) => Some((FmtNode::Comment(s.clone()), idx + 1)),

        Token::ReaderMacro(prefix) => {
            // Reader macro applies to the next form
            let (inner, new_idx) = parse_one(tokens, idx + 1)?;
            Some((
                FmtNode::ReaderMacro {
                    prefix: prefix.clone(),
                    inner: Box::new(inner),
                },
                new_idx,
            ))
        }

        Token::Open(delim) => {
            let mut children = Vec::new();
            let mut i = idx + 1;

            while i < tokens.len() {
                match &tokens[i] {
                    Token::Close(close_delim)
                        if close_delim == delim
                            || matches!(delim, Delimiter::Set)
                                && matches!(close_delim, Delimiter::Brace) =>
                    {
                        // Look for trailing comment
                        let mut trailing = None;
                        let mut next_i = i + 1;
                        while next_i < tokens.len() {
                            match &tokens[next_i] {
                                Token::Whitespace(ws) if !ws.contains('\n') => {
                                    next_i += 1;
                                }
                                Token::Comment(c) => {
                                    trailing = Some(c.clone());
                                    next_i += 1;
                                    break;
                                }
                                _ => break,
                            }
                        }
                        let end_idx = if trailing.is_some() { next_i } else { i + 1 };
                        return Some((
                            FmtNode::Collection {
                                delimiter: *delim,
                                children,
                                trailing_comment: trailing,
                            },
                            end_idx,
                        ));
                    }
                    Token::Close(_) => {
                        // Mismatched delimiter, bail
                        return Some((
                            FmtNode::Collection {
                                delimiter: *delim,
                                children,
                                trailing_comment: None,
                            },
                            i,
                        ));
                    }
                    Token::Whitespace(_) => {
                        i += 1;
                    }
                    _ => {
                        if let Some((child, new_i)) = parse_one(tokens, i) {
                            children.push(child);
                            i = new_i;
                        } else {
                            i += 1;
                        }
                    }
                }
            }

            // Unclosed delimiter
            Some((
                FmtNode::Collection {
                    delimiter: *delim,
                    children,
                    trailing_comment: None,
                },
                i,
            ))
        }

        Token::Close(_) | Token::Whitespace(_) => None,
    }
}

/// Format source code
pub fn format(source: &str, config: &FormatConfig) -> String {
    let tokens = tokenize(source);
    let nodes = parse_fmt(&tokens);

    let mut output = String::new();
    let mut prev_was_comment = false;

    for (i, node) in nodes.iter().enumerate() {
        if i > 0 {
            output.push('\n');
            // Clojure convention: one blank line between top-level forms
            // Exception: comments attach to the following form
            // - No blank line before a comment (comment starts a new "group")
            // - No blank line after a comment (comment attaches to next form)
            let is_comment = matches!(node, FmtNode::Comment(_));
            if !is_comment && !prev_was_comment {
                output.push('\n');
            }
        }
        format_node(&mut output, node, 0, config);
        prev_was_comment = matches!(node, FmtNode::Comment(_));
    }

    // Ensure trailing newline
    if !output.is_empty() && !output.ends_with('\n') {
        output.push('\n');
    }

    output
}

fn format_node(out: &mut String, node: &FmtNode, indent: usize, config: &FormatConfig) {
    match node {
        FmtNode::Atom(s) => {
            out.push_str(s);
        }

        FmtNode::Comment(s) => {
            out.push_str(s);
        }

        FmtNode::ReaderMacro { prefix, inner } => {
            out.push_str(prefix);
            format_node(out, inner, indent, config);
        }

        FmtNode::Collection {
            delimiter,
            children,
            trailing_comment,
        } => {
            // Check for special form formatting
            if let Some(form_name) = node.special_form_name() {
                format_special_form(
                    out,
                    form_name,
                    delimiter,
                    children,
                    trailing_comment,
                    indent,
                    config,
                );
                return;
            }

            let complexity = node.complexity();
            let inline_len = node.inline_len();
            let available = config.max_line_length.saturating_sub(indent);

            // Check for table mode FIRST (vector/list of uniform maps)
            // Table mode takes precedence because it provides better readability
            // for structured data even when it could fit on one line
            if matches!(delimiter, Delimiter::Bracket | Delimiter::Paren) {
                if let Some(formatted) = try_format_table(children, indent, config) {
                    out.push_str(delimiter.open_str());
                    out.push_str(&formatted);
                    out.push_str(delimiter.close_str());
                    if let Some(tc) = trailing_comment {
                        out.push(' ');
                        out.push_str(tc);
                    }
                    return;
                }
            }

            // Check for map with alignable values
            if *delimiter == Delimiter::Brace && config.align_map_values {
                if let Some(formatted) = try_format_aligned_map(children, indent, config) {
                    out.push_str(delimiter.open_str());
                    out.push_str(&formatted);
                    out.push_str(delimiter.close_str());
                    if let Some(tc) = trailing_comment {
                        out.push(' ');
                        out.push_str(tc);
                    }
                    return;
                }
            }

            // Try inline if simple enough
            if complexity <= config.max_inline_complexity
                && inline_len <= available
                && !children.iter().any(|c| matches!(c, FmtNode::Comment(_)))
            {
                format_inline(out, delimiter, children, trailing_comment);
                return;
            }

            // Check for compact multiline (uniform simple items)
            if complexity <= config.max_compact_complexity
                && children.len() >= config.min_compact_items
                && !children.iter().any(|c| matches!(c, FmtNode::Comment(_)))
                && children.iter().all(|c| c.complexity() <= 1)
            {
                if let Some(formatted) = try_format_compact(children, indent, config) {
                    out.push_str(delimiter.open_str());
                    out.push_str(&formatted);
                    out.push_str(delimiter.close_str());
                    if let Some(tc) = trailing_comment {
                        out.push(' ');
                        out.push_str(tc);
                    }
                    return;
                }
            }

            // Fall back to expanded
            format_expanded(out, delimiter, children, trailing_comment, indent, config);
        }
    }
}

fn format_inline(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
) {
    out.push_str(delimiter.open_str());
    let mut first = true;
    for child in children {
        if matches!(child, FmtNode::Comment(_)) {
            continue;
        }
        if !first {
            out.push(' ');
        }
        // Inline formatting - no indentation tracking needed
        format_node_inline(out, child);
        first = false;
    }
    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_node_inline(out: &mut String, node: &FmtNode) {
    match node {
        FmtNode::Atom(s) => out.push_str(s),
        FmtNode::Comment(s) => out.push_str(s),
        FmtNode::ReaderMacro { prefix, inner } => {
            out.push_str(prefix);
            format_node_inline(out, inner);
        }
        FmtNode::Collection {
            delimiter,
            children,
            ..
        } => {
            out.push_str(delimiter.open_str());
            let mut first = true;
            for child in children {
                if matches!(child, FmtNode::Comment(_)) {
                    continue;
                }
                if !first {
                    out.push(' ');
                }
                format_node_inline(out, child);
                first = false;
            }
            out.push_str(delimiter.close_str());
        }
    }
}

fn format_expanded(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let child_indent = indent + config.indent_size;
    let mut first = true;

    for child in children {
        if first {
            first = false;
        } else {
            out.push('\n');
            write_indent(out, child_indent);
        }
        format_node(out, child, child_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

/// Try to format as compact multiline (multiple items per row)
fn try_format_compact(
    children: &[FmtNode],
    base_indent: usize,
    config: &FormatConfig,
) -> Option<String> {
    let child_indent = base_indent + 1; // After opening delimiter
    let available = config.max_line_length.saturating_sub(child_indent);

    let mut result = String::new();
    let mut line_items: Vec<String> = Vec::new();
    let mut line_len = 0;

    for child in children {
        let mut item = String::new();
        format_node_inline(&mut item, child);
        let item_len = item.len();

        // Check if adding this item would exceed line length
        let needed = if line_items.is_empty() {
            item_len
        } else {
            item_len + 1 // +1 for space
        };

        if !line_items.is_empty() && line_len + needed > available {
            // Flush current line
            result.push_str(&line_items.join(" "));
            result.push('\n');
            write_indent_to(&mut result, child_indent);
            line_items.clear();
            line_len = 0;
        }

        if line_items.is_empty() {
            line_len = item_len;
        } else {
            line_len += item_len + 1;
        }
        line_items.push(item);
    }

    // Flush remaining
    if !line_items.is_empty() {
        result.push_str(&line_items.join(" "));
    }

    Some(result)
}

/// Try to format a map with aligned values
fn try_format_aligned_map(
    children: &[FmtNode],
    base_indent: usize,
    config: &FormatConfig,
) -> Option<String> {
    // Must have even number of children (key-value pairs)
    if children.len() % 2 != 0 || children.is_empty() {
        return None;
    }

    let pairs: Vec<_> = children.chunks(2).collect();

    // Only use aligned format if:
    // - Map has 3+ pairs, OR
    // - Map wouldn't fit inline
    let inline_len: usize = children.iter().map(|c| c.inline_len()).sum::<usize>()
        + children.len() // spaces
        + 2; // braces
    let available = config.max_line_length.saturating_sub(base_indent);

    if pairs.len() < 3 && inline_len <= available {
        return None; // Let inline formatting handle small maps
    }

    // Check all keys are simple atoms (keywords typically)
    let max_key_len = pairs
        .iter()
        .filter_map(|pair| {
            if let FmtNode::Atom(k) = &pair[0] {
                Some(k.len())
            } else {
                None
            }
        })
        .max()?;

    // Don't align if keys are too different in length
    if max_key_len > 20 {
        return None;
    }

    let child_indent = base_indent + 1;
    let mut result = String::new();
    let mut first = true;

    for pair in pairs {
        if !first {
            result.push('\n');
            write_indent_to(&mut result, child_indent);
        }
        first = false;

        let key = &pair[0];
        let val = &pair[1];

        let mut key_str = String::new();
        format_node_inline(&mut key_str, key);

        // Pad key to alignment
        result.push_str(&key_str);
        for _ in key_str.len()..max_key_len {
            result.push(' ');
        }
        result.push(' ');

        format_node(&mut result, val, child_indent + max_key_len + 1, config);
    }

    Some(result)
}

/// Try to format as a table (vector/list of uniform maps)
/// This is the FracturedJson-inspired "table mode"
fn try_format_table(
    children: &[FmtNode],
    base_indent: usize,
    config: &FormatConfig,
) -> Option<String> {
    // Need at least 2 items to be a table
    if children.len() < 2 {
        return None;
    }

    // All children must be maps
    let maps: Vec<_> = children
        .iter()
        .filter_map(|c| {
            if let FmtNode::Collection {
                delimiter: Delimiter::Brace,
                children: map_children,
                ..
            } = c
            {
                // Must have even number of children (key-value pairs)
                if map_children.len() % 2 == 0 {
                    return Some(map_children);
                }
            }
            None
        })
        .collect();

    if maps.len() != children.len() {
        return None; // Not all children are maps
    }

    // Collect all keys from all maps
    let mut all_keys: Vec<String> = Vec::new();
    for map_children in &maps {
        for pair in map_children.chunks(2) {
            let mut key_str = String::new();
            format_node_inline(&mut key_str, &pair[0]);
            if !all_keys.contains(&key_str) {
                all_keys.push(key_str);
            }
        }
    }

    // Check that each row would fit on one line
    let child_indent = base_indent + 1;
    let available = config.max_line_length.saturating_sub(child_indent);

    for map_children in &maps {
        let row_len: usize = map_children.iter().map(|c| c.inline_len()).sum::<usize>()
            + map_children.len() // spaces
            + 2; // braces
        if row_len > available {
            return None; // Row too long for table mode
        }
    }

    // Format as table - each map on its own line
    let mut result = String::new();

    for (i, child) in children.iter().enumerate() {
        if i > 0 {
            result.push('\n');
            write_indent_to(&mut result, child_indent);
        }
        format_node_inline(&mut result, child);
    }

    Some(result)
}

fn format_special_form(
    out: &mut String,
    form_name: &str,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    match form_name {
        // Threading macros: each step on its own line
        "->" | "->>" | "as->" | "some->" | "some->>" | "+>>" => {
            format_threading(out, delimiter, children, trailing_comment, indent, config);
        }

        // Simple def - keep inline if short
        "def" | "defonce" => {
            format_def(out, delimiter, children, trailing_comment, indent, config);
        }

        // Function definitions
        "defn" | "defn-" | "defmacro" => {
            format_defn(out, delimiter, children, trailing_comment, indent, config);
        }

        // Anonymous function
        "fn" => {
            format_fn(out, delimiter, children, trailing_comment, indent, config);
        }

        // Let/loop bindings
        "let" | "loop" | "binding" | "when-let" | "if-let" => {
            format_let(out, delimiter, children, trailing_comment, indent, config);
        }

        // Conditionals
        "if" | "when" | "when-not" => {
            format_if(out, delimiter, children, trailing_comment, indent, config);
        }

        "cond" => {
            format_cond(out, delimiter, children, trailing_comment, indent, config);
        }

        // Effect handlers
        "with-handler" => {
            format_with_handler(out, delimiter, children, trailing_comment, indent, config);
        }

        // Default: standard expanded
        _ => {
            format_expanded(out, delimiter, children, trailing_comment, indent, config);
        }
    }
}

fn format_threading(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let child_indent = indent + config.indent_size;

    for (i, child) in children.iter().enumerate() {
        if i == 0 {
            // Macro name
            format_node(out, child, indent, config);
        } else if i == 1 {
            // Initial value - on same line
            out.push(' ');
            format_node(out, child, indent, config);
        } else {
            // Each step on its own line
            out.push('\n');
            write_indent(out, child_indent);
            format_node(out, child, child_indent, config);
        }
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_def(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    // Try inline for simple def
    let inline_len: usize = children.iter().map(|c| c.inline_len()).sum::<usize>() + children.len();
    let max_complexity = children.iter().map(|c| c.complexity()).max().unwrap_or(0);

    if inline_len + indent <= config.max_line_length && max_complexity <= 2 {
        format_inline(out, delimiter, children, trailing_comment);
        return;
    }

    // Expanded: (def name\n  value)
    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // def name
    for (i, child) in children.iter().take(2).enumerate() {
        if i > 0 {
            out.push(' ');
        }
        format_node(out, child, indent, config);
    }

    // Value(s) on next line
    for child in children.iter().skip(2) {
        out.push('\n');
        write_indent(out, body_indent);
        format_node(out, child, body_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_defn(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;
    let mut idx = 0;

    // defn name
    for child in children.iter().take(2) {
        if idx > 0 {
            out.push(' ');
        }
        format_node(out, child, indent, config);
        idx += 1;
    }

    // Check for docstring (string literal)
    if children.len() > 2 {
        if let FmtNode::Atom(s) = &children[2] {
            if s.starts_with('"') {
                out.push('\n');
                write_indent(out, body_indent);
                format_node(out, &children[2], body_indent, config);
                idx = 3;
            }
        }
    }

    // Parameters vector (or multi-arity)
    if idx < children.len() {
        out.push('\n');
        write_indent(out, body_indent);

        // Check if it's multi-arity (next child is a list)
        if let FmtNode::Collection {
            delimiter: Delimiter::Paren,
            ..
        } = &children[idx]
        {
            // Multi-arity - each clause on its own line
            for child in &children[idx..] {
                format_node(out, child, body_indent, config);
                if !std::ptr::eq(child, children.last().unwrap()) {
                    out.push('\n');
                    write_indent(out, body_indent);
                }
            }
        } else {
            // Single arity - params then body
            format_node(out, &children[idx], body_indent, config);
            idx += 1;

            // Body expressions
            for child in &children[idx..] {
                out.push('\n');
                write_indent(out, body_indent);
                format_node(out, child, body_indent, config);
            }
        }
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_fn(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    // Try inline for simple fns
    let complexity: usize = children.iter().map(|c| c.complexity()).sum();
    let inline_len: usize = children.iter().map(|c| c.inline_len()).sum::<usize>() + children.len();

    if complexity <= 2 && inline_len + indent <= config.max_line_length {
        format_inline(out, delimiter, children, trailing_comment);
        return;
    }

    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // fn [params]
    for (i, child) in children.iter().take(2).enumerate() {
        if i > 0 {
            out.push(' ');
        }
        format_node(out, child, indent, config);
    }

    // Body
    for child in children.iter().skip(2) {
        out.push('\n');
        write_indent(out, body_indent);
        format_node(out, child, body_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_let(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // let keyword
    if let Some(kw) = children.first() {
        format_node(out, kw, indent, config);
    }

    // Bindings vector
    if children.len() > 1 {
        out.push(' ');
        if let FmtNode::Collection {
            delimiter: Delimiter::Bracket,
            children: bindings,
            ..
        } = &children[1]
        {
            format_let_bindings(out, bindings, indent, config);
        } else {
            format_node(out, &children[1], indent, config);
        }
    }

    // Body
    for child in children.iter().skip(2) {
        out.push('\n');
        write_indent(out, body_indent);
        format_node(out, child, body_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_let_bindings(
    out: &mut String,
    bindings: &[FmtNode],
    base_indent: usize,
    config: &FormatConfig,
) {
    // Must have even number (name-value pairs)
    if bindings.len() % 2 != 0 {
        // Fall back to simple formatting
        out.push('[');
        for (i, b) in bindings.iter().enumerate() {
            if i > 0 {
                out.push(' ');
            }
            format_node_inline(out, b);
        }
        out.push(']');
        return;
    }

    let pairs: Vec<_> = bindings.chunks(2).collect();

    // Try inline if simple
    let total_len: usize = bindings.iter().map(|b| b.inline_len()).sum::<usize>() + bindings.len();
    if total_len + base_indent + 2 <= config.max_line_length && pairs.len() <= 2 {
        out.push('[');
        for (i, b) in bindings.iter().enumerate() {
            if i > 0 {
                out.push(' ');
            }
            format_node_inline(out, b);
        }
        out.push(']');
        return;
    }

    // Multiline with alignment
    let max_name_len = if config.align_let_bindings {
        pairs
            .iter()
            .filter_map(|p| {
                if let FmtNode::Atom(name) = &p[0] {
                    Some(name.len())
                } else {
                    None
                }
            })
            .max()
            .unwrap_or(0)
    } else {
        0
    };

    out.push('[');
    let binding_indent = base_indent + config.indent_size + 1;

    for (i, pair) in pairs.iter().enumerate() {
        if i > 0 {
            out.push('\n');
            write_indent(out, binding_indent);
        }

        let mut name_str = String::new();
        format_node_inline(&mut name_str, &pair[0]);
        out.push_str(&name_str);

        // Align values if configured
        if config.align_let_bindings && max_name_len > 0 {
            for _ in name_str.len()..max_name_len {
                out.push(' ');
            }
        }
        out.push(' ');

        format_node(out, &pair[1], binding_indent, config);
    }

    out.push(']');
}

fn format_if(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    // Try inline for simple if
    let total_len: usize = children.iter().map(|c| c.inline_len()).sum::<usize>() + children.len();
    let complexity: usize = children.iter().map(|c| c.complexity()).max().unwrap_or(0);

    if complexity <= 1 && total_len + indent <= config.max_line_length {
        format_inline(out, delimiter, children, trailing_comment);
        return;
    }

    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // if/when condition
    for (i, child) in children.iter().take(2).enumerate() {
        if i > 0 {
            out.push(' ');
        }
        format_node(out, child, indent, config);
    }

    // then/else branches
    for child in children.iter().skip(2) {
        out.push('\n');
        write_indent(out, body_indent);
        format_node(out, child, body_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_cond(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // cond keyword
    if let Some(kw) = children.first() {
        format_node(out, kw, indent, config);
    }

    // Pairs - each pair on its own line
    let pairs: Vec<_> = children.iter().skip(1).collect();
    for pair in pairs.chunks(2) {
        out.push('\n');
        write_indent(out, body_indent);

        // Test
        if let Some(test) = pair.first() {
            format_node(out, test, body_indent, config);
        }

        // Result
        if let Some(result) = pair.get(1) {
            out.push(' ');
            format_node(out, result, body_indent, config);
        }
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn format_with_handler(
    out: &mut String,
    delimiter: &Delimiter,
    children: &[FmtNode],
    trailing_comment: &Option<String>,
    indent: usize,
    config: &FormatConfig,
) {
    out.push_str(delimiter.open_str());

    let body_indent = indent + config.indent_size;

    // with-handler [effect]
    for (i, child) in children.iter().take(2).enumerate() {
        if i > 0 {
            out.push(' ');
        }
        format_node(out, child, indent, config);
    }

    // Body and handler clauses
    // Look for :handle keyword to format it with the following clause
    let mut iter = children.iter().skip(2).peekable();
    while let Some(child) = iter.next() {
        out.push('\n');
        write_indent(out, body_indent);

        // Check if this is :handle keyword
        if let FmtNode::Atom(s) = child {
            if s == ":handle" {
                out.push_str(s);
                // Put the handler clause on the same line
                if let Some(clause) = iter.next() {
                    out.push(' ');
                    format_node(out, clause, body_indent, config);
                }
                continue;
            }
        }

        format_node(out, child, body_indent, config);
    }

    out.push_str(delimiter.close_str());
    if let Some(tc) = trailing_comment {
        out.push(' ');
        out.push_str(tc);
    }
}

fn write_indent(out: &mut String, n: usize) {
    for _ in 0..n {
        out.push(' ');
    }
}

fn write_indent_to(out: &mut String, n: usize) {
    for _ in 0..n {
        out.push(' ');
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_tokenize_simple() {
        let tokens = tokenize("(+ 1 2)");
        assert_eq!(
            tokens,
            vec![
                Token::Open(Delimiter::Paren),
                Token::Atom("+".into()),
                Token::Whitespace(" ".into()),
                Token::Atom("1".into()),
                Token::Whitespace(" ".into()),
                Token::Atom("2".into()),
                Token::Close(Delimiter::Paren),
            ]
        );
    }

    #[test]
    fn test_tokenize_with_comment() {
        let tokens = tokenize("(+ 1 ; comment\n 2)");
        assert!(tokens.contains(&Token::Comment("; comment".into())));
    }

    #[test]
    fn test_format_simple() {
        let config = FormatConfig::default();
        let result = format("(+ 1 2)", &config);
        assert_eq!(result, "(+ 1 2)\n");
    }

    #[test]
    fn test_format_defn() {
        let config = FormatConfig::default();
        let result = format("(defn foo [x] (+ x 1))", &config);
        assert!(result.contains("defn foo"));
        assert!(result.contains("[x]"));
    }

    #[test]
    fn test_format_let() {
        let config = FormatConfig::default();
        let result = format("(let [a 1 b 2] (+ a b))", &config);
        assert!(result.contains("let"));
    }

    #[test]
    fn test_format_threading() {
        let config = FormatConfig::default();
        let result = format("(-> x (f a) (g b) (h c))", &config);
        // Each step should be on its own line
        assert!(result.contains('\n'));
    }

    #[test]
    fn test_complexity() {
        let tokens = tokenize("[1 2 3]");
        let nodes = parse_fmt(&tokens);
        assert_eq!(nodes[0].complexity(), 1);

        let tokens = tokenize("[[1] [2]]");
        let nodes = parse_fmt(&tokens);
        assert_eq!(nodes[0].complexity(), 2);
    }
}
