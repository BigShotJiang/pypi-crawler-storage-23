//! Clojure value types
//!
//! See SPEC.md Section 1 for the complete type list.
//!
//! Note: Function and Macro values are only used by the VM's heap objects.
//! This module defines the AST values produced by the reader.

use std::hash::Hash;
use std::sync::Arc;

use crate::Result;
use crate::eval::NativeResult;
use crate::list::List;
use crate::optic::Optic;
use crate::span::Span;

/// Unique identifier for an effect instance.
///
/// Effect identity is by EffectId, not by name - this allows lexical shadowing
/// to create distinct effects.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct EffectId(pub u64);

/// Operation signature within an effect
#[derive(Debug, Clone)]
pub struct OpSignature {
    /// Operation name
    pub name: Arc<str>,
    /// Parameter names (for documentation/error messages)
    pub params: Vec<Arc<str>>,
}

/// What kind of call frame appears in the call stack
#[derive(Debug, Clone)]
pub enum CallFrameKind {
    /// Named user-defined function: (defn foo ...)
    UserFn(Arc<str>),
    /// Anonymous function: (fn [...] ...)
    Anonymous,
    /// Native function: +, map, etc.
    Native(&'static str),
    /// Effect operation: exn/raise, console/println
    Effect { effect: Arc<str>, op: Arc<str> },
    /// Handler clause (synthetic): <handler exn/raise>
    Handler { effect: Arc<str>, op: Arc<str> },
}

/// A single frame in the call stack
#[derive(Debug, Clone)]
pub struct CallFrame {
    /// What kind of call this is
    pub kind: CallFrameKind,
    /// Call site location (where the call expression appears)
    pub span: Option<Span>,
}

/// Interned symbol: foo, bar, clojure.core/map
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Symbol {
    pub namespace: Option<Arc<str>>,
    pub name: Arc<str>,
}

/// Interned keyword: :foo, :bar, :user/name (callable)
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Keyword {
    pub namespace: Option<Arc<str>>,
    pub name: Arc<str>,
}

/// Native function signature
pub type NativeFn = Arc<dyn Fn(&[Value]) -> Result<NativeResult>>;

/// A Clojure value
///
/// Uses `im` crate for persistent collections with structural sharing.
/// See SPEC.md "Backing Data Structures" for rationale.
///
/// Note: List is wrapped in Arc to break the recursive type cycle and
/// enable cheap cloning of list heads.
#[derive(Clone)]
pub enum Value {
    Nil,
    Bool(bool),
    Int(i64),
    Ratio {
        numer: i64,
        denom: i64,
    },
    Float(f64),
    String(Arc<str>),
    Symbol(Symbol),
    Keyword(Keyword),
    List(Arc<List>), // Persistent cons cells (Arc breaks recursion)
    Vector(crate::collections::Vector<Value>), // Persistent RRB-tree
    Map(crate::collections::HashMap<Value, Value>), // Persistent HAMT
    Set(crate::collections::HashSet<Value>), // Persistent HAMT
    NativeFn {
        name: &'static str,
        func: NativeFn,
    },
    Meta {
        value: Box<Value>,
        span: Span,
    },
    Optic(Arc<Optic>),
    /// Compiled regular expression
    Regex(Arc<regex::Regex>),
    /// Effect definition: a named collection of operations
    Effect {
        id: EffectId,
        name: Option<Arc<str>>,
        ops: crate::collections::HashMap<Arc<str>, OpSignature>,
    },
    /// Mutable atom (lock-free reference cell)
    Atom(Arc<arc_swap::ArcSwap<Value>>),
}

impl std::fmt::Debug for Value {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Value::Nil => write!(f, "Nil"),
            Value::Bool(b) => write!(f, "Bool({})", b),
            Value::Int(i) => write!(f, "Int({})", i),
            Value::Ratio { numer, denom } => write!(f, "Ratio({}/{})", numer, denom),
            Value::Float(fl) => write!(f, "Float({})", fl),
            Value::String(s) => write!(f, "String({:?})", s),
            Value::Symbol(sym) => write!(f, "Symbol({:?})", sym),
            Value::Keyword(kw) => write!(f, "Keyword({:?})", kw),
            Value::List(list) => write!(f, "List({:?})", list),
            Value::Vector(vec) => write!(f, "Vector({:?})", vec),
            Value::Map(map) => write!(f, "Map({:?})", map),
            Value::Set(set) => write!(f, "Set({:?})", set),
            Value::NativeFn { name, .. } => write!(f, "NativeFn({})", name),
            Value::Meta { value, span } => write!(f, "Meta({:?}, {:?})", value, span),
            Value::Optic(o) => write!(f, "Optic({:?})", o),
            Value::Regex(r) => write!(f, "Regex({:?})", r.as_str()),
            Value::Effect { id, name, ops } => write!(f, "Effect({:?}, {:?}, {:?})", id, name, ops),
            Value::Atom(a) => write!(f, "Atom({:?})", a.load()),
        }
    }
}

impl Value {
    pub fn symbol(name: impl Into<Arc<str>>) -> Self {
        Value::Symbol(Symbol {
            namespace: None,
            name: name.into(),
        })
    }

    pub fn symbol_ns(ns: impl Into<Arc<str>>, name: impl Into<Arc<str>>) -> Self {
        Value::Symbol(Symbol {
            namespace: Some(ns.into()),
            name: name.into(),
        })
    }

    pub fn keyword(name: impl Into<Arc<str>>) -> Self {
        Value::Keyword(Keyword {
            namespace: None,
            name: name.into(),
        })
    }

    pub fn keyword_ns(ns: impl Into<Arc<str>>, name: impl Into<Arc<str>>) -> Self {
        Value::Keyword(Keyword {
            namespace: Some(ns.into()),
            name: name.into(),
        })
    }

    pub fn list_from_iter(iter: impl IntoIterator<Item = Value>) -> Self {
        Value::List(Arc::new(List::from_iter(iter)))
    }

    pub fn split_meta(&self) -> (&Value, Option<Span>) {
        let mut current = self;
        let mut span = None;
        while let Value::Meta {
            value,
            span: value_span,
        } = current
        {
            if span.is_none() {
                span = Some(*value_span);
            }
            current = value;
        }
        (current, span)
    }

    pub fn strip_meta(&self) -> &Value {
        self.split_meta().0
    }

    pub fn meta_span(&self) -> Option<Span> {
        self.split_meta().1
    }

    pub fn type_name(&self) -> &'static str {
        match self.strip_meta() {
            Value::Nil => "nil",
            Value::Bool(_) => "bool",
            Value::Int(_) => "int",
            Value::Ratio { .. } => "ratio",
            Value::Float(_) => "float",
            Value::String(_) => "string",
            Value::Symbol(_) => "symbol",
            Value::Keyword(_) => "keyword",
            Value::List(_) => "list",
            Value::Vector(_) => "vector",
            Value::Map(_) => "map",
            Value::Set(_) => "set",
            Value::NativeFn { .. } => "native-fn",
            Value::Meta { .. } => "meta",
            Value::Optic(_) => "optic",
            Value::Regex(_) => "regex",
            Value::Effect { .. } => "effect",
            Value::Atom(_) => "atom",
        }
    }

    pub fn is_truthy(&self) -> bool {
        !matches!(self.strip_meta(), Value::Nil | Value::Bool(false))
    }
}

// --- PartialEq, Eq, Hash for Value ---
// Required for use as keys in crate::collections::HashMap and crate::collections::HashSet

impl PartialEq for Value {
    fn eq(&self, other: &Self) -> bool {
        let left = self.strip_meta();
        let right = other.strip_meta();
        match (left, right) {
            (Value::Nil, Value::Nil) => true,
            (Value::Bool(a), Value::Bool(b)) => a == b,
            (Value::Int(a), Value::Int(b)) => a == b,
            (Value::Ratio { numer: a, denom: b }, Value::Ratio { numer: c, denom: d }) => {
                a == c && b == d
            }
            (Value::Float(a), Value::Float(b)) => a.to_bits() == b.to_bits(),
            (Value::String(a), Value::String(b)) => a == b,
            (Value::Symbol(a), Value::Symbol(b)) => a == b,
            (Value::Keyword(a), Value::Keyword(b)) => a == b,
            (Value::List(a), Value::List(b)) => list_eq(a, b),
            (Value::Vector(a), Value::Vector(b)) => a == b,
            (Value::Map(a), Value::Map(b)) => a == b,
            (Value::Set(a), Value::Set(b)) => a == b,
            // Functions are never equal (identity comparison would need more machinery)
            (Value::NativeFn { name: a, .. }, Value::NativeFn { name: b, .. }) => a == b,
            (Value::Optic(a), Value::Optic(b)) => Arc::ptr_eq(a, b),
            // Regexes are equal if their patterns are equal
            (Value::Regex(a), Value::Regex(b)) => a.as_str() == b.as_str(),
            // Effects are equal if they have the same EffectId
            (Value::Effect { id: a, .. }, Value::Effect { id: b, .. }) => a == b,
            // Atoms use identity comparison
            (Value::Atom(a), Value::Atom(b)) => Arc::ptr_eq(a, b),
            _ => false,
        }
    }
}

impl Eq for Value {}

impl std::hash::Hash for Value {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        let value = self.strip_meta();
        std::mem::discriminant(value).hash(state);
        match value {
            Value::Nil => {}
            Value::Bool(b) => b.hash(state),
            Value::Int(i) => i.hash(state),
            Value::Ratio { numer, denom } => {
                numer.hash(state);
                denom.hash(state);
            }
            Value::Float(f) => f.to_bits().hash(state),
            Value::String(s) => s.hash(state),
            Value::Symbol(s) => s.hash(state),
            Value::Keyword(k) => k.hash(state),
            Value::List(l) => list_hash(l, state),
            Value::Vector(v) => {
                for item in v.iter() {
                    item.hash(state);
                }
            }
            Value::Map(m) => {
                // Hash order-independently by XORing hashes
                let mut h = 0u64;
                for (k, v) in m.iter() {
                    let mut hasher = std::hash::DefaultHasher::new();
                    k.hash(&mut hasher);
                    v.hash(&mut hasher);
                    h ^= std::hash::Hasher::finish(&hasher);
                }
                h.hash(state);
            }
            Value::Set(s) => {
                let mut h = 0u64;
                for item in s.iter() {
                    let mut hasher = std::hash::DefaultHasher::new();
                    item.hash(&mut hasher);
                    h ^= std::hash::Hasher::finish(&hasher);
                }
                h.hash(state);
            }
            Value::NativeFn { name, .. } => name.hash(state),
            Value::Meta { .. } => {}
            Value::Optic(o) => Arc::as_ptr(o).hash(state), // Identity-based hash
            Value::Regex(r) => r.as_str().hash(state),     // Hash by pattern string
            Value::Effect { id, .. } => id.hash(state),    // Hash by EffectId
            Value::Atom(a) => Arc::as_ptr(a).hash(state),  // Identity-based hash
        }
    }
}

fn list_eq(a: &List, b: &List) -> bool {
    if a.len() != b.len() {
        return false;
    }
    a.iter().zip(b.iter()).all(|(x, y)| x == y)
}

fn list_hash<H: std::hash::Hasher>(list: &List, state: &mut H) {
    for item in list.iter() {
        item.hash(state);
    }
}
