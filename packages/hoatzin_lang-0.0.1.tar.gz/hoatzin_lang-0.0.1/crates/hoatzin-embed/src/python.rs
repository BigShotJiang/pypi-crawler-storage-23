use pyo3::prelude::*;
use pyo3::types::{PyBool, PyDict, PyFloat, PyFrozenSet, PyInt, PyList, PySet, PyString, PyTuple};

use crate::engine::Engine;
use crate::value::Value;
use crate::HandlerResult;

// ---------------------------------------------------------------------------
// Exception hierarchy
// ---------------------------------------------------------------------------

pyo3::create_exception!(hoatzin, HoatzinError, pyo3::exceptions::PyException, "Base exception for all Hoatzin errors.");
pyo3::create_exception!(hoatzin, EvalError, HoatzinError, "Raised when Hoatzin code fails to evaluate.");
pyo3::create_exception!(hoatzin, CompileError, HoatzinError, "Raised when Hoatzin code fails to compile.");
pyo3::create_exception!(hoatzin, HandlerError, HoatzinError, "Raised when an effect handler callback fails.");
pyo3::create_exception!(hoatzin, EffectNotFoundError, HoatzinError, "Raised when a named effect does not exist.");

// ---------------------------------------------------------------------------
// Error mapping
// ---------------------------------------------------------------------------

fn to_py_err(e: crate::Error) -> PyErr {
    match &e {
        crate::Error::Hoatzin(eval_err) => {
            let msg = e.to_string();
            match eval_err {
                hoatzin_core::vm::EvalError::Parse(_)
                | hoatzin_core::vm::EvalError::Compile(_) => PyErr::new::<CompileError, _>(msg),
                hoatzin_core::vm::EvalError::Runtime(_) => PyErr::new::<EvalError, _>(msg),
            }
        }
        crate::Error::Type { .. } => PyErr::new::<EvalError, _>(e.to_string()),
        crate::Error::Edn(_) => PyErr::new::<CompileError, _>(e.to_string()),
        crate::Error::Handler(_) => PyErr::new::<HandlerError, _>(e.to_string()),
        crate::Error::EffectNotFound(_) => PyErr::new::<EffectNotFoundError, _>(e.to_string()),
    }
}

// ---------------------------------------------------------------------------
// PyKeyword
// ---------------------------------------------------------------------------

#[pyclass(name = "Keyword", module = "hoatzin", frozen, hash, eq)]
#[derive(Clone)]
pub struct PyKeyword {
    #[pyo3(get)]
    name: String,
}

#[pymethods]
impl PyKeyword {
    #[new]
    fn new(name: String) -> Self {
        PyKeyword { name }
    }

    fn __repr__(&self) -> String {
        format!("Keyword(\"{}\")", self.name)
    }

    fn __str__(&self) -> &str {
        &self.name
    }
}

impl PartialEq for PyKeyword {
    fn eq(&self, other: &Self) -> bool {
        self.name == other.name
    }
}

impl Eq for PyKeyword {}

impl std::hash::Hash for PyKeyword {
    fn hash<H: std::hash::Hasher>(&self, state: &mut H) {
        self.name.hash(state);
    }
}

// ---------------------------------------------------------------------------
// PyAgentJournal
// ---------------------------------------------------------------------------

#[pyclass(name = "AgentJournal", module = "hoatzin", unsendable)]
pub struct PyAgentJournal {
    inner: hoatzin_core::vm::AgentJournal,
}

#[pymethods]
impl PyAgentJournal {
    #[new]
    fn new() -> Self {
        PyAgentJournal {
            inner: hoatzin_core::vm::AgentJournal::new(),
        }
    }
}

// ---------------------------------------------------------------------------
// PyEngine
// ---------------------------------------------------------------------------

#[pyclass(name = "Engine", module = "hoatzin", unsendable)]
pub struct PyEngine {
    engine: Engine,
}

#[pymethods]
impl PyEngine {
    #[new]
    fn new() -> PyResult<Self> {
        let engine = Engine::with_default_handlers().map_err(to_py_err)?;
        Ok(PyEngine { engine })
    }

    #[staticmethod]
    fn bare() -> Self {
        PyEngine {
            engine: Engine::bare(),
        }
    }

    #[staticmethod]
    fn with_defaults() -> PyResult<Self> {
        let engine = Engine::with_default_handlers().map_err(to_py_err)?;
        Ok(PyEngine { engine })
    }

    fn eval(&mut self, py: Python, src: &str) -> PyResult<PyObject> {
        let val = self.engine.eval(src).map_err(to_py_err)?;
        value_to_py(py, &val)
    }

    fn eval_with_source(
        &mut self,
        py: Python,
        src: &str,
        source_name: &str,
    ) -> PyResult<PyObject> {
        let val = self
            .engine
            .eval_with_source(src, source_name)
            .map_err(to_py_err)?;
        value_to_py(py, &val)
    }

    fn define(&mut self, py: Python, name: &str, val: PyObject) -> PyResult<()> {
        let v = py_to_value(py, val.bind(py))?;
        self.engine.define(name, v);
        Ok(())
    }

    fn define_fn(&mut self, _py: Python, name: &str, func: PyObject) -> PyResult<()> {
        let func: Py<PyAny> = func;
        self.engine.define_fn(name, move |args: Vec<Value>| {
            Python::with_gil(|py| {
                let py_args: Vec<PyObject> = args
                    .iter()
                    .map(|a| value_to_py(py, a))
                    .collect::<PyResult<_>>()
                    .map_err(|e| crate::Error::Handler(e.to_string()))?;
                let tuple = PyTuple::new(py, &py_args)
                    .map_err(|e| crate::Error::Handler(e.to_string()))?;
                let result = func
                    .call1(py, tuple)
                    .map_err(|e| crate::Error::Handler(e.to_string()))?;
                py_to_value(py, result.bind(py))
                    .map_err(|e| crate::Error::Handler(e.to_string()))
            })
        });
        Ok(())
    }

    fn register_handler(
        &mut self,
        _py: Python,
        effect: &str,
        handler: PyObject,
    ) -> PyResult<()> {
        let handler: Py<PyAny> = handler;
        self.engine
            .register_handler(effect, move |op: &str, args: Vec<Value>| {
                Python::with_gil(|py| {
                    let py_args: Vec<PyObject> = args
                        .iter()
                        .map(|a| value_to_py(py, a))
                        .collect::<PyResult<_>>()
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    let py_args_list = PyList::new(py, &py_args)
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    let result = handler
                        .call1(py, (op, py_args_list))
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    let result = result.bind(py);
                    let action: String = result
                        .get_item(0)
                        .map_err(|e| crate::Error::Handler(e.to_string()))?
                        .extract()
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    let val_obj = result
                        .get_item(1)
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    let val = py_to_value(py, &val_obj)
                        .map_err(|e| crate::Error::Handler(e.to_string()))?;
                    match action.as_str() {
                        "resume" => Ok(HandlerResult::Resume(val)),
                        "abort" => Ok(HandlerResult::Abort(val)),
                        other => Err(crate::Error::Handler(format!(
                            "expected 'resume' or 'abort', got '{}'",
                            other
                        ))),
                    }
                })
            })
            .map_err(to_py_err)
    }

    fn effect_id(&self, name: &str) -> Option<u64> {
        self.engine.effect_id(name).map(|id| id.0)
    }

    fn eval_agent(
        &mut self,
        py: Python,
        src: &str,
        journal: &mut PyAgentJournal,
    ) -> PyResult<PyObject> {
        let results = self
            .engine
            .eval_agent(src, &mut journal.inner)
            .map_err(to_py_err)?;
        let list = PyList::empty(py);
        for r in &results {
            let dict = PyDict::new(py);
            dict.set_item("value", value_to_py(py, &r.value)?)?;
            dict.set_item("lineage_message", r.lineage_message.as_deref())?;
            list.append(dict)?;
        }
        Ok(list.into_any().unbind())
    }

    /// Porcelain agent eval: text in, text out.
    /// Returns formatted output matching the CLI REPL experience.
    fn eval_text(
        &mut self,
        src: &str,
        journal: &mut PyAgentJournal,
    ) -> PyResult<String> {
        self.engine
            .eval_agent_text(src, &mut journal.inner)
            .map_err(to_py_err)
    }
}

// ---------------------------------------------------------------------------
// Value ↔ PyObject conversions
// ---------------------------------------------------------------------------

fn value_to_py(py: Python, val: &Value) -> PyResult<PyObject> {
    match val {
        Value::Nil => Ok(py.None()),
        Value::Bool(b) => Ok(b.into_pyobject(py)?.to_owned().into_any().unbind()),
        Value::Int(i) => Ok(i.into_pyobject(py)?.into_any().unbind()),
        Value::Float(f) => Ok(f.into_pyobject(py)?.into_any().unbind()),
        Value::Ratio { numer, denom } => {
            let fractions = py.import("fractions")?;
            let frac = fractions.getattr("Fraction")?.call1((*numer, *denom))?;
            Ok(frac.unbind())
        }
        Value::String(s) => Ok(s.as_ref().into_pyobject(py)?.into_any().unbind()),
        Value::Keyword(s) => {
            let kw = PyKeyword::new(s.to_string());
            Ok(kw.into_pyobject(py)?.into_any().unbind())
        }
        Value::Symbol(s) => Ok(s.as_ref().into_pyobject(py)?.into_any().unbind()),
        Value::List(items) | Value::Vector(items) => {
            let py_items: Vec<PyObject> = items
                .iter()
                .map(|v| value_to_py(py, v))
                .collect::<PyResult<_>>()?;
            let list = PyList::new(py, &py_items)?;
            Ok(list.into_any().unbind())
        }
        Value::Map(map) => {
            let dict = PyDict::new(py);
            for (k, v) in map.iter() {
                dict.set_item(value_to_py(py, k)?, value_to_py(py, v)?)?;
            }
            Ok(dict.into_any().unbind())
        }
        Value::Set(set) => {
            let py_items: Vec<PyObject> = set
                .iter()
                .map(|v| value_to_py(py, v))
                .collect::<PyResult<_>>()?;
            let frozen = PyFrozenSet::new(py, &py_items)?;
            Ok(frozen.into_any().unbind())
        }
        Value::Regex(r) => {
            let re = py.import("re")?;
            let compiled = re.call_method1("compile", (r.as_str(),))?;
            Ok(compiled.unbind())
        }
        Value::Opaque(s) => Ok(s.as_str().into_pyobject(py)?.into_any().unbind()),
    }
}

fn py_to_value(py: Python, obj: &Bound<'_, PyAny>) -> PyResult<Value> {
    // None
    if obj.is_none() {
        return Ok(Value::Nil);
    }
    // Bool before Int (bool is subclass of int in Python)
    if obj.is_instance_of::<PyBool>() {
        return Ok(Value::Bool(obj.extract::<bool>()?));
    }
    if obj.is_instance_of::<PyInt>() {
        return Ok(Value::Int(obj.extract::<i64>()?));
    }
    if obj.is_instance_of::<PyFloat>() {
        return Ok(Value::Float(obj.extract::<f64>()?));
    }
    if obj.is_instance_of::<PyString>() {
        let s: String = obj.extract()?;
        return Ok(Value::String(s.into()));
    }
    // PyKeyword
    if obj.is_instance_of::<PyKeyword>() {
        let kw: PyRef<PyKeyword> = obj.extract()?;
        return Ok(Value::Keyword(kw.name.clone().into()));
    }
    // List or Tuple → Vector
    if obj.is_instance_of::<PyList>() {
        let list = obj.downcast::<PyList>()?;
        let items: Vec<Value> = list
            .iter()
            .map(|item| py_to_value(py, &item))
            .collect::<PyResult<_>>()?;
        return Ok(Value::Vector(items.into_iter().collect()));
    }
    if obj.is_instance_of::<PyTuple>() {
        let tuple = obj.downcast::<PyTuple>()?;
        let items: Vec<Value> = tuple
            .iter()
            .map(|item| py_to_value(py, &item))
            .collect::<PyResult<_>>()?;
        return Ok(Value::Vector(items.into_iter().collect()));
    }
    // Dict → Map
    if obj.is_instance_of::<PyDict>() {
        let dict = obj.downcast::<PyDict>()?;
        let mut map = hoatzin_core::collections::HashMap::new();
        for (k, v) in dict.iter() {
            map.insert(py_to_value(py, &k)?, py_to_value(py, &v)?);
        }
        return Ok(Value::Map(map));
    }
    // Set or FrozenSet → Set
    if obj.is_instance_of::<PySet>() {
        let set = obj.downcast::<PySet>()?;
        let mut hset = hoatzin_core::collections::HashSet::new();
        for item in set.iter() {
            hset.insert(py_to_value(py, &item)?);
        }
        return Ok(Value::Set(hset));
    }
    if obj.is_instance_of::<PyFrozenSet>() {
        let set = obj.downcast::<PyFrozenSet>()?;
        let mut hset = hoatzin_core::collections::HashSet::new();
        for item in set.iter() {
            hset.insert(py_to_value(py, &item)?);
        }
        return Ok(Value::Set(hset));
    }
    // fractions.Fraction
    if let Ok(fractions) = py.import("fractions")
        && let Ok(frac_type) = fractions.getattr("Fraction")
        && obj.is_instance(&frac_type).unwrap_or(false)
    {
        let numer: i64 = obj.getattr("numerator")?.extract()?;
        let denom: i64 = obj.getattr("denominator")?.extract()?;
        return Ok(Value::Ratio { numer, denom });
    }
    // Fallback: stringify
    let s: String = obj.str()?.to_string();
    Ok(Value::String(s.into()))
}

// ---------------------------------------------------------------------------
// Module-level function
// ---------------------------------------------------------------------------

#[pyfunction]
fn parse_edn(py: Python, src: &str) -> PyResult<PyObject> {
    let val = crate::edn::parse(src).map_err(to_py_err)?;
    value_to_py(py, &val)
}

// ---------------------------------------------------------------------------
// Module registration
// ---------------------------------------------------------------------------

#[pymodule]
fn hoatzin(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<PyEngine>()?;
    m.add_class::<PyKeyword>()?;
    m.add_class::<PyAgentJournal>()?;
    m.add_function(wrap_pyfunction!(parse_edn, m)?)?;

    // Exception hierarchy
    m.add("HoatzinError", m.py().get_type::<HoatzinError>())?;
    m.add("EvalError", m.py().get_type::<EvalError>())?;
    m.add("CompileError", m.py().get_type::<CompileError>())?;
    m.add("HandlerError", m.py().get_type::<HandlerError>())?;
    m.add("EffectNotFoundError", m.py().get_type::<EffectNotFoundError>())?;

    Ok(())
}
