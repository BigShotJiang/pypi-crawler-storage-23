use hoatzin_core::vm::EvalError;

#[derive(Debug, thiserror::Error)]
pub enum Error {
    #[error("{0}")]
    Hoatzin(#[from] EvalError),

    #[error("type error: expected {expected}, got {got}")]
    Type {
        expected: &'static str,
        got: &'static str,
    },

    #[error("invalid EDN: {0}")]
    Edn(String),

    #[error("handler error: {0}")]
    Handler(String),

    #[error("effect not found: {0}")]
    EffectNotFound(String),
}
