use std::rc::Rc;

use hoatzin_core::collections;
use hoatzin_core::vm::{HeapObject, SeqData, SeqKind, VM, VMValue};

use crate::Value;

impl Value {
    /// Convert a VMValue from the VM into an embedding Value.
    pub fn from_vm(vm: &VM, v: VMValue) -> Value {
        match v {
            VMValue::Nil => Value::Nil,
            VMValue::Bool(b) => Value::Bool(b),
            VMValue::Int(i) => Value::Int(i),
            VMValue::Float(f) => Value::Float(f),
            VMValue::Ratio { numer, denom } => Value::Ratio { numer, denom },
            VMValue::Symbol(spur) => {
                Value::Symbol(Rc::from(vm.interner().resolve(&spur)))
            }
            VMValue::Keyword(spur) => {
                Value::Keyword(Rc::from(vm.interner().resolve(&spur)))
            }
            VMValue::NativeFn(_) => Value::Opaque("native-fn".into()),
            VMValue::HeapRef(key) => match vm.heap().get(key) {
                Some(HeapObject::String(s)) => Value::String(Rc::from(s.as_str())),
                Some(HeapObject::Seq(seq)) => {
                    let items: collections::Vector<Value> =
                        seq.data.iter().map(|v| Value::from_vm(vm, *v)).collect();
                    match seq.kind {
                        SeqKind::List => Value::List(items),
                        SeqKind::Vector => Value::Vector(items),
                    }
                }
                Some(HeapObject::Map(m)) => {
                    let map: collections::HashMap<Value, Value> = m
                        .iter()
                        .map(|(k, v)| (Value::from_vm(vm, *k), Value::from_vm(vm, *v)))
                        .collect();
                    Value::Map(map)
                }
                Some(HeapObject::Set(s)) => {
                    let set: collections::HashSet<Value> =
                        s.iter().map(|v| Value::from_vm(vm, *v)).collect();
                    Value::Set(set)
                }
                Some(HeapObject::Regex(r)) => Value::Regex(Rc::new(r.clone())),
                Some(HeapObject::Variant(inst)) => {
                    Value::Opaque(format!("variant(tag={})", inst.tag))
                }
                Some(HeapObject::Closure(_) | HeapObject::ClosureTemplate(_)) => {
                    Value::Opaque("closure".into())
                }
                Some(HeapObject::Continuation(_)) => Value::Opaque("continuation".into()),
                Some(HeapObject::Atom(_)) => Value::Opaque("atom".into()),
                Some(HeapObject::Optic(_)) => Value::Opaque("optic".into()),
                Some(HeapObject::Effect(_)) => Value::Opaque("effect".into()),
                Some(HeapObject::KeyBox(_)) => Value::Opaque("keybox".into()),
                None => Value::Nil,
            },
        }
    }

    /// Convert an AST Value (from the reader) into an embedding Value.
    pub fn from_ast(v: &hoatzin_core::Value) -> Value {
        let v = v.strip_meta();
        match v {
            hoatzin_core::Value::Nil => Value::Nil,
            hoatzin_core::Value::Bool(b) => Value::Bool(*b),
            hoatzin_core::Value::Int(i) => Value::Int(*i),
            hoatzin_core::Value::Float(f) => Value::Float(*f),
            hoatzin_core::Value::Ratio { numer, denom } => Value::Ratio {
                numer: *numer,
                denom: *denom,
            },
            hoatzin_core::Value::String(s) => Value::String(Rc::from(s.as_ref())),
            hoatzin_core::Value::Symbol(sym) => Value::Symbol(Rc::from(sym.name.as_ref())),
            hoatzin_core::Value::Keyword(kw) => Value::Keyword(Rc::from(kw.name.as_ref())),
            hoatzin_core::Value::List(list) => {
                let items: collections::Vector<Value> =
                    list.iter().map(Value::from_ast).collect();
                Value::List(items)
            }
            hoatzin_core::Value::Vector(vec) => {
                let items: collections::Vector<Value> =
                    vec.iter().map(Value::from_ast).collect();
                Value::Vector(items)
            }
            hoatzin_core::Value::Map(m) => {
                let map: collections::HashMap<Value, Value> = m
                    .iter()
                    .map(|(k, v)| (Value::from_ast(k), Value::from_ast(v)))
                    .collect();
                Value::Map(map)
            }
            hoatzin_core::Value::Set(s) => {
                let set: collections::HashSet<Value> = s.iter().map(Value::from_ast).collect();
                Value::Set(set)
            }
            hoatzin_core::Value::Regex(r) => Value::Regex(Rc::new(r.as_ref().clone())),
            hoatzin_core::Value::NativeFn { .. }
            | hoatzin_core::Value::Optic(_)
            | hoatzin_core::Value::Effect { .. }
            | hoatzin_core::Value::Atom(_) => Value::Opaque(v.type_name().into()),
            hoatzin_core::Value::Meta { .. } => unreachable!("strip_meta handled above"),
        }
    }

    /// Convert an embedding Value into a VMValue, allocating on the VM heap.
    pub fn to_vm(self, vm: &mut VM) -> VMValue {
        match self {
            Value::Nil => VMValue::Nil,
            Value::Bool(b) => VMValue::Bool(b),
            Value::Int(i) => VMValue::Int(i),
            Value::Float(f) => VMValue::Float(f),
            Value::Ratio { numer, denom } => VMValue::Ratio { numer, denom },
            Value::String(s) => vm.alloc_string(s.to_string()),
            Value::Symbol(s) => VMValue::Symbol(vm.interner_mut().get_or_intern(&*s)),
            Value::Keyword(s) => VMValue::Keyword(vm.interner_mut().get_or_intern(&*s)),
            Value::List(items) => {
                let data: collections::Vector<VMValue> =
                    items.into_iter().map(|v| v.to_vm(vm)).collect();
                let seq = SeqData {
                    data,
                    kind: SeqKind::List,
                };
                let key = vm.intern_seq(seq);
                VMValue::HeapRef(key)
            }
            Value::Vector(items) => {
                let data: collections::Vector<VMValue> =
                    items.into_iter().map(|v| v.to_vm(vm)).collect();
                let seq = SeqData {
                    data,
                    kind: SeqKind::Vector,
                };
                let key = vm.intern_seq(seq);
                VMValue::HeapRef(key)
            }
            Value::Map(m) => {
                let mut vm_map = collections::HashMap::new();
                for (k, v) in m {
                    let k = k.to_vm(vm);
                    let v = v.to_vm(vm);
                    vm_map = vm.map_insert(&vm_map, k, v);
                }
                let key = vm.intern_map(vm_map);
                VMValue::HeapRef(key)
            }
            Value::Set(s) => {
                let mut vm_set = collections::HashSet::new();
                for item in s {
                    let v = item.to_vm(vm);
                    let v = vm.canonicalize_key(v);
                    vm_set.insert(v);
                }
                let key = vm.intern_set(vm_set);
                VMValue::HeapRef(key)
            }
            Value::Regex(r) => {
                let obj = HeapObject::Regex(r.as_ref().clone());
                let key = vm.heap_mut().alloc_no_gc(obj);
                VMValue::HeapRef(key)
            }
            Value::Opaque(_) => VMValue::Nil,
        }
    }
}
