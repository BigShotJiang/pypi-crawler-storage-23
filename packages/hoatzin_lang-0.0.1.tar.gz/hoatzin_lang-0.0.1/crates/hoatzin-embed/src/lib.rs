#![allow(clippy::result_large_err)]

mod convert;
pub mod edn;
mod engine;
mod error;
#[cfg(feature = "python")]
mod python;
mod value;

pub use engine::Engine;
pub use error::Error;
pub use value::{Value, kw};

// Re-exports from hoatzin-core that embedders need
pub use hoatzin_core::vm::EffectId;
pub use hoatzin_core::vm::{AgentJournal, CompilationUnit, DocEntry};

/// Result of a native effect handler operation.
pub enum HandlerResult {
    /// Continue execution with this value.
    Resume(Value),
    /// Abort to handler install point, returning this value.
    Abort(Value),
}

/// Result from agent-mode evaluation.
pub struct AgentResult {
    pub value: Value,
    pub lineage_message: Option<String>,
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_edn_parse_map() {
        let val = edn::parse("{:port 8080}").unwrap();
        let map = val.as_map().unwrap();
        let port = map.get(&kw("port")).unwrap();
        assert_eq!(port, &Value::Int(8080));
    }

    #[test]
    fn test_edn_parse_all() {
        let vals = edn::parse_all("1 2 3").unwrap();
        assert_eq!(vals.len(), 3);
        assert_eq!(vals[0], Value::Int(1));
        assert_eq!(vals[1], Value::Int(2));
        assert_eq!(vals[2], Value::Int(3));
    }

    #[test]
    fn test_engine_eval_arithmetic() {
        let mut engine = Engine::with_default_handlers().unwrap();
        let result = engine.eval("(+ 1 2)").unwrap();
        assert_eq!(result, Value::Int(3));
    }

    #[test]
    fn test_engine_eval_string() {
        let mut engine = Engine::new().unwrap();
        let result = engine.eval(r#""hello""#).unwrap();
        assert_eq!(result.as_str(), Some("hello"));
    }

    #[test]
    fn test_engine_define_and_eval() {
        let mut engine = Engine::new().unwrap();
        engine.define("my-vec", Value::Vector(
            vec![Value::Int(1), Value::Int(2), Value::Int(3)].into_iter().collect(),
        ));
        let result = engine.eval("(count my-vec)").unwrap();
        assert_eq!(result, Value::Int(3));
    }

    #[test]
    fn test_engine_define_fn() {
        let mut engine = Engine::new().unwrap();
        engine.define_fn("double", |args| {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(n * 2)),
                _ => Err(Error::Type {
                    expected: "int",
                    got: "other",
                }),
            }
        });
        let result = engine.eval("(double 21)").unwrap();
        assert_eq!(result, Value::Int(42));
    }

    #[test]
    fn test_engine_define_fn_in_higher_order() {
        let mut engine = Engine::with_default_handlers().unwrap();
        engine.define_fn("triple", |args| {
            match &args[0] {
                Value::Int(n) => Ok(Value::Int(n * 3)),
                _ => Err(Error::Type {
                    expected: "int",
                    got: "other",
                }),
            }
        });
        let result = engine.eval("(first (map triple [1 2 3]))").unwrap();
        assert_eq!(result, Value::Int(3));
    }

    #[test]
    fn test_engine_register_handler() {
        use std::cell::RefCell;
        use std::rc::Rc;

        let output = Rc::new(RefCell::new(Vec::<String>::new()));
        let output_clone = output.clone();

        let mut engine = Engine::new().unwrap();
        engine
            .register_handler("console", move |op, args| {
                if op == "println" || op == "print" {
                    if let Some(val) = args.first() {
                        if let Some(s) = val.as_str() {
                            output_clone.borrow_mut().push(s.to_string());
                        }
                    }
                }
                Ok(HandlerResult::Resume(Value::Nil))
            })
            .unwrap();

        engine.eval(r#"(console/println "hello")"#).unwrap();
        engine.eval(r#"(console/println "world")"#).unwrap();

        let captured = output.borrow();
        assert_eq!(captured.len(), 2);
        assert_eq!(captured[0], "hello");
        assert_eq!(captured[1], "world");
    }

    #[test]
    fn test_round_trip_vector() {
        let mut engine = Engine::new().unwrap();
        let original = Value::Vector(
            vec![Value::Int(1), Value::Int(2), Value::Int(3)]
                .into_iter()
                .collect(),
        );
        engine.define("data", original.clone());
        let result = engine.eval("data").unwrap();
        assert_eq!(result, original);
    }

    #[test]
    fn test_round_trip_map() {
        let mut engine = Engine::new().unwrap();
        let mut map = hoatzin_core::collections::HashMap::new();
        map.insert(kw("a"), Value::Int(1));
        map.insert(kw("b"), Value::Int(2));
        let original = Value::Map(map);
        engine.define("m", original.clone());
        let result = engine.eval("(get m :a)").unwrap();
        assert_eq!(result, Value::Int(1));
    }

    #[test]
    fn test_round_trip_keyword() {
        let mut engine = Engine::new().unwrap();
        let result = engine.eval(":hello").unwrap();
        assert_eq!(result.as_keyword(), Some("hello"));
    }

    #[test]
    fn test_edn_parse_nested() {
        let val = edn::parse("{:db {:host \"localhost\" :port 5432}}").unwrap();
        let map = val.as_map().unwrap();
        let db = map.get(&kw("db")).unwrap();
        let db_map = db.as_map().unwrap();
        let port = db_map.get(&kw("port")).unwrap();
        assert_eq!(port, &Value::Int(5432));
    }

    #[test]
    fn test_bare_engine() {
        let mut engine = Engine::bare();
        let result = engine.eval("(+ 1 2)").unwrap();
        assert_eq!(result, Value::Int(3));
    }

    #[test]
    fn test_value_accessors() {
        assert!(Value::Nil.is_nil());
        assert!(!Value::Nil.is_truthy());
        assert!(Value::Bool(true).is_truthy());
        assert!(!Value::Bool(false).is_truthy());
        assert!(Value::Int(42).is_truthy());
        assert_eq!(Value::Int(42).as_i64(), Some(42));
        assert_eq!(Value::Float(3.14).as_f64(), Some(3.14));
        assert_eq!(Value::Int(5).as_f64(), Some(5.0));
    }

    #[test]
    fn test_value_get() {
        let vec = Value::Vector(
            vec![Value::Int(10), Value::Int(20), Value::Int(30)]
                .into_iter()
                .collect(),
        );
        assert_eq!(vec.get(&Value::Int(1)), Some(&Value::Int(20)));
        assert_eq!(vec.get(&Value::Int(5)), None);
    }
}
