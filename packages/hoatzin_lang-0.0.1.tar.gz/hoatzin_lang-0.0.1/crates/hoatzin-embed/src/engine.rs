use std::rc::Rc;

use hoatzin_core::vm::{
    AgentJournal, CompilationUnit, DocEntry, HandlerAction, Runtime, VMError, VMValue,
};
use hoatzin_core::Spur;

use crate::error::Error;
use crate::{AgentResult, HandlerResult, Value};

/// High-level embedding engine wrapping a Hoatzin runtime.
pub struct Engine {
    runtime: Runtime,
}

impl Engine {
    /// Create a new engine with stdlib loaded but no effect handlers installed.
    pub fn new() -> Result<Self, Error> {
        let runtime = Runtime::with_stdlib()?;
        Ok(Engine { runtime })
    }

    /// Create a new engine with stdlib and default console/random handlers.
    pub fn with_default_handlers() -> Result<Self, Error> {
        let mut engine = Self::new()?;
        engine.install_default_handlers()?;
        Ok(engine)
    }

    /// Create a bare engine with no stdlib loaded.
    pub fn bare() -> Self {
        Engine {
            runtime: Runtime::new(),
        }
    }

    /// Evaluate source code, returning the result.
    pub fn eval(&mut self, src: &str) -> Result<Value, Error> {
        let vm_val = self.runtime.eval_str(src)?;
        Ok(Value::from_vm(self.runtime.vm(), vm_val))
    }

    /// Evaluate source code with a named source for error reporting.
    pub fn eval_with_source(&mut self, src: &str, source_name: &str) -> Result<Value, Error> {
        let source_id = self.runtime.vm_mut().interner_mut().get_or_intern(source_name);
        let vm_val = self.runtime.eval_str_with_source(src, source_id)?;
        Ok(Value::from_vm(self.runtime.vm(), vm_val))
    }

    /// Define a global value in the runtime.
    pub fn define(&mut self, name: &str, val: Value) {
        let vm_val = val.to_vm(self.runtime.vm_mut());
        self.runtime.define(name, vm_val);
    }

    /// Define a host callback function callable from Hoatzin code.
    pub fn define_fn(
        &mut self,
        name: &str,
        func: impl Fn(Vec<Value>) -> Result<Value, Error> + 'static,
    ) {
        let func = Rc::new(func);
        #[allow(clippy::type_complexity)]
        let wrapper: Rc<dyn Fn(&mut hoatzin_core::vm::VM, &[VMValue]) -> Result<VMValue, VMError>> =
            Rc::new(move |vm: &mut hoatzin_core::vm::VM, args: &[VMValue]| {
                let embed_args: Vec<Value> = args.iter().map(|a| Value::from_vm(vm, *a)).collect();
                match func(embed_args) {
                    Ok(result) => Ok(result.to_vm(vm)),
                    Err(e) => Err(VMError::ValueError(e.to_string())),
                }
            });
        self.runtime.define_fn(name, wrapper);
    }

    /// Register a native effect handler by effect name.
    pub fn register_handler(
        &mut self,
        effect_name: &str,
        handler: impl Fn(&str, Vec<Value>) -> Result<HandlerResult, Error> + 'static,
    ) -> Result<(), Error> {
        let handler = Rc::new(handler);
        let native_handler: hoatzin_core::vm::NativeHandler = Rc::new(
            move |vm: &mut hoatzin_core::vm::VM, op: Spur, args: Vec<VMValue>| {
                let op_str = vm.interner().resolve(&op).to_string();
                let embed_args: Vec<Value> = args.iter().map(|a| Value::from_vm(vm, *a)).collect();
                match handler(&op_str, embed_args) {
                    Ok(HandlerResult::Resume(val)) => {
                        Ok(HandlerAction::Resume(val.to_vm(vm)))
                    }
                    Ok(HandlerResult::Abort(val)) => {
                        Ok(HandlerAction::Abort(val.to_vm(vm)))
                    }
                    Err(e) => Err(VMError::ValueError(e.to_string())),
                }
            },
        );
        self.runtime
            .register_native_handler_by_name(effect_name, native_handler)
            .map_err(|_| Error::EffectNotFound(effect_name.to_string()))
    }

    /// Register a native effect handler by EffectId.
    pub fn register_handler_by_id(
        &mut self,
        effect_id: hoatzin_core::vm::EffectId,
        handler: impl Fn(&str, Vec<Value>) -> Result<HandlerResult, Error> + 'static,
    ) {
        let handler = Rc::new(handler);
        let native_handler: hoatzin_core::vm::NativeHandler = Rc::new(
            move |vm: &mut hoatzin_core::vm::VM, op: Spur, args: Vec<VMValue>| {
                let op_str = vm.interner().resolve(&op).to_string();
                let embed_args: Vec<Value> = args.iter().map(|a| Value::from_vm(vm, *a)).collect();
                match handler(&op_str, embed_args) {
                    Ok(HandlerResult::Resume(val)) => {
                        Ok(HandlerAction::Resume(val.to_vm(vm)))
                    }
                    Ok(HandlerResult::Abort(val)) => {
                        Ok(HandlerAction::Abort(val.to_vm(vm)))
                    }
                    Err(e) => Err(VMError::ValueError(e.to_string())),
                }
            },
        );
        self.runtime
            .register_native_handler(effect_id, native_handler);
    }

    /// Get the EffectId for a named effect.
    pub fn effect_id(&self, name: &str) -> Option<hoatzin_core::vm::EffectId> {
        self.runtime.get_effect_id(name)
    }

    /// Compile source code without executing it.
    pub fn compile(&mut self, src: &str) -> Result<CompilationUnit, Error> {
        Ok(self.runtime.compile_str(src)?)
    }

    /// Iterate over all accumulated documentation entries.
    pub fn docs(&self) -> impl Iterator<Item = (&str, &DocEntry)> {
        self.runtime
            .docs()
            .iter()
            .map(|(spur, entry)| (self.runtime.interner().resolve(spur), entry))
    }

    /// Evaluate source code in agent mode.
    pub fn eval_agent(
        &mut self,
        src: &str,
        journal: &mut AgentJournal,
    ) -> Result<Vec<AgentResult>, Error> {
        let source_id = self
            .runtime
            .vm_mut()
            .interner_mut()
            .get_or_intern("<agent>");
        let results = self.runtime.eval_str_agent(src, source_id, journal)?;
        Ok(results
            .into_iter()
            .map(|r| AgentResult {
                value: Value::from_vm(self.runtime.vm(), r.value),
                lineage_message: r.lineage_message,
            })
            .collect())
    }

    /// Evaluate source code in agent mode, returning plain-text output
    /// matching the CLI REPL format: each result value on its own line,
    /// followed by a lineage message if one was recorded.
    pub fn eval_agent_text(
        &mut self,
        src: &str,
        journal: &mut AgentJournal,
    ) -> Result<String, Error> {
        let results = self.eval_agent(src, journal)?;
        let mut out = String::new();
        for r in &results {
            out.push_str(&r.value.to_string());
            out.push('\n');
            if let Some(ref msg) = r.lineage_message {
                out.push_str(msg);
                out.push('\n');
            }
        }
        // Trim trailing newline for cleaner single-expression output
        if out.ends_with('\n') {
            out.pop();
        }
        Ok(out)
    }

    /// Escape hatch: access the underlying Runtime directly.
    pub fn runtime(&mut self) -> &mut Runtime {
        &mut self.runtime
    }

    // --- Default handlers ---

    fn install_default_handlers(&mut self) -> Result<(), Error> {
        // Console handler
        let console_handler: hoatzin_core::vm::NativeHandler = Rc::new(
            |vm: &mut hoatzin_core::vm::VM, op: Spur, args: Vec<VMValue>| {
                let op_str = vm.interner().resolve(&op);
                match op_str {
                    "print" => {
                        if let Some(arg) = args.first() {
                            let s = hoatzin_core::vm::value_to_pr_string(vm, *arg);
                            let s = s
                                .strip_prefix('"')
                                .and_then(|s| s.strip_suffix('"'))
                                .unwrap_or(&s);
                            print!("{}", s);
                        }
                        Ok(HandlerAction::Resume(VMValue::Nil))
                    }
                    "println" => {
                        if let Some(arg) = args.first() {
                            let s = hoatzin_core::vm::value_to_pr_string(vm, *arg);
                            let s = s
                                .strip_prefix('"')
                                .and_then(|s| s.strip_suffix('"'))
                                .unwrap_or(&s);
                            println!("{}", s);
                        } else {
                            println!();
                        }
                        Ok(HandlerAction::Resume(VMValue::Nil))
                    }
                    "read-line" => {
                        use std::io::BufRead;
                        let stdin = std::io::stdin();
                        let line = stdin
                            .lock()
                            .lines()
                            .next()
                            .unwrap_or(Ok(String::new()))
                            .unwrap_or_default();
                        let key = vm.alloc_string(line);
                        Ok(HandlerAction::Resume(key))
                    }
                    _ => Ok(HandlerAction::Resume(VMValue::Nil)),
                }
            },
        );
        self.runtime
            .register_native_handler_by_name("console", console_handler)
            .map_err(|_| Error::EffectNotFound("console".into()))?;

        // Random handler
        let random_handler: hoatzin_core::vm::NativeHandler = Rc::new(
            |_vm: &mut hoatzin_core::vm::VM, op: Spur, args: Vec<VMValue>| {
                use rand::Rng;
                let op_str = _vm.interner().resolve(&op);
                match op_str {
                    "rand" => {
                        let val: f64 = rand::random();
                        Ok(HandlerAction::Resume(VMValue::Float(val)))
                    }
                    "rand-int" => {
                        if let Some(VMValue::Int(n)) = args.first() {
                            let val = rand::thread_rng().gen_range(0..*n);
                            Ok(HandlerAction::Resume(VMValue::Int(val)))
                        } else {
                            Err(VMError::TypeError("rand-int expects an integer argument"))
                        }
                    }
                    _ => Ok(HandlerAction::Resume(VMValue::Nil)),
                }
            },
        );
        self.runtime
            .register_native_handler_by_name("random", random_handler)
            .map_err(|_| Error::EffectNotFound("random".into()))?;

        Ok(())
    }
}
