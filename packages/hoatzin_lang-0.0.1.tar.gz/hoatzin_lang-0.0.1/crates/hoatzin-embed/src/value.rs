use std::hash::{Hash, Hasher};
use std::rc::Rc;

use hoatzin_core::collections::{HashMap, HashSet, Vector};

#[derive(Debug, Clone)]
pub enum Value {
    Nil,
    Bool(bool),
    Int(i64),
    Float(f64),
    Ratio { numer: i64, denom: i64 },
    String(Rc<str>),
    /// Stored without leading colon
    Keyword(Rc<str>),
    Symbol(Rc<str>),
    List(Vector<Value>),
    Vector(Vector<Value>),
    Map(HashMap<Value, Value>),
    Set(HashSet<Value>),
    Regex(Rc<regex::Regex>),
    /// Non-convertible VM value (closures, continuations, etc.)
    Opaque(String),
}

impl PartialEq for Value {
    fn eq(&self, other: &Self) -> bool {
        match (self, other) {
            (Value::Nil, Value::Nil) => true,
            (Value::Bool(a), Value::Bool(b)) => a == b,
            (Value::Int(a), Value::Int(b)) => a == b,
            (Value::Float(a), Value::Float(b)) => a.to_bits() == b.to_bits(),
            (Value::Ratio { numer: an, denom: ad }, Value::Ratio { numer: bn, denom: bd }) => {
                an == bn && ad == bd
            }
            (Value::String(a), Value::String(b)) => a == b,
            (Value::Keyword(a), Value::Keyword(b)) => a == b,
            (Value::Symbol(a), Value::Symbol(b)) => a == b,
            (Value::List(a), Value::List(b)) => a == b,
            (Value::Vector(a), Value::Vector(b)) => a == b,
            (Value::Map(a), Value::Map(b)) => a == b,
            (Value::Set(a), Value::Set(b)) => a == b,
            (Value::Regex(a), Value::Regex(b)) => a.as_str() == b.as_str(),
            (Value::Opaque(a), Value::Opaque(b)) => a == b,
            _ => false,
        }
    }
}

impl Eq for Value {}

impl Hash for Value {
    fn hash<H: Hasher>(&self, state: &mut H) {
        std::mem::discriminant(self).hash(state);
        match self {
            Value::Nil => {}
            Value::Bool(b) => b.hash(state),
            Value::Int(i) => i.hash(state),
            Value::Float(f) => f.to_bits().hash(state),
            Value::Ratio { numer, denom } => {
                numer.hash(state);
                denom.hash(state);
            }
            Value::String(s) => s.hash(state),
            Value::Keyword(k) => k.hash(state),
            Value::Symbol(s) => s.hash(state),
            Value::List(v) | Value::Vector(v) => {
                for item in v.iter() {
                    item.hash(state);
                }
            }
            Value::Map(m) => {
                let mut h = 0u64;
                for (k, v) in m.iter() {
                    let mut hasher = std::collections::hash_map::DefaultHasher::new();
                    k.hash(&mut hasher);
                    v.hash(&mut hasher);
                    h ^= hasher.finish();
                }
                h.hash(state);
            }
            Value::Set(s) => {
                let mut h = 0u64;
                for item in s.iter() {
                    let mut hasher = std::collections::hash_map::DefaultHasher::new();
                    item.hash(&mut hasher);
                    h ^= hasher.finish();
                }
                h.hash(state);
            }
            Value::Regex(r) => r.as_str().hash(state),
            Value::Opaque(s) => s.hash(state),
        }
    }
}

// --- Accessor methods ---

impl Value {
    pub fn is_nil(&self) -> bool {
        matches!(self, Value::Nil)
    }

    pub fn is_truthy(&self) -> bool {
        !matches!(self, Value::Nil | Value::Bool(false))
    }

    pub fn as_bool(&self) -> Option<bool> {
        match self {
            Value::Bool(b) => Some(*b),
            _ => None,
        }
    }

    pub fn as_i64(&self) -> Option<i64> {
        match self {
            Value::Int(i) => Some(*i),
            _ => None,
        }
    }

    pub fn as_f64(&self) -> Option<f64> {
        match self {
            Value::Float(f) => Some(*f),
            Value::Int(i) => Some(*i as f64),
            Value::Ratio { numer, denom } => Some(*numer as f64 / *denom as f64),
            _ => None,
        }
    }

    pub fn as_str(&self) -> Option<&str> {
        match self {
            Value::String(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_keyword(&self) -> Option<&str> {
        match self {
            Value::Keyword(k) => Some(k),
            _ => None,
        }
    }

    pub fn as_symbol(&self) -> Option<&str> {
        match self {
            Value::Symbol(s) => Some(s),
            _ => None,
        }
    }

    pub fn as_vec(&self) -> Option<&Vector<Value>> {
        match self {
            Value::Vector(v) | Value::List(v) => Some(v),
            _ => None,
        }
    }

    pub fn as_map(&self) -> Option<&HashMap<Value, Value>> {
        match self {
            Value::Map(m) => Some(m),
            _ => None,
        }
    }

    /// Look up by integer index or keyword key.
    pub fn get(&self, key: &Value) -> Option<&Value> {
        match (self, key) {
            (Value::Vector(v) | Value::List(v), Value::Int(i)) => {
                if *i >= 0 {
                    v.get(*i as usize)
                } else {
                    None
                }
            }
            (Value::Map(m), _) => m.get(key),
            _ => None,
        }
    }
}

impl std::fmt::Display for Value {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Value::Nil => write!(f, "nil"),
            Value::Bool(b) => write!(f, "{}", b),
            Value::Int(i) => write!(f, "{}", i),
            Value::Float(v) => {
                if v.fract() == 0.0 {
                    write!(f, "{}.0", v)
                } else {
                    write!(f, "{}", v)
                }
            }
            Value::Ratio { numer, denom } => write!(f, "{}/{}", numer, denom),
            Value::String(s) => write!(f, "\"{}\"", s),
            Value::Keyword(k) => write!(f, ":{}", k),
            Value::Symbol(s) => write!(f, "{}", s),
            Value::List(items) => {
                write!(f, "(")?;
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        write!(f, " ")?;
                    }
                    write!(f, "{}", item)?;
                }
                write!(f, ")")
            }
            Value::Vector(items) => {
                write!(f, "[")?;
                for (i, item) in items.iter().enumerate() {
                    if i > 0 {
                        write!(f, " ")?;
                    }
                    write!(f, "{}", item)?;
                }
                write!(f, "]")
            }
            Value::Map(m) => {
                write!(f, "{{")?;
                for (i, (k, v)) in m.iter().enumerate() {
                    if i > 0 {
                        write!(f, ", ")?;
                    }
                    write!(f, "{} {}", k, v)?;
                }
                write!(f, "}}")
            }
            Value::Set(s) => {
                write!(f, "#{{")?;
                for (i, item) in s.iter().enumerate() {
                    if i > 0 {
                        write!(f, " ")?;
                    }
                    write!(f, "{}", item)?;
                }
                write!(f, "}}")
            }
            Value::Regex(r) => write!(f, "#\"{}\"", r.as_str()),
            Value::Opaque(s) => write!(f, "#<{}>", s),
        }
    }
}

/// Shorthand for creating a keyword Value.
pub fn kw(name: &str) -> Value {
    Value::Keyword(Rc::from(name))
}
