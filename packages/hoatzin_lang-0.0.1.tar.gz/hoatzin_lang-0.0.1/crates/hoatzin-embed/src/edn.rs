use hoatzin_core::Reader;

use crate::error::Error;
use crate::Value;

/// Parse an EDN string, returning the last value.
pub fn parse(src: &str) -> Result<Value, Error> {
    let mut reader = Reader::new(src);
    let forms = reader.read_all().map_err(|e| Error::Edn(e.to_string()))?;
    match forms.last() {
        Some(v) => Ok(Value::from_ast(v)),
        None => Ok(Value::Nil),
    }
}

/// Parse an EDN string, returning all values.
pub fn parse_all(src: &str) -> Result<Vec<Value>, Error> {
    let mut reader = Reader::new(src);
    let forms = reader.read_all().map_err(|e| Error::Edn(e.to_string()))?;
    Ok(forms.iter().map(Value::from_ast).collect())
}
