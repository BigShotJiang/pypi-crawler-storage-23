"""Agent-mode REPL for Hoatzin, built on the Python binding.

Usage:
    cd crates/hoatzin-embed
    maturin develop
    python examples/agent_repl.py
"""

import sys
import hoatzin


def main():
    engine = hoatzin.Engine()
    journal = hoatzin.AgentJournal()

    print("Hoatzin agent REPL (Ctrl-D to exit)")
    print()

    while True:
        try:
            src = input("hoatzin> ")
        except (EOFError, KeyboardInterrupt):
            print()
            break

        if not src.strip():
            continue

        try:
            result = engine.eval_text(src, journal)
            if result:
                print(result)
        except hoatzin.CompileError as e:
            print(f"compile error: {e}", file=sys.stderr)
        except hoatzin.EvalError as e:
            print(f"eval error: {e}", file=sys.stderr)
        except hoatzin.HoatzinError as e:
            print(f"error: {e}", file=sys.stderr)


if __name__ == "__main__":
    main()
