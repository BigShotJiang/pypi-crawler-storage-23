import argparse
import mcp_hn.hn as hn
from mcp.server.models import InitializationOptions
import mcp.types as types
from mcp.server import NotificationOptions, Server
import mcp.server.stdio
import json

DEFAULT_NUM_STORIES = 10
DEFAULT_TIMEOUT = 5
DEFAULT_MAX_RESPONSE_WORDS = 10000

server = Server("hn")
_request_timeout = DEFAULT_TIMEOUT
_max_response_words = DEFAULT_MAX_RESPONSE_WORDS


def _trim_text_by_words(text: str, max_words: int) -> str:
    if max_words <= 0:
        return text
    words = text.split()
    total_words = len(words)
    if total_words <= max_words:
        return text
    trimmed_text = " ".join(words[:max_words])
    return (
        f"{trimmed_text}\n\n"
        f"[output trimmed: showing first {max_words} words out of {total_words}. "
        "Increase --max-response-words to return more.]"
    )


def _to_text_content(payload: object) -> list[types.TextContent]:
    text = json.dumps(payload, indent=2)
    text = _trim_text_by_words(text, _max_response_words)
    return [types.TextContent(type="text", text=text)]

@server.list_tools()
async def handle_list_tools() -> list[types.Tool]:
    """
    List available tools.
    Each tool specifies its arguments using JSON Schema validation.
    """
    return [
        types.Tool(
            name="get_stories",
            description="Get stories from Hacker News. The options are `top`, `new`, `ask_hn`, `show_hn` for types of stories. This doesn't include the comments. Use `get_story_info` to get the comments.",
            inputSchema={
                "type": "object",
                "properties": {
                    "story_type": {
                        "type": "string",
                        "description": "Type of stories to get, one of: `top`, `new`, `ask_hn`, `show_hn`",
                    },
                    "num_stories": {
                        "type": "integer",
                        "description": "Number of stories to get",
                    },
                },
            },
        ),
        types.Tool(
            name="get_user_info",
            description="Get user info from Hacker News, including the stories they've submitted",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_name": {
                        "type": "string",
                        "description": "Username of the user",
                    },
                    "num_stories": {
                        "type": "integer",
                        "description": f"Number of stories to get, defaults to {DEFAULT_NUM_STORIES}",
                    },
                },
                "required": ["user_name"],
            },
        ),
        types.Tool(
            name="search_stories",
            description="Search stories from Hacker News. It is generally recommended to use simpler queries to get a broader set of results (less than 5 words). Very targetted queries may not return any results.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "search_by_date": {
                        "type": "boolean",
                        "description": "Search by date, defaults to False. If this is False, then we search by relevance, then points, then number of comments.",
                    },
                    "num_results": {
                        "type": "integer",
                        "description": f"Number of results to get, defaults to {DEFAULT_NUM_STORIES}",
                    },
                },
                "required": ["query"],
            },
        ),
        types.Tool(
            name="search_hn",
            description="Generic Hacker News search with advanced Algolia parameters, pagination and metadata.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Optional search query",
                    },
                    "tags": {
                        "type": "string",
                        "description": "Optional tags expression, e.g. story, comment, front_page, author_pg,(story,poll)",
                    },
                    "search_by_date": {
                        "type": "boolean",
                        "description": "Sort by date when true, otherwise relevance ranking",
                    },
                    "page": {
                        "type": "integer",
                        "description": "Results page index (0-based), defaults to 0",
                    },
                    "hits_per_page": {
                        "type": "integer",
                        "description": f"Results per page, defaults to {DEFAULT_NUM_STORIES}",
                    },
                    "numeric_filters": {
                        "type": "string",
                        "description": "Algolia numericFilters, e.g. created_at_i>1700000000,points>100",
                    },
                    "restrict_searchable_attributes": {
                        "type": "string",
                        "description": "Restrict attributes, e.g. url or title",
                    },
                    "filters": {
                        "type": "string",
                        "description": "Algolia filters expression",
                    },
                },
            },
        ),
        types.Tool(
            name="search_comments",
            description="Search comments globally or within a specific story, with pagination and metadata.",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Optional search query",
                    },
                    "story_id": {
                        "type": "integer",
                        "description": "Optional story id to constrain comments to one story",
                    },
                    "search_by_date": {
                        "type": "boolean",
                        "description": "Sort by date when true (default true for comment search)",
                    },
                    "page": {
                        "type": "integer",
                        "description": "Results page index (0-based), defaults to 0",
                    },
                    "hits_per_page": {
                        "type": "integer",
                        "description": f"Results per page, defaults to {DEFAULT_NUM_STORIES}",
                    },
                    "numeric_filters": {
                        "type": "string",
                        "description": "Algolia numericFilters, e.g. created_at_i>1700000000",
                    },
                    "filters": {
                        "type": "string",
                        "description": "Algolia filters expression",
                    },
                },
            },
        ),
        types.Tool(
            name="get_story_info",
            description="Get detailed story info from Hacker News, including the comments",
            inputSchema={
                "type": "object",
                "properties": {
                    "story_id": {
                        "type": "integer",
                        "description": "Story ID",
                    },
                    "comment_depth": {
                        "type": "integer",
                        "description": "How many nested levels of comments to include, defaults to 2",
                    },
                    "num_comments": {
                        "type": "integer",
                        "description": "Max number of comments to include per level, defaults to 10",
                    },
                },
            },
        ),
        types.Tool(
            name="get_item",
            description="Get a raw item by id (story/comment/poll/job) from Hacker News.",
            inputSchema={
                "type": "object",
                "properties": {
                    "item_id": {
                        "type": "integer",
                        "description": "Item ID",
                    },
                },
                "required": ["item_id"],
            },
        ),
        types.Tool(
            name="get_user_activity",
            description="Search user activity by author across item types with pagination and metadata.",
            inputSchema={
                "type": "object",
                "properties": {
                    "user_name": {
                        "type": "string",
                        "description": "Username of the user",
                    },
                    "item_types": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "Optional subset of item types: story, comment, poll, job",
                    },
                    "search_by_date": {
                        "type": "boolean",
                        "description": "Sort by date when true, defaults to true",
                    },
                    "page": {
                        "type": "integer",
                        "description": "Results page index (0-based), defaults to 0",
                    },
                    "num_results": {
                        "type": "integer",
                        "description": f"Results per page, defaults to {DEFAULT_NUM_STORIES}",
                    },
                },
                "required": ["user_name"],
            },
        ),
    ]

@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[types.TextContent | types.ImageContent | types.EmbeddedResource]:
    """
    Handle tool execution requests.
    """
    global _request_timeout
    arguments = arguments or {}
    if name == "get_stories":
        story_type = arguments.get("story_type", "top")
        num_stories = arguments.get("num_stories", DEFAULT_NUM_STORIES)
        output = hn.get_stories(story_type, num_stories, timeout=_request_timeout)
        return _to_text_content(output)
    elif name == "search_stories":
        query = arguments.get("query")
        search_by_date = arguments.get("search_by_date", False)
        num_results = arguments.get("num_results", DEFAULT_NUM_STORIES)
        output = hn.search_stories(query, num_results, search_by_date, timeout=_request_timeout)
        return _to_text_content(output)
    elif name == "search_hn":
        output = hn.search_hn(
            query=arguments.get("query"),
            tags=arguments.get("tags"),
            search_by_date=arguments.get("search_by_date", False),
            page=arguments.get("page", 0),
            hits_per_page=arguments.get("hits_per_page", DEFAULT_NUM_STORIES),
            numeric_filters=arguments.get("numeric_filters"),
            restrict_searchable_attributes=arguments.get("restrict_searchable_attributes"),
            filters=arguments.get("filters"),
            timeout=_request_timeout,
        )
        return _to_text_content(output)
    elif name == "search_comments":
        output = hn.search_comments(
            query=arguments.get("query"),
            story_id=arguments.get("story_id"),
            search_by_date=arguments.get("search_by_date", True),
            page=arguments.get("page", 0),
            hits_per_page=arguments.get("hits_per_page", DEFAULT_NUM_STORIES),
            numeric_filters=arguments.get("numeric_filters"),
            filters=arguments.get("filters"),
            timeout=_request_timeout,
        )
        return _to_text_content(output)
    elif name == "get_story_info":
        story_id = int(arguments.get("story_id"))
        output = hn.get_story_info(
            story_id,
            comment_depth=arguments.get("comment_depth", 2),
            num_comments=arguments.get("num_comments", 10),
            timeout=_request_timeout,
        )
        return _to_text_content(output)
    elif name == "get_item":
        item_id = int(arguments.get("item_id"))
        output = hn.get_item(item_id, timeout=_request_timeout)
        return _to_text_content(output)
    elif name == "get_user_info":
        user_name = arguments.get("user_name")
        num_stories = arguments.get("num_stories", DEFAULT_NUM_STORIES)
        output = hn.get_user_info(user_name, num_stories, timeout=_request_timeout)
        return _to_text_content(output)
    elif name == "get_user_activity":
        output = hn.get_user_activity(
            user_name=arguments.get("user_name"),
            item_types=arguments.get("item_types"),
            search_by_date=arguments.get("search_by_date", True),
            page=arguments.get("page", 0),
            num_results=arguments.get("num_results", DEFAULT_NUM_STORIES),
            timeout=_request_timeout,
        )
        return _to_text_content(output)
    else:
        raise ValueError(f"Unknown tool: {name}")

async def main():
    global _request_timeout, _max_response_words
    parser = argparse.ArgumentParser(description="Hacker News MCP Server")
    parser.add_argument(
        "-t",
        "--max-time",
        type=float,
        default=DEFAULT_TIMEOUT,
        help=f"Maximum time allowed for requests in seconds (default: {DEFAULT_TIMEOUT})",
    )
    parser.add_argument(
        "--max-response-words",
        type=int,
        default=DEFAULT_MAX_RESPONSE_WORDS,
        help=(
            "Maximum number of words to return per MCP tool response "
            f"(default: {DEFAULT_MAX_RESPONSE_WORDS}). Use 0 for no trimming."
        ),
    )
    args = parser.parse_args()
    _request_timeout = args.max_time
    _max_response_words = args.max_response_words

    # Run the server using stdin/stdout streams
    async with mcp.server.stdio.stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="hn",
                server_version="0.1.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )
