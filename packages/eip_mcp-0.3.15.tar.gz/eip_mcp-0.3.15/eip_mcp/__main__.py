"""Allow running with: python -m eip_mcp"""

from eip_mcp.server import main

main()
