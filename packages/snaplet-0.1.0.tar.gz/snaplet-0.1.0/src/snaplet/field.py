from typing import Optional


class Field:
    def __init__(self, alias: Optional[str] = None):
        self.alias = alias
