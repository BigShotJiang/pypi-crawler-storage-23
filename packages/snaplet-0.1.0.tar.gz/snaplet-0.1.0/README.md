# Snaplet
Faster JSON Mapping.