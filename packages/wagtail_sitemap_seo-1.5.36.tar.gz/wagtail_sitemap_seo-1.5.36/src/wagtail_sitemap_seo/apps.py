# -*- coding: utf-8 -*-
from django.apps import AppConfig


class SitemapSeoConfig(AppConfig):
    name = 'wagtail_sitemap_seo'
