default_app_config = "wagtail_sitemap_seo.apps.SitemapSeoConfig"
