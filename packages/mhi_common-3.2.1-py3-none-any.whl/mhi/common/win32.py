"""
Windows-specific functionality

- Registry reading
- Process lookup
- TCP/IP Port availability
"""

#===============================================================================
# Imports
#===============================================================================

import ctypes
import ipaddress
import logging
import os
import socket
import struct
import subprocess

from pathlib import Path
from typing import Any, Dict, Iterator, List, Optional, Set, Sequence, Tuple

# Pywin32
from winreg import EnumKey as _EnumKey
from winreg import OpenKey as _OpenKey, CloseKey as _CloseKey
from winreg import QueryValueEx as _QueryValueEx
from winreg import HKEY_LOCAL_MACHINE as _HKLM, KEY_READ as _KEY_READ
from winreg import KEY_WOW64_32KEY as _KEY32, KEY_WOW64_64KEY as _KEY64
from winreg import REG_SZ as _REG_SZ
from winreg import REG_EXPAND_SZ as _REG_EXPAND_SZ

import win32con
import win32com.client

from .types import AddressPortPid



#===============================================================================
# Logging
#===============================================================================

_LOG = logging.getLogger(__name__)


#===============================================================================
# Pywin32, socket, related window constants, structures
#===============================================================================

_AF_INET = 2
_AF_INET6 = int(socket.AF_INET6)
_UBYTE = ctypes.c_ubyte
_DWORD = ctypes.c_ulong
_ERROR_NO_MORE_ITEMS = 259
_MIB_TCP_STATE_LISTEN = 2
_NULL = ""
_TCP_TABLE_BASIC_ALL = 2
_TCP_TABLE_OWNER_PID_LISTENER = 3

# pylint: disable=too-few-public-methods, missing-class-docstring, invalid-name
# pylint: disable=missing-function-docstring

class MIB_TCPROW_LH(ctypes.Structure):
    _fields_ = [('dwState', _DWORD),
                ('dwLocalAddr', _DWORD),
                ('dwLocalPort', _DWORD),
                ('dwRemoteAddr', _DWORD),
                ('dwRemotePort', _DWORD)]


class MIB_TCPROW_OWNER_PID(ctypes.Structure):
    _fields_ = [('dwState', _DWORD),
                ('dwLocalAddr', _DWORD),
                ('dwLocalPort', _DWORD),
                ('dwRemoteAddr', _DWORD),
                ('dwRemotePort', _DWORD),
                ('dwOwningPid', _DWORD)]

    @property
    def local_address(self) -> str:
        return socket.inet_ntoa(struct.pack('L', self.dwLocalAddr))

    @property
    def local_port(self) -> int:
        return socket.ntohs(self.dwLocalPort)

class MIB_TCP6ROW_OWNER_PID(ctypes.Structure):
    _fields_ = [('ucLocalAddr', _UBYTE * 16),
                ('dwLocalScopeId', _DWORD),
                ('dwLocalPort', _DWORD),
                ('ucRemoteAddr', _UBYTE * 16),
                ('dwRemoteScopeId', _DWORD),
                ('dwRemotePort', _DWORD),
                ('dwState', _DWORD),
                ('dwOwningPid', _DWORD)]

    @property
    def local_address(self) -> str:
        return str(ipaddress.ip_address(bytes(self.ucLocalAddr)))

    @property
    def local_port(self) -> int:
        return socket.ntohs(self.dwLocalPort)


# pylint: enable=missing-function-docstring
# pylint: enable=too-few-public-methods, missing-class-docstring, invalid-name

#===============================================================================
# WMI Query
#===============================================================================

def _wmi():
    if not hasattr(_wmi, '_cache'):
        obj = win32com.client.GetObject('winmgmts:')
        t_i = obj._oleobj_.GetTypeInfo().GetContainingTypeLib()[0].GetTypeComp() # pylint: disable=protected-access
        flags = (t_i.Bind('wbemFlagReturnImmediately')[1].value |
                 t_i.Bind('wbemFlagForwardOnly')[1].value)
        _wmi._cache = (obj, flags)            # pylint: disable=protected-access

    return _wmi._cache                        # pylint: disable=protected-access

def _query(*props: str, where: Optional[str] = None, kind: type = tuple):

    fields = ', '.join(props)

    query = f"SELECT {fields} FROM Win32_Process"
    if where:
        query += " WHERE " + where
    _LOG.debug("WMI.query: %s", query)

    wmi, flags = _wmi()
    result = wmi.ExecQuery(query, iFlags=flags)

    return [kind(getattr(row, prop) for prop in props) for row in result]


#===============================================================================
# Find processes
#===============================================================================

def _process_pids(names: Sequence[str]) -> List[Tuple[str, int]]:

    """
    Return the process id's of any process with the given executable names.

    Application names may include the ``%`` wildcard.  For example,
    the following query might find both ``SkypeApp.exe`` and
    ``SkypeBackgroundHost.exe``::

        process_ids('skype%.exe')

    Since applications may terminate and can be started at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        *names (str): application filename patterns, without any path.

    Returns:
        List[tuple]: A list of process name & process id pairs
    """

    where = None
    if names:
        where = " OR ".join(f"Name LIKE {name!r}" for name in names)

    return _query('Name', 'ProcessId', where=where)


#===============================================================================
# Listening Ports
#===============================================================================

def _tcp_ports_in_use() -> Set[int]:
    """
    Find all TCP ports in use

    Returns:
        Set[int]: Set of all ports in use by the TCP protocol
    """

    ip_api = ctypes.windll.iphlpapi

    dw_size = _DWORD(0)
    b_order = 0        # Unordered

    # Get TcpTable dwSize value
    ip_api.GetExtendedTcpTable(_NULL, ctypes.byref(dw_size), b_order,
                               _AF_INET, _TCP_TABLE_BASIC_ALL, 0)

    # Divide the size of buffer by the size of each row to get the
    # approximate number of rows in the table.  If the header is large,
    # or there is a lot of padding, we might end up allocating an extra
    # row or two, but it is OK to have extra.
    max_rows = dw_size.value // ctypes.sizeof(MIB_TCPROW_LH)

    # pylint: disable=too-few-public-methods, missing-class-docstring, invalid-name, attribute-defined-outside-init

    class MIB_TCPTABLE(ctypes.Structure):
        _fields_ = [('dwNumEntries', _DWORD),
                    ('table', MIB_TCPROW_LH * max_rows)]

    tcp_table = MIB_TCPTABLE()
    tcp_table.dwNumEntries = 0

    # pylint: enable=too-few-public-methods, missing-class-docstring, invalid-name, attribute-defined-outside-init

    error = ip_api.GetExtendedTcpTable(ctypes.byref(tcp_table),
                                       ctypes.byref(dw_size), b_order, _AF_INET,
                                       _TCP_TABLE_BASIC_ALL, 0)

    if error:
        ports = set()
        _LOG.warning("Error getting TCP Table: %s", error)

    else:
        ports = set(socket.ntohs(row.dwLocalPort)
                    for row in tcp_table.table[:tcp_table.dwNumEntries])

    return ports


def _listeners_by_pid(pid: Tuple[int, ...],
                      family: int,
                      row_class: type) -> List[AddressPortPid]:
    # Loosely based on:
    #   "Using the WIN32 IPHelper API (Python Recipe)"
    #   http://code.activestate.com/recipes/392572/

    ip_api = ctypes.windll.iphlpapi

    dw_size = _DWORD(0)
    b_order = 0        # Unordered

    # Get TcpTable dwSize value
    ip_api.GetExtendedTcpTable(_NULL, ctypes.byref(dw_size), b_order,
                               family, _TCP_TABLE_OWNER_PID_LISTENER, 0)

    # Divide the size of buffer by the size of each row to get the
    # approximate number of rows in the table.  If the header is large,
    # or there is a lot of padding, we might end up allocating an extra
    # row or two, but it is OK to have extra.
    max_rows = dw_size.value // ctypes.sizeof(row_class)

    # pylint: disable=too-few-public-methods, missing-class-docstring, invalid-name, attribute-defined-outside-init

    class MIB_TCPTABLE_OWNER_PID(ctypes.Structure):
        _fields_ = [('dwNumEntries', _DWORD),
                    ('table', row_class * max_rows)] # type: ignore

    tcp_table = MIB_TCPTABLE_OWNER_PID()
    tcp_table.dwNumEntries = 0

    # pylint: enable=too-few-public-methods, missing-class-docstring, invalid-name, attribute-defined-outside-init

    error = ip_api.GetExtendedTcpTable(ctypes.byref(tcp_table),
                                       ctypes.byref(dw_size), b_order, family,
                                       _TCP_TABLE_OWNER_PID_LISTENER, 0)

    if error:
        ports = []
        _LOG.warning("Error getting TCP Table: %s", error)

    else:
        ports = [
            AddressPortPid(row.local_address, row.local_port, row.dwOwningPid)
            for row in tcp_table.table[:tcp_table.dwNumEntries]
            if (row.dwState == _MIB_TCP_STATE_LISTEN and
                row.dwOwningPid in pid)]

    return ports


def _listener_ports_by_pid(*pid: int) -> List[AddressPortPid]:
    """
    Find all listener ports opened by processes with the given PIDs.

    Since applications may terminate and can be started at any time,
    as well as open and close ports at any time,
    the returned value is obsolete immediately upon being returned.

    Parameters:
        *pid (int): Process ids

    Returns:
        List[tuple]: a list of (addr, port, pid) tuples
    """

    ports = _listeners_by_pid(pid, _AF_INET, MIB_TCPROW_OWNER_PID)
    ports += _listeners_by_pid(pid, _AF_INET6, MIB_TCP6ROW_OWNER_PID)

    return ports


#===============================================================================
# Launch processes
#===============================================================================

def _subkeys(key) -> Iterator[str]:

    i = 0
    while True:
        try:
            yield _EnumKey(key, i) # pylint: disable=possibly-used-before-assignment
            i += 1
        except OSError as ex:
            if ex.winerror == _ERROR_NO_MORE_ITEMS: # type: ignore
                break
            raise


def _app_path(app_name: str) -> Tuple[Dict[str, str],Dict[str, str]]:
    # pylint: disable=possibly-used-before-assignment

    app_paths = []

    company_names = ['Manitoba HVDC Research Centre Inc',
                     'Manitoba Hydro International']

    for access in (_KEY32, _KEY64): # pylint: disable=too-many-nested-blocks
        paths = {}
        for company_name in company_names:
            keyname = rf'SOFTWARE\{company_name}\{app_name}'

            try:
                key = _OpenKey(_HKLM, keyname, 0, access | _KEY_READ)
                for ver in _subkeys(key):
                    subkey = _OpenKey(key, ver)
                    try:
                        app_path = _QueryValueEx(subkey, 'AppPath')
                        if app_path[1] == _REG_SZ:
                            paths[ver] = app_path[0]
                    except FileNotFoundError:
                        pass
                    _CloseKey(subkey)
                _CloseKey(key)
            except FileNotFoundError:
                pass
        app_paths.append(paths)

    return app_paths[0], app_paths[1]


def _exe_path(app_name: str) -> Tuple[Dict[str, str], Dict[str, str]]:

    exe_paths = []

    for app_paths in _app_path(app_name):
        paths = {}

        for version, path in app_paths.items():
            exe = os.path.join(path, app_name + '.exe')
            if os.path.isfile(exe):
                paths[version] = exe
            else:
                for ver in ('Alpha', 'Beta', 'Free', version):
                    exe = os.path.join(path, app_name + ver + '.exe')
                    if os.path.isfile(exe):
                        paths[version] = exe
                        break

        exe_paths.append(paths)

    return exe_paths[0], exe_paths[1]


def _launch(args: Sequence[str], options: Dict[str, Any]):

    _LOG.info("Launching %s", args[0])
    _LOG.info("    Args: %s", args[1:])

    # Ensure application crashes don't result in an Error Dialog
    # that needs to be dismissed manually
    ctypes.windll.kernel32.SetErrorMode(win32con.SEM_NOGPFAULTERRORBOX)

    # Start Up Info for the child process
    sui = subprocess.STARTUPINFO()
    minimize = options.get('minimize', None)
    minimize = options.get('launch-minimized', minimize) # Backwards compat
    if minimize is not None:
        if minimize:
            sui.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            sui.wShowWindow = win32con.SW_SHOWMINNOACTIVE

    # Launch the subprocess
    proc = subprocess.Popen(args, close_fds=True, startupinfo=sui) # pylint: disable=consider-using-with
    _LOG.debug("Process ID = %d", proc.pid)

    return proc

#===============================================================================
# Shell Folders
#===============================================================================

def _shell_folder(name: str) -> Path:
    """
    Return the path to a special Windows Shell Folder

    Parameters:
        name (str): The shell folder name

    Returns:
        str: The path, read from the Windows registry
    """

    # pylint: disable=possibly-used-before-assignment

    folders = r"SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders"
    with _OpenKey(_HKLM, folders) as key:
        try:
            value, value_type = _QueryValueEx(key, name)
        except WindowsError:
            raise KeyError(f"No such Shell Folder {name!r}") from None

    if value_type == _REG_EXPAND_SZ:
        value = os.path.expandvars(value)
    elif value_type != _REG_SZ:
        raise ValueError(f"Shell Folder {name!r} is not a string")

    return Path(value)
