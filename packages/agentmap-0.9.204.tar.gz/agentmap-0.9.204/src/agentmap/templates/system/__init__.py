"""
System templates for AgentMap.

Contains default system prompts and registry configurations.
"""
