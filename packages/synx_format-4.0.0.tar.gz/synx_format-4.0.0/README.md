# SYNX for Python — synx-format

The official Python parser for the SYNX format.

## Install

```bash
pip install synx-format
```

## Usage

```python
from synx import Synx

# Load from file
data = Synx.load('config.synx')
print(data['server']['port'])  # 8080

# Parse from string
data = Synx.parse('name Wario\nage 30')
print(data['name'])   # 'Wario'
print(data['age'])    # 30
```

## API

| Method | Description |
|---|---|
| `Synx.parse(text, **opts)` | Parse a .synx string → dict |
| `Synx.load(path, **opts)` | Load & parse a .synx file |
| `Synx.stringify(obj, active)` | Serialize dict → .synx string |

### Options (keyword arguments)

```python
Synx.parse(text,
    env={'PORT': '3000'},     # Override env vars
    region='RU',              # For :geo
    base_path='./configs',    # For :include resolution
)
```

## License

MIT — © APERTURESyndicate
