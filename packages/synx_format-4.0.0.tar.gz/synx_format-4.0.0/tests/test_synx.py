"""Tests for the SYNX Python parser and engine."""

from synx import Synx


# ─── Static mode ──────────────────────────────────────────

class TestStaticMode:
    def test_simple_key_value(self):
        data = Synx.parse(
            "name Wario\n"
            "age 30\n"
            "active true\n"
            "score 99.5\n"
            "empty null\n"
        )
        assert data['name'] == 'Wario'
        assert data['age'] == 30
        assert data['active'] is True
        assert data['score'] == 99.5
        assert data['empty'] is None

    def test_nested_objects(self):
        data = Synx.parse(
            "server\n"
            "  host 0.0.0.0\n"
            "  port 8080\n"
            "  ssl\n"
            "    enabled true\n"
        )
        assert data['server']['host'] == '0.0.0.0'
        assert data['server']['port'] == 8080
        assert data['server']['ssl']['enabled'] is True

    def test_lists(self):
        data = Synx.parse(
            "inventory\n"
            "  - Sword\n"
            "  - Shield\n"
            "  - Potion\n"
        )
        assert data['inventory'] == ['Sword', 'Shield', 'Potion']

    def test_multiline_blocks(self):
        data = Synx.parse(
            "rules |\n"
            "  Rule one.\n"
            "  Rule two.\n"
            "  Rule three.\n"
        )
        assert data['rules'] == 'Rule one.\nRule two.\nRule three.'

    def test_hash_comments(self):
        data = Synx.parse(
            "# This is a comment\n"
            "name Wario # inline\n"
        )
        assert data['name'] == 'Wario'

    def test_slash_comments(self):
        data = Synx.parse(
            "// This is a comment\n"
            "name Wario // inline\n"
        )
        assert data['name'] == 'Wario'

    def test_markers_ignored_without_active(self):
        data = Synx.parse(
            "price 100\n"
            "total:calc price * 2\n"
        )
        # Without !active, parser still parses the key but engine doesn't resolve
        assert data['total'] == 'price * 2'


# ─── Active mode ──────────────────────────────────────────

class TestActiveMode:
    def test_calc(self):
        data = Synx.parse(
            "!active\n"
            "price 100\n"
            "tax:calc price * 0.2\n"
        )
        assert data['tax'] == 20

    def test_calc_chain(self):
        data = Synx.parse(
            "!active\n"
            "price 100\n"
            "tax:calc price * 0.2\n"
            "total:calc price + 20\n"
        )
        assert data['total'] == 120

    def test_random_picks_one(self):
        data = Synx.parse(
            "!active\n"
            "pick:random\n"
            "  - Alpha\n"
            "  - Beta\n"
            "  - Gamma\n"
        )
        assert data['pick'] in ['Alpha', 'Beta', 'Gamma']

    def test_weighted_random(self):
        for _ in range(20):
            data = Synx.parse(
                "!active\n"
                "tier:random 90 5 5\n"
                "  - common\n"
                "  - rare\n"
                "  - legendary\n"
            )
            assert data['tier'] in ['common', 'rare', 'legendary']

    def test_env(self):
        data = Synx.parse(
            "!active\n"
            "home:env TEST_VAR\n",
            env={'TEST_VAR': 'hello_synx'}
        )
        assert data['home'] == 'hello_synx'

    def test_env_default(self):
        data = Synx.parse(
            "!active\n"
            "port:env:default:3000 NONEXISTENT\n",
            env={}
        )
        assert data['port'] == 3000

    def test_alias(self):
        data = Synx.parse(
            "!active\n"
            "admin admin@test.com\n"
            "contact:alias admin\n"
        )
        assert data['contact'] == 'admin@test.com'

    def test_unique(self):
        data = Synx.parse(
            "!active\n"
            "tags:unique\n"
            "  - action\n"
            "  - rpg\n"
            "  - action\n"
            "  - sim\n"
            "  - rpg\n"
        )
        assert data['tags'] == ['action', 'rpg', 'sim']

    def test_secret(self):
        data = Synx.parse(
            "!active\n"
            "key:secret my_api_key_123\n"
        )
        assert str(data['key']) == '[SECRET]'
        assert data['key'].reveal() == 'my_api_key_123'


# ─── Safe calc ────────────────────────────────────────────

class TestSafeCalc:
    def test_basic(self):
        data = Synx.parse("!active\nresult:calc 2 + 3 * 4")
        assert data['result'] == 14

    def test_parentheses(self):
        data = Synx.parse("!active\nresult:calc (2 + 3) * 4")
        assert data['result'] == 20

    def test_modulo(self):
        data = Synx.parse("!active\nresult:calc 10 % 3")
        assert data['result'] == 1

    def test_negative(self):
        data = Synx.parse("!active\nresult:calc -5 + 3")
        assert data['result'] == -2
