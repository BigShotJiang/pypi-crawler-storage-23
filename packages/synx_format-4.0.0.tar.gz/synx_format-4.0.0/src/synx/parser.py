"""
SYNX Parser

Converts raw .synx text into a structured Python dict/list tree
with hidden metadata (__synx) for the Engine to resolve.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

# ─── Type aliases ──────────────────────────────────────────

SynxObject = Dict[str, Any]
SynxArray = List[Any]

# ─── Line regex ────────────────────────────────────────────
# key(type)[constraints]:markers value
LINE_RE = re.compile(
    r'^([^\s\[:\-#/(][^\s\[:(]*)'  # key
    r'(?:\((\w+)\))?'               # (type)         (optional)
    r'(?:\[([^\]]*)\])?'            # [constraints]  (optional)
    r'(?::([\w:]+))?'               # :markers       (optional)
    r'(?:\s+(.*))?$'                # value          (optional)
)


# ─── Helpers ───────────────────────────────────────────────

def _cast(val: str) -> Any:
    """Cast a raw string value to a Python primitive."""
    if val == 'true':
        return True
    if val == 'false':
        return False
    if val == 'null':
        return None

    # Explicit cast: (int)007, (string)90210
    m = re.match(r'^\((\w+)\)(.*)$', val)
    if m:
        hint, raw = m.group(1), m.group(2)
        if hint == 'int':
            return int(raw) if raw else 0
        if hint == 'float':
            return float(raw) if raw else 0.0
        if hint == 'bool':
            return raw.strip() == 'true'
        if hint == 'string':
            return raw
        return raw

    # Auto number
    if re.match(r'^-?\d+$', val):
        return int(val)
    if re.match(r'^-?\d+\.\d+$', val):
        return float(val)

    return val


def _strip_inline_comment(val: str) -> str:
    """Remove inline # or // comments from a value string."""
    # Strip // (always safe)
    idx = val.find(' //')
    if idx != -1:
        val = val[:idx]
    # Strip # only if preceded by whitespace (preserve #FF0000)
    idx = val.find(' #')
    if idx != -1:
        val = val[:idx]
    return val.rstrip()


def _parse_constraints(raw: str) -> dict:
    """Parse constraint string like 'min:3, max:30, required'."""
    constraints: dict = {}
    for part in raw.split(','):
        part = part.strip()
        if not part:
            continue
        if part == 'required':
            constraints['required'] = True
        elif part == 'readonly':
            constraints['readonly'] = True
        else:
            segments = part.split(':', 1)
            if len(segments) == 2:
                key, value = segments
                if key == 'min':
                    constraints['min'] = float(value) if '.' in value else int(value)
                elif key == 'max':
                    constraints['max'] = float(value) if '.' in value else int(value)
                elif key == 'type':
                    constraints['type'] = value
                elif key == 'pattern':
                    constraints['pattern'] = value
                elif key == 'enum':
                    constraints['enum'] = value.split('|')
    return constraints


def _save_meta(
    obj: dict,
    key: str,
    markers: List[str],
    args: List[str],
    constraints: Optional[dict],
    mode: str,
) -> None:
    """Attach __synx metadata to an object."""
    if mode != 'active':
        return
    if not markers and not constraints:
        return

    if '__synx' not in obj:
        obj['__synx'] = {}

    meta: dict = {'markers': markers}
    if args:
        meta['args'] = args
    if constraints:
        meta['constraints'] = constraints

    obj['__synx'][key] = meta


# ─── Main parser ──────────────────────────────────────────

def parse_data(text: str) -> Tuple[SynxObject, str]:
    """
    Parse a .synx text string into a raw object tree.

    Returns:
        (root_object, mode) where mode is 'static' or 'active'.
    """
    lines = text.split('\n')
    root: SynxObject = {}
    stack: List[Tuple[int, Any]] = [(-1, root)]

    mode = 'static'
    current_block: Optional[dict] = None
    current_list: Optional[dict] = None

    for i, raw_line in enumerate(lines):
        raw = raw_line.rstrip('\r\n')
        trimmed = raw.lstrip()

        # ── Mode declaration ──
        if trimmed == '!active':
            mode = 'active'
            continue

        # Legacy support
        if trimmed.startswith('#!mode:'):
            declared = trimmed.split(':')[1].strip()
            mode = 'active' if declared == 'active' else 'static'
            continue

        # ── Skip empty / comments ──
        if not trimmed or trimmed.startswith('#') or trimmed.startswith('//'):
            continue

        indent = len(raw) - len(trimmed)

        # ── Continue multiline block ──
        if current_block is not None and indent > current_block['indent']:
            line = trimmed.replace('/n', '\n')
            key = current_block['key']
            parent = current_block['obj']
            parent[key] += ('\n' + line) if parent[key] else line
            continue
        else:
            current_block = None

        # ── Continue list items ──
        if trimmed.startswith('- '):
            if current_list is not None and indent > current_list['indent']:
                val = _strip_inline_comment(trimmed[2:].strip()).replace('/n', '\n')

                # Peek ahead: is next meaningful line a sub-key? → object in list
                next_i = i + 1
                while next_i < len(lines) and not lines[next_i].strip():
                    next_i += 1

                if next_i < len(lines):
                    next_trimmed = lines[next_i].strip()
                    next_indent = len(lines[next_i]) - len(lines[next_i].lstrip())
                    if (
                        next_indent > indent
                        and not next_trimmed.startswith('- ')
                        and not next_trimmed.startswith('#')
                        and not next_trimmed.startswith('//')
                    ):
                        # Object list item
                        item_obj: SynxObject = {}
                        m = LINE_RE.match(val)
                        if m:
                            i_key = m.group(1)
                            i_type_hint = m.group(2)
                            i_val = m.group(5)
                            if i_val and i_type_hint:
                                i_val = f'({i_type_hint}){i_val}'
                            elif i_type_hint:
                                i_val = f'({i_type_hint})'
                            item_obj[i_key] = _cast(_strip_inline_comment(i_val)) if i_val else {}
                        else:
                            item_obj['_value'] = _cast(val)
                        current_list['arr'].append(item_obj)
                        stack.append((indent, item_obj))
                        continue

                current_list['arr'].append(_cast(val))
                continue
        elif current_list is not None and indent <= current_list['indent']:
            current_list = None

        # ── Parse key line ──
        m = LINE_RE.match(trimmed)
        if not m:
            continue

        key = m.group(1)
        type_hint = m.group(2)
        constraint_str = m.group(3)
        marker_chain = m.group(4)
        raw_value = m.group(5)
        raw_value = _strip_inline_comment(raw_value.strip()) if raw_value else ''

        # Apply explicit type cast: key(type) value → (type)value
        if type_hint:
            raw_value = f'({type_hint}){raw_value}'

        # Parse markers
        markers: List[str] = marker_chain.split(':') if marker_chain else []
        marker_args: List[str] = []

        # For :random — extract weight percentages from value
        if 'random' in markers and raw_value:
            nums = [s for s in raw_value.split() if re.match(r'^\d+(\.\d+)?$', s)]
            if nums:
                marker_args = nums
                raw_value = ''

        # Parse constraints
        constraints = _parse_constraints(constraint_str) if constraint_str else None

        # ── Pop stack to correct parent ──
        while len(stack) > 1 and stack[-1][0] >= indent:
            stack.pop()
        parent = stack[-1][1]

        # ── Determine what this line creates ──
        is_block = raw_value == '|'
        is_list_marker = any(m in markers for m in ('random', 'unique', 'geo'))

        if is_block:
            parent[key] = ''
            current_block = {'indent': indent, 'obj': parent, 'key': key}
            _save_meta(parent, key, markers, marker_args, constraints, mode)

        elif is_list_marker and not raw_value:
            parent[key] = []
            current_list = {'indent': indent, 'arr': parent[key]}
            _save_meta(parent, key, markers, marker_args, constraints, mode)

        elif not raw_value:
            # No value → object group or list (peek ahead)
            parent[key] = {}
            stack.append((indent, parent[key]))

            peek = i + 1
            while peek < len(lines) and not lines[peek].strip():
                peek += 1
            if peek < len(lines) and lines[peek].strip().startswith('- '):
                parent[key] = []
                stack[-1] = (indent, parent[key])
                current_list = {'indent': indent, 'arr': parent[key]}

            _save_meta(parent, key, markers, marker_args, constraints, mode)

        else:
            parent[key] = _cast(raw_value)
            _save_meta(parent, key, markers, marker_args, constraints, mode)

    return root, mode
