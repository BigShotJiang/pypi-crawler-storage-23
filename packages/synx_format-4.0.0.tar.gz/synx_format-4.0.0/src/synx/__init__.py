"""
SYNX — The Active Data Format
==============================

Faster than JSON. Cheaper for AI tokens. Built-in logic.

Usage::

    from synx import Synx

    # From file (recommended)
    data = Synx.load('config.synx')

    # From string
    data = Synx.parse(text)

    # Access data as a normal dict
    print(data['server']['port'])  # 8080

(c) APERTURESyndicate
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional

from .parser import parse_data
from .engine import resolve, clean, SynxSecret

__version__ = "4.0.0"
__author__ = "APERTURESyndicate"
__all__ = ["Synx", "SynxSecret"]


class Synx:
    """
    Main entry point for parsing .synx files.

    Methods:
        parse(text, **options)  — Parse a .synx string into a dict.
        load(path, **options)   — Load and parse a .synx file.
        stringify(obj, active)  — Serialize a dict back to .synx format.
    """

    @staticmethod
    def parse(
        text: str,
        *,
        env: Optional[Dict[str, str]] = None,
        region: str = 'US',
        base_path: str = '.',
    ) -> dict:
        """
        Parse a .synx text string into a native Python dict.

        Args:
            text:      The .synx file contents as a string.
            env:       Override environment variables (for testing).
            region:    Region code for :geo (e.g. ``"RU"``).
            base_path: Base directory for :include resolution.

        Returns:
            A plain dict with all data resolved.

        Example::

            data = Synx.parse('name Wario\\nage 30')
            print(data['name'])  # 'Wario'
            print(data['age'])   # 30
        """
        root, mode = parse_data(text)

        if mode == 'active':
            resolve(root, env=env, region=region, base_path=base_path)

        clean(root)
        return root

    @staticmethod
    def load(
        path: str,
        *,
        env: Optional[Dict[str, str]] = None,
        region: str = 'US',
    ) -> dict:
        """
        Load and parse a .synx file.

        Args:
            path:   Path to the .synx file.
            env:    Override environment variables.
            region: Region code for :geo.

        Returns:
            A plain dict with all data resolved.

        Example::

            config = Synx.load('config.synx')
            print(config['server']['port'])  # 8080
        """
        abs_path = os.path.abspath(path)
        base = os.path.dirname(abs_path)

        with open(abs_path, 'r', encoding='utf-8') as f:
            text = f.read()

        return Synx.parse(text, env=env, region=region, base_path=base)

    @staticmethod
    def stringify(obj: dict, active: bool = False) -> str:
        """
        Serialize a dict back to .synx format.

        Args:
            obj:    The dict to serialize.
            active: If True, prepend ``!active`` header.

        Returns:
            A .synx formatted string.
        """
        out = ''
        if active:
            out += '!active\n'
        out += _serialize(obj, 0)
        return out


def _serialize(obj: dict, indent: int) -> str:
    """Recursively serialize a dict to .synx text."""
    out = ''
    spaces = ' ' * indent

    for key, val in obj.items():
        if isinstance(val, list):
            out += f'{spaces}{key}\n'
            for item in val:
                if isinstance(item, dict):
                    entries = list(item.items())
                    if entries:
                        k0, v0 = entries[0]
                        out += f'{spaces}  - {k0} {v0}\n'
                        for k, v in entries[1:]:
                            out += f'{spaces}    {k} {v}\n'
                else:
                    out += f'{spaces}  - {item}\n'
        elif isinstance(val, dict):
            out += f'{spaces}{key}\n'
            out += _serialize(val, indent + 2)
        elif isinstance(val, str) and '\n' in val:
            out += f'{spaces}{key} |\n'
            for line in val.split('\n'):
                out += f'{spaces}  {line}\n'
        else:
            out += f'{spaces}{key} {val}\n'

    return out
