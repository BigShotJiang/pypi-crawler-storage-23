"""
SYNX Safe Calculator

Evaluates arithmetic expressions WITHOUT eval().
Supports: +, -, *, /, %, parentheses, and numeric literals.
Variable references are resolved before this stage.
"""

from __future__ import annotations
from typing import List, Tuple


class CalcError(Exception):
    """Raised when a :calc expression cannot be evaluated."""
    pass


# ─── Tokenizer ─────────────────────────────────────────────

TOKEN_NUMBER = 'number'
TOKEN_OP = 'op'
TOKEN_PAREN = 'paren'


def _tokenize(expr: str) -> list:
    tokens: list = []
    i = 0
    n = len(expr)

    while i < n:
        ch = expr[i]

        # Skip whitespace
        if ch in ' \t':
            i += 1
            continue

        # Number (including negative after operator or start)
        if (ch.isdigit() or ch == '.') or (
            ch == '-' and (
                len(tokens) == 0
                or tokens[-1][0] == TOKEN_OP
                or (tokens[-1][0] == TOKEN_PAREN and tokens[-1][1] == '(')
            )
        ):
            num = ''
            if ch == '-':
                num = '-'
                i += 1
            while i < n and (expr[i].isdigit() or expr[i] == '.'):
                num += expr[i]
                i += 1
            try:
                value = float(num)
                if value == int(value) and '.' not in num:
                    value = int(num)
            except ValueError:
                raise CalcError(f"Invalid number: '{num}'")
            tokens.append((TOKEN_NUMBER, value))
            continue

        # Operators
        if ch in '+-*/%':
            tokens.append((TOKEN_OP, ch))
            i += 1
            continue

        # Parentheses
        if ch in '()':
            tokens.append((TOKEN_PAREN, ch))
            i += 1
            continue

        raise CalcError(f"SYNX :calc — unexpected character: '{ch}' in expression \"{expr}\"")

    return tokens


# ─── Recursive descent parser ──────────────────────────────
# expr   → term (('+' | '-') term)*
# term   → factor (('*' | '/' | '%') factor)*
# factor → NUMBER | '(' expr ')'

class _ExprParser:
    def __init__(self, tokens: list):
        self.tokens = tokens
        self.pos = 0

    def parse(self) -> float:
        result = self._expr()
        if self.pos < len(self.tokens):
            raise CalcError(f"SYNX :calc — unexpected token at position {self.pos}")
        return result

    def _expr(self) -> float:
        left = self._term()
        while self.pos < len(self.tokens) and self.tokens[self.pos][0] == TOKEN_OP and self.tokens[self.pos][1] in ('+', '-'):
            op = self.tokens[self.pos][1]
            self.pos += 1
            right = self._term()
            left = left + right if op == '+' else left - right
        return left

    def _term(self) -> float:
        left = self._factor()
        while self.pos < len(self.tokens) and self.tokens[self.pos][0] == TOKEN_OP and self.tokens[self.pos][1] in ('*', '/', '%'):
            op = self.tokens[self.pos][1]
            self.pos += 1
            right = self._factor()
            if op == '*':
                left = left * right
            elif op == '/':
                if right == 0:
                    raise CalcError("SYNX :calc — division by zero")
                left = left / right
            else:
                left = left % right
        return left

    def _factor(self) -> float:
        if self.pos >= len(self.tokens):
            raise CalcError("SYNX :calc — unexpected end of expression")

        tok = self.tokens[self.pos]

        if tok[0] == TOKEN_NUMBER:
            self.pos += 1
            return tok[1]

        if tok[0] == TOKEN_PAREN and tok[1] == '(':
            self.pos += 1  # skip '('
            val = self._expr()
            if self.pos >= len(self.tokens) or self.tokens[self.pos] != (TOKEN_PAREN, ')'):
                raise CalcError("SYNX :calc — missing closing parenthesis")
            self.pos += 1  # skip ')'
            return val

        raise CalcError(f"SYNX :calc — unexpected token: {tok}")


def safe_calc(expr: str) -> float | int:
    """
    Safely evaluate an arithmetic expression.
    All variable names must be substituted with numbers before calling this.

    Args:
        expr: e.g. "100 * 5 + (20 / 4)"

    Returns:
        The computed number.
    """
    expr = expr.strip()
    if not expr:
        return 0

    tokens = _tokenize(expr)
    if not tokens:
        return 0

    result = _ExprParser(tokens).parse()

    # Return int if the result is a whole number
    if isinstance(result, float) and result == int(result):
        return int(result)
    return result
