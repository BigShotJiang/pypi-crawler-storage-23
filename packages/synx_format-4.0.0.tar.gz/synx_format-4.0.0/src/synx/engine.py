"""
SYNX Engine

Resolves active markers (:random, :calc, :env, :alias, :secret, etc.)
in a parsed SYNX object tree. Only runs in !active mode.
"""

from __future__ import annotations

import os
import re
import random as _random
from typing import Any, Dict, List, Optional

from .calc import safe_calc
from .parser import parse_data


# ─── Secret wrapper ────────────────────────────────────────

class SynxSecret:
    """
    A secret value that hides itself in str()/repr()/print().
    Call .reveal() to get the real value.
    """

    def __init__(self, value: str):
        self._value = value

    def reveal(self) -> str:
        """Return the real secret value."""
        return self._value

    def __str__(self) -> str:
        return '[SECRET]'

    def __repr__(self) -> str:
        return 'SynxSecret([SECRET])'

    def __eq__(self, other: object) -> bool:
        if isinstance(other, SynxSecret):
            return self._value == other._value
        if isinstance(other, str):
            return self._value == other
        return NotImplemented

    def __hash__(self) -> int:
        return hash(self._value)


# ─── Engine ────────────────────────────────────────────────

def resolve(
    obj: dict,
    root: Optional[dict] = None,
    *,
    env: Optional[Dict[str, str]] = None,
    region: str = 'US',
    base_path: str = '.',
) -> dict:
    """
    Resolve all active markers in a parsed SYNX object tree.

    Args:
        obj:       The parsed object (or sub-object).
        root:      The top-level root object (for variable references).
        env:       Override environment variables (for testing). None = use os.environ.
        region:    Region code for :geo (e.g. "RU", "US").
        base_path: Base directory for :include resolution.

    Returns:
        The same object, with markers resolved in-place.
    """
    if root is None:
        root = obj

    meta_map: dict = obj.get('__synx', {})

    for key in list(obj.keys()):
        if key == '__synx':
            continue

        value = obj[key]

        # Recurse into nested dicts
        if isinstance(value, dict):
            resolve(value, root, env=env, region=region, base_path=base_path)

        # Recurse into lists of dicts
        if isinstance(value, list):
            for item in value:
                if isinstance(item, dict):
                    resolve(item, root, env=env, region=region, base_path=base_path)

        # Apply markers
        instr = meta_map.get(key)
        if not instr:
            continue

        markers: List[str] = instr.get('markers', [])
        args: List[str] = instr.get('args', [])

        # ── :include ──
        if 'include' in markers and isinstance(obj[key], str):
            import os.path as _osp
            include_path = str(obj[key])
            full_path = _osp.normpath(_osp.join(base_path, include_path))
            try:
                with open(full_path, 'r', encoding='utf-8') as f:
                    text = f.read()
                included, included_mode = parse_data(text)
                if included_mode == 'active':
                    resolve(included, root, env=env, region=region,
                            base_path=_osp.dirname(full_path))
                obj[key] = included
            except Exception as e:
                obj[key] = f'INCLUDE_ERR: {e}'
            continue

        # ── :env ──
        if 'env' in markers:
            var_name = str(obj[key])
            env_source = env if env is not None else os.environ
            env_val = env_source.get(var_name)

            default_idx = markers.index('default') if 'default' in markers else -1

            if env_val is not None and env_val != '':
                try:
                    obj[key] = int(env_val) if env_val.isdigit() else float(env_val)
                except ValueError:
                    obj[key] = env_val
            elif default_idx != -1 and len(markers) > default_idx + 1:
                fallback = markers[default_idx + 1]
                try:
                    obj[key] = int(fallback) if fallback.isdigit() else float(fallback)
                except ValueError:
                    obj[key] = fallback
            else:
                obj[key] = None

        # ── :random ──
        if 'random' in markers and isinstance(obj[key], list):
            arr = obj[key]
            if not arr:
                obj[key] = None
                continue

            if args:
                obj[key] = _weighted_random(arr, [float(w) for w in args])
            else:
                obj[key] = _random.choice(arr)

        # ── :calc ──
        if 'calc' in markers and isinstance(obj[key], str):
            expr = obj[key]

            # Substitute root-level variables
            for r_key, r_val in root.items():
                if isinstance(r_val, (int, float)):
                    expr = re.sub(rf'\b{re.escape(r_key)}\b', str(r_val), expr)

            # Substitute local-level variables
            for r_key, r_val in obj.items():
                if r_key != key and isinstance(r_val, (int, float)):
                    expr = re.sub(rf'\b{re.escape(r_key)}\b', str(r_val), expr)

            try:
                obj[key] = safe_calc(expr)
            except Exception as e:
                obj[key] = f"CALC_ERR: {e}"

        # ── :alias ──
        if 'alias' in markers and isinstance(obj[key], str):
            target = obj[key]
            obj[key] = _deep_get(root, target)

        # ── :secret ──
        if 'secret' in markers:
            obj[key] = SynxSecret(str(obj[key]))

        # ── :unique ──
        if 'unique' in markers and isinstance(obj[key], list):
            seen: set = set()
            unique: list = []
            for item in obj[key]:
                s = str(item)
                if s not in seen:
                    seen.add(s)
                    unique.append(item)
            obj[key] = unique

        # ── :geo ──
        if 'geo' in markers and isinstance(obj[key], list):
            arr = obj[key]
            found = None
            for item in arr:
                s = str(item)
                if s.startswith(region + ' '):
                    found = s[len(region) + 1:].strip()
                    break
            if found:
                obj[key] = found
            elif arr:
                first = str(arr[0])
                if ' ' in first:
                    obj[key] = first.split(' ', 1)[1].strip()
                else:
                    obj[key] = first
            else:
                obj[key] = None

        # ── :default (standalone) ──
        if 'default' in markers and 'env' not in markers:
            if obj[key] is None or obj[key] == '':
                default_idx = markers.index('default')
                if len(markers) > default_idx + 1:
                    fallback = markers[default_idx + 1]
                    try:
                        obj[key] = int(fallback) if fallback.isdigit() else float(fallback)
                    except ValueError:
                        obj[key] = fallback

    return obj


def clean(obj: Any) -> Any:
    """Remove all __synx metadata from the tree."""
    if isinstance(obj, dict):
        obj.pop('__synx', None)
        for v in obj.values():
            clean(v)
    elif isinstance(obj, list):
        for v in obj:
            clean(v)
    return obj


# ─── Helpers ───────────────────────────────────────────────

def _weighted_random(items: list, weights: list) -> Any:
    """Pick one item using weighted probabilities."""
    w = list(weights)

    # Pad if fewer weights than items
    if len(w) < len(items):
        assigned = sum(w)
        remaining = max(0, 100 - assigned)
        per_item = remaining / (len(items) - len(w))
        while len(w) < len(items):
            w.append(per_item)

    # Normalize
    total = sum(w)
    if total == 0:
        return _random.choice(items)

    normalized = [v / total for v in w]

    # Pick
    rand = _random.random()
    cumulative = 0.0
    for i, item in enumerate(items):
        cumulative += normalized[i]
        if rand <= cumulative:
            return item

    return items[-1]


def _deep_get(obj: dict, path: str) -> Any:
    """Get a value by key or dot-path from a dict tree."""
    if path in obj:
        return obj[path]

    parts = path.split('.')
    current = obj
    for part in parts:
        if not isinstance(current, dict):
            return None
        current = current.get(part)
    return current
