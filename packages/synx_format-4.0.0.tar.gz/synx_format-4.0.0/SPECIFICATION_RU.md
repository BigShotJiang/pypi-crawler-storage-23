# 📘 SYNX — Полная спецификация формата

**Версия:** 4.0  
**Название:** SYNX (Syndicate Exchange), читается как «Синус Х»  
**Расширение файлов:** `.synx`

---

## 1. Философия

SYNX — это формат данных, который убирает весь синтаксический мусор: кавычки, запятые, скобки, двоеточия вокруг значений. Остаётся только **ключ**, **пробел**, **значение**.

| Критерий | JSON | YAML | SYNX |
|---|---|---|---|
| Кавычки | Обязательны | Иногда | Нет |
| Запятые / скобки | Да | Нет | Нет |
| Встроенная логика | Нет | Нет | Да (`!active`) |
| Токены для AI | ~100% | ~75% | ~40% |

---

## 2. Базовый синтаксис (работает всегда)

### 2.1 Ключ-значение

Всё, что идёт после **первого пробела** — это значение. Кавычки не нужны.

```synx
имя Иван
возраст 25
фраза Я люблю программировать и пить кофе!
```

Эквивалент в JSON:
```json
{
  "имя": "Иван",
  "возраст": 25,
  "фраза": "Я люблю программировать и пить кофе!"
}
```

**Правила для ключей:**
- Без пробелов (используйте `_` или `camelCase`)
- Не могут начинаться с `-`, `#`, `//`, `!`
- Могут содержать буквы любого алфавита, цифры, `_`, `-` (внутри)

---

### 2.2 Автоопределение типов

Парсер автоматически определяет типы:

```synx
строка Hello World
целое 42
дробное 3.14
правда true
ложь false
пусто null
```

Результат:
```json
{
  "строка": "Hello World",
  "целое": 42,
  "дробное": 3.14,
  "правда": true,
  "ложь": false,
  "пусто": null
}
```

**Принудительное приведение типа** (если нужно число как строку):
```synx
zip_code(string) 90210
id(int) 007
```

Поддерживаемые касты: `(int)`, `(float)`, `(bool)`, `(string)`

---

### 2.3 Вложенность (объекты)

Отступ **2 пробела** создаёт вложенный объект. Ключ без значения — это группа (папка).

```synx
сервер
  хост 0.0.0.0
  порт 8080
  ssl
    включён true
    сертификат /etc/ssl/cert.pem
```

Результат:
```json
{
  "сервер": {
    "хост": "0.0.0.0",
    "порт": 8080,
    "ssl": {
      "включён": true,
      "сертификат": "/etc/ssl/cert.pem"
    }
  }
}
```

> ⚠️ Используйте **пробелы**, а не TAB. Стандарт — **2 пробела** на уровень.

---

### 2.4 Списки

Символ `- ` (дефис + пробел) создаёт элемент списка. Элементы без имён — просто порядковый набор.

```synx
инвентарь
  - Меч
  - Щит
  - Зелье здоровья
```

Результат:
```json
{
  "инвентарь": ["Меч", "Щит", "Зелье здоровья"]
}
```

**Список объектов** (каждый элемент — мини-анкета):

```synx
гараж
  - марка BMW
    цвет чёрный
    год 2023
  - марка Audi
    цвет белый
    год 2021
```

Результат:
```json
{
  "гараж": [
    { "марка": "BMW", "цвет": "чёрный", "год": 2023 },
    { "марка": "Audi", "цвет": "белый", "год": 2021 }
  ]
}
```

---

### 2.5 Многострочный текст (блоки)

Символ `|` после ключа начинает блок текста. Всё, что идёт ниже с отступом — часть этого текста.

```synx
описание |
  Это длинное описание,
  которое занимает несколько строк.
  Каждая строка склеивается через перенос.
```

Результат:
```json
{
  "описание": "Это длинное описание,\nкоторое занимает несколько строк.\nКаждая строка склеивается через перенос."
}
```

Принудительный перенос строки внутри одной строки: `/n`

```synx
баннер Добро пожаловать!/nУдачной игры!
```

Результат: 
```
Добро пожаловать!
Удачной игры!
```

---

### 2.6 Комментарии

Поддерживаются **два стиля** комментариев:

```synx
# Это комментарий (стиль Python/YAML)
// Это тоже комментарий (стиль JS/C++)

имя Иван  # Инлайн-комментарий после значения
порт 8080 // Тоже инлайн
```

Комментарии полностью игнорируются парсером.

---

## 3. Режим `!active` — живой конфиг

### 3.1 Что это такое

По умолчанию `.synx` файл — это **статичные данные**. Просто ключи и значения, как JSON.

Но если в **первой строке** файла написать `!active`, файл превращается в **живой конфиг** — включаются:

- **Функции** (`:random`, `:calc`, `:env` и др.)
- **Ограничения** (`[min:3]`, `[type:int]` и др.)

```synx
!active

порт:env PORT
приветствие:random
  - Привет!
  - Здорово!
```

Без `!active` — маркеры `:random`, `:calc` и квадратные скобки `[]` **полностью игнорируются**. Парсер читает файл как обычный текст:

```synx
// Нет !active — функции НЕ работают
порт:env PORT           // ключ = "порт:env", значение = "PORT" (просто строка)
приветствие:random       // ключ = "приветствие:random", значение = {} (объект)
```

> 💡 Это сделано для безопасности: статичный файл **никогда** не выполнит код, не полезет в переменные окружения и не запустит команды.

---

### 3.2 Полный список функций (`:`)

Функции записываются через двоеточие сразу после имени ключа: `ключ:функция значение`.

---

#### `:random` — случайный выбор

Выбирает **один** элемент из списка при каждом парсинге.

**Равные шансы** (без процентов):
```synx
!active

боевой_клич:random
  - Время побеждать!
  - Ва-ха-ха!
  - За Синдикат!
```
Каждый элемент имеет шанс 33.3%.

**Взвешенный рандом** (с процентами):
```synx
!active

// Проценты указываются после :random через пробел
// Порядок процентов соответствует порядку элементов
награда:random 70 20 10
  - Обычный сундук
  - Редкий сундук
  - Легендарный сундук
```

Здесь:
- «Обычный сундук» выпадает с шансом **70%**
- «Редкий сундук» — **20%**
- «Легендарный сундук» — **10%**

**Правила процентов:**
| Ситуация | Поведение |
| Процентов нет | Все элементы равновероятны |
| Сумма = 100 | Используются как есть |
| Сумма ≠ 100 | Автоматически нормализуются (пропорции сохраняются) |
| Процентов меньше, чем элементов | Остаток делится поровну между элементами без процента |
| Процентов больше, чем элементов | Лишние проценты игнорируются |

Пример нормализации:
```synx
!active

// 2 + 1 = 3, нормализация: ~66.7% и ~33.3%
тип:random 2 1
  - Воин
  - Маг
```

Пример неполных процентов:
```synx
!active

// Первому — 80%, оставшиеся 20% делятся на два: по 10%
дроп:random 80
  - Ничего
  - Меч
  - Щит
```

---

#### `:calc` — вычисление выражения

Вычисляет арифметическое выражение. Может ссылаться на другие ключи по имени.

```synx
!active

цена 100
налог:calc цена * 0.2
итого:calc цена + налог
```

Результат:
```
цена 100
налог 20 // < программа получит это значение
итого 120 // < программа получит это значение
```

Если брать файл .json
```json
{
  "цена": 100,
  "налог": 20,
  "итого": 120
}
```

**Поддерживаемые операции:** `+`, `-`, `*`, `/`, `%` (остаток), `(`, `)`.

> ⚠️ Только арифметика. Никакого произвольного кода. Парсер использует безопасный вычислитель, не `eval()`.

---

#### `:env` — переменная окружения

Подставляет значение переменной окружения системы.

```synx
!active

порт:env PORT
домашняя_папка:env HOME
```

Если переменная не найдена — значение будет `null`.

**С дефолтом** (через `:default`):
```synx
!active

порт:env:default:8080 PORT
```
Если `PORT` не задан в системе → вернётся `8080`.

---

#### `:alias` — ссылка на другой ключ

Копирует значение другого ключа. Не дублирует данные — ссылается.

```synx
!active

главный_админ alex@mail.com
почта_для_жалоб:alias главный_админ
```

Результат:
```json
{
  "главный_админ": "alex@mail.com",
  "почта_для_жалоб": "alex@mail.com"
}
```

---

#### `:secret` — скрытое значение

Значение читается программой, но **не выводится** в логи, при `freeze`, при сериализации в JSON. Защита от случайной утечки.

```synx
!active

api_key:secret sk-1234567890abcdef
db_password:secret P@ssw0rd!
```

При `console.log(data)`, `print(data)`, `JSON.stringify(data)` — покажет `"[SECRET]"`.  
Чтобы **получить реальное значение**, используйте метод `.reveal()`:

```javascript
// JavaScript / TypeScript
const key = data.api_key;          // SynxSecret объект
console.log(String(key));           // "[SECRET]"
console.log(JSON.stringify(key));   // '"[SECRET]"'
console.log(key.reveal());          // "sk-1234567890abcdef"  ← реальное значение
```

```python
# Python
key = data['api_key']               # SynxSecret объект
print(key)                          # [SECRET]
print(key.reveal())                 # sk-1234567890abcdef  ← реальное значение
```

> ⚠️ **Важно:** Никогда не логируйте результат `.reveal()`. Этот метод предназначен только для передачи значения в API, подключения к БД и т.д.

---

#### `:default` — значение по умолчанию

Задаёт fallback, если основное значение пустое или не найдено. Чаще всего комбинируется с `:env`.

```synx
!active

// Если переменная PORT не задана — будет 3000
порт:env:default:3000 PORT

// Просто значение по умолчанию (если значение = null или пусто)
тема:default dark
```

---

#### `:unique` — убрать дубликаты из списка

Оставляет только уникальные элементы.

```synx
!active

теги:unique
  - экшн
  - рпг
  - экшн
  - симулятор
  - рпг
```

Результат: `["экшн", "рпг", "симулятор"]`

---

#### `:include` — подключить другой файл

Вставляет содержимое другого `.synx` файла в текущий. Путь относительный от текущего файла.

```synx
!active

// Подтянуть настройки базы данных из отдельного файла
database:include ./db.synx
```

Где `db.synx`:
```synx
host localhost
port 5432
name mydb
```

Результат:
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "name": "mydb"
  }
}
```

---

#### `:geo` — значение по геолокации / региону

Выбирает значение на основе региона пользователя (определяется по IP или системной локали).

```synx
!active

валюта:geo
  - RU RUB
  - US USD
  - EU EUR
```

> Эта функция требует поддержки в рантайме. Парсер передаёт текущий регион движку.

---

### 3.3 Сводная таблица функций

| Функция | Описание | Пример |
|---|---|---|
| `:random` | Случайный элемент из списка | `фраза:random` |
| `:random N N N` | Взвешенный рандом (проценты) | `дроп:random 70 20 10` |
| `:calc` | Арифметическое вычисление | `итого:calc цена * 1.2` |
| `:env` | Переменная окружения | `порт:env PORT` |
| `:alias` | Ссылка на другой ключ | `копия:alias оригинал` |
| `:secret` | Скрытое от логов значение | `пароль:secret abc123` |
| `:default` | Значение по умолчанию | `тема:default dark` |
| `:default:X` | Fallback (в комбинации) | `порт:env:default:8080 PORT` |
| `:unique` | Дедупликация списка | `теги:unique` |
| `:include` | Подключить внешний файл | `бд:include ./db.synx` |
| `:geo` | Значение по региону | `валюта:geo` |

**Комбинирование функций** — через цепочку `:`:
```synx
!active
порт:env:default:8080 PORT
```

---

### 3.4 Ограничения (`[]`) — валидация данных

Ограничения записываются в квадратных скобках между ключом и функцией (или значением). Они работают **только** в режиме `!active`.

Общий синтаксис:
```
ключ[ограничение1:значение, ограничение2:значение]:функция значение
```

---

#### `min` / `max` — минимум и максимум

Для **чисел** — ограничивает диапазон значения.  
Для **строк** — ограничивает длину (количество символов).

```synx
!active

// Строка от 3 до 30 символов
имя_приложения[min:3, max:30] TotalWario

// Число от 1 до 100
громкость[min:1, max:100] 75

// Только минимум
пароль[min:8] мойпароль123
```

---

#### `required` — обязательное поле

Парсер выкинет ошибку, если значение пустое или отсутствует.

```synx
!active

api_key[required]:env API_KEY
имя[required, min:1] Wario
```

---

#### `pattern` — регулярное выражение

Значение должно соответствовать regex-шаблону.

```synx
!active

код_страны[pattern:^[A-Z]{2}$] RU
телефон[pattern:^\+\d{10,15}$] +79991234567
```

---

#### `enum` — допустимые значения

Значение должно быть одним из перечисленных.

```synx
!active

тема[enum:light|dark|auto] dark
регион[enum:EU|US|RU|AS] RU
```

---

#### `readonly` — только для чтения

Значение нельзя изменить через API / горячую перезагрузку конфига. Только ручное редактирование файла.

```synx
!active

версия[readonly] 2.0.0
```

---

### 3.5 Сводная таблица ограничений

| Ограничение | Описание | Синтаксис |
|---|---|---|
| `min` | Минимум (длина или значение) | `[min:3]` |
| `max` | Максимум (длина или значение) | `[max:100]` |
| `type` | Тип данных | `[type:int]` |
| `required` | Обязательное поле | `[required]` |
| `pattern` | Regex-валидация | `[pattern:^\d+$]` |
| `enum` | Список допустимых значений | `[enum:a\|b\|c]` |
| `readonly` | Запрет на изменение | `[readonly]` |

Ограничения можно комбинировать через запятую:
```synx
!active
пароль[required, min:8, max:64, type:string] MyP@ssw0rd
```

---

## 4. Полные примеры

### 4.1 Обычный файл (без `!active`)

Простой статичный конфиг. Никакой магии — просто данные.

```synx
# Конфиг игры TotalWario (статичный)

app_name TotalWario
version 2.0.0

server
  host 0.0.0.0
  port 8080
  ssl_enabled false

gameplay
  base_hp 100
  boss_hp 500
  max_players 16
  greeting Prepare to fight.

map_rotation
  - Arena of Doom
  - Crystal Caverns
  - Wario Stadium

rules |
  1. Не читерить.
  2. Уважать Синдикат.
  3. Весело проводить время!

credits
  lead_dev KaiserBerg
  studio APERTURESyndicate
  year 2026
```

Результат (`Synx.parse()`):
```json
{
  "app_name": "TotalWario",
  "version": "2.0.0",
  "server": {
    "host": "0.0.0.0",
    "port": 8080,
    "ssl_enabled": false
  },
  "gameplay": {
    "base_hp": 100,
    "boss_hp": 500,
    "max_players": 16,
    "greeting": "Prepare to fight."
  },
  "map_rotation": [
    "Arena of Doom",
    "Crystal Caverns",
    "Wario Stadium"
  ],
  "rules": "1. Не читерить.\n2. Уважать Синдикат.\n3. Весело проводить время!",
  "credits": {
    "lead_dev": "KaiserBerg",
    "studio": "APERTURESyndicate",
    "year": 2026
  }
}
```

---

### 4.2 Файл с `!active` — живой конфиг

Тот же конфиг, но с динамическими функциями и валидацией.

```synx
!active
# Живой конфиг проекта TotalWario

app_name[required, min:3, max:30] TotalWario
version[readonly] 2.0.0

server
  // Порт из переменной окружения, если нет — 8080
  port:env:default:8080 PORT
  host 0.0.0.0
  ssl_enabled false

gameplay
  base_hp 100
  // Движок сам посчитает: 100 * 5 = 500
  boss_hp:calc base_hp * 5
  max_players[type:int, min:2, max:64] 16
  difficulty[enum:easy|normal|hard|nightmare] normal

  // Каждый раз при парсинге — случайная фраза
  greeting:random
    - Welcome to the arena!
    - Prepare to fight.
    - Wario time!

  // Взвешенный рандом: обычный дроп 70%, редкий 20%, легенда 10%
  loot_tier:random 70 20 10
    - common
    - rare
    - legendary

map_rotation
  - Arena of Doom
  - Crystal Caverns
  - Wario Stadium

rules |
  1. Не читерить.
  2. Уважать Синдикат.
  3. Весело проводить время!

// Подключить настройки БД из отдельного файла
database:include ./db.synx

// Секреты — не попадут в логи
api_key[required]:secret sk-live-abc123def456

credits
  lead_dev KaiserBerg
  studio APERTURESyndicate
  year 2026
  contact:alias lead_dev
```

Результат одного из вызовов `Synx.parse()`:
```json
{
  "app_name": "TotalWario",
  "version": "2.0.0",
  "server": {
    "port": 8080,
    "host": "0.0.0.0",
    "ssl_enabled": false
  },
  "gameplay": {
    "base_hp": 100,
    "boss_hp": 500,
    "max_players": 16,
    "difficulty": "normal",
    "greeting": "Wario time!",
    "loot_tier": "common"
  },
  "map_rotation": [
    "Arena of Doom",
    "Crystal Caverns",
    "Wario Stadium"
  ],
  "rules": "1. Не читерить.\n2. Уважать Синдикат.\n3. Весело проводить время!",
  "database": {
    "host": "localhost",
    "port": 5432,
    "name": "mydb"
  },
  "api_key": "[SECRET]",
  "credits": {
    "lead_dev": "KaiserBerg",
    "studio": "APERTURESyndicate",
    "year": 2026,
    "contact": "KaiserBerg"
  }
}
```

> При следующем вызове `parse()` поля `greeting` и `loot_tier` будут другими — в этом и смысл `:random`.

---

## 5. Использование в коде — напрямую, без конвертации

> 🚀 **Главный принцип:** SYNX читается вашим кодом **напрямую**. Никакой конвертации в JSON не нужно. Библиотека сама парсит `.synx` файл и возвращает готовый родной объект вашего языка — `dict` в Python, `Object` в JavaScript. Вы работаете с данными сразу.

### 5.1 Установка

```bash
# JavaScript / TypeScript
npm install @aperturesyndicate/synx

# Python
pip install synx-format
```

---

### 5.2 Python — чтение `.synx` напрямую

```python
from synx import Synx

# Читаем .synx файл — и сразу получаем dict
data = Synx.load('config.synx')

# Всё. Данные готовы. Работайте как с обычным словарём:
print(data['app_name'])                # "TotalWario"
print(data['server']['port'])          # 8080
print(data['gameplay']['base_hp'])     # 100
print(data['gameplay']['boss_hp'])     # 500 (посчитано через :calc)
print(data['gameplay']['greeting'])    # "Wario time!" (выбрано :random)

# Списки — обычные list:
for map_name in data['map_rotation']:
    print(f'Загружаю карту: {map_name}')

# Вложенность — обычные dict:
if data['server']['ssl_enabled']:
    print('SSL включён')
```

**Метод `Synx.load(path)`** — читает файл и парсит за один вызов.  
**Метод `Synx.parse(text)`** — парсит строку (если файл уже прочитан).

```python
# Альтернативно — из строки:
with open('config.synx', 'r', encoding='utf-8') as f:
    data = Synx.parse(f.read())
```

---

### 5.3 JavaScript — чтение `.synx` напрямую

```javascript
const Synx = require('@aperturesyndicate/synx');

// Читаем .synx файл — получаем обычный JS-объект
const data = Synx.loadSync('config.synx');

// Работайте как с обычным объектом через точку:
console.log(data.app_name);               // "TotalWario"
console.log(data.server.port);             // 8080
console.log(data.gameplay.base_hp);        // 100
console.log(data.gameplay.boss_hp);        // 500
console.log(data.gameplay.greeting);       // случайная фраза

// Списки — обычные Array:
data.map_rotation.forEach(map => {
    console.log(`Загружаю карту: ${map}`);
});

// Деструктуризация:
const { base_hp, boss_hp, greeting } = data.gameplay;
console.log(`HP босса: ${boss_hp}, приветствие: ${greeting}`);
```

**`Synx.loadSync(path)`** — читает файл и парсит синхронно.  
**`Synx.load(path)`** — асинхронная версия (возвращает `Promise`).  
**`Synx.parse(text)`** — парсит строку.

```javascript
// Асинхронный вариант:
const data = await Synx.load('config.synx');

// Из строки:
const fs = require('fs');
const text = fs.readFileSync('config.synx', 'utf-8');
const data = Synx.parse(text);
```

---

### 5.4 TypeScript — с типизацией

```typescript
import Synx from '@aperturesyndicate/synx';

// Опишите структуру вашего конфига:
interface GameConfig {
  app_name: string;
  version: string;
  server: {
    port: number;
    host: string;
    ssl_enabled: boolean;
  };
  gameplay: {
    base_hp: number;
    boss_hp: number;
    greeting: string;
    loot_tier: string;
  };
  map_rotation: string[];
}

// Парсер вернёт типизированный объект:
const data = Synx.loadSync<GameConfig>('config.synx');

console.log(data.gameplay.boss_hp);  // number, автодополнение работает
console.log(data.server.port);       // number
```

---

### 5.5 Использование данных SYNX для CSS

SYNX возвращает обычный объект — `Object` в JS, `dict` в Python. Вы можете использовать эти данные для генерации CSS, CSS-переменных, или передавать в любую систему стилей.

**Пример: CSS-переменные из SYNX в Node.js**

```synx
# theme.synx
primary #5a6eff
secondary #ff5a8a
font_size 16
border_radius 8
spacing 12
```

```javascript
const Synx = require('@aperturesyndicate/synx');
const fs = require('fs');

const theme = Synx.loadSync('theme.synx');

// Генерация CSS-переменных
const css = `:root {
  --color-primary: ${theme.primary};
  --color-secondary: ${theme.secondary};
  --font-size: ${theme.font_size}px;
  --border-radius: ${theme.border_radius}px;
  --spacing: ${theme.spacing}px;
}`;

fs.writeFileSync('theme.css', css);
```

**Пример: Inline-стили в React**

```tsx
import Synx from '@aperturesyndicate/synx';

const theme = Synx.loadSync('theme.synx');

function Button({ children }) {
  return (
    <button style={{
      backgroundColor: theme.primary,
      borderRadius: `${theme.border_radius}px`,
      padding: `${theme.spacing}px`,
      fontSize: `${theme.font_size}px`,
    }}>
      {children}
    </button>
  );
}
```

**Пример: CSS-in-JS (styled-components, Tailwind config)**

```javascript
// tailwind.config.js
const Synx = require('@aperturesyndicate/synx');
const theme = Synx.loadSync('theme.synx');

module.exports = {
  theme: {
    extend: {
      colors: {
        primary: theme.primary,
        secondary: theme.secondary,
      },
      spacing: {
        base: `${theme.spacing}px`,
      },
    },
  },
};
```

> SYNX не заменяет CSS — он предоставляет **данные** (цвета, размеры, токены), которые ваш код
использует для генерации стилей. Это особенно полезно для дизайн-систем и тематизации.

---

### 5.6 Сравнение: SYNX напрямую vs JSON

| | JSON | SYNX |
|---|---|---|
| **Чтение** | `JSON.parse(fs.readFileSync(...))` | `Synx.loadSync('file.synx')` |
| **Промежуточный формат** | Нет | Нет — тоже нет! |
| **Что получаете** | Object / dict | Object / dict (то же самое) |
| **Встроенная логика** | Нет — пишете руками | `:random`, `:calc`, `:env` из коробки |
| **Валидация** | Нет — нужна отдельная библиотека | `[min:3, type:int]` прямо в файле |
| **Размер файла** | ~100% | ~40% меньше (нет кавычек/скобок) |

> Формат `.synx` — это **не промежуточный формат**, который нужно конвертировать. Это **прямой источник данных**, как `.json`, только легче и умнее.

---

## 6. Конвертация в JSON (опционально)

> 📎 Конвертация в JSON — это **необязательная** возможность. Она нужна только если вы хотите передать данные в систему, которая понимает исключительно JSON (сторонний API, legacy-код, и т.д.).

### 6.1 Через VS Code (расширение SYNX)

Если установлено расширение **SYNX for VS Code**:

1. Откройте `.synx` файл
2. Нажмите **ПКМ** (правой кнопкой мыши) по файлу
3. Выберите **«Конвертировать в JSON»**
4. Готовый `.json` файл появится рядом

### 6.2 Через терминал (CLI)

```bash
# Конвертировать в JSON и вывести в консоль
synx to-json config.synx

# Конвертировать и сохранить в файл
synx to-json config.synx -o config.json

# Заморозить !active конфиг в статичный .synx (без функций)
synx freeze active_config.synx -o static_config.synx
```

### 6.3 Программно (если очень нужно)

```python
import json
from synx import Synx

data = Synx.load('config.synx')
json_string = json.dumps(data, ensure_ascii=False, indent=2)
```

```javascript
const Synx = require('@aperturesyndicate/synx');
const data = Synx.loadSync('config.synx');
const jsonString = JSON.stringify(data, null, 2);
```

> Но ещё раз: **это не нужно для работы**. Ваш код читает `.synx` напрямую.

---

## 7. Краткая шпаргалка

```
КЛЮЧ ЗНАЧЕНИЕ                    → простая пара
ключ                             → пустой объект (группа)
  вложенный_ключ значение        → вложенность (2 пробела)
ключ |                           → многострочный текст
  строка 1                         (блок)
  строка 2
список                           → список
  - элемент 1
  - элемент 2
# комментарий                    → однострочный комментарий
// комментарий                   → однострочный комментарий

─── Только с !active ───────────────────────────
ключ:random                      → случайный элемент
ключ:random 70 20 10             → взвешенный рандом
ключ:calc A * B                  → арифметика
ключ:env VAR                     → переменная окружения
ключ:env:default:X VAR           → env с дефолтом
ключ:alias другой_ключ           → ссылка на другой ключ
ключ:secret значение             → скрытое значение
ключ:unique                      → дедупликация списка
ключ:include ./файл.synx         → подключить файл
ключ[min:N, max:N]               → ограничения длины/значения
ключ[type:int]                   → тип данных
ключ[required]                   → обязательное поле
ключ[enum:a|b|c]                 → допустимые значения
ключ[pattern:regex]              → regex-валидация
ключ[readonly]                   → только для чтения
```
