# 📘 SYNX — Full Format Specification

**Version:** 4.0  
**Name:** SYNX (Syndicate Exchange), pronounced "Sine-X"  
**File extension:** `.synx`

---

## 1. Philosophy

SYNX is a data format that strips away all syntactic noise — quotes, commas, brackets, colons around values. All that remains is **key**, **space**, **value**.

| Criteria | JSON | YAML | SYNX |
|---|---|---|---|
| Quotes | Required | Sometimes | No |
| Commas / brackets | Yes | No | No |
| Built-in logic | No | No | Yes (`!active`) |
| Tokens for AI | ~100% | ~75% | ~40% |

---

## 2. Basic Syntax (always works)

### 2.1 Key–Value

Everything after the **first space** is the value. No quotes needed.

```synx
name John
age 25
phrase I love programming and drinking coffee!
```

JSON equivalent:
```json
{
  "name": "John",
  "age": 25,
  "phrase": "I love programming and drinking coffee!"
}
```

**Key rules:**
- No spaces (use `_` or `camelCase`)
- Cannot start with `-`, `#`, `//`, `!`
- May contain letters of any alphabet, digits, `_`, `-` (inside)

---

### 2.2 Automatic Type Detection

The parser detects types automatically:

```synx
greeting Hello World
count 42
rate 3.14
enabled true
disabled false
empty null
```

Result:
```json
{
  "greeting": "Hello World",
  "count": 42,
  "rate": 3.14,
  "enabled": true,
  "disabled": false,
  "empty": null
}
```

**Explicit type casting** (if you need a number as a string):
```synx
zip_code(string) 90210
id(int) 007
```

Supported casts: `(int)`, `(float)`, `(bool)`, `(string)`

---

### 2.3 Nesting (objects)

An indent of **2 spaces** creates a nested object. A key without a value is a group (folder).

```synx
server
  host 0.0.0.0
  port 8080
  ssl
    enabled true
    cert /etc/ssl/cert.pem
```

Result:
```json
{
  "server": {
    "host": "0.0.0.0",
    "port": 8080,
    "ssl": {
      "enabled": true,
      "cert": "/etc/ssl/cert.pem"
    }
  }
}
```

> ⚠️ Use **spaces**, not TABs. The standard is **2 spaces** per level.

---

### 2.4 Lists

The `- ` (dash + space) symbol creates a list item. Items without names form an ordered collection.

```synx
inventory
  - Sword
  - Shield
  - Health Potion
```

Result:
```json
{
  "inventory": ["Sword", "Shield", "Health Potion"]
}
```

**List of objects** (each item is a mini-record):

```synx
garage
  - make BMW
    color black
    year 2023
  - make Audi
    color white
    year 2021
```

Result:
```json
{
  "garage": [
    { "make": "BMW", "color": "black", "year": 2023 },
    { "make": "Audi", "color": "white", "year": 2021 }
  ]
}
```

---

### 2.5 Multiline Text (blocks)

The `|` character after a key starts a text block. Everything indented below is part of that text.

```synx
description |
  This is a long description
  that spans multiple lines.
  Each line is joined with a newline character.
```

Result:
```json
{
  "description": "This is a long description\nthat spans multiple lines.\nEach line is joined with a newline character."
}
```

Forced line break inside a single line: `/n`

```synx
banner Welcome!/nEnjoy the game!
```

Result:
```
Welcome!
Enjoy the game!
```

---

### 2.6 Comments

**Two styles** are supported:

```synx
# This is a comment (Python/YAML style)
// This is also a comment (JS/C++ style)

name John  # Inline comment after value
port 8080 // Also inline
```

Comments are completely ignored by the parser.

---

## 3. `!active` Mode — Live Config

### 3.1 What Is It

By default a `.synx` file contains **static data**. Just keys and values, like JSON.

But if the **first line** of the file says `!active`, the file becomes a **live config** — enabling:

- **Functions** (`:random`, `:calc`, `:env`, etc.)
- **Constraints** (`[min:3]`, `[type:int]`, etc.)

```synx
!active

port:env PORT
greeting:random
  - Hello!
  - Welcome!
```

Without `!active` — markers `:random`, `:calc` and square brackets `[]` are **completely ignored**. The parser reads the file as plain text:

```synx
// No !active — functions DO NOT work
port:env PORT           // key = "port:env", value = "PORT" (just a string)
greeting:random          // key = "greeting:random", value = {} (object)
```

> 💡 This is a security feature: a static file will **never** execute code, access environment variables, or run commands.

---

### 3.2 Full List of Functions (`:`)

Functions are written with a colon immediately after the key name: `key:function value`.

---

#### `:random` — Random Selection

Selects **one** element from a list on each parse.

**Equal chances** (no percentages):
```synx
!active

battle_cry:random
  - Time to win!
  - Ha-ha-ha!
  - For the Syndicate!
```
Each item has a 33.3% chance.

**Weighted random** (with percentages):
```synx
!active

// Percentages go after :random separated by spaces
// Order of percentages matches order of items
loot:random 70 20 10
  - Common Chest
  - Rare Chest
  - Legendary Chest
```

Here:
- "Common Chest" drops with **70%** chance
- "Rare Chest" — **20%**
- "Legendary Chest" — **10%**

**Percentage rules:**
| Situation | Behavior |
|---|---|
| No percentages | All items are equally likely |
| Sum = 100 | Used as-is |
| Sum ≠ 100 | Automatically normalized (proportions preserved) |
| Fewer percentages than items | Remainder is split evenly among items without a percentage |
| More percentages than items | Extra percentages are ignored |

Normalization example:
```synx
!active

// 2 + 1 = 3, normalized: ~66.7% and ~33.3%
class:random 2 1
  - Warrior
  - Mage
```

Partial percentages example:
```synx
!active

// First gets 80%, remaining 20% split between two: 10% each
drop:random 80
  - Nothing
  - Sword
  - Shield
```

---

#### `:calc` — Expression Evaluation

Evaluates an arithmetic expression. Can reference other keys by name.

```synx
!active

price 100
tax:calc price * 0.2
total:calc price + tax
```

Result:
```
price 100
tax 20    // ← your program receives this value
total 120 // ← your program receives this value
```

As a JSON file:
```json
{
  "price": 100,
  "tax": 20,
  "total": 120
}
```

**Supported operations:** `+`, `-`, `*`, `/`, `%` (remainder), `(`, `)`.

> ⚠️ Arithmetic only. No arbitrary code. The parser uses a safe evaluator, not `eval()`.

---

#### `:env` — Environment Variable

Substitutes the value of a system environment variable.

```synx
!active

port:env PORT
home_dir:env HOME
```

If the variable is not found — the value will be `null`.

**With a default** (via `:default`):
```synx
!active

port:env:default:8080 PORT
```
If `PORT` is not set → returns `8080`.

---

#### `:alias` — Reference to Another Key

Copies the value of another key. Does not duplicate data — references it.

```synx
!active

admin_email alex@example.com
complaints_email:alias admin_email
```

Result:
```json
{
  "admin_email": "alex@example.com",
  "complaints_email": "alex@example.com"
}
```

---

#### `:secret` — Hidden Value

The value is readable by your program but **not shown** in logs, during `freeze`, or when serialized to JSON. Protects against accidental leaks.

```synx
!active

api_key:secret sk-1234567890abcdef
db_password:secret P@ssw0rd!
```

With `console.log(data)`, `print(data)`, `JSON.stringify(data)` — shows `"[SECRET]"`.  
To **get the real value**, use the `.reveal()` method:

```javascript
// JavaScript / TypeScript
const key = data.api_key;          // SynxSecret object
console.log(String(key));           // "[SECRET]"
console.log(JSON.stringify(key));   // '"[SECRET]"'
console.log(key.reveal());          // "sk-1234567890abcdef"  ← real value
```

```python
# Python
key = data['api_key']               # SynxSecret object
print(key)                          # [SECRET]
print(key.reveal())                 # sk-1234567890abcdef  ← real value
```

> ⚠️ **Important:** Never log the result of `.reveal()`. This method is intended only for passing the value to APIs, database connections, etc.

---

#### `:default` — Default Value

Sets a fallback if the main value is empty or not found. Most often combined with `:env`.

```synx
!active

// If PORT env var is not set — will be 3000
port:env:default:3000 PORT

// Just a default value (if value = null or empty)
theme:default dark
```

---

#### `:unique` — Remove Duplicates from List

Keeps only unique elements.

```synx
!active

tags:unique
  - action
  - rpg
  - action
  - simulation
  - rpg
```

Result: `["action", "rpg", "simulation"]`

---

#### `:include` — Include Another File

Inserts the contents of another `.synx` file into the current one. Path is relative to the current file.

```synx
!active

// Pull database settings from a separate file
database:include ./db.synx
```

Where `db.synx`:
```synx
host localhost
port 5432
name mydb
```

Result:
```json
{
  "database": {
    "host": "localhost",
    "port": 5432,
    "name": "mydb"
  }
}
```

---

#### `:geo` — Value by Geolocation / Region

Selects a value based on user region (determined by IP or system locale).

```synx
!active

currency:geo
  - US USD
  - EU EUR
  - GB GBP
```

> This function requires runtime support. The parser passes the current region to the engine.

---

### 3.3 Functions Summary Table

| Function | Description | Example |
|---|---|---|
| `:random` | Random item from list | `phrase:random` |
| `:random N N N` | Weighted random (percentages) | `loot:random 70 20 10` |
| `:calc` | Arithmetic evaluation | `total:calc price * 1.2` |
| `:env` | Environment variable | `port:env PORT` |
| `:alias` | Reference to another key | `copy:alias original` |
| `:secret` | Value hidden from logs | `password:secret abc123` |
| `:default` | Default value | `theme:default dark` |
| `:default:X` | Fallback (in combination) | `port:env:default:8080 PORT` |
| `:unique` | List deduplication | `tags:unique` |
| `:include` | Include external file | `db:include ./db.synx` |
| `:geo` | Value by region | `currency:geo` |

**Chaining functions** — via `:` chain:
```synx
!active
port:env:default:8080 PORT
```

---

### 3.4 Constraints (`[]`) — Data Validation

Constraints are written in square brackets between the key and the function (or value). They only work in `!active` mode.

General syntax:
```
key[constraint1:value, constraint2:value]:function value
```

---

#### `min` / `max` — Minimum and Maximum

For **numbers** — restricts the value range.  
For **strings** — restricts the length (character count).

```synx
!active

// String from 3 to 30 characters
app_name[min:3, max:30] TotalWario

// Number from 1 to 100
volume[min:1, max:100] 75

// Minimum only
password[min:8] mypassword123
```

---

#### `required` — Required Field

The parser will throw an error if the value is empty or missing.

```synx
!active

api_key[required]:env API_KEY
name[required, min:1] Wario
```

---

#### `pattern` — Regular Expression

The value must match a regex pattern.

```synx
!active

country_code[pattern:^[A-Z]{2}$] US
phone[pattern:^\+\d{10,15}$] +12025551234
```

---

#### `enum` — Allowed Values

The value must be one of the listed options.

```synx
!active

theme[enum:light|dark|auto] dark
region[enum:EU|US|GB|AS] US
```

---

#### `readonly` — Read Only

The value cannot be changed via API / hot-reload of the config. Only manual file editing.

```synx
!active

version[readonly] 2.0.0
```

---

### 3.5 Constraints Summary Table

| Constraint | Description | Syntax |
|---|---|---|
| `min` | Minimum (length or value) | `[min:3]` |
| `max` | Maximum (length or value) | `[max:100]` |
| `type` | Data type | `[type:int]` |
| `required` | Required field | `[required]` |
| `pattern` | Regex validation | `[pattern:^\d+$]` |
| `enum` | List of allowed values | `[enum:a\|b\|c]` |
| `readonly` | Modification forbidden | `[readonly]` |

Constraints can be combined with commas:
```synx
!active
password[required, min:8, max:64, type:string] MyP@ssw0rd
```

---

## 4. Full Examples

### 4.1 Plain File (no `!active`)

A simple static config. No magic — just data.

```synx
# TotalWario game config (static)

app_name TotalWario
version 2.0.0

server
  host 0.0.0.0
  port 8080
  ssl_enabled false

gameplay
  base_hp 100
  boss_hp 500
  max_players 16
  greeting Prepare to fight.

map_rotation
  - Arena of Doom
  - Crystal Caverns
  - Wario Stadium

rules |
  1. No cheating.
  2. Respect the Syndicate.
  3. Have fun!

credits
  lead_dev KaiserBerg
  studio APERTURESyndicate
  year 2026
```

Result (`Synx.parse()`):
```json
{
  "app_name": "TotalWario",
  "version": "2.0.0",
  "server": {
    "host": "0.0.0.0",
    "port": 8080,
    "ssl_enabled": false
  },
  "gameplay": {
    "base_hp": 100,
    "boss_hp": 500,
    "max_players": 16,
    "greeting": "Prepare to fight."
  },
  "map_rotation": [
    "Arena of Doom",
    "Crystal Caverns",
    "Wario Stadium"
  ],
  "rules": "1. No cheating.\n2. Respect the Syndicate.\n3. Have fun!",
  "credits": {
    "lead_dev": "KaiserBerg",
    "studio": "APERTURESyndicate",
    "year": 2026
  }
}
```

---

### 4.2 File with `!active` — Live Config

The same config, but with dynamic functions and validation.

```synx
!active
# Live config for TotalWario

app_name[required, min:3, max:30] TotalWario
version[readonly] 2.0.0

server
  // Port from environment variable, fallback to 8080
  port:env:default:8080 PORT
  host 0.0.0.0
  ssl_enabled false

gameplay
  base_hp 100
  // Engine calculates: 100 * 5 = 500
  boss_hp:calc base_hp * 5
  max_players[type:int, min:2, max:64] 16
  difficulty[enum:easy|normal|hard|nightmare] normal

  // A random phrase on every parse
  greeting:random
    - Welcome to the arena!
    - Prepare to fight.
    - Wario time!

  // Weighted random: common 70%, rare 20%, legendary 10%
  loot_tier:random 70 20 10
    - common
    - rare
    - legendary

map_rotation
  - Arena of Doom
  - Crystal Caverns
  - Wario Stadium

rules |
  1. No cheating.
  2. Respect the Syndicate.
  3. Have fun!

// Include database settings from a separate file
database:include ./db.synx

// Secrets — won't appear in logs
api_key[required]:secret sk-live-abc123def456

credits
  lead_dev KaiserBerg
  studio APERTURESyndicate
  year 2026
  contact:alias lead_dev
```

Result of one `Synx.parse()` call:
```json
{
  "app_name": "TotalWario",
  "version": "2.0.0",
  "server": {
    "port": 8080,
    "host": "0.0.0.0",
    "ssl_enabled": false
  },
  "gameplay": {
    "base_hp": 100,
    "boss_hp": 500,
    "max_players": 16,
    "difficulty": "normal",
    "greeting": "Wario time!",
    "loot_tier": "common"
  },
  "map_rotation": [
    "Arena of Doom",
    "Crystal Caverns",
    "Wario Stadium"
  ],
  "rules": "1. No cheating.\n2. Respect the Syndicate.\n3. Have fun!",
  "database": {
    "host": "localhost",
    "port": 5432,
    "name": "mydb"
  },
  "api_key": "[SECRET]",
  "credits": {
    "lead_dev": "KaiserBerg",
    "studio": "APERTURESyndicate",
    "year": 2026,
    "contact": "KaiserBerg"
  }
}
```

> On the next `parse()` call, `greeting` and `loot_tier` will be different — that's the point of `:random`.

---

## 5. Using in Code — Directly, Without Conversion

> 🚀 **Core Principle:** SYNX is read by your code **directly**. No conversion to JSON is needed. The library parses the `.synx` file itself and returns a native object for your language — `dict` in Python, `Object` in JavaScript. You work with data immediately.

### 5.1 Installation

```bash
# JavaScript / TypeScript
npm install @aperturesyndicate/synx

# Python
pip install synx-format
```

---

### 5.2 Python — Reading `.synx` Directly

```python
from synx import Synx

# Read a .synx file — and get a dict immediately
data = Synx.load('config.synx')

# Done. Data is ready. Work with it like a regular dictionary:
print(data['app_name'])                # "TotalWario"
print(data['server']['port'])          # 8080
print(data['gameplay']['base_hp'])     # 100
print(data['gameplay']['boss_hp'])     # 500 (computed by :calc)
print(data['gameplay']['greeting'])    # "Wario time!" (chosen by :random)

# Lists are regular lists:
for map_name in data['map_rotation']:
    print(f'Loading map: {map_name}')

# Nesting is regular dicts:
if data['server']['ssl_enabled']:
    print('SSL is enabled')
```

**`Synx.load(path)`** — reads the file and parses in one call.  
**`Synx.parse(text)`** — parses a string (if you already have the content).

```python
# Alternatively — from a string:
with open('config.synx', 'r', encoding='utf-8') as f:
    data = Synx.parse(f.read())
```

---

### 5.3 JavaScript — Reading `.synx` Directly

```javascript
const Synx = require('@aperturesyndicate/synx');

// Read a .synx file — get a regular JS object
const data = Synx.loadSync('config.synx');

// Work with it like a normal object using dot notation:
console.log(data.app_name);               // "TotalWario"
console.log(data.server.port);             // 8080
console.log(data.gameplay.base_hp);        // 100
console.log(data.gameplay.boss_hp);        // 500
console.log(data.gameplay.greeting);       // random phrase

// Lists are regular Arrays:
data.map_rotation.forEach(map => {
    console.log(`Loading map: ${map}`);
});

// Destructuring:
const { base_hp, boss_hp, greeting } = data.gameplay;
console.log(`Boss HP: ${boss_hp}, greeting: ${greeting}`);
```

**`Synx.loadSync(path)`** — reads the file and parses synchronously.  
**`Synx.load(path)`** — async version (returns `Promise`).  
**`Synx.parse(text)`** — parses a string.

```javascript
// Async variant:
const data = await Synx.load('config.synx');

// From a string:
const fs = require('fs');
const text = fs.readFileSync('config.synx', 'utf-8');
const data = Synx.parse(text);
```

---

### 5.4 TypeScript — With Type Safety

```typescript
import Synx from '@aperturesyndicate/synx';

// Define the structure of your config:
interface GameConfig {
  app_name: string;
  version: string;
  server: {
    port: number;
    host: string;
    ssl_enabled: boolean;
  };
  gameplay: {
    base_hp: number;
    boss_hp: number;
    greeting: string;
    loot_tier: string;
  };
  map_rotation: string[];
}

// The parser returns a typed object:
const data = Synx.loadSync<GameConfig>('config.synx');

console.log(data.gameplay.boss_hp);  // number — autocomplete works
console.log(data.server.port);       // number
```

---

### 5.5 Using SYNX Data for CSS

SYNX returns a plain object — `Object` in JS, `dict` in Python. You can use this data to generate CSS, CSS custom properties, or pass it into any styling system.

**Example: CSS custom properties from SYNX in Node.js**

```synx
# theme.synx
primary #5a6eff
secondary #ff5a8a
font_size 16
border_radius 8
spacing 12
```

```javascript
const Synx = require('@aperturesyndicate/synx');
const fs = require('fs');

const theme = Synx.loadSync('theme.synx');

// Generate CSS custom properties
const css = `:root {
  --color-primary: ${theme.primary};
  --color-secondary: ${theme.secondary};
  --font-size: ${theme.font_size}px;
  --border-radius: ${theme.border_radius}px;
  --spacing: ${theme.spacing}px;
}`;

fs.writeFileSync('theme.css', css);
```

**Example: Inline styles in React**

```tsx
import Synx from '@aperturesyndicate/synx';

const theme = Synx.loadSync('theme.synx');

function Button({ children }) {
  return (
    <button style={{
      backgroundColor: theme.primary,
      borderRadius: `${theme.border_radius}px`,
      padding: `${theme.spacing}px`,
      fontSize: `${theme.font_size}px`,
    }}>
      {children}
    </button>
  );
}
```

**Example: CSS-in-JS (styled-components, Tailwind config)**

```javascript
// tailwind.config.js
const Synx = require('@aperturesyndicate/synx');
const theme = Synx.loadSync('theme.synx');

module.exports = {
  theme: {
    extend: {
      colors: {
        primary: theme.primary,
        secondary: theme.secondary,
      },
      spacing: {
        base: `${theme.spacing}px`,
      },
    },
  },
};
```

> SYNX doesn't replace CSS — it provides **data** (colors, sizes, tokens) that your code uses
to generate styles. This is especially useful for design systems and theming.

---

### 5.6 Comparison: SYNX Directly vs JSON

| | JSON | SYNX |
|---|---|---|
| **Reading** | `JSON.parse(fs.readFileSync(...))` | `Synx.loadSync('file.synx')` |
| **Intermediate format** | None | None — same! |
| **What you get** | Object / dict | Object / dict (the same thing) |
| **Built-in logic** | No — write it yourself | `:random`, `:calc`, `:env` out of the box |
| **Validation** | No — need a separate lib | `[min:3, type:int]` right in the file |
| **File size** | ~100% | ~40% smaller (no quotes/brackets) |

> The `.synx` format is **not an intermediate format** that needs conversion. It's a **direct data source**, like `.json`, only lighter and smarter.

---

## 6. Conversion to JSON (optional)

> 📎 JSON conversion is an **optional** feature. It's only needed if you want to pass data to a system that exclusively understands JSON (third-party APIs, legacy code, etc.).

### 6.1 Via VS Code (SYNX Extension)

If the **SYNX for VS Code** extension is installed:

1. Open a `.synx` file
2. **Right-click** on the file
3. Select **"Convert to JSON"**
4. A `.json` file will appear alongside

### 6.2 Via Terminal (CLI)

```bash
# Convert to JSON and print to console
synx to-json config.synx

# Convert and save to file
synx to-json config.synx -o config.json

# Freeze an !active config into a static .synx (without functions)
synx freeze active_config.synx -o static_config.synx
```

### 6.3 Programmatically (if you really need to)

```python
import json
from synx import Synx

data = Synx.load('config.synx')
json_string = json.dumps(data, ensure_ascii=False, indent=2)
```

```javascript
const Synx = require('@aperturesyndicate/synx');
const data = Synx.loadSync('config.synx');
const jsonString = JSON.stringify(data, null, 2);
```

> But again: **this is not needed to work with SYNX**. Your code reads `.synx` directly.

---

## 7. Quick Reference

```
KEY VALUE                        → simple pair
key                              → empty object (group)
  nested_key value               → nesting (2 spaces)
key |                            → multiline text
  line 1                           (block)
  line 2
list                             → list
  - item 1
  - item 2
# comment                       → single-line comment
// comment                      → single-line comment

─── Only with !active ──────────────────────────
key:random                       → random item
key:random 70 20 10              → weighted random
key:calc A * B                   → arithmetic
key:env VAR                      → environment variable
key:env:default:X VAR            → env with default
key:alias other_key              → reference to another key
key:secret value                 → hidden value
key:unique                       → list deduplication
key:include ./file.synx          → include file
key[min:N, max:N]                → length/value constraints
key[type:int]                    → data type
key[required]                    → required field
key[enum:a|b|c]                  → allowed values
key[pattern:regex]               → regex validation
key[readonly]                    → read-only
```
