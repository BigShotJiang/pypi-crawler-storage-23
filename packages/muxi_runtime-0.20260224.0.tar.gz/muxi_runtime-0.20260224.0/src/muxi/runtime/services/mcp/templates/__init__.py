from .discovery import MCPTemplateDiscovery

__all__ = [
    "MCPTemplateDiscovery",
]
