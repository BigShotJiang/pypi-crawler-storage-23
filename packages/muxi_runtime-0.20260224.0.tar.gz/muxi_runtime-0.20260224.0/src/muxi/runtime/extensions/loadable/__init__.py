"""Loadable extensions for MUXI runtime."""

__all__ = []
