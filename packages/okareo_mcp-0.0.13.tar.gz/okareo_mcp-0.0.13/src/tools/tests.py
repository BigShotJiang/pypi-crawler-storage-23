"""Test run tools for the Okareo MCP server.

Provides four MCP tools for the core test execution workflow:

- list_checks: Browse available quality checks that can evaluate model outputs
- run_test: Execute a test by evaluating a model against a scenario with checks
- list_test_runs: Browse past test runs with optional filters
- get_test_run_results: Load detailed per-row results of a specific test run
"""

import json
from typing import Optional

from mcp.server.fastmcp import Context, FastMCP
from okareo_api_client.errors import UnexpectedStatus

from src.key_registry import sanitize_error
from src.okareo_client import get_okareo_client, resolve_project_id


def _serialize_datetime(dt) -> Optional[str]:
    """Convert a datetime to ISO format string, handling Unset values."""
    if dt is None or isinstance(dt, type(None)):
        return None
    try:
        return dt.isoformat()
    except (AttributeError, TypeError):
        return None


def _serialize_metrics(metrics) -> Optional[dict]:
    """Convert model metrics to a plain dict, handling Unset values."""
    if metrics is None:
        return None
    try:
        if hasattr(metrics, "additional_properties"):
            return dict(metrics.additional_properties)
        if hasattr(metrics, "to_dict"):
            return metrics.to_dict()
        return None
    except (AttributeError, TypeError):
        return None


def _serialize_value(val):
    """Serialize a value that may be Unset, a complex object, or a primitive."""
    if val is None:
        return None
    # Handle Unset sentinel from the SDK
    if type(val).__name__ == "Unset":
        return None
    if hasattr(val, "additional_properties"):
        return dict(val.additional_properties)
    if hasattr(val, "to_dict"):
        return val.to_dict()
    if isinstance(val, (dict, list, str, int, float, bool)):
        return val
    return str(val)


def _get_attr(obj, attr, default=None):
    """Get an attribute, returning default if Unset."""
    val = getattr(obj, attr, default)
    if type(val).__name__ == "Unset":
        return default
    return val


def register_tools(mcp: FastMCP) -> None:
    """Register all test run tools with the FastMCP server."""

    @mcp.tool()
    def list_checks() -> str:
        """List available quality checks that can be used to evaluate model outputs.

        Returns all checks (both built-in and custom) available in your Okareo account.
        Each check has a name, description, and output type (score or pass_fail).
        Use these check names with run_test to evaluate model quality.
        """
        try:
            okareo = get_okareo_client()
            checks = okareo.get_all_checks()
        except Exception as e:
            return json.dumps({"error": f"Failed to retrieve checks: {e}"})

        if not checks:
            return json.dumps({
                "checks": [],
                "count": 0,
                "message": "No checks available.",
            })

        result = []
        for check in checks:
            result.append({
                "name": _get_attr(check, "name", ""),
                "description": _get_attr(check, "description", ""),
                "output_data_type": _get_attr(check, "output_data_type", ""),
            })

        return json.dumps({"checks": result, "count": len(result)}, default=str)

    @mcp.tool()
    def run_test(
        scenario_name: str,
        model_name: str,
        checks: list[str],
        name: Optional[str] = None,
        type: str = "NL_GENERATION",
        detail_level: str = "aggregate",
        ctx: Context = None,
    ) -> str:
        """Run a quality test that evaluates a model against a scenario using specified checks.

        Executes synchronously — the test runs to completion before returning results.
        By default returns aggregate metrics only (fast, concise). Set detail_level to
        "detailed" to include per-row scores and model inputs/outputs.

        Args:
            scenario_name: Name of the scenario to evaluate against.
            model_name: Name of the registered model to evaluate.
            checks: List of check names to apply (e.g., ["coherence", "relevance"]).
                Use list_checks to discover available checks.
            name: Optional human-readable name for this test run.
            type: Type of evaluation. Defaults to NL_GENERATION. Valid values:
                NL_GENERATION, INFORMATION_RETRIEVAL, MULTI_CLASS_CLASSIFICATION,
                INVARIANT, MULTI_TURN, AGENT_EVAL.
            detail_level: Level of detail in results. "aggregate" (default) returns
                summary metrics only. "detailed" includes per-row scores, model
                inputs/outputs, and error messages.
        """
        # Lazy imports to avoid circular dependencies and keep SDK path setup in okareo_client
        from okareo_api_client.api.default import (
            get_scenario_sets_v0_scenario_sets_get,
        )
        from okareo_api_client.models.find_test_data_point_payload import (
            FindTestDataPointPayload,
        )
        from okareo_api_client.models.test_run_type import TestRunType

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        # Look up scenario by name
        try:
            scenarios = get_scenario_sets_v0_scenario_sets_get.sync(
                client=okareo.client,
                project_id=project_id,
                api_key=okareo.api_key,
            )
        except Exception as e:
            return json.dumps({"error": f"Failed to list scenarios: {e}"})

        scenario = None
        if scenarios and not isinstance(scenarios, Exception):
            for s in scenarios:
                if _get_attr(s, "name") == scenario_name:
                    scenario = s
                    break

        if scenario is None:
            return json.dumps({
                "error": f"Scenario '{scenario_name}' not found. "
                "Use list_scenarios to see available scenarios.",
            })

        # Look up MUT by name
        try:
            mut = okareo.get_model(name=model_name)
        except Exception:
            return json.dumps({
                "error": f"Model '{model_name}' not found. "
                "Use list_models to see registered models.",
            })

        # Validate check names
        try:
            available_checks = okareo.get_all_checks()
            available_names = {
                _get_attr(c, "name") for c in available_checks
            }
        except Exception as e:
            return json.dumps({"error": f"Failed to validate checks: {e}"})

        for check_name in checks:
            if check_name not in available_names:
                return json.dumps({
                    "error": f"Check '{check_name}' not found. "
                    "Use list_checks to see available checks.",
                })

        # Validate test run type
        try:
            test_run_type = TestRunType(type)
        except ValueError:
            valid_types = [t.value for t in TestRunType]
            return json.dumps({
                "error": f"Invalid test run type '{type}'. "
                f"Valid values: {', '.join(valid_types)}.",
            })

        # Get provider keys from lifespan context + SSE headers
        key_registry = {}
        if ctx and hasattr(ctx, "request_context"):
            lifespan_ctx = getattr(ctx.request_context, "lifespan_context", None)
            if lifespan_ctx and isinstance(lifespan_ctx, dict):
                key_registry = dict(lifespan_ctx.get("key_registry", {}))
        # Merge SSE header keys (take precedence over env vars)
        try:
            from src.sse_middleware import sse_provider_keys
            header_keys = sse_provider_keys.get()
            if header_keys:
                key_registry = {**key_registry, **header_keys}
        except (ImportError, LookupError):
            pass

        # Execute test
        run_name = name or f"{scenario_name}-{model_name}"
        try:
            test_kwargs = dict(
                scenario=scenario,
                name=run_name,
                test_run_type=test_run_type,
                checks=checks,
            )
            if key_registry:
                test_kwargs["api_keys"] = key_registry
            test_run = mut.run_test(**test_kwargs)
        except Exception as e:
            return json.dumps({
                "error": sanitize_error(
                    f"Test execution failed: {e}", key_registry
                ),
            })

        # Build aggregate response
        response = {
            "test_run_id": test_run.id,
            "name": _get_attr(test_run, "name", run_name),
            "status": _get_attr(test_run, "status", "UNKNOWN"),
            "type": _get_attr(test_run, "type", type),
            "test_data_point_count": _get_attr(test_run, "test_data_point_count", 0),
            "model_metrics": _serialize_metrics(
                _get_attr(test_run, "model_metrics")
            ),
            "start_time": _serialize_datetime(
                _get_attr(test_run, "start_time")
            ),
            "end_time": _serialize_datetime(_get_attr(test_run, "end_time")),
            "app_link": _get_attr(test_run, "app_link", ""),
        }

        # If detailed, fetch per-row results
        if detail_level == "detailed":
            try:
                data_points = okareo.find_test_data_points(
                    FindTestDataPointPayload(
                        test_run_id=test_run.id,
                        full_data_point=True,
                    )
                )
                if isinstance(data_points, list):
                    response["data_points"] = [
                        {
                            "scenario_input": _serialize_value(
                                _get_attr(dp, "scenario_input")
                            ),
                            "scenario_result": _serialize_value(
                                _get_attr(dp, "scenario_result")
                            ),
                            "model_input": _serialize_value(
                                _get_attr(dp, "model_input")
                            ),
                            "model_result": _serialize_value(
                                _get_attr(dp, "model_result")
                            ),
                            "metric_value": _serialize_value(
                                _get_attr(dp, "metric_value")
                            ),
                            "error_message": _get_attr(dp, "error_message"),
                        }
                        for dp in data_points
                    ]
                    response["data_point_count"] = len(data_points)
                else:
                    response["data_points"] = []
                    response["data_point_count"] = 0
            except Exception as e:
                response["data_points_error"] = (
                    f"Failed to fetch detailed results: {e}"
                )

        return json.dumps(response, default=str)

    @mcp.tool()
    def list_test_runs(
        model_name: Optional[str] = None,
        scenario_name: Optional[str] = None,
        limit: int = 10,
        simulation_only: bool = False,
    ) -> str:
        """List past test runs in the project.

        Returns test run names, IDs, timestamps, status, and summary scores,
        sorted by most recent first. Defaults to the 10 most recent runs.
        Optionally filter by model name, scenario name, or type.

        For simulation runs (type MULTI_TURN), use get_test_run_results with the
        returned test_run_id to retrieve full conversation transcripts and per-turn
        check scores.

        Args:
            model_name: Optional filter — only show test runs using this model.
            scenario_name: Optional filter — only show test runs using this scenario.
            limit: Maximum number of runs to return, sorted by most recent first.
                Defaults to 10. Set to 0 to return all runs.
            simulation_only: When True, return only MULTI_TURN simulation runs.
                Useful for browsing past simulation results without NL_GENERATION or
                other test run types appearing in the list.
        """
        from okareo_api_client.api.default import (
            find_test_run_v0_find_test_runs_post,
            get_scenario_sets_v0_scenario_sets_get,
        )
        from okareo_api_client.models.general_find_payload import GeneralFindPayload
        from okareo_api_client.models.test_run_type import TestRunType

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        # Build filter payload
        payload_kwargs: dict = {
            "project_id": project_id,
            "return_model_metrics": True,
        }

        if simulation_only:
            payload_kwargs["types"] = [TestRunType.MULTI_TURN]

        # Resolve model_name to mut_id if provided
        if model_name is not None:
            try:
                mut = okareo.get_model(name=model_name)
                payload_kwargs["mut_id"] = mut.mut_id
            except Exception:
                return json.dumps({
                    "error": f"Model '{model_name}' not found. "
                    "Use list_models to see registered models.",
                })

        # Resolve scenario_name to scenario_set_id if provided
        if scenario_name is not None:
            try:
                scenarios = get_scenario_sets_v0_scenario_sets_get.sync(
                    client=okareo.client,
                    project_id=project_id,
                    api_key=okareo.api_key,
                )
                scenario_id = None
                if scenarios and not isinstance(scenarios, Exception):
                    for s in scenarios:
                        if _get_attr(s, "name") == scenario_name:
                            scenario_id = _get_attr(s, "scenario_id")
                            break
                if scenario_id is None:
                    return json.dumps({
                        "error": f"Scenario '{scenario_name}' not found. "
                        "Use list_scenarios to see available scenarios.",
                    })
                payload_kwargs["scenario_set_id"] = scenario_id
            except Exception as e:
                return json.dumps({"error": f"Failed to resolve scenario: {e}"})

        # Find test runs
        try:
            payload = GeneralFindPayload(**payload_kwargs)
            runs = find_test_run_v0_find_test_runs_post.sync(
                client=okareo.client,
                json_body=payload,
                api_key=okareo.api_key,
            )
        except UnexpectedStatus as e:
            if e.status_code == 200:
                runs = json.loads(e.content)
            else:
                return json.dumps({"error": f"Failed to list test runs: HTTP {e.status_code}"})
        except Exception as e:
            return json.dumps({"error": f"Failed to list test runs: {e}"})

        if not runs or isinstance(runs, Exception):
            return json.dumps({
                "test_runs": [],
                "count": 0,
                "message": "No test runs found.",
            })

        # Format results — runs may be raw dicts from the low-level API
        result = []
        for run in runs:
            if isinstance(run, dict):
                result.append({
                    "id": run.get("id", ""),
                    "name": run.get("name", ""),
                    "type": run.get("type", ""),
                    "status": run.get("status", ""),
                    "test_data_point_count": run.get("test_data_point_count", 0),
                    "model_metrics": run.get("model_metrics"),
                    "start_time": run.get("start_time"),
                    "end_time": run.get("end_time"),
                    "app_link": run.get("app_link", ""),
                })
            else:
                result.append({
                    "id": _get_attr(run, "id", ""),
                    "name": _get_attr(run, "name", ""),
                    "type": _get_attr(run, "type", ""),
                    "status": _get_attr(run, "status", ""),
                    "test_data_point_count": _get_attr(
                        run, "test_data_point_count", 0
                    ),
                    "model_metrics": _serialize_metrics(
                        _get_attr(run, "model_metrics")
                    ),
                    "start_time": _serialize_datetime(
                        _get_attr(run, "start_time")
                    ),
                    "end_time": _serialize_datetime(
                        _get_attr(run, "end_time")
                    ),
                    "app_link": _get_attr(run, "app_link", ""),
                })

        # Sort by start_time descending (most recent first)
        result.sort(key=lambda r: r.get("start_time") or "", reverse=True)

        # Apply limit (0 = return all)
        if limit > 0:
            result = result[:limit]

        return json.dumps(
            {"test_runs": result, "count": len(result)}, default=str
        )

    @mcp.tool()
    def get_test_run_results(
        test_run_id: Optional[str] = None,
        name: Optional[str] = None,
    ) -> str:
        """Load the detailed results of a specific test run.

        Look up by test run ID (UUID) or by name (returns the most recent run
        matching that name). Returns aggregate metrics and per-row scores for
        each check applied, including model inputs and outputs.

        For simulation runs (type MULTI_TURN), each data point represents one
        full multi-turn conversation. The model_input field contains the complete
        conversation transcript (alternating driver and target messages) and
        model_result contains the final turn's output. Per-turn check evaluations
        are included in metric_value.

        Args:
            test_run_id: The UUID of the test run. Takes precedence over name.
            name: The name of the test run. Returns the most recent match.
        """
        from okareo_api_client.api.default import (
            find_test_run_v0_find_test_runs_post,
        )
        from okareo_api_client.models.find_test_data_point_payload import (
            FindTestDataPointPayload,
        )
        from okareo_api_client.models.general_find_payload import GeneralFindPayload

        if not test_run_id and not name:
            return json.dumps({
                "error": "Provide either test_run_id or name to look up a test run.",
            })

        try:
            okareo = get_okareo_client()
            project_id = resolve_project_id(okareo)
        except Exception as e:
            return json.dumps({"error": str(e)})

        resolved_id = test_run_id
        run_metadata = None

        # If looking up by name, resolve to most recent test run
        if not test_run_id and name:
            try:
                payload = GeneralFindPayload(
                    project_id=project_id,
                    return_model_metrics=True,
                )
                runs = find_test_run_v0_find_test_runs_post.sync(
                    client=okareo.client,
                    json_body=payload,
                    api_key=okareo.api_key,
                )
            except UnexpectedStatus as e:
                if e.status_code == 200:
                    runs = json.loads(e.content)
                else:
                    return json.dumps({"error": f"Failed to search test runs: HTTP {e.status_code}"})
            except Exception as e:
                return json.dumps({"error": f"Failed to search test runs: {e}"})

            if not runs or isinstance(runs, Exception):
                return json.dumps({
                    "error": f"No test run named '{name}' found. "
                    "Use list_test_runs to find available test runs.",
                })

            # Filter by name and find most recent
            matching = []
            for run in runs:
                if isinstance(run, dict):
                    run_name = run.get("name", "")
                    if run_name == name:
                        matching.append(run)
                else:
                    run_name = _get_attr(run, "name", "")
                    if run_name == name:
                        matching.append(run)

            if not matching:
                return json.dumps({
                    "error": f"No test run named '{name}' found. "
                    "Use list_test_runs to find available test runs.",
                })

            # Sort by start_time descending, take most recent
            def _get_start_time(r):
                if isinstance(r, dict):
                    return r.get("start_time", "")
                return str(_get_attr(r, "start_time", ""))

            matching.sort(key=_get_start_time, reverse=True)
            best = matching[0]

            if isinstance(best, dict):
                resolved_id = best.get("id", "")
                run_metadata = best
            else:
                resolved_id = _get_attr(best, "id", "")
                run_metadata = {
                    "id": _get_attr(best, "id", ""),
                    "name": _get_attr(best, "name", ""),
                    "type": _get_attr(best, "type", ""),
                    "status": _get_attr(best, "status", ""),
                    "test_data_point_count": _get_attr(
                        best, "test_data_point_count", 0
                    ),
                    "model_metrics": _serialize_metrics(
                        _get_attr(best, "model_metrics")
                    ),
                    "start_time": _serialize_datetime(
                        _get_attr(best, "start_time")
                    ),
                    "end_time": _serialize_datetime(
                        _get_attr(best, "end_time")
                    ),
                    "app_link": _get_attr(best, "app_link", ""),
                }

        # If we have a test_run_id but no metadata yet, fetch it
        if run_metadata is None:
            try:
                payload = GeneralFindPayload(
                    id=resolved_id,
                    project_id=project_id,
                    return_model_metrics=True,
                )
                try:
                    runs = find_test_run_v0_find_test_runs_post.sync(
                        client=okareo.client,
                        json_body=payload,
                        api_key=okareo.api_key,
                    )
                except UnexpectedStatus as ue:
                    runs = json.loads(ue.content) if ue.status_code == 200 else None
                if runs and not isinstance(runs, Exception) and len(runs) > 0:
                    r = runs[0]
                    if isinstance(r, dict):
                        run_metadata = r
                    else:
                        run_metadata = {
                            "id": _get_attr(r, "id", ""),
                            "name": _get_attr(r, "name", ""),
                            "type": _get_attr(r, "type", ""),
                            "status": _get_attr(r, "status", ""),
                            "test_data_point_count": _get_attr(
                                r, "test_data_point_count", 0
                            ),
                            "model_metrics": _serialize_metrics(
                                _get_attr(r, "model_metrics")
                            ),
                            "start_time": _serialize_datetime(
                                _get_attr(r, "start_time")
                            ),
                            "end_time": _serialize_datetime(
                                _get_attr(r, "end_time")
                            ),
                            "app_link": _get_attr(r, "app_link", ""),
                        }
                else:
                    return json.dumps({
                        "error": f"Test run with ID '{test_run_id}' not found. "
                        "Use list_test_runs to find available test runs.",
                    })
            except Exception as e:
                return json.dumps({
                    "error": f"Failed to fetch test run metadata: {e}",
                })

        # Fetch per-row data points
        try:
            data_points = okareo.find_test_data_points(
                FindTestDataPointPayload(
                    test_run_id=resolved_id,
                    full_data_point=True,
                )
            )
        except Exception as e:
            return json.dumps({
                "error": f"Failed to fetch test run results: {e}",
            })

        dp_list = []
        if isinstance(data_points, list):
            for dp in data_points:
                dp_list.append({
                    "scenario_input": _serialize_value(
                        _get_attr(dp, "scenario_input")
                    ),
                    "scenario_result": _serialize_value(
                        _get_attr(dp, "scenario_result")
                    ),
                    "model_input": _serialize_value(
                        _get_attr(dp, "model_input")
                    ),
                    "model_result": _serialize_value(
                        _get_attr(dp, "model_result")
                    ),
                    "metric_value": _serialize_value(
                        _get_attr(dp, "metric_value")
                    ),
                    "error_message": _get_attr(dp, "error_message"),
                })

        response = {
            "test_run": run_metadata,
            "data_points": dp_list,
            "data_point_count": len(dp_list),
        }

        return json.dumps(response, default=str)

    return None
