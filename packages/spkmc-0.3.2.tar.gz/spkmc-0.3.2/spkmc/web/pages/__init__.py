"""
SPKMC Web Interface Pages.

This package contains the individual page modules for the Streamlit web interface.
"""

__all__ = ["dashboard", "experiment_detail", "settings"]
