"""Tests for SPKMC web interface."""
