"""End-to-end tests for the SPKMC web interface."""
