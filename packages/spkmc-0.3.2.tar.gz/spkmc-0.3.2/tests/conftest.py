"""Pytest configuration."""

import os

os.environ.setdefault("MPLBACKEND", "Agg")
