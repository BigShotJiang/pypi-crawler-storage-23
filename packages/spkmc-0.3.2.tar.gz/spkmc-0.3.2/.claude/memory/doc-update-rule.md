# Documentation Update Rule

**ALWAYS update documentation when modifying CLI commands, options, or behavior.**

## Checklist

When changing CLI:
1. `README.md` - Command reference tables
2. `docs/usage.md` - Detailed usage documentation
3. `CLAUDE.md` - If it affects project architecture or quick commands

## Files to check for CLI changes

- `README.md` - Look for option tables and examples
- `docs/usage.md` - Comprehensive CLI documentation
- Test files - Update test cases that use modified options
