//! Error type for the libxrk core crate.

use std::fmt;

/// Errors that can occur during XRK file parsing and processing.
#[derive(Debug)]
pub enum Error {
    /// I/O error reading the file.
    Io(std::io::Error),
    /// Decompression failed (XRZ files).
    Decompression(String),
    /// Invalid or corrupt data in the XRK stream.
    InvalidData(String),
    /// Arrow conversion error (only with `arrow` feature).
    #[cfg(feature = "arrow")]
    Arrow(arrow::error::ArrowError),
}

impl fmt::Display for Error {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Error::Io(e) => write!(f, "I/O error: {}", e),
            Error::Decompression(msg) => write!(f, "decompression error: {}", msg),
            Error::InvalidData(msg) => write!(f, "invalid data: {}", msg),
            #[cfg(feature = "arrow")]
            Error::Arrow(e) => write!(f, "Arrow error: {}", e),
        }
    }
}

impl std::error::Error for Error {
    fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
        match self {
            Error::Io(e) => Some(e),
            #[cfg(feature = "arrow")]
            Error::Arrow(e) => Some(e),
            _ => None,
        }
    }
}

impl From<std::io::Error> for Error {
    fn from(e: std::io::Error) -> Self {
        Error::Io(e)
    }
}

#[cfg(feature = "arrow")]
impl From<arrow::error::ArrowError> for Error {
    fn from(e: arrow::error::ArrowError) -> Self {
        Error::Arrow(e)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_display_invalid_data() {
        let e = Error::InvalidData("bad stuff".into());
        assert_eq!(e.to_string(), "invalid data: bad stuff");
    }

    #[test]
    fn test_display_decompression() {
        let e = Error::Decompression("corrupt".into());
        assert_eq!(e.to_string(), "decompression error: corrupt");
    }

    #[test]
    fn test_display_io() {
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "gone");
        let e = Error::from(io_err);
        assert!(e.to_string().starts_with("I/O error:"));
    }

    #[test]
    fn test_source_io() {
        use std::error::Error as StdError;
        let io_err = std::io::Error::new(std::io::ErrorKind::NotFound, "gone");
        let e = Error::from(io_err);
        assert!(e.source().is_some());
    }

    #[test]
    fn test_source_invalid_data() {
        use std::error::Error as StdError;
        let e = Error::InvalidData("test".into());
        assert!(e.source().is_none());
    }
}
