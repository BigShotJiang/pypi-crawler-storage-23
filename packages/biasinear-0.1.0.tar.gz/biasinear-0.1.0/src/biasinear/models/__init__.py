"""Model interfaces for BiasInEar."""

from biasinear.models.base import BaseModel

__all__ = ["BaseModel"]
