"""MCPFind: Context-efficient MCP tool proxy with semantic search."""

__version__ = "0.2.0"
