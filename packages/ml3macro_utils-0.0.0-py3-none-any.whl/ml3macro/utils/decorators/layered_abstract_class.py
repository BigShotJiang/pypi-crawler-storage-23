from typing import Any, Callable, TypeVar

T = TypeVar("T")


def layered_abstract_class(base_class: type[T]) -> type[T]:
    """
    Decorator to enforce that concrete classes cannot inherit directly from the base class.
    They must inherit from an intermediate abstract class.

    Args:
        base_class: The base class that should only be inherited by abstract classes

    Returns:
        The same base class with the enforcement logic added
    """
    original_init_subclass: Callable[..., None] | None = getattr(
        base_class, "__init_subclass__", None
    )

    def decorator_error(s: str, /) -> TypeError:
        return TypeError(f"[@{layered_abstract_class.__name__}]: {s}")

    def __init_subclass__(cls: type, **kwargs: Any) -> None:
        # Call original __init_subclass__ if it exists
        if original_init_subclass:
            original_init_subclass(**kwargs)

        # Check if base_class is a direct parent
        if base_class in cls.__bases__:
            # Check if the class is abstract by looking for any unimplemented abstract methods
            # in the entire inheritance chain (excluding object)
            has_unimplemented_abstract_methods = False

            # Get all abstract methods from the inheritance chain
            all_abstract_methods = set()
            for base in cls.__mro__[1:]:  # Skip the class itself
                if base is object:
                    continue
                if hasattr(base, "__abstractmethods__"):
                    all_abstract_methods.update(base.__abstractmethods__)

            # Check if any of these abstract methods are still unimplemented in cls
            if all_abstract_methods:
                # Get the methods that cls has implemented
                implemented_methods = set()
                for name in all_abstract_methods:
                    if name in cls.__dict__ and not getattr(
                        cls.__dict__[name], "__isabstractmethod__", False
                    ):
                        implemented_methods.add(name)

                # If there are still unimplemented abstract methods, the class is abstract
                if all_abstract_methods - implemented_methods:
                    has_unimplemented_abstract_methods = True

            if not has_unimplemented_abstract_methods:
                raise decorator_error(
                    f"{cls.__name__} cannot inherit directly from {base_class.__name__}. "
                    "It must inherit from an intermediate abstract class."
                )

    # Add the __init_subclass__ method to the base class
    # We use setattr to avoid mypy's method assignment complaints
    setattr(base_class, "__init_subclass__", classmethod(__init_subclass__))
    return base_class
