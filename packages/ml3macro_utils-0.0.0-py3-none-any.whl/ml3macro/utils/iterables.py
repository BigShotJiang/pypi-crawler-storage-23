from itertools import tee
from typing import Callable, Iterable, TypeVar

Item = TypeVar("Item")


# TODO: WRITE UNIT TESTS
def partition(
    iterable: Iterable[Item], /, *, condition: Callable[[Item], bool]
) -> tuple[Iterable[Item], Iterable[Item]]:
    t1, t2 = tee(iterable)
    return filter(condition, t1), filter(lambda x: not condition(x), t2)
