"""TcEx Framework Module"""

__license__ = 'Apache-2.0'
__version__ = '4.0.10'
