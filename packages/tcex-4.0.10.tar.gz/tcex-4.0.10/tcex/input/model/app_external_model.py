"""TcEx Framework Module"""

# first-party
from tcex.input.model.common_model import CommonModel


class AppExternalModel(CommonModel):
    """Model Definition"""
