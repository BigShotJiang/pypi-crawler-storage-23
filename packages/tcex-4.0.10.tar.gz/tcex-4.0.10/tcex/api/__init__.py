"""TcEx Framework Module"""
