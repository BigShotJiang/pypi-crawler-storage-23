"""TcEx Framework Module"""

# first-party
from tcex.api.tc.v2.v2 import V2

__all__ = ['V2']
