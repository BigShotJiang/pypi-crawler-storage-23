"""Shared infrastructure for UKAM OS builder pipelines."""
