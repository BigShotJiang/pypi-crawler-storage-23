class ToFlatfileError(Exception):
    """Error during flatfile transformation."""


class PipelineError(Exception):
    """Error during pipeline execution."""
