"""Transform stages for ABP data."""
