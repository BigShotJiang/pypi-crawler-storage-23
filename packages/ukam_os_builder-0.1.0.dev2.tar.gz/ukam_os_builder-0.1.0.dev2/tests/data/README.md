# Test CSV Fixtures

The rows in this folder are based on example records from:
https://docs.os.uk/os-downloads/products/addresses-and-names-portfolio/addressbase-premium/addressbase-premium-technical-specification/example-records/csv
