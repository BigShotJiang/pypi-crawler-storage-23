"""
Slack-specific functionality.
"""

from .monitor import SlackRoomMonitor

__all__ = ["SlackRoomMonitor"]
