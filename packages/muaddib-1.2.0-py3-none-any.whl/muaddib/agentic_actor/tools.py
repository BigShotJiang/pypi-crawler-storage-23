"""Tool definitions and executors for AI agent."""

from __future__ import annotations

import asyncio
import base64
import logging
import random
import re
import time
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any, TypedDict
from urllib.parse import parse_qs, quote, unquote, urlparse

import aiohttp
from ddgs import DDGS

from ..chronicler.tools import (
    ChapterAppendExecutor,
    ChapterRenderExecutor,
    QuestSnoozeExecutor,
    QuestStartExecutor,
    SubquestStartExecutor,
)

logger = logging.getLogger(__name__)


_ARTIFACT_INDEX_HTML = Path(__file__).with_name("artifact_viewer.html").read_text(encoding="utf-8")


def _extract_filename_from_query(query: str) -> str | None:
    """Extract artifact filename from query string."""
    if not query:
        return None

    if "=" in query:
        params = parse_qs(query)
        for key in ("file", "filename"):
            values = params.get(key)
            if values:
                value = values[0].strip()
                if value:
                    return unquote(value)
        return None

    value = query.strip()
    return unquote(value) if value else None


def _extract_local_artifact_path(url: str, artifacts_url: str) -> str | None:
    """Extract local artifact relative path from raw or viewer URL."""
    base = artifacts_url.rstrip("/")
    if not (url == base or url.startswith(base + "/") or url.startswith(base + "?")):
        return None

    remainder = url[len(base) :]
    if remainder.startswith("/"):
        remainder = remainder[1:]

    if remainder.startswith("?"):
        return _extract_filename_from_query(remainder[1:])

    if remainder.startswith("index.html?"):
        return _extract_filename_from_query(remainder[len("index.html?") :])

    if "?" in remainder:
        path_part, query = remainder.split("?", 1)
        if path_part == "index.html":
            return _extract_filename_from_query(query)

    if not remainder:
        return None

    return unquote(remainder)


def _extract_filename_from_url(url: str) -> str | None:
    """Extract filename from generic URL, including viewer-style query URLs."""
    parsed = urlparse(url)

    filename = _extract_filename_from_query(parsed.query)
    if filename:
        return filename

    path = unquote(parsed.path)
    if not path or path.endswith("/"):
        return None

    leaf = path.rsplit("/", 1)[-1]
    if leaf == "index.html":
        return None
    return leaf


def _to_artifact_viewer_url(base_url: str, filename: str) -> str:
    """Build artifact viewer URL in /?filename format."""
    return f"{base_url.rstrip('/')}/?{quote(filename, safe='')}"


def _ensure_artifacts_dir(path: Path) -> None:
    """Create artifacts directory and install artifact viewer index.html."""
    path.mkdir(parents=True, exist_ok=True)
    index_file = path / "index.html"

    current = index_file.read_text(encoding="utf-8") if index_file.exists() else None
    if current != _ARTIFACT_INDEX_HTML:
        index_file.write_text(_ARTIFACT_INDEX_HTML, encoding="utf-8")


def resolve_http_headers(url: str, secrets: dict[str, Any] | None) -> dict[str, str]:
    """Resolve HTTP headers for a URL from the secrets dict."""
    headers = {"User-Agent": "muaddib/1.0"}
    if not secrets:
        return headers

    extra_headers: dict[str, str] = {}
    exact = secrets.get("http_headers") if isinstance(secrets, dict) else None
    if isinstance(exact, dict):
        candidate = exact.get(url)
        if isinstance(candidate, dict):
            extra_headers = candidate

    if not extra_headers:
        prefixes = secrets.get("http_header_prefixes") if isinstance(secrets, dict) else None
        if isinstance(prefixes, dict):
            for prefix, candidate in prefixes.items():
                if url.startswith(prefix) and isinstance(candidate, dict):
                    extra_headers = candidate
                    break

    headers.update(extra_headers)
    return headers


def generate_artifact_id(length: int = 8) -> str:
    """Generate a random base62 artifact ID."""
    BASE62_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    return "".join(random.choices(BASE62_ALPHABET, k=length))


async def fetch_image_b64(
    session: aiohttp.ClientSession,
    url: str,
    max_size: int,
    timeout: int = 30,
    headers: dict[str, str] | None = None,
) -> tuple[str, str]:
    """
    Fetch an image from URL and return (content_type, base64_string).
    Raises ValueError if not an image, too large, or fetch fails.
    """
    async with session.head(
        url,
        timeout=aiohttp.ClientTimeout(total=timeout),
        headers=headers or {"User-Agent": "muaddib/1.0"},
    ) as head_response:
        content_type = head_response.headers.get("content-type", "").lower()
        if not content_type.startswith("image/"):
            raise ValueError(f"URL is not an image (content-type: {content_type})")

    async with session.get(
        url,
        timeout=aiohttp.ClientTimeout(total=timeout),
        headers=headers or {"User-Agent": "muaddib/1.0"},
        max_line_size=8190 * 2,
        max_field_size=8190 * 2,
    ) as response:
        response.raise_for_status()

        content_length = response.headers.get("content-length")
        if content_length and int(content_length) > max_size:
            raise ValueError(
                f"Image too large ({content_length} bytes). Maximum allowed: {max_size} bytes"
            )

        image_data = await response.read()
        if len(image_data) > max_size:
            raise ValueError(
                f"Image too large ({len(image_data)} bytes). Maximum allowed: {max_size} bytes"
            )

        image_b64 = base64.b64encode(image_data).decode()
        logger.info(
            f"Downloaded image from {url}, content-type: {content_type}, size: {len(image_data)} bytes"
        )
        return (content_type, image_b64)


class Tool(TypedDict):
    """Tool definition schema."""

    name: str
    description: str
    input_schema: dict
    persist: str  # "none", "exact", "summary", or "artifact"


# Available tools for AI agent
TOOLS: list[Tool] = [
    {
        "name": "web_search",
        "description": "Search the web and return top results with titles, URLs, and descriptions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The search query to perform. Never use \\u unicode escapes.",
                }
            },
            "required": ["query"],
        },
        "persist": "summary",
    },
    {
        "name": "visit_webpage",
        "description": "Visit the given URL and return its content as markdown text if HTML website, or picture if an image URL (or raw if an artifact).",
        "input_schema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "format": "uri",
                    "description": "The URL of the webpage to visit or artifact to load.",
                }
            },
            "required": ["url"],
        },
        "persist": "summary",
    },
    {
        "name": "execute_code",
        "description": "Execute code in a sandbox environment and return the output. The sandbox environment is persisted to follow-up calls of this tool within this thread. Use /workspace/ to store files that should persist across conversations. Use output_files to download any generated files from the sandbox.",
        "input_schema": {
            "type": "object",
            "properties": {
                "code": {
                    "type": "string",
                    "description": "The code to execute in the sandbox. Each execution is auto-saved to /tmp/_v{n}.py (or .sh for bash) - the exact path is returned in the response. You can re-run previous code with 'python /tmp/_v1.py' after fixing issues (e.g., pip install missing module).",
                },
                "language": {
                    "type": "string",
                    "enum": ["python", "bash"],
                    "default": "python",
                    "description": "The language to execute the code in.",
                },
                "input_artifacts": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of artifact URLs to download into the sandbox at /artifacts/ before execution (e.g., ['https://example.com/artifacts/?abc123.csv'] -> /artifacts/abc123.csv).",
                },
                "output_files": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional list of file paths in the sandbox to download and share as artifacts (e.g., ['/tmp/report.csv']).",
                },
            },
            "required": ["code"],
        },
        "persist": "artifact",
    },
    {
        "name": "progress_report",
        "description": "Send a brief one-line progress update to the user.",
        "input_schema": {
            "type": "object",
            "properties": {
                "text": {
                    "type": "string",
                    "description": "One-line progress update. Keep it super concise, but very casual and even snarky in line with your instructions and previous conversation.",
                }
            },
            "required": ["text"],
        },
        "persist": "none",
    },
    {
        "name": "final_answer",
        "description": "Provide the final answer to the user's question. This tool MUST be used when the agent is ready to give its final response.",
        "input_schema": {
            "type": "object",
            "properties": {
                "answer": {
                    "type": "string",
                    "description": "The final answer or response to the user's question. Start with final deliberation in <thinking>...</thinking>. Never say 'you are doing something' or 'you will do something' - at this point, you are *done*. Cite your sources; if you have produced some artifacts (even side-effect artifacts from e.g. execute_code), do not forget to link them.",
                }
            },
            "required": ["answer"],
        },
        "persist": "none",
    },
    {
        "name": "make_plan",
        "description": "Consider different approaches and formulate a brief research and/or execution plan. Only use this tool if research or code execution seems necessary. Can only be called alongside final_answer if quest_start or subquest_start is also present.",
        "input_schema": {
            "type": "object",
            "properties": {
                "plan": {
                    "type": "string",
                    "description": "A brief research and/or execution plan to handle the user's request, outlining (a) concerns and key goals that require further actions before responding, (b) the key steps and approach how to address them.",
                }
            },
            "required": ["plan"],
        },
        "persist": "none",
    },
    {
        "name": "share_artifact",
        "description": "Share an additional artifact (created script, detailed report, supporting data). The content is made available on a public link that is returned by the tool. Use this only for additional content that doesn't fit into your standard IRC message response (or when explicitly requested).",
        "input_schema": {
            "type": "object",
            "properties": {
                "content": {
                    "type": "string",
                    "description": "The content of the artifact to share (script, report, detailed data, etc.).",
                }
            },
            "required": ["content"],
        },
        "persist": "none",
    },
    {
        "name": "edit_artifact",
        "description": "Edit an existing artifact by replacing a unique (exactly one) occurrence of old_string with new_string, creating a new derived artifact in the process. The new artifact is shared in return value of the tool.",
        "input_schema": {
            "type": "object",
            "properties": {
                "artifact_url": {
                    "type": "string",
                    "format": "uri",
                    "description": "The URL of the artifact to edit (from a previous share_artifact or visit_webpage call).",
                },
                "old_string": {
                    "type": "string",
                    "description": "The text to find and replace, which must match exactly, even whitespaces perfectly. Include enough surrounding context (3-5 lines) to ensure uniqueness.",
                },
                "new_string": {
                    "type": "string",
                    "description": "The text to replace old_string with. Can be empty to delete text.",
                },
            },
            "required": ["artifact_url", "old_string", "new_string"],
        },
        "persist": "artifact",
    },
    {
        "name": "generate_image",
        "description": "Generate image(s) using {tools.image_gen.model} on OpenRouter - use for creating or editing pictures, photos, diagrams, visualizations, etc. Optionally provide reference image URLs for editing/variations.",
        "input_schema": {
            "type": "object",
            "properties": {
                "prompt": {
                    "type": "string",
                    "description": "Text description of the image to generate.",
                },
                "image_urls": {
                    "type": "array",
                    "items": {"type": "string", "format": "uri"},
                    "description": "Optional list of reference image URLs to include as input for editing or creating variations.",
                },
            },
            "required": ["prompt"],
        },
        "persist": "artifact",
    },
    {
        "name": "oracle",
        "description": "Consult the oracle - a more powerful reasoning model that may be consulted for complex analysis and creative work. Invoke it whenever it would be helpful to get deep advice on complex problems or produce a high quality creative piece.",
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "The question or task for the oracle. Be extremely specific about what analysis, plan, or solution you need. The Oracle will get access to the chat context, but not to your progress made on the last request so far.",
                },
            },
            "required": ["query"],
        },
        "persist": "none",
    },
]


class RateLimiter:
    """Simple rate limiter for tool calls."""

    def __init__(self, max_calls_per_second: float = 1.0):
        self.max_calls_per_second = max_calls_per_second
        self.min_interval = 1.0 / max_calls_per_second if max_calls_per_second > 0 else 0.0
        self.last_call_time = 0.0

    async def wait_if_needed(self):
        """Wait if needed to respect rate limit."""
        if self.min_interval <= 0:
            return

        now = time.time()
        elapsed = now - self.last_call_time
        if elapsed < self.min_interval:
            wait_time = self.min_interval - elapsed
            await asyncio.sleep(wait_time)
        self.last_call_time = time.time()


class BraveSearchExecutor:
    """Async Brave Search API executor."""

    def __init__(self, api_key: str, max_results: int = 5, max_calls_per_second: float = 1.0):
        self.api_key = api_key
        self.max_results = max_results
        self.rate_limiter = RateLimiter(max_calls_per_second)

    async def execute(self, query: str) -> str:
        """Execute Brave search and return formatted results."""
        await self.rate_limiter.wait_if_needed()

        url = "https://api.search.brave.com/res/v1/web/search"
        headers = {
            "Accept": "application/json",
            "Accept-Encoding": "gzip",
            "X-Subscription-Token": self.api_key,
        }
        params = {
            "q": query,
            "count": self.max_results,
        }

        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(url, headers=headers, params=params) as response:
                    response.raise_for_status()
                    data = await response.json()

                    results = data.get("web", {}).get("results", [])
                    logger.info(f"Brave searching '{query}': {len(results)} results")

                    if not results:
                        return "No search results found. Try a different query."

                    # Format results as markdown
                    formatted_results = []
                    for result in results:
                        title = result.get("title", "No title")
                        url = result.get("url", "#")
                        description = result.get("description", "No description")
                        formatted_results.append(f"[{title}]({url})\n{description}")

                    return "## Search Results\n\n" + "\n\n".join(formatted_results)

            except Exception as e:
                logger.error(f"Brave search failed: {e}")
                return f"Search failed: {e}"


class WebSearchExecutor:
    """Async ddgs web search executor."""

    def __init__(
        self, max_results: int = 10, max_calls_per_second: float = 1.0, backend: str = "auto"
    ):
        self.max_results = max_results
        self.rate_limiter = RateLimiter(max_calls_per_second)
        self.backend = backend

    async def execute(self, query: str) -> str:
        """Execute web search and return formatted results."""
        await self.rate_limiter.wait_if_needed()

        # Note: DDGS is not async, so we run it in executor
        loop = asyncio.get_event_loop()
        with DDGS() as ddgs:
            results = await loop.run_in_executor(
                None,
                lambda: list(ddgs.text(query, max_results=self.max_results, backend=self.backend)),
            )

        logger.info(f"Searching '{query}': {len(results)} results")

        if not results:
            return "No search results found. Try a different query."

        # Format results as markdown
        formatted_results = []
        for result in results:
            title = result.get("title", "No title")
            url = result.get("href", "#")
            body = result.get("body", "No description")
            formatted_results.append(f"[{title}]({url})\n{body}")

        return "## Search Results\n\n" + "\n\n".join(formatted_results)


class JinaSearchExecutor:
    """Async Jina.ai search executor."""

    def __init__(
        self, max_results: int = 10, max_calls_per_second: float = 1.0, api_key: str | None = None
    ):
        self.max_results = max_results
        self.rate_limiter = RateLimiter(max_calls_per_second)
        self.api_key = api_key

    async def execute(self, query: str, **kwargs) -> str:
        """Execute Jina search and return formatted results."""
        await self.rate_limiter.wait_if_needed()

        warning_prefix = ""
        if kwargs:
            logger.warning(f"JinaSearchExecutor received unsupported arguments: {kwargs}")
            warning_prefix = (
                f"Warning: The following parameters were ignored: {', '.join(kwargs.keys())}\n\n"
            )

        url = "https://s.jina.ai/?q=" + query
        headers = {
            "User-Agent": "muaddib/1.0",
            "X-Respond-With": "no-content",
            "Accept": "text/plain",
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        async with aiohttp.ClientSession() as session:
            try:
                async with session.get(
                    url,
                    headers=headers,
                    timeout=aiohttp.ClientTimeout(total=30),
                ) as response:
                    content = (await response.text()).strip()

                    if (
                        response.status == 422
                        and "No search results available for query" in content
                    ):
                        logger.info(f"Jina searching '{query}': no results")
                        return f"{warning_prefix}No search results found. Try a different query."

                    if response.status >= 400:
                        logger.error(
                            f"Jina search failed with HTTP {response.status}: {content[:300]}"
                        )
                        return (
                            f"{warning_prefix}Search failed: Jina HTTP {response.status}: {content}"
                        )

                    logger.info(f"Jina searching '{query}': retrieved search results")

                    if not content:
                        return f"{warning_prefix}No search results found. Try a different query."

                    return f"{warning_prefix}## Search Results\n\n{content}"

            except Exception as e:
                logger.error(f"Jina search failed: {e}")
                return f"{warning_prefix}Search failed: {e}"


class WebpageVisitorExecutor:
    """Async webpage visitor and content extractor."""

    def __init__(
        self,
        max_content_length: int = 40000,
        timeout: int = 60,
        max_image_size: int = 3_500_000,
        progress_callback: Any | None = None,
        api_key: str | None = None,
        artifact_store: ArtifactStore | None = None,
        secrets: dict[str, Any] | None = None,
    ):
        self.max_content_length = max_content_length
        self.timeout = timeout
        self.max_image_size = max_image_size  # 5MB default limit post base64 encode
        self.progress_callback = progress_callback
        self.api_key = api_key
        self.artifact_store = artifact_store
        self.secrets = secrets

    async def execute(self, url: str) -> str | list[dict]:
        """Visit webpage and return content as markdown, or image data for images."""
        logger.info(f"Visiting {url}")

        # Basic URL validation
        if not url.startswith(("http://", "https://")):
            raise ValueError("Invalid URL. Must start with http:// or https://")

        # Check if this is a local artifact we can access directly
        if (
            self.artifact_store
            and self.artifact_store.artifacts_url
            and self.artifact_store.artifacts_path
            and (filename := _extract_local_artifact_path(url, self.artifact_store.artifacts_url))
        ):
            # Direct file system access for local artifacts
            logger.info(f"Using direct filesystem access for local artifact: {url}")
            filepath = self.artifact_store.artifacts_path / filename

            # Resolve paths and validate no path traversal
            try:
                # Resolve paths (non-strict to catch traversal even if target doesn't exist)
                resolved_path = filepath.resolve()
                artifacts_base = self.artifact_store.artifacts_path.resolve()

                # Validate containment
                if not resolved_path.is_relative_to(artifacts_base):
                    raise ValueError("Path traversal detected")

                # Check existence after validating path
                if not resolved_path.exists():
                    raise ValueError("Artifact file not found")

                # Check if it's an image file
                suffix = resolved_path.suffix.lower()
                if suffix in (".png", ".jpg", ".jpeg", ".gif", ".webp"):
                    file_size = resolved_path.stat().st_size
                    if file_size > self.max_image_size:
                        raise ValueError(f"Image too large: {file_size} bytes")
                    image_data = resolved_path.read_bytes()
                    media_type = {
                        ".png": "image/png",
                        ".jpg": "image/jpeg",
                        ".jpeg": "image/jpeg",
                        ".gif": "image/gif",
                        ".webp": "image/webp",
                    }[suffix]
                    logger.info(f"Read local image artifact: {filename}")
                    return [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": media_type,
                                "data": base64.b64encode(image_data).decode(),
                            },
                        }
                    ]

                # Text file handling
                file_size = resolved_path.stat().st_size
                if file_size > self.max_content_length:
                    content = resolved_path.read_text(encoding="utf-8")[: self.max_content_length]
                    logger.warning(
                        f"Local artifact truncated from {file_size} to {self.max_content_length}"
                    )
                    return content + "\n\n..._Content truncated_..."
                else:
                    content = resolved_path.read_text(encoding="utf-8")

                logger.info(f"Read local artifact: {filename}")
                return content
            except Exception as e:
                logger.error(f"Failed to read local artifact '{filename}': {e}")
                raise ValueError(f"Failed to read artifact: {e}") from e

        headers = resolve_http_headers(url, self.secrets)
        has_auth_headers = any(key.lower() != "user-agent" for key in headers)

        async with aiohttp.ClientSession() as session:
            # First, check the original URL for content-type to detect images
            async with session.head(
                url,
                timeout=aiohttp.ClientTimeout(total=self.timeout),
                headers=headers,
            ) as head_response:
                content_type = head_response.headers.get("content-type", "").lower()

                if content_type.startswith("image/"):
                    try:
                        content_type, image_b64 = await fetch_image_b64(
                            session,
                            url,
                            self.max_image_size,
                            self.timeout,
                            headers=headers,
                        )
                        # Return Anthropic content blocks with image
                        return [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": content_type,
                                    "data": image_b64,
                                },
                            }
                        ]
                    except ValueError as e:
                        return f"Error: {e}"

            # Handle text/HTML content - use direct fetch when auth headers are needed
            if has_auth_headers:
                async with session.get(
                    url,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                    headers=headers,
                    max_line_size=8190 * 2,
                    max_field_size=8190 * 2,
                ) as response:
                    response.raise_for_status()
                    content_type = response.headers.get("content-type", "").lower()
                    data = await response.read()

                truncated = False
                if len(data) > self.max_content_length:
                    data = data[: self.max_content_length]
                    truncated = True

                if (
                    content_type.startswith("text/")
                    or "json" in content_type
                    or "xml" in content_type
                    or "javascript" in content_type
                ):
                    markdown_content = data.decode("utf-8", errors="replace")
                    if truncated:
                        markdown_content += "\n\n..._Content truncated_..."
                else:
                    b64 = base64.b64encode(data).decode()
                    suffix = " (truncated)" if truncated else ""
                    return (
                        f"## Binary content from {url} (content-type: {content_type})\n\n"
                        f"Base64{suffix}: {b64}"
                    )
            else:
                # Handle text/HTML content - use jina.ai reader service
                jina_url = f"https://r.jina.ai/{url}"
                markdown_content = await self._fetch(session, jina_url)

        # Clean up multiple line breaks
        markdown_content = re.sub(r"\n{3,}", "\n\n", markdown_content)

        # Truncate if too long
        if len(markdown_content) > self.max_content_length:
            truncated_content = markdown_content[
                : self.max_content_length - 100
            ]  # Leave room for message
            markdown_content = truncated_content + "\n\n..._Content truncated_..."
            logger.warning(
                f"{url} truncated from {len(markdown_content)} to {len(truncated_content)}"
            )

        return f"## Content from {url}\n\n{markdown_content}"

    async def _fetch(self, session: aiohttp.ClientSession, jina_url: str) -> str:
        """Fetch from jina.ai with backoff on HTTP 451."""
        backoff_delays = [0, 30, 90]  # No delay, then 30s, then 90s

        for attempt, delay in enumerate(backoff_delays):
            if delay > 0:
                logger.info(f"Waiting {delay}s before retry {attempt + 1}/3 for jina.ai")
                await asyncio.sleep(delay)

            try:
                headers = {"User-Agent": "muaddib/1.0"}
                if self.api_key:
                    headers["Authorization"] = f"Bearer {self.api_key}"
                async with session.get(
                    jina_url,
                    timeout=aiohttp.ClientTimeout(total=self.timeout),
                    headers=headers,
                ) as response:
                    response.raise_for_status()
                    content = await response.text()
                    return content.strip()

            except aiohttp.ClientResponseError as e:
                if (e.status == 451 or e.status >= 500) and attempt < len(backoff_delays) - 1:
                    # Only send error info on second failure (attempt 1) to reduce spam
                    if self.progress_callback and attempt == 1:
                        await self.progress_callback(
                            f"r.jina.ai HTTP {e.status}, retrying in a bit...", "progress"
                        )
                    continue
                raise

        raise RuntimeError("This should not be reached")


def _normalize_arc_id(arc: str) -> str:
    """Normalize arc ID for use as Sprite name (must be injective).

    Uses hash-based naming to guarantee different arcs always map to different
    Sprite names, preventing any possibility of cross-arc access.
    """
    import hashlib

    # Use SHA256 hash truncated to 16 hex chars (64 bits) for uniqueness
    # This is injective for all practical purposes (collision probability ~1/2^64)
    arc_hash = hashlib.sha256(arc.encode()).hexdigest()[:16]
    return arc_hash


# Global cache of Sprites per arc (singleton pattern for sprite reuse)
_sprite_cache: dict[str, Any] = {}
_sprite_cache_lock: asyncio.Lock | None = None


def _get_sprite_cache_lock() -> asyncio.Lock:
    """Get or create the sprite cache lock (lazy init for thread safety)."""
    global _sprite_cache_lock
    if _sprite_cache_lock is None:
        _sprite_cache_lock = asyncio.Lock()
    return _sprite_cache_lock


class _CommandResult:
    """Result of a command execution, compatible with subprocess.CompletedProcess."""

    def __init__(self, returncode: int, stdout: bytes, stderr: bytes):
        self.returncode = returncode
        self.stdout = stdout
        self.stderr = stderr


class CodeExecutorSprites:
    """Code executor using Fly.io Sprites sandbox. Supports Python and Bash.

    Architecture:
    - One Sprite per arc (persisted, reused across actor calls)
    - Per-actor-call isolated workdir in /tmp/actor-{uuid}/
    - Shared workspace in /workspace/ (persists across calls)
    """

    def __init__(
        self,
        token: str | None = None,
        arc: str = "default",
        timeout: int = 600,
        artifact_store: ArtifactStore | None = None,
        webpage_visitor: WebpageVisitorExecutor | None = None,
    ):
        self.token = token
        self.arc = arc
        self.timeout = timeout
        self.artifact_store = artifact_store
        self.webpage_visitor = webpage_visitor
        self._version_counter = 0
        self._workdir: str | None = None  # Per-call isolated workdir

    def _get_sprite_name(self) -> str:
        """Get the Sprite name for this arc."""
        return f"arc-{_normalize_arc_id(self.arc)}"

    def _run_command(
        self,
        sprite: Any,
        *args: str,
        cwd: str | None = None,
        timeout: float | None = None,
        capture_on_error: bool = False,
    ) -> _CommandResult:
        """Run a command on the sprite and return result with returncode/stdout/stderr.

        This wraps the sprites-py API (sprite.command()) to provide a
        subprocess.CompletedProcess-like interface.

        Args:
            capture_on_error: If True, wrap the command to capture output even on
                non-zero exit. sprites-py doesn't capture output in ExitError, so
                this is needed for commands where we care about error messages.

        Note: stdin is not supported by sprites-py command API. Use the filesystem
        API (sprite.filesystem().write_bytes()) to write data to files instead.
        """
        from sprites.exceptions import ExitError

        cmd_kwargs: dict[str, Any] = {}
        if cwd:
            cmd_kwargs["cwd"] = cwd
        if timeout:
            cmd_kwargs["timeout"] = timeout

        if capture_on_error and len(args) >= 1:
            # Wrap command to capture output to temp file, then read it back
            # This works around sprites-py not returning output on ExitError
            import uuid

            tmp_id = uuid.uuid4().hex[:8]
            output_file = f"/tmp/.cmd_output_{tmp_id}"
            exit_file = f"/tmp/.cmd_exit_{tmp_id}"
            script_file = f"/tmp/.cmd_script_{tmp_id}"

            fs = sprite.filesystem("/tmp")

            # Write script to file to handle multiline code properly
            if args[0] == "bash" and len(args) >= 3 and args[1] == "-c":
                script_content = args[2]
                script_file = f"/tmp/.cmd_script_{tmp_id}.sh"
                run_cmd = f"bash {script_file}"
            elif args[0] == "python3" and len(args) >= 3 and args[1] == "-c":
                script_content = args[2]
                script_file = f"/tmp/.cmd_script_{tmp_id}.py"
                run_cmd = f"python3 {script_file}"
            else:
                # Generic command - just run directly, quote args
                import shlex

                script_content = None
                run_cmd = " ".join(shlex.quote(a) for a in args)

            # Write script if needed
            if script_content is not None:
                (fs / script_file.split("/")[-1]).write_text(script_content)

            # Wrapper captures output and exit code, always exits 0
            wrapper = f"""
{{ {run_cmd} ; }} 2>&1 | tee {output_file}
echo ${{PIPESTATUS[0]}} > {exit_file}
exit 0
"""
            from contextlib import suppress

            cmd = sprite.command("bash", "-c", wrapper, **cmd_kwargs)
            with suppress(ExitError):
                cmd.combined_output()  # We don't use this, just trigger execution

            # Read captured output and exit code
            try:
                output = (fs / output_file.split("/")[-1]).read_bytes()
            except Exception:
                output = b""
            try:
                exit_code_str = (fs / exit_file.split("/")[-1]).read_text().strip()
                exit_code = int(exit_code_str) if exit_code_str else 0
            except Exception:
                exit_code = 0

            # Clean up temp files
            for f in [output_file, exit_file, script_file]:
                with suppress(Exception):
                    (fs / f.split("/")[-1]).unlink()

            return _CommandResult(returncode=exit_code, stdout=output, stderr=b"")

        # Standard execution (no error output capture)
        cmd = sprite.command(*args, **cmd_kwargs)

        try:
            # combined_output() captures both stdout and stderr
            output = cmd.combined_output()
            return _CommandResult(returncode=0, stdout=output, stderr=b"")
        except ExitError as e:
            # ExitError contains exit code in args[0], output in stdout/stderr attrs
            exit_code = e.args[0] if e.args else 1
            return _CommandResult(
                returncode=exit_code,
                stdout=e.stdout if e.stdout else b"",
                stderr=e.stderr if e.stderr else b"",
            )

    async def _ensure_sprite(self) -> Any:
        """Ensure Sprite exists and is connected. Returns the sprite."""
        try:
            from sprites import SpritesClient
        except ImportError:
            raise ImportError(
                "sprites-py package not installed. Install with: pip install sprites-py"
            ) from None

        sprite_name = self._get_sprite_name()

        async with _get_sprite_cache_lock():
            if sprite_name in _sprite_cache:
                sprite = _sprite_cache[sprite_name]
                logger.debug(f"Reusing existing Sprite: {sprite_name}")
                return sprite

            # Create new Sprite
            def create_sprite():
                client_args: dict[str, Any] = {}
                if self.token:
                    client_args["token"] = self.token
                client = SpritesClient(**client_args)

                # Create or get existing sprite
                try:
                    sprite = client.create_sprite(sprite_name)
                    logger.info(f"Created new Sprite: {sprite_name}")
                except Exception:
                    # Sprite may already exist, get handle
                    sprite = client.get_sprite(sprite_name)
                    logger.info(f"Connected to existing Sprite: {sprite_name}")

                return sprite

            sprite = await asyncio.to_thread(create_sprite)
            _sprite_cache[sprite_name] = sprite
            return sprite

    async def _ensure_workdir(self, sprite: Any) -> str:
        """Ensure per-actor-call workdir exists. Returns the workdir path."""
        if self._workdir is None:
            import uuid

            actor_id = str(uuid.uuid4())[:8]
            self._workdir = f"/tmp/actor-{actor_id}"

            # Create the workdir
            result = await asyncio.to_thread(
                self._run_command, sprite, "mkdir", "-p", self._workdir
            )
            if result.returncode != 0:
                logger.warning(f"Failed to create workdir: {result.stderr}")

            # Also ensure /workspace exists for shared data
            await asyncio.to_thread(self._run_command, sprite, "mkdir", "-p", "/workspace")

            logger.debug(f"Created actor workdir: {self._workdir}")

        return self._workdir

    def _upload_image_data(self, data: bytes | bytearray, suffix: str) -> str | None:
        """Upload image data to artifact store, return URL or None."""
        if not self.artifact_store:
            return None
        url = self.artifact_store.write_bytes(bytes(data), suffix)
        if url.startswith("Error:"):
            logger.warning(f"Failed to upload image artifact: {url}")
            return None
        return url

    async def _download_sprite_file(
        self, sprite: Any, path: str
    ) -> tuple[bytes | bytearray, str] | None:
        """Download a file from the Sprite, return (data, filename) or None."""
        from pathlib import PurePosixPath

        try:
            # Use cat to read file content
            result = await asyncio.to_thread(self._run_command, sprite, "cat", path)
            if result.returncode != 0:
                logger.warning(f"Failed to read file {path}: {result.stderr}")
                return None

            # stdout is bytes
            data = result.stdout if isinstance(result.stdout, bytes) else result.stdout.encode()
            filename = PurePosixPath(path).name
            return data, filename
        except Exception as e:
            logger.warning(f"Failed to download sprite file {path}: {e}")
            return None

    def _get_suffix_from_filename(self, filename: str) -> str:
        """Extract file suffix from filename."""
        from pathlib import PurePosixPath

        suffix = PurePosixPath(filename).suffix
        return suffix if suffix else ".bin"

    def _extract_image_data(self, content: list[dict]) -> bytes | None:
        """Extract binary image data from Anthropic content blocks."""
        for block in content:
            if block.get("type") == "image":
                source = block.get("source", {})
                if source.get("type") == "base64":
                    return base64.b64decode(source["data"])
        return None

    async def _upload_input_artifacts(self, sprite: Any, input_artifacts: list[str]) -> list[str]:
        """Download artifacts and upload them to Sprite. Returns list of messages."""
        if not self.webpage_visitor:
            return ["Warning: input_artifacts requested but webpage visitor not configured"]

        # Ensure /artifacts directory exists
        await asyncio.to_thread(self._run_command, sprite, "mkdir", "-p", "/artifacts")

        messages = []
        for artifact_url in input_artifacts:
            filename = _extract_filename_from_url(artifact_url)
            if filename:
                filename = Path(filename).name

            if not filename:
                messages.append(f"Error: Invalid artifact URL (no filename): {artifact_url}")
                continue

            try:
                content = await self.webpage_visitor.execute(artifact_url)
                sprite_path = f"/artifacts/{filename}"

                if isinstance(content, list):
                    data = self._extract_image_data(content)
                    if data is None:
                        messages.append(f"Error: Unsupported image format: {artifact_url}")
                        continue
                    content_type = "image"
                else:
                    data = content.encode() if isinstance(content, str) else content
                    content_type = "text"

                data_bytes: bytes
                if isinstance(data, bytearray):
                    data_bytes = bytes(data)
                elif isinstance(data, bytes):
                    data_bytes = data
                elif isinstance(data, str):
                    data_bytes = data.encode()
                else:
                    raise ValueError("Unsupported artifact data type")

                # Write file using filesystem API
                def write_file(
                    data_bytes: bytes = data_bytes, sprite_path: str = sprite_path
                ) -> None:
                    fs = sprite.filesystem("/")
                    (fs / sprite_path.lstrip("/")).write_bytes(data_bytes)

                try:
                    await asyncio.to_thread(write_file)
                except Exception as write_err:
                    messages.append(f"Error: Failed to write {sprite_path}: {write_err}")
                    continue

                logger.info(f"Uploaded {content_type} to sprite: {artifact_url} -> {sprite_path}")
                messages.append(f"Uploaded {content_type}: {sprite_path}")

            except Exception as e:
                logger.warning(f"Failed to upload artifact {artifact_url}: {e}")
                messages.append(f"Error: Failed to upload {artifact_url}: {e}")

        return messages

    async def execute(
        self,
        code: str,
        language: str = "python",
        input_artifacts: list[str] | None = None,
        output_files: list[str] | None = None,
    ) -> str:
        """Execute code in Sprites sandbox and return output."""
        try:
            sprite = await self._ensure_sprite()
        except ImportError as e:
            return str(e)

        try:
            workdir = await self._ensure_workdir(sprite)
            output_parts = []

            # Upload input artifacts first
            if input_artifacts:
                artifact_messages = await self._upload_input_artifacts(sprite, input_artifacts)
                for msg in artifact_messages:
                    output_parts.append(f"**{msg}**")

            # Auto-save code to workdir/_v{n}.py for re-runs
            self._version_counter += 1
            ext = ".py" if language == "python" else ".sh"
            saved_file = f"{workdir}/_v{self._version_counter}{ext}"

            # Write code to file using filesystem API
            def write_code():
                fs = sprite.filesystem("/")
                (fs / saved_file.lstrip("/")).write_text(code)

            await asyncio.to_thread(write_code)

            # Execute based on language (with capture_on_error for error messages)
            if language == "python":
                # Run Python code
                result = await asyncio.to_thread(
                    self._run_command,
                    sprite,
                    "python3",
                    "-c",
                    code,
                    timeout=self.timeout,
                    cwd=workdir,
                    capture_on_error=True,
                )
            else:
                # Run Bash code
                result = await asyncio.to_thread(
                    self._run_command,
                    sprite,
                    "bash",
                    "-c",
                    code,
                    timeout=self.timeout,
                    cwd=workdir,
                    capture_on_error=True,
                )

            logger.debug(f"Sprite execution result: returncode={result.returncode}")

            artifact_urls = []

            # Check for execution error
            if result.returncode != 0:
                stderr = (
                    result.stderr.decode() if isinstance(result.stderr, bytes) else result.stderr
                )
                if stderr:
                    output_parts.append(
                        f"**Execution error (exit {result.returncode}):**\n```\n{stderr.strip()}\n```"
                    )
                else:
                    output_parts.append(f"**Execution error:** Exit code {result.returncode}")

            # Process stdout
            stdout = result.stdout.decode() if isinstance(result.stdout, bytes) else result.stdout
            if stdout and stdout.strip():
                output_parts.append(f"**Output:**\n```\n{stdout.strip()}\n```")

            # Process stderr (warnings, etc.) if command succeeded
            if result.returncode == 0:
                stderr = (
                    result.stderr.decode() if isinstance(result.stderr, bytes) else result.stderr
                )
                if stderr and stderr.strip():
                    output_parts.append(f"**Warnings:**\n```\n{stderr.strip()}\n```")

            # Check for generated images in workdir (matplotlib saves)
            for img_ext in ["*.png", "*.jpg", "*.jpeg"]:
                find_result = await asyncio.to_thread(
                    self._run_command,
                    sprite,
                    "find",
                    workdir,
                    "-name",
                    img_ext,
                    "-type",
                    "f",
                )
                if find_result.returncode == 0:
                    stdout_find = (
                        find_result.stdout.decode()
                        if isinstance(find_result.stdout, bytes)
                        else find_result.stdout
                    )
                    for img_path in stdout_find.strip().split("\n"):
                        if img_path:
                            file_result = await self._download_sprite_file(sprite, img_path)
                            if file_result:
                                data, filename = file_result
                                suffix = self._get_suffix_from_filename(filename)
                                url = self._upload_image_data(data, suffix)
                                if url:
                                    artifact_urls.append(url)
                                    output_parts.append(f"**Generated image:** {url}")

            # Download explicit output files from sprite
            if output_files and self.artifact_store:
                for file_path in output_files:
                    file_result = await self._download_sprite_file(sprite, file_path)
                    if file_result:
                        data, filename = file_result
                        suffix = self._get_suffix_from_filename(filename)
                        url = self.artifact_store.write_bytes(data, suffix)
                        if not url.startswith("Error:"):
                            artifact_urls.append(url)
                            output_parts.append(f"**Downloaded file ({filename}):** {url}")
                        else:
                            output_parts.append(f"**Error uploading {filename}:** {url}")
                    else:
                        output_parts.append(f"**Error:** Could not download {file_path}")
            elif output_files and not self.artifact_store:
                output_parts.append(
                    "**Warning:** output_files requested but artifact store not configured"
                )

            if not output_parts:
                output_parts.append("Code executed successfully with no output.")

            # Append saved file info for re-runs
            output_parts.append(f"_Code saved to `{saved_file}` for re-run._")

            logger.info(
                f"Executed {language} code in Sprite {self._get_sprite_name()}: "
                f"{code[:512]}... -> {str(output_parts)[:512]}"
            )

            return "\n\n".join(output_parts)

        except Exception as e:
            logger.error(f"Sprites execution failed: {e}")
            return f"Error executing code: {e}"

    async def cleanup(self):
        """Clean up per-call workdir (but not the Sprite itself)."""
        if self._workdir:
            try:
                sprite_name = self._get_sprite_name()
                if sprite_name in _sprite_cache:
                    sprite = _sprite_cache[sprite_name]
                    await asyncio.to_thread(self._run_command, sprite, "rm", "-rf", self._workdir)
                    logger.debug(f"Cleaned up workdir: {self._workdir}")
            except Exception as e:
                logger.warning(f"Failed to clean up workdir {self._workdir}: {e}")
            finally:
                self._workdir = None


# Alias for backwards compatibility in tests
CodeExecutorE2B = CodeExecutorSprites


class ProgressReportExecutor:
    """Executor that sends progress updates via a provided callback."""

    def __init__(
        self,
        send_callback: Callable[[str], Awaitable[None]] | None = None,
        min_interval_seconds: int = 15,
    ):
        self.send_callback = send_callback
        self.min_interval_seconds = min_interval_seconds
        self._last_sent: float | None = None

    async def execute(self, text: str) -> str:
        # Sanitize to single line and trim
        clean = re.sub(r"\s+", " ", text or "").strip()
        logger.info(f"progress_report: {text}")
        if not clean:
            return "OK"

        # No-op if no callback (e.g., proactive mode)
        if not self.send_callback:
            return "OK"

        now = time.time()
        if self._last_sent is not None and (now - self._last_sent) < self.min_interval_seconds:
            return "OK"

        # Send update
        try:
            await self.send_callback(clean)
            self._last_sent = now
        except Exception as e:
            logger.warning(f"progress_report send failed: {e}")
        return "OK"


class FinalAnswerExecutor:
    """Executor for providing final answers."""

    async def execute(self, answer: str) -> str:
        """Return the final answer."""
        logger.info(f"Final answer provided: {answer[:500]}...")
        return answer


class MakePlanExecutor:
    """Executor for making/updating plans. Stores plan in quest DB when inside a quest."""

    def __init__(self, agent: Any = None, current_quest_id: str | None = None):
        self.agent = agent
        self.current_quest_id = current_quest_id

    async def execute(self, plan: str) -> str:
        """Store plan in quest DB (if in quest) and confirm receipt."""
        logger.info(f"Plan formulated: {plan[:500]}...")

        if self.agent and self.current_quest_id:
            await self.agent.chronicle.quest_set_plan(self.current_quest_id, plan)
            logger.debug(f"Stored plan for quest {self.current_quest_id}")

        return "OK, follow this plan (stored for future quest steps)"


class OracleExecutor:
    """Executor that spawns a nested agentic loop with a powerful reasoning model."""

    # Tools excluded from oracle's nested loop
    EXCLUDED_TOOLS = {"oracle", "progress_report", "quest_start", "subquest_start", "quest_snooze"}

    def __init__(
        self,
        config: dict,
        agent: Any,
        arc: str,
        conversation_context: list[dict],
        progress_callback: Callable[[str], Awaitable[None]] | None = None,
        secrets: dict[str, Any] | None = None,
    ):
        self.config = config
        self.agent = agent
        self.arc = arc
        self.conversation_context = conversation_context
        self.progress_callback = progress_callback
        self.secrets = secrets

    async def execute(self, query: str) -> str:
        """Consult the oracle with a query, returning its response."""
        from .actor import AgenticLLMActor, AgentIterationLimitError, get_tools_for_arc

        oracle_config = self.config.get("tools", {}).get("oracle", {})
        model = oracle_config.get("model")
        if not model:
            return "Error: oracle.model not configured"

        system_prompt = oracle_config.get(
            "prompt",
            "You are an oracle - a powerful reasoning entity consulted for complex analysis.",
        )

        # Build allowed tools list (all tools except excluded ones)
        all_tools = get_tools_for_arc(self.config, self.arc, current_quest_id=None)
        allowed_tools = [t["name"] for t in all_tools if t["name"] not in self.EXCLUDED_TOOLS]

        # Build context: original conversation + oracle query as new user turn
        context = list(self.conversation_context) + [{"role": "user", "content": query}]

        logger.info(
            f"---------------------------------------------- CONSULTING ORACLE: {query[:500]}..."
        )

        actor = AgenticLLMActor(
            config=self.config,
            model=model,
            system_prompt_generator=lambda: system_prompt,
            reasoning_effort="high",
            allowed_tools=allowed_tools,
            agent=self.agent,
            secrets=self.secrets,
        )

        try:
            result = await actor.run_agent(
                context,
                progress_callback=self.progress_callback,
                arc=self.arc,
                current_quest_id=None,
            )
            logger.info(
                f"---------------------------------------------- Oracle response: {result.text[:500]}..."
            )
            return result.text
        except AgentIterationLimitError as e:
            logger.warning(
                f"---------------------------------------------- Oracle exhausted: {e}..."
            )
            return f"Oracle exhausted iterations: {e}"
        except Exception as e:
            logger.error(
                f"---------------------------------------------- Oracle failed: {e}", exc_info=True
            )
            return f"Oracle error: {e}"


class ArtifactStore:
    """Shared artifact storage for files and URLs."""

    def __init__(self, artifacts_path: str | None = None, artifacts_url: str | None = None):
        self.artifacts_path = Path(artifacts_path).expanduser() if artifacts_path else None
        self.artifacts_url = artifacts_url.rstrip("/") if artifacts_url else None

    @classmethod
    def from_config(cls, config: dict) -> ArtifactStore:
        """Create store from configuration.

        If artifacts.path is a relative path, it's resolved relative to MUADDIB_HOME.
        """
        from ..paths import get_muaddib_home

        artifacts_config = config.get("tools", {}).get("artifacts", {})
        path = artifacts_config.get("path")

        # Resolve relative paths against MUADDIB_HOME
        if path and not Path(path).is_absolute():
            path = str(get_muaddib_home() / path)

        return cls(
            artifacts_path=path,
            artifacts_url=artifacts_config.get("url"),
        )

    def _ensure_configured(self) -> str | None:
        """Check if store is configured, return error message if not."""
        if not self.artifacts_path or not self.artifacts_url:
            return "Error: artifacts.path and artifacts.url must be configured"
        return None

    def write_text(self, content: str, suffix: str = ".txt") -> str:
        """Write text content to artifact file, return URL."""
        if err := self._ensure_configured():
            return err

        assert self.artifacts_path is not None
        assert self.artifacts_url is not None

        try:
            _ensure_artifacts_dir(self.artifacts_path)
        except Exception as e:
            logger.error(f"Failed to create artifacts directory: {e}")
            return f"Error: Failed to create artifacts directory: {e}"

        file_id = generate_artifact_id()
        filepath = self.artifacts_path / f"{file_id}{suffix}"

        try:
            filepath.write_text(content, encoding="utf-8")
            logger.info(f"Created artifact file: {filepath}")
        except Exception as e:
            logger.error(f"Failed to write artifact file: {e}")
            return f"Error: Failed to create artifact file: {e}"

        return _to_artifact_viewer_url(self.artifacts_url, f"{file_id}{suffix}")

    def write_bytes(self, data: bytes | bytearray, suffix: str) -> str:
        """Write binary data to artifact file, return URL."""
        if err := self._ensure_configured():
            return err

        assert self.artifacts_path is not None
        assert self.artifacts_url is not None

        try:
            _ensure_artifacts_dir(self.artifacts_path)
        except Exception as e:
            logger.error(f"Failed to create artifacts directory: {e}")
            return f"Error: Failed to create artifacts directory: {e}"

        file_id = generate_artifact_id()
        filepath = self.artifacts_path / f"{file_id}{suffix}"

        try:
            filepath.write_bytes(data)
            logger.info(f"Created artifact file: {filepath}")
        except Exception as e:
            logger.error(f"Failed to write artifact file: {e}")
            return f"Error: Failed to create artifact file: {e}"

        return _to_artifact_viewer_url(self.artifacts_url, f"{file_id}{suffix}")


class ShareArtifactExecutor:
    """Executor for sharing artifacts via files and links."""

    def __init__(self, store: ArtifactStore):
        self.store = store

    @classmethod
    def from_config(cls, config: dict) -> ShareArtifactExecutor:
        """Create executor from configuration."""
        return cls(ArtifactStore.from_config(config))

    async def execute(self, content: str) -> str:
        """Share an artifact by creating a file and providing a link."""
        url = self.store.write_text(content, ".txt")
        if url.startswith("Error:"):
            return url
        return f"Artifact shared: {url}"


class EditArtifactExecutor:
    """Executor for editing existing artifacts."""

    def __init__(self, store: ArtifactStore, webpage_visitor: WebpageVisitorExecutor):
        self.store = store
        self.webpage_visitor = webpage_visitor

    @classmethod
    def from_config(
        cls, config: dict, webpage_visitor: WebpageVisitorExecutor
    ) -> EditArtifactExecutor:
        """Create executor from configuration."""
        return cls(ArtifactStore.from_config(config), webpage_visitor)

    async def execute(self, artifact_url: str, old_string: str, new_string: str) -> str:
        """Edit an artifact by replacing old_string with new_string."""
        # Fetch via webpage visitor (handles local artifacts automatically)
        try:
            content_result = await self.webpage_visitor.execute(artifact_url)
            if isinstance(content_result, list):
                return "Error: Cannot edit binary artifacts (images)"

            # Extract content from markdown wrapper if present (remote URLs only)
            content = content_result
            if content.startswith("## Content from "):
                # Strip the markdown header
                parts = content.split("\n\n", 1)
                if len(parts) == 2:
                    content = parts[1]
        except Exception as e:
            logger.error(f"Failed to fetch artifact from {artifact_url}: {e}")
            return f"Error: Failed to fetch artifact: {e}"

        # Validate old_string exists and is unique
        if old_string not in content:
            return "Error: old_string not found in artifact. The artifact may have changed, or the search string is incorrect."

        occurrences = content.count(old_string)
        if occurrences > 1:
            return f"Error: old_string appears {occurrences} times in the artifact. It must be unique. Add more surrounding context to make it unique."

        # Perform the replacement
        new_content = content.replace(old_string, new_string, 1)

        # Extract suffix from URL (supports both raw URLs and viewer URLs)
        url_filename = _extract_filename_from_url(artifact_url) or ""
        suffix = "." + url_filename.split(".", 1)[1] if "." in url_filename else ".txt"

        url = self.store.write_text(new_content, suffix)
        if url.startswith("Error:"):
            return url

        logger.info(f"Edited artifact: {artifact_url} -> {url}")
        return f"Artifact edited successfully. New version: {url}"


class ImageGenExecutor:
    """Executor for generating images via OpenRouter."""

    def __init__(
        self,
        router: Any,
        config: dict,
        max_image_size: int = 5 * 1024 * 1024,
        timeout: int = 30,
        secrets: dict[str, Any] | None = None,
    ):
        from ..providers import parse_model_spec

        self.router = router
        self.config = config
        self.max_image_size = max_image_size
        self.timeout = timeout
        self.secrets = secrets
        self.store = ArtifactStore.from_config(config)

        tools_config = config.get("tools", {}).get("image_gen", {})
        self.model = tools_config.get("model", "openrouter:google/gemini-2.5-flash-preview-image")

        spec = parse_model_spec(self.model)
        if spec.provider != "openrouter":
            raise ValueError(f"image_gen.model must use openrouter provider, got: {spec.provider}")

    @classmethod
    def from_config(
        cls, config: dict, router: Any, secrets: dict[str, Any] | None = None
    ) -> ImageGenExecutor:
        """Create executor from configuration."""
        return cls(router=router, config=config, secrets=secrets)

    async def execute(self, prompt: str, image_urls: list[str] | None = None) -> str | list[dict]:
        """Generate image(s) using OpenRouter and store as artifacts."""

        # Build message content with text and optional images
        content: str | list[dict]
        logger.info(f"Generating image with prompt: {prompt}")
        if image_urls:
            content_blocks: list[dict] = [{"type": "text", "text": prompt}]
            async with aiohttp.ClientSession() as session:
                for url in image_urls:
                    try:
                        headers = resolve_http_headers(url, self.secrets)
                        ct, b64 = await fetch_image_b64(
                            session,
                            url,
                            self.max_image_size,
                            self.timeout,
                            headers=headers,
                        )
                        content_blocks.append(
                            {"type": "image_url", "image_url": {"url": f"data:{ct};base64,{b64}"}}
                        )
                        logger.info(f"Including additional image as input: {url}")
                    except ValueError as e:
                        logger.warning(f"Failed to fetch reference image {url}: {e}")
                        return f"Error: Failed to fetch reference image {url}: {e}"
            content = content_blocks
        else:
            content = prompt

        context = [{"role": "user", "content": content}]

        try:
            response, _, _, _ = await self.router.call_raw_with_model(
                model_str=self.model,
                context=context,
                system_prompt="",
                modalities=["image", "text"],
            )
        except Exception as e:
            logger.error(f"OpenRouter image generation failed: {e}")
            return f"Error: Image generation failed: {e}"

        if "error" in response:
            return f"Error: {response['error']}"

        # Extract images from response
        choices = response.get("choices", [])
        if not choices:
            logger.warning(f"No choices in response: {response}")
            return "Error: Model returned no output"

        message = choices[0].get("message", {})
        images = message.get("images", [])

        if not images:
            logger.warning(f"No images in message: {message}")
            return "Error: No images generated by model"

        artifact_urls = []
        image_blocks = []

        for img in images:
            img_url = None
            if isinstance(img, dict):
                img_url = img.get("image_url", {}).get("url") or img.get("url")
            elif isinstance(img, str):
                img_url = img

            if not img_url or not img_url.startswith("data:"):
                logger.warning(f"Invalid image data: {img}")
                continue

            # Parse data URL: data:image/png;base64,<data>
            try:
                parts = img_url.split(",", 1)
                if len(parts) != 2:
                    continue
                header, b64_data = parts
                mime_type = header.split(";")[0].replace("data:", "")
                img_bytes = base64.b64decode(b64_data)
            except Exception as e:
                logger.error(f"Failed to parse image data URL: {e}")
                continue

            ext_map = {"image/png": ".png", "image/jpeg": ".jpg", "image/webp": ".webp"}
            suffix = ext_map.get(mime_type, ".png")

            url = self.store.write_bytes(img_bytes, suffix)
            if url.startswith("Error:"):
                return url

            # Add slop watermark using ImageMagick
            if self.store.artifacts_path and self.store.artifacts_url:
                filename = _extract_local_artifact_path(url, self.store.artifacts_url)
                if filename:
                    filepath = self.store.artifacts_path / filename
                    try:
                        import subprocess

                        subprocess.run(
                            [
                                "convert",
                                str(filepath),
                                "-gravity",
                                "SouthEast",
                                "-pointsize",
                                "20",
                                "-fill",
                                "rgba(255,255,255,0.6)",
                                "-stroke",
                                "rgba(0,0,0,0.8)",
                                "-strokewidth",
                                "1",
                                "-annotate",
                                "+10+10",
                                "🍌slop",
                                str(filepath),
                            ],
                            check=True,
                            capture_output=True,
                        )
                    except Exception as e:
                        logger.warning(f"Failed to add watermark to {filepath}: {e}")

            artifact_urls.append(url)

            # Add image block (reuse b64_data already parsed)
            image_blocks.append(
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "media_type": mime_type,
                        "data": b64_data,
                    },
                }
            )

        if not artifact_urls:
            return "Error: No images could be extracted from response"

        # Return Anthropic content blocks: text (URLs) + images
        content_blocks = [
            {
                "type": "text",
                "text": "\n".join(f"Generated image: {url}" for url in artifact_urls),
            }
        ] + image_blocks

        return content_blocks


def create_tool_executors(
    config: dict | None = None,
    *,
    progress_callback: Callable[[str], Awaitable[None]] | None = None,
    agent: Any,
    arc: str,
    router: Any = None,
    current_quest_id: str | None = None,
    secrets: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Create tool executors with configuration."""
    # Tool configs
    tools = config.get("tools", {}) if config else {}

    # Sprites config
    sprites_config = tools.get("sprites", {})
    sprites_token = sprites_config.get("token")

    # Jina config
    jina_config = tools.get("jina", {})
    jina_api_key = jina_config.get("api_key")

    # Search provider config
    tools_config = config.get("tools", {}) if config else {}
    search_provider = tools_config.get("search_provider", "auto")

    # Create appropriate search executor based on provider
    if search_provider == "jina":
        search_executor = JinaSearchExecutor(api_key=jina_api_key)
    elif search_provider == "brave":
        brave_config = tools.get("brave", {})
        brave_api_key = brave_config.get("api_key")
        if not brave_api_key:
            logger.warning("Brave search configured but no API key found, falling back to ddgs")
            search_executor = WebSearchExecutor(backend="brave")
        else:
            search_executor = BraveSearchExecutor(api_key=brave_api_key)
    else:
        if "jina" in search_provider:
            raise ValueError(
                f"Jina search provider must be exclusive. Found: '{search_provider}'. "
                "Use exactly 'jina' for jina search (recommended provider, but API key required)."
            )
        search_executor = WebSearchExecutor(backend=search_provider)

    # Progress executor settings
    behavior = (config or {}).get("behavior", {})
    progress_cfg = behavior.get("progress", {}) if behavior else {}
    min_interval = int(progress_cfg.get("min_interval_seconds", 15))

    # Shared artifact store for code executor and share_artifact
    artifact_store = ArtifactStore.from_config(config or {})

    webpage_visitor = WebpageVisitorExecutor(
        progress_callback=progress_callback,
        api_key=jina_api_key,
        artifact_store=artifact_store,
        secrets=secrets,
    )

    executors = {
        "web_search": search_executor,
        "visit_webpage": webpage_visitor,
        "execute_code": CodeExecutorSprites(
            token=sprites_token,
            arc=arc,
            artifact_store=artifact_store,
            webpage_visitor=webpage_visitor,
        ),
        "progress_report": ProgressReportExecutor(
            send_callback=progress_callback, min_interval_seconds=min_interval
        ),
        "final_answer": FinalAnswerExecutor(),
        "make_plan": MakePlanExecutor(agent=agent, current_quest_id=current_quest_id),
        "share_artifact": ShareArtifactExecutor(store=artifact_store),
        "edit_artifact": EditArtifactExecutor(
            store=artifact_store, webpage_visitor=webpage_visitor
        ),
        "chronicle_append": ChapterAppendExecutor(agent=agent, arc=arc),
        "chronicle_read": ChapterRenderExecutor(chronicle=agent.chronicle, arc=arc),
    }

    # Add quest tools conditionally based on current_quest_id
    if current_quest_id is None:
        executors["quest_start"] = QuestStartExecutor(agent=agent, arc=arc)
    else:
        executors["subquest_start"] = SubquestStartExecutor(
            agent=agent, arc=arc, parent_quest_id=current_quest_id
        )
        executors["quest_snooze"] = QuestSnoozeExecutor(agent=agent, quest_id=current_quest_id)

    # Add generate_image only if router is available
    if router:
        executors["generate_image"] = ImageGenExecutor.from_config(
            config or {}, router, secrets=secrets
        )

    return executors


async def execute_tool(
    tool_name: str, tool_executors: dict[str, Any], **kwargs
) -> str | list[dict]:
    """Execute a tool by name with given arguments."""
    executors = tool_executors

    if tool_name not in executors:
        raise ValueError(f"Unknown tool '{tool_name}'")

    executor = executors[tool_name]
    return await executor.execute(**kwargs)
