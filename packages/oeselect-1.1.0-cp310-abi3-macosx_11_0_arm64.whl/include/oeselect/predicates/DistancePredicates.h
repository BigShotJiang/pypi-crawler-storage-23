/**
 * @file DistancePredicates.h
 * @brief Distance-based selection predicates.
 *
 * These predicates select atoms based on spatial proximity to a reference
 * selection. They use a k-d tree spatial index for efficient queries.
 */

#ifndef OESELECT_PREDICATES_DISTANCE_PREDICATES_H
#define OESELECT_PREDICATES_DISTANCE_PREDICATES_H

#include "oeselect/Predicate.h"

namespace OESel {

/**
 * @brief Selects atoms within a distance of a reference selection, excluding reference.
 *
 * Matches any atom that is within the specified radius of at least one
 * atom in the reference selection. The reference atoms themselves are
 * excluded from the result.
 *
 * @code
 * // Selection: ligand around 5.0
 * // Matches atoms within 5A of ligand, but not ligand atoms themselves
 * @endcode
 */
class AroundPredicate : public Predicate {
public:
    /**
     * @brief Construct around predicate.
     * @param radius Distance threshold in Angstroms.
     * @param reference Reference selection for distance calculation.
     */
    AroundPredicate(float radius, Ptr reference);

    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override;
    [[nodiscard]] PredicateType Type() const override { return PredicateType::AROUND; }
    [[nodiscard]] std::vector<Ptr> Children() const override { return {reference_}; }

private:
    float radius_;
    Ptr reference_;

    /// Compute and cache the boolean mask of nearby atoms
    const std::vector<bool>& GetAroundMask(Context& ctx) const;
};

/**
 * @brief Selects atoms within a distance of a reference selection, including reference.
 *
 * Matches any atom that is within the specified radius of at least one
 * atom in the reference selection. The reference atoms themselves are
 * included in the result.
 *
 * @code
 * // Selection: ligand expand 5.0
 * // Matches all atoms within 5 Angstroms of any ligand atom, including ligand
 * @endcode
 */
class ExpandPredicate : public Predicate {
public:
    /**
     * @brief Construct expand predicate.
     * @param radius Distance threshold in Angstroms.
     * @param reference Reference selection for distance calculation.
     */
    ExpandPredicate(float radius, Ptr reference);

    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override;
    [[nodiscard]] PredicateType Type() const override { return PredicateType::EXPAND; }
    [[nodiscard]] std::vector<Ptr> Children() const override { return {reference_}; }

private:
    float radius_;
    Ptr reference_;

    /// Compute and cache the boolean mask (shared with AroundPredicate)
    const std::vector<bool>& GetAroundMask(Context& ctx) const;
};

/**
 * @brief Selects atoms beyond a distance from a reference selection.
 *
 * Matches atoms that are farther than the specified radius from ALL
 * atoms in the reference selection. This is the logical inverse of
 * AroundPredicate.
 *
 * @code
 * // Selection: beyond 10.0 protein
 * // Matches atoms more than 10A away from any protein atom
 * @endcode
 */
class BeyondPredicate : public Predicate {
public:
    /**
     * @brief Construct beyond predicate.
     * @param radius Distance threshold in Angstroms.
     * @param reference Reference selection for distance calculation.
     */
    BeyondPredicate(float radius, Ptr reference);

    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override;
    [[nodiscard]] PredicateType Type() const override { return PredicateType::BEYOND; }
    [[nodiscard]] std::vector<Ptr> Children() const override { return {reference_}; }

private:
    float radius_;
    Ptr reference_;

    /// Compute and cache the around mask (inverted for beyond logic)
    const std::vector<bool>& GetAroundMask(Context& ctx) const;
};

}  // namespace OESel

#endif  // OESELECT_PREDICATES_DISTANCE_PREDICATES_H
