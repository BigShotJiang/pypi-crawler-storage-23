/**
 * @file SecondaryStructurePredicates.h
 * @brief Secondary structure predicates (helix, sheet, turn, loop).
 *
 * These predicates select atoms based on the secondary structure
 * assignment of their residues. Secondary structure must be assigned
 * prior to selection (e.g., from PDB HELIX/SHEET records or DSSP).
 */

#ifndef OESELECT_PREDICATES_SECONDARY_STRUCTURE_PREDICATES_H
#define OESELECT_PREDICATES_SECONDARY_STRUCTURE_PREDICATES_H

#include "oeselect/Predicate.h"

namespace OESel {

/**
 * @brief Selects atoms in alpha helix secondary structure.
 *
 * Matches atoms in residues with OESecondaryStructure::Helix assignment.
 */
class HelixPredicate : public Predicate {
public:
    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override { return "helix"; }
    [[nodiscard]] PredicateType Type() const override { return PredicateType::HELIX; }
};

/**
 * @brief Selects atoms in beta sheet secondary structure.
 *
 * Matches atoms in residues with OESecondaryStructure::Sheet assignment.
 */
class SheetPredicate : public Predicate {
public:
    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override { return "sheet"; }
    [[nodiscard]] PredicateType Type() const override { return PredicateType::SHEET; }
};

/**
 * @brief Selects atoms in turn secondary structure.
 *
 * Matches atoms in residues with OESecondaryStructure::Turn assignment.
 */
class TurnPredicate : public Predicate {
public:
    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override { return "turn"; }
    [[nodiscard]] PredicateType Type() const override { return PredicateType::TURN; }
};

/**
 * @brief Selects atoms in loop/coil secondary structure.
 *
 * Matches atoms in residues that are NOT assigned as helix, sheet, or turn.
 * This includes random coil and any unassigned residues.
 */
class LoopPredicate : public Predicate {
public:
    bool Evaluate(Context& ctx, const OEChem::OEAtomBase& atom) const override;
    [[nodiscard]] std::string ToCanonical() const override { return "loop"; }
    [[nodiscard]] PredicateType Type() const override { return PredicateType::LOOP; }
};

}  // namespace OESel

#endif  // OESELECT_PREDICATES_SECONDARY_STRUCTURE_PREDICATES_H
