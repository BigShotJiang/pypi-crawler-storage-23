# Auto-generated build information - do not edit
OPENEYE_BUILD_VERSION = "2025.2.1"
OPENEYE_LIBRARY_TYPE = "SHARED"
