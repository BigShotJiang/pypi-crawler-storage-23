__version__ = "4.0.0"
dependencies = ["falcon==4.2.0",
                "portalocker==2.10.1",
                "huckle>=5.5.6,<6.0.0",
                "hcli_problem_details>=0.2.0,<1.0.0",
                "argon2-cffi==25.1.0"]
