import errno
import sys
import os
import stat
import importlib
import shutil
import inspect
import signal
import atexit
import portalocker

from io import StringIO
from contextlib import contextmanager
from pathlib import Path
from os import listdir
from os.path import isfile, join
from os import path
from configparser import ConfigParser
from threading import Lock, local

from threading import local

home = os.getenv('HCLI_CORE_HOME') or os.path.expanduser("~")
dot_hcli_core = os.path.join(home, ".hcli_core")
dot_hcli_core_var = os.path.join(dot_hcli_core + "/var")
dot_hcli_core_var_log = os.path.join(dot_hcli_core_var + "/log")
dot_hcli_core_config = os.path.join(dot_hcli_core + "/etc")
log_file_path = dot_hcli_core_var_log + "/hcli_core.log"


class ServerContext:
    _context = local()

    @classmethod
    def _ensure_context(cls):
        if not hasattr(cls._context, 'data'):
            cls._context.data = {}

    @classmethod
    def set_current_server(cls, server_type):
        cls._ensure_context()
        cls._context.data['current_server'] = server_type

    @classmethod
    def get_current_server(cls):
        cls._ensure_context()
        return cls._context.data.get('current_server', 'core')

    @classmethod
    def set_current_user(cls, username):
        cls._ensure_context()
        cls._context.data['current_user'] = username

    @classmethod
    def get_current_user(cls):
        cls._ensure_context()
        return cls._context.data.get('current_user', None)


class Config:
    _instances = {}       # Dictionary to store named instances
    _instance_locks = {}  # Dictionary to store locks for each named instance
    _global_lock = Lock() # Lock for managing instance creation

    # Get management port from config file if explicitly configured, else None.
    @classmethod
    def get_management_port(cls, config_path=None):
        with cls._global_lock:
            if not config_path:
                config_path = os.path.join(os.path.dirname(inspect.getfile(lambda: None)), "auth/cli/config")

            try:
                parser = ConfigParser(interpolation=None)
                with open(config_path, 'r') as config_file:
                    parser.read_file(config_file)

                    if parser.has_section("default") and parser.has_option("default", "hco.port"):
                        try:
                            port = int(parser.get("default", "hco.port"))
                            if 1 <= port <= 65536:
                                return port
                            log.warning(f"Invalid management port value: {port}")
                        except ValueError:
                            log.warning("Invalid management port configuration")

                return None
            except Exception as e:
                log.warning(f"Error reading management port configuration: {e}")
                return None

    # Get management root aggregation cue from config file if explicitly configured, else None.
    @classmethod
    def get_core_root(cls, config_path=None):
        with cls._global_lock:
            if not config_path:
                config_path = os.path.join(os.path.dirname(inspect.getfile(lambda: None)), "auth/cli/config")

            try:
                parser = ConfigParser(interpolation=None)
                with open(config_path, 'r') as config_file:
                    parser.read_file(config_file)

                    if parser.has_section("default") and parser.has_option("default", "core.root"):
                        try:
                            root = parser.get("default", "core.root")
                            if root == 'aggregate' or root == 'management':
                                return root
                            log.warning(f"Invalid core root value: {root}")
                        except ValueError:
                            log.warning("Invalid core root configuration")

                return None
            except Exception as e:
                log.warning(f"Error reading management root configuration: {e}")
                return None

    # Get custom wsgi app port from config file if explicitly configured, else None.
    @classmethod
    def get_core_wsgiapp_port(cls, config_path=None):
        with cls._global_lock:
            if not config_path:
                config_path = os.path.join(os.path.dirname(inspect.getfile(lambda: None)), "auth/cli/config")

            try:
                parser = ConfigParser(interpolation=None)
                with open(config_path, 'r') as config_file:
                    parser.read_file(config_file)

                    if parser.has_section("default") and parser.has_option("default", "core.wsgiapp.port"):
                        try:
                            port = int(parser.get("default", "core.wsgiapp.port"))
                            if 1 <= port <= 65536:
                                return port
                            log.warning(f"Invalid core wsgi app port value: {port}")
                        except ValueError:
                            log.warning("Invalid core wsgi app port configuration")

                return None
            except Exception as e:
                log.warning(f"Error reading core wsgi app port configuration: {e}")
                return None

    def __new__(cls, name=None):
        # If no name provided, get it from context
        if name is None:
            name = ServerContext.get_current_server()

        # Create lock for this instance name if it doesn't exist
        with cls._global_lock:
            if name not in cls._instance_locks:
                cls._instance_locks[name] = Lock()

        # Check if instance exists, if not create it
        if name not in cls._instances:
            with cls._instance_locks[name]:  # Thread-safe instance creation
                if name not in cls._instances:  # Double-checked locking
                    instance = super(Config, cls).__new__(cls)

                    # core and management service shared values
                    instance.name = name
                    instance.root = os.path.dirname(inspect.getfile(lambda: None))
                    instance.sample = instance.root + "/sample"
                    instance.hcli_core_manpage_path = instance.root + "/data/hcli_core.1"
                    instance.template = None
                    instance.plugin_path = instance.root + "/cli"
                    instance.cli = None
                    instance.default_config_file_path = instance.root + "/auth/cli/config"
                    instance.config_file_path = None
                    instance.auth = True
                    instance.log = logger.Logger(f"hcli_core")
                    instance.mgmt_credentials = 'local'
                    instance.core_root = None

                    # management specific service value
                    if name == 'management':
                        instance.mgmt_port = 9000

                    # core wsgiapp specific service value
                    if name == 'wsgiapp':
                        instance.wsgapp_port = None

                    cls._instances[name] = instance

        return cls._instances[name]

    @classmethod
    def get_instance(cls, name="core"):
        """Get a named instance of the Config class."""
        return cls(name)

    @classmethod
    def list_instances(cls):
        """List all created configuration instances."""
        return list(cls._instances.keys())

    def parse_configuration(self):
        try:
            with open(self.config_file_path, 'r') as config_file:
                parser = ConfigParser(interpolation=None)
                parser.read_file(config_file)

                if not parser.has_section("default"):
                    log.critical(f"No [default] section available in {self.config_file_path}")
                    assert False

                # Core authentication
                if self.name == 'core':
                    if parser.has_option("default", "core.auth"):
                        value = parser.get("default", "core.auth")
                        if value.lower() in ('true', 'false'):
                            self.auth = value.lower() == 'true'
                            if not self.auth:
                                log.warning("Authentication is disabled for the core HCLI app. Make sure this is intentional.")
                        else:
                            log.warning(f"Invalid core.auth value: {value}. Enabling authentication.")
                            self.auth = True
                        log.info(f"Core Authentication: {self.auth}")

                # Management configuration
                if self.name == 'management':
                    if parser.has_option("default", "hco.port"):
                        try:
                            port = int(parser.get("default", "hco.port"))
                            if 1 <= port <= 65535:
                                self.mgmt_port = port
                            else:
                                log.warning(f"Invalid management port value: {port}. Using default: 9000")
                                self.mgmt_port = 9000
                        except ValueError:
                            log.warning(f"Invalid management port value. Using default: 9000")
                            self.mgmt_port = 9000
                        log.info(f"Management Port: {self.mgmt_port}")
                    else:
                        log.info(f"Default Management Port: {self.mgmt_port}")

                # WSGApp configuration
                if self.name == 'wsgiapp':
                    if parser.has_option("default", "core.wsgiapp.port"):
                        try:
                            port = int(parser.get("default", "core.wsgiapp.port"))
                            if 1 <= port <= 65535:
                                self.core_wsgiapp_port = port
                            else:
                                log.warning(f"Invalid wsgi app port value: {port}.")
                                self.core_wsgiapp_port = None
                        except ValueError:
                            log.warning(f"Invalid wsgi app port value.")
                            self.core_wsgiapp_port = None
                        log.info(f"Core WSGIApp Port: {self.core_wsgiapp_port}")
                    else:
                        log.info(f"Default Core WSGIApp Port: {self.core_wsgiapp_port}")

                # Common configuration options
                value = parser.get("default", "hco.credentials", fallback=None)
                if value is not None:
                    if value in ('local', 'remote'):
                        self.mgmt_credentials = value
                    else:
                        log.warning(f"Invalid credentials management mode: {value}. Using default: local")
                        self.mgmt_credentials = 'local'
                    log.info(f"Credentials management: {self.mgmt_credentials}")

                value = parser.get("default", "core.root", fallback=None)
                if value is not None:
                    if value in ('aggregate', 'management'):
                        self.core_root = value
                    else:
                        log.warning(f"Invalid core root override: {value}. Using default: None")
                        self.core_root = None
                    log.info(f"Core root override: {self.core_root}")

                # Special logging for management auth
                if self.name == 'management':
                    log.info(f"Management Auth: {self.auth}")

        except Exception as e:
            log.critical(f"Unable to load configuration: {str(e)}")
            assert False

    def set_config_path(self, config_path):
        if config_path:
            self.config_file_path = os.path.abspath(config_path)
            self.log.info(f"Custom configuration for '{self.name}':")
        else:
            self.config_file_path = self.default_config_file_path
            self.log.warning(f"Default configuration for '{self.name}':")
        self.log.info(self.config_file_path)

        if not self.is_600(os.path.join(os.path.dirname(self.config_file_path), "credentials")):
            self.log.warning("The credentials file's permissions SHOULD be set to 600 (e.g. chmod 600 credentials).")

    def parse_template(self, t):
        self.template = t

    def set_plugin_path(self, p):
        if p is not None:
            self.plugin_path = p

        try:
            # Clear any existing 'cli' module from cache
            if 'cli' in sys.modules:
                del sys.modules['cli']

            plugin_dir = os.path.dirname(self.plugin_path)
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            if self.plugin_path not in sys.path:
                sys.path.insert(0, self.plugin_path)

            log.debug(f"Loading CLI for {self.name}.")
            log.debug(f"Plugin path: {self.plugin_path}.")
            log.debug(f"sys.path: {sys.path}.")

            # Use a unique module name for each CLI
            module_name = f"cli_{self.name}"
            cli_path = os.path.join(self.plugin_path, 'cli.py')

            log.debug(f"Loading from: {cli_path}")
            spec = importlib.util.spec_from_file_location(module_name, cli_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self._cli_module = module
            log.debug(f"Loaded module from: {module.__file__}.")

            log.info(f"Successfully loaded CLI plugin for {self.name}.")
        except Exception as e:
            log.error(f"Failed to load CLI plugin from {self.plugin_path}: {str(e)}")
            raise

    def set_wsgiapp_path(self, p):
        if p is not None:
            self.plugin_path = p

        try:
            # Clear any existing 'wsgiapp' module from cache
            if 'wsgiapp' in sys.modules:
                del sys.modules['wsgiapp']

            plugin_dir = os.path.dirname(self.plugin_path)
            if plugin_dir not in sys.path:
                sys.path.insert(0, plugin_dir)
            if self.plugin_path not in sys.path:
                sys.path.insert(0, self.plugin_path)

            log.debug(f"Loading WSGI App for {self.name}.")
            log.debug(f"Plugin path: {self.plugin_path}.")
            log.debug(f"sys.path: {sys.path}.")

            # Use a unique module name for each WSGI App
            module_name = f"wsgiapp_{self.name}"
            wsgiapp_path = os.path.join(self.plugin_path, 'wsgiapp', 'wsgiapp.py')

            log.debug(f"Loading from: {wsgiapp_path}")
            spec = importlib.util.spec_from_file_location(module_name, wsgiapp_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self._wsgiapp_module = module
            log.debug(f"Loaded module from: {module.__file__}.")

            log.info(f"Successfully loaded WSGI App plugin for {self.name}.")
        except Exception as e:
            log.error(f"Failed to load CLI plugin from {self.plugin_path}: {str(e)}")
            raise

    # Return the CLI class itself, not the module
    @property
    def cli(self):
        if hasattr(self, '_cli_module'):
            if hasattr(self._cli_module, 'CLI'):
                return getattr(self._cli_module, 'CLI')
        return None

    # Return the WSGIApp class itself, not the module
    @property
    def wsgiapp(self):
        if hasattr(self, '_wsgiapp_module'):
            if hasattr(self._wsgiapp_module, 'WSGIApp'):
                return getattr(self._wsgiapp_module, 'WSGIApp')
        return None

    @cli.setter
    def cli(self, value):
        self._cli_module = value

    def is_600(self, filepath):
        mode = os.stat(filepath).st_mode & 0o777

        # Print actual permissions and platform for debugging
        log.debug(f"Platform: {sys.platform}")
        log.info(f"Credentials file permissions (octal): {oct(mode)}")

        # 0o600 = rw------- (read/write for owner only)
        is_user_rw = bool(mode & 0o600)  # User has read and write
        is_other_none = (mode & 0o177) == 0  # No permissions for group/others

        return is_user_rw and is_other_none

    def __str__(self):
        return f"{self.name}"

# creates a configuration file for a named service
def create_configuration(name, plugin_path, description):
    config_file_folder = os.path.join(dot_hcli_core_config, name)
    config_file = os.path.join(config_file_folder, "config")
    credentials_file = os.path.join(config_file_folder, "credentials")

    try:
        create_folder(config_file_folder)
    except Exception as e:
        error = repr(e)
        log.error(error)

    if not os.path.exists(credentials_file):
        try:
            init_credentials(name, plugin_path)
        except Exception as e:
            error = repr(e)
            log.error(error)
    else:
        pass

    if not os.path.exists(config_file):
        try:
            init_credentials(name, plugin_path)
            return init_configuration(name, plugin_path, description)
        except Exception as e:
            error = repr(e)
            log.error(error)
    else:
        error = f"hcli_core: the configuration for {name} already exists. leaving the existing configuration untouched."
        raise Exception(error)

# initializes the configuration file of a given service name
def init_configuration(name, plugin_path, description):

    config_file_path = dot_hcli_core_config + "/" + name + "/config"
    parser = ConfigParser()

    parser.read_file(StringIO(u"[default]"))
    parser.set("default", "core.plugin.path", plugin_path)
    parser.set("default", "core.description", description)
    parser.set("default", "core.auth", "False")
    parser.set("default", "core.port", "8000")

    with open(config_file_path, "w") as config:
        parser.write(config)

    return name

# initializes the credentials file of a given service name
def init_credentials(name, plugin_path):

    credentials_file_path = dot_hcli_core_config + "/" + name + "/credentials"
    parser = ConfigParser()

    parser.read_file(StringIO(u"[default]"))
    parser.set("default", "username", "admin")
    parser.set("default", "password", "*")

    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY

    try:
        file_handle = os.open(credentials_file_path, flags, 0o0600)
    except OSError as e:
        if e.errno == errno.EEXIST:  # Failed since the file already exists.
            pass
        else:
            raise
    else:
        with os.fdopen(file_handle, 'w') as credentials:
            parser.write(credentials)
            credentials.close

    return ""

# creates a folder at "path"
def create_folder(path):

    # Skip lock only if this is the actual user's home directory (not a custom HCLI_CORE_HOME)
    if path == os.path.expanduser("~"):
        if not os.path.exists(path):
            os.makedirs(path)
        return

    with write_lock(path):
        if not os.path.exists(path):
            os.makedirs(path)

# lists all the configuration parameters of a named service
def config_list(name):
    config_file_path = dot_hcli_core_config + "/" + name + "/config"
    parser = ConfigParser()
    parser.read(config_file_path)

    def generator():
        try:
            # Get all content first
            all_lines = []
            for section_name in parser.sections():
                all_lines.append(f"[{section_name}]")
                for name, value in parser.items(section_name):
                    all_lines.append(f'{name} = {value}')

            # Handle empty case
            if not all_lines:
                yield ('stdout', b'')
                return

            # Output all but last line with newlines
            for line in all_lines[:-1]:
                yield ('stdout', f"{line}\n".encode('utf-8'))

            # Output last line without newline
            if all_lines:
                yield ('stdout', all_lines[-1].encode('utf-8'))

        except Exception as error:
            error = "huckle: unable to list configuration."
            raise Exception(error)

    return generator()

# get a configured parameter
def get_parameter(name, parameter):
    config_file_path = dot_hcli_core_config + "/" + name + "/config"
    parser = ConfigParser()
    parser.read(config_file_path)

    found = None

    def generator():
        try:
            for section in parser.sections():
                if parser.has_option(section, parameter):
                    found = parser.get(section, parameter)

            yield ('stdout', found.encode('utf-8'))
        except Exception as error:
            error = "hcli_core: unable to retrieve configuration."
            raise Exception(error)

    return generator()

# update a configured parameter to a new value
def update_parameter(name, parameter, value):
    config_file_path = dot_hcli_core_config + "/" + name + "/config"
    parser = ConfigParser()
    parser.read(config_file_path)

    def generator():
        try:
            parser.set('default', parameter, value)
            with write_lock(config_file_path):
                with open(config_file_path, "w") as config:
                    parser.write(config)
            yield ('stdout', b'')
        except Exception as error:
            error = "hcli_core: unable to update configuration."
            raise Exception(error)

    return generator()

# unset a configured parameter
def unset_parameter(name, parameter):
    config_file_path = dot_hcli_core_config + "/" + name + "/config"
    parser = ConfigParser()
    parser.read(config_file_path)

    def generator():
        try:
            if parser.has_section('default') and parser.has_option('default', parameter):
                parser.remove_option('default', parameter)
            with write_lock(config_file_path):
                with open(config_file_path, "w") as config:
                    parser.write(config)
            yield ('stdout', b'')
        except Exception as error:
            error = "hcli_core: unable to update configuration."
            raise Exception(error)

    return generator()

def get_description(config_path):
    parser = ConfigParser()
    parser.read(config_path)

    description = ""
    for section in parser.sections():
        if parser.has_option(section, "core.description"):
            return parser.get(section, "core.description")

    return ""

# list all the named services
def list_clis():
    def generator():
        try:
            files = [f for f in listdir(dot_hcli_core_config)]

            # Handle empty list case first
            if not files:
                yield ('stdout', b'')
                return

            # Find the longest CLI name for padding calculation
            longest_name = max(len(f) for f in files) if files else 0
            # Set column width with exactly 2 spaces after the longest name
            column_width = longest_name + 2

            # Calculate terminal width (fallback to 80 if can't determine)
            terminal_width = 80
            try:
                import shutil
                terminal_width = shutil.get_terminal_size().columns
            except:
                pass  # Use default 80 if we can't get the terminal width

            # Leave some space for the HCLI column and spacing
            desc_max_width = terminal_width - column_width - 2

            # Format and output header
            yield ('stdout', f"{'HCLI':<{column_width}}DESCRIPTION\n".encode('utf-8'))

            # Output all but last item with newlines
            for f in files[:-1]:
                config_path = dot_hcli_core_config + "/" + f + "/config"
                description = get_description(config_path)

                # Truncate description if needed to fit in terminal
                if desc_max_width > 10 and len(description) > desc_max_width:
                    description = description[:desc_max_width-3] + "..."

                yield ('stdout', f"{f:<{column_width}}{description}\n".encode('utf-8'))

            # Last item without newline
            if files:
                f = files[-1]
                config_path = dot_hcli_core_config + "/" + f + "/config"
                description = get_description(config_path)

                # Truncate description if needed to fit in terminal
                if desc_max_width > 10 and len(description) > desc_max_width:
                    description = description[:desc_max_width-3] + "..."

                yield ('stdout', f"{f:<{column_width}}{description}".encode('utf-8'))

        except Exception as e:
            error = f"hcli_core: error listing clis: {str(e)}"
            raise Exception(error)

    return generator()

# remove a cli
def remove_cli(name):
    config_path = os.path.join(dot_hcli_core_config, name)

    def generator():
        if path.exists(config_path):
            shutil.rmtree(config_path)
            yield ('stdout', b'')
        else:
            error = f"hcli_core: {name} is not installed."
            raise Exception(error)

    return generator()

# run a previously installed cli
def run_cli(name):

    parser = ConfigParser()
    config_path = os.path.join(dot_hcli_core_config, name, "config")
    parser.read(config_path)

    plugin_path = None
    for section in parser.sections():
        if parser.has_option(section, "core.plugin.path"):
            plugin_path = parser.get(section, "core.plugin.path")

    core_port = None
    for section in parser.sections():
        if parser.has_option(section, "core.port"):
            core_port = parser.get(section, "core.port")

    hco_port = None
    for section in parser.sections():
        if parser.has_option(section, "hco.port"):
            hco_port = parser.get(section, "hco.port")

    core_wsgiapp_port = None
    for section in parser.sections():
        if parser.has_option(section, "core.wsgiapp.port"):
            core_wsgiapp_port = parser.get(section, "core.wsgiapp.port")

    gunicorn_command = f'gunicorn --workers=1 --threads=100 '
    core_port_command = f'-b 0.0.0.0:{core_port} '
    hco_port_command = f'-b 0.0.0.0:{hco_port} '
    core_wsgiapp_port_command = f'-b 0.0.0.0:{core_wsgiapp_port} '
    hcli_core_command = f'"hcli_core:connector(plugin_path=\\"{plugin_path}\\", config_path=\\"{config_path}\\")"'

    command = gunicorn_command
    if core_port is not None:
        command = command + core_port_command

    if hco_port is not None:
        command = command + hco_port_command

    if core_wsgiapp_port is not None:
        command = command + core_wsgiapp_port_command
    command = command + hcli_core_command

    def generator():
        if path.exists(config_path):
            yield ('stdout', command.encode('utf-8'))
        else:
            error = f"hcli_core: {name} is not installed."
            raise Exception(error)

    return generator()

@contextmanager
def write_lock(file_path):
    lockfile = Path(file_path).with_suffix('.lock')
    with portalocker.Lock(lockfile, timeout=10) as lock:
        yield

        # we cleanup the lock if successful.
        try:
            if lockfile.exists():
                os.unlink(lockfile)
        except OSError:
            pass

create_folder(home)
create_folder(dot_hcli_core)
create_folder(dot_hcli_core_config)
create_folder(dot_hcli_core_var)
create_folder(dot_hcli_core_var_log)

# we load the logger after the configuration is in otherwise we get no logger
from hcli_core import logger

# Map string log levels to logger constants
LOG_LEVELS = {
    'debug': logger.DEBUG,
    'info': logger.INFO,
    'warning': logger.WARNING,
    'error': logger.ERROR,
    'critical' : logger.CRITICAL
}

log = 'log'
log_level = 'INFO'
log_level = LOG_LEVELS.get(log_level.lower(), logger.INFO)
log = logger.Logger("hcli_core", log=log)
log.setLevel(log_level)

