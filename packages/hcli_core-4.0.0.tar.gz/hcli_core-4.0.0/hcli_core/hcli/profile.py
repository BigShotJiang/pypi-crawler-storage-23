class ProfileLink:
    href = None

    def __init__(self):
        self.href = "/hcli/profile"
