# SPDX-FileCopyrightText: 2025-present Tyst Marin <moddingfox@foxtek.us>
#
# SPDX-License-Identifier: MIT
__version__ = "0.0.5"
