# pyser-panel - PyServer Control Center

A premium, modern XAMPP-like control panel written in Python. Manage Apache, MariaDB, and built-in Python servers with a beautiful "Glassmorphism" UI.

## Features

- **Service Management**: Start/Stop Apache and MariaDB/MySQL.
- **Deep Troubleshooting**: One-click fixes for FQDN, 403 Forbidden, and phpMyAdmin issues.
- **Built-in Servers**: Instantly launch Python HTTP and FTP servers.
- **Live Logs**: Stream Apache error logs in real-time.
- **Auto-Detection**: Automatically finds PHP, Perl, and service binaries.
- **Premium UI**: Modern dark theme with smooth animations and status indicators.

### On Linux (Recommended)
```bash
pipx install pyser-panel
```

### On Windows/Other
```bash
pip install pyser-panel
```

## Usage

Simply run:

```bash
pyser
```

## Troubleshooting (Linux)

If Apache permissions are locked, use the integrated **Troubleshooting** menu inside the app to:
- Fix Port 80 conflicts.
- Apply `Require all granted` to your web root.
- Enable phpMyAdmin web access.
