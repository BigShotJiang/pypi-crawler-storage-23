import subprocess
import os
import sys

def install_dependencies():
    required = ["customtkinter", "pyftpdlib"]
    missing = []
    for module in required:
        try:
            __import__(module)
        except ImportError:
            missing.append(module)
    
    if missing:
        print(f"Installing missing dependencies: {missing}...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
            print("Successfully installed dependencies.")
        except Exception as e:
            print(f"Failed to install dependencies: {e}")

def find_executable(name, os_type):
    try:
        return subprocess.check_output(["which" if os_type != "Windows" else "where", name], text=True).strip().split('\n')[0]
    except:
        return ""
