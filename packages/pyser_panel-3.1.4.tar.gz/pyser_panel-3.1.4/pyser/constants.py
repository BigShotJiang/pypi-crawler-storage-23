APP_NAME = "PyServer Control Center"
VERSION = "3.1.4 PRO"
DEVELOPER = "gtsivam"
COLORS = {
    "bg": "#121212",
    "sidebar": "#1a1a1a",
    "card": "#242424",
    "accent": "#3b82f6",
    "success": "#22c55e",
    "danger": "#ef4444",
    "warning": "#f59e0b",
    "text_dim": "#a1a1aa"
}
