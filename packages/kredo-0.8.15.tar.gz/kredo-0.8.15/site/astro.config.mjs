import { defineConfig } from 'astro/config';

export default defineConfig({
  site: 'https://aikredo.com',
  output: 'static',
});
