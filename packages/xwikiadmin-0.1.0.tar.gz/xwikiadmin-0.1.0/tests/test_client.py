"""Unit tests for XWiki Client."""

import pytest
import requests

from xwikiadmin.client import XWikiClient
from xwikiadmin.exceptions import (
    XWikiAuthenticationError,
    XWikiAuthorizationError,
    XWikiConnectionError,
    XWikiEndpointNotFoundError,
)
from xwikiadmin.validators import (
    resolve_password,
    validate_base_url,
    validate_timeout,
)


class TestValidateBaseUrl:
    """Tests for the validate_base_url function."""

    def test_valid_http_url(self):
        """Test that valid HTTP URL is normalized correctly."""
        result = validate_base_url("http://example.org")
        assert result == "http://example.org"

    def test_valid_https_url(self):
        """Test that valid HTTPS URL is normalized correctly."""
        result = validate_base_url("https://example.org")
        assert result == "https://example.org"

    def test_url_with_trailing_slash(self):
        """Test that trailing slash is removed."""
        result = validate_base_url("https://example.org/")
        assert result == "https://example.org"

    def test_url_with_path(self):
        """Test that URL with path is preserved."""
        result = validate_base_url("https://example.org/xwiki/")
        assert result == "https://example.org/xwiki"

    def test_url_without_scheme(self):
        """Test that URL without scheme raises ValueError."""
        with pytest.raises(ValueError, match="Must include scheme"):
            validate_base_url("example.org")

    def test_url_with_invalid_scheme(self):
        """Test that URL with invalid scheme raises ValueError."""
        with pytest.raises(ValueError, match="Must use http or https"):
            validate_base_url("ftp://example.org")

    def test_url_without_domain(self):
        """Test that URL without domain raises ValueError."""
        with pytest.raises(ValueError, match="Must include scheme"):
            validate_base_url("https://")


class TestValidateTimeout:
    """Tests for the validate_timeout function."""

    def test_valid_timeout(self):
        """Test that valid timeout is returned as-is."""
        result = validate_timeout(20)
        assert result == 20

    def test_timeout_minimum(self):
        """Test that minimum timeout (1) is valid."""
        result = validate_timeout(1)
        assert result == 1

    def test_timeout_maximum(self):
        """Test that maximum timeout (300) is valid."""
        result = validate_timeout(300)
        assert result == 300

    def test_timeout_too_low(self):
        """Test that timeout below 1 raises ValueError."""
        with pytest.raises(ValueError, match="between 1 and 300"):
            validate_timeout(0)

    def test_timeout_too_high(self):
        """Test that timeout above 300 raises ValueError."""
        with pytest.raises(ValueError, match="between 1 and 300"):
            validate_timeout(301)

    def test_timeout_negative(self):
        """Test that negative timeout raises ValueError."""
        with pytest.raises(ValueError, match="between 1 and 300"):
            validate_timeout(-1)

    def test_timeout_not_integer(self):
        """Test that non-integer timeout raises TypeError."""
        with pytest.raises(TypeError, match="must be an integer"):
            validate_timeout("20")  # type: ignore[arg-type]

    def test_timeout_float(self):
        """Test that float timeout raises TypeError."""
        with pytest.raises(TypeError, match="must be an integer"):
            validate_timeout(20.5)  # type: ignore[arg-type]


class TestResolvePassword:
    """Tests for the resolve_password function."""

    def test_resolve_password_none(self):
        """Test that None is returned when password is None."""
        result = resolve_password(None)
        assert result is None

    def test_resolve_password_plain(self, caplog):
        """Test that plain password is returned with warning."""
        result = resolve_password("mypassword")
        assert result == "mypassword"
        # Check that warning was logged
        assert "shell history" in caplog.text.lower()

    def test_resolve_password_from_env(self, monkeypatch):
        """Test that password is resolved from environment variable."""
        monkeypatch.setenv("TEST_PASSWORD", "secret123")
        result = resolve_password("env:TEST_PASSWORD")
        assert result == "secret123"

    def test_resolve_password_env_missing(self, monkeypatch):
        """Test that ValueError is raised when env var doesn't exist."""
        monkeypatch.delenv("MISSING_VAR", raising=False)
        with pytest.raises(ValueError, match="Environment variable 'MISSING_VAR'"):
            resolve_password("env:MISSING_VAR")

    def test_resolve_password_env_empty_string(self, monkeypatch):
        """Test that empty string from env var is returned."""
        monkeypatch.setenv("EMPTY_VAR", "")
        result = resolve_password("env:EMPTY_VAR")
        assert result == ""


class TestXWikiClientInit:
    """Tests for XWikiClient initialization."""

    def test_init_basic(self, mock_base_url):
        """Test basic initialization."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        assert client.base_url == mock_base_url
        assert client.timeout == 20
        assert client.session.auth is None

    def test_init_with_auth(self, mock_base_url, mock_credentials):
        """Test initialization with authentication."""
        client = XWikiClient(
            base_url=mock_base_url,
            username=mock_credentials["username"],
            password=mock_credentials["password"],
        )
        assert client.session.auth == (
            mock_credentials["username"],
            mock_credentials["password"],
        )

    def test_init_strips_trailing_slash(self):
        """Test that trailing slash is removed from base URL."""
        client = XWikiClient(
            base_url="https://xwiki.example.org/", username=None, password=None
        )
        assert client.base_url == "https://xwiki.example.org"

    def test_init_custom_timeout(self, mock_base_url):
        """Test initialization with custom timeout."""
        client = XWikiClient(
            base_url=mock_base_url, username=None, password=None, timeout=60
        )
        assert client.timeout == 60

    def test_init_invalid_url(self):
        """Test that invalid URL raises ValueError."""
        with pytest.raises(ValueError, match="Invalid URL"):
            XWikiClient(base_url="not-a-url", username=None, password=None)

    def test_init_url_without_scheme(self):
        """Test that URL without scheme raises ValueError."""
        with pytest.raises(ValueError, match="Must include scheme"):
            XWikiClient(base_url="example.org", username=None, password=None)

    def test_init_url_with_invalid_scheme(self):
        """Test that URL with invalid scheme raises ValueError."""
        with pytest.raises(ValueError, match="Must use http or https"):
            XWikiClient(base_url="ftp://example.org", username=None, password=None)

    def test_init_invalid_timeout(self, mock_base_url):
        """Test that invalid timeout raises ValueError."""
        with pytest.raises(ValueError, match="between 1 and 300"):
            XWikiClient(base_url=mock_base_url, username=None, password=None, timeout=0)

    def test_init_timeout_too_high(self, mock_base_url):
        """Test that timeout above 300 raises ValueError."""
        with pytest.raises(ValueError, match="between 1 and 300"):
            XWikiClient(
                base_url=mock_base_url, username=None, password=None, timeout=301
            )

    def test_init_timeout_not_integer(self, mock_base_url):
        """Test that non-integer timeout raises TypeError."""
        with pytest.raises(TypeError, match="must be an integer"):
            XWikiClient(
                base_url=mock_base_url,
                username=None,
                password=None,
                timeout="20",  # type: ignore[arg-type]
            )

    def test_url_helper(self, mock_base_url):
        """Test the _url() helper method."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        assert client._url("/rest/wikis") == f"{mock_base_url}/rest/wikis"


@pytest.mark.unit
class TestXWikiClientListSpaces:
    """Tests for XWikiClient.list_spaces() method."""

    def test_list_spaces_success_rest(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test successful spaces listing via /rest endpoint."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        spaces = client.list_spaces(wiki="xwiki")

        assert len(spaces) == 2
        assert spaces[0]["name"] == "Main"
        assert spaces[1]["name"] == "Sandbox"

    def test_list_spaces_fallback_xwiki_rest(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test fallback to /xwiki/rest endpoint when /rest fails."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        spaces = client.list_spaces(wiki="xwiki")

        assert len(spaces) == 2
        assert spaces[0]["name"] == "Main"

    def test_list_spaces_nested_structure(
        self, requests_mock, mock_base_url, sample_space_response_nested
    ):
        """Test parsing nested spaces response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response_nested,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        spaces = client.list_spaces(wiki="xwiki")

        assert len(spaces) == 1
        assert spaces[0]["name"] == "Main"

    def test_list_spaces_different_wiki(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test listing spaces from a different wiki."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/otherwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        spaces = client.list_spaces(wiki="otherwiki")

        assert len(spaces) == 2


@pytest.mark.unit
class TestXWikiClientGetPage:
    """Tests for XWikiClient.get_page() method."""

    def test_get_page_success(self, requests_mock, mock_base_url, sample_page_response):
        """Test successful page retrieval."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome",
            json=sample_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        page = client.get_page(wiki="xwiki", space="Sandbox", page="WebHome")

        assert page["title"] == "Sandbox Home"
        assert page["name"] == "WebHome"
        assert page["space"] == "Sandbox"

    def test_get_page_fallback(
        self, requests_mock, mock_base_url, sample_page_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome",
            json=sample_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        page = client.get_page(wiki="xwiki", space="Sandbox", page="WebHome")

        assert page["title"] == "Sandbox Home"

    def test_get_page_url_encoding(
        self, requests_mock, mock_base_url, sample_page_response
    ):
        """Test that special characters in space/page names are URL-encoded."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/My%20Space/pages/My%20Page",
            json=sample_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        page = client.get_page(wiki="xwiki", space="My Space", page="My Page")

        assert page is not None

    def test_get_page_not_found(self, requests_mock, mock_base_url):
        """Test handling when page is not found on any endpoint."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NotFound",
            status_code=404,
        )
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/NotFound",
            status_code=404,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiEndpointNotFoundError) as exc_info:
            client.get_page(wiki="xwiki", space="Sandbox", page="NotFound")

        # Verify the exception contains the attempted paths
        assert len(exc_info.value.attempted_paths) == 2
        assert "/rest/wikis/xwiki/spaces/Sandbox/pages/NotFound" in str(
            exc_info.value.attempted_paths
        )


@pytest.mark.unit
class TestXWikiClientListPageVersions:
    """Tests for XWikiClient.list_page_versions() method."""

    def test_list_page_versions_success(
        self, requests_mock, mock_base_url, sample_page_versions_response
    ):
        """Test successful listing of page versions."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history",
            json=sample_page_versions_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        versions = client.list_page_versions(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(versions) == 3
        assert versions[0]["version"] == "2.1"
        assert versions[0]["author"] == "XWiki.User"
        assert versions[2]["version"] == "1.0"

    def test_list_page_versions_nested_structure(
        self, requests_mock, mock_base_url, sample_page_versions_response_nested
    ):
        """Test handling of nested response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history",
            json=sample_page_versions_response_nested,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        versions = client.list_page_versions(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(versions) == 1
        assert versions[0]["version"] == "1.0"

    def test_list_page_versions_empty(self, requests_mock, mock_base_url):
        """Test handling of empty version history."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Empty/pages/WebHome/history",
            json={"history": []},
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        versions = client.list_page_versions(
            wiki="xwiki", space="Empty", page="WebHome"
        )

        assert versions == []

    def test_list_page_versions_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_page_versions_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history",
            json=sample_page_versions_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        versions = client.list_page_versions(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(versions) == 3
        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientGetPageVersion:
    """Tests for XWikiClient.get_page_version() method."""

    def test_get_page_version_success(
        self, requests_mock, mock_base_url, sample_page_version_response
    ):
        """Test successful retrieval of a specific page version."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/1.0",
            json=sample_page_version_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        version = client.get_page_version(
            wiki="xwiki", space="Sandbox", page="WebHome", version="1.0"
        )

        assert version["version"] == "1.0"
        assert version["author"] == "XWiki.Admin"
        assert "version 1.0 content" in version["content"]

    def test_get_page_version_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_page_version_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/1.0",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/1.0",
            json=sample_page_version_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        version = client.get_page_version(
            wiki="xwiki", space="Sandbox", page="WebHome", version="1.0"
        )

        assert version["version"] == "1.0"
        assert client.endpoint_prefix == "/xwiki/rest"

    def test_get_page_version_not_found(self, requests_mock, mock_base_url):
        """Test that 404 is raised when version doesn't exist."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/99.0",
            status_code=404,
        )
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/99.0",
            status_code=404,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiEndpointNotFoundError):
            client.get_page_version(
                wiki="xwiki", space="Sandbox", page="WebHome", version="99.0"
            )

    def test_get_page_version_url_encoding(
        self, requests_mock, mock_base_url, sample_page_version_response
    ):
        """Test that version numbers with special chars are URL-encoded."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/1.0",
            json=sample_page_version_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        version = client.get_page_version(
            wiki="xwiki", space="Sandbox", page="WebHome", version="1.0"
        )

        assert version is not None


@pytest.mark.unit
class TestXWikiClientListPages:
    """Tests for XWikiClient.list_pages() method."""

    def test_list_pages_success(
        self, requests_mock, mock_base_url, sample_pages_list_response
    ):
        """Test successful pages listing."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages",
            json=sample_pages_list_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        pages = client.list_pages(wiki="xwiki", space="Main")

        assert len(pages) == 2
        assert pages[0]["name"] == "WebHome"
        assert pages[1]["name"] == "Dashboard"

    def test_list_pages_nested_structure(
        self, requests_mock, mock_base_url, sample_pages_list_response_nested
    ):
        """Test parsing nested pages response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages",
            json=sample_pages_list_response_nested,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        pages = client.list_pages(wiki="xwiki", space="Main")

        assert len(pages) == 1
        assert pages[0]["name"] == "WebHome"

    def test_list_pages_fallback(
        self, requests_mock, mock_base_url, sample_pages_list_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages",
            status_code=404,
        )
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Main/pages",
            json=sample_pages_list_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        pages = client.list_pages(wiki="xwiki", space="Main")

        assert len(pages) == 2

    def test_list_pages_not_found(self, requests_mock, mock_base_url):
        """Test error handling when space doesn't exist."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/NonExistent/pages",
            status_code=404,
        )
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/NonExistent/pages",
            status_code=404,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiEndpointNotFoundError) as exc_info:
            client.list_pages(wiki="xwiki", space="NonExistent")

        # Verify the exception contains the attempted paths
        assert len(exc_info.value.attempted_paths) == 2


@pytest.mark.unit
class TestXWikiClientSearch:
    """Tests for XWikiClient.search() method."""

    def test_search_basic(self, requests_mock, mock_base_url, sample_search_response):
        """Test basic search functionality."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        results = client.search(wiki="xwiki", query="test")

        assert len(results) == 2
        assert results[0]["title"] == "Main Home"
        assert results[1]["title"] == "Test Page"

    def test_search_with_space_filter(
        self, requests_mock, mock_base_url, sample_search_response
    ):
        """Test search with space filter."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        results = client.search(wiki="xwiki", query="test", space="Main")

        # Verify space parameter was sent
        assert requests_mock.last_request.qs.get("space") == ["main"]
        assert len(results) == 2

    def test_search_with_limit(
        self, requests_mock, mock_base_url, sample_search_response
    ):
        """Test search with custom limit."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        results = client.search(wiki="xwiki", query="test", limit=50)

        # Verify limit parameter was sent
        assert requests_mock.last_request.qs.get("number") == ["50"]
        assert len(results) == 2

    def test_search_nested_structure(
        self, requests_mock, mock_base_url, sample_search_response_nested
    ):
        """Test parsing nested search response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response_nested,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        results = client.search(wiki="xwiki", query="test")

        assert len(results) == 1
        assert results[0]["title"] == "Main Home"

    def test_search_fallback(
        self, requests_mock, mock_base_url, sample_search_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            status_code=404,
        )
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        results = client.search(wiki="xwiki", query="test")

        assert len(results) == 2


@pytest.mark.unit
class TestXWikiClientErrorHandling:
    """Tests for error handling in XWikiClient."""

    def test_get_raises_on_error(self, requests_mock, mock_base_url):
        """Test that get() raises HTTPError on non-2xx status codes."""
        requests_mock.get(
            f"{mock_base_url}/rest/test",
            status_code=500,
            json={"error": "Internal Server Error"},
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(requests.HTTPError):
            client.get("/rest/test")

    def test_authentication_error(self, requests_mock, mock_base_url):
        """Test that 401 status raises XWikiAuthenticationError."""
        requests_mock.get(
            f"{mock_base_url}/rest/test",
            status_code=401,
            json={"error": "Unauthorized"},
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthenticationError) as exc_info:
            client.get("/rest/test")

        assert exc_info.value.status_code == 401
        assert "credentials" in str(exc_info.value).lower()

    def test_authorization_error(self, requests_mock, mock_base_url):
        """Test that 403 status raises XWikiAuthorizationError."""
        requests_mock.get(
            f"{mock_base_url}/rest/test",
            status_code=403,
            json={"error": "Forbidden"},
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthorizationError) as exc_info:
            client.get("/rest/test")

        assert exc_info.value.status_code == 403
        assert "permissions" in str(exc_info.value).lower()

    def test_connection_error(self, requests_mock, mock_base_url):
        """Test that connection errors raise XWikiConnectionError."""
        requests_mock.get(
            f"{mock_base_url}/rest/test",
            exc=requests.ConnectionError("Connection refused"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError) as exc_info:
            client.get("/rest/test")

        assert mock_base_url in str(exc_info.value)
        assert exc_info.value.base_url == mock_base_url

    def test_timeout_error(self, requests_mock, mock_base_url):
        """Test that timeout errors raise XWikiConnectionError."""
        requests_mock.get(
            f"{mock_base_url}/rest/test",
            exc=requests.Timeout("Request timed out"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError) as exc_info:
            client.get("/rest/test")

        assert mock_base_url in str(exc_info.value)

    def test_timeout_configuration(self, requests_mock, mock_base_url):
        """Test that timeout is applied to requests."""
        requests_mock.get(f"{mock_base_url}/rest/test", json={}, status_code=200)

        client = XWikiClient(
            base_url=mock_base_url, username=None, password=None, timeout=30
        )
        client.get("/rest/test")

        # requests_mock doesn't capture timeout, but we can verify it's set
        assert client.timeout == 30

    def test_auth_error_stops_endpoint_retry(self, requests_mock, mock_base_url):
        """Test that authentication errors stop endpoint retry logic."""
        # First endpoint returns 401
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            status_code=401,
        )
        # Second endpoint should not be tried
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces",
            json={"spaces": []},
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        # Should raise auth error and not try second endpoint
        with pytest.raises(XWikiAuthenticationError):
            client.list_spaces()

        # Verify only one request was made (auth error stopped retry)
        assert len(requests_mock.request_history) == 1


@pytest.mark.unit
class TestXWikiClientEndpointCaching:
    """Tests for endpoint pattern caching behavior."""

    def test_endpoint_prefix_initially_none(self, mock_base_url):
        """Test that endpoint_prefix is None before any request."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        assert client.endpoint_prefix is None

    def test_endpoint_prefix_cached_after_success(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test that successful request caches the endpoint prefix."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces()

        assert client.endpoint_prefix == "/rest"

    def test_endpoint_prefix_cached_fallback(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test that fallback endpoint is cached when first fails."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces()

        assert client.endpoint_prefix == "/xwiki/rest"

    def test_cached_prefix_used_for_subsequent_requests(
        self, requests_mock, mock_base_url, sample_space_response, sample_page_response
    ):
        """Test that cached prefix is used for subsequent requests."""
        # Setup both endpoints for spaces
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )
        # Setup page endpoint only on /rest (not /xwiki/rest)
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome",
            json=sample_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        # First request discovers the endpoint
        client.list_spaces()
        assert client.endpoint_prefix == "/rest"

        # Second request should use cached prefix directly
        client.get_page(wiki="xwiki", space="Sandbox", page="WebHome")

        # Verify only 2 requests were made (no retry attempts)
        assert len(requests_mock.request_history) == 2

    def test_clear_endpoint_cache(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test that clear_endpoint_cache() resets the cached prefix."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces()
        assert client.endpoint_prefix == "/rest"

        client.clear_endpoint_cache()
        assert client.endpoint_prefix is None

    def test_cache_invalidated_on_error(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test that cache is invalidated when cached endpoint returns error."""
        # First request succeeds on /rest
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces()
        assert client.endpoint_prefix == "/rest"

        # Now simulate /rest failing for pages
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages",
            status_code=500,
        )
        # And /xwiki/rest works
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Main/pages",
            json={"pages": []},
            status_code=200,
        )

        # This should invalidate cache and rediscover
        client.list_pages(wiki="xwiki", space="Main")

        # Cache should now point to fallback
        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientResponseCaching:
    """Tests for response caching behavior."""

    def test_cache_disabled_by_default(self, mock_base_url):
        """Test that response caching is disabled by default."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        assert client.cache_enabled is False

    def test_cache_enabled_when_requested(self, mock_base_url):
        """Test that response caching can be enabled."""
        client = XWikiClient(
            base_url=mock_base_url,
            username=None,
            password=None,
            cache_enabled=True,
        )
        assert client.cache_enabled is True

    def test_cache_ttl_default(self, mock_base_url):
        """Test that cached session has correct default TTL."""
        client = XWikiClient(
            base_url=mock_base_url,
            username=None,
            password=None,
            cache_enabled=True,
        )
        # Check that a CachedSession is used
        import requests_cache

        assert isinstance(client.session, requests_cache.CachedSession)

    def test_cache_ttl_custom(self, mock_base_url):
        """Test that cached session respects custom TTL."""
        client = XWikiClient(
            base_url=mock_base_url,
            username=None,
            password=None,
            cache_enabled=True,
            cache_ttl=600,
        )
        import requests_cache

        assert isinstance(client.session, requests_cache.CachedSession)

    def test_non_cached_session_when_disabled(self, mock_base_url):
        """Test that regular Session is used when caching is disabled."""
        import requests_cache

        client = XWikiClient(
            base_url=mock_base_url,
            username=None,
            password=None,
            cache_enabled=False,
        )
        # Should be a regular Session, not CachedSession
        assert not isinstance(client.session, requests_cache.CachedSession)


@pytest.mark.unit
class TestXWikiClientPagination:
    """Tests for pagination support in XWikiClient methods."""

    def test_list_spaces_with_offset(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test list_spaces with offset parameter."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces(wiki="xwiki", offset=10)

        # Verify offset was sent as 'start' parameter
        assert requests_mock.last_request.qs.get("start") == ["10"]

    def test_list_spaces_with_limit(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test list_spaces with limit parameter."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces(wiki="xwiki", limit=50)

        # Verify limit was sent as 'number' parameter
        assert requests_mock.last_request.qs.get("number") == ["50"]

    def test_list_spaces_with_offset_and_limit(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test list_spaces with both offset and limit parameters."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces(wiki="xwiki", offset=20, limit=10)

        # Verify both parameters were sent
        assert requests_mock.last_request.qs.get("start") == ["20"]
        assert requests_mock.last_request.qs.get("number") == ["10"]

    def test_list_spaces_no_pagination_params(
        self, requests_mock, mock_base_url, sample_space_response
    ):
        """Test list_spaces without pagination parameters sends no query params."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_spaces(wiki="xwiki")

        # Verify no pagination params were sent
        assert "start" not in requests_mock.last_request.qs
        assert "number" not in requests_mock.last_request.qs

    def test_list_pages_with_pagination(
        self, requests_mock, mock_base_url, sample_pages_list_response
    ):
        """Test list_pages with pagination parameters."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages",
            json=sample_pages_list_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.list_pages(wiki="xwiki", space="Main", offset=5, limit=25)

        # Verify pagination parameters were sent
        assert requests_mock.last_request.qs.get("start") == ["5"]
        assert requests_mock.last_request.qs.get("number") == ["25"]

    def test_search_with_offset(
        self, requests_mock, mock_base_url, sample_search_response
    ):
        """Test search with offset parameter."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.search(wiki="xwiki", query="test", offset=10, limit=20)

        # Verify offset was sent as 'start' parameter
        assert requests_mock.last_request.qs.get("start") == ["10"]
        assert requests_mock.last_request.qs.get("number") == ["20"]

    def test_search_offset_zero_not_sent(
        self, requests_mock, mock_base_url, sample_search_response
    ):
        """Test search with offset=0 doesn't include start parameter."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.search(wiki="xwiki", query="test", offset=0)

        # Verify start param not sent when offset is 0
        assert "start" not in requests_mock.last_request.qs


@pytest.mark.unit
class TestXWikiClientPutPage:
    """Tests for XWikiClient.put_page() method."""

    def test_put_page_success(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test successful page creation/update."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            json=sample_put_page_response,
            status_code=201,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.put_page(
            wiki="xwiki",
            space="Sandbox",
            page="NewPage",
            title="New Page Title",
            content="This is the page content.",
        )

        assert result["title"] == "New Page Title"
        assert result["name"] == "NewPage"
        assert result["space"] == "Sandbox"

    def test_put_page_sends_correct_data(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test that put_page sends correct JSON data."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/TestPage",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.put_page(
            wiki="xwiki",
            space="Sandbox",
            page="TestPage",
            title="Test Title",
            content="Test content here.",
        )

        # Verify request body
        assert requests_mock.last_request.json() == {
            "title": "Test Title",
            "content": "Test content here.",
        }

    def test_put_page_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.put(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            json=sample_put_page_response,
            status_code=201,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.put_page(
            wiki="xwiki",
            space="Sandbox",
            page="NewPage",
            title="New Page Title",
            content="Content",
        )

        assert result["title"] == "New Page Title"
        # Verify fallback endpoint is now cached
        assert client.endpoint_prefix == "/xwiki/rest"

    def test_put_page_url_encoding(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test that special characters in space/page names are URL-encoded."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/My%20Space/pages/My%20Page",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.put_page(
            wiki="xwiki",
            space="My Space",
            page="My Page",
            title="Title",
            content="Content",
        )

        assert result is not None

    def test_put_page_authentication_error(self, requests_mock, mock_base_url):
        """Test that 401 raises XWikiAuthenticationError."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            status_code=401,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthenticationError):
            client.put_page(
                wiki="xwiki",
                space="Sandbox",
                page="NewPage",
                title="Title",
                content="Content",
            )

    def test_put_page_authorization_error(self, requests_mock, mock_base_url):
        """Test that 403 raises XWikiAuthorizationError."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            status_code=403,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthorizationError):
            client.put_page(
                wiki="xwiki",
                space="Sandbox",
                page="NewPage",
                title="Title",
                content="Content",
            )


@pytest.mark.unit
class TestXWikiClientUpdatePage:
    """Tests for XWikiClient.update_page() method."""

    def test_update_page_with_title_only(
        self,
        requests_mock,
        mock_base_url,
        sample_page_response,
        sample_put_page_response,
    ):
        """Test updating only the page title."""
        # First request: get_page to fetch current content
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_page_response,
            status_code=200,
        )
        # Second request: put_page to update
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.update_page(
            wiki="xwiki",
            space="Sandbox",
            page="ExistingPage",
            title="Updated Title",
        )

        assert result["title"] == "New Page Title"

    def test_update_page_with_content_only(
        self,
        requests_mock,
        mock_base_url,
        sample_page_response,
        sample_put_page_response,
    ):
        """Test updating only the page content."""
        # First request: get_page to fetch current title
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_page_response,
            status_code=200,
        )
        # Second request: put_page to update
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.update_page(
            wiki="xwiki",
            space="Sandbox",
            page="ExistingPage",
            content="Updated content.",
        )

        assert result["title"] == "New Page Title"

    def test_update_page_with_both(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test updating both title and content."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.update_page(
            wiki="xwiki",
            space="Sandbox",
            page="ExistingPage",
            title="Updated Title",
            content="Updated content.",
        )

        assert result["title"] == "New Page Title"

    def test_update_page_requires_at_least_one_param(self, mock_base_url):
        """Test that update_page requires at least title or content."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(ValueError, match="At least one of"):
            client.update_page(
                wiki="xwiki",
                space="Sandbox",
                page="ExistingPage",
            )

    def test_update_page_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.put(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.update_page(
            wiki="xwiki",
            space="Sandbox",
            page="ExistingPage",
            title="Updated Title",
            content="Updated content.",
        )

        assert result["title"] == "New Page Title"
        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientPutMethod:
    """Tests for XWikiClient.put() method."""

    def test_put_connection_error(self, requests_mock, mock_base_url):
        """Test that connection errors raise XWikiConnectionError."""
        requests_mock.put(
            f"{mock_base_url}/rest/test",
            exc=requests.ConnectionError("Connection refused"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError):
            client.put("/rest/test", data={"test": "data"})

    def test_put_timeout_error(self, requests_mock, mock_base_url):
        """Test that timeout errors raise XWikiConnectionError."""
        requests_mock.put(
            f"{mock_base_url}/rest/test",
            exc=requests.Timeout("Request timed out"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError):
            client.put("/rest/test", data={"test": "data"})


@pytest.mark.unit
class TestXWikiClientListAttachments:
    """Tests for XWikiClient.list_attachments() method."""

    def test_list_attachments_success(
        self, requests_mock, mock_base_url, sample_attachments_response
    ):
        """Test successful attachments listing."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments",
            json=sample_attachments_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        attachments = client.list_attachments(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(attachments) == 2
        assert attachments[0]["name"] == "document.pdf"
        assert attachments[1]["name"] == "image.png"

    def test_list_attachments_nested_structure(self, requests_mock, mock_base_url):
        """Test parsing nested attachments response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments",
            json={"attachments": {"attachment": [{"name": "test.pdf", "size": 1000}]}},
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        attachments = client.list_attachments(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(attachments) == 1
        assert attachments[0]["name"] == "test.pdf"

    def test_list_attachments_empty(self, requests_mock, mock_base_url):
        """Test empty attachments list."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments",
            json={"attachments": []},
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        attachments = client.list_attachments(
            wiki="xwiki", space="Sandbox", page="WebHome"
        )

        assert len(attachments) == 0


@pytest.mark.unit
class TestXWikiClientGetAttachment:
    """Tests for XWikiClient.get_attachment() method."""

    def test_get_attachment_success(self, requests_mock, mock_base_url):
        """Test successful attachment download."""
        file_content = b"PDF file content here"
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/doc.pdf",
            content=file_content,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        content = client.get_attachment(
            wiki="xwiki", space="Sandbox", page="WebHome", filename="doc.pdf"
        )

        assert content == file_content

    def test_get_attachment_url_encoding(self, requests_mock, mock_base_url):
        """Test that special characters in filename are URL-encoded."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/my%20file.pdf",
            content=b"content",
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        content = client.get_attachment(
            wiki="xwiki", space="Sandbox", page="WebHome", filename="my file.pdf"
        )

        assert content == b"content"


@pytest.mark.unit
class TestXWikiClientPutAttachment:
    """Tests for XWikiClient.put_attachment() method."""

    def test_put_attachment_success(
        self, requests_mock, mock_base_url, sample_attachment_metadata
    ):
        """Test successful attachment upload."""
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/new.pdf",
            json=sample_attachment_metadata,
            status_code=201,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.put_attachment(
            wiki="xwiki",
            space="Sandbox",
            page="WebHome",
            filename="new.pdf",
            content=b"file content",
            content_type="application/pdf",
        )

        assert result["name"] == "uploaded.pdf"

    def test_put_attachment_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_attachment_metadata
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/new.pdf",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.put(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/new.pdf",
            json=sample_attachment_metadata,
            status_code=201,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.put_attachment(
            wiki="xwiki",
            space="Sandbox",
            page="WebHome",
            filename="new.pdf",
            content=b"file content",
        )

        assert result["name"] == "uploaded.pdf"
        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientDeleteAttachment:
    """Tests for XWikiClient.delete_attachment() method."""

    def test_delete_attachment_success(self, requests_mock, mock_base_url):
        """Test successful attachment deletion."""
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/old.pdf",
            status_code=204,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        # Should not raise any exception
        client.delete_attachment(
            wiki="xwiki", space="Sandbox", page="WebHome", filename="old.pdf"
        )

    def test_delete_attachment_fallback_endpoint(self, requests_mock, mock_base_url):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/old.pdf",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.delete(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/old.pdf",
            status_code=204,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.delete_attachment(
            wiki="xwiki", space="Sandbox", page="WebHome", filename="old.pdf"
        )

        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientDeleteMethod:
    """Tests for XWikiClient.delete() method."""

    def test_delete_connection_error(self, requests_mock, mock_base_url):
        """Test that connection errors raise XWikiConnectionError."""
        requests_mock.delete(
            f"{mock_base_url}/rest/test",
            exc=requests.ConnectionError("Connection refused"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError):
            client.delete("/rest/test")

    def test_delete_authentication_error(self, requests_mock, mock_base_url):
        """Test that 401 raises XWikiAuthenticationError."""
        requests_mock.delete(
            f"{mock_base_url}/rest/test",
            status_code=401,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthenticationError):
            client.delete("/rest/test")

    def test_delete_authorization_error(self, requests_mock, mock_base_url):
        """Test that 403 raises XWikiAuthorizationError."""
        requests_mock.delete(
            f"{mock_base_url}/rest/test",
            status_code=403,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthorizationError):
            client.delete("/rest/test")


@pytest.mark.unit
class TestXWikiClientListComments:
    """Tests for XWikiClient.list_comments() method."""

    def test_list_comments_success(
        self, requests_mock, mock_base_url, sample_comments_response
    ):
        """Test successful listing of comments."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comments_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        comments = client.list_comments(wiki="xwiki", space="Sandbox", page="WebHome")

        assert len(comments) == 2
        assert comments[0]["id"] == 1
        assert comments[0]["author"] == "XWiki.Admin"
        assert comments[0]["text"] == "This is a great page!"

    def test_list_comments_nested_structure(
        self, requests_mock, mock_base_url, sample_comments_response_nested
    ):
        """Test handling of nested response structure."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Main/pages/WebHome/comments",
            json=sample_comments_response_nested,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        comments = client.list_comments(wiki="xwiki", space="Main", page="WebHome")

        assert len(comments) == 1
        assert comments[0]["id"] == 1
        assert comments[0]["text"] == "This is a comment."

    def test_list_comments_empty(self, requests_mock, mock_base_url):
        """Test handling of empty comments list."""
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Empty/pages/WebHome/comments",
            json={"comments": []},
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        comments = client.list_comments(wiki="xwiki", space="Empty", page="WebHome")

        assert comments == []

    def test_list_comments_fallback_endpoint(
        self, requests_mock, mock_base_url, sample_comments_response
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.get(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comments_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        comments = client.list_comments(wiki="xwiki", space="Sandbox", page="WebHome")

        assert len(comments) == 2
        assert client.endpoint_prefix == "/xwiki/rest"


@pytest.mark.unit
class TestXWikiClientAddComment:
    """Tests for XWikiClient.add_comment() method."""

    def test_add_comment_success(
        self, requests_mock, mock_base_url, mock_credentials, sample_comment_metadata
    ):
        """Test successful comment creation."""
        requests_mock.post(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comment_metadata,
            status_code=201,
        )

        client = XWikiClient(
            base_url=mock_base_url,
            username=mock_credentials["username"],
            password=mock_credentials["password"],
        )
        result = client.add_comment(
            wiki="xwiki",
            space="Sandbox",
            page="WebHome",
            text="New comment text",
        )

        assert result["id"] == 3
        assert result["text"] == "New comment text"
        assert result["author"] == "XWiki.TestUser"

    def test_add_comment_fallback_endpoint(
        self, requests_mock, mock_base_url, mock_credentials, sample_comment_metadata
    ):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.post(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.post(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comment_metadata,
            status_code=201,
        )

        client = XWikiClient(
            base_url=mock_base_url,
            username=mock_credentials["username"],
            password=mock_credentials["password"],
        )
        result = client.add_comment(
            wiki="xwiki",
            space="Sandbox",
            page="WebHome",
            text="New comment text",
        )

        assert result["id"] == 3
        assert client.endpoint_prefix == "/xwiki/rest"

    def test_add_comment_endpoint_not_found(
        self, requests_mock, mock_base_url, mock_credentials
    ):
        """Test that XWikiEndpointNotFoundError is raised when all endpoints fail."""
        requests_mock.post(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            status_code=404,
        )
        requests_mock.post(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            status_code=404,
        )

        client = XWikiClient(
            base_url=mock_base_url,
            username=mock_credentials["username"],
            password=mock_credentials["password"],
        )

        with pytest.raises(XWikiEndpointNotFoundError):
            client.add_comment(
                wiki="xwiki",
                space="Sandbox",
                page="WebHome",
                text="Test comment",
            )


@pytest.mark.unit
class TestXWikiClientPostMethod:
    """Tests for XWikiClient.post() method."""

    def test_post_connection_error(self, requests_mock, mock_base_url):
        """Test that connection errors raise XWikiConnectionError."""
        requests_mock.post(
            f"{mock_base_url}/rest/test",
            exc=requests.ConnectionError("Connection refused"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError):
            client.post("/rest/test", data={"key": "value"})

    def test_post_authentication_error(self, requests_mock, mock_base_url):
        """Test that 401 raises XWikiAuthenticationError."""
        requests_mock.post(
            f"{mock_base_url}/rest/test",
            status_code=401,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthenticationError):
            client.post("/rest/test", data={"key": "value"})

    def test_post_authorization_error(self, requests_mock, mock_base_url):
        """Test that 403 raises XWikiAuthorizationError."""
        requests_mock.post(
            f"{mock_base_url}/rest/test",
            status_code=403,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthorizationError):
            client.post("/rest/test", data={"key": "value"})

    def test_post_timeout_error(self, requests_mock, mock_base_url):
        """Test that timeout raises XWikiConnectionError."""
        requests_mock.post(
            f"{mock_base_url}/rest/test",
            exc=requests.Timeout("Request timed out"),
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiConnectionError):
            client.post("/rest/test", data={"key": "value"})


@pytest.mark.unit
class TestXWikiClientDeleteComment:
    """Tests for XWikiClient.delete_comment() method."""

    def test_delete_comment_success(self, requests_mock, mock_base_url):
        """Test successful comment deletion."""
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=204,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        # Should not raise any exception
        client.delete_comment(
            wiki="xwiki", space="Sandbox", page="WebHome", comment_id=1
        )

    def test_delete_comment_fallback_endpoint(self, requests_mock, mock_base_url):
        """Test fallback to /xwiki/rest endpoint."""
        # First endpoint fails
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=404,
        )
        # Second endpoint succeeds
        requests_mock.delete(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=204,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        client.delete_comment(
            wiki="xwiki", space="Sandbox", page="WebHome", comment_id=1
        )

        assert client.endpoint_prefix == "/xwiki/rest"

    def test_delete_comment_not_found(self, requests_mock, mock_base_url):
        """Test that 404 is not caught (comment doesn't exist)."""
        # Both endpoints fail with 404
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/999",
            status_code=404,
        )
        requests_mock.delete(
            f"{mock_base_url}/xwiki/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/999",
            status_code=404,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiEndpointNotFoundError):
            client.delete_comment(
                wiki="xwiki", space="Sandbox", page="WebHome", comment_id=999
            )

    def test_delete_comment_authentication_error(self, requests_mock, mock_base_url):
        """Test that 401 raises XWikiAuthenticationError."""
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=401,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthenticationError):
            client.delete_comment(
                wiki="xwiki", space="Sandbox", page="WebHome", comment_id=1
            )

    def test_delete_comment_authorization_error(self, requests_mock, mock_base_url):
        """Test that 403 raises XWikiAuthorizationError."""
        requests_mock.delete(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=403,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(XWikiAuthorizationError):
            client.delete_comment(
                wiki="xwiki", space="Sandbox", page="WebHome", comment_id=1
            )


@pytest.mark.unit
class TestXWikiClientBulkUpdatePages:
    """Tests for XWikiClient.bulk_update_pages() method."""

    def test_bulk_update_pages_all_success(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test successful bulk update of multiple pages."""
        pages = ["Page1", "Page2"]
        for page in pages:
            requests_mock.put(
                f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_put_page_response,
                status_code=200,
            )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.bulk_update_pages(
            wiki="xwiki",
            space="Sandbox",
            pages=pages,
            title="Updated Title",
            content="Updated content.",
        )

        assert result["updated"] == 2
        assert result["failed"] == 0
        assert len(result["details"]) == 2
        assert result["details"][0]["status"] == "success"

    def test_bulk_update_pages_partial_failure(
        self, requests_mock, mock_base_url, sample_put_page_response
    ):
        """Test bulk update with some failures."""
        pages = ["Page1", "Page2", "Page3"]
        # Success for Page1 and Page2
        for page in pages[:2]:
            requests_mock.put(
                f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_put_page_response,
                status_code=200,
            )
        # Failure for Page3
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/Page3",
            status_code=403,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.bulk_update_pages(
            wiki="xwiki",
            space="Sandbox",
            pages=pages,
            title="Updated Title",
            content="Updated content.",
        )

        assert result["updated"] == 2
        assert result["failed"] == 1
        assert result["details"][2]["status"] == "failed"

    def test_bulk_update_pages_with_title_only(
        self,
        requests_mock,
        mock_base_url,
        sample_page_response,
        sample_put_page_response,
    ):
        """Test bulk update with only title (content fetched from pages)."""
        pages = ["Page1", "Page2"]
        # Get requests to fetch current content
        for page in pages:
            requests_mock.get(
                f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_page_response,
                status_code=200,
            )
            requests_mock.put(
                f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_put_page_response,
                status_code=200,
            )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.bulk_update_pages(
            wiki="xwiki",
            space="Sandbox",
            pages=pages,
            title="New Title",
        )

        assert result["updated"] == 2
        assert result["failed"] == 0

    def test_bulk_update_pages_empty_list(self, mock_base_url):
        """Test that empty page list raises ValueError."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(ValueError, match="At least one page"):
            client.bulk_update_pages(
                wiki="xwiki",
                space="Sandbox",
                pages=[],
                title="Title",
            )

    def test_bulk_update_pages_no_content_or_title(self, mock_base_url):
        """Test that neither content nor title raises ValueError."""
        client = XWikiClient(base_url=mock_base_url, username=None, password=None)

        with pytest.raises(ValueError, match="At least one of"):
            client.bulk_update_pages(
                wiki="xwiki",
                space="Sandbox",
                pages=["Page1"],
            )

    def test_bulk_update_pages_with_content_only(
        self,
        requests_mock,
        mock_base_url,
        sample_page_response,
        sample_put_page_response,
    ):
        """Test bulk update with only content (title fetched from pages)."""
        pages = ["Page1"]
        requests_mock.get(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/Page1",
            json=sample_page_response,
            status_code=200,
        )
        requests_mock.put(
            f"{mock_base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/Page1",
            json=sample_put_page_response,
            status_code=200,
        )

        client = XWikiClient(base_url=mock_base_url, username=None, password=None)
        result = client.bulk_update_pages(
            wiki="xwiki",
            space="Sandbox",
            pages=pages,
            content="New content.",
        )

        assert result["updated"] == 1
        assert result["failed"] == 0
