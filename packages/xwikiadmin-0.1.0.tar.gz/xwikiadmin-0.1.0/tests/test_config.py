"""Tests for configuration module."""

from __future__ import annotations

from pathlib import Path

import pytest

from xwikiadmin.config import (
    get_default_config_path,
    load_config,
    save_config,
)
from xwikiadmin.exceptions import XWikiConfigError


class TestGetDefaultConfigPath:
    """Tests for get_default_config_path()."""

    def test_returns_path_object(self) -> None:
        """Should return a Path object."""
        path = get_default_config_path()
        assert isinstance(path, Path)

    def test_xdg_path(self, tmp_path: Path) -> None:
        """Should return XDG config path by default."""
        path = get_default_config_path()
        assert path.parts[-3:] == (".config", "xwiki", "config.toml")

    def test_prefers_legacy_if_exists(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Should prefer legacy path if it exists."""
        # Create a fake home directory
        fake_home = tmp_path / "home"
        fake_home.mkdir()

        # Create legacy file
        legacy_file = fake_home / ".xwikirc.toml"
        legacy_file.write_text("[default]\nbase_url = 'https://test'\n")

        # Mock Path.home()
        monkeypatch.setattr(Path, "home", lambda: fake_home)

        path = get_default_config_path()
        assert path == legacy_file


class TestLoadConfig:
    """Tests for load_config()."""

    def test_returns_empty_dict_when_file_not_exists(self, tmp_path: Path) -> None:
        """Should return empty dict if config file doesn't exist."""
        config_path = tmp_path / "nonexistent.toml"
        result = load_config(config_path)
        assert result == {}

    def test_loads_default_profile(self, tmp_path: Path) -> None:
        """Should load values from default profile."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[default]\nbase_url = "https://xwiki.example.org"\n'
            'username = "john"\npassword = "secret"\n'
        )

        result = load_config(config_file)
        assert result == {
            "base_url": "https://xwiki.example.org",
            "username": "john",
            "password": "secret",
        }

    def test_loads_named_profile(self, tmp_path: Path) -> None:
        """Should load values from named profile."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[default]\nbase_url = "https://default.org"\nusername = "default_user"\n'
            '[profiles.work]\nbase_url = "https://work.org"\nusername = "work_user"\n'
        )

        result = load_config(config_file, profile="work")
        assert result["base_url"] == "https://work.org"
        assert result["username"] == "work_user"

    def test_profile_inherits_default_values(self, tmp_path: Path) -> None:
        """Profile should inherit values from default if not overridden."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[default]\nbase_url = "https://default.org"\n'
            'username = "default_user"\npassword = "default_pass"\n'
            '[profiles.work]\nbase_url = "https://work.org"\n'
        )

        result = load_config(config_file, profile="work")
        assert result["base_url"] == "https://work.org"  # overridden
        assert result["username"] == "default_user"  # inherited
        assert result["password"] == "default_pass"  # noqa: S105 (test data)

    def test_raises_error_for_missing_profile(self, tmp_path: Path) -> None:
        """Should raise error if profile doesn't exist."""
        config_file = tmp_path / "config.toml"
        config_file.write_text('[default]\nbase_url = "https://test.org"\n')

        with pytest.raises(XWikiConfigError, match="Profile 'missing' not found"):
            load_config(config_file, profile="missing")

    def test_raises_error_for_invalid_toml(self, tmp_path: Path) -> None:
        """Should raise error for invalid TOML syntax."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("[invalid\nthis is not valid toml")

        with pytest.raises(XWikiConfigError, match="Failed to parse config file"):
            load_config(config_file)


class TestSaveConfig:
    """Tests for save_config()."""

    def test_creates_file_if_not_exists(self, tmp_path: Path) -> None:
        """Should create config file if it doesn't exist."""
        config_file = tmp_path / "config.toml"

        save_config(config_file, "base_url", "https://test.org")

        assert config_file.exists()
        content = config_file.read_text()
        assert "https://test.org" in content

    def test_creates_parent_directories(self, tmp_path: Path) -> None:
        """Should create parent directories if they don't exist."""
        config_file = tmp_path / "nested" / "config" / "file.toml"

        save_config(config_file, "base_url", "https://test.org")

        assert config_file.exists()

    def test_saves_to_default_profile(self, tmp_path: Path) -> None:
        """Should save to default profile."""
        config_file = tmp_path / "config.toml"

        save_config(config_file, "base_url", "https://test.org", profile="default")

        content = config_file.read_text()
        assert "[default]" in content
        assert 'base_url = "https://test.org"' in content

    def test_saves_to_named_profile(self, tmp_path: Path) -> None:
        """Should save to named profile."""
        config_file = tmp_path / "config.toml"

        save_config(config_file, "base_url", "https://work.org", profile="work")

        content = config_file.read_text()
        assert "[profiles.work]" in content
        assert 'base_url = "https://work.org"' in content

    def test_preserves_existing_values(self, tmp_path: Path) -> None:
        """Should preserve existing values when updating."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[default]\nbase_url = "https://test.org"\nusername = "john"\n'
        )

        save_config(config_file, "password", "secret", profile="default")

        result = load_config(config_file)
        assert result["base_url"] == "https://test.org"
        assert result["username"] == "john"
        assert result["password"] == "secret"  # noqa: S105 (test data)

    def test_updates_existing_value(self, tmp_path: Path) -> None:
        """Should update existing values."""
        config_file = tmp_path / "config.toml"
        config_file.write_text('[default]\nbase_url = "https://old.org"\n')

        save_config(config_file, "base_url", "https://new.org")

        result = load_config(config_file)
        assert result["base_url"] == "https://new.org"

    def test_escapes_special_characters(self, tmp_path: Path) -> None:
        """Should properly escape special characters in values."""
        config_file = tmp_path / "config.toml"

        save_config(config_file, "password", 'secret"with"quotes')

        content = config_file.read_text()
        # Should be escaped
        assert '\\"' in content

        # Should load correctly
        result = load_config(config_file)
        assert result["password"] == 'secret"with"quotes'  # noqa: S105 (test data)

    def test_handles_backslashes(self, tmp_path: Path) -> None:
        """Should properly escape backslashes in values."""
        config_file = tmp_path / "config.toml"

        save_config(config_file, "password", "secret\\with\\backslash")

        result = load_config(config_file)
        assert result["password"] == "secret\\with\\backslash"  # noqa: S105

    def test_uses_default_path_when_none(
        self, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
    ) -> None:
        """Should use default path when config_path is None."""
        # Mock get_default_config_path to return our tmp path
        default_path = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.config.get_default_config_path",
            lambda: default_path,
        )

        save_config(None, "base_url", "https://test.org")

        assert default_path.exists()


class TestIntegration:
    """Integration tests for config module."""

    def test_save_and_load_roundtrip(self, tmp_path: Path) -> None:
        """Should be able to save and load config correctly."""
        config_file = tmp_path / "config.toml"

        # Save config
        save_config(config_file, "base_url", "https://xwiki.org", profile="default")
        save_config(config_file, "username", "john", profile="default")
        save_config(config_file, "password", "env:PASS", profile="default")

        # Load config
        result = load_config(config_file)
        assert result == {
            "base_url": "https://xwiki.org",
            "username": "john",
            "password": "env:PASS",
        }

    def test_multiple_profiles(self, tmp_path: Path) -> None:
        """Should handle multiple profiles correctly."""
        config_file = tmp_path / "config.toml"

        # Create default and work profiles
        save_config(config_file, "base_url", "https://default.org", profile="default")
        save_config(config_file, "username", "default_user", profile="default")

        save_config(config_file, "base_url", "https://work.org", profile="work")
        save_config(config_file, "username", "work_user", profile="work")

        # Load default
        default_cfg = load_config(config_file, profile="default")
        assert default_cfg["base_url"] == "https://default.org"
        assert default_cfg["username"] == "default_user"

        # Load work
        work_cfg = load_config(config_file, profile="work")
        assert work_cfg["base_url"] == "https://work.org"
        assert work_cfg["username"] == "work_user"
