"""Integration tests for XWiki CLI commands."""

import json

import pytest
from click.testing import CliRunner

from xwikiadmin.cli import cli


@pytest.fixture
def cli_runner():
    """Fixture that provides a Click CLI test runner."""
    return CliRunner()


@pytest.mark.integration
class TestCLISpacesCommands:
    """Integration tests for spaces CLI commands."""

    def test_spaces_list_success(
        self, cli_runner, requests_mock, sample_space_response
    ):
        """Test 'spaces list' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "spaces",
                "list",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2
        assert output_data[0]["name"] == "Main"

    def test_spaces_list_different_wiki(
        self, cli_runner, requests_mock, sample_space_response
    ):
        """Test 'spaces list' command with different wiki."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/otherwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "spaces",
                "list",
                "--wiki",
                "otherwiki",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2

    def test_spaces_list_missing_base_url(self, cli_runner):
        """Test that missing --base-url is caught."""
        result = cli_runner.invoke(cli, ["spaces", "list"])

        assert result.exit_code != 0
        assert "base-url" in result.output.lower() or "missing" in result.output.lower()

    def test_spaces_list_http_error(self, cli_runner, requests_mock):
        """Test handling of HTTP errors in spaces list."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            status_code=404,
        )
        requests_mock.get(
            f"{base_url}/xwiki/rest/wikis/xwiki/spaces",
            status_code=404,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "spaces",
                "list",
            ],
        )

        # Should handle error gracefully
        assert result.exit_code != 0


@pytest.mark.integration
class TestCLIPagesCommands:
    """Integration tests for pages CLI commands."""

    def test_pages_get_success(self, cli_runner, requests_mock, sample_page_response):
        """Test 'pages get' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome",
            json=sample_page_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "get",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["title"] == "Sandbox Home"
        assert output_data["name"] == "WebHome"

    def test_pages_list_success(
        self, cli_runner, requests_mock, sample_pages_list_response
    ):
        """Test 'pages list' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Main/pages",
            json=sample_pages_list_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "list",
                "--wiki",
                "xwiki",
                "--space",
                "Main",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2
        assert output_data[0]["name"] == "WebHome"

    def test_pages_get_missing_required_args(self, cli_runner):
        """Test that missing required arguments are caught."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "get",
                # Missing --wiki, --space, --page
            ],
        )

        assert result.exit_code != 0

    def test_pages_put_success(
        self, cli_runner, requests_mock, sample_put_page_response, tmp_path
    ):
        """Test 'pages put' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.put(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/NewPage",
            json=sample_put_page_response,
            status_code=201,
        )

        # Create a temporary content file
        content_file = tmp_path / "content.txt"
        content_file.write_text("This is the page content.")

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "put",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "NewPage",
                "--title",
                "New Page Title",
                "--content-file",
                str(content_file),
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["title"] == "New Page Title"
        assert output_data["name"] == "NewPage"

    def test_pages_put_missing_content_file(self, cli_runner):
        """Test 'pages put' fails when content file doesn't exist."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "put",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "NewPage",
                "--title",
                "Title",
                "--content-file",
                "/nonexistent/file.txt",
            ],
        )

        assert result.exit_code != 0
        output_lower = result.output.lower()
        assert "does not exist" in output_lower or "invalid" in output_lower

    def test_pages_update_with_title(
        self, cli_runner, requests_mock, sample_page_response, sample_put_page_response
    ):
        """Test 'pages update' with title only."""
        base_url = "https://xwiki.example.org"
        # Get request to fetch current content
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_page_response,
            status_code=200,
        )
        # Put request to update
        requests_mock.put(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "ExistingPage",
                "--title",
                "Updated Title",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["title"] == "New Page Title"

    def test_pages_update_with_content_file(
        self,
        cli_runner,
        requests_mock,
        sample_page_response,
        sample_put_page_response,
        tmp_path,
    ):
        """Test 'pages update' with content file only."""
        base_url = "https://xwiki.example.org"
        # Get request to fetch current title
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_page_response,
            status_code=200,
        )
        # Put request to update
        requests_mock.put(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        # Create a temporary content file
        content_file = tmp_path / "updated_content.txt"
        content_file.write_text("Updated page content.")

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "ExistingPage",
                "--content-file",
                str(content_file),
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["title"] == "New Page Title"

    def test_pages_update_with_both(
        self,
        cli_runner,
        requests_mock,
        sample_put_page_response,
        tmp_path,
    ):
        """Test 'pages update' with both title and content."""
        base_url = "https://xwiki.example.org"
        requests_mock.put(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/ExistingPage",
            json=sample_put_page_response,
            status_code=200,
        )

        # Create a temporary content file
        content_file = tmp_path / "updated_content.txt"
        content_file.write_text("Updated page content.")

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "ExistingPage",
                "--title",
                "Updated Title",
                "--content-file",
                str(content_file),
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["title"] == "New Page Title"

    def test_pages_update_requires_at_least_one(self, cli_runner):
        """Test 'pages update' fails without title or content."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "ExistingPage",
            ],
        )

        assert result.exit_code != 0
        output_lower = result.output.lower()
        assert "at least one" in output_lower or "title" in output_lower

    def test_pages_history_success(
        self, cli_runner, requests_mock, sample_page_versions_response
    ):
        """Test 'pages history' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history",
            json=sample_page_versions_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "history",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 3
        assert output_data[0]["version"] == "2.1"

    def test_pages_history_empty(self, cli_runner, requests_mock):
        """Test 'pages history' with no versions."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Empty/pages/WebHome/history",
            json={"history": []},
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "history",
                "--wiki",
                "xwiki",
                "--space",
                "Empty",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data == []

    def test_pages_get_version_success(
        self, cli_runner, requests_mock, sample_page_version_response
    ):
        """Test 'pages get-version' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/history/1.0",
            json=sample_page_version_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "get-version",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--version",
                "1.0",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["version"] == "1.0"
        assert output_data["author"] == "XWiki.Admin"

    def test_pages_get_version_missing_version(self, cli_runner):
        """Test 'pages get-version' fails when version is missing."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "get-version",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                # Missing --version
            ],
        )

        assert result.exit_code != 0
        assert "version" in result.output.lower() or "missing" in result.output.lower()

    def test_pages_bulk_update_success(
        self, cli_runner, requests_mock, sample_put_page_response, tmp_path
    ):
        """Test 'pages bulk-update' command with successful response."""
        base_url = "https://xwiki.example.org"
        pages = ["Page1", "Page2"]
        for page in pages:
            requests_mock.put(
                f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_put_page_response,
                status_code=200,
            )

        # Create a temporary content file
        content_file = tmp_path / "bulk_content.txt"
        content_file.write_text("Bulk updated content.")

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "bulk-update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "Page1",
                "--page",
                "Page2",
                "--title",
                "Bulk Updated Title",
                "--content-file",
                str(content_file),
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["updated"] == 2
        assert output_data["failed"] == 0

    def test_pages_bulk_update_with_title_only(
        self,
        cli_runner,
        requests_mock,
        sample_page_response,
        sample_put_page_response,
    ):
        """Test 'pages bulk-update' with title only."""
        base_url = "https://xwiki.example.org"
        pages = ["Page1", "Page2"]
        for page in pages:
            requests_mock.get(
                f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_page_response,
                status_code=200,
            )
            requests_mock.put(
                f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/{page}",
                json=sample_put_page_response,
                status_code=200,
            )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "pages",
                "bulk-update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "Page1",
                "--page",
                "Page2",
                "--title",
                "Updated Title",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["updated"] == 2

    def test_pages_bulk_update_requires_at_least_one(self, cli_runner):
        """Test 'pages bulk-update' fails without title or content."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "pages",
                "bulk-update",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "Page1",
            ],
        )

        assert result.exit_code != 0
        output_lower = result.output.lower()
        assert "at least one" in output_lower or "title" in output_lower


@pytest.mark.integration
class TestCLIAttachmentsCommands:
    """Integration tests for attachments CLI commands."""

    def test_attachments_list_success(
        self, cli_runner, requests_mock, sample_attachments_response
    ):
        """Test 'attachments list' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments",
            json=sample_attachments_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "attachments",
                "list",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2
        assert output_data[0]["name"] == "document.pdf"

    def test_attachments_get_success(self, cli_runner, requests_mock, tmp_path):
        """Test 'attachments get' command with successful response."""
        base_url = "https://xwiki.example.org"
        file_content = b"PDF file content"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/doc.pdf",
            content=file_content,
            status_code=200,
        )

        output_file = tmp_path / "downloaded.pdf"
        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "attachments",
                "get",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--filename",
                "doc.pdf",
                "--output",
                str(output_file),
            ],
        )

        assert result.exit_code == 0
        assert output_file.exists()
        assert output_file.read_bytes() == file_content

    def test_attachments_add_success(
        self, cli_runner, requests_mock, sample_attachment_metadata, tmp_path
    ):
        """Test 'attachments add' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.put(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/test.txt",
            json=sample_attachment_metadata,
            status_code=201,
        )

        # Create a test file
        test_file = tmp_path / "test.txt"
        test_file.write_text("Test content")

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "attachments",
                "add",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--file",
                str(test_file),
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["name"] == "uploaded.pdf"

    def test_attachments_delete_success(self, cli_runner, requests_mock):
        """Test 'attachments delete' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.delete(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/attachments/old.pdf",
            status_code=204,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "attachments",
                "delete",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--filename",
                "old.pdf",
            ],
        )

        assert result.exit_code == 0
        assert "Deleted old.pdf" in result.output


@pytest.mark.integration
class TestCLISearchCommand:
    """Integration tests for search CLI command."""

    def test_search_basic(self, cli_runner, requests_mock, sample_search_response):
        """Test basic search command."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "search",
                "--wiki",
                "xwiki",
                "--query",
                "test",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2
        assert output_data[0]["title"] == "Main Home"

    def test_search_with_space_filter(
        self, cli_runner, requests_mock, sample_search_response
    ):
        """Test search with space filter."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "search",
                "--wiki",
                "xwiki",
                "--query",
                "test",
                "--space",
                "Main",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2

    def test_search_with_limit(self, cli_runner, requests_mock, sample_search_response):
        """Test search with custom limit."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/search",
            json=sample_search_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "search",
                "--wiki",
                "xwiki",
                "--query",
                "test",
                "--limit",
                "50",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2


@pytest.mark.integration
class TestCLIGlobalOptions:
    """Integration tests for global CLI options."""

    def test_verbose_flag(self, cli_runner, requests_mock, sample_space_response):
        """Test --verbose flag enables debug logging."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--verbose",
                "spaces",
                "list",
            ],
        )

        assert result.exit_code == 0

    def test_quiet_flag(self, cli_runner, requests_mock, sample_space_response):
        """Test --quiet flag reduces logging."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--quiet",
                "spaces",
                "list",
            ],
        )

        assert result.exit_code == 0

    def test_env_password_resolution(
        self, cli_runner, requests_mock, sample_space_response, monkeypatch
    ):
        """Test password resolution from environment variable."""
        base_url = "https://xwiki.example.org"
        monkeypatch.setenv("TEST_WIKI_PASS", "secret123")

        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            json=sample_space_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "env:TEST_WIKI_PASS",
                "spaces",
                "list",
            ],
        )

        assert result.exit_code == 0


@pytest.mark.integration
class TestCLIErrorHandling:
    """Integration tests for CLI error handling."""

    def test_connection_error_handling(self, cli_runner, requests_mock):
        """Test handling of connection errors."""
        base_url = "https://unreachable.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            exc=Exception("Connection refused"),
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "spaces",
                "list",
            ],
        )

        assert result.exit_code != 0

    def test_invalid_json_response(self, cli_runner, requests_mock):
        """Test handling of invalid JSON responses."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            text="Invalid JSON",
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "spaces",
                "list",
            ],
        )

        # Should handle JSON decode error
        assert result.exit_code != 0


@pytest.mark.integration
class TestCLICommentsCommands:
    """Integration tests for comments CLI commands."""

    def test_comments_list_success(
        self, cli_runner, requests_mock, sample_comments_response
    ):
        """Test 'comments list' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comments_response,
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "comments",
                "list",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert len(output_data) == 2
        assert output_data[0]["text"] == "This is a great page!"

    def test_comments_list_empty(self, cli_runner, requests_mock):
        """Test 'comments list' command with no comments."""
        base_url = "https://xwiki.example.org"
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces/Empty/pages/WebHome/comments",
            json={"comments": []},
            status_code=200,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "comments",
                "list",
                "--wiki",
                "xwiki",
                "--space",
                "Empty",
                "--page",
                "WebHome",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data == []

    def test_comments_add_success(
        self, cli_runner, requests_mock, sample_comment_metadata
    ):
        """Test 'comments add' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.post(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments",
            json=sample_comment_metadata,
            status_code=201,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "comments",
                "add",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--text",
                "New comment text",
            ],
        )

        assert result.exit_code == 0
        output_data = json.loads(result.output)
        assert output_data["id"] == 3
        assert output_data["text"] == "New comment text"

    def test_comments_add_missing_text(self, cli_runner):
        """Test 'comments add' fails when --text is missing."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "comments",
                "add",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                # Missing --text
            ],
        )

        assert result.exit_code != 0
        assert "text" in result.output.lower() or "missing" in result.output.lower()

    def test_comments_delete_success(self, cli_runner, requests_mock):
        """Test 'comments delete' command with successful response."""
        base_url = "https://xwiki.example.org"
        requests_mock.delete(
            f"{base_url}/rest/wikis/xwiki/spaces/Sandbox/pages/WebHome/comments/1",
            status_code=204,
        )

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "--username",
                "testuser",
                "--password",
                "testpass",
                "comments",
                "delete",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--comment-id",
                "1",
            ],
        )

        assert result.exit_code == 0
        assert "Deleted comment 1" in result.output

    def test_comments_delete_missing_comment_id(self, cli_runner):
        """Test 'comments delete' fails when --comment-id is missing."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "comments",
                "delete",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                # Missing --comment-id
            ],
        )

        assert result.exit_code != 0
        output_lower = result.output.lower()
        assert "comment-id" in output_lower or "missing" in output_lower

    def test_comments_delete_invalid_comment_id(self, cli_runner):
        """Test 'comments delete' fails with invalid comment ID."""
        base_url = "https://xwiki.example.org"

        result = cli_runner.invoke(
            cli,
            [
                "--base-url",
                base_url,
                "comments",
                "delete",
                "--wiki",
                "xwiki",
                "--space",
                "Sandbox",
                "--page",
                "WebHome",
                "--comment-id",
                "not-a-number",
            ],
        )

        assert result.exit_code != 0


@pytest.mark.integration
class TestCLIConfigCommands:
    """Integration tests for config CLI commands."""

    def test_config_init_creates_file(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config init' creates a config file."""
        # Mock get_default_config_path to use tmp_path
        config_file = tmp_path / ".config" / "xwiki" / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "init"])

        assert result.exit_code == 0
        assert config_file.exists()
        content = config_file.read_text()
        assert "[default]" in content
        assert "base_url" in content

    def test_config_init_file_already_exists(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config init' when file already exists."""
        config_file = tmp_path / "config.toml"
        config_file.write_text("[default]\nbase_url = 'test'\n")

        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "init"])

        assert result.exit_code == 0
        assert "already exists" in result.output

    def test_config_path_shows_path(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config path' shows config file path."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "path"])

        assert result.exit_code == 0
        assert str(config_file) in result.output

    def test_config_show_empty(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config show' when no config file exists."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "show"])

        assert result.exit_code == 0
        assert "not found" in result.output

    def test_config_show_displays_values(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config show' displays config values."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[default]\n"
            'base_url = "https://xwiki.org"\n'
            'username = "john"\n'
            'password = "secret"\n'
        )

        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "show"])

        assert result.exit_code == 0
        assert "https://xwiki.org" in result.output
        assert "john" in result.output
        assert "(masked)" in result.output  # password should be masked

    def test_config_show_env_var_reference(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config show' shows env var references."""
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            "[default]\n"
            'base_url = "https://xwiki.org"\n'
            'password = "env:XWIKI_PASS"\n'
        )

        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "show"])

        assert result.exit_code == 0
        assert "env:XWIKI_PASS" in result.output

    def test_config_set_value(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config set' saves a value."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(
            cli, ["config", "set", "base_url", "https://xwiki.org"]
        )

        assert result.exit_code == 0
        assert config_file.exists()
        content = config_file.read_text()
        assert "https://xwiki.org" in content

    def test_config_set_invalid_key(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config set' rejects invalid keys."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.config.get_default_config_path",
            lambda: config_file,
        )
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "set", "invalid_key", "value"])

        assert result.exit_code != 0
        assert "Invalid key" in result.output

    def test_config_set_profile(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config set' with --profile option."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(
            cli,
            ["config", "set", "base_url", "https://work.org", "--profile", "work"],
        )

        assert result.exit_code == 0
        content = config_file.read_text()
        assert "[profiles.work]" in content
        assert "https://work.org" in content

    def test_config_set_password_warning(self, cli_runner, tmp_path, monkeypatch):
        """Test 'config set' warns about plaintext passwords."""
        config_file = tmp_path / "config.toml"
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        result = cli_runner.invoke(cli, ["config", "set", "password", "secret123"])

        assert result.exit_code == 0
        assert "WARNING" in result.output or "warning" in result.output.lower()

    def test_cli_with_config_file(
        self, cli_runner, requests_mock, tmp_path, monkeypatch
    ):
        """Test using config file for base_url."""
        base_url = "https://xwiki.example.org"
        config_file = tmp_path / "config.toml"
        config_content = (
            f'[default]\nbase_url = "{base_url}"\n'
            'username = "testuser"\npassword = "testpass"\n'
        )
        config_file.write_text(config_content)

        # Mock the default config path in both modules
        monkeypatch.setattr(
            "xwikiadmin.config.get_default_config_path",
            lambda: config_file,
        )
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        sample_response = {"spaces": [{"name": "Main"}, {"name": "Sandbox"}]}
        requests_mock.get(
            f"{base_url}/rest/wikis/xwiki/spaces",
            json=sample_response,
            status_code=200,
        )

        # Run without --base-url, should load from config
        result = cli_runner.invoke(cli, ["spaces", "list"])

        assert result.exit_code == 0

    def test_cli_config_with_profile(
        self, cli_runner, requests_mock, tmp_path, monkeypatch
    ):
        """Test using config file with --profile option."""
        work_url = "https://work.xwiki.org"
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            '[default]\nbase_url = "https://default.org"\nusername = "default_user"\n'
            f'[profiles.work]\nbase_url = "{work_url}"\nusername = "work_user"\n'
        )

        monkeypatch.setattr(
            "xwikiadmin.config.get_default_config_path",
            lambda: config_file,
        )
        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        sample_response = {"spaces": [{"name": "Main"}]}
        requests_mock.get(
            f"{work_url}/rest/wikis/xwiki/spaces",
            json=sample_response,
            status_code=200,
        )

        result = cli_runner.invoke(cli, ["--profile", "work", "spaces", "list"])

        assert result.exit_code == 0

    def test_cli_args_override_config(
        self, cli_runner, requests_mock, tmp_path, monkeypatch
    ):
        """Test that CLI args override config file values."""
        cli_url = "https://cli.example.org"
        config_url = "https://config.example.org"
        config_file = tmp_path / "config.toml"
        config_file.write_text(
            f'[default]\nbase_url = "{config_url}"\nusername = "config_user"\n'
        )

        monkeypatch.setattr(
            "xwikiadmin.cli.get_default_config_path",
            lambda: config_file,
        )

        sample_response = {"spaces": []}
        requests_mock.get(
            f"{cli_url}/rest/wikis/xwiki/spaces",
            json=sample_response,
            status_code=200,
        )

        # CLI arg should override config
        result = cli_runner.invoke(cli, ["--base-url", cli_url, "spaces", "list"])

        assert result.exit_code == 0
