"""Input validation functions for XWiki CLI."""

from __future__ import annotations

import logging
import os
import urllib.parse


def validate_base_url(url: str) -> str:
    """Validate and normalize base URL.

    Args:
        url: The base URL to validate

    Returns:
        Normalized URL with trailing slash removed

    Raises:
        ValueError: If URL is invalid or uses unsupported scheme
    """
    parsed = urllib.parse.urlparse(url)

    # Validate URL has scheme and netloc
    if not parsed.scheme or not parsed.netloc:
        raise ValueError(
            f"Invalid URL '{url}': Must include scheme (http/https) and domain"
        )

    # Validate scheme is http or https
    if parsed.scheme not in ("http", "https"):
        raise ValueError(
            f"Invalid URL scheme '{parsed.scheme}': Must use http or https"
        )

    # Reconstruct and normalize URL
    normalized_url = f"{parsed.scheme}://{parsed.netloc}{parsed.path}".rstrip("/")
    return normalized_url


def validate_timeout(timeout: int) -> int:
    """Validate timeout is within acceptable range.

    Args:
        timeout: Timeout value in seconds

    Returns:
        The validated timeout value

    Raises:
        TypeError: If timeout is not an integer
        ValueError: If timeout is outside acceptable range (1-300 seconds)
    """
    if not isinstance(timeout, int):
        raise TypeError(f"Timeout must be an integer, got {type(timeout).__name__}")

    if timeout < 1 or timeout > 300:
        raise ValueError(f"Timeout must be between 1 and 300 seconds, got {timeout}")

    return timeout


def resolve_password(pw: str | None) -> str | None:
    """Resolve password from direct value or environment variable.

    Args:
        pw: Password value or 'env:VAR_NAME' reference

    Returns:
        Resolved password value, or None if not provided

    Raises:
        ValueError: If env variable is referenced but not set
    """
    if not pw:
        return pw

    if pw.startswith("env:"):
        env_var = pw.split(":", 1)[1]
        value = os.getenv(env_var)
        if value is None:
            raise ValueError(
                f"Environment variable '{env_var}' is not set. "
                f"Please set it before running the command."
            )
        return value

    # Warn about plaintext password in command line
    logging.warning(
        "Password provided directly in command line is visible in shell history. "
        "Consider using --password env:VAR_NAME instead."
    )
    return pw
