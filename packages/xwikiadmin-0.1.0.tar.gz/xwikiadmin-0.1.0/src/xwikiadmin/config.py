"""Configuration file handling for XWiki CLI.

Supports XDG Base Directory specification with fallback to ~/.xwikirc.toml.
Allows storing credentials and multiple profiles in TOML format.
"""

from __future__ import annotations

import logging
import tomllib
from pathlib import Path
from typing import Any

from xwikiadmin.exceptions import XWikiConfigError


def get_default_config_path() -> Path:
    """Get the default config file path following XDG specification.

    Returns XDG config path (~/.config/xwiki/config.toml) with fallback
    to ~/.xwikirc.toml if it exists.

    Returns:
        Path to config file
    """
    # XDG Base Directory
    xdg_config_home = Path.home() / ".config" / "xwiki"
    xdg_path = xdg_config_home / "config.toml"

    # Fallback to legacy location
    legacy_path = Path.home() / ".xwikirc.toml"

    # Prefer legacy path if it exists, otherwise use XDG path
    if legacy_path.exists():
        return legacy_path
    return xdg_path


def load_config(
    config_path: Path | None = None, profile: str = "default"
) -> dict[str, str]:
    """Load configuration from TOML file.

    Args:
        config_path: Path to config file. If None, uses default location.
        profile: Profile name to load (default: "default")

    Returns:
        Dictionary with configuration values (base_url, username, password)

    Raises:
        XWikiConfigError: If config file is invalid or profile not found
    """
    if config_path is None:
        config_path = get_default_config_path()

    config_path = Path(config_path).expanduser()

    # If file doesn't exist, return empty dict
    if not config_path.exists():
        logging.debug("Config file not found at %s", config_path)
        return {}

    try:
        with open(config_path, "rb") as f:
            data = tomllib.load(f)
    except Exception as e:
        msg = f"Failed to parse config file at {config_path}: {e}"
        raise XWikiConfigError(msg) from e

    # Get profile-specific config
    profile_config: dict[str, str] = {}

    # Load default profile first
    if "default" in data:
        profile_config.update(data["default"])

    # Override with specific profile if different from default
    if profile != "default":
        if "profiles" not in data or profile not in data["profiles"]:
            available = ", ".join(data.get("profiles", {}).keys())
            raise XWikiConfigError(
                f"Profile '{profile}' not found in config file. "
                f"Available profiles: default, {available}"
            )
        profile_config.update(data["profiles"][profile])

    return profile_config


def save_config(
    config_path: Path | None,
    key: str,
    value: str,
    profile: str = "default",
) -> None:
    """Save or update a configuration value in TOML file.

    Args:
        config_path: Path to config file. If None, uses default location.
        key: Configuration key (base_url, username, password)
        value: Value to set
        profile: Profile name to update (default: "default")

    Raises:
        XWikiConfigError: If config file is invalid or write fails
    """
    if config_path is None:
        config_path = get_default_config_path()

    config_path = Path(config_path).expanduser()

    # Create parent directories if needed
    config_path.parent.mkdir(parents=True, exist_ok=True)

    # Load existing config or create new
    if config_path.exists():
        try:
            with open(config_path, "rb") as f:
                data = tomllib.load(f)
        except Exception as e:
            raise XWikiConfigError(f"Failed to parse existing config file: {e}") from e
    else:
        data = {}

    # Ensure structure exists
    if profile == "default":
        if "default" not in data:
            data["default"] = {}
        data["default"][key] = value
    else:
        if "profiles" not in data:
            data["profiles"] = {}
        if profile not in data["profiles"]:
            data["profiles"][profile] = {}
        data["profiles"][profile][key] = value

    # Write TOML file
    _write_toml(config_path, data)


def _write_toml(path: Path, data: dict[str, Any]) -> None:
    """Write configuration to TOML file.

    This is a simple TOML writer that handles the basic structure needed
    for xwiki config (flat key-value pairs in sections).

    Args:
        path: Path to write to
        data: Dictionary to write

    Raises:
        XWikiConfigError: If write fails
    """
    try:
        lines = []

        # Write default section
        if "default" in data:
            lines.append("[default]")
            for key, value in data["default"].items():
                lines.append(_format_toml_value(key, value))
            lines.append("")

        # Write profile sections
        if "profiles" in data:
            for profile_name, profile_data in data["profiles"].items():
                lines.append(f"[profiles.{profile_name}]")
                for key, value in profile_data.items():
                    lines.append(_format_toml_value(key, value))
                lines.append("")

        # Remove trailing empty line
        while lines and lines[-1] == "":
            lines.pop()

        content = "\n".join(lines)
        if content:
            content += "\n"

        path.write_text(content, encoding="utf-8")
    except Exception as e:
        raise XWikiConfigError(f"Failed to write config file: {e}") from e


def _format_toml_value(key: str, value: str) -> str:
    """Format a key-value pair as TOML.

    Args:
        key: Configuration key
        value: Configuration value (string)

    Returns:
        Formatted TOML line
    """
    # Simple escaping for TOML strings
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'{key} = "{escaped}"'
