"""XWiki CLI - Command-line interface for managing XWiki instances via REST API."""

from xwikiadmin.client import XWikiClient
from xwikiadmin.exceptions import (
    XWikiAPIError,
    XWikiAuthenticationError,
    XWikiAuthorizationError,
    XWikiConnectionError,
    XWikiEndpointNotFoundError,
    XWikiError,
    XWikiResourceNotFoundError,
)

__version__ = "0.1.0"

__all__ = [
    "XWikiClient",
    "XWikiError",
    "XWikiAPIError",
    "XWikiEndpointNotFoundError",
    "XWikiAuthenticationError",
    "XWikiAuthorizationError",
    "XWikiConnectionError",
    "XWikiResourceNotFoundError",
]
