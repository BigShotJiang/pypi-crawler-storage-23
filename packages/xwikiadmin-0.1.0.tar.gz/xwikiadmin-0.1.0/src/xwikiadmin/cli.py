"""XWiki CLI - Command-line interface entry point."""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import click
import requests

from xwikiadmin.client import XWikiClient
from xwikiadmin.config import get_default_config_path, load_config, save_config
from xwikiadmin.exceptions import (
    XWikiAuthenticationError,
    XWikiAuthorizationError,
    XWikiConfigError,
    XWikiConnectionError,
    XWikiEndpointNotFoundError,
    XWikiError,
)
from xwikiadmin.validators import resolve_password


@click.group()
@click.option(
    "--config",
    type=click.Path(dir_okay=False, path_type=Path),
    default=None,
    help="Path to config file (default: ~/.config/xwiki/config.toml)",
)
@click.option(
    "--profile", default="default", show_default=True, help="Config profile to use"
)
@click.option(
    "--base-url",
    required=False,
    default=None,
    help="Base URL, e.g. https://xwiki.example.org",
)
@click.option(
    "--username", envvar="XWIKI_USER", default=None, help="Username or env XWIKI_USER"
)
@click.option(
    "--password",
    envvar="XWIKI_PASS",
    default=None,
    help=(
        "Password or env:VAR_NAME reference. "
        "WARNING: Providing password directly on command line exposes it "
        "in shell history. Use --password env:VAR_NAME or set XWIKI_PASS "
        "environment variable instead."
    ),
)
@click.option("--verbose", is_flag=True, help="Enable verbose logging")
@click.option("--quiet", is_flag=True, help="Reduce log output")
@click.option(
    "--cache",
    is_flag=True,
    help="Enable response caching for faster repeated queries",
)
@click.option(
    "--cache-ttl",
    default=300,
    show_default=True,
    type=int,
    help="Cache time-to-live in seconds (only used with --cache)",
)
@click.pass_context
def cli(
    ctx: click.Context,
    config: Path | None,
    profile: str,
    base_url: str | None,
    username: str | None,
    password: str | None,
    verbose: bool,
    quiet: bool,
    cache: bool,
    cache_ttl: int,
) -> None:
    """XWiki REST API command-line client."""
    level = logging.INFO
    if verbose:
        level = logging.DEBUG
    if quiet:
        level = logging.WARNING
    logging.basicConfig(level=level, format="%(levelname)s: %(message)s")

    if cache:
        logging.debug("Response caching enabled with TTL=%d seconds", cache_ttl)

    # Check if this is a config subcommand that doesn't need a client
    if ctx.invoked_subcommand == "config":
        ctx.obj = None
        return

    # Load config file and merge with CLI args
    # Priority: CLI Args > Env Vars > Config File > Error
    try:
        config_data = load_config(config, profile)
    except XWikiConfigError as e:
        raise click.UsageError(str(e)) from e

    if base_url is None:
        base_url = config_data.get("base_url")
    if username is None:
        username = config_data.get("username")
    if password is None:
        password = config_data.get("password")

    if base_url is None:
        raise click.UsageError(
            "Missing --base-url (not set via CLI, env var, or config file)"
        )

    pw = resolve_password(password)
    ctx.obj = XWikiClient(
        base_url=base_url,
        username=username,
        password=pw,
        cache_enabled=cache,
        cache_ttl=cache_ttl,
    )


@cli.group()
def spaces() -> None:
    """Manage spaces."""


@spaces.command("list")
@click.option("--wiki", default="xwiki", show_default=True)
@click.option("--offset", default=0, show_default=True, type=int, help="Skip N items")
@click.option("--limit", default=None, type=int, help="Max items to return")
@click.pass_obj
def spaces_list(client: XWikiClient, wiki: str, offset: int, limit: int | None) -> None:
    """List spaces in a wiki."""
    spaces_data = client.list_spaces(wiki=wiki, offset=offset, limit=limit)
    click.echo(json.dumps(spaces_data, indent=2))


@cli.group()
def pages() -> None:
    """Manage pages."""


@pages.command("get")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.pass_obj
def pages_get(client: XWikiClient, wiki: str, space: str, page: str) -> None:
    """Fetch a page JSON representation."""
    data = client.get_page(wiki=wiki, space=space, page=page)
    click.echo(json.dumps(data, indent=2))


@pages.command("list")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Main")
@click.option("--offset", default=0, show_default=True, type=int, help="Skip N items")
@click.option("--limit", default=None, type=int, help="Max items to return")
@click.pass_obj
def pages_list(
    client: XWikiClient, wiki: str, space: str, offset: int, limit: int | None
) -> None:
    """List pages in a space."""
    data = client.list_pages(wiki=wiki, space=space, offset=offset, limit=limit)
    click.echo(json.dumps(data, indent=2))


@pages.command("put")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. MyPage")
@click.option("--title", required=True, help="Page display title")
@click.option(
    "--content-file",
    required=True,
    type=click.Path(exists=True, readable=True, path_type=Path),
    help="Path to file containing page content",
)
@click.pass_obj
def pages_put(
    client: XWikiClient,
    wiki: str,
    space: str,
    page: str,
    title: str,
    content_file: Path,
) -> None:
    """Create or update a page from a file."""
    content = content_file.read_text(encoding="utf-8")
    data = client.put_page(
        wiki=wiki, space=space, page=page, title=title, content=content
    )
    click.echo(json.dumps(data, indent=2))


@pages.command("update")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. MyPage")
@click.option("--title", default=None, help="New page display title (optional)")
@click.option(
    "--content-file",
    default=None,
    type=click.Path(exists=True, readable=True, path_type=Path),
    help="Path to file with new page content (optional)",
)
@click.pass_obj
def pages_update(
    client: XWikiClient,
    wiki: str,
    space: str,
    page: str,
    title: str | None,
    content_file: Path | None,
) -> None:
    """Update an existing page (title and/or content)."""
    if title is None and content_file is None:
        msg = "At least one of --title or --content-file must be provided"
        raise click.UsageError(msg)

    content = None
    if content_file is not None:
        content = content_file.read_text(encoding="utf-8")

    data = client.update_page(
        wiki=wiki, space=space, page=page, title=title, content=content
    )
    click.echo(json.dumps(data, indent=2))


@pages.command("history")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.pass_obj
def pages_history(client: XWikiClient, wiki: str, space: str, page: str) -> None:
    """List version history of a page."""
    data = client.list_page_versions(wiki=wiki, space=space, page=page)
    click.echo(json.dumps(data, indent=2))


@pages.command("get-version")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option("--version", required=True, help="Version number, e.g. 1.1")
@click.pass_obj
def pages_get_version(
    client: XWikiClient, wiki: str, space: str, page: str, version: str
) -> None:
    """Get a specific version of a page."""
    data = client.get_page_version(wiki=wiki, space=space, page=page, version=version)
    click.echo(json.dumps(data, indent=2))


@pages.command("bulk-update")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option(
    "--page",
    "pages",
    multiple=True,
    required=True,
    help="Page names to update (can specify multiple times)",
)
@click.option("--title", default=None, help="New page display title (optional)")
@click.option(
    "--content-file",
    default=None,
    type=click.Path(exists=True, readable=True, path_type=Path),
    help="Path to file with new page content (optional)",
)
@click.pass_obj
def pages_bulk_update(
    client: XWikiClient,
    wiki: str,
    space: str,
    pages: tuple[str, ...],
    title: str | None,
    content_file: Path | None,
) -> None:
    """Update multiple pages with the same content/title."""
    if title is None and content_file is None:
        msg = "At least one of --title or --content-file must be provided"
        raise click.UsageError(msg)

    content = None
    if content_file is not None:
        content = content_file.read_text(encoding="utf-8")

    result = client.bulk_update_pages(
        wiki=wiki,
        space=space,
        pages=list(pages),
        title=title,
        content=content,
    )
    click.echo(json.dumps(result, indent=2))


@cli.group()
def attachments() -> None:
    """Manage page attachments."""


@attachments.command("list")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.pass_obj
def attachments_list(client: XWikiClient, wiki: str, space: str, page: str) -> None:
    """List attachments on a page."""
    data = client.list_attachments(wiki=wiki, space=space, page=page)
    click.echo(json.dumps(data, indent=2))


@attachments.command("get")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option("--filename", required=True, help="Attachment filename")
@click.option(
    "--output",
    required=True,
    type=click.Path(path_type=Path),
    help="Output file path",
)
@click.pass_obj
def attachments_get(
    client: XWikiClient,
    wiki: str,
    space: str,
    page: str,
    filename: str,
    output: Path,
) -> None:
    """Download an attachment from a page."""
    content = client.get_attachment(
        wiki=wiki, space=space, page=page, filename=filename
    )
    output.write_bytes(content)
    click.echo(f"Downloaded {filename} to {output}")


@attachments.command("add")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option(
    "--file",
    "file_path",
    required=True,
    type=click.Path(exists=True, readable=True, path_type=Path),
    help="File to upload",
)
@click.option("--filename", default=None, help="Override filename (uses file name)")
@click.pass_obj
def attachments_add(
    client: XWikiClient,
    wiki: str,
    space: str,
    page: str,
    file_path: Path,
    filename: str | None,
) -> None:
    """Upload an attachment to a page."""
    import mimetypes

    actual_filename = filename or file_path.name
    content = file_path.read_bytes()
    content_type, _ = mimetypes.guess_type(str(file_path))
    content_type = content_type or "application/octet-stream"

    data = client.put_attachment(
        wiki=wiki,
        space=space,
        page=page,
        filename=actual_filename,
        content=content,
        content_type=content_type,
    )
    click.echo(json.dumps(data, indent=2))


@attachments.command("delete")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option("--filename", required=True, help="Attachment filename to delete")
@click.pass_obj
def attachments_delete(
    client: XWikiClient, wiki: str, space: str, page: str, filename: str
) -> None:
    """Delete an attachment from a page."""
    client.delete_attachment(wiki=wiki, space=space, page=page, filename=filename)
    click.echo(f"Deleted {filename}")


@cli.group()
def comments() -> None:
    """Manage page comments."""


@comments.command("list")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.pass_obj
def comments_list(client: XWikiClient, wiki: str, space: str, page: str) -> None:
    """List comments on a page."""
    data = client.list_comments(wiki=wiki, space=space, page=page)
    click.echo(json.dumps(data, indent=2))


@comments.command("add")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option("--text", required=True, help="Comment text")
@click.pass_obj
def comments_add(
    client: XWikiClient, wiki: str, space: str, page: str, text: str
) -> None:
    """Add a comment to a page."""
    data = client.add_comment(wiki=wiki, space=space, page=page, text=text)
    click.echo(json.dumps(data, indent=2))


@comments.command("delete")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--space", required=True, help="Space name, e.g. Sandbox")
@click.option("--page", required=True, help="Page name, e.g. WebHome")
@click.option("--comment-id", required=True, type=int, help="Comment ID to delete")
@click.pass_obj
def comments_delete(
    client: XWikiClient, wiki: str, space: str, page: str, comment_id: int
) -> None:
    """Delete a comment from a page."""
    client.delete_comment(wiki=wiki, space=space, page=page, comment_id=comment_id)
    click.echo(f"Deleted comment {comment_id}")


@cli.command("search")
@click.option("--wiki", required=True, default="xwiki", show_default=True)
@click.option("--query", required=True, help="Search query text")
@click.option("--space", default=None, help="Optional space filter")
@click.option("--offset", default=0, show_default=True, type=int, help="Skip N results")
@click.option("--limit", default=20, show_default=True, type=int, help="Max results")
@click.pass_obj
def search_cmd(
    client: XWikiClient,
    wiki: str,
    query: str,
    space: str | None,
    offset: int,
    limit: int,
) -> None:
    """Full-text search across a wiki (optionally within a space)."""
    results = client.search(
        wiki=wiki, query=query, space=space, offset=offset, limit=limit
    )
    click.echo(json.dumps(results, indent=2))


@cli.group()
def config() -> None:
    """Manage configuration and profiles."""


@config.command("init")
def config_init() -> None:
    """Initialize configuration file with example content."""
    config_path = get_default_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)

    example_content = """# XWiki CLI Configuration
# See https://github.com/john-doe/xwikiadmin for documentation

[default]
base_url = "https://xwiki.example.org"
username = "your_username"
password = "env:XWIKI_PASS"

# Additional profiles can be defined here:
# [profiles.work]
# base_url = "https://xwiki.company.org"
# username = "your_work_username"
"""

    if config_path.exists():
        click.echo(f"Config file already exists at {config_path}")
        return

    config_path.write_text(example_content, encoding="utf-8")
    click.echo(f"Created config file at {config_path}")
    click.echo("Edit the file and set your credentials, then use: xwiki spaces list")


@config.command("path")
def config_path_cmd() -> None:
    """Show the path to the configuration file."""
    config_path = get_default_config_path()
    click.echo(str(config_path))


@config.command("show")
@click.option("--profile", default="default", show_default=True, help="Profile to show")
def config_show(profile: str) -> None:
    """Show current configuration (password masked)."""
    config_path = get_default_config_path()

    if not config_path.exists():
        click.echo(f"Config file not found at {config_path}")
        return

    try:
        config_data = load_config(config_path, profile)
    except XWikiConfigError as e:
        click.echo(f"Error: {e}", err=True)
        return

    if not config_data:
        click.echo(f"No configuration found for profile '{profile}'")
        return

    click.echo(f"Configuration for profile '{profile}':")
    for key, value in config_data.items():
        if key == "password":
            # Mask password but show if it's env var reference
            if value.startswith("env:"):
                click.echo(f"  {key} = {value}")
            else:
                click.echo(f"  {key} = (masked)")
        else:
            click.echo(f"  {key} = {value}")


@config.command("set")
@click.argument("key", required=True)
@click.argument("value", required=True)
@click.option(
    "--profile", default="default", show_default=True, help="Profile to update"
)
def config_set(key: str, value: str, profile: str) -> None:
    """Set a configuration value.

    Examples:
        xwiki config set base_url https://xwiki.example.org
        xwiki config set username john
        xwiki config set password env:XWIKI_PASS
    """
    valid_keys = {"base_url", "username", "password"}
    if key not in valid_keys:
        keys_str = ", ".join(valid_keys)
        raise click.UsageError(f"Invalid key '{key}'. Must be one of: {keys_str}")

    config_path = get_default_config_path()

    try:
        save_config(config_path, key, value, profile)
    except XWikiConfigError as e:
        raise click.UsageError(str(e)) from e

    click.echo(f"Set {key} in profile '{profile}'")
    if key == "password" and not value.startswith("env:"):
        warning_msg = (
            "WARNING: Password stored in plaintext. "
            "Consider using 'password = env:VAR_NAME' instead."
        )
        click.echo(warning_msg)


def main() -> int:
    """Main entry point for the CLI.

    Returns:
        Exit code: 0 for success, 1 for general errors, 2 for HTTP/API errors,
        3 for authentication errors, 4 for connection errors
    """
    try:
        cli(standalone_mode=True)
        return 0
    except XWikiAuthenticationError as e:
        logging.error("Authentication error: %s", e)
        return 3
    except XWikiAuthorizationError as e:
        logging.error("Authorization error: %s", e)
        return 3
    except XWikiConnectionError as e:
        logging.error("Connection error: %s", e)
        return 4
    except XWikiEndpointNotFoundError as e:
        logging.error("Endpoint error: %s", e)
        logging.debug("Attempted paths: %s", e.attempted_paths)
        return 2
    except XWikiError as e:
        logging.error("XWiki error: %s", e)
        return 2
    except requests.HTTPError as e:
        logging.error("HTTP error: %s", e)
        return 2
    except Exception as e:  # noqa: BLE001
        logging.error("Error: %s", e)
        return 1


if __name__ == "__main__":
    sys.exit(main())
