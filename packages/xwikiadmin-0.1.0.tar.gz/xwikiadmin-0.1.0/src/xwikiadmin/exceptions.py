"""Custom exceptions for XWiki CLI.

This module defines a hierarchy of custom exceptions for better error handling
and more informative error messages when interacting with XWiki instances.
"""

from __future__ import annotations


class XWikiError(Exception):
    """Base exception for all XWiki CLI errors.

    All custom exceptions in this module inherit from this base class,
    making it easy to catch any XWiki-related error.
    """


class XWikiAPIError(XWikiError):
    """Raised when the XWiki REST API returns an error.

    This exception captures both the error message and the HTTP status code
    from the API response.

    Attributes:
        status_code: The HTTP status code from the API response, if available
    """

    def __init__(self, message: str, status_code: int | None = None) -> None:
        """Initialize the API error.

        Args:
            message: Error message describing what went wrong
            status_code: Optional HTTP status code from the API response
        """
        super().__init__(message)
        self.status_code = status_code


class XWikiEndpointNotFoundError(XWikiAPIError):
    """Raised when no valid REST endpoint is found.

    This occurs when the client tries multiple REST API endpoint patterns
    (e.g., /rest and /xwiki/rest) but none of them respond successfully.

    Attributes:
        attempted_paths: List of endpoint paths that were attempted
    """

    def __init__(self, attempted_paths: list[str]) -> None:
        """Initialize the endpoint not found error.

        Args:
            attempted_paths: List of REST endpoint paths that were tried
        """
        self.attempted_paths = attempted_paths
        paths_str = ", ".join(attempted_paths)
        super().__init__(
            f"No valid REST endpoint found. Tried: {paths_str}",
            status_code=404,
        )


class XWikiAuthenticationError(XWikiAPIError):
    """Raised when authentication with the XWiki instance fails.

    This typically occurs when:
    - Invalid credentials are provided
    - The user account doesn't have API access
    - The authentication token has expired
    """

    def __init__(self, message: str = "Authentication failed") -> None:
        """Initialize the authentication error.

        Args:
            message: Error message describing the authentication failure
        """
        super().__init__(message, status_code=401)


class XWikiAuthorizationError(XWikiAPIError):
    """Raised when the user lacks permission to access a resource.

    This occurs when the authenticated user doesn't have sufficient
    permissions to perform the requested operation.
    """

    def __init__(
        self, message: str = "Insufficient permissions to access this resource"
    ) -> None:
        """Initialize the authorization error.

        Args:
            message: Error message describing the permission issue
        """
        super().__init__(message, status_code=403)


class XWikiResourceNotFoundError(XWikiAPIError):
    """Raised when a requested resource doesn't exist.

    This occurs when trying to access a wiki, space, or page that
    doesn't exist on the XWiki instance.
    """

    def __init__(self, resource_type: str, resource_id: str) -> None:
        """Initialize the resource not found error.

        Args:
            resource_type: Type of resource (e.g., 'wiki', 'space', 'page')
            resource_id: Identifier of the resource that wasn't found
        """
        self.resource_type = resource_type
        self.resource_id = resource_id
        super().__init__(
            f"{resource_type.capitalize()} '{resource_id}' not found",
            status_code=404,
        )


class XWikiConnectionError(XWikiError):
    """Raised when connection to the XWiki instance fails.

    This occurs when:
    - The XWiki instance is unreachable
    - Network connectivity issues
    - DNS resolution fails
    - Connection timeout
    """

    def __init__(self, base_url: str, original_error: Exception | None = None) -> None:
        """Initialize the connection error.

        Args:
            base_url: The XWiki instance URL that couldn't be reached
            original_error: The underlying exception that caused the connection failure
        """
        self.base_url = base_url
        self.original_error = original_error
        message = f"Failed to connect to XWiki instance at {base_url}"
        if original_error:
            message += f": {original_error}"
        super().__init__(message)


class XWikiConfigError(XWikiError):
    """Raised when config file is invalid or profile not found."""

    def __init__(self, message: str) -> None:
        """Initialize the config error.

        Args:
            message: Error message describing the config issue
        """
        super().__init__(message)
