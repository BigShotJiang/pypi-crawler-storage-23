"""XWiki REST API client."""

from __future__ import annotations

import urllib.parse
from typing import Any

import requests
import requests_cache

from xwikiadmin.exceptions import (
    XWikiAuthenticationError,
    XWikiAuthorizationError,
    XWikiConnectionError,
    XWikiEndpointNotFoundError,
)
from xwikiadmin.validators import validate_base_url, validate_timeout


class XWikiClient:
    """Client for interacting with XWiki REST API.

    Args:
        base_url: Base URL of the XWiki instance (http://... or https://...)
        username: Username for authentication (optional)
        password: Password for authentication (optional)
        timeout: Request timeout in seconds (1-300, default: 20)
        cache_enabled: Enable response caching for faster repeated queries
            (default: False)
        cache_ttl: Cache time-to-live in seconds (default: 300 = 5 minutes)

    Raises:
        ValueError: If base_url is invalid or timeout is out of range
        TypeError: If timeout is not an integer

    Attributes:
        endpoint_prefix: The cached REST endpoint prefix ('/rest' or '/xwiki/rest')
            that works for this XWiki instance. None until first successful request.
        cache_enabled: Whether response caching is enabled.
    """

    # REST endpoint prefixes to try (in order of preference)
    REST_PREFIXES = ["/rest", "/xwiki/rest"]

    def __init__(
        self,
        base_url: str,
        username: str | None,
        password: str | None,
        timeout: int = 20,
        cache_enabled: bool = False,
        cache_ttl: int = 300,
    ):
        # Validate and normalize base URL
        self.base_url = validate_base_url(base_url)

        # Validate timeout
        self.timeout = validate_timeout(timeout)

        # Set up session - use cached session if caching is enabled
        self.cache_enabled = cache_enabled
        if cache_enabled:
            self.session: requests.Session = requests_cache.CachedSession(
                cache_name="xwiki_cache",
                backend="memory",
                expire_after=cache_ttl,
            )
        else:
            self.session = requests.Session()

        if username and password:
            self.session.auth = (username, password)

        # Cache for successful REST endpoint prefix
        # Once we find a working prefix, reuse it for subsequent requests
        self._endpoint_prefix: str | None = None

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def get(self, path: str, **kwargs: Any) -> requests.Response:
        """Perform a GET request with error handling.

        Args:
            path: The API path to request
            **kwargs: Additional arguments to pass to requests.get()

        Returns:
            The HTTP response object

        Raises:
            XWikiConnectionError: If connection to the server fails
            XWikiAuthenticationError: If authentication fails (401)
            XWikiAuthorizationError: If authorization fails (403)
            XWikiResourceNotFoundError: If the resource is not found (404)
            XWikiAPIError: For other HTTP errors
        """
        url = self._url(path)
        try:
            resp = self.session.get(url, timeout=self.timeout, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.ConnectionError as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.Timeout as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.HTTPError as e:
            # Convert HTTP errors to specific custom exceptions
            if e.response is not None:
                status_code = e.response.status_code
                if status_code == 401:
                    raise XWikiAuthenticationError(
                        "Authentication failed. Check your credentials."
                    ) from e
                if status_code == 403:
                    raise XWikiAuthorizationError(
                        "Access forbidden. Check your permissions."
                    ) from e
                # Don't raise XWikiResourceNotFoundError here - let calling code
                # handle 404s since _try_rest_paths needs to try multiple endpoints
            raise

    def put(
        self, path: str, data: dict[str, Any] | None = None, **kwargs: Any
    ) -> requests.Response:
        """Perform a PUT request with error handling.

        Args:
            path: The API path to request
            data: JSON data to send in the request body
            **kwargs: Additional arguments to pass to requests.put()

        Returns:
            The HTTP response object

        Raises:
            XWikiConnectionError: If connection to the server fails
            XWikiAuthenticationError: If authentication fails (401)
            XWikiAuthorizationError: If authorization fails (403)
        """
        url = self._url(path)
        try:
            resp = self.session.put(url, json=data, timeout=self.timeout, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.ConnectionError as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.Timeout as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.HTTPError as e:
            if e.response is not None:
                status_code = e.response.status_code
                if status_code == 401:
                    raise XWikiAuthenticationError(
                        "Authentication failed. Check your credentials."
                    ) from e
                if status_code == 403:
                    raise XWikiAuthorizationError(
                        "Access forbidden. Check your permissions."
                    ) from e
            raise

    def delete(self, path: str, **kwargs: Any) -> requests.Response:
        """Perform a DELETE request with error handling.

        Args:
            path: The API path to request
            **kwargs: Additional arguments to pass to requests.delete()

        Returns:
            The HTTP response object

        Raises:
            XWikiConnectionError: If connection to the server fails
            XWikiAuthenticationError: If authentication fails (401)
            XWikiAuthorizationError: If authorization fails (403)
        """
        url = self._url(path)
        try:
            resp = self.session.delete(url, timeout=self.timeout, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.ConnectionError as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.Timeout as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.HTTPError as e:
            if e.response is not None:
                status_code = e.response.status_code
                if status_code == 401:
                    raise XWikiAuthenticationError(
                        "Authentication failed. Check your credentials."
                    ) from e
                if status_code == 403:
                    raise XWikiAuthorizationError(
                        "Access forbidden. Check your permissions."
                    ) from e
            raise

    def post(
        self, path: str, data: dict[str, Any] | None = None, **kwargs: Any
    ) -> requests.Response:
        """Perform a POST request with error handling.

        Args:
            path: The API path to request
            data: JSON data to send in the request body
            **kwargs: Additional arguments to pass to requests.post()

        Returns:
            The HTTP response object

        Raises:
            XWikiConnectionError: If connection to the server fails
            XWikiAuthenticationError: If authentication fails (401)
            XWikiAuthorizationError: If authorization fails (403)
        """
        url = self._url(path)
        try:
            resp = self.session.post(url, json=data, timeout=self.timeout, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.ConnectionError as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.Timeout as e:
            raise XWikiConnectionError(self.base_url, e) from e
        except requests.HTTPError as e:
            if e.response is not None:
                status_code = e.response.status_code
                if status_code == 401:
                    raise XWikiAuthenticationError(
                        "Authentication failed. Check your credentials."
                    ) from e
                if status_code == 403:
                    raise XWikiAuthorizationError(
                        "Access forbidden. Check your permissions."
                    ) from e
            raise

    def _get_rest_path(
        self,
        path_suffix: str,
        headers: dict[str, str] | None = None,
        params: dict[str, str] | None = None,
    ) -> requests.Response:
        """Get a REST API resource, using cached endpoint prefix if available.

        This method handles the endpoint discovery and caching logic. On first
        request, it tries multiple REST endpoint prefixes (/rest, /xwiki/rest)
        and caches the one that works. Subsequent requests use the cached prefix
        directly, avoiding unnecessary failed requests.

        Args:
            path_suffix: The API path suffix (e.g., '/wikis/xwiki/spaces')
            headers: Optional HTTP headers to include in the request
            params: Optional query parameters to include in the request

        Returns:
            The successful HTTP response object

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint is found
            XWikiAuthenticationError: If authentication fails
            XWikiAuthorizationError: If authorization fails
            XWikiConnectionError: If connection to the server fails
        """
        headers = headers or {}

        # If we have a cached prefix, try it first
        if self._endpoint_prefix is not None:
            path = f"{self._endpoint_prefix}{path_suffix}"
            try:
                return self.get(path, headers=headers, params=params)
            except requests.HTTPError:
                # Cached prefix failed - invalidate cache and try discovery
                self._endpoint_prefix = None

        # Discovery mode: try all prefixes
        attempted_paths: list[str] = []
        for prefix in self.REST_PREFIXES:
            path = f"{prefix}{path_suffix}"
            attempted_paths.append(path)
            try:
                resp = self.get(path, headers=headers, params=params)
                # Success! Cache this prefix for future requests
                self._endpoint_prefix = prefix
                return resp
            except (
                requests.HTTPError,
                XWikiAuthenticationError,
                XWikiAuthorizationError,
            ) as e:
                # Re-raise auth errors immediately - don't try other endpoints
                if isinstance(e, XWikiAuthenticationError | XWikiAuthorizationError):
                    raise
                # For HTTP errors, try next prefix
                continue

        # If we got here, none of the endpoints succeeded
        raise XWikiEndpointNotFoundError(attempted_paths)

    def _put_rest_path(
        self,
        path_suffix: str,
        data: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> requests.Response:
        """Put a REST API resource, using cached endpoint prefix if available.

        This method handles the endpoint discovery and caching logic for PUT
        requests. On first request, it tries multiple REST endpoint prefixes
        (/rest, /xwiki/rest) and caches the one that works.

        Args:
            path_suffix: The API path suffix
                (e.g., '/wikis/xwiki/spaces/Main/pages/Test')
            data: JSON data to send in the request body
            headers: Optional HTTP headers to include in the request

        Returns:
            The successful HTTP response object

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint is found
            XWikiAuthenticationError: If authentication fails
            XWikiAuthorizationError: If authorization fails
            XWikiConnectionError: If connection to the server fails
        """
        headers = headers or {}

        # If we have a cached prefix, try it first
        if self._endpoint_prefix is not None:
            path = f"{self._endpoint_prefix}{path_suffix}"
            try:
                return self.put(path, data=data, headers=headers)
            except requests.HTTPError:
                # Cached prefix failed - invalidate cache and try discovery
                self._endpoint_prefix = None

        # Discovery mode: try all prefixes
        attempted_paths: list[str] = []
        for prefix in self.REST_PREFIXES:
            path = f"{prefix}{path_suffix}"
            attempted_paths.append(path)
            try:
                resp = self.put(path, data=data, headers=headers)
                # Success! Cache this prefix for future requests
                self._endpoint_prefix = prefix
                return resp
            except (
                requests.HTTPError,
                XWikiAuthenticationError,
                XWikiAuthorizationError,
            ) as e:
                # Re-raise auth errors immediately - don't try other endpoints
                if isinstance(e, XWikiAuthenticationError | XWikiAuthorizationError):
                    raise
                # For HTTP errors, try next prefix
                continue

        # If we got here, none of the endpoints succeeded
        raise XWikiEndpointNotFoundError(attempted_paths)

    def _delete_rest_path(
        self,
        path_suffix: str,
        headers: dict[str, str] | None = None,
    ) -> requests.Response:
        """Delete a REST API resource, using cached endpoint prefix if available.

        Args:
            path_suffix: The API path suffix
            headers: Optional HTTP headers to include in the request

        Returns:
            The successful HTTP response object

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint is found
            XWikiAuthenticationError: If authentication fails
            XWikiAuthorizationError: If authorization fails
            XWikiConnectionError: If connection to the server fails
        """
        headers = headers or {}

        # If we have a cached prefix, try it first
        if self._endpoint_prefix is not None:
            path = f"{self._endpoint_prefix}{path_suffix}"
            try:
                return self.delete(path, headers=headers)
            except requests.HTTPError:
                # Cached prefix failed - invalidate cache and try discovery
                self._endpoint_prefix = None

        # Discovery mode: try all prefixes
        attempted_paths: list[str] = []
        for prefix in self.REST_PREFIXES:
            path = f"{prefix}{path_suffix}"
            attempted_paths.append(path)
            try:
                resp = self.delete(path, headers=headers)
                # Success! Cache this prefix for future requests
                self._endpoint_prefix = prefix
                return resp
            except (
                requests.HTTPError,
                XWikiAuthenticationError,
                XWikiAuthorizationError,
            ) as e:
                # Re-raise auth errors immediately - don't try other endpoints
                if isinstance(e, XWikiAuthenticationError | XWikiAuthorizationError):
                    raise
                # For HTTP errors, try next prefix
                continue

        # If we got here, none of the endpoints succeeded
        raise XWikiEndpointNotFoundError(attempted_paths)

    def _post_rest_path(
        self,
        path_suffix: str,
        data: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> requests.Response:
        """Post to a REST API resource, using cached endpoint prefix if available.

        Args:
            path_suffix: The API path suffix
                (e.g., '/wikis/xwiki/spaces/Main/pages/Test/comments')
            data: JSON data to send in the request body
            headers: Optional HTTP headers to include in the request

        Returns:
            The successful HTTP response object

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint is found
            XWikiAuthenticationError: If authentication fails
            XWikiAuthorizationError: If authorization fails
            XWikiConnectionError: If connection to the server fails
        """
        headers = headers or {}

        # If we have a cached prefix, try it first
        if self._endpoint_prefix is not None:
            path = f"{self._endpoint_prefix}{path_suffix}"
            try:
                return self.post(path, data=data, headers=headers)
            except requests.HTTPError:
                # Cached prefix failed - invalidate cache and try discovery
                self._endpoint_prefix = None

        # Discovery mode: try all prefixes
        attempted_paths: list[str] = []
        for prefix in self.REST_PREFIXES:
            path = f"{prefix}{path_suffix}"
            attempted_paths.append(path)
            try:
                resp = self.post(path, data=data, headers=headers)
                # Success! Cache this prefix for future requests
                self._endpoint_prefix = prefix
                return resp
            except (
                requests.HTTPError,
                XWikiAuthenticationError,
                XWikiAuthorizationError,
            ) as e:
                # Re-raise auth errors immediately - don't try other endpoints
                if isinstance(e, XWikiAuthenticationError | XWikiAuthorizationError):
                    raise
                # For HTTP errors, try next prefix
                continue

        # If we got here, none of the endpoints succeeded
        raise XWikiEndpointNotFoundError(attempted_paths)

    def clear_endpoint_cache(self) -> None:
        """Clear the cached REST endpoint prefix.

        Call this if you need to force re-discovery of the endpoint pattern,
        for example after XWiki configuration changes.
        """
        self._endpoint_prefix = None

    @property
    def endpoint_prefix(self) -> str | None:
        """Get the cached REST endpoint prefix, or None if not yet discovered."""
        return self._endpoint_prefix

    def list_spaces(
        self,
        wiki: str = "xwiki",
        offset: int = 0,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """List spaces in a wiki with optional pagination.

        This method tries multiple REST API endpoint patterns to accommodate
        different XWiki deployment configurations (/rest and /xwiki/rest).

        Args:
            wiki: The wiki identifier. Defaults to "xwiki" for the main wiki.
                Use a different identifier for other wikis in a multi-wiki setup.
            offset: Number of items to skip (0-based). Defaults to 0.
            limit: Maximum number of items to return. None returns all items.

        Returns:
            A list of space dictionaries. Each space dict typically contains:
                - 'id': Space identifier (str)
                - 'name': Display name of the space (str)
                - 'home': URL to the space home page (str)
                - 'xwikiRelativeUrl': Relative URL within XWiki (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> spaces = client.list_spaces()
            >>> print(spaces[0]['name'])
            'Main'
            >>> # Get first 10 spaces
            >>> first_page = client.list_spaces(limit=10)
            >>> # Get next 10 spaces
            >>> second_page = client.list_spaces(offset=10, limit=10)
        """
        path_suffix = f"/wikis/{urllib.parse.quote(wiki)}/spaces"
        params: dict[str, str] = {}
        if offset > 0:
            params["start"] = str(offset)
        if limit is not None:
            params["number"] = str(limit)

        resp = self._get_rest_path(
            path_suffix,
            headers={"Accept": "application/json"},
            params=params if params else None,
        )
        data = resp.json()

        # XWiki may return either {"spaces": [{...}]} or {"spaces": {"space": [{...}]}}
        spaces: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("spaces"), list):
                spaces = data["spaces"]
            else:
                spaces = data.get("spaces", {}).get("space", [])
        return spaces

    def get_page(self, wiki: str, space: str, page: str) -> dict[str, Any]:
        """Get a single page from a space.

        Retrieves detailed information about a specific page including its
        content, metadata, and version information. Tries multiple REST API
        endpoint patterns for compatibility.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located (case-sensitive)
            page: The page name to retrieve (case-sensitive, e.g., "WebHome")

        Returns:
            A dictionary containing page information:
                - 'id': Full page identifier (str)
                - 'title': Page title (str)
                - 'name': Page name (str)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'version': Version number (str)
                - 'author': Author identifier (str)
                - 'content': Page content in XWiki syntax (str)
                - 'xwikiRelativeUrl': Relative URL to the page (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds or
                the page doesn't exist.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> page = client.get_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome"
            ... )
            >>> print(page['title'])
            'Sandbox Home'
            >>> print(page['version'])
            '1.1'
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
        )
        resp = self._get_rest_path(path_suffix, headers={"Accept": "application/json"})
        result: dict[str, Any] = resp.json()
        return result

    def list_page_versions(
        self,
        wiki: str,
        space: str,
        page: str,
    ) -> list[dict[str, Any]]:
        """List all versions of a page.

        Retrieves the version history of a specific page, showing all revisions
        that have been created. Each version includes metadata like author,
        date, and version number.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located (case-sensitive)
            page: The page name (case-sensitive, e.g., "WebHome")

        Returns:
            A list of version dictionaries. Each dict typically contains:
                - 'version': Version number (str, e.g., "1.1", "2.3")
                - 'author': Author of this version (str)
                - 'date': Date the version was created (str, ISO 8601 format)
                - 'comment': Commit message/comment (str, if provided)
                - 'minorEdit': Whether this was a minor edit (bool)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds or
                the page doesn't exist.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> versions = client.list_page_versions(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome"
            ... )
            >>> for version in versions:
            ...     print(f"{version['version']}: {version['author']}")
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/history"
        )
        resp = self._get_rest_path(path_suffix, headers={"Accept": "application/json"})
        data = resp.json()

        # Normalize response structure
        versions: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("history"), list):
                versions = data["history"]
            else:
                versions = data.get("history", {}).get("version", [])
        return versions

    def get_page_version(
        self,
        wiki: str,
        space: str,
        page: str,
        version: str,
    ) -> dict[str, Any]:
        """Get a specific version of a page.

        Retrieves the content and metadata of a specific version of a page.
        This is useful for viewing previous versions or comparing changes
        between versions.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located (case-sensitive)
            page: The page name (case-sensitive, e.g., "WebHome")
            version: The version number to retrieve (e.g., "1.1", "2.3")

        Returns:
            A dictionary containing the page version information:
                - 'id': Full page identifier (str)
                - 'title': Page title (str)
                - 'name': Page name (str)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'version': Version number (str)
                - 'author': Author of this version (str)
                - 'date': Date the version was created (str)
                - 'content': Page content at this version (str)
                - 'xwikiRelativeUrl': Relative URL to the page (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds or
                the page/version doesn't exist.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> version = client.get_page_version(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     version="1.1"
            ... )
            >>> print(f"Title: {version['title']}")
            >>> print(f"Author: {version['author']}")
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/history/{urllib.parse.quote(version)}"
        )
        resp = self._get_rest_path(path_suffix, headers={"Accept": "application/json"})
        result: dict[str, Any] = resp.json()
        return result

    def list_pages(
        self,
        wiki: str,
        space: str,
        offset: int = 0,
        limit: int | None = None,
    ) -> list[dict[str, Any]]:
        """List pages in a space with optional pagination.

        Retrieves a list of pages within a specified space. This is useful
        for discovering available pages or iterating through space content.
        Tries multiple REST API endpoint patterns for compatibility.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name to list pages from (case-sensitive)
            offset: Number of items to skip (0-based). Defaults to 0.
            limit: Maximum number of items to return. None returns all items.

        Returns:
            A list of page dictionaries. Each page dict typically contains:
                - 'id': Full page identifier (str)
                - 'name': Page name (str)
                - 'title': Page title (str)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'xwikiRelativeUrl': Relative URL to the page (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds or
                the space doesn't exist.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> pages = client.list_pages(wiki="xwiki", space="Main")
            >>> for page in pages:
            ...     print(f"{page['name']}: {page['title']}")
            WebHome: Main Home
            Dashboard: Main Dashboard
            >>> # Get first 50 pages
            >>> first_page = client.list_pages(wiki="xwiki", space="Main", limit=50)
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages"
        )
        params: dict[str, str] = {}
        if offset > 0:
            params["start"] = str(offset)
        if limit is not None:
            params["number"] = str(limit)

        resp = self._get_rest_path(
            path_suffix,
            headers={"Accept": "application/json"},
            params=params if params else None,
        )
        data = resp.json()

        # Normalize typical structures
        # Either {"pages":[...]} or {"pages":{"page":[...]}} or {"pageSummaries":[...]}
        pages: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("pages"), list):
                pages = data["pages"]
            else:
                pages = data.get("pages", {}).get("page", []) or data.get(
                    "pageSummaries", []
                )
        return pages

    def search(
        self,
        wiki: str,
        query: str,
        space: str | None = None,
        offset: int = 0,
        limit: int = 20,
    ) -> list[dict[str, Any]]:
        """Full-text search across a wiki with pagination support.

        Performs a full-text search across wiki content. You can optionally
        filter results to a specific space and control pagination.
        Tries multiple REST API endpoint patterns for compatibility.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            query: The search query text. Supports XWiki search syntax for
                advanced queries (e.g., exact phrases with quotes)
            space: Optional space name to limit search scope. If None, searches
                across all spaces the user has access to
            offset: Number of results to skip (0-based). Defaults to 0.
            limit: Maximum number of results to return (default: 20). Set higher
                for comprehensive searches, lower for quick previews

        Returns:
            A list of search result dictionaries. Each result typically contains:
                - 'id': Page identifier (str)
                - 'title': Page title (str)
                - 'excerpt': Text excerpt showing query context (str)
                - 'score': Relevance score (float)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'xwikiRelativeUrl': Relative URL to the page (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> # Basic search across all spaces
            >>> results = client.search(wiki="xwiki", query="documentation")
            >>> print(f"Found {len(results)} results")
            Found 15 results
            >>>
            >>> # Paginated search
            >>> page1 = client.search(wiki="xwiki", query="API", limit=10)
            >>> page2 = client.search(wiki="xwiki", query="API", offset=10, limit=10)
        """
        path_suffix = f"/wikis/{urllib.parse.quote(wiki)}/search"
        params: dict[str, str] = {"q": query, "number": str(limit)}
        if space:
            params["space"] = space
        if offset > 0:
            params["start"] = str(offset)

        resp = self._get_rest_path(
            path_suffix, headers={"Accept": "application/json"}, params=params
        )
        data = resp.json()

        # Normalize: results can be under 'searchResults' or 'searchResult'
        results: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("searchResults"), list):
                results = data["searchResults"]
            else:
                results = data.get("searchResults", {}).get("searchResult", [])
        return results

    def put_page(
        self,
        wiki: str,
        space: str,
        page: str,
        title: str,
        content: str,
    ) -> dict[str, Any]:
        """Create or update a page in a space.

        Uses PUT to create a new page or update an existing one. The page will
        be created if it doesn't exist, or updated if it already exists.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page should be located (case-sensitive)
            page: The page name to create/update (case-sensitive, e.g., "MyPage")
            title: The display title for the page
            content: The page content in XWiki syntax or plain text

        Returns:
            A dictionary containing the created/updated page information:
                - 'id': Full page identifier (str)
                - 'title': Page title (str)
                - 'name': Page name (str)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'version': Version number (str)
                - 'content': Page content (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> # Create a new page
            >>> page = client.put_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="MyNewPage",
            ...     title="My New Page",
            ...     content="This is the page content."
            ... )
            >>> print(page['title'])
            'My New Page'
            >>>
            >>> # Update an existing page
            >>> updated = client.put_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="MyNewPage",
            ...     title="Updated Title",
            ...     content="Updated content."
            ... )
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
        )
        page_data = {
            "title": title,
            "content": content,
        }
        resp = self._put_rest_path(
            path_suffix,
            data=page_data,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        result: dict[str, Any] = resp.json()
        return result

    def update_page(
        self,
        wiki: str,
        space: str,
        page: str,
        title: str | None = None,
        content: str | None = None,
    ) -> dict[str, Any]:
        """Update an existing page in a space.

        Updates the title and/or content of an existing page. At least one of
        title or content must be provided. If not provided, the method retrieves
        the current page and uses existing values.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located (case-sensitive)
            page: The page name to update (case-sensitive, e.g., "MyPage")
            title: New display title for the page (optional, uses current
                if not provided)
            content: New page content in XWiki syntax or plain text
                (optional, uses current if not provided)

        Returns:
            A dictionary containing the updated page information:
                - 'id': Full page identifier (str)
                - 'title': Page title (str)
                - 'name': Page name (str)
                - 'space': Space name (str)
                - 'wiki': Wiki identifier (str)
                - 'version': Version number (str)
                - 'content': Page content (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds or
                the page doesn't exist.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.
            ValueError: If neither title nor content is provided.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> # Update only the title
            >>> updated = client.update_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="MyPage",
            ...     title="Updated Title"
            ... )
            >>> # Update only the content
            >>> updated = client.update_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="MyPage",
            ...     content="Updated content."
            ... )
            >>> # Update both title and content
            >>> updated = client.update_page(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="MyPage",
            ...     title="New Title",
            ...     content="New content."
            ... )
        """
        if title is None and content is None:
            raise ValueError("At least one of title or content must be provided")

        # If title or content is not provided, fetch the current page
        if title is None or content is None:
            current_page = self.get_page(wiki=wiki, space=space, page=page)
            if title is None:
                title = current_page.get("title", "")
            if content is None:
                content = current_page.get("content", "")

        # Use put_page to perform the actual update
        return self.put_page(
            wiki=wiki, space=space, page=page, title=title, content=content
        )

    def list_attachments(
        self,
        wiki: str,
        space: str,
        page: str,
    ) -> list[dict[str, Any]]:
        """List all attachments on a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name

        Returns:
            A list of attachment dictionaries. Each dict typically contains:
                - 'name': Attachment filename (str)
                - 'size': File size in bytes (int)
                - 'mimeType': MIME type of the file (str)
                - 'author': Author who uploaded the attachment (str)
                - 'version': Version number (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> attachments = client.list_attachments(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome"
            ... )
            >>> for att in attachments:
            ...     print(f"{att['name']} ({att['size']} bytes)")
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/attachments"
        )
        resp = self._get_rest_path(path_suffix, headers={"Accept": "application/json"})
        data = resp.json()

        # Normalize response structure
        attachments: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("attachments"), list):
                attachments = data["attachments"]
            else:
                attachments = data.get("attachments", {}).get("attachment", [])
        return attachments

    def get_attachment(
        self,
        wiki: str,
        space: str,
        page: str,
        filename: str,
    ) -> bytes:
        """Download an attachment from a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name
            filename: The attachment filename to download

        Returns:
            The raw bytes of the attachment content.

        Raises:
            XWikiEndpointNotFoundError: If the attachment is not found.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> content = client.get_attachment(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     filename="document.pdf"
            ... )
            >>> with open("document.pdf", "wb") as f:
            ...     f.write(content)
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/attachments/{urllib.parse.quote(filename)}"
        )
        resp = self._get_rest_path(path_suffix)
        return resp.content

    def put_attachment(
        self,
        wiki: str,
        space: str,
        page: str,
        filename: str,
        content: bytes,
        content_type: str = "application/octet-stream",
    ) -> dict[str, Any]:
        """Upload or update an attachment on a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name
            filename: The filename for the attachment
            content: The raw bytes of the file content
            content_type: MIME type of the file (default: application/octet-stream)

        Returns:
            A dictionary containing the attachment metadata.

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> with open("document.pdf", "rb") as f:
            ...     content = f.read()
            >>> result = client.put_attachment(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     filename="document.pdf",
            ...     content=content,
            ...     content_type="application/pdf"
            ... )
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/attachments/{urllib.parse.quote(filename)}"
        )

        # For file uploads, we need to use the raw put method with proper headers
        # Try cached prefix first, then discovery
        headers = {"Content-Type": content_type, "Accept": "application/json"}

        if self._endpoint_prefix is not None:
            path = f"{self._endpoint_prefix}{path_suffix}"
            try:
                resp = self.session.put(
                    self._url(path),
                    data=content,
                    headers=headers,
                    timeout=self.timeout,
                )
                resp.raise_for_status()
                result: dict[str, Any] = resp.json()
                return result
            except requests.HTTPError:
                self._endpoint_prefix = None

        # Discovery mode
        attempted_paths: list[str] = []
        for prefix in self.REST_PREFIXES:
            path = f"{prefix}{path_suffix}"
            attempted_paths.append(path)
            try:
                resp = self.session.put(
                    self._url(path),
                    data=content,
                    headers=headers,
                    timeout=self.timeout,
                )
                resp.raise_for_status()
                self._endpoint_prefix = prefix
                discovery_result: dict[str, Any] = resp.json()
                return discovery_result
            except requests.HTTPError:
                continue

        raise XWikiEndpointNotFoundError(attempted_paths)

    def delete_attachment(
        self,
        wiki: str,
        space: str,
        page: str,
        filename: str,
    ) -> None:
        """Delete an attachment from a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name
            filename: The attachment filename to delete

        Raises:
            XWikiEndpointNotFoundError: If the attachment is not found.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> client.delete_attachment(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     filename="old_document.pdf"
            ... )
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/attachments/{urllib.parse.quote(filename)}"
        )
        self._delete_rest_path(path_suffix)

    def list_comments(
        self,
        wiki: str,
        space: str,
        page: str,
    ) -> list[dict[str, Any]]:
        """List all comments on a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name

        Returns:
            A list of comment dictionaries. Each dict typically contains:
                - 'id': Comment identifier (int)
                - 'author': Author who posted the comment (str)
                - 'date': Date the comment was posted (str)
                - 'text': Comment text content (str)
                - 'highlight': Highlighted text if applicable (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> comments = client.list_comments(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome"
            ... )
            >>> for comment in comments:
            ...     print(f"{comment['author']}: {comment['text']}")
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/comments"
        )
        resp = self._get_rest_path(path_suffix, headers={"Accept": "application/json"})
        data = resp.json()

        # Normalize response structure
        comments: list[dict[str, Any]] = []
        if isinstance(data, dict):
            if isinstance(data.get("comments"), list):
                comments = data["comments"]
            else:
                comments = data.get("comments", {}).get("comment", [])
        return comments

    def add_comment(
        self,
        wiki: str,
        space: str,
        page: str,
        text: str,
    ) -> dict[str, Any]:
        """Add a comment to a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name
            text: The comment text content

        Returns:
            A dictionary containing the created comment metadata:
                - 'id': Comment identifier (int)
                - 'author': Author who posted the comment (str)
                - 'date': Date the comment was posted (str)
                - 'text': Comment text content (str)

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> comment = client.add_comment(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     text="This is a great page!"
            ... )
            >>> print(f"Comment ID: {comment['id']}")
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/comments"
        )
        comment_data = {"text": text}
        resp = self._post_rest_path(
            path_suffix,
            data=comment_data,
            headers={"Accept": "application/json", "Content-Type": "application/json"},
        )
        result: dict[str, Any] = resp.json()
        return result

    def delete_comment(
        self,
        wiki: str,
        space: str,
        page: str,
        comment_id: int,
    ) -> None:
        """Delete a comment from a page.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where the page is located
            page: The page name
            comment_id: The ID of the comment to delete

        Raises:
            XWikiEndpointNotFoundError: If no valid REST endpoint responds.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> client.delete_comment(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     page="WebHome",
            ...     comment_id=1
            ... )
        """
        path_suffix = (
            f"/wikis/{urllib.parse.quote(wiki)}"
            f"/spaces/{urllib.parse.quote(space)}"
            f"/pages/{urllib.parse.quote(page)}"
            f"/comments/{comment_id}"
        )
        self._delete_rest_path(path_suffix)

    def bulk_update_pages(
        self,
        wiki: str,
        space: str,
        pages: list[str],
        title: str | None = None,
        content: str | None = None,
    ) -> dict[str, Any]:
        """Update multiple pages in a space with the same content/title.

        Performs batch updates on multiple pages. This is useful for applying
        the same changes to several pages at once. At least one of title or
        content must be provided.

        Args:
            wiki: The wiki identifier (e.g., "xwiki" for main wiki)
            space: The space name where pages are located (case-sensitive)
            pages: List of page names to update (case-sensitive)
            title: New display title for all pages (optional)
            content: New page content for all pages (optional)

        Returns:
            A dictionary containing bulk operation results:
                - 'updated': Number of pages successfully updated (int)
                - 'failed': Number of pages that failed (int)
                - 'details': List of results for each page with 'page', 'status',
                  and 'message' fields

        Raises:
            ValueError: If neither title nor content is provided or pages list
                is empty.
            XWikiAuthenticationError: If authentication fails (401).
            XWikiAuthorizationError: If access is forbidden (403).
            XWikiConnectionError: If connection to the server fails.

        Example:
            >>> client = XWikiClient(
            ...     "https://xwiki.example.org",
            ...     "alice",
            ...     "secret"
            ... )
            >>> result = client.bulk_update_pages(
            ...     wiki="xwiki",
            ...     space="Sandbox",
            ...     pages=["Page1", "Page2", "Page3"],
            ...     title="Updated Title",
            ...     content="Bulk updated content."
            ... )
            >>> print(f"Updated {result['updated']} pages")
        """
        if not pages:
            raise ValueError("At least one page name must be provided")
        if title is None and content is None:
            raise ValueError("At least one of title or content must be provided")

        results: dict[str, Any] = {
            "updated": 0,
            "failed": 0,
            "details": [],
        }

        for page in pages:
            try:
                # If title or content not provided, fetch current values
                update_title = title
                update_content = content

                if update_title is None or update_content is None:
                    current_page = self.get_page(wiki=wiki, space=space, page=page)
                    if update_title is None:
                        update_title = current_page.get("title", "")
                    if update_content is None:
                        update_content = current_page.get("content", "")

                # Perform the update
                self.put_page(
                    wiki=wiki,
                    space=space,
                    page=page,
                    title=update_title,
                    content=update_content,
                )
                results["updated"] += 1
                results["details"].append(
                    {
                        "page": page,
                        "status": "success",
                        "message": "Page updated successfully",
                    }
                )
            except Exception as e:
                results["failed"] += 1
                results["details"].append(
                    {
                        "page": page,
                        "status": "failed",
                        "message": str(e),
                    }
                )

        return results
