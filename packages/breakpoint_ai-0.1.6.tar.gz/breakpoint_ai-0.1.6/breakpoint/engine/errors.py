class ConfigValidationError(ValueError):
    pass

