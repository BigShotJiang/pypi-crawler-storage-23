# z\_build Role

Build Z projects.
Currently only supports Go.

## Example Playbook

```yaml
- hosts: localhost
  roles:
    - role: z_build
```
