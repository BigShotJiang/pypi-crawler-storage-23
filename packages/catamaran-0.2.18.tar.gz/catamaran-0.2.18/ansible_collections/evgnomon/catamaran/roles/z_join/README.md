# z\_join

Call z join



## Example Playbook

```yaml
- hosts: shards
  roles:
    - role: z_join
```
