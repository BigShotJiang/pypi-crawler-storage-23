import sys

if "--os" in sys.argv:
    from rich import print as rich_print
    from rich.markdown import Markdown
    from rich.rule import Rule

    def print_markdown(message):
        """
        Display markdown message. Works with multiline strings with lots of indentation.
        Will automatically make single line > tags beautiful.
        """

        for line in message.split("\n"):
            line = line.strip()
            if line == "":
                print("")
            elif line == "---":
                rich_print(Rule(style="white"))
            else:
                try:
                    rich_print(Markdown(line))
                except UnicodeEncodeError as e:
                    # Replace the problematic character or handle the error as needed
                    print("Error displaying line:", line)

        if "\n" not in message and message.startswith(">"):
            # Aesthetic choice. For these tags, they need a space below them
            print("")

    from importlib.metadata import version
    import requests
    from packaging import version

    def check_for_update():
        # Fetch the latest version from the PyPI API
        response = requests.get(f"https://pypi.org/pypi/close-probe/json")
        latest_version = response.json()["info"]["version"]

        # Get the current version using importlib.metadata
        current_version = version("close-probe")

        return version.parse(latest_version) > version.parse(current_version)

    if check_for_update():
        print_markdown(
            "> **A new version of CloseProbe is available.**\n>Please run: `pip install --upgrade close-probe`\n\n---"
        )

    if "--voice" in sys.argv:
        print("Coming soon...")
    from .computer_use.loop import run_async_main

    run_async_main()
    exit()

from .core.async_core import AsyncProbe
from .core.computer.terminal.base_language import BaseLanguage
from .core.core import CloseProbe

from importlib.metadata import version as _get_version

probe = CloseProbe()
computer = probe.computer

# provide a consistent __version__ attribute matching pyproject.toml
__version__ = _get_version("close-probe")

# Backward compatibility aliases for old close-probe naming convention
# These will be removed in a future major version
import warnings
interpreter = probe  # Alias for old import style
CloseProbe = CloseProbe  # Alias for old class imports
AsyncInterpreter = AsyncProbe  # Alias for old async class imports

def __getattr__(name):
    """Provide deprecation warnings for old naming conventions."""
    if name == "interpreter":
        warnings.warn(
            "The 'interpreter' import is deprecated. Please use 'probe' instead.\n"
            "Old: from probe import probe (deprecated)\n"
            "New: from probe import probe",
            DeprecationWarning,  
            stacklevel=2
        )
        return probe
    elif name == "CloseProbe":
        warnings.warn(
            "The 'CloseProbe' class is deprecated. Please use 'CloseProbe' instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return CloseProbe
    elif name == "AsyncInterpreter":
        warnings.warn(
            "The 'AsyncInterpreter' class is deprecated. Please use 'AsyncProbe' instead.",
            DeprecationWarning,
            stacklevel=2
        )
        return AsyncProbe
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

#     ____                      ____      __                            __
#    / __ \____  ___  ____     /  _/___  / /____  _________  ________  / /____  _____
#   / / / / __ \/ _ \/ __ \    / // __ \/ __/ _ \/ ___/ __ \/ ___/ _ \/ __/ _ \/ ___/
#  / /_/ / /_/ /  __/ / / /  _/ // / / / /_/  __/ /  / /_/ / /  /  __/ /_/  __/ /
#  \____/ .___/\___/_/ /_/  /___/_/ /_/\__/\___/_/  / .___/_/   \___/\__/\___/_/
#      /_/                                         /_/
