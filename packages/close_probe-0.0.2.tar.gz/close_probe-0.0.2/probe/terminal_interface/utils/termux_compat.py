"""
Termux Detection and Compatibility Module

Provides utilities for detecting and optimizing for the Termux environment
on Android, including graceful degradation of desktop-only features.
"""

import os
import sys
import warnings
from typing import Optional


def is_termux() -> bool:
    """
    Detect if running in Termux environment.
    
    Returns:
        bool: True if running in Termux, False otherwise
    """
    # Check TERMUX_VERSION environment variable
    if os.environ.get("TERMUX_VERSION") is not None:
        return True
    
    # Check for Termux directory structure
    if os.path.exists("/data/data/com.termux"):
        return True
    
    # Check for Termux prefix directory
    termux_prefix = os.environ.get("PREFIX", "")
    if "/termux" in termux_prefix or "/com.termux" in termux_prefix:
        return True
    
    return False


def get_termux_home() -> Optional[str]:
    """
    Get the Termux home directory.
    
    Returns:
        Optional[str]: Termux home directory if running in Termux, None otherwise
    """
    if is_termux():
        return os.path.expanduser("~")
    return None


def get_close_probe_config_dir() -> str:
    """
    Get the appropriate CloseProbe configuration directory for the current environment.
    
    Returns:
        str: Configuration directory path
    """
    if is_termux():
        termux_home = get_termux_home()
        config_dir = os.path.join(termux_home, ".close-probe")
    else:
        try:
            import platformdirs
            config_dir = platformdirs.user_config_dir("close-probe")
        except ImportError:
            # Fallback if platformdirs not available
            config_dir = os.path.join(os.path.expanduser("~"), ".close-probe")
    
    os.makedirs(config_dir, exist_ok=True)
    return config_dir


def is_low_memory_environment() -> bool:
    """
    Check if running in a low-memory environment (typical for mobile).
    
    Returns:
        bool: True if estimated to be low-memory environment
    """
    if not is_termux():
        return False
    
    # Termux on mobile devices typically has limited memory
    # This could be refined with actual memory detection
    return True


def get_recommended_context_window() -> int:
    """
    Get recommended LLM context window size for current environment.
    
    Returns:
        int: Recommended context window size (tokens)
    """
    if is_termux():
        # Reduce context window for mobile devices to save memory
        return 2000  # Conservative default for Termux
    return 8000  # Standard default


def safely_import_desktop_feature(module_name: str, fallback=None, warn=True):
    """
    Safely import desktop-only features with graceful fallback.
    
    Useful for features like tkinter, clipboard libraries, etc. that may not
    be available or functional on Termux/Android.
    
    Args:
        module_name: Name of module to import
        fallback: Value to return if import fails (default None)
        warn: Whether to print warning on fallback (default True)
    
    Returns:
        Imported module or fallback value
    """
    try:
        return __import__(module_name)
    except (ImportError, ModuleNotFoundError, Exception) as e:
        if is_termux():
            if warn:
                print(
                    f"⚠️  Warning: '{module_name}' not available in Termux. "
                    f"This feature will be disabled. ({str(e)})",
                    file=sys.stderr
                )
        else:
            if warn:
                warnings.warn(
                    f"Could not import '{module_name}': {str(e)}",
                    ImportWarning
                )
        return fallback


def setup_termux_optimizations():
    """
    Apply Termux-specific optimizations during startup.
    
    This should be called early in the initialization process.
    """
    if not is_termux():
        return
    
    # Reduce verbosity to save terminal bandwidth
    os.environ.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    
    # Optimize for low-memory environments
    if is_low_memory_environment():
        # Reduce compilation cache size
        os.environ.setdefault("PYTHONUNBUFFERED", "1")


class TermuxCompatibilityWarning(UserWarning):
    """Warning emitted when features degrade gracefully in Termux."""
    pass


def warn_feature_unavailable_in_termux(feature_name: str, reason: str = ""):
    """
    Emit a warning about unavailable feature in Termux.
    
    Args:
        feature_name: Name of the unavailable feature
        reason: Optional explanation of why it's unavailable
    """
    message = f"Feature '{feature_name}' is not available in Termux environment"
    if reason:
        message += f": {reason}"
    
    warnings.warn(message, TermuxCompatibilityWarning, stacklevel=2)


__all__ = [
    "is_termux",
    "get_termux_home",
    "get_close_probe_config_dir",
    "is_low_memory_environment",
    "get_recommended_context_window",
    "safely_import_desktop_feature",
    "setup_termux_optimizations",
    "TermuxCompatibilityWarning",
    "warn_feature_unavailable_in_termux",
]
