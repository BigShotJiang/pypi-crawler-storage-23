import os
import platformdirs

def _get_termux_home():
    """Get Termux home directory if running in Termux."""
    if os.environ.get("TERMUX_VERSION") is not None or os.path.exists("/data/data/com.termux"):
        # Running in Termux
        termux_home = os.path.expanduser("~")
        return termux_home
    return None

termux_home = _get_termux_home()
if termux_home:
    # Use Termux-compatible path
    oi_dir = os.path.join(termux_home, ".close-probe")
else:
    # Use standard platform directory
    oi_dir = platformdirs.user_config_dir("close-probe")

# Ensure directory exists
os.makedirs(oi_dir, exist_ok=True)
