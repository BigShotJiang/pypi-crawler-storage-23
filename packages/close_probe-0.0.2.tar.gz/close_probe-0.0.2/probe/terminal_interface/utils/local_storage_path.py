import os
import platformdirs

def _get_termux_home():
    """Get Termux home directory if running in Termux."""
    if os.environ.get("TERMUX_VERSION") is not None or os.path.exists("/data/data/com.termux"):
        return os.path.expanduser("~")
    return None

termux_home = _get_termux_home()
if termux_home:
    # Use Termux-compatible path
    config_dir = os.path.join(termux_home, ".close-probe")
else:
    # Use standard platform directory
    config_dir = platformdirs.user_config_dir("close-probe")


def get_storage_path(subdirectory=None):
    if subdirectory is None:
        return config_dir
    else:
        path = os.path.join(config_dir, subdirectory)
        os.makedirs(path, exist_ok=True)
        return path
