"""
prompt_loader.py — Load system prompt templates for sub-agents.

Resolution order (first found wins):
  1. User override: SUBGEMI_HOME/prompts/<name>.md  (customizable without code changes)
  2. Package default: gemini_subagent/prompts/<name>.md  (shipped with the package)
"""

import importlib.resources
from pathlib import Path
from string import Template

from gemini_subagent.config import PROMPTS_DIR


def _load_template(name: str) -> str:
    """
    Load a prompt template by name, checking user overrides first,
    then falling back to the package-shipped default.
    """
    # 1. User override in SUBGEMI_HOME/prompts/
    user_path = PROMPTS_DIR / f"{name}.md"
    if user_path.exists():
        return user_path.read_text()

    # 2. Package default via importlib.resources (works in installed packages)
    try:
        pkg = importlib.resources.files("gemini_subagent") / "prompts" / f"{name}.md"
        return pkg.read_text()
    except (FileNotFoundError, TypeError):
        pass

    raise FileNotFoundError(
        f"Prompt template '{name}' not found in {PROMPTS_DIR} or package data."
    )


def render_worktree_prompt(worktree_dir: str, branch_name: str) -> str:
    """Render the system prompt for a worktree-isolated agent."""
    template = _load_template("system_worktree")
    return Template(template).safe_substitute(
        worktree_dir=worktree_dir,
        branch_name=branch_name,
    )


def render_fallback_prompt(session_dir: str, workspace_root: str) -> str:
    """Render the system prompt for a fallback (no git worktree) agent."""
    template = _load_template("system_fallback")
    return Template(template).safe_substitute(
        session_dir=session_dir,
        workspace_root=workspace_root,
    )
