import json
import typer
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.text import Text

from gemini_subagent.config import METRICS_DIR
from .ui import generate_header
from .common import console

metrics_app = typer.Typer(context_settings={"help_option_names": ["-h", "--help"]}, help="Analyze token burn and cost metrics.")

def generate_metrics_board() -> Layout:
    """Aggregates distributed metrics and renders a high-impact dashboard."""
    try:
        # 1. Aggregate distributed JSONs
        metrics_files = list(METRICS_DIR.glob("*.json"))
        aggregated = {
            "total_tokens": 0,
            "total_cost": 0.0,
            "total_latency": 0,
            "total_tools": 0,
            "total_lines": 0,
            "avg_efficiency": 0.0,
            "sessions_count": len(metrics_files),
            "models": {},
            "lanes": {},
        }

        history = []
        efficiency_sum = 0.0
        sessions_with_efficiency = 0

        for mf in metrics_files:
            try:
                data = json.loads(mf.read_text())
                history.append(data)

                # Accumulate
                aggregated["total_tokens"] += data["tokens"]["total"]
                aggregated["total_cost"] += data["cost_usd"]
                aggregated["total_latency"] += data["latency_ms"]
                aggregated["total_tools"] += data["tool_calls"]

                git_data = data.get("git", {})
                aggregated["total_lines"] += git_data.get("total_lines", 0)
                efficiency = git_data.get("efficiency", 0.0)
                if efficiency > 0:
                    efficiency_sum += efficiency
                    sessions_with_efficiency += 1

                # Model breakdown
                m = data["model"]
                aggregated["models"][m] = aggregated["models"].get(m, 0) + 1

                # Lane breakdown
                lane_val = data.get("lane", "default")
                aggregated["lanes"][lane_val] = aggregated["lanes"].get(lane_val, 0) + 1
            except Exception:
                continue

        if sessions_with_efficiency > 0:
            aggregated["avg_efficiency"] = efficiency_sum / sessions_with_efficiency

        # 2. Build UI Components
        header = generate_header()

        # Summary Row (Stats)
        stats_table = Table.grid(expand=True)
        stats_table.add_column(justify="center", ratio=1)
        stats_table.add_column(justify="center", ratio=1)
        stats_table.add_column(justify="center", ratio=1)
        stats_table.add_column(justify="center", ratio=1)
        stats_table.add_column(justify="center", ratio=1)
        stats_table.add_column(justify="center", ratio=1)

        avg_cost = (
            aggregated["total_cost"] / aggregated["sessions_count"]
            if aggregated["sessions_count"] > 0
            else 0
        )
        proj_1k = avg_cost * 1000

        stats_table.add_row(
            Panel(
                Text(f"{aggregated['sessions_count']}", style="bold cyan"),
                title="Sessions",
                border_style="cyan",
            ),
            Panel(
                Text(f"${aggregated['total_cost']:,.4f}", style="bold green"),
                title="Total Spend",
                border_style="green",
            ),
            Panel(
                Text(
                    f"${proj_1k:,.2f}",
                    style="bold red" if proj_1k > 50 else "bold yellow",
                ),
                title="Proj. 1k Tasks",
                border_style="red" if proj_1k > 50 else "yellow",
            ),
            Panel(
                Text(f"{aggregated['total_tokens']:,}", style="dim"),
                title="Total Tokens",
                border_style="dim",
            ),
            Panel(
                Text(f"{aggregated['total_lines']:,}", style="bold blue"),
                title="Lines Changed",
                border_style="blue",
            ),
            Panel(
                Text(f"{aggregated['avg_efficiency']:.2f}", style="bold white"),
                title="ROI (Lines/1k Tok)",
                border_style="white",
            ),
        )

        model_table = Table(title="Model Distribution", box=None, header_style="bold blue")
        model_table.add_column("Model")
        model_table.add_column("Usage", justify="right")
        for m, count in sorted(aggregated["models"].items(), key=lambda x: x[1], reverse=True):
            model_table.add_row(m, str(count))

        lane_table = Table(title="Lane Distribution", box=None, header_style="bold magenta")
        lane_table.add_column("Lane")
        lane_table.add_column("Usage", justify="right")
        for lane_name, count in sorted(aggregated["lanes"].items(), key=lambda x: x[1], reverse=True):
            lane_table.add_row(lane_name, str(count))

        # Recent History Table
        history_table = Table(title="Recent Token Burn History", box=None, expand=True)
        history_table.add_column("Session", style="cyan")
        history_table.add_column("Model", style="blue")
        history_table.add_column("Tokens", justify="right", style="yellow")
        history_table.add_column("Cost", justify="right", style="green")
        history_table.add_column("Git", justify="right", style="blue")
        history_table.add_column("ROI", justify="right", style="white")
        history_table.add_column("Lane", style="magenta")
        history_table.add_column("Status", style="bold")

        for item in sorted(history, key=lambda x: x["timestamp"], reverse=True)[:10]:
            status_style = "green" if item["status"] == "COMPLETED" else "red" if "FAILED" in item["status"] else "white"
            git = item.get("git", {})
            status_fmt = item["status"][:12]
            heals = item.get("heal_attempts", 0)
            if heals > 0:
                status_fmt += f" (H:{heals})"
            history_table.add_row(
                item["session_id"][-8:],
                item["model"][:15],
                f"{item['tokens']['total']:,}",
                f"${item['cost_usd']:.4f}",
                f"+{git.get('lines_added', 0)}/-{git.get('lines_removed', 0)}",
                f"{git.get('efficiency', 0.0):.2f}",
                item.get("lane", "default"),
                Text(status_fmt, style=status_style)
            )

        # Assemble Layout
        layout = Layout()
        layout.split(
            Layout(name="header", size=3),
            Layout(name="summary", size=5),
            Layout(name="tables", size=12),
            Layout(name="history")
        )

        layout["header"].update(header)
        layout["summary"].update(stats_table)
        layout["tables"].split_row(
            Layout(Panel(model_table, border_style="blue")),
            Layout(Panel(lane_table, border_style="magenta"))
        )
        layout["history"].update(Panel(history_table, title="Detailed Execution Bank", border_style="dim"))

        return layout

    except Exception as e:
        return Panel(f"Error aggregating metrics: {e}", title="Error", border_style="red")

@metrics_app.command("board")
def metrics_board(
    json_mode: bool = typer.Option(False, "--json", "-j", help="Output raw JSON.")
):
    """Analyze token burn and cost metrics across all history."""
    if json_mode:
        metrics_files = list(METRICS_DIR.glob("*.json"))
        history = []
        for mf in metrics_files:
            try:
                history.append(json.loads(mf.read_text()))
            except Exception:
                continue
        console.print(json.dumps(history))
    else:
        console.print(generate_metrics_board())
