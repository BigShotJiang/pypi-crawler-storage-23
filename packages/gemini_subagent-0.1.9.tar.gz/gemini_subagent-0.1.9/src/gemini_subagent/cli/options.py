from typing import Optional
from typing_extensions import Annotated
import typer

# Common Typer CLI Options (Annotated pattern).
# NOTE: Do NOT include default values inside typer.Option() here.
# Defaults are declared in each command function signature instead.

LaneOpt = Annotated[str, typer.Option("--lane", "-l", help="Execution lane.")]
BackgroundOpt = Annotated[bool, typer.Option("--background/--foreground", help="Run in background.")]
ParentIdOpt = Annotated[Optional[str], typer.Option("--parent-id", "-pid", help="ID of the parent session for lineage tracking.")]
TimeoutOpt = Annotated[int, typer.Option("--timeout", "-t", help="Timeout for the task in seconds.")]
ApprovalModeOpt = Annotated[str, typer.Option("--approval-mode", "-a", help="Approval mode: default, auto_edit, yolo, plan. Defaults to 'yolo' for headless sub-agents.")]
VerifyCmdOpt = Annotated[Optional[str], typer.Option("--verify-cmd", "-v", help="Command to run after execution to verify success. If it fails, auto-heal is triggered.")]
ModelOpt = Annotated[Optional[str], typer.Option("--model", "-m", help="Gemini model to use for this sub-agent.")]
SlimOpt = Annotated[bool, typer.Option("--slim/--no-slim", help="Skip optional context (GEMINI.md, plans, etc.) to save tokens.")]
IncludeOpt = Annotated[Optional[str], typer.Option("--include", help="Comma-separated patterns to include in Repomix context.")]
ExcludeOpt = Annotated[Optional[str], typer.Option("--exclude", help="Comma-separated patterns to exclude from Repomix context.")]
