from rich.console import Console

console = Console()
state = {"quiet": False, "json": False}
