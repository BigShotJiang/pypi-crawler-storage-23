import os
import time
import json
import shutil
import logging
import asyncio
import subprocess
from pathlib import Path
from typing import Dict, Any, Optional
from uuid import uuid4
from filelock import FileLock

from gemini_subagent.config import SESSIONS_DIR, MEMORY_DIR, LOG_DIR, WORKTREES_DIR, WORKSPACE_ROOT, REGISTRY_PRUNE_THRESHOLD, REGISTRY_DIR
from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-session")

class SessionError(Exception):
    pass

class SessionManager:
    """
    Manages the lifecycle of sub-agent execution sessions.
    Handles ID generation, filesystem setup, backgrounding (Tmux), and cleanup.
    """
    def __init__(self, sessions_root: Path = SESSIONS_DIR):
        self.sessions_root = sessions_root
        self.registry_dir = REGISTRY_DIR
        # Legacy support/cleanup
        self.legacy_registry_path = MEMORY_DIR / "sub_agent_registry.json"

    def create_session(self, parent_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Generates a new session ID and directory.
        
        Returns:
            Dict containing session_id and session_dir (as Path).
        """
        session_id = f"sub_{int(time.time())}_{uuid4().hex[:8]}"
        session_dir = self.sessions_root / session_id
        session_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize registry entry early to track lineage
        self.update_registry(session_id, {
            "status": "PENDING",
            "parent_id": parent_id,
            "created_at": time.time()
        })
        
        return {"id": session_id, "dir": session_dir}

    def create_worktree(self, session_id: str) -> Optional[Path]:
        """
        Creates an isolated git worktree for the sub-agent.
        This is the V1 isolation mechanism — agents write to their own
        branch without touching the user's workspace HEAD.

        Returns:
            Path to the worktree, or None if git or the repo is unavailable.
        """
        if not shutil.which("git"):
            logger.warning("git not found — worktree unavailable.")
            return None

        worktree_path = WORKTREES_DIR / session_id
        branch_name = f"subgemi/{session_id}"

        try:
            result = subprocess.run(
                ["git", "-C", str(WORKSPACE_ROOT), "worktree", "add",
                 "-b", branch_name, str(worktree_path)],
                capture_output=True, text=True, timeout=30
            )
            if result.returncode == 0:
                logger.info(f"Worktree created: {worktree_path} on branch {branch_name}")
                return worktree_path
            else:
                logger.warning(f"git worktree add failed: {result.stderr.strip()}")
                return None
        except Exception as e:
            logger.error(f"Worktree creation error: {e}")
            return None

    def remove_worktree(self, session_id: str):
        """Prunes the git worktree after a session ends."""
        worktree_path = WORKTREES_DIR / session_id
        if not worktree_path.exists():
            return
        
        # Epic 3.1: Cleanup Hardening — Ensure metadata is writable before removal
        git_meta = worktree_path / ".git"
        if git_meta.exists():
            try:
                os.chmod(git_meta, 0o666)
            except Exception:
                pass

        try:
            subprocess.run(
                ["git", "-C", str(WORKSPACE_ROOT), "worktree", "remove",
                 str(worktree_path), "--force"],
                capture_output=True, timeout=30
            )
            logger.info(f"Worktree removed: {worktree_path}")
        except Exception as e:
            logger.warning(f"Worktree removal failed (may need manual cleanup): {e}")



    def get_all_sessions(self) -> Dict[str, Any]:
        """
        Aggregates all distributed session state artifacts.
        """
        registry = {}
        try:
            for state_file in self.registry_dir.glob("*.json"):
                try:
                    session_id = state_file.stem
                    data = json.loads(state_file.read_text())
                    registry[session_id] = data
                except Exception:
                    continue
            return registry
        except Exception as e:
            logger.error(f"Failed to aggregate registry: {e}")
            return {}

    def get_active_session_count(self) -> int:
        """Counts sessions that are in a non-terminal state."""
        sessions = self.get_all_sessions()
        terminal_states = ["COMPLETED", "FAILED", "VALIDATION_FAILED", "DETACHED"]
        count = 0
        for info in sessions.values():
            if info.get("status") not in terminal_states:
                count += 1
        return count

    def get_session(self, session_id: str) -> Optional[Dict[str, Any]]:
        """
        Safely retrieves a specific session from the registry.
        """
        registry = self.get_all_sessions()
        return registry.get(session_id)

    def update_registry(self, session_id: str, data: Dict[str, Any]):
        """
        Updates an individual session state artifact atomically.
        """
        state_file = self.registry_dir / f"{session_id}.json"
        
        try:
            current_entry = {}
            if state_file.exists():
                try:
                    current_entry = json.loads(state_file.read_text())
                except Exception:
                    pass
            
            # Update specific session
            current_entry.update(data)
            current_entry["last_update"] = time.time()
            
            # Atomic-ish write (per-file is already safe from cross-session contention)
            state_file.write_text(json.dumps(current_entry, indent=2))
            
            # Periodic Pruning (triggered on update, but only for old terminal files)
            # This keeps the registry dir clean without a central lock.
            now = time.time()
            # Random chance to prune to avoid every process doing it at once
            if now % 10 < 1: # ~10% chance per call
                self._prune_legacy_registry()
                self._prune_old_artifacts()

        except Exception as e:
            logger.error(f"Failed to update session state {session_id}: {e}")

    def _prune_legacy_registry(self):
        """Removes the old monolithic registry if it exists."""
        if self.legacy_registry_path.exists():
            try:
                self.legacy_registry_path.unlink()
                logger.info("Removed legacy monolithic registry.")
            except Exception:
                pass

    def _prune_old_artifacts(self):
        """Deletes terminal state artifacts older than the threshold."""
        now = time.time()
        terminal_states = ["COMPLETED", "FAILED", "VALIDATION_FAILED"]
        for sf in self.registry_dir.glob("*.json"):
            try:
                data = json.loads(sf.read_text())
                if (now - data.get("last_update", 0) >= REGISTRY_PRUNE_THRESHOLD) and (data.get("status") in terminal_states):
                    sf.unlink()
                    logger.debug(f"Pruned stale state artifact: {sf.name}")
            except Exception:
                continue

    def prune_orphaned_monitors(self):
        """
        Forceful cleanup of any strictly 'gemini_' prefixed tmux sessions 
        that do not exist in our active registry. Useful if the worker crashed.
        """
        if not shutil.which("tmux"):
            return

        try:
            # Get all current gemini tmux sessions
            result = subprocess.run(["tmux", "ls", "-F", "#S"], capture_output=True, text=True)
            if result.returncode != 0:
                return
            
            existing_tmux = [line.strip() for line in result.stdout.splitlines() if line.startswith("gemini_")]
            if not existing_tmux:
                return

            # Get all registered tmux sessions
            registry = self.get_all_sessions()
            registered_tmux = set()
            for info in registry.values():
                if info.get("tmux_session"):
                    registered_tmux.add(info["tmux_session"])

            # Kill any not in registry
            for session in existing_tmux:
                if session not in registered_tmux:
                    subprocess.run(["tmux", "kill-session", "-t", session], 
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                    logger.info(f"Pruned orphaned tmux monitor: {session}")
        except Exception as e:
            logger.debug(f"Failed to prune orphaned tmux monitors: {e}")

    def is_process_alive(self, pid: Optional[int]) -> bool:
        """
        Uses OS kill signal 0 to check if a process is actually running.
        """
        if pid is None:
            return False
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False

    def remove_session(self, session_id: str):
        """
        Removes an individual session state artifact.
        """
        state_file = self.registry_dir / f"{session_id}.json"
        try:
            if state_file.exists():
                state_file.unlink()
        except Exception as e:
            logger.error(f"Failed to remove session artifact {session_id}: {e}")

    def cleanup_session(self, session_dir: Path, session_id: Optional[str] = None):
        """Removes the session directory and its associated git worktree."""
        if session_dir.exists():
            shutil.rmtree(session_dir, ignore_errors=True)
            logger.debug(f"Cleaned up session dir: {session_dir}")
        if session_id:
            self.remove_worktree(session_id)

    def get_log_paths(self, session_dir: Path) -> Dict[str, Path]:
        return {
            "stdout": session_dir / "stdout.log",
            "stderr": session_dir / "stderr.log"
        }
