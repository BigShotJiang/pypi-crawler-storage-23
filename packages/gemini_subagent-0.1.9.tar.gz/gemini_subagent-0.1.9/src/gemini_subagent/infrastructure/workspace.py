import subprocess
import logging
from pathlib import Path
from typing import List, Optional, Tuple
from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-workspace")

class GitWorkspace:
    """
    Handles git operations within an isolated worktree or project root.
    Provides methods for status checking, diffing, and auto-committing.
    """
    def __init__(self, root: Path):
        self.root = root
        self.is_git = (root / ".git").exists()

    def check_for_artifacts(self, paths: Optional[List[str]] = None) -> bool:
        """Checks for uncommitted/modified files using git status."""
        if not self.is_git:
            return False
            
        cmd = ["git", "status", "--porcelain", "-uall"]
        if paths:
            cmd.extend(paths)
            
        try:
            result = subprocess.run(cmd, cwd=str(self.root), capture_output=True, text=True, timeout=10)
            lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
            return len(lines) > 0
        except Exception as e:
            logger.error(f"Artifact check failed: {e}")
            return False

    def get_diff_stats(self) -> Tuple[int, int]:
        """Returns (lines_added, lines_removed) using git diff across the worktree."""
        if not self.is_git:
            return 0, 0
            
        try:
            # 1. Stage everything to ensure diff includes new files
            subprocess.run(["git", "add", "-A"], cwd=str(self.root), check=True, timeout=30)
            
            # 2. Get numstat for the staged changes
            result = subprocess.run(
                ["git", "diff", "--cached", "--numstat"], 
                cwd=str(self.root), capture_output=True, text=True, timeout=10
            )
            
            total_added = 0
            total_removed = 0
            
            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue
                parts = line.split()
                if len(parts) >= 3:
                    try:
                        added = int(parts[0]) if parts[0] != '-' else 0
                        removed = int(parts[1]) if parts[1] != '-' else 0
                        total_added += added
                        total_removed += removed
                    except ValueError:
                        continue
                        
            return total_added, total_removed
            
        except Exception as e:
            logger.error(f"Failed to get git metrics: {e}")
            return 0, 0

    def commit(self, message: str):
        """Auto-commits all changes in the workspace."""
        if not self.is_git:
            return
            
        try:
            subprocess.run(["git", "add", "-A"], cwd=str(self.root), check=True, timeout=30)
            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=str(self.root),
                check=True,
                timeout=30
            )
        except Exception as e:
            logger.warning(f"Commit failed (maybe no changes?): {e}")

    def get_status_porcelain(self) -> str:
        """Returns the raw porcelain status output."""
        if not self.is_git:
            return ""
        try:
            result = subprocess.run(
                ["git", "status", "--porcelain", "-uall"],
                cwd=str(self.root), capture_output=True, text=True, timeout=10
            )
            return result.stdout
        except Exception:
            return ""
