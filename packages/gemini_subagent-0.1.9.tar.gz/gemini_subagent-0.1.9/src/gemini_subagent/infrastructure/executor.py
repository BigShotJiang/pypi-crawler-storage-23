import asyncio
import os
import subprocess
from pathlib import Path
from typing import List, Optional, Tuple, Callable, Dict
from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-executor")

class ProcessExecutor:
    """
    Handles execution of the gemini-cli process with safety sandboxing.
    """
    def __init__(self, session_id: str, session_dir: Path, execution_cwd: Optional[Path] = None):
        self.session_id = session_id
        self.session_dir = session_dir
        self.execution_cwd = execution_cwd
        self.stdout_path = session_dir / "stdout.log"
        self.stderr_path = session_dir / "stderr.log"
        self.safety_bin_dir = session_dir / "safety_bin"

    def _setup_safety_sandbox(self) -> Dict[str, str]:
        """Creates a mock PATH to intercept dangerous commands."""
        self.safety_bin_dir.mkdir(exist_ok=True, parents=True)
        blocked_cmds = ["rm", "deploy", "kubectl", "terraform", "aws", "gcloud"]
        for cmd_name in blocked_cmds:
            mock_path = self.safety_bin_dir / cmd_name
            if not mock_path.exists():
                mock_path.write_text(
                    f"#!/usr/bin/env bash\n"
                    f"echo 'ERROR: Execution of `{cmd_name}` is strictly prohibited by Subgemi safety sandbox.' >&2\n"
                    f"exit 1\n"
                )
                mock_path.chmod(0o755)

        custom_env = os.environ.copy()
        custom_env["PATH"] = f"{self.safety_bin_dir}:{custom_env.get('PATH', '')}"
        return custom_env

    async def execute(
        self, 
        cmd: List[str], 
        timeout: int, 
        heartbeat_callback: Optional[Callable] = None
    ) -> Tuple[str, str, int, Optional[int]]:
        """
        Runs the command and returns (stdout, stderr, exit_code, pid).
        """
        logger.info(f"Executing in {self.execution_cwd or 'CWD'}: {' '.join(cmd)}")
        
        custom_env = self._setup_safety_sandbox()
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdin=subprocess.DEVNULL,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            cwd=str(self.execution_cwd) if self.execution_cwd else None,
            env=custom_env
        )

        pid = process.pid
        stdout_chunks = []
        stderr_chunks = []

        async def read_stream(stream, path, chunks):
            with open(path, "ab") as f:
                while True:
                    line = await stream.read(4096)
                    if not line:
                        break
                    f.write(line)
                    f.flush()
                    chunks.append(line.decode(errors="replace"))

        # Monitor heartbeat if callback provided
        async def monitor_heartbeat():
            if not heartbeat_callback:
                return
            while process.returncode is None:
                await asyncio.sleep(30)
                if process.returncode is None:
                    await heartbeat_callback()

        heartbeat_task = asyncio.create_task(monitor_heartbeat())

        try:
            await asyncio.wait_for(
                asyncio.gather(
                    read_stream(process.stdout, self.stdout_path, stdout_chunks),
                    read_stream(process.stderr, self.stderr_path, stderr_chunks),
                    process.wait()
                ),
                timeout=timeout
            )
            return "".join(stdout_chunks), "".join(stderr_chunks), process.returncode, pid
        except asyncio.TimeoutError:
            logger.error(f"Process timeout after {timeout}s")
            try:
                process.kill()
            except Exception:
                pass
            return "".join(stdout_chunks), "TIMEOUT", -1, pid
        finally:
            heartbeat_task.cancel()
            try:
                await heartbeat_task
            except asyncio.CancelledError:
                pass
