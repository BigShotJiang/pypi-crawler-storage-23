"""
tmux_monitor.py — Provides terminal multiplexer monitoring capabilities.
Abstracts away the spawning of background standard output tailing for agents.
"""

import shlex
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-tmux")


class TmuxMonitor:
    """Handles spawning background tmux sessions for monitoring logs."""
    
    @staticmethod
    def start_monitor(session_id: str, session_dir: Path) -> Optional[str]:
        """
        Starts a background Tmux session to monitor the log file.
        
        Args:
            session_id: The unique ID.
            session_dir: The session directory where stdout.log will be written.
            
        Returns:
            The name of the created tmux session, or None if tmux is unavailable.
        """
        if not shutil.which("tmux"):
            logger.warning("Tmux not found. Background monitoring disabled.")
            return None

        tmux_session_name = f"gemini_{session_id[-8:]}"
        log_file = session_dir / "stdout.log"
        
        # Monitor command: Wait for file, then tail it
        # Use shlex.quote to prevent shell injection vulnerabilities on log_file
        safe_log_file = shlex.quote(str(log_file))
        monitor_cmd = f"until [ -f {safe_log_file} ]; do sleep 0.1; done; tail -f {safe_log_file}"
        
        try:
            subprocess.Popen([
                "tmux", "new-session", "-d", "-s", tmux_session_name, "bash", "-c", monitor_cmd
            ])
            logger.info(f"Background monitoring started: {tmux_session_name}")
            return tmux_session_name
        except Exception as e:
            logger.error(f"Failed to start tmux session: {e}")
            return None
