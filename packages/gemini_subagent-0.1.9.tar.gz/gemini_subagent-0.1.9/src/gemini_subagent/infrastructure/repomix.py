import asyncio
import logging
from pathlib import Path
from typing import Optional, List

from gemini_subagent.config import WORKSPACE_ROOT
from gemini_subagent.utils.logger import setup_gemini_logging

logger = setup_gemini_logging("geminis-repomix")

class RepomixError(Exception):
    """Raised when Repomix execution fails."""
    pass

class RepomixClient:
    """
    Handles interactions with the Repomix tool to pack codebases for context.
    """
    
    @staticmethod
    async def pack(
        target: str, 
        output_dir: Path, 
        index: int = 0,
        include: Optional[str] = None,
        exclude: Optional[str] = None
    ) -> Optional[str]:
        """
        Runs repomix on a target directory/file and outputs to the session directory.
        
        Args:
            target: The target path (relative or absolute) to pack.
            output_dir: The directory where the packed file will be saved.
            index: An index to ensure unique filenames for multiple targets.
            
        Returns:
            The absolute path to the generated context file, or None if failed.
        """
        target_path = Path(target)
        if not target_path.is_absolute():
            target_path = WORKSPACE_ROOT / target_path
        
        if not target_path.exists():
            logger.warning(f"Repomix target not found: {target_path}")
            return None

        output_name = f"context_pack_{index}_{target_path.name}.md"
        output_path = output_dir / output_name
        logger.info(f"Running Repomix on {target_path} -> {output_path}")

        try:
            repomix_args = [
                "npx", "-y", "repomix",
                "--style", "markdown",
                "--output", str(output_path),
                "--", str(target_path)
            ]
            
            if include:
                repomix_args.extend(["--include", include])
            if exclude:
                repomix_args.extend(["--exclude", exclude])

            # Special case: If packing internal .agent/knowledge, ensure we don't ignore it via .gitignore rules
            if ".agent/knowledge" in str(target_path):
                repomix_args.append("--no-gitignore")
            
            process = await asyncio.create_subprocess_exec(
                *repomix_args,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE
            )
            stdout_bytes, stderr_bytes = await process.communicate()
            
            if process.returncode != 0:
                error_msg = stderr_bytes.decode()
                logger.error(f"Repomix terminated with error: {error_msg}")
                raise RepomixError(f"Repomix failed: {error_msg}")
            
            if output_path.exists():
                logger.info(f"Successfully packed context: {output_path}")
                return str(output_path)
            else:
                logger.error(f"Repomix finished but output file missing: {output_path}")
                return None

        except Exception as e:
            logger.error(f"Repomix failed for {target}: {e}")
            return None
