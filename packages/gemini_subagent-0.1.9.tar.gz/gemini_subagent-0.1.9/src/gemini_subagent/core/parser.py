import json
from pathlib import Path
from typing import Dict, Any, Tuple, Optional

class ResultParser:
    """
    Standardized parsing for extracting structured payloads from session outputs.
    """
    
    @staticmethod
    def parse_session_output(session_dir: Path) -> Tuple[Dict[str, Any], bool, str]:
        """
        Parses session output from files.
        Returns:
            Tuple[Dict[str, Any], bool, str]: 
                - The parsed JSON dictionary
                - A boolean indicating whether it fell back to scraping stdout.log
                - The raw stdout text (useful for error reporting)
        """
        payload_file = session_dir / "fsm_payload_out.json"
        log_file = session_dir / "stdout.log"

        if payload_file.exists():
            try:
                return json.loads(payload_file.read_text()), False, ""
            except Exception:
                pass

        raw_stdout = ""
        if log_file.exists():
            raw_stdout = log_file.read_text().strip()
            # Try to find JSON block directly
            try:
                json_str = raw_stdout
                if "{" in raw_stdout:
                    json_start = raw_stdout.find("{")
                    json_end = raw_stdout.rfind("}") + 1
                    if json_end > json_start:
                        json_str = raw_stdout[json_start:json_end]
                return json.loads(json_str), True, raw_stdout
            except json.JSONDecodeError:
                # Try markdown code block
                if "```json" in raw_stdout:
                    try:
                        clean = raw_stdout.split("```json")[1].split("```")[0].strip()
                        return json.loads(clean), True, raw_stdout
                    except Exception:
                        pass
                
                return {"error": "Failed to parse JSON output STRICTLY"}, True, raw_stdout
                
        return {"error": "Result files missing"}, False, raw_stdout
