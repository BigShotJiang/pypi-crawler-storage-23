from enum import Enum, auto
from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any

class AgentState(Enum):
    PENDING = auto()
    PREPARING_CONTEXT = auto()
    EXECUTING_PROCESS = auto()
    VALIDATING_OUTPUT = auto()
    CLEANUP = auto()
    COMPLETED = auto()
    FAILED = auto()
    VALIDATION_FAILED = auto()
    DETACHED = auto()
    HEALING = auto()
    VERIFICATION = auto()

@dataclass
class ExecutionResult:
    status: str
    output: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    exit_code: int = 0
    duration: float = 0.0
    lines_added: int = 0
    lines_removed: int = 0
    heal_attempts: int = 0
