# pylint: disable=invalid-name, missing-docstring, line-too-long, logging-fstring-interpolation, too-many-arguments

import os
import sys
import typing
import logging
from collections import defaultdict
from datetime import datetime
from datetime import timedelta
from concurrent.futures import ThreadPoolExecutor

import numpy as np
from google.cloud import bigtable
from google.cloud.bigtable.data import BigtableDataClient
from google.cloud.bigtable.data import ReadRowsQuery
from google.cloud.bigtable.data import RowRange
from google.cloud.bigtable.data.mutations import SetCell
from google.cloud.bigtable.data.mutations import DeleteRangeFromColumn
from google.cloud.bigtable.data.mutations import DeleteAllFromRow
from google.cloud.bigtable.data.mutations import RowMutationEntry
from google.cloud.bigtable.data.read_modify_write_rules import IncrementRule
from google.cloud.bigtable.data.exceptions import MutationsExceptionGroup
from google.cloud.bigtable.column_family import MaxAgeGCRule
from google.cloud.bigtable.column_family import MaxVersionsGCRule
from google.cloud.bigtable.data.row_filters import RowFilter
from google.api_core.exceptions import Aborted
from google.api_core.exceptions import DeadlineExceeded
from google.api_core.exceptions import ServiceUnavailable

from . import utils
from . import BigTableConfig
from ..base import Cell
from ..base import ClientWithIDGen
from ..base import OperationLogger
from .. import attributes
from .. import exceptions
from ..serializers import serialize_uint64
from ..utils import get_valid_timestamp


def _datetime_to_micros(dt: datetime) -> int:
    """Convert datetime to microseconds for bigtable mutations."""
    return int(dt.timestamp() * 1_000_000)


class _CompatibleRow:
    """Wraps a new-API Row to mimic legacy PartialRowData.

    Provides ``.cells`` as ``{family_str: {qualifier_bytes: [Cell, ...]}}``.
    """

    __slots__ = ("cells",)

    def __init__(self, row):
        families = defaultdict(lambda: defaultdict(list))
        for cell in row.cells:
            qual = cell.qualifier if isinstance(cell.qualifier, bytes) else cell.qualifier.encode()
            families[cell.family][qual].append(
                Cell(value=cell.value, timestamp=cell.timestamp_micros)
            )
        self.cells = dict(families)

    def __eq__(self, other):
        if not isinstance(other, _CompatibleRow):
            return NotImplemented
        return self.cells == other.cells

    def __hash__(self):
        return id(self)


class _ReadAllRowsResult:
    """Wrapper for read_all_rows result, compatible with legacy RowIterator API."""

    def __init__(self, rows_list):
        self.rows = {row.row_key: _CompatibleRow(row) for row in rows_list}

    def consume_all(self):
        pass


class Client(ClientWithIDGen, OperationLogger):
    def __init__(
        self,
        table_id: str,
        config: BigTableConfig = BigTableConfig(),
        graph_meta=None,
        lock_expiry: timedelta = timedelta(minutes=3),
    ):
        # Admin client (legacy — only for table/column family management)
        admin_kwargs = dict(project=config.PROJECT, admin=config.ADMIN)
        if config.CREDENTIALS:
            admin_kwargs["credentials"] = config.CREDENTIALS
        self._admin_client = bigtable.Client(**admin_kwargs)
        admin_instance = self._admin_client.instance(config.INSTANCE)
        self._admin_table = admin_instance.table(table_id)

        # Data client (new — all read/write/lock operations)
        data_kwargs = dict(project=config.PROJECT)
        if config.CREDENTIALS:
            data_kwargs["credentials"] = config.CREDENTIALS
        self._data_client = BigtableDataClient(**data_kwargs)
        self._table = self._data_client.get_table(
            config.INSTANCE,
            table_id,
            # Read rows
            default_read_rows_operation_timeout=600.0,
            default_read_rows_attempt_timeout=20.0,
            # Mutate rows (batch)
            default_mutate_rows_retryable_errors=(
                Aborted, DeadlineExceeded, ServiceUnavailable,
            ),
            default_mutate_rows_operation_timeout=600.0,
            default_mutate_rows_attempt_timeout=60.0,
            # Single-row ops (lock/unlock/increment)
            default_operation_timeout=60.0,
            default_attempt_timeout=20.0,
            default_retryable_errors=(DeadlineExceeded, ServiceUnavailable),
        )

        self.logger = logging.getLogger(
            f"{config.PROJECT}/{config.INSTANCE}/{table_id}"
        )
        self.logger.setLevel(logging.WARNING)
        if not self.logger.handlers:
            sh = logging.StreamHandler(sys.stdout)
            sh.setLevel(logging.WARNING)
            self.logger.addHandler(sh)
        self._graph_meta = graph_meta
        self._lock_expiry = lock_expiry
        self._version = None
        self._max_row_key_count = config.MAX_ROW_KEY_COUNT

    # ── Admin ────────────────────────────────────────────────────────────

    def _create_column_families(self):
        f = self._admin_table.column_family("0")
        f.create()
        f = self._admin_table.column_family("1", gc_rule=MaxVersionsGCRule(1))
        f.create()
        f = self._admin_table.column_family("2")
        f.create()
        f = self._admin_table.column_family("3", gc_rule=MaxAgeGCRule(timedelta(days=365)))
        f.create()
        f = self._admin_table.column_family("4")
        f.create()

    def create_graph(self, meta, version: str) -> None:
        if self._admin_table.exists():
            raise ValueError(f"{self._admin_table.table_id} already exists.")
        self._admin_table.create()
        self._create_column_families()
        self.add_graph_version(version)
        self.update_graph_meta(meta)

    def create_column_family(self, family_id, gc_rule=None):
        f = self._admin_table.column_family(family_id, gc_rule=gc_rule)
        f.create()

    # ── Write ────────────────────────────────────────────────────────────

    def mutate_row(
        self,
        row_key: bytes,
        val_dict: typing.Dict[attributes._Attribute, typing.Any],
        time_stamp: typing.Optional[datetime] = None,
    ) -> RowMutationEntry:
        ts_micros = _datetime_to_micros(time_stamp) if time_stamp else None
        mutations = []
        for column, value in val_dict.items():
            mutations.append(
                SetCell(
                    family=column.family_id,
                    qualifier=column.key,
                    new_value=column.serialize(value),
                    timestamp_micros=ts_micros,
                )
            )
        return RowMutationEntry(row_key, mutations)

    def write(
        self,
        rows,
        root_ids=None,
        operation_id=None,
        slow_retry: bool = True,
        block_size: int = 2000,
    ):
        if root_ids is not None and operation_id is not None:
            if isinstance(root_ids, int):
                root_ids = [root_ids]
            if not self.renew_locks(root_ids, operation_id):
                raise exceptions.LockingError(
                    f"Root lock renewal failed: operation {operation_id}"
                )

        rows_list = list(rows)
        if not rows_list:
            return

        timeout = self._lock_expiry.total_seconds() if slow_retry else 30.0
        try:
            if len(rows_list) == 1:
                entry = rows_list[0]
                self._table.mutate_row(entry.row_key, list(entry.mutations))
            else:
                self._table.bulk_mutate_rows(rows_list, operation_timeout=timeout)
        except MutationsExceptionGroup:
            raise exceptions.KVDBClientError(
                f"Bulk write failed: operation {operation_id}"
            )

    # ── Locking ──────────────────────────────────────────────────────────

    def lock_root(self, root_id: np.uint64, operation_id: np.uint64) -> bool:
        lock_column = attributes.Concurrency.Lock
        indefinite_lock_column = attributes.Concurrency.IndefiniteLock
        filter_ = utils.get_root_lock_filter(
            lock_column, self._lock_expiry, indefinite_lock_column
        )
        lock_acquired = not self._table.check_and_mutate_row(
            serialize_uint64(root_id),
            predicate=filter_,
            false_case_mutations=SetCell(
                family=lock_column.family_id,
                qualifier=lock_column.key,
                new_value=serialize_uint64(operation_id),
                timestamp_micros=_datetime_to_micros(get_valid_timestamp(None)),
            ),
            operation_timeout=30.0,
        )
        if not lock_acquired:
            row = self._read_byte_row(serialize_uint64(root_id), columns=lock_column)
            l_operation_ids = [cell.value for cell in row]
            self.logger.debug(f"Locked operation ids: {l_operation_ids}")
        return lock_acquired

    def lock_root_indefinitely(self, root_id: np.uint64, operation_id: np.uint64) -> bool:
        lock_column = attributes.Concurrency.IndefiniteLock
        filter_ = utils.get_indefinite_root_lock_filter(lock_column)
        lock_acquired = not self._table.check_and_mutate_row(
            serialize_uint64(root_id),
            predicate=filter_,
            false_case_mutations=SetCell(
                family=lock_column.family_id,
                qualifier=lock_column.key,
                new_value=serialize_uint64(operation_id),
                timestamp_micros=_datetime_to_micros(get_valid_timestamp(None)),
            ),
            operation_timeout=30.0,
        )
        if not lock_acquired:
            row = self._read_byte_row(serialize_uint64(root_id), columns=lock_column)
            l_operation_ids = [cell.value for cell in row]
            self.logger.debug(f"Indefinitely locked operation ids: {l_operation_ids}")
        return lock_acquired

    def unlock_root(self, root_id: np.uint64, operation_id: np.uint64):
        lock_column = attributes.Concurrency.Lock
        filter_ = utils.get_unlock_root_filter(
            lock_column, self._lock_expiry, operation_id
        )
        return self._table.check_and_mutate_row(
            serialize_uint64(root_id),
            predicate=filter_,
            true_case_mutations=DeleteRangeFromColumn(
                family=lock_column.family_id,
                qualifier=lock_column.key,
            ),
            operation_timeout=30.0,
        )

    def unlock_indefinitely_locked_root(self, root_id: np.uint64, operation_id: np.uint64):
        lock_column = attributes.Concurrency.IndefiniteLock
        return self._table.check_and_mutate_row(
            serialize_uint64(root_id),
            predicate=utils.get_indefinite_unlock_root_filter(lock_column, operation_id),
            true_case_mutations=DeleteRangeFromColumn(
                family=lock_column.family_id,
                qualifier=lock_column.key,
            ),
            operation_timeout=30.0,
        )

    def renew_lock(self, root_id: np.uint64, operation_id: np.uint64) -> bool:
        lock_column = attributes.Concurrency.Lock
        return not self._table.check_and_mutate_row(
            serialize_uint64(root_id),
            predicate=utils.get_renew_lock_filter(lock_column, operation_id),
            false_case_mutations=SetCell(
                family=lock_column.family_id,
                qualifier=lock_column.key,
                new_value=lock_column.serialize(operation_id),
            ),
            operation_timeout=30.0,
        )

    # ── Timestamp ────────────────────────────────────────────────────────

    def get_compatible_timestamp(self, time_stamp: datetime, round_up: bool = False) -> datetime:
        return utils.get_google_compatible_time_stamp(time_stamp, round_up=round_up)

    # ── IDs ──────────────────────────────────────────────────────────────

    def _get_ids_range(self, key: bytes, size: int) -> typing.Tuple:
        column = attributes.Concurrency.Counter
        result_row = self._table.read_modify_write_row(
            key,
            IncrementRule(column.family_id, column.key, increment_amount=size),
        )
        cells = result_row.get_cells(column.family_id, column.key)
        high = column.deserialize(cells[0].value)
        return high + np.uint64(1) - size, high

    # ── Read ─────────────────────────────────────────────────────────────

    def _read_byte_rows(
        self,
        start_key=None,
        end_key=None,
        end_key_inclusive=False,
        row_keys=None,
        columns=None,
        start_time=None,
        end_time=None,
        end_time_inclusive=False,
        user_id=None,
    ):
        row_ranges = None
        if row_keys is not None:
            pass
        elif start_key is not None and end_key is not None:
            row_ranges = [RowRange(
                start_key=start_key,
                end_key=end_key,
                start_is_inclusive=True,
                end_is_inclusive=end_key_inclusive,
            )]
        else:
            raise exceptions.PreconditionError(
                "Need to either provide a valid set of rows, or"
                " both, a start row and an end row."
            )

        filter_ = utils.get_time_range_and_column_filter(
            columns=columns,
            start_time=start_time,
            end_time=end_time,
            end_inclusive=end_time_inclusive,
            user_id=user_id,
        )

        rows = self._read(
            row_keys=row_keys,
            row_ranges=row_ranges,
            row_filter=filter_,
        )

        # Deserialize cell values
        for row_key, column_dict in rows.items():
            for column, cell_entries in column_dict.items():
                for i, cell_entry in enumerate(cell_entries):
                    column_dict[column][i] = Cell(
                        value=column.deserialize(cell_entry.value),
                        timestamp=cell_entry.timestamp,
                    )
            if isinstance(columns, attributes._Attribute):
                rows[row_key] = column_dict.get(columns, [])
        return rows

    def _read_byte_row(self, row_key, columns=None, start_time=None, end_time=None, end_time_inclusive=False):
        row = self._read_byte_rows(
            row_keys=[row_key],
            columns=columns,
            start_time=start_time,
            end_time=end_time,
            end_time_inclusive=end_time_inclusive,
        )
        return (
            row.get(row_key, [])
            if isinstance(columns, attributes._Attribute)
            else row.get(row_key, {})
        )

    def _execute_read(self, query: ReadRowsQuery) -> typing.Dict:
        if not query.row_keys and not query.row_ranges:
            return {}
        return {
            row.row_key: utils.row_to_column_dict(row)
            for row in self._table.read_rows_stream(query)
        }

    def _read(
        self,
        row_keys=None,
        row_ranges=None,
        row_filter: typing.Optional[RowFilter] = None,
    ):
        keys = row_keys or []
        n_subrequests = max(
            1, int(np.ceil(len(keys) / self._max_row_key_count))
        )
        n_threads = min(n_subrequests, 2 * (os.cpu_count() or 1))

        queries = []
        for i in range(n_subrequests):
            chunk_keys = keys[
                i * self._max_row_key_count : (i + 1) * self._max_row_key_count
            ]
            queries.append(ReadRowsQuery(
                row_keys=chunk_keys if chunk_keys else None,
                row_filter=row_filter,
            ))

        if row_ranges:
            for rr in row_ranges:
                queries[0].add_range(rr)

        if n_threads <= 1:
            responses = [self._execute_read(q) for q in queries]
        else:
            with ThreadPoolExecutor(max_workers=n_threads) as executor:
                responses = list(executor.map(self._execute_read, queries))

        combined_response = {}
        for resp in responses:
            combined_response.update(resp)
        return combined_response

    def read_all_rows(self):
        rows_list = self._table.read_rows(ReadRowsQuery())
        return _ReadAllRowsResult(rows_list)

    # ── Delete ───────────────────────────────────────────────────────────

    def _delete_meta(self):
        self._table.mutate_row(attributes.GraphMeta.key, DeleteAllFromRow())

    def delete_cells(self, mutations, row_keys_to_delete=None):
        entries = []
        for row_key, column, timestamps in mutations:
            row_mutations = []
            for ts in timestamps:
                start_us = _datetime_to_micros(ts)
                end_us = start_us + 1
                row_mutations.append(DeleteRangeFromColumn(
                    family=column.family_id,
                    qualifier=column.key,
                    start_timestamp_micros=start_us,
                    end_timestamp_micros=end_us,
                ))
            entries.append(RowMutationEntry(row_key, row_mutations))
        for key in (row_keys_to_delete or []):
            entries.append(RowMutationEntry(key, DeleteAllFromRow()))
        if entries:
            self._table.bulk_mutate_rows(entries)

    def delete_row(self, row_key):
        self._table.mutate_row(row_key, DeleteAllFromRow())
