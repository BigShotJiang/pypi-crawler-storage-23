"""Tests for OGM Platform CLI."""

import pytest


class TestCLIImport:
    """Basic tests for CLI imports and structure."""

    def test_cli_can_be_imported(self):
        """Test that the CLI module can be imported."""
        try:
            from ogm.cli import main
            assert main is not None
        except ImportError as e:
            pytest.fail(f"Failed to import CLI: {e}")

    def test_create_app_can_be_imported(self):
        """Test that the create_app function can be imported."""
        try:
            from ogm.cli import create_app
            assert create_app is not None
        except ImportError as e:
            pytest.fail(f"Failed to import create_app: {e}")

    def test_cli_has_docstring(self):
        """Test that the main CLI function has a docstring."""
        from ogm.cli import main
        assert main.__doc__ is not None
        assert "OGM Kubernetes Platform for GenAI Applications" in main.__doc__

    def test_create_app_has_docstring(self):
        """Test that the create_app function has a docstring."""
        from ogm.cli import create_app
        assert create_app.__doc__ is not None
        assert "Create folder structure and .ogmconfig" in create_app.__doc__