"""Synchronization module."""

from datetime import datetime
from typing import Dict

try:
    from rich.console import Console

    console = Console()
except ImportError:

    class MockConsole:
        def print(self, *args, **kwargs):
            print(*args)

    console = MockConsole()  # type: ignore


class SyncManager:
    """Manages synchronization operations."""

    def __init__(self, config, git_manager, helm_manager, state_manager):
        self.config = config
        self.git = git_manager
        self.helm = helm_manager
        self.state = state_manager

    def sync_repository(self, repo_name: str, rebuild: bool = True) -> bool:
        console.print(f"[cyan]Syncing: {repo_name}[/cyan]")

        # Get current status
        status_before = self.git.get_status(repo_name)
        if not status_before:
            console.print("[red]✗ Repository not found[/red]")
            return False

        # Pull latest
        if not self.git.pull_repository(repo_name):
            return False

        # Get new status
        status_after = self.git.get_status(repo_name)

        # Check if changed
        if status_before["commit"] == status_after["commit"]:
            console.print("[green]✓ Up to date[/green]")
            return True

        console.print(f"[green]✓ Updated to {status_after['commit']}[/green]")

        # Add to sync history
        self.state.add_sync_history(
            repo_name,
            {
                "timestamp": datetime.now().isoformat(),
                "before_commit": status_before["commit"],
                "after_commit": status_after["commit"],
                "changes": True,
            },
        )

        return True

    def sync_all_repositories(self, rebuild: bool = True) -> Dict[str, bool]:
        console.print("[bold cyan]Syncing all repositories...[/bold cyan]")

        results = {}
        for repo_config in self.config.repositories:
            results[repo_config.name] = self.sync_repository(repo_config.name, rebuild=rebuild)

        success = sum(1 for v in results.values() if v)
        console.print(f"[green]✓ Synced {success}/{len(results)} repositories[/green]")
        return results

    def check_for_updates(self) -> Dict[str, Dict]:
        console.print("[cyan]Checking for updates...[/cyan]")

        updates = {}
        for repo_config in self.config.repositories:
            self.git.fetch_all(repo_config.name)
            status = self.git.get_status(repo_config.name)
            if status:
                updates[repo_config.name] = {
                    "has_updates": False,
                    "current_commit": status["commit"],
                }

        return updates
