"""
PiQrypt Certification Service — Pay-Per Tier

Automated certification with 3 tiers:
- Simple (€9): PiQrypt CA signature
- Timestamp (€29): + TSA RFC 3161
- Post-Quantum (€99): + Dilithium3 + .pqz archive

Workflow:
    1. User uploads audit.json
    2. User pays via Stripe (€9/€29/€99)
    3. Webhook triggers certification
    4. Worker certifies based on tier
    5. User receives certified bundle via email

Integration:
    - Stripe webhooks
    - Google Drive storage
    - Email delivery (Gmail SMTP)
"""

import json
import time
import hashlib
import zipfile
import uuid
from pathlib import Path
from typing import Dict, Any
from datetime import datetime, timezone

from aiss.crypto import ed25519
from aiss.exceptions import PiQryptError
from aiss.logger import get_logger
from aiss.cert_badges import generate_cert_badge, generate_badge_snippets
from aiss.verify import verify_audit_chain

logger = get_logger(__name__)


# ─── Exceptions ───────────────────────────────────────────────────────────────

class CertificationError(PiQryptError):
    """Certification error."""
    pass


# ─── Certification Core ───────────────────────────────────────────────────────

def generate_cert_id() -> str:
    """
    Generate unique certification ID.

    Format: CERT-YYYYMMDD-XXXXXX
    Example: CERT-20260220-A3F7E8
    """
    date_str = datetime.now(timezone.utc).strftime("%Y%m%d")
    random_hex = uuid.uuid4().hex[:6].upper()
    return f"CERT-{date_str}-{random_hex}"


def validate_audit_for_certification(audit_path: str) -> Dict[str, Any]:
    """
    Validate audit file before certification.

    Args:
        audit_path: Path to audit.json file

    Returns:
        Validated audit data

    Raises:
        CertificationError: If audit invalid
    """
    try:
        with open(audit_path, 'r', encoding='utf-8') as f:
            audit = json.load(f)
    except Exception as e:
        raise CertificationError(f"Failed to load audit file: {e}")

    # Basic structure validation
    if "events" not in audit:
        raise CertificationError("Audit missing 'events' field")

    if not isinstance(audit["events"], list):
        raise CertificationError("Audit 'events' must be a list")

    if len(audit["events"]) == 0:
        raise CertificationError("Audit contains no events")

    # Verify chain integrity
    try:
        verify_audit_chain(audit)
    except Exception as e:
        raise CertificationError(f"Chain verification failed: {e}")

    logger.info(f"✅ Audit validation passed ({len(audit['events'])} events)")

    return audit


def compute_audit_hash(audit_data: Dict[str, Any]) -> str:
    """
    Compute SHA-256 hash of audit.

    Args:
        audit_data: Audit dictionary

    Returns:
        Hex hash string with sha256: prefix
    """
    audit_json = json.dumps(audit_data, sort_keys=True)
    hash_bytes = hashlib.sha256(audit_json.encode()).digest()
    return "sha256:" + hash_bytes.hex()


def certify_simple(
    audit_path: str,
    ca_private_key: bytes,
    ca_agent_id: str,
    output_dir: str = "."
) -> Dict[str, Any]:
    """
    Simple Certification (€9 tier).

    Includes:
    - PiQrypt CA signature (Ed25519)
    - Audit hash
    - Certificate metadata

    Args:
        audit_path: Path to audit.json
        ca_private_key: PiQrypt CA private key
        ca_agent_id: PiQrypt CA agent ID
        output_dir: Output directory for bundle

    Returns:
        Certification result with cert_id and files
    """
    logger.info("🔹 Starting Simple Certification (€9)")

    # 1. Validate audit
    audit = validate_audit_for_certification(audit_path)

    # 2. Generate cert ID
    cert_id = generate_cert_id()

    # 3. Compute audit hash
    audit_hash = compute_audit_hash(audit)

    # 4. Create certificate
    certificate = {
        "version": "PIQRYPT-CERT-1.0",
        "cert_id": cert_id,
        "tier": "simple",
        "audit_hash": audit_hash,
        "agent_id": audit.get("agent_id", "unknown"),
        "events_count": len(audit["events"]),
        "certified_at": int(time.time()),
        "certified_by": {
            "authority": "PiQrypt Inc.",
            "ca_agent_id": ca_agent_id
        }
    }

    # 5. Sign certificate with CA key
    cert_json = json.dumps(certificate, sort_keys=True)
    ca_signature = ed25519.sign(ca_private_key, cert_json.encode())
    certificate["ca_signature"] = "base64:" + ed25519.encode_base64(ca_signature)

    # 6. Generate badge
    badge = generate_cert_badge(cert_id, "simple")

    # 7. Create bundle
    bundle_dir = Path(output_dir) / cert_id
    bundle_dir.mkdir(exist_ok=True, parents=True)

    # Save files
    with open(bundle_dir / 'audit.json', 'w', encoding='utf-8') as f:
        json.dump(audit, f, indent=2)

    with open(bundle_dir / 'certificate.json', 'w', encoding='utf-8') as f:
        json.dump(certificate, f, indent=2)

    with open(bundle_dir / 'badge.svg', 'w', encoding='utf-8') as f:
        f.write(badge["svg"])

    with open(bundle_dir / 'SNIPPETS.txt', 'w', encoding='utf-8') as f:
        f.write(generate_badge_snippets(cert_id, "simple"))

    # 8. Create ZIP
    bundle_path = Path(output_dir) / f"{cert_id}.piqrypt-certified"
    with zipfile.ZipFile(bundle_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file in bundle_dir.iterdir():
            zf.write(file, file.name)

    logger.piqrypt(f"✅ Simple certification complete: {cert_id}")

    return {
        "cert_id": cert_id,
        "tier": "simple",
        "bundle_path": str(bundle_path),
        "badge": badge,
        "certificate": certificate
    }


def certify_timestamp(
    audit_path: str,
    ca_private_key: bytes,
    ca_agent_id: str,
    output_dir: str = ".",
    tsa_url: str = "http://freetsa.org/tsr"
) -> Dict[str, Any]:
    """
    Timestamp Certification (€29 tier).

    Includes:
    - Everything from Simple
    - TSA RFC 3161 timestamp token

    Args:
        audit_path: Path to audit.json
        ca_private_key: PiQrypt CA private key
        ca_agent_id: PiQrypt CA agent ID
        output_dir: Output directory
        tsa_url: TSA server URL (default: FreeTSA)

    Returns:
        Certification result
    """
    logger.info("🔸 Starting Timestamp Certification (€29)")

    # 1-6. Same as simple
    audit = validate_audit_for_certification(audit_path)
    cert_id = generate_cert_id()
    audit_hash = compute_audit_hash(audit)

    certificate = {
        "version": "PIQRYPT-CERT-1.0",
        "cert_id": cert_id,
        "tier": "timestamp",
        "audit_hash": audit_hash,
        "agent_id": audit.get("agent_id", "unknown"),
        "events_count": len(audit["events"]),
        "certified_at": int(time.time()),
        "certified_by": {
            "authority": "PiQrypt Inc.",
            "ca_agent_id": ca_agent_id
        }
    }

    # Sign certificate
    cert_json = json.dumps(certificate, sort_keys=True)
    ca_signature = ed25519.sign(ca_private_key, cert_json.encode())
    certificate["ca_signature"] = "base64:" + ed25519.encode_base64(ca_signature)

    # 7. Get TSA timestamp
    try:
        from aiss.rfc3161 import get_tsa_timestamp

        # Hash audit for TSA
        tsa_token = get_tsa_timestamp(audit_hash.encode(), tsa_url)

        certificate["tsa"] = {
            "url": tsa_url,
            "token_size": len(tsa_token)
        }

        logger.info(f"✅ TSA timestamp obtained from {tsa_url}")

    except Exception as e:
        logger.piqrypt_warn(f"⚠️ TSA timestamp failed: {e}")
        logger.piqrypt_warn("⚠️ Falling back to simple certification")
        # Continue without TSA (degrade gracefully)
        tsa_token = None

    # 8. Generate badge
    badge = generate_cert_badge(cert_id, "timestamp")

    # 9. Create bundle
    bundle_dir = Path(output_dir) / cert_id
    bundle_dir.mkdir(exist_ok=True, parents=True)

    with open(bundle_dir / 'audit.json', 'w', encoding='utf-8') as f:
        json.dump(audit, f, indent=2)

    with open(bundle_dir / 'certificate.json', 'w', encoding='utf-8') as f:
        json.dump(certificate, f, indent=2)

    if tsa_token:
        with open(bundle_dir / "tsa_token.tsr", 'wb') as f:
            f.write(tsa_token)

    with open(bundle_dir / 'badge.svg', 'w', encoding='utf-8') as f:
        f.write(badge["svg"])

    with open(bundle_dir / 'SNIPPETS.txt', 'w', encoding='utf-8') as f:
        f.write(generate_badge_snippets(cert_id, "timestamp"))

    # 10. Create ZIP
    bundle_path = Path(output_dir) / f"{cert_id}.piqrypt-certified"
    with zipfile.ZipFile(bundle_path, 'w', zipfile.ZIP_DEFLATED) as zf:
        for file in bundle_dir.iterdir():
            zf.write(file, file.name)

    logger.piqrypt(f"✅ Timestamp certification complete: {cert_id}")

    return {
        "cert_id": cert_id,
        "tier": "timestamp",
        "bundle_path": str(bundle_path),
        "badge": badge,
        "certificate": certificate,
        "has_tsa": tsa_token is not None
    }


def certify_pq_bundle(
    audit_path: str,
    ca_private_key: bytes,
    ca_agent_id: str,
    output_dir: str = "."
) -> Dict[str, Any]:
    """
    Post-Quantum Bundle Certification (€99 tier).

    Includes:
    - Everything from Timestamp
    - Dilithium3 signature
    - Encrypted .pqz archive

    Args:
        audit_path: Path to audit.json
        ca_private_key: PiQrypt CA private key
        ca_agent_id: PiQrypt CA agent ID
        output_dir: Output directory

    Returns:
        Certification result
    """
    logger.info("🔶 Starting Post-Quantum Bundle Certification (€99)")

    # 1-7. Same as timestamp
    result = certify_timestamp(
        audit_path,
        ca_private_key,
        ca_agent_id,
        output_dir
    )

    # 8. Add Dilithium3 signature
    # Uses aiss.crypto.dilithium with automatic fallback:
    #   1. liboqs-python (C backend, preferred)
    #   2. dilithium-py (pure Python fallback)
    from aiss.crypto import dilithium

    certificate = result["certificate"]
    certificate["tier"] = "pq_bundle"

    if dilithium.is_available():
        cert_bytes = json.dumps(certificate, sort_keys=True).encode()
        pq_priv, pq_pub = dilithium.generate_keypair()
        pq_signature = dilithium.sign(pq_priv, cert_bytes)
        backend_info = dilithium.get_backend_info()
        certificate["post_quantum"] = {
            "algorithm": "ML-DSA-65 (Dilithium3)",
            "status": "signed",
            "backend": backend_info["backend"],
            "public_key": pq_pub.hex(),
            "signature": pq_signature.hex(),
        }
        logger.info(f"🔐 Dilithium3 signature added (backend: {backend_info['backend']})")
    else:
        certificate["post_quantum"] = {
            "algorithm": "ML-DSA-65 (Dilithium3)",
            "status": "unavailable",
            "note": "Install liboqs-python or dilithium-py for PQ signatures",
        }
        logger.piqrypt_warn("⚠️ Dilithium3 backend not available — PQ signature skipped")

    # 9. Create .pqz archive (standard zip for now)

    # 10. Update badge
    badge = generate_cert_badge(result["cert_id"], "pq_bundle")

    logger.piqrypt(f"✅ Post-Quantum certification complete: {result['cert_id']}")

    return {
        **result,
        "tier": "pq_bundle",
        "badge": badge
    }


def certify_audit(
    audit_path: str,
    tier: str,
    ca_private_key: bytes = None,
    ca_agent_id: str = None,
    output_dir: str = "."
) -> Dict[str, Any]:
    """
    Main certification function — dispatches to tier-specific certifier.

    Args:
        audit_path: Path to audit.json
        tier: "simple", "timestamp", or "pq_bundle"
        ca_private_key: PiQrypt CA private key (loaded from keyfile if None)
        ca_agent_id: PiQrypt CA agent ID
        output_dir: Output directory

    Returns:
        Certification result
    """
    # Load CA key if not provided
    if ca_private_key is None:
        ca_key_path = Path.home() / ".piqrypt-ca" / "piqrypt-ca-private.key"
        if not ca_key_path.exists():
            raise CertificationError(
                "PiQrypt CA private key not found. "
                "This function requires CA credentials."
            )
        with open(ca_key_path, 'rb') as f:
            ca_private_key = f.read()

        ca_agent_id = "4q3cQHcH1oJsNwLEtbUiaMZ19THREoji"  # PiQrypt CA ID

    # Dispatch to tier
    if tier == "simple":
        return certify_simple(audit_path, ca_private_key, ca_agent_id, output_dir)
    elif tier == "timestamp":
        return certify_timestamp(audit_path, ca_private_key, ca_agent_id, output_dir)
    elif tier == "pq_bundle":
        return certify_pq_bundle(audit_path, ca_private_key, ca_agent_id, output_dir)
    else:
        raise CertificationError(f"Unknown tier: {tier}")


__all__ = [
    "generate_cert_id",
    "validate_audit_for_certification",
    "certify_simple",
    "certify_timestamp",
    "certify_pq_bundle",
    "certify_audit",
    "CertificationError",
]
