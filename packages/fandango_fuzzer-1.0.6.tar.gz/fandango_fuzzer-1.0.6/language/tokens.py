TOKENS = {
    "INDENT": None,
    "DEDENT": None,
    "SPACE": r" ",
    "TAB": r"\t",
    "NEWLINE": r"\n|\r\n",
    "COMMENT": r"#[^\n]*",
    "STRING": r"[]",
}
