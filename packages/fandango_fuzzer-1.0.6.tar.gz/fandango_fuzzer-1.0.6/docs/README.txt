This are the sources for the Fandango documentation, built using Jupyter Book. See https://jupyterbook.org/ for details.

To install, run

    $ make install

To build, use

    $ make html


