---
jupytext:
  formats: md:myst
  text_representation:
    extension: .md
    format_name: myst
kernelspec:
  display_name: Python 3
  language: python
  name: python3
---

(sec:distributions)=
# Statistical Distributions

```{admonition} Under Construction
:class: attention
This chapter is still under construction.
```

When introducing [generators](Generators.md), we have seen a first method on how to create distributions.
