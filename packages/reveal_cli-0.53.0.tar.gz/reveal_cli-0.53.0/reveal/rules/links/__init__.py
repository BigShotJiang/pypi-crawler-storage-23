# Link validation rules
from .L004 import L004  # noqa: F401
from .L005 import L005  # noqa: F401
