from __future__ import annotations

import calendar
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Union, ClassVar, Dict, cast

import pandas as pd
import pytz


@dataclass(frozen=True)
class KlineTimestamp:
    """
    Representa una vela (kline) identificada por un timestamp en milisegundos
    desde epoch (UTC) y un intervalo.

    Soporta intervalos de duracion fija (1m..1w) y mensual (1M, duracion variable).

    Parameters
    ----------
    timestamp_ms : int
        Epoch en milisegundos (UTC). Se alinea al open de la vela correspondiente.
    interval : str
        Intervalo de la vela. Valores validos: 1m, 3m, 5m, 15m, 30m, 1h, 2h,
        4h, 6h, 8h, 12h, 1d, 3d, 1w (case-insensitive), y 1M (mensual,
        case-sensitive).
    tzinfo : str or pytz.BaseTzInfo
        Zona horaria para presentacion. Default "UTC". No afecta identidad.

    Attributes
    ----------
    open : int
        Primer milisegundo de la vela (epoch ms, UTC).
    close : int
        Ultimo milisegundo de la vela (epoch ms, UTC).
    tick_ms : int
        Duracion de la vela en milisegundos. Para 1M, varia segun el mes.

    Raises
    ------
    TypeError
        Si timestamp_ms no es int.
    ValueError
        Si interval no es valido.
    """
    timestamp_ms: int
    interval: str
    tzinfo: Union[pytz.BaseTzInfo, str] = "UTC"

    # Derivados
    open: int = field(init=False)
    close: int = field(init=False)
    tick_ms: int = field(init=False, repr=False)

    # Tabla global de duración de cada intervalo en milisegundos.
    # Subconjunto de intervalos de Binance con duración fija.
    tick_milliseconds: ClassVar[Dict[str, int]] = {
        "1m": 60 * 1000,
        "3m": 3 * 60 * 1000,
        "5m": 5 * 60 * 1000,
        "15m": 15 * 60 * 1000,
        "30m": 30 * 60 * 1000,
        "1h": 60 * 60 * 1000,
        "2h": 2 * 60 * 60 * 1000,
        "4h": 4 * 60 * 60 * 1000,
        "6h": 6 * 60 * 60 * 1000,
        "8h": 8 * 60 * 60 * 1000,
        "12h": 12 * 60 * 60 * 1000,
        "1d": 24 * 60 * 60 * 1000,
        "3d": 3 * 24 * 60 * 60 * 1000,
        "1w": 7 * 24 * 60 * 60 * 1000,
    }

    def __post_init__(self) -> None:
        if not isinstance(self.timestamp_ms, int):
            raise TypeError(
                f"timestamp_ms must be int, got {type(self.timestamp_ms).__name__}"
            )

        # Normaliza el intervalo (1M es case-sensitive: mensual vs 1m minuto)
        interval_norm = "1M" if self.interval == "1M" else self.interval.lower()

        if interval_norm == "1M":
            object.__setattr__(self, "interval", "1M")
            open_ts, close_ts, tick_ms = self._monthly_bounds(self.timestamp_ms)
        elif interval_norm in self.tick_milliseconds:
            object.__setattr__(self, "interval", interval_norm)
            tick_ms = self.tick_milliseconds[interval_norm]
            open_ts = (self.timestamp_ms // tick_ms) * tick_ms
            close_ts = open_ts + tick_ms - 1
        else:
            valid = list(self.tick_milliseconds.keys()) + ["1M"]
            raise ValueError(
                f"Invalid interval: {self.interval}. "
                f"Valid intervals are: {valid}."
            )

        object.__setattr__(self, "tick_ms", tick_ms)
        object.__setattr__(self, "open", open_ts)
        object.__setattr__(self, "close", close_ts)

        # Normalización de tzinfo a instancia pytz
        tz = self._normalize_tzinfo(self.tzinfo)
        object.__setattr__(self, "tzinfo", tz)

    @staticmethod
    def _monthly_bounds(timestamp_ms: int) -> tuple[int, int, int]:
        """Calcula open, close y tick_ms para intervalo mensual (1M)."""
        dt = datetime.fromtimestamp(timestamp_ms // 1000, tz=timezone.utc)
        open_dt = dt.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        open_ms = calendar.timegm(open_dt.timetuple()) * 1000
        last_day = calendar.monthrange(dt.year, dt.month)[1]
        close_dt = dt.replace(day=last_day, hour=23, minute=59, second=59, microsecond=0)
        close_ms = calendar.timegm(close_dt.timetuple()) * 1000 + 999
        return open_ms, close_ms, close_ms - open_ms + 1

    @staticmethod
    def _normalize_tzinfo(tzinfo: Union[str, pytz.BaseTzInfo]) -> pytz.BaseTzInfo:
        """
        Normaliza la zona horaria a una instancia de pytz.
        """
        if isinstance(tzinfo, str):
            return pytz.timezone(tzinfo)
        if isinstance(tzinfo, pytz.BaseTzInfo):
            return tzinfo
        raise TypeError("tzinfo must be a string or pytz.timezone object")

    # ----------------- Conversiones -----------------

    def to_datetime(self) -> datetime:
        """
        Retorna la apertura de la vela como datetime en la zona horaria configurada.
        """
        dt_utc = datetime.fromtimestamp(self.open // 1000, tz=timezone.utc)
        return dt_utc.astimezone(self.tzinfo)

    def to_pandas_timestamp(self) -> pd.Timestamp:
        """
        Retorna la apertura de la vela como pandas.Timestamp en la zona horaria configurada.
        """
        ts_utc = pd.Timestamp(self.open, unit="ms", tz="UTC")
        ts_local = ts_utc.tz_convert(self.tzinfo)

        if pd.isna(ts_local):
            raise ValueError("Unexpected NaT in to_pandas_timestamp()")

        return cast(pd.Timestamp, ts_local)

    # ----------------- Variaciones inmutables -----------------

    def with_timezone(self, tzinfo: Union[str, pytz.BaseTzInfo]) -> KlineTimestamp:
        """
        Devuelve una nueva instancia con zona horaria actualizada.
        """
        return KlineTimestamp(self.timestamp_ms, self.interval, tzinfo)

    def with_interval(self, new_interval: str) -> KlineTimestamp:
        """
        Devuelve una nueva instancia con intervalo actualizado.
        """
        return KlineTimestamp(self.timestamp_ms, new_interval, self.tzinfo)

    # ----------------- Navegación entre velas -----------------

    def next(self) -> KlineTimestamp:
        """Retorna la siguiente vela (kline) contigua en el mismo intervalo."""
        if self.interval == "1M":
            dt = datetime.fromtimestamp(self.open // 1000, tz=timezone.utc)
            y, m = (dt.year + 1, 1) if dt.month == 12 else (dt.year, dt.month + 1)
            next_ms = calendar.timegm(datetime(y, m, 1, tzinfo=timezone.utc).timetuple()) * 1000
            return KlineTimestamp(next_ms, "1M", self.tzinfo)
        return KlineTimestamp(self.open + self.tick_ms, self.interval, self.tzinfo)

    def prev(self) -> KlineTimestamp:
        """Retorna la vela (kline) inmediatamente anterior en el mismo intervalo."""
        if self.interval == "1M":
            dt = datetime.fromtimestamp(self.open // 1000, tz=timezone.utc)
            y, m = (dt.year - 1, 12) if dt.month == 1 else (dt.year, dt.month - 1)
            prev_ms = calendar.timegm(datetime(y, m, 1, tzinfo=timezone.utc).timetuple()) * 1000
            return KlineTimestamp(prev_ms, "1M", self.tzinfo)
        return KlineTimestamp(self.open - self.tick_ms, self.interval, self.tzinfo)

    # ----------------- Representación -----------------

    def __str__(self) -> str:
        return (
            f"KlineTimestamp(open={self.to_datetime().isoformat()}, "
            f"interval='{self.interval}', tz='{self.tzinfo.zone}')"
        )

    # ----------------- Igualdad / orden / hash -----------------

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return (self.open, self.tick_ms) == (other.open, other.tick_ms)

    def __hash__(self) -> int:
        return hash((self.open, self.tick_ms))

    def _cmp_key(self) -> tuple[int, int]:
        """
        Clave de comparacion: orden lexicografico por (open, tick_ms).
        """
        return self.open, self.tick_ms

    def __lt__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() < other._cmp_key()

    def __le__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() <= other._cmp_key()

    def __gt__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() > other._cmp_key()

    def __ge__(self, other: KlineTimestamp) -> bool:
        if not isinstance(other, KlineTimestamp):
            return NotImplemented
        return self._cmp_key() >= other._cmp_key()

    # ----------------- Operadores aritméticos -----------------

    def __add__(self, other: timedelta) -> KlineTimestamp:
        """
        Desplaza el instante base `timestamp_ms` hacia adelante un timedelta.

        No se permite sumar dos KlineTimestamp entre sí.
        """
        if not isinstance(other, timedelta):
            raise TypeError(
                f"Unsupported type for +: 'KlineTimestamp' and '{type(other).__name__}'"
            )
        new_timestamp_ms = self.timestamp_ms + int(other.total_seconds() * 1000)
        return KlineTimestamp(new_timestamp_ms, self.interval, self.tzinfo)

    def __radd__(self, other: timedelta) -> KlineTimestamp:
        """
        Soporta `timedelta + KlineTimestamp`.
        """
        return self.__add__(other)

    def __sub__(self, other: Union[timedelta, KlineTimestamp]) -> Union[KlineTimestamp, timedelta]:
        """
        Resta un timedelta (devuelve nueva KlineTimestamp) o
        resta otra KlineTimestamp (devuelve timedelta entre opens).
        """
        if isinstance(other, timedelta):
            new_timestamp_ms = self.timestamp_ms - int(other.total_seconds() * 1000)
            return KlineTimestamp(new_timestamp_ms, self.interval, self.tzinfo)
        if isinstance(other, KlineTimestamp):
            diff_ms = self.open - other.open
            return timedelta(milliseconds=diff_ms)
        raise TypeError(
            f"Unsupported type for -: 'KlineTimestamp' and '{type(other).__name__}'"
        )


if __name__ == "__main__":
    # Ejemplo rápido de uso manual
    from datetime import timedelta as _td

    kt = KlineTimestamp(timestamp_ms=1633036800000, interval="1h", tzinfo="Europe/Madrid")

    print(f"Open timestamp (ms): {kt.open}")
    print(f"Close timestamp (ms): {kt.close}")
    print(f"Datetime local: {kt.to_datetime()}")
    print(f"Pandas Timestamp: {kt.to_pandas_timestamp()}")

    kt_utc = kt.with_timezone("UTC")
    print(f"Same kline in UTC: {kt_utc}")

    kt_next = kt.next()
    kt_prev = kt.prev()
    print(f"Next candle: {kt_next.to_datetime()}")
    print(f"Previous candle: {kt_prev.to_datetime()}")

    # Ordenación
    klines = [kt_next, kt_prev, kt]
    print("Sorted:", sorted(klines))

    # Aritmética con timedelta
    kt_plus = kt + _td(minutes=30)
    kt_minus = kt - _td(minutes=30)
    print(f"+30 min: {kt_plus.to_datetime()}")
    print(f"-30 min: {kt_minus.to_datetime()}")
