from pathlib import Path

from setuptools import find_packages, setup

# Directorio raíz del proyecto (donde está este setup.py)
this_directory = Path(__file__).parent

# README.md para la descripción larga de PyPI
readme_path = this_directory / "README.md"
with open(readme_path, "r", encoding="utf-8") as fh:
    long_description = fh.read()

# requirements.txt para dependencias en tiempo de instalación
requirements_path = this_directory / "requirements.txt"
with open(requirements_path, encoding="utf-8") as f:
    required_packages = f.read().splitlines()

setup(
    name="kline_timestamp",
    version="0.3.0",  # 1M mensual, bugfixes eq/hash/sub, validacion timestamp_ms
    author="nand0san",
    author_email="",
    description=(
        "KlineTimestamp is a Python library designed to efficiently handle "
        "timestamps within discrete time intervals (klines/candlesticks), "
        "commonly used in financial data analysis."
    ),
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/nand0san/kline_timestamp",
    packages=find_packages(),
    include_package_data=True,  # Respeta MANIFEST.in para incluir LICENSE, README, etc.
    install_requires=required_packages,
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3 :: Only",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Office/Business :: Financial :: Investment",
        "Typing :: Typed",
    ],
    python_requires=">=3.9",  # Alineado con pandas 2.3.x y Python 3.12
    exclude_package_data={"": ["*.ipynb", "*.ipynb_checkpoints/*"]},
)
