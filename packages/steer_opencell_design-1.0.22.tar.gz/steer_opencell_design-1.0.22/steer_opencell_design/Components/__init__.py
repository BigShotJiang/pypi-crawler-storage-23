"""Battery cell components including electrodes, separators, current collectors, and containers."""
