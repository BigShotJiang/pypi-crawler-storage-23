"""Complete battery cell definitions for cylindrical, prismatic, pouch, and flex-frame formats."""
