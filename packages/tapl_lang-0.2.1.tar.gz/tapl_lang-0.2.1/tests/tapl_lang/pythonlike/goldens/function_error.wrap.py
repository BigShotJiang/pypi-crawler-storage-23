try:
    import function_error1
except Exception as e:
    print(e)