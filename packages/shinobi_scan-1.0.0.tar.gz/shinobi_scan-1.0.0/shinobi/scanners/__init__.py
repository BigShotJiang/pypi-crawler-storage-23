"""Shinobi security scanners."""
