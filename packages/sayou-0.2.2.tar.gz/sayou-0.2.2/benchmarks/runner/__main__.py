"""Allow running as: python -m benchmarks.runner.cli"""

from benchmarks.runner.cli import main

main()
