# MCP Directory Submissions

Ready-to-submit descriptions for major MCP directories.

## pulsemcp.com

**Name:** sayou
**Category:** Developer Tools / Storage
**Short description (160 chars):**
Persistent workspace memory for AI agents. Files with versioning, frontmatter metadata, full-text search. Zero-config local setup.

**Description:**
Sayou gives AI agents persistent file-based memory across sessions. Write files with YAML frontmatter metadata, search by content or metadata, track version history, and build knowledge graphs. Works with Claude Code, Cursor, and any MCP client. Zero configuration — pip install and go.

## mcp.so

**Name:** sayou
**One-liner:** Persistent workspace memory for AI agents
**Tags:** storage, memory, workspace, versioning, search

## awesome-mcp-servers (GitHub)

**PR title:** Add sayou — persistent workspace memory
**Description:**
- **sayou** - Persistent file workspace with versioning, frontmatter metadata, full-text search, and knowledge graphs. Zero-config local setup with SQLite.

## mcpservers.org

**Name:** sayou
**Category:** Storage & Memory
**Description:** File-based persistent memory for AI agents with automatic versioning, YAML frontmatter metadata, full-text search, and knowledge graphs. Zero configuration required.

## Common Links

- **Repository:** https://github.com/pixell-global/sayou
- **PyPI:** https://pypi.org/project/sayou/
- **Install:** `pip install sayou`
