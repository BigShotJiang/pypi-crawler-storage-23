"""Agent loop — multi-turn LLM with tool execution."""
