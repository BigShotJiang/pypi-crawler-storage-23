"""E2B sandbox execution."""
