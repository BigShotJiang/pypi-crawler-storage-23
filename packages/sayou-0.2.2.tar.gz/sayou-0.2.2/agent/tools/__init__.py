"""Agent tools — workspace, web search, sandbox executors."""
