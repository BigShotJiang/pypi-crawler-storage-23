"""Tool executor implementations."""
