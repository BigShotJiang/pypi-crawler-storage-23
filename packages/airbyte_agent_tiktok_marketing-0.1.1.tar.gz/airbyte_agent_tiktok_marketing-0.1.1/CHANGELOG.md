# Tiktok Marketing changelog

## [0.1.1] - 2026-02-18
- Updated connector definition (YAML version 1.0.2)
- Source commit: 0186dbc7
- SDK version: 0.1.0

## [0.1.0] - 2026-02-18
- Updated connector definition (YAML version 1.0.1)
- Source commit: c68d41e9
- SDK version: 0.1.0
