from __future__ import annotations

"""
RemoteServer：宿主机通信服务器。

- 监听指定 TCP 端口，接受来自 RemoteSerialCore 的连接；
- 本模块直接实现服务端协议与串口管理逻辑；
- 作为对象封装，便于在代码中以编程方式启动/管理 server。
"""

from typing import List

from loguru import logger

from ..base.serial_core import SerialCore, scan_serial_ports, check_port_alive_nonblock


def _handle_list(conn, addr) -> None:
    """
    处理 list 请求：并行非阻塞探测各 demoboard 串口，返回 boards 列表。
    每个串口在独立线程中执行 check_port_alive_nonblock（内部带串口锁）。
    """
    import json
    from concurrent.futures import ThreadPoolExecutor, as_completed

    ports = scan_serial_ports()
    logger.info(f"[server] list request from {addr}, ports={ports}")
    boards = []

    if not ports:
        conn.sendall(json.dumps({"boards": boards}, ensure_ascii=False).encode("utf-8") + b"\n")
        return

    def _probe(port: str):
        return check_port_alive_nonblock(port, timeout=1.5)

    max_workers = min(8, len(ports))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(_probe, p): p for p in ports}
        for fut in as_completed(future_map):
            result = fut.result()
            boards.append(
                {
                    "port": result["port"],
                    "baudrate": result["baudrate"],
                    "available": result["available"],
                    "reason": result.get("reason", ""),
                }
            )

    conn.sendall(json.dumps({"boards": boards}, ensure_ascii=False).encode("utf-8") + b"\n")


def _handle_probe(conn, init: dict, addr) -> None:
    """
    处理 probe 请求：对指定串口执行非阻塞检查，用于 sdev remote activate。
    init: {"cmd": "probe", "port": "...", "baudrate": int}
    """
    import json

    port = (init.get("port") or "").strip()
    baudrate = int(init.get("baudrate") or 115200)
    if not port:
        conn.sendall(b'{"ok":false,"error":"missing port"}\n')
        return
    logger.info(f"[server] probe request from {addr}: port={port}, baudrate={baudrate}")
    result = check_port_alive_nonblock(port, baudrate=baudrate, timeout=1.5)
    payload = json.dumps({"ok": True, "result": result}, ensure_ascii=False).encode("utf-8") + b"\n"
    conn.sendall(payload)


def _discovery_loop(udp_sock, service_port: int) -> None:
    """
    UDP 发现线程：
    - 监听固定端口上的探测报文 "SDEV_DISCOVERY"；
    - 收到后向请求方回发 {"host": ip, "port": service_port}。
    """
    import json

    while True:
        try:
            data, addr = udp_sock.recvfrom(4096)
        except OSError:
            break
        if not data:
            continue
        msg = data.strip()
        if msg != b"SDEV_DISCOVERY":
            continue
        logger.info(f"[server] discovery ping from {addr}, respond with port={service_port}")
        # 回传固定 magic + TCP 服务端口，便于客户端甄别非 sdev 的 UDP 应答。
        resp = json.dumps(
            {
                "magic": "sdev-remote-v1",
                "port": service_port,
            },
            ensure_ascii=False,
        ).encode("utf-8")
        try:
            udp_sock.sendto(resp, addr)
        except OSError:
            continue


def _get_server_log_path() -> str:
    """
    server.log 路径计算逻辑，与 CLI 侧保持一致：
    默认 ~/.cache/sdev/server.log 或 XDG_RUNTIME_DIR/sdev/server.log。
    """
    import os

    base = os.environ.get("XDG_RUNTIME_DIR") or os.path.join(os.path.expanduser("~"), ".cache")
    log_dir = os.path.join(base, "sdev")
    os.makedirs(log_dir, mode=0o700, exist_ok=True)
    return os.path.join(log_dir, "server.log")


def _setup_logging() -> None:
    """
    配置 loguru 日志输出到 server.log，并限制最大大小：
    - 单个日志文件按 1 MiB 自动轮转；
    - 保留若干历史文件，避免无限增长。
    """
    import os

    log_path = _get_server_log_path()
    # 确保目录存在（_get_server_log_path 已处理），这里冗余一次也无妨。
    os.makedirs(os.path.dirname(log_path) or ".", exist_ok=True)

    # 移除默认 stderr sink，避免重复输出。
    logger.remove()
    logger.add(
        log_path,
        rotation="1 MB",  # 单文件约 1 MiB 时自动轮转
        retention=5,  # 最多保留 5 个历史文件
        encoding="utf-8",
        enqueue=True,
        backtrace=False,
        diagnose=False,
    )


def _handle(conn, addr):
    import json

    dev: SerialCore | None = None
    try:
        buf = b""
        while b"\n" not in buf:
            chunk = conn.recv(4096)
            if not chunk:
                return
            buf += chunk
        line = buf.split(b"\n", 1)[0].decode("utf-8")
        try:
            init = json.loads(line)
        except json.JSONDecodeError:
            conn.sendall(b'{"ok":false,"error":"invalid json"}\n')
            return
        if isinstance(init, dict) and init.get("cmd") == "list":
            _handle_list(conn, addr)
            return
        if isinstance(init, dict) and init.get("cmd") == "probe":
            _handle_probe(conn, init, addr)
            return
        port = init.get("port") or ""
        baudrate = int(init.get("baudrate") or 115200)
        if not port:
            conn.sendall(b'{"ok":false,"error":"missing port"}\n')
            return
        logger.info(f"[server] open session from {addr}: port={port}, baudrate={baudrate}")
        dev = SerialCore(port, baudrate)
        try:
            dev.connect()
        except Exception as e:
            conn.sendall(json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False).encode("utf-8") + b"\n")
            dev = None
            return
        conn.sendall(b'{"ok":true}\n')
        buf = b""
        while True:
            try:
                chunk = conn.recv(4096)
            except (ConnectionResetError, BrokenPipeError, OSError):
                break
            if not chunk:
                break
            buf += chunk
            while b"\n" in buf:
                msg_b, buf = buf.split(b"\n", 1)
                msg = msg_b.decode("utf-8", errors="replace").strip()
                if not msg:
                    continue
                try:
                    obj = json.loads(msg)
                except json.JSONDecodeError:
                    continue
                cmd = (obj or {}).get("cmd")
                if cmd == "disconnect":
                    # 主动断开：交由 finally 中统一释放资源
                    return
                if cmd == "send":
                    data = (obj.get("data") or "").strip()
                    if data:
                        dev.send(data)
                    continue
                if cmd == "scan":
                    timeout = obj.get("timeout")
                    end_flag = obj.get("end_flag")
                    replace_with_acc = bool(obj.get("replace_with_acc"))
                    try:
                        for line_out in dev.scan(end_flag=end_flag, timeout=timeout, replace_with_acc=replace_with_acc):
                            conn.sendall(
                                json.dumps({"line": line_out}, ensure_ascii=False).encode("utf-8") + b"\n"
                            )
                    except TimeoutError:
                        pass
                    conn.sendall(b'{"scan_done":true}\n')
                    continue
                if cmd == "clear":
                    dev.clear()
    finally:
        # 确保无论客户端是否正确发送 disconnect，都能关闭串口与后台线程。
        if dev is not None:
            try:
                dev.disconnect()
            except Exception:
                pass
        try:
            conn.close()
        except Exception:
            pass


class RemoteServer:
    """
    远程串口服务端封装。

    封装 TCP/UDP 监听逻辑，供 CLI 或其他代码直接启动。
    """

    def __init__(self, port: int = 7000):
        self.port = port
        # 保留 zeroconf 对象引用，避免被 GC 提前释放
        self._zeroconf = None
        self._zeroconf_info = None

    def _start_zeroconf(self) -> None:
        """
        通过 zeroconf(mDNS) 发布 sdev server 服务，便于在不支持 UDP 广播的环境中发现。
        失败时静默降级，不影响主流程。
        """
        try:
            import socket
            from zeroconf import IPVersion, ServiceInfo, Zeroconf
        except Exception as e:  # pragma: no cover - 依赖缺失时直接跳过
            logger.warning(f"[server] zeroconf unavailable, skip mDNS advertise: {e}")
            return

        try:
            host_ip = socket.gethostbyname(socket.gethostname())
        except OSError:
            # 回退到本地回环地址，至少不会报错；client 侧会同时使用 UDP 发现。
            host_ip = "127.0.0.1"

        service_type = "_sdev._tcp.local."
        service_name = f"sdev-{host_ip}-{self.port}.{service_type}"

        try:
            info = ServiceInfo(
                type_=service_type,
                name=service_name,
                addresses=[socket.inet_aton(host_ip)],
                port=self.port,
                properties={},
            )
            zc = Zeroconf(ip_version=IPVersion.V4Only)
            zc.register_service(info)
        except Exception as e:  # pragma: no cover - mDNS 故障时直接降级
            logger.warning(f"[server] zeroconf advertise failed: {e}")
            return

        self._zeroconf = zc
        self._zeroconf_info = info
        logger.info(f"[server] zeroconf advertised as {service_name} ({host_ip}:{self.port})")

    def serve_forever(self) -> int:
        import socket
        import threading

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.port))
        sock.listen(5)

        udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        udp_sock.bind(("0.0.0.0", 7001))
        threading.Thread(target=_discovery_loop, args=(udp_sock, self.port), daemon=True).start()

        # 通过 zeroconf 发布服务，作为 UDP discovery 的补充通道。
        self._start_zeroconf()

        logger.info(f"[server] listening on 0.0.0.0:{self.port} (TCP) and 0.0.0.0:7001 (UDP discovery)")
        while True:
            conn, addr = sock.accept()
            logger.info(f"[server] new TCP connection from {addr}")
            threading.Thread(target=_handle, args=(conn, addr), daemon=True).start()


def main() -> int:
    """
    作为 `python -m sdev.remote.server` 的入口。
    """
    import sys

    # 在解析参数后立即配置日志，保证后续日志都写入带大小限制的 server.log。
    port: int = 7000
    if len(sys.argv) > 1:
        try:
            port = int(sys.argv[1])
        except ValueError:
            pass

    _setup_logging()
    server = RemoteServer(port=port)
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

