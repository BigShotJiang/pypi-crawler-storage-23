from __future__ import annotations

"""
RemoteSerialCore：基于宿主机之间通信协议的远程串口核心客户端（纯 IO 层）。

- 通过 TCP 连接远端 sdev server；
- 在远端主机上由 SerialCore 控制物理串口；
- 本地仅负责发送 JSON 命令并接收行流；
- 不包含日志/显示接口，由上层 Demoboard / CLI 决定是否记录日志。
"""

import json
import queue
import socket
import threading
import time
from typing import Any, Generator, Iterable, Optional

_SCAN_DONE = object()


class RemoteSerialCore:
    """
    远程串口核心：
    - 接口尽量与 SerialCore 对齐：connect / disconnect / send / scan / clear；
    - 内部直接实现与远端 server 的 JSON 协议。
    """

    def __init__(
        self,
        host: str,
        port: str,
        baudrate: int = 115200,
        service_port: int = 7000,
    ):
        self.port = port
        self.baudrate = baudrate
        self._host = host
        self._service_port = service_port
        self._socket: Optional[socket.socket] = None
        self._buffer: queue.Queue = queue.Queue()
        self._reader_thread: Optional[threading.Thread] = None
        self._is_connected = False
        self._stop_reading = False
        self._scan_timeout = 0.1
        self._max_lines_per_prompt = 4

    # --- 底层 TCP 收发 ---

    def _read_loop(self) -> None:
        buf = b""
        while not self._stop_reading and self._socket is not None:
            try:
                data = self._socket.recv(4096)
            except (OSError, ConnectionResetError, BrokenPipeError):
                break
            if not data:
                break
            buf += data
            while b"\n" in buf or (buf and self._stop_reading):
                if b"\n" not in buf:
                    break
                line_b, buf = buf.split(b"\n", 1)
                line = line_b.decode("utf-8", errors="replace").strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    if "line" in obj:
                        self._buffer.put(obj["line"])
                    elif obj.get("scan_done") is True:
                        self._buffer.put(_SCAN_DONE)
        self._buffer.put(_SCAN_DONE)

    def _send_cmd(self, obj: dict[str, Any]) -> None:
        if self._socket is None:
            raise RuntimeError("not connected")
        msg = json.dumps(obj, ensure_ascii=False) + "\n"
        self._socket.sendall(msg.encode("utf-8"))

    # --- SerialCore 接口实现 ---

    def connect(self) -> None:
        if self._is_connected:
            return
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(10.0)
        try:
            sock.connect((self._host, self._service_port))
        except OSError as e:
            raise RuntimeError(f"无法连接 {self._host}:{self._service_port}: {e}") from e

        init_msg = json.dumps({"port": self.port, "baudrate": self.baudrate}, ensure_ascii=False) + "\n"
        sock.sendall(init_msg.encode("utf-8"))

        sock.settimeout(5.0)
        raw = b""
        while b"\n" not in raw:
            try:
                chunk = sock.recv(4096)
            except socket.timeout:
                sock.close()
                raise RuntimeError("等待 host 初始化超时") from None
            if not chunk:
                sock.close()
                raise RuntimeError("host 关闭连接") from None
            raw += chunk

        line = raw.split(b"\n", 1)[0].decode("utf-8")
        try:
            resp = json.loads(line)
        except json.JSONDecodeError:
            sock.close()
            raise RuntimeError("host 返回无效 JSON") from None
        if resp.get("ok") is not True:
            sock.close()
            raise RuntimeError(resp.get("error", "host 拒绝连接"))

        self._socket = sock
        self._socket.settimeout(self._scan_timeout)
        self._stop_reading = False
        self._reader_thread = threading.Thread(target=self._read_loop, daemon=True)
        self._reader_thread.start()
        self._is_connected = True

    def disconnect(self) -> None:
        if not self._is_connected:
            return
        self._stop_reading = True
        try:
            self._send_cmd({"cmd": "disconnect"})
        except Exception:
            pass
        if self._reader_thread is not None and self._reader_thread.is_alive():
            self._reader_thread.join(timeout=2.0)
        self._reader_thread = None
        if self._socket is not None:
            try:
                self._socket.close()
            except Exception:
                pass
            self._socket = None
        self._is_connected = False

    def __enter__(self) -> "RemoteSerialCore":
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.disconnect()

    def send(self, cmd: str) -> None:
        self._send_cmd({"cmd": "send", "data": cmd})

    def _drain_scan_buffer(self) -> None:
        while True:
            try:
                item = self._buffer.get_nowait()
                if item is _SCAN_DONE:
                    break
            except queue.Empty:
                break

    def _scan_raw(self, timeout: Optional[float] = None) -> Generator[str, None, None]:
        if not self._is_connected:
            raise RuntimeError("not connected")
        self._drain_scan_buffer()
        self._send_cmd(
            {
                "cmd": "scan",
                "timeout": timeout,
                "end_flag": None,
                "replace_with_acc": False,
            }
        )
        deadline = (time.monotonic() + timeout) if timeout else None
        while True:
            try:
                remaining = (deadline - time.monotonic()) if deadline else None
                if remaining is not None and remaining <= 0:
                    raise TimeoutError("scan deadline exceeded (no response)")
                item = self._buffer.get(timeout=remaining if remaining else 0.5)
            except queue.Empty:
                if deadline and time.monotonic() >= deadline:
                    raise TimeoutError("scan deadline exceeded (no response)")
                continue
            if item is _SCAN_DONE:
                return
            yield item

    def scan(
        self,
        end_flag: Optional[str],
        timeout: Optional[float] = None,
        replace_with_acc: bool = False,
    ) -> Generator[str, None, None]:
        if not self._is_connected:
            raise RuntimeError("not connected")
        self._drain_scan_buffer()

        # end_flag 语义与 SerialCore.scan 对齐：
        # - end_flag is None：仅根据超时结束扫描，超时不抛异常（用于非阻塞探测）；
        # - end_flag 非 None：超时视为错误，抛出 TimeoutError 交由上层处理。
        if end_flag is None:
            self._send_cmd(
                {
                    "cmd": "scan",
                    "timeout": timeout,
                    "end_flag": None,
                    "replace_with_acc": False,
                }
            )
            try:
                for item in self._scan_raw(timeout):
                    yield item
            except TimeoutError:
                return
        else:
            self._send_cmd(
                {
                    "cmd": "scan",
                    "timeout": timeout,
                    "end_flag": end_flag,
                    "replace_with_acc": replace_with_acc,
                }
            )
            deadline = (time.monotonic() + timeout) if timeout else None
            while True:
                try:
                    remaining = (deadline - time.monotonic()) if deadline else None
                    if remaining is not None and remaining <= 0:
                        raise TimeoutError("scan deadline exceeded (no response)")
                    item = self._buffer.get(timeout=remaining if remaining else 0.5)
                except queue.Empty:
                    if deadline and time.monotonic() >= deadline:
                        raise TimeoutError("scan deadline exceeded (no response)")
                    continue
                if item is _SCAN_DONE:
                    return
                yield item

    def clear(self) -> None:
        self._drain_scan_buffer()
        self._send_cmd({"cmd": "clear"})

__all__ = ["RemoteSerialCore"]

