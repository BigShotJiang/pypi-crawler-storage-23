from __future__ import annotations

"""
远程串口子包：

- client.RemoteSerialCore：远程串口核心客户端；
- server.RemoteServer：远程串口服务端；
- discovery：远程 host 发现与 demoboard 列表/激活记录管理。
"""

from .client import RemoteSerialCore
from .server import RemoteServer
from . import discovery

__all__ = ["RemoteSerialCore", "RemoteServer", "discovery"]

