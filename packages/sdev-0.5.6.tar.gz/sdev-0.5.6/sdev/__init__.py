"""
SDEV - 串口控制器工具包

- Demoboard：统一封装本地与远程串口交互的新模型；
- sdev() 工厂方法：快速构建设备实例。
"""

from __future__ import annotations

from .models import Demoboard

__version__ = "0.5.6"
__author__ = "klrc"
__email__ = "1440698245@qq.com"


def sdev(port: str, baudrate: int = 115200, **kwargs):
    """构造 Demoboard 设备实例。"""
    return Demoboard(port, baudrate, **kwargs)


__all__ = ["Demoboard", "sdev"]
