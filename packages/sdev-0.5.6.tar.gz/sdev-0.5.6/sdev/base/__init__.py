from __future__ import annotations

"""
基础串口与远程通信模块聚合：

- SerialCore：本地串口核心读写封装；
- RemoteSerialCore：基于 TCP 协议的远程串口核心；
- RemoteServer：远程宿主机上的串口服务端。

提示：Demoboard 设备模型已迁移至 sdev.models.Demoboard。
"""

from .serial_core import SerialCore
from ..remote.client import RemoteSerialCore
from ..remote.server import RemoteServer

__all__ = [
    "SerialCore",
    "RemoteSerialCore",
    "RemoteServer",
]

