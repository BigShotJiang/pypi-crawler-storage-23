from __future__ import annotations

"""
模型层入口：

- Demoboard：统一封装本地与远程串口交互，基于 SerialCore / RemoteSerialCore。
"""

from .demoboard import Demoboard

__all__ = ["Demoboard"]

