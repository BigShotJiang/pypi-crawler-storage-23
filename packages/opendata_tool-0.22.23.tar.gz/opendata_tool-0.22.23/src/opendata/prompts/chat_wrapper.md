{context}

RECENT CONVERSATION HISTORY:
{history}

LATEST USER INPUT:
{user_input}

INSTRUCTION: 
Respond to the user. Maintain the existing metadata draft in your reasoning.
Identify all missing or ambiguous fields and ask questions for all of them at once in the structured ANALYSIS block.
If the user confirmed using a file for metadata extraction, the system should process it.
If the user asks to search for something (like an ORCID), use the tools provided.
