"""Ollama provider package."""

from thryve.providers.ollama.provider import OllamaProvider
from thryve.providers.ollama.param import OllamaProviderParam

__all__ = ["OllamaProvider", "OllamaProviderParam"]
