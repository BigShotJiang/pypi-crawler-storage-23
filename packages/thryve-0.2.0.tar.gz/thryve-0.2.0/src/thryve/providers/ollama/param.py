"""Ollama provider parameters."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from thryve.providers.param import BaseProviderParam


@dataclass
class OllamaProviderParam(BaseProviderParam):
    """Parameters specific to the Ollama provider."""

    model: str = "llama3"
    base_url: str = "http://localhost:11434"
    temperature: float = 0.7
    max_tokens: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)
