"""Provider subsystem – register all known providers on import."""

from thryve.providers.base import Provider
from thryve.providers.factory import ProviderFactory
from thryve.providers.llama_capp import LlamaCappProvider, LlamaCappProviderParam
from thryve.providers.ollama import OllamaProvider, OllamaProviderParam
from thryve.providers.openai import OpenAIProvider, OpenAIProviderParam
from thryve.providers.transformers import TransformersProvider, TransformersProviderParam

# Register providers (explicit, no file scanning – per DESIGN.md)
ProviderFactory.register("openai", OpenAIProvider, OpenAIProviderParam)
ProviderFactory.register("ollama", OllamaProvider, OllamaProviderParam)
ProviderFactory.register("llama_capp", LlamaCappProvider, LlamaCappProviderParam)
ProviderFactory.register("transformers", TransformersProvider, TransformersProviderParam)

__all__ = [
    "Provider",
    "ProviderFactory",
    "OpenAIProvider",
    "OpenAIProviderParam",
    "OllamaProvider",
    "OllamaProviderParam",
    "LlamaCappProvider",
    "LlamaCappProviderParam",
    "TransformersProvider",
    "TransformersProviderParam",
]
