"""Thryve configuration schema — single source of truth."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class ModelConfig(BaseModel):
    """Capability declaration for a specific model.

    ``role`` distinguishes how the model is used in the pipeline:

    - ``"chat"``  — conversational / instruction-following (default)
    - ``"embed"`` — embedding / vector representation only

    OCR and rerank roles are reserved for future use.
    """

    id: str
    role: Literal["chat", "embed"] = "chat"
    vision: bool = False
    tool: bool = True
    level: str = "medium"


class ProviderConfig(BaseModel):
    """Any OpenAI-compatible LLM provider."""

    base_url: str
    api_key: str = ""
    temperature: float | None = None
    max_tokens: int | None = None
    models: list[str | ModelConfig] = Field(default_factory=list)


class RoutingRule(BaseModel):
    """Single routing rule matching user input to a model level."""

    keywords: list[str] = Field(default_factory=list)
    min_length: int | None = None
    max_length: int | None = None
    level: str = "medium"
    priority: int = 0


class RoutingConfig(BaseModel):
    """Model routing configuration."""

    auto: bool = False
    rules: list[RoutingRule] = Field(default_factory=list)


class ToolModelsConfig(BaseModel):
    """Explicit assignments for non-chat tool models.

    Each field accepts a ``"provider/model"`` reference string, identical in
    format to ``agent.model``.  When set, this takes precedence over
    auto-discovery via ``ModelConfig.role``.

    Example::

        tool_models:
          embed: "openai/text-embedding-3-small"
          ocr: "easyocr/default"    # Phase 1.4
    """

    embed: str | None = None
    ocr: str | None = None    # reserved for Phase 1.4
    rerank: str | None = None  # reserved for future use


class AgentConfig(BaseModel):
    """Agent behaviour settings."""

    model: str = "ollama/qwen3"
    max_tokens: int = 8192
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tool_iterations: int = 20


class MemoryConfig(BaseModel):
    """Memory subsystem settings."""

    model_config = ConfigDict(extra="forbid")

    storage_path: str = "~/.thryve/data/memory.db"
    markdown_path: str = "~/.thryve/data/memory"
    short_term_retention_days: int = Field(default=7, ge=1)
    enable_fts: bool = True


class ContextBlocksConfig(BaseModel):
    """Per-block token budgets for the context window.

    Each value is a hard upper limit in tokens.  When ``None``, the budget
    is computed automatically from ``ContextConfig.max_tokens`` using
    built-in default ratios (system 15%, memory 20%, conversation 50%,
    user_input 15%).
    """

    system_identity: int | None = None
    memory: int | None = None
    conversation: int | None = None
    user_input: int | None = None


class ContextCompressionConfig(BaseModel):
    """Strategy-specific knobs for context compression."""

    recent_keep: int = Field(default=4, ge=1)
    extract_threshold: int = Field(default=2, ge=0)


class ContextConfig(BaseModel):
    """Context window management."""

    max_tokens: int = Field(default=8000, ge=1)
    compression: str = "truncate"
    blocks: ContextBlocksConfig = Field(default_factory=ContextBlocksConfig)
    compression_config: ContextCompressionConfig = Field(
        default_factory=ContextCompressionConfig,
    )


class MultimodalConfig(BaseModel):
    """Multimodal (VLM) limits and behaviour."""

    max_images: int = Field(default=10, ge=1)
    max_file_size_mb: float = Field(default=20.0, gt=0)


class Config(BaseSettings):
    """Root configuration for the Thryve framework.

    Supports environment variables prefixed with ``THRYVE_`` and nested
    delimiter ``__``.  Example: ``THRYVE_AGENT__TEMPERATURE=0.5``.
    """

    model_config = SettingsConfigDict(
        env_prefix="THRYVE_",
        env_nested_delimiter="__",
        extra="ignore",
    )

    agent: AgentConfig = Field(default_factory=AgentConfig)
    providers: dict[str, ProviderConfig] = Field(default_factory=dict)
    memory: MemoryConfig = Field(default_factory=MemoryConfig)
    context: ContextConfig = Field(default_factory=ContextConfig)
    routing: RoutingConfig = Field(default_factory=RoutingConfig)
    tool_models: ToolModelsConfig = Field(default_factory=ToolModelsConfig)
    multimodal: MultimodalConfig = Field(default_factory=MultimodalConfig)

    @classmethod
    def from_env(cls) -> Config:
        """Load config from environment variables (THRYVE_*)."""
        return cls()

    @classmethod
    def from_file(cls, path: str | Path) -> Config:
        """Load config from a YAML/JSON file. See :func:`thryve.config.load_config`."""
        from thryve.config.loader import load_config
        return load_config(path)
