"""Thryve – a modular framework for multi-LLM agents, tools, and workflows."""

__version__ = "0.2.0"
__author__ = "SyJarvis"
__url__ = "https://github.com/SyJarvis/thryve"

from thryve.config import (
    AgentConfig,
    Config,
    ContextConfig,
    MemoryConfig,
    ModelConfig,
    MultimodalConfig,
    ProviderConfig,
    RoutingConfig,
    RoutingRule,
    load_config,
)

# README / docs use ThryveConfig; keep alias for compatibility.
ThryveConfig = Config
from thryve.agent import Agent, AgentLoop, LoopConfig, MultiAgentOrchestrator, StopReason, TurnResult
from thryve.providers.adapter import ProviderAdapter
from thryve.context import (
    ChatResponse,
    ContextManager,
    ImagePart,
    Message,
    TextPart,
    ToolCall,
    ToolResult,
)
from thryve.graph import Graph, GraphExecutor, FunctionNode, LLMNode, AgentNode, ToolNode
from thryve.memory import MarkdownStorage, MemoryChunk, MemoryManager, MemorySource, MemoryType
from thryve.multimodal import ContentInput, ContentItem, MediaProcessor, MediaSource, MediaType
from thryve.tools import Tool, ToolParameter, ToolRegistry, ToolExecutor, tool
from thryve.thryve import Thryve

__all__ = [
    # Entry point
    "Thryve",
    # Config
    "Config",
    "ThryveConfig",
    "AgentConfig",
    "ContextConfig",
    "MemoryConfig",
    "ModelConfig",
    "MultimodalConfig",
    "ProviderConfig",
    "RoutingConfig",
    "RoutingRule",
    "load_config",
    # Models
    "Message",
    "ChatResponse",
    "ImagePart",
    "TextPart",
    "ToolCall",
    "ToolResult",
    "MemoryChunk",
    "MemorySource",
    "MemoryType",
    "MarkdownStorage",
    # Multimodal
    "ContentInput",
    "ContentItem",
    "MediaProcessor",
    "MediaSource",
    "MediaType",
    # Providers
    "ProviderAdapter",
    # Tools
    "Tool",
    "ToolParameter",
    "ToolRegistry",
    "ToolExecutor",
    "tool",
    # Agent
    "Agent",
    "AgentLoop",
    "LoopConfig",
    "StopReason",
    "TurnResult",
    "MultiAgentOrchestrator",
    # Context
    "ContextManager",
    # Memory
    "MemoryManager",
    # Graph
    "Graph",
    "GraphExecutor",
    "FunctionNode",
    "LLMNode",
    "AgentNode",
    "ToolNode",
]
