"""Complexity scorer – estimates the difficulty level of a request.

Outputs one of ``"low"``, ``"medium"``, or ``"high"`` based on lightweight
heuristics that do not require a model call.  The rules are intentionally
transparent so the routing decision is always explainable.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Complexity signals
# ---------------------------------------------------------------------------

# Keywords that suggest a high-complexity (reasoning-heavy) request.
_HIGH_COMPLEXITY_KEYWORDS = frozenset([
    "debug", "error", "fix", "bug", "trace", "exception", "stacktrace",
    "analyze", "analyse", "explain", "compare", "evaluate", "optimize",
    "architecture", "design", "refactor", "review", "audit",
    "implement", "algorithm", "proof", "derive", "math", "equation",
    "why", "how does", "what is the difference",
])

# Keywords that suggest a low-complexity (quick-answer) request.
_LOW_COMPLEXITY_KEYWORDS = frozenset([
    "hello", "hi", "thanks", "thank you", "ok", "okay", "yes", "no",
    "simple", "quick", "short", "brief", "summarize briefly",
    "what is", "define", "translate",
])

# Regex patterns that add to complexity score.
_CODE_BLOCK_RE = re.compile(r"```|~~~", re.MULTILINE)
_NUMBERED_LIST_RE = re.compile(r"^\s*\d+\.", re.MULTILINE)
_BULLET_LIST_RE = re.compile(r"^\s*[-*•]", re.MULTILINE)
_CONSTRAINT_RE = re.compile(
    r"\b(must|should|need to|require|ensure|constraint|rule|condition)\b",
    re.IGNORECASE,
)


@dataclass
class ComplexityScore:
    """Detailed breakdown of the complexity assessment."""

    level: str  # "low" | "medium" | "high"
    score: float  # normalised 0-1
    reasons: list[str] = field(default_factory=list)


class ComplexityScorer:
    """Rule-based complexity scorer.

    Evaluates a text string and returns a :class:`ComplexityScore`.
    The scoring logic is:

    1. Start at 0.
    2. Add points for each signal (length, code blocks, constraints, keywords).
    3. Map final score to ``low / medium / high``.

    The thresholds can be adjusted at instantiation time.
    """

    def __init__(
        self,
        low_threshold: float = 0.25,
        high_threshold: float = 0.60,
    ) -> None:
        self._low = low_threshold
        self._high = high_threshold

    def score(self, text: str) -> ComplexityScore:
        """Score *text* and return a :class:`ComplexityScore`."""
        reasons: list[str] = []
        s = 0.0
        lower = text.lower()

        # --- Length -------------------------------------------------------
        char_len = len(text)
        if char_len > 2000:
            s += 0.30
            reasons.append(f"long text ({char_len} chars)")
        elif char_len > 500:
            s += 0.15
            reasons.append(f"medium text ({char_len} chars)")

        # --- Code blocks --------------------------------------------------
        code_blocks = len(_CODE_BLOCK_RE.findall(text)) // 2
        if code_blocks > 0:
            s += min(0.20 * code_blocks, 0.40)
            reasons.append(f"{code_blocks} code block(s)")

        # --- Numbered/bullet lists ----------------------------------------
        num_items = len(_NUMBERED_LIST_RE.findall(text)) + len(_BULLET_LIST_RE.findall(text))
        if num_items >= 3:
            s += 0.10
            reasons.append(f"{num_items} list item(s)")

        # --- Constraint keywords ------------------------------------------
        constraints = len(_CONSTRAINT_RE.findall(text))
        if constraints >= 2:
            s += min(0.05 * constraints, 0.20)
            reasons.append(f"{constraints} constraint keyword(s)")

        # --- High-complexity keyword boost --------------------------------
        matched_high = [kw for kw in _HIGH_COMPLEXITY_KEYWORDS if kw in lower]
        if matched_high:
            s += min(0.10 * len(matched_high), 0.30)
            reasons.append(f"high-complexity keywords: {matched_high[:3]}")

        # --- Low-complexity keyword penalty -------------------------------
        matched_low = [kw for kw in _LOW_COMPLEXITY_KEYWORDS if kw in lower]
        if matched_low and not matched_high:
            s -= min(0.10 * len(matched_low), 0.20)
            reasons.append(f"low-complexity keywords: {matched_low[:3]}")

        # Clamp to [0, 1]
        s = max(0.0, min(1.0, s))

        if s >= self._high:
            level = "high"
        elif s <= self._low:
            level = "low"
        else:
            level = "medium"

        return ComplexityScore(level=level, score=round(s, 3), reasons=reasons)
