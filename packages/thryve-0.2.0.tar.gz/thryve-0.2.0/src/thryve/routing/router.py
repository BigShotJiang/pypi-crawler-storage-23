"""ModelRouter – selects the most appropriate (provider, model) for a request.

Selection priority (highest to lowest):
1. Media rule: if the conversation contains images, prefer a vision-capable model.
2. Keyword rules: first rule whose keywords match the user text wins (sorted by priority desc).
3. Complexity: automatic level estimation from text features.
4. Default: the model configured in ``config.agent.model``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from thryve.config.schema import Config
    from thryve.context.models import Message


@dataclass
class ModelCandidate:
    """A single (provider, model) candidate for routing."""

    provider: str
    model_id: str
    level: str
    vision: bool = False


@dataclass
class RoutingDecision:
    """The final routing decision including fallback chain and observability info."""

    provider: str
    model_id: str
    level: str
    rule_hit: str | None  # which rule or strategy triggered this
    score: float  # complexity score if complexity routing was used
    fallbacks: list[tuple[str, str]] = field(default_factory=list)  # [(provider, model_id), ...]

    def __str__(self) -> str:
        chain = " → ".join(f"{p}/{m}" for p, m in self.fallbacks)
        fallback_info = f", fallbacks=[{chain}]" if self.fallbacks else ""
        return (
            f"RoutingDecision({self.provider}/{self.model_id}, "
            f"level={self.level}, rule={self.rule_hit!r}"
            f"{fallback_info})"
        )


class ModelRouter:
    """Stateless router: given messages and config, returns a :class:`RoutingDecision`.

    The router reads ``config.providers`` to enumerate all declared models and
    ``config.routing.rules`` for keyword rules.  It never makes network calls.
    """

    def __init__(self, config: Config) -> None:
        self._config = config
        from thryve.routing.scorer import ComplexityScorer
        self._scorer = ComplexityScorer()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def select_model(self, messages: list[Message]) -> RoutingDecision:
        """Return the routing decision for the given *messages*."""
        user_text = " ".join(m.text for m in messages if m.role in ("user", "system"))

        # 1. Media rule
        if self._has_images(messages):
            return self._select_by_capability(
                "vision", user_text, rule_hit="media:image"
            )

        # 2. Keyword rules (sorted by priority descending, ties by insertion order)
        for rule in sorted(
            self._config.routing.rules, key=lambda r: r.priority, reverse=True
        ):
            if self._matches_keyword_rule(user_text, rule):
                return self._select_by_level(
                    rule.level,
                    rule_hit=f"keyword:{rule.keywords[:2]}",
                    score=0.0,
                )

        # 3. Complexity evaluation
        result = self._scorer.score(user_text)
        return self._select_by_level(
            result.level,
            rule_hit=f"complexity:{result.reasons[:2]}",
            score=result.score,
        )

    # ------------------------------------------------------------------
    # Selection helpers
    # ------------------------------------------------------------------

    def _select_by_level(
        self, level: str, *, rule_hit: str, score: float
    ) -> RoutingDecision:
        """Find candidates matching *level*; fall back to adjacent levels."""
        candidates = self._collect_candidates_by_level(level)
        if not candidates:
            # Widen: try all candidates
            candidates = self._collect_all_candidates()
        if not candidates:
            # Last resort: use the default agent model
            return self._default_decision(rule_hit=rule_hit, score=score)

        primary = candidates[0]
        fallbacks = [(c.provider, c.model_id) for c in candidates[1:]]
        return RoutingDecision(
            provider=primary.provider,
            model_id=primary.model_id,
            level=primary.level,
            rule_hit=rule_hit,
            score=score,
            fallbacks=fallbacks,
        )

    def _select_by_capability(
        self, capability: str, text: str, *, rule_hit: str
    ) -> RoutingDecision:
        """Select a model that advertises *capability* (e.g. 'vision')."""
        if capability == "vision":
            candidates = [c for c in self._collect_all_candidates() if c.vision]
        else:
            candidates = self._collect_all_candidates()

        if not candidates:
            # Fall back to complexity-based selection
            result = self._scorer.score(text)
            return self._select_by_level(
                result.level,
                rule_hit=rule_hit + "(fallback:no_vision_model)",
                score=result.score,
            )

        primary = candidates[0]
        fallbacks = [(c.provider, c.model_id) for c in candidates[1:]]
        return RoutingDecision(
            provider=primary.provider,
            model_id=primary.model_id,
            level=primary.level,
            rule_hit=rule_hit,
            score=0.0,
            fallbacks=fallbacks,
        )

    def _default_decision(self, *, rule_hit: str, score: float) -> RoutingDecision:
        """Fallback when no model is found in config."""
        from thryve.llm import _parse_model_ref

        provider, model_id = _parse_model_ref(self._config.agent.model)
        return RoutingDecision(
            provider=provider,
            model_id=model_id,
            level="medium",
            rule_hit=rule_hit + "(fallback:default)",
            score=score,
            fallbacks=[],
        )

    # ------------------------------------------------------------------
    # Candidate enumeration
    # ------------------------------------------------------------------

    def _collect_all_candidates(self) -> list[ModelCandidate]:
        """Return all models declared across all providers."""
        from thryve.config.schema import ModelConfig

        candidates: list[ModelCandidate] = []
        for provider_name, provider_cfg in self._config.providers.items():
            for entry in provider_cfg.models:
                if isinstance(entry, str):
                    candidates.append(
                        ModelCandidate(
                            provider=provider_name,
                            model_id=entry,
                            level="medium",
                            vision=False,
                        )
                    )
                elif isinstance(entry, ModelConfig):
                    if not getattr(entry, "enabled", True):
                        continue
                    candidates.append(
                        ModelCandidate(
                            provider=provider_name,
                            model_id=entry.id,
                            level=entry.level,
                            vision=entry.vision,
                        )
                    )
        return candidates

    def _collect_candidates_by_level(self, level: str) -> list[ModelCandidate]:
        """Return candidates matching *level* exactly."""
        return [c for c in self._collect_all_candidates() if c.level == level]

    # ------------------------------------------------------------------
    # Rule matching
    # ------------------------------------------------------------------

    @staticmethod
    def _matches_keyword_rule(text: str, rule: Any) -> bool:
        """Return True if *text* matches the keyword rule."""
        lower = text.lower()

        # Length constraints
        if rule.min_length is not None and len(text) < rule.min_length:
            return False
        if rule.max_length is not None and len(text) > rule.max_length:
            return False

        # Keyword match (any keyword is sufficient)
        if rule.keywords:
            return any(kw.lower() in lower for kw in rule.keywords)

        # Pure length-based rule (no keywords specified)
        return True

    @staticmethod
    def _has_images(messages: list[Message]) -> bool:
        """Return True if any message contains an ImagePart."""
        from thryve.context.models import ImagePart

        for msg in messages:
            if isinstance(msg.content, list):
                if any(isinstance(part, ImagePart) for part in msg.content):
                    return True
        return False
