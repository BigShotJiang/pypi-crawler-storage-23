"""RoutingProviderAdapter – dynamic per-call model selection with fallback.

When ``config.routing.auto`` is ``True``, ``create_llm()`` returns one of
these instead of a plain ``ProviderAdapter``.  It presents the **same**
``ProviderAdapter`` interface so callers require no changes.
"""

from __future__ import annotations

from collections.abc import AsyncIterator
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from thryve.config.schema import Config
    from thryve.context.models import ChatResponse, Message, ProviderInfo
    from thryve.tools.models import Tool

from thryve.providers.adapter import ProviderAdapter
from thryve.routing.router import ModelRouter, RoutingDecision
from thryve.utils import get_logger

logger = get_logger("routing.adapter")


class RoutingProviderAdapter:
    """Wraps multiple :class:`ProviderAdapter` instances and selects the right
    one per request using :class:`ModelRouter`.

    Fallback behaviour:
    - If the primary model raises any exception, the adapter tries each
      fallback in order.
    - If all candidates fail, the last exception is re-raised with a
      structured message listing all attempted models.

    The class exposes the same interface as :class:`ProviderAdapter` so it
    can be used as a drop-in replacement.
    """

    def __init__(self, config: Config, bound_tools: list[Any] | None = None) -> None:
        self._config = config
        self._router = ModelRouter(config)
        self._bound_tools: list[Any] = bound_tools or []
        # Cache of ProviderAdapter instances keyed by (provider, model_id).
        self._adapters: dict[tuple[str, str], ProviderAdapter] = {}

    # ------------------------------------------------------------------
    # Chat
    # ------------------------------------------------------------------

    async def chat(
        self,
        messages: list[Message],
        model: str | None = None,
        tools: list[Tool] | None = None,
        **kwargs: Any,
    ) -> ChatResponse:
        decision = self._router.select_model(messages)
        logger.info("Routing decision: %s", decision)

        effective_tools = tools if tools is not None else (self._bound_tools or None)
        tried: list[str] = []
        last_exc: Exception | None = None

        for provider, model_id in self._candidate_chain(decision):
            label = f"{provider}/{model_id}"
            tried.append(label)
            try:
                adapter = self._get_adapter(provider, model_id)
                return await adapter.chat(
                    messages,
                    model=model or model_id,
                    tools=effective_tools,
                    **kwargs,
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("Model %s failed: %s – trying fallback", label, exc)
                last_exc = exc

        raise RuntimeError(
            f"All routing candidates failed: {tried}. Last error: {last_exc}"
        ) from last_exc

    async def chat_stream(
        self,
        messages: list[Message],
        model: str | None = None,
        **kwargs: Any,
    ) -> AsyncIterator[str]:
        decision = self._router.select_model(messages)
        logger.info("Routing decision (stream): %s", decision)

        tried: list[str] = []
        last_exc: Exception | None = None

        for provider, model_id in self._candidate_chain(decision):
            label = f"{provider}/{model_id}"
            tried.append(label)
            try:
                adapter = self._get_adapter(provider, model_id)
                async for chunk in adapter.chat_stream(
                    messages, model=model or model_id, **kwargs
                ):
                    yield chunk
                return
            except Exception as exc:  # noqa: BLE001
                logger.warning("Stream model %s failed: %s – trying fallback", label, exc)
                last_exc = exc

        raise RuntimeError(
            f"All routing candidates failed (stream): {tried}. Last error: {last_exc}"
        ) from last_exc

    # ------------------------------------------------------------------
    # Embeddings
    # ------------------------------------------------------------------

    async def embed(self, texts: list[str], **kwargs: Any) -> list[list[float]]:
        """Embedding always uses the primary/default adapter (no routing)."""
        from thryve.llm import _parse_model_ref

        provider, model_id = _parse_model_ref(self._config.agent.model)
        adapter = self._get_adapter(provider, model_id)
        return await adapter.embed(texts, **kwargs)

    # ------------------------------------------------------------------
    # Tool binding (immutable pattern)
    # ------------------------------------------------------------------

    def bind_tools(self, tools: list[Tool]) -> RoutingProviderAdapter:
        new = RoutingProviderAdapter.__new__(RoutingProviderAdapter)
        new._config = self._config
        new._router = self._router
        new._bound_tools = list(tools)
        new._adapters = self._adapters  # share cache
        return new

    # ------------------------------------------------------------------
    # Introspection (delegate to the default model)
    # ------------------------------------------------------------------

    def get_info(self) -> ProviderInfo:
        from thryve.llm import _parse_model_ref

        provider, model_id = _parse_model_ref(self._config.agent.model)
        return self._get_adapter(provider, model_id).get_info()

    def get_model_list(self) -> list[str]:
        from thryve.routing.router import ModelRouter

        return [
            f"{c.provider}/{c.model_id}"
            for c in ModelRouter(self._config)._collect_all_candidates()
        ]

    def supports_vision(self, model: str) -> bool:
        from thryve.llm import _parse_model_ref

        provider, _ = _parse_model_ref(self._config.agent.model)
        adapter = self._get_adapter(provider, model)
        return adapter.supports_vision(model)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _get_adapter(self, provider: str, model_id: str) -> ProviderAdapter:
        """Return (and cache) a :class:`ProviderAdapter` for the given pair."""
        key = (provider, model_id)
        if key not in self._adapters:
            import thryve.providers  # noqa: F401 – ensure registration

            from thryve.config.schema import ProviderConfig

            provider_cfg = self._config.providers.get(provider) or ProviderConfig(base_url="")
            params: dict[str, Any] = {"model": model_id}
            if provider_cfg.api_key:
                params["api_key"] = provider_cfg.api_key
            if provider_cfg.base_url:
                params["base_url"] = provider_cfg.base_url
            params["temperature"] = self._config.agent.temperature
            if self._config.agent.max_tokens:
                params["max_tokens"] = self._config.agent.max_tokens

            self._adapters[key] = ProviderAdapter(provider, params)
        return self._adapters[key]

    @staticmethod
    def _candidate_chain(decision: RoutingDecision) -> list[tuple[str, str]]:
        """Return primary + fallbacks as an ordered list."""
        chain = [(decision.provider, decision.model_id)]
        chain.extend(decision.fallbacks)
        return chain
