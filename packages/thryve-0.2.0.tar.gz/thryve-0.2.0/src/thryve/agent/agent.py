"""Agent – wraps an LLM, tools, and config into a single callable unit."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from thryve.agent.loop import AgentLoop
from thryve.agent.models import LoopConfig, StopReason, TurnResult
from thryve.providers.adapter import ProviderAdapter
from thryve.context.models import Message
from thryve.tools.models import Tool
from thryve.utils import get_logger

if TYPE_CHECKING:
    from thryve.context.manager import ContextManager
    from thryve.context.scheduler import Scheduler

logger = get_logger("agent")


class Agent:
    """A single autonomous agent.

    An agent owns:

    * A provider adapter (LLM).
    * A set of tools it may invoke.
    * A loop configuration.
    * An optional system prompt.
    """

    def __init__(
        self,
        name: str,
        llm: ProviderAdapter,
        tools: list[Tool] | None = None,
        config: LoopConfig | None = None,
        system_prompt: str = "",
    ) -> None:
        self.name = name
        self.llm = llm
        self.tools = tools or []
        self.config = config or LoopConfig()
        self.system_prompt = system_prompt

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------

    async def run(
        self,
        task: str,
        context: ContextManager | None = None,
        scheduler: Scheduler | None = None,
        **llm_kwargs: Any,
    ) -> TurnResult:
        """Execute *task* using the agent's LLM and tools.

        If a *scheduler* is supplied, it handles message assembly (including
        memory retrieval and block ordering) and post-turn commit.

        If only a *context* manager is supplied (no scheduler), messages are
        drawn from (and written back to) it directly (legacy behaviour).
        """
        if scheduler is not None:
            return await self._run_with_scheduler(task, scheduler, **llm_kwargs)
        return await self._run_legacy(task, context, **llm_kwargs)

    async def _run_with_scheduler(
        self,
        task: str,
        scheduler: Scheduler,
        **llm_kwargs: Any,
    ) -> TurnResult:
        """Run the agent loop with Scheduler-based message assembly."""
        messages = scheduler.assemble(task)

        loop = AgentLoop(self.llm, self.tools, self.config)
        result = await loop.execute(messages, **llm_kwargs)

        new_turn_messages = self._extract_new_messages(messages, task)
        if new_turn_messages:
            scheduler.commit_messages(new_turn_messages)

        return result

    async def _run_legacy(
        self,
        task: str,
        context: ContextManager | None = None,
        **llm_kwargs: Any,
    ) -> TurnResult:
        """Original execution path (backward-compatible)."""
        messages: list[Message] = []
        if self.system_prompt:
            messages.append(Message(role="system", content=self.system_prompt))

        if context is not None:
            messages.extend(context.messages)

        messages.append(Message(role="user", content=task))

        loop = AgentLoop(self.llm, self.tools, self.config)
        result = await loop.execute(messages, **llm_kwargs)

        if context is not None:
            context.messages = messages

        return result

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_new_messages(messages: list[Message], task: str) -> list[Message]:
        """Return messages produced during this turn (user + loop output)."""
        result: list[Message] = []
        found_user = False
        for msg in messages:
            if not found_user and msg.role == "user" and msg.text == task:
                found_user = True
                result.append(msg)
                continue
            if found_user:
                result.append(msg)
        return result

    # ------------------------------------------------------------------
    # Repr
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        return (
            f"Agent(name={self.name!r}, model={self.llm.get_info().model!r}, "
            f"tools={[t.name for t in self.tools]})"
        )
