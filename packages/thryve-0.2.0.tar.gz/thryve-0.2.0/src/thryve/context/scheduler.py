"""Scheduler – lightweight coordinator that assembles per-turn LLM messages.

The Scheduler reads from ContextManager (blocks), MemoryManager (retrieval),
and ToolRegistry (tool definitions) to produce the final ``list[Message]``
sent to the LLM each turn.  After the LLM responds, it commits new messages
back into the conversation block of the ContextManager.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from thryve.context.manager import ContextManager
from thryve.context.models import Message, MessageContent
from thryve.utils import estimate_tokens, get_logger

if TYPE_CHECKING:
    from thryve.memory.manager import MemoryManager
    from thryve.memory.types import MemoryChunk
    from thryve.tools.models import Tool
    from thryve.tools.registry import ToolRegistry

logger = get_logger("context.scheduler")


class Scheduler:
    """Assembles per-turn messages from Context, Memory, and Tools.

    Lifecycle per turn::

        messages = scheduler.assemble(user_input_text)
        response = await llm.chat(messages)
        scheduler.commit(user_msg, assistant_msg)

    The Scheduler never owns LLM / Memory / Tools state — it only reads
    and coordinates.
    """

    def __init__(
        self,
        context: ContextManager,
        memory: MemoryManager | None = None,
        tool_registry: ToolRegistry | None = None,
        *,
        memory_top_k: int = 5,
        system_prompt: str = "",
    ) -> None:
        self._ctx = context
        self._memory = memory
        self._tool_registry = tool_registry
        self._memory_top_k = memory_top_k
        if system_prompt:
            self._ctx.set_system_identity(system_prompt)

    # ------------------------------------------------------------------
    # Assembly
    # ------------------------------------------------------------------

    def assemble(
        self,
        user_input: str | MessageContent,
        *,
        session_id: str | None = None,
    ) -> list[Message]:
        """Build the full message list for one LLM call.

        Steps:
        1. Retrieve relevant memories and populate the memory block.
        2. Set the current user input in the user_input block.
        3. Concatenate blocks in order: system_identity → memory →
           conversation → user_input.

        Tool definitions are **not** injected here — they are passed via
        ``ProviderAdapter.bind_tools()`` at the LLM call site.

        Returns the assembled ``list[Message]`` ready for the LLM.
        """
        # 1. Memory retrieval
        query_text = user_input if isinstance(user_input, str) else _extract_text(user_input)
        self._populate_memory_block(query_text)

        # 2. User input
        user_msg = Message(role="user", content=user_input)
        user_msg.token_count = estimate_tokens(user_msg.text)
        self._ctx.set_user_input(user_msg)

        # 3. Collect from all blocks in order
        assembled: list[Message] = []
        for block_name in self._ctx.block_names:
            assembled.extend(self._ctx.get_block_messages(block_name))

        logger.debug(
            "Assembled %d messages (sys=%d, mem=%d, conv=%d, user=%d)",
            len(assembled),
            len(self._ctx.get_block("system_identity").messages),
            len(self._ctx.get_block("memory").messages),
            len(self._ctx.get_block("conversation").messages),
            len(self._ctx.get_block("user_input").messages),
        )
        return assembled

    # ------------------------------------------------------------------
    # Commit (post-LLM)
    # ------------------------------------------------------------------

    def commit(
        self,
        user_text: str,
        assistant_text: str,
        *,
        extra_messages: list[Message] | None = None,
    ) -> None:
        """Persist this turn's messages into the conversation block.

        Call this **after** the LLM has responded.  The user and assistant
        messages are appended to the conversation block.  Any additional
        messages (e.g. tool calls/results from an agent loop) can be passed
        via *extra_messages*.

        The user_input block is cleared after commit since the message has
        been incorporated into conversation history.
        """
        self._ctx.add_conversation_message("user", user_text)

        if extra_messages:
            for msg in extra_messages:
                self._ctx.add_conversation(msg)

        self._ctx.add_conversation_message("assistant", assistant_text)
        self._ctx.clear_user_input()

    def commit_messages(self, messages: list[Message]) -> None:
        """Bulk-commit a list of messages into the conversation block.

        Useful after an agent loop where the full message trail
        (user → assistant → tool → assistant …) is already available.
        """
        for msg in messages:
            if msg.role == "system":
                continue
            self._ctx.add_conversation(msg)
        self._ctx.clear_user_input()

    # ------------------------------------------------------------------
    # Memory block population
    # ------------------------------------------------------------------

    def _populate_memory_block(self, query: str) -> None:
        """Retrieve memories and fill the memory block."""
        if self._memory is None:
            self._ctx.set_memory_messages([])
            return

        chunks: list[MemoryChunk] = []
        try:
            chunks = self._memory.search(query, top_k=self._memory_top_k)
        except Exception:
            logger.debug("Memory search failed; continuing without memories")

        if not chunks:
            self._ctx.set_memory_messages([])
            return

        ctx_text = "\n".join(f"- {c.text}" for c in chunks)
        memory_msg = Message(
            role="system",
            content=f"Relevant context from memory:\n{ctx_text}",
        )
        memory_msg.token_count = estimate_tokens(memory_msg.text)
        self._ctx.set_memory_messages([memory_msg])

    # ------------------------------------------------------------------
    # Tool helpers
    # ------------------------------------------------------------------

    def get_tools(self) -> list[Tool]:
        """Return tools from the registry (for ``bind_tools``)."""
        if self._tool_registry is None:
            return []
        return self._tool_registry.list_tools()

    # ------------------------------------------------------------------
    # Persistence helpers
    # ------------------------------------------------------------------

    def save_to_memory(self, user_text: str, assistant_text: str) -> None:
        """Write this turn to short-term memory (fire-and-forget)."""
        if self._memory is None:
            return
        try:
            self._memory.append_to_short_term(f"User: {user_text}")
            self._memory.append_to_short_term(f"Assistant: {assistant_text}")
        except Exception:
            logger.debug("Failed to persist turn to memory")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _extract_text(content: MessageContent) -> str:
    """Get plain text from a MessageContent value."""
    if isinstance(content, str):
        return content
    from thryve.context.models import TextPart
    parts = [p.text for p in content if isinstance(p, TextPart)]
    return "".join(parts)
