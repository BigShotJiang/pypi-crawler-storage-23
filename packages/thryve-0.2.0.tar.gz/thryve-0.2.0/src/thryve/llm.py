"""Top-level LLM facade – create a provider from config."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Union

from thryve.config.schema import Config, ProviderConfig
from thryve.providers.adapter import ProviderAdapter

if TYPE_CHECKING:
    from thryve.routing.adapter import RoutingProviderAdapter

# Convenience alias used by type-annotated callers.
LLMAdapter = Union[ProviderAdapter, "RoutingProviderAdapter"]


def create_llm(config: Config) -> LLMAdapter:
    """Create an LLM adapter from *config*.

    When ``config.routing.auto`` is ``True``, returns a
    :class:`RoutingProviderAdapter` that selects the model per request.
    Otherwise returns a fixed-model :class:`ProviderAdapter`.
    """
    import thryve.providers  # noqa: F401 — ensure providers are registered

    if config.routing.auto:
        from thryve.routing.adapter import RoutingProviderAdapter
        return RoutingProviderAdapter(config)

    # Fixed-model mode.
    provider_name, model_name = _parse_model_ref(config.agent.model)
    provider_cfg = config.providers.get(provider_name)
    if provider_cfg is None:
        provider_cfg = ProviderConfig(base_url="")

    params: dict[str, Any] = {"model": model_name}
    if provider_cfg.api_key:
        params["api_key"] = provider_cfg.api_key
    if provider_cfg.base_url:
        params["base_url"] = provider_cfg.base_url
    # Provider config takes precedence over agent config
    if provider_cfg.temperature is not None:
        params["temperature"] = provider_cfg.temperature
    else:
        params["temperature"] = config.agent.temperature
    if provider_cfg.max_tokens is not None:
        params["max_tokens"] = provider_cfg.max_tokens
    elif config.agent.max_tokens:
        params["max_tokens"] = config.agent.max_tokens

    return ProviderAdapter(provider_name, params)


def _parse_model_ref(model: str) -> tuple[str, str]:
    """Split ``'provider/model'`` into ``(provider, model)``.

    If there is no slash, defaults provider to ``'openai'``.
    """
    if "/" in model:
        provider, _, name = model.partition("/")
        return provider, name
    return "openai", model
