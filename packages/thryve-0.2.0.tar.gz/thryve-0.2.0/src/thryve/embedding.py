"""Top-level embedding facade.

:func:`create_embedding` resolves the embedding model from config following a
three-tier priority (see :meth:`ToolModelFactory.create_embed`):

1. ``config.tool_models.embed``  — explicit ``"provider/model"`` reference.
2. First ``ModelConfig`` with ``role="embed"`` in any provider's ``models``.
3. No embed model → returns ``None``; memory falls back to keyword-only search.
"""

from __future__ import annotations

from thryve.config.schema import Config
from thryve.tool_models.base import EmbedProvider
from thryve.tool_models.factory import ToolModelFactory
from thryve.utils import run_sync


class EmbeddingModel:
    """Synchronous ``embed()`` callable for the memory system.

    Wraps an :class:`EmbedProvider` and bridges its async interface via
    :func:`run_sync` so that callers (e.g. :class:`MemoryManager`) do not
    need to manage event loops.
    """

    def __init__(self, provider: EmbedProvider) -> None:
        self._provider = provider

    def embed(self, texts: list[str]) -> list[list[float]]:
        return run_sync(self._provider.embed(texts))

    def __call__(self, texts: list[str]) -> list[list[float]]:
        return self.embed(texts)

    @property
    def info(self):
        """Return metadata about the underlying embedding model."""
        return self._provider.get_info()


def create_embedding(config: Config) -> EmbeddingModel | None:
    """Create an :class:`EmbeddingModel` from *config*, or ``None`` if no
    embedding model is configured.

    Delegates resolution to :class:`ToolModelFactory` which applies the
    three-tier priority described in this module's docstring.
    """
    provider = ToolModelFactory.create_embed(config)
    if provider is None:
        return None
    return EmbeddingModel(provider)
