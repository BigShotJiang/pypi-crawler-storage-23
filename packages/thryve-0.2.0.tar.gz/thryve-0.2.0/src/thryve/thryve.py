"""Thryve – main entry class that wires all subsystems together."""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from typing import Any, Callable

from thryve.config.schema import Config
from thryve.agent.agent import Agent
from thryve.agent.models import LoopConfig, TurnResult
from thryve.agent.multi_agent import MultiAgentOrchestrator
from thryve.providers.adapter import ProviderAdapter
from thryve.context.manager import ContextManager
from thryve.context.models import ImagePart, Message, MessageContent, ProviderInfo, TextPart
from thryve.context.scheduler import Scheduler
from thryve.graph.executor import GraphExecutor
from thryve.graph.graph import Graph
from thryve.memory.manager import MemoryManager
from thryve.memory.types import MemoryChunk
from thryve.multimodal.models import ContentInput, MediaSource
from thryve.multimodal.processor import MediaProcessor
from thryve.tools.models import Tool
from thryve.tools.registry import ToolRegistry
from thryve.llm import create_llm
from thryve.tool_models.base import OCRProvider
from thryve.utils import get_logger

logger = get_logger("thryve")


def _create_memory(
    config: Config,
) -> MemoryManager:
    """Create a :class:`MemoryManager` from config."""
    return MemoryManager(
        storage_path=config.memory.storage_path,
        markdown_path=config.memory.markdown_path,
        short_term_retention_days=config.memory.short_term_retention_days,
        enable_fts=config.memory.enable_fts,
    )


class Thryve:
    """Top-level facade for the Thryve framework.

    Initializes LLM, embedding, memory, context, agent, and graph subsystems
    in the correct dependency order and exposes a unified public API.

    Usage::

        from thryve import Thryve
        from thryve.config import load_config

        app = Thryve()
        reply = app.chat("Hello!")
    """

    def __init__(self, config: Config | None = None) -> None:
        self.config = config or Config()

        # 1. LLM (no deps)
        self.llm: ProviderAdapter = self._init_llm()
        # 2. Tool models
        self.ocr: OCRProvider | None = self._init_tool_models()
        # 3. Memory
        self.memory: MemoryManager = self._init_memory()
        # 4. Context
        self.context: ContextManager = self._init_context()
        # 5. Tools
        self._tool_registry = ToolRegistry()
        # 6. Scheduler
        self.scheduler: Scheduler = self._init_scheduler()
        # 7. Agent orchestrator
        self.agent_orchestrator = MultiAgentOrchestrator()
        # 8. Graph executor
        self.graph_executor = GraphExecutor()
        # 9. Multimodal processor
        self._media_processor = MediaProcessor(
            max_images=self.config.multimodal.max_images,
            max_file_size_mb=self.config.multimodal.max_file_size_mb,
        )

        logger.info(
            "Thryve initialised (provider=%s, memory_search=keyword)",
            self.llm.get_info().provider,
        )

    # ------------------------------------------------------------------
    # Subsystem initialisation
    # ------------------------------------------------------------------

    def _init_llm(self) -> ProviderAdapter:
        return create_llm(self.config)

    def _init_tool_models(self) -> OCRProvider | None:
        """Initialise optional tool models beyond embedding.

        Currently a hook for Phase 1.4 (OCR).  Additional tool models
        (reranker, STT, …) should be resolved here and stored as attributes.
        """
        return None  # Phase 1.4 will populate OCR here

    def _init_memory(self) -> MemoryManager:
        return _create_memory(self.config)

    def _init_context(self) -> ContextManager:
        from thryve.context.compression import get_strategy

        name = self.config.context.compression
        strategy = get_strategy(
            name,
            llm=self.llm,
            memory=self.memory,
            recent_keep=self.config.context.compression_config.recent_keep,
        )
        return ContextManager(
            config=self.config.context,
            strategy=strategy,
        )

    def _init_scheduler(self) -> Scheduler:
        return Scheduler(
            context=self.context,
            memory=self.memory,
            tool_registry=self._tool_registry,
        )

    # ==================================================================
    # Chat interface
    # ==================================================================

    async def chat_async(
        self,
        message: str | None = None,
        *,
        content: ContentInput | None = None,
        images: list[MediaSource] | None = None,
        session_id: str | None = None,
    ) -> str:
        """Async LLM chat with optional memory retrieval and multimodal input.

        Parameters
        ----------
        message:
            Plain-text message (compatible with pre-1.4 callers).
        content:
            Full multimodal input (``ContentInput``). Mutually exclusive
            with *message*.
        images:
            Shorthand for attaching images alongside *message*.
        session_id:
            Optional session identifier.
        """
        text, user_content = self._resolve_input(message, content, images)

        messages = self.scheduler.assemble(user_content, session_id=session_id)
        self._guard_vision(messages)
        response = await self.llm.chat(messages)

        self.scheduler.commit(text, response.content)
        self.scheduler.save_to_memory(text, response.content)

        return response.content

    async def chat_stream_async(
        self,
        message: str | None = None,
        *,
        content: ContentInput | None = None,
        images: list[MediaSource] | None = None,
        session_id: str | None = None,
    ) -> AsyncIterator[str]:
        """Async streaming chat with optional multimodal input."""
        text, user_content = self._resolve_input(message, content, images)

        messages = self.scheduler.assemble(user_content, session_id=session_id)
        self._guard_vision(messages)
        full_content: list[str] = []
        async for chunk in self.llm.chat_stream(messages):
            full_content.append(chunk)
            yield chunk
        full_text = "".join(full_content)

        self.scheduler.commit(text, full_text)
        self.scheduler.save_to_memory(text, full_text)

    async def chat_with_agent_async(
        self,
        message: str,
        agent_name: str = "default",
        **kwargs: Any,
    ) -> TurnResult:
        """Async agent chat – the agent can call registered tools."""
        agent = self._get_or_create_agent(agent_name)
        return await agent.run(message, context=self.context, scheduler=self.scheduler, **kwargs)

    async def execute_graph_async(
        self,
        graph: Graph,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Async DAG workflow execution."""
        return await self.graph_executor.execute(graph, inputs)

    # ---- sync wrappers ------------------------------------------------

    def chat(
        self,
        message: str | None = None,
        *,
        content: ContentInput | None = None,
        images: list[MediaSource] | None = None,
        session_id: str | None = None,
    ) -> str:
        return asyncio.run(
            self.chat_async(message, content=content, images=images, session_id=session_id)
        )

    def chat_stream(
        self,
        message: str | None = None,
        *,
        content: ContentInput | None = None,
        images: list[MediaSource] | None = None,
        session_id: str | None = None,
        callback: Callable[[str], None] | None = None,
    ) -> str:
        full: list[str] = []

        async def _consume() -> str:
            async for chunk in self.chat_stream_async(
                message, content=content, images=images, session_id=session_id,
            ):
                full.append(chunk)
                if callback:
                    callback(chunk)
            return "".join(full)

        return asyncio.run(_consume())

    def chat_with_agent(
        self,
        message: str,
        agent_name: str = "default",
        **kwargs: Any,
    ) -> TurnResult:
        return asyncio.run(self.chat_with_agent_async(message, agent_name=agent_name, **kwargs))

    def execute_graph(
        self,
        graph: Graph,
        inputs: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        return asyncio.run(self.execute_graph_async(graph, inputs))

    # ==================================================================
    # Memory interface
    # ==================================================================

    def add_to_memory(self, content: str, permanent: bool = False) -> None:
        if permanent:
            self.memory.promote_to_long_term(content)
        else:
            self.memory.append_to_short_term(content)

    def search_memory(self, query: str, top_k: int = 5) -> list[MemoryChunk]:
        return self.memory.search(query, top_k=top_k)

    # ==================================================================
    # Tool interface
    # ==================================================================

    def register_tool(self, tool: Tool) -> None:
        self._tool_registry.register(tool)

    def list_tools(self) -> list[Tool]:
        return self._tool_registry.list_tools()

    # ==================================================================
    # Agent interface
    # ==================================================================

    def register_agent(self, agent: Agent) -> None:
        self.agent_orchestrator.register_agent(agent)

    # ==================================================================
    # Introspection
    # ==================================================================

    def get_llm_info(self) -> ProviderInfo:
        return self.llm.get_info()

    # ==================================================================
    # Internals
    # ==================================================================

    # ------------------------------------------------------------------
    # Multimodal helpers
    # ------------------------------------------------------------------

    def _resolve_input(
        self,
        message: str | None,
        content: ContentInput | None,
        images: list[MediaSource] | None,
    ) -> tuple[str, MessageContent]:
        """Normalise the three input styles into (plain_text, MessageContent).

        Returns
        -------
        (text, message_content) where *text* is the plain string used for
        memory search, and *message_content* is the value to put into the
        ``Message.content`` field (either a ``str`` or a multimodal part
        list).
        """
        if content is not None and message is not None:
            raise ValueError("Provide either 'message' or 'content', not both")
        if content is not None and images is not None:
            raise ValueError("Provide either 'content' or 'images', not both")
        if content is None and message is None:
            raise ValueError("One of 'message' or 'content' is required")

        if content is not None:
            text = content.text
            image_parts = self._media_processor.process_content_items(content.images)
            return text, self._media_processor.build_message_content(text, image_parts)

        assert message is not None  # ensured by guard above
        if images:
            image_parts = self._media_processor.process_images(images)
            return message, self._media_processor.build_message_content(message, image_parts)

        return message, message

    def _guard_vision(self, messages: list[Message]) -> None:
        """Raise if any message contains images but the model lacks vision."""
        has_images = any(
            isinstance(msg.content, list)
            and any(isinstance(p, ImagePart) for p in msg.content)
            for msg in messages
        )
        if not has_images:
            return

        info = self.llm.get_info()
        if not info.supports_vision:
            raise ValueError(
                f"Model {info.model!r} (provider={info.provider!r}) does not "
                f"support vision input. Choose a vision-capable model or remove "
                f"the image arguments."
            )

    def _get_or_create_agent(self, name: str) -> Agent:
        agent = self.agent_orchestrator.labor_market.get(name)
        if agent is not None:
            return agent

        agent = Agent(
            name=name,
            llm=self.llm,
            tools=self._tool_registry.list_tools(),
            config=LoopConfig(
                max_turns=self.config.agent.max_tool_iterations,
                max_steps_per_turn=5,
                loop_detection_window=3,
                enable_auto_continue=True,
            ),
        )
        self.agent_orchestrator.register_agent(agent)
        return agent
