"""ToolModelFactory — creates and caches tool model instances from config.

For embed models the factory delegates to the existing ``ProviderFactory``
because OpenAI/Ollama providers already implement ``embed()``.  It then
wraps the result in a thin :class:`ProviderEmbedAdapter` that satisfies the
:class:`EmbedProvider` protocol without requiring the full LLM provider
interface from callers.

For OCR and future tool types, dedicated provider classes will be registered
here via ``register_ocr()`` and similar class methods.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from thryve.config.schema import Config

from thryve.tool_models.base import EmbedProvider, ToolModelInfo


# ---------------------------------------------------------------------------
# Thin adapter: wraps a ProviderAdapter as an EmbedProvider
# ---------------------------------------------------------------------------

class ProviderEmbedAdapter(EmbedProvider):
    """Wraps a :class:`ProviderAdapter` to satisfy the :class:`EmbedProvider`
    protocol.

    This lets the embedding subsystem remain decoupled from the full LLM
    provider interface — callers only see ``embed()`` and ``get_info()``.
    """

    def __init__(self, adapter: Any, provider_name: str, model_id: str) -> None:
        self._adapter = adapter
        self._provider_name = provider_name
        self._model_id = model_id

    async def embed(self, texts: list[str], **kwargs: Any) -> list[list[float]]:
        return await self._adapter.embed(texts, **kwargs)

    def get_info(self) -> ToolModelInfo:
        return ToolModelInfo(
            tool_type="embed",
            provider=self._provider_name,
            model=self._model_id,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

class ToolModelFactory:
    """Create tool model instances from config.

    Resolution order for ``create_embed(config)``:

    1. ``config.tool_models.embed`` — explicit ``"provider/model"`` reference.
    2. First ``ModelConfig`` with ``role="embed"`` found in any provider's
       ``models`` list.
    3. ``None`` — caller decides how to handle the absence (typically
       keyword-only memory fallback).
    """

    @classmethod
    def create_embed(cls, config: Config) -> EmbedProvider | None:
        """Return an :class:`EmbedProvider` or ``None`` if no embed model is
        configured."""
        import thryve.providers  # noqa: F401 — ensure providers are registered

        from thryve.providers.factory import ProviderFactory
        from thryve.providers.adapter import ProviderAdapter
        from thryve.config.schema import ModelConfig, ProviderConfig
        from thryve.llm import _parse_model_ref

        # -- Priority 1: explicit tool_models.embed ---------------------------
        if config.tool_models.embed:
            provider_name, model_id = _parse_model_ref(config.tool_models.embed)
            adapter = cls._build_adapter(config, provider_name, model_id)
            return ProviderEmbedAdapter(adapter, provider_name, model_id)

        # -- Priority 2: auto-discover via role="embed" in providers ----------
        for provider_name, provider_cfg in config.providers.items():
            for entry in provider_cfg.models:
                if isinstance(entry, ModelConfig) and entry.role == "embed":
                    adapter = cls._build_adapter(config, provider_name, entry.id)
                    return ProviderEmbedAdapter(adapter, provider_name, entry.id)

        # -- Priority 3: no embed model configured ----------------------------
        return None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _build_adapter(config: Config, provider_name: str, model_id: str):
        """Build a bare :class:`ProviderAdapter` for *provider_name/model_id*."""
        from thryve.providers.adapter import ProviderAdapter
        from thryve.config.schema import ProviderConfig

        provider_cfg = config.providers.get(provider_name) or ProviderConfig(base_url="")
        params: dict[str, Any] = {"model": model_id}
        if provider_cfg.api_key:
            params["api_key"] = provider_cfg.api_key
        if provider_cfg.base_url:
            params["base_url"] = provider_cfg.base_url

        return ProviderAdapter(provider_name, params)
