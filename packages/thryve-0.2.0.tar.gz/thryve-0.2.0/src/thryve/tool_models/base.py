"""Abstract base classes for non-chat tool models.

Tool models are pipeline utilities that have a specific, narrow interface
rather than the general ``chat / chat_stream / embed`` interface of a
full LLM Provider.  They are configured independently via
``config.tool_models`` and resolved by :mod:`thryve.tool_models.factory`.

Current hierarchy:

    EmbedProvider   — embedding / vector representation
    OCRProvider     — image-to-text extraction  (Phase 1.4)

Future candidates: RerankerProvider, ClassifierProvider, STTProvider, …
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass


# ---------------------------------------------------------------------------
# Shared metadata
# ---------------------------------------------------------------------------

@dataclass
class ToolModelInfo:
    """Metadata returned by every tool model."""

    tool_type: str   # e.g. "embed", "ocr", "rerank"
    provider: str    # e.g. "openai", "ollama"
    model: str       # model id


# ---------------------------------------------------------------------------
# Embedding
# ---------------------------------------------------------------------------

class EmbedProvider(ABC):
    """Minimal interface for models that produce vector embeddings.

    Any object implementing this protocol can serve as the embedding backend
    for the memory system.  Both dedicated embedding services (e.g.
    ``text-embedding-3-small``) and LLM providers that expose an ``/embed``
    endpoint satisfy this interface.
    """

    @abstractmethod
    async def embed(self, texts: list[str], **kwargs) -> list[list[float]]:
        """Return one embedding vector per input text."""

    @abstractmethod
    def get_info(self) -> ToolModelInfo:
        """Return metadata about this embedding model."""


# ---------------------------------------------------------------------------
# OCR  (Phase 1.4 — interface definition only)
# ---------------------------------------------------------------------------

class OCRProvider(ABC):
    """Minimal interface for models that extract text from images.

    Implementations are registered in Phase 1.4 (multimodal support).
    The interface is defined here so that dependent code (e.g. the multimodal
    strategy layer) can reference it without a circular dependency.
    """

    @abstractmethod
    async def extract_text(self, image: bytes, mime_type: str = "image/png") -> str:
        """Extract plain text from *image* bytes.

        Parameters
        ----------
        image:
            Raw image bytes (PNG, JPEG, WebP, …).
        mime_type:
            MIME type hint for format detection.

        Returns
        -------
        str
            Extracted text; empty string if no text was found.
        """

    @abstractmethod
    def get_info(self) -> ToolModelInfo:
        """Return metadata about this OCR model."""
