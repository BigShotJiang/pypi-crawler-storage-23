"""
Post-processing functions for successful LANraragi API calls. All functions in this module are private.
"""
