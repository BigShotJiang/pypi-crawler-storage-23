"""Version information for the Confidence OpenFeature provider."""

__version__ = "0.4.1"  # x-release-please-version
