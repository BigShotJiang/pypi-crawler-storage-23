import Chat from "@/components/Chat";

export default function Home() {
	return <Chat />;
}
