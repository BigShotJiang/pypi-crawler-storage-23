# `Payloads`

::: agents.extensions.experimental.codex.payloads
