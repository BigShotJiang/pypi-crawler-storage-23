# `Tool Output Trimmer`

::: agents.extensions.tool_output_trimmer
