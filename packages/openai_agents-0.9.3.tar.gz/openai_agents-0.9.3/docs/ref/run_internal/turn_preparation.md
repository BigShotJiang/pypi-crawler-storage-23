# `Turn Preparation`

::: agents.run_internal.turn_preparation
