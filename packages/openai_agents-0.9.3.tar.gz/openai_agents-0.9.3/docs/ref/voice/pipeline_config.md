# `Pipeline Config`

::: agents.voice.pipeline_config
