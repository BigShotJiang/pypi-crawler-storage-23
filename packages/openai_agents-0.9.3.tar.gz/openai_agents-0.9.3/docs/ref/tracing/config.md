# `Config`

::: agents.tracing.config
