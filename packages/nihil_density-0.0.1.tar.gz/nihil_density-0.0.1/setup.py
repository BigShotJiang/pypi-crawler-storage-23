from setuptools import setup

setup(
    name="nihil-density",
    version="0.0.1",
    author="unknown",
    description="hello",
    long_description="hello world",
    long_description_content_type="text/markdown",
    packages=[],
)
