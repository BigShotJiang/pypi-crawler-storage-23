# -*- coding: UTF-8 -*-
# Copyright 2024 Rumma & Ko Ltd
# License: GNU Affero General Public License v3 (see file COPYING for details)

from lino.api import rt, dd, _
from lino_xl.lib.accounting.roles import LedgerUser
from django.db import models


def make_ledger_subscription(authorizable_user, apv, ar, user_type=dd.plugins.users.user_type_verified):
    ledger = apv['ledger']
    if (company := apv['company']) is None:
        company = ledger.company
    elif ledger is None:
        ledger = company.ledger

    user = rt.models.users.User(
        username=f"{company.as_ref_prefix()}{authorizable_user.username}")
    for attr_name in ['initials', 'first_name', 'last_name', 'nickname', 'language',
                        'remarks', 'partner', 'time_zone', 'date_format', 'sales_journal']:
        setattr(user, attr_name, getattr(
            authorizable_user, attr_name) if hasattr(user, attr_name) else None)
    user.user_type = user_type
    user.full_clean()
    user.save_new_instance(user.get_default_table().create_request(parent=ar))
    authority = rt.models.users.Authority(authorized=authorizable_user, user=user)
    authority.save_new_instance(
        authority.get_default_table().create_request(parent=ar))

    user.ledger = ledger
    user.save()

    if user.partner is not None and apv["role"]:
        Role = rt.models.contacts.Role
        role_attr = dict(type=apv['role'], company=company, person=user.person)
        if not Role.objects.filter(**role_attr).exists():
            role = Role(**role_attr)
            role.save_new_instance(role.get_default_table().create_request(parent=ar))


class SubscribeToLedger(dd.Action):
    label = _("Subscribe to ledger")
    select_rows = True
    required_roles = dd.login_required(LedgerUser)

    parameters = {
        "company": dd.ForeignKey("contacts.Company", verbose_name=_("Company"), blank=True),
        "ledger": dd.ForeignKey("ledgers.Ledger", verbose_name=_("Ledger"), blank=True),
        "role": dd.ForeignKey("contacts.RoleType", verbose_name=_("Role"), blank=True),
        "user": dd.ForeignKey("users.User", verbose_name=_("User"), blank=True),
    }

    def get_authorized(self, user):
        Authority = rt.models.users.Authority
        while True:
            if (qs := Authority.objects.filter(user=user)).exists():
                user = qs.first().authorized
            elif user.has_usable_password():
                return user
            else:
                return None

    def action_param_defaults(self, ar, obj, **kw):
        kw = super().action_param_defaults(ar, obj, **kw)
        Authority = rt.models.users.Authority
        if obj is not None:
            if isinstance(obj, rt.models.ledgers.Ledger):
                kw['company'] = obj.company
                kw['ledger'] = obj
            elif isinstance(obj, rt.models.users.User):
                kw['user'] = self.get_authorized(obj)
            else:
                raise Exception(
                    _("Invalid selected_row: must be a ledgers.Ledger or users.User instance"))
        return kw

    def is_parameters_valid(self, ar, apv):
        if len(ar.selected_rows) > 1:
            ar.error(_(
                "Invalid parameter %s: only one row is required"
            ) % ar.actor.model.__name__.lower())
            return False
        if apv['role'] is None:
            ar.error(_("Missing required parameter: role"))
            return False
        if (user := apv['user']) is None:
            ar.error(_("Missing required parameter: user"))
            return False
        user = self.get_authorized(user)
        if user is None:
            ar.error(_(
                "User {} is not authorized by any other user and has no usable password"
            ).format(user))
            return False
        self.user = user
        ledger = apv['ledger']
        if (company := apv['company']) is None and ledger is None:
            ar.error(
                _("Missing complementary required parameter: company or ledger"))
            return False

        ledger = ledger or company.ledger
        if user.ledger == ledger:
            ar.error(_(
                "Invalid operation: User (%s) already assigned to the selected ledger"
            ) % str(user), alert=True)
            return False
        if (qs := rt.models.users.User.objects.filter(ledger=ledger).annotate(authorized=models.Case(
                    models.When(models.Exists(rt.models.users.Authority.objects.filter(
                        user=models.OuterRef('pk'), authorized=user)), then=models.Value(True)),
                default=models.Value(False),
                output_field=models.BooleanField()
                )).filter(models.Q(authorized=True) | models.Q(pk=user.pk))).exists():
            ar.error(_(
                "Invalid operation: Authorized user (%s) already assigned to the selected ledger"
            ) % str(qs.first()))
            return False

        return True

    @staticmethod
    def make_subscription(authorizable_user, apv, ar, user_type=dd.plugins.users.user_type_verified):
        make_ledger_subscription(authorizable_user, apv, ar, user_type=user_type)

    def run_from_ui(self, ar, **kwargs):
        apv = ar.action_param_values
        if not self.is_parameters_valid(ar, apv):
            return

        self.make_subscription(self.user, apv, ar)

        ar.goto_instance(apv['company'] or apv['ledger'].company)
        ar.success()
