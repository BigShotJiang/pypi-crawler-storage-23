"""
Supply CLI utilities package.

Contains TUI and WebSocket client implementations for supply monitoring.
The main CLI command is located at cli/commands/power/supply.py.
"""
