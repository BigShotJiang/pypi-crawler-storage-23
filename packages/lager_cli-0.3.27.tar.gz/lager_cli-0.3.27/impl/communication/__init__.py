# Communication implementation scripts
# Handles UART, BLE, and WiFi operations executed on boxes
