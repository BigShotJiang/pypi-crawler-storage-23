# -*- coding: utf-8 -*-
"""Backward compatibility stub - moved to cli/vendor/PyCRC/CRC16SICK.py."""

from ..vendor.PyCRC.CRC16SICK import CRC16SICK

__all__ = ["CRC16SICK"]
