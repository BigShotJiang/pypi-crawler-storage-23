"""MCP tool definitions for Lager CLI commands."""
