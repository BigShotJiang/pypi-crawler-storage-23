if __name__ == "__main__":
    from .main import base_cli
    base_cli()
