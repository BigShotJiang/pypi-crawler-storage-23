# 1 add a sync source
from etiket_client.local.database import Session 

from etiket_client.sync.database.models_pydantic import sync_source
from etiket_client.sync.database.types import SyncSourceTypes
from etiket_client.sync.backends.sources import SyncSource
from etiket_client.sync.run import run_sync_iter, sync_loop
from etiket_client.sync.backends.qcodes.qcodes_sync_class import QCoDeSConfigData
from etiket_client.sync.backends.quantify.quantify_sync_class import QuantifyConfigData, QuantifySync

from etiket_client.sync.backends.core_tools.core_tools_sync_class import CoreToolsConfigData

import pathlib, dataclasses, uuid, logging, sys

logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))


from etiket_client.sync.database.dao_sync_sources import dao_sync_sources


sync_loop()

# credentials = CoreToolsConfigData(dbname="core_tools", user="stephan", password="", host="localhost",port= 5432)
# ss = sync_source(name="CoreTools", type=SyncSourceTypes.coretools,
#                     config_data=dataclasses.asdict(credentials), auto_mapping=True)

# with Session() as session:
#     dao_sync_sources.add_new_source(ss, session)
    

# config_data = QuantifyConfigData(quantify_directory = pathlib.Path("Users/stephan/Downloads/quantify-data"), set_up = "XLD")
# ss = sync_source(name="Quantify", type=SyncSourceTypes.quantify,
#                  config_data=dataclasses.asdict(config_data), auto_mapping=False, default_scope=uuid.UUID("3fa85f64-5617-4562-b3fc-2c963f66afa6"))

# with Session() as session:
#     dao_sync_sources.add_new_source(ss, session)


    
# with Session() as session:
#     run_sync_iter(session)
    

# get sync info ::


# ss = dao_sync_sources.read_sources(Session())

# for s in ss:
#     print(s)
# path = "/Users/stephan/coding/eTiKeT-testing/quantify_tests/QCoDeS_example.db"
# path = "/Users/stephan/Desktop/testing_data_diff_sources/QCoDeS_example.db"

# config_data = QCoDeSConfigData(database_directory= pathlib.Path(path), set_up = "XLD")
# ss = sync_source(name="QCoDeS_1", type=SyncSourceTypes.qcodes,
#                  config_data=dataclasses.asdict(config_data),
#                  auto_mapping=False, default_scope=uuid.UUID("3fa85f64-5717-4562-b3fc-2c990f66afa6"))


# with Session() as session:
#     dao_sync_sources.add_new_source(ss, session)
    