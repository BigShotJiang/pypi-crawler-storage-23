
from etiket_client.GUI.sync.app import launch_GUI


launch_GUI()