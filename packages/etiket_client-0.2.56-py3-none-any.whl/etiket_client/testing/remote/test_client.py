import unittest

from etiket_client.remote.authenticate import login, _refresh_token, logout

login(username = "test_user", password = "test")
_refresh_token()
logout()


