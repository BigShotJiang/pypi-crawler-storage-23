# Examples

Runnable Python examples for every major `deteqt` functionality.

## Setup

```zsh
uv venv .venv --python 3.13
source .venv/bin/activate
uv pip install -e . --group all
```

## Run

Run from repository root:

```zsh
uv run --active python examples/00_settings_create_and_load.py --help
```

### Script map

- `00_settings_create_and_load.py`: create `settings.toml` and load it.
- `01_write_point.py`: write one record with `write_point`.
- `02_write_batch.py`: write multiple records with `write_batch`.
- `03_ingest_preview_matches.py`: preview recursive QoI/snapshot matching.
- `04_ingest_process_write.py`: manual pipeline (`ingest_data` -> `process_data`
  -> `write_batch`).
- `05_ingest_and_write.py`: one-call recursive ingest and write.
- `06_build_query.py`: build a Flux query string with `build_query`.
- `07_query_structured.py`: run structured query helpers.
- `08_query_raw_flux.py`: run raw-Flux query helpers.
- `09_load_json_file_records.py`: load one JSON/snapshot file into records.

### Notebook map

Notebook equivalents are available in `examples/notebooks/`:

- `00_settings_create_and_load.ipynb`
- `01_write_point.ipynb`
- `02_write_batch.ipynb`
- `03_ingest_preview_matches.ipynb`
- `04_ingest_process_write.ipynb`
- `05_ingest_and_write.ipynb`
- `06_build_query.ipynb`
- `07_query_structured.ipynb`
- `08_query_raw_flux.ipynb`
- `09_load_json_file_records.ipynb`

Open with Jupyter:

```zsh
uv run --active jupyter lab
```

Notes:

- Pass `--settings-path` when your `settings.toml` is not in the current
  directory.
- Do not commit real write tokens.
