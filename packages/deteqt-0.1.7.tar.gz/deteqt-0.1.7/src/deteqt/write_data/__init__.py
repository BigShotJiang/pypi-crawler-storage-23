"""Write helpers for single-point and batch QOI data ingestion."""
