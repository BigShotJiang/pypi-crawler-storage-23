from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import datetime
import json
import logging
from pathlib import Path
from types import TracebackType
from typing import TypeAlias

from influxdb_client.client.influxdb_client import InfluxDBClient
from influxdb_client.client.write.point import Point
from influxdb_client.client.write_api import SYNCHRONOUS
from influxdb_client.rest import ApiException

from ..settings import InfluxSettings, load_settings

logger = logging.getLogger(__name__)

FieldValue: TypeAlias = str | int | float | bool
_NumericFieldValue: TypeAlias = int | float
PointTime: TypeAlias = str | int | float | datetime

QOI_KEY = "qoi"
TIME_KEY = "time"
QOI_TAG_KEYS = (
    "element",
    "label",
    "unit",
    "element_label",
    "device_ID",
    "run_ID",
    "cycle_ID",
    "condition",
)
QOI_FIELD_KEYS = (
    "nominal_value",
    "uncertainty",
    "tuid",
)
RESERVED_KEYS = frozenset((QOI_KEY, TIME_KEY, *QOI_TAG_KEYS, *QOI_FIELD_KEYS))
WriteRecord: TypeAlias = tuple[
    Mapping[str, object],
    Mapping[str, str] | None,
    Mapping[str, FieldValue] | None,
]


class InfluxWriteError(RuntimeError):
    """User-facing write error with actionable context."""


def _api_error_detail(error: ApiException) -> str | None:
    """Extract a compact detail message from an InfluxDB API error."""
    body = error.body
    if isinstance(body, bytes):
        body = body.decode("utf-8", errors="replace")

    if isinstance(body, str) and body.strip():
        raw = body.strip()
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError:
            return raw

        if isinstance(payload, dict):
            code = payload.get("code")
            message = payload.get("message")
            if isinstance(code, str) and code.strip():
                if isinstance(message, str) and message.strip():
                    return f"{code}: {message}"
                return code
            if isinstance(message, str) and message.strip():
                return message
        return raw

    if isinstance(error.reason, str) and error.reason.strip():
        return error.reason
    return None


def _friendly_write_error_message(error: Exception, settings: InfluxSettings) -> str:
    """Translate low-level client errors into user-friendly write guidance."""
    if isinstance(error, ApiException):
        detail = _api_error_detail(error)
        status = error.status

        if status == 401:
            return (
                "Write rejected (401 unauthorized). "
                "Check settings.toml values (`url`, `org`, `bucket`, `token`) and "
                "use a write-capable token for this org/bucket."
            )
        if status == 403:
            return (
                "Write rejected (403 forbidden). "
                "Token is valid but lacks permission for this org/bucket."
            )
        if status == 404:
            return (
                "Write rejected (404 not found). "
                f"Bucket/org mismatch for bucket='{settings.bucket}', org='{settings.org}'."
            )
        if status == 422:
            suffix = f" Detail: {detail}" if detail else ""
            return f"Write rejected (422 invalid point format).{suffix}"

        suffix = f" Detail: {detail}" if detail else ""
        return f"Write failed with InfluxDB API error (HTTP {status}).{suffix}"

    raw_message = str(error)
    lowered = raw_message.lower()
    if "timed out" in lowered:
        return (
            "Write timed out before server confirmation. "
            f"Increase `timeout_ms` in settings.toml (current={settings.timeout_ms}) "
            "or check server/network latency. "
            f"Original error: {raw_message}"
        )

    return f"Write failed before server confirmation: {raw_message}"


def _as_clean_string(value: object, field_name: str) -> str:
    """Validate and normalize a required non-empty string.

    Parameters
    ----------
    value : object
        Candidate value.
    field_name : str
        Field name for error messages.

    Returns
    -------
    str
        Stripped string value.

    Raises
    ------
    ValueError
        If value is not a non-empty string.
    """
    if not isinstance(value, str) or not value.strip():
        logger.error("Invalid string value for '%s'.", field_name)
        raise ValueError(f"'{field_name}' must be a non-empty string.")
    return value.strip()


def _validate_field_value(key: str, value: object) -> FieldValue:
    """Validate a field value type.

    Parameters
    ----------
    key : str
        Field name.
    value : object
        Field value.

    Returns
    -------
    FieldValue
        Validated value.

    Raises
    ------
    ValueError
        If value type is not supported.
    """
    if not isinstance(value, (str, int, float, bool)):
        logger.error("Unsupported field type for '%s': %s", key, type(value))
        raise ValueError(f"Field '{key}' has unsupported value type: {type(value)}")
    return value


def _validate_numeric_field_value(key: str, value: object) -> _NumericFieldValue:
    """Validate numeric field values for strict schema fields."""
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        logger.error("Invalid numeric value for '%s': %s", key, type(value))
        raise ValueError(f"'{key}' must be an int or float.")
    return value


def _normalize_point_time(value: object) -> PointTime:
    """Normalize optional point time to supported InfluxDB types."""
    if isinstance(value, datetime):
        return value
    if isinstance(value, bool):
        raise ValueError("'time' must be datetime, RFC3339 string, int, or float.")
    if isinstance(value, (str, int, float)):
        return value
    raise ValueError("'time' must be datetime, RFC3339 string, int, or float.")


def _normalize_extra_tags(extra_tags: Mapping[str, str] | None) -> dict[str, str]:
    """Normalize and validate extra tag mappings.

    Parameters
    ----------
    extra_tags : Mapping[str, str] | None
        Extra tag mapping.

    Returns
    -------
    dict[str, str]
        Normalized tag mapping.

    Raises
    ------
    ValueError
        If keys collide with reserved keys or contain invalid strings.
    """
    if extra_tags is None:
        return {}

    normalized: dict[str, str] = {}
    for key, value in extra_tags.items():
        clean_key = _as_clean_string(key, "extra tag key")
        if clean_key in RESERVED_KEYS:
            logger.error("Extra tag '%s' conflicts with reserved keys.", clean_key)
            raise ValueError(
                f"Extra tag '{clean_key}' conflicts with built-in keys. "
                "Use built-in arguments/record keys for standard fields."
            )
        normalized[clean_key] = _as_clean_string(value, f"extra tag '{clean_key}'")
    logger.debug("Normalized %d extra tags.", len(normalized))
    return normalized


def _normalize_extra_fields(
    extra_fields: Mapping[str, FieldValue] | None,
) -> dict[str, FieldValue]:
    """Normalize and validate extra field mappings.

    Parameters
    ----------
    extra_fields : Mapping[str, FieldValue] | None
        Extra field mapping.

    Returns
    -------
    dict[str, FieldValue]
        Normalized field mapping.

    Raises
    ------
    ValueError
        If keys collide with reserved keys or values are invalid.
    """
    if extra_fields is None:
        return {}

    normalized: dict[str, FieldValue] = {}
    for key, value in extra_fields.items():
        clean_key = _as_clean_string(key, "extra field key")
        if clean_key in RESERVED_KEYS:
            logger.error("Extra field '%s' conflicts with reserved keys.", clean_key)
            raise ValueError(
                f"Extra field '{clean_key}' conflicts with built-in keys. "
                "Use built-in arguments/record keys for standard fields."
            )
        normalized[clean_key] = _validate_field_value(clean_key, value)
    logger.debug("Normalized %d extra fields.", len(normalized))
    return normalized


def build_point(
    *,
    record: Mapping[str, object],
    default_tags: Mapping[str, str],
    extra_tags: Mapping[str, str] | None,
    extra_fields: Mapping[str, FieldValue] | None,
) -> Point:
    """Build an InfluxDB ``Point`` from one standard record.

    Parameters
    ----------
    record : Mapping[str, object]
        Standard record containing reserved QOI keys only.
        Optional ``time`` can be provided for idempotent retry workflows.
    default_tags : Mapping[str, str]
        Tags applied to every point.
    extra_tags : Mapping[str, str] | None
        Optional user-defined tag mapping.
    extra_fields : Mapping[str, FieldValue] | None
        Optional user-defined field mapping.

    Returns
    -------
    Point
        InfluxDB point ready to be written.

    Raises
    ------
    ValueError
        If record contains unknown keys, invalid values, or is missing
        required ``nominal_value``.
    """
    logger.debug("Building point from record with %d keys.", len(record))

    unknown_keys = [key for key in record if key not in RESERVED_KEYS]
    if unknown_keys:
        unknown = ", ".join(sorted(unknown_keys))
        logger.error("Unknown record keys: %s", unknown)
        raise ValueError(
            f"Unknown record keys: {unknown}. "
            "Use extra_tags / extra_fields for custom keys."
        )

    measurement = _as_clean_string(record.get(QOI_KEY), QOI_KEY)
    point = Point(measurement)

    point_time = record.get(TIME_KEY)
    if point_time is not None:
        point.time(_normalize_point_time(point_time))

    merged_tags: dict[str, str] = dict(default_tags)
    for key in QOI_TAG_KEYS:
        value = record.get(key)
        if value is None:
            continue
        merged_tags[key] = _as_clean_string(value, key)
    merged_tags.update(_normalize_extra_tags(extra_tags))

    for key, value in merged_tags.items():
        point.tag(key, value)

    nominal_value = record.get("nominal_value")
    if nominal_value is None:
        logger.error("Write rejected: required field 'nominal_value' is missing.")
        raise ValueError("Record must include required field 'nominal_value'.")
    point.field(
        "nominal_value", _validate_numeric_field_value("nominal_value", nominal_value)
    )

    uncertainty = record.get("uncertainty")
    if uncertainty is not None:
        point.field(
            "uncertainty", _validate_numeric_field_value("uncertainty", uncertainty)
        )

    tuid = record.get("tuid")
    if tuid is not None:
        point.field("tuid", _as_clean_string(tuid, "tuid"))

    for key, value in _normalize_extra_fields(extra_fields).items():
        point.field(key, value)

    return point


class InfluxWriter:
    """Thin wrapper around the InfluxDB client for synchronous writes.

    Parameters
    ----------
    settings : InfluxSettings
        Validated InfluxDB settings.
    """

    def __init__(self, settings: InfluxSettings) -> None:
        """Initialize writer state and client handles.

        Parameters
        ----------
        settings : InfluxSettings
            Validated InfluxDB settings.
        """
        logger.debug(
            "Initializing InfluxWriter for org='%s', bucket='%s'.",
            settings.org,
            settings.bucket,
        )
        self.settings = settings
        self._client = InfluxDBClient(
            url=settings.url,
            token=settings.token,
            org=settings.org,
            timeout=settings.timeout_ms,
        )
        self._write_api = self._client.write_api(write_options=SYNCHRONOUS)

    @classmethod
    def from_toml(cls, path: str | Path | None = None) -> InfluxWriter:
        """Create a writer from a TOML settings file.

        Parameters
        ----------
        path : str | Path | None, default=None
            Path to settings file. If ``None``, uses ``settings.toml``.

        Returns
        -------
        InfluxWriter
            Initialized writer instance.
        """
        return cls(load_settings(path))

    def write_record(
        self,
        record: Mapping[str, object],
        *,
        extra_tags: Mapping[str, str] | None = None,
        extra_fields: Mapping[str, FieldValue] | None = None,
    ) -> None:
        """Write one standard record.

        Parameters
        ----------
        record : Mapping[str, object]
            Standard record to write.
        extra_tags : Mapping[str, str] | None, default=None
            Extra tags to merge into the point.
        extra_fields : Mapping[str, FieldValue] | None, default=None
            Extra fields to merge into the point.

        Raises
        ------
        ValueError
            If record or extras fail validation.
        """
        point = build_point(
            record=record,
            default_tags=self.settings.default_tags,
            extra_tags=extra_tags,
            extra_fields=extra_fields,
        )
        try:
            self._write_api.write(
                bucket=self.settings.bucket,
                org=self.settings.org,
                record=point,
            )
        except Exception as error:
            message = _friendly_write_error_message(error, self.settings)
            logger.error(message)
            raise InfluxWriteError(message) from None

    def write_records(
        self,
        records: Iterable[WriteRecord],
    ) -> None:
        """Write multiple records in one request."""
        points: list[Point] = []
        for record, extra_tags, extra_fields in records:
            points.append(
                build_point(
                    record=record,
                    default_tags=self.settings.default_tags,
                    extra_tags=extra_tags,
                    extra_fields=extra_fields,
                )
            )
        if not points:
            return
        try:
            self._write_api.write(
                bucket=self.settings.bucket,
                org=self.settings.org,
                record=points,
            )
        except Exception as error:
            message = _friendly_write_error_message(error, self.settings)
            logger.error(message)
            raise InfluxWriteError(message) from None

    def close(self) -> None:
        """Close the underlying InfluxDB client."""
        self._client.close()

    def __enter__(self) -> InfluxWriter:
        """Return self for context-manager usage.

        Returns
        -------
        InfluxWriter
            Current writer instance.
        """
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: TracebackType | None,
    ) -> None:
        """Close resources at context-manager exit.

        Parameters
        ----------
        exc_type : type[BaseException] | None
            Exception type if one occurred.
        exc : BaseException | None
            Exception instance if one occurred.
        tb : TracebackType | None
            Exception traceback if one occurred.
        """
        self.close()
