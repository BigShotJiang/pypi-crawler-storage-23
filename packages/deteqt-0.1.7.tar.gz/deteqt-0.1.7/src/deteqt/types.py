"""Project-local type definitions."""

from __future__ import annotations

from typing import NewType

TUID = NewType("TUID", str)
"""Timestamp-based unique identifier.

Notes
-----
This is a lightweight, local typing marker used for static type checking.
Runtime values remain plain strings.
"""
