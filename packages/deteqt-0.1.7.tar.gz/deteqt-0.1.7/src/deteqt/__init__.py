import logging
from importlib.metadata import PackageNotFoundError, version

from .ingest_data import (
    debug_ingest_matches,
    ingest_and_write,
    ingest_data,
    process_data,
)
from .query_data import (
    QueryResultMeta,
    build_query,
    query_flux_rows,
    query_flux_rows_with_meta,
    query_flux_stream,
    query_rows,
    query_rows_with_meta,
    query_stream,
)
from .settings import InfluxSettings, load_settings, write_settings_file
from .types import TUID
from .write_data.write_batch import write_batch
from .write_data.write_point import write_point
from .write_data.writer import InfluxWriteError

logging.getLogger(__name__).addHandler(logging.NullHandler())

try:
    __version__ = version("deteqt")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "__version__",
    "InfluxSettings",
    "QueryResultMeta",
    "build_query",
    "debug_ingest_matches",
    "ingest_and_write",
    "ingest_data",
    "load_settings",
    "process_data",
    "query_flux_rows",
    "query_flux_rows_with_meta",
    "query_flux_stream",
    "query_rows",
    "query_rows_with_meta",
    "query_stream",
    "write_settings_file",
    "write_batch",
    "write_point",
    "TUID",
    "InfluxWriteError",
]
