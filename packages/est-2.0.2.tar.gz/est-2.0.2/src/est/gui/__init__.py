"""est graphical user interface module"""
