"""est core module. Contains core features. It must stay Qt free"""
