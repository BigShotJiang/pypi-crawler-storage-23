"""est settings"""

DEFAULT_READ_TIMEOUT = 1.0  # default timeout to read files
