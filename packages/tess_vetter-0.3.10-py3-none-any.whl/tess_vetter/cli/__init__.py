"""CLI entrypoints for tess-vetter.

These modules are primarily intended for subprocess-safe execution from host
applications (e.g. MCP tools) to isolate optional runtimes like MLX/Metal.
"""
