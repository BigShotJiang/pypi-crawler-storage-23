"""Branch diff layer."""
