# OpenIRF: An Open-Source Package for Impulse Response Function Estimation

A collection of tools for the time domain analysis of mechanical systems.

## Installation

To install OpenIRF through pip, use the following command:

`pip install openirf`
