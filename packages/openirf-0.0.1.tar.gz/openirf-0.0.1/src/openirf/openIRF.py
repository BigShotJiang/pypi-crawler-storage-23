import numpy as np
import scipy as sp

class OpenIRF:
    """
    OpenIRF: An Open-Source Package for Impulse Response Function Estimation

    """
    def __init__(self):
        print('Init.')