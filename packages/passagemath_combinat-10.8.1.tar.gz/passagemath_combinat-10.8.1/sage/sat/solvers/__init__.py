# sage_setup: distribution = sagemath-combinat
from sage.sat.solvers.cryptominisat import CryptoMiniSat
from sage.sat.solvers.dimacs import Glucose, GlucoseSyrup, Kissat, RSat
from sage.sat.solvers.satsolver import SatSolver
