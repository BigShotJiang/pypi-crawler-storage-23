# Quick Start Guide

## 🚀 Fast Setup (5 minutes)

### Option 1: Automated Setup (Recommended)

```bash
cd /Users/narunaskapocius/repos/github/castai-mcp-external

# Run the setup script
./setup_claude_desktop.sh YOUR_API_KEY_HERE
```

The script will:
- ✅ Configure Claude Desktop automatically
- ✅ Backup existing config
- ✅ Validate configuration
- ✅ Test the server

### Option 2: Manual Setup

1. **Get API Key** from https://console.cast.ai → Settings → API Keys

2. **Edit Claude Desktop Config:**
   ```bash
   # macOS
   code ~/Library/Application\ Support/Claude/claude_desktop_config.json
   ```

3. **Add this configuration:**
   ```json
   {
     "mcpServers": {
       "castai": {
         "command": "uv",
         "args": [
           "--directory",
           "/Users/narunaskapocius/repos/github/castai-mcp-external",
           "run",
           "python",
           "main.py"
         ],
         "env": {
           "CASTAI_API_KEY": "YOUR_API_KEY_HERE"
         }
       }
     }
   }
   ```

4. **Restart Claude Desktop** (Cmd+Q, then relaunch)

---

## ✅ Test It Works

After restarting Claude Desktop, try these queries:

```
Show me all my Kubernetes clusters
```

```
What are the details of my production cluster?
```

```
What's the optimization score for my main cluster?
```

---

## 🔧 Troubleshooting

### Server not showing up?

```bash
# Check logs (macOS)
tail -f ~/Library/Logs/Claude/mcp*.log

# Test manually
export CASTAI_API_KEY="your-key"
uv run python main.py
```

### Authentication error?

- Verify API key is correct in config file
- Check key hasn't expired at console.cast.ai
- Try creating a new API key

---

## 📚 Full Documentation

- **Detailed Setup:** [CLAUDE_DESKTOP_SETUP.md](CLAUDE_DESKTOP_SETUP.md)
- **User Guide:** [README.md](README.md)
- **Implementation Details:** [IMPLEMENTATION.md](IMPLEMENTATION.md)

---

## 🎯 Available Tools

1. **list_clusters** - List all your clusters
2. **get_cluster_details** - Get cluster details
3. **get_cluster_policies** - View policies
4. **get_cluster_score** - Get optimization score
5. **get_cluster_score_history** - View score history

---

## 💡 Example Queries

| What you want | Ask Claude |
|---------------|------------|
| See all clusters | "Show me all my Kubernetes clusters" |
| Cluster details | "What are the details of cluster X?" |
| Check policies | "What policies are configured for my staging cluster?" |
| Optimization score | "What's the cluster score for production?" |
| Compare clusters | "Which of my clusters has the best optimization score?" |
| Score trends | "Show me the cluster score history for my main cluster" |

---

**Need help?** Check [CLAUDE_DESKTOP_SETUP.md](CLAUDE_DESKTOP_SETUP.md) for detailed troubleshooting.