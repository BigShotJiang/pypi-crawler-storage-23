"""Tools for CAST.AI MCP Server."""
