#!/bin/bash
# Test script for CAST.AI MCP server startup
# Usage: ./test_startup.sh YOUR_API_KEY

if [ -z "$1" ]; then
    echo "Usage: ./test_startup.sh YOUR_API_KEY"
    echo ""
    echo "Or set environment variable:"
    echo "  export CASTAI_API_KEY='your-key-here'"
    echo "  ./test_startup.sh"
    exit 1
fi

API_KEY="${1:-$CASTAI_API_KEY}"

echo "=================================================="
echo "Testing CAST.AI MCP Server Startup"
echo "=================================================="
echo ""
echo "Setting API key..."
export CASTAI_API_KEY="$API_KEY"

echo "Starting server (press Ctrl+C to stop)..."
echo ""
uv run python main.py
