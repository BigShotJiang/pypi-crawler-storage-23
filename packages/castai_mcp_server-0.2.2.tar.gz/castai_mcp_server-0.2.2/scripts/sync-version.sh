#!/bin/bash
# Sync version between pyproject.toml and package.json

set -e

if [ -z "$1" ]; then
  echo "Usage: ./scripts/sync-version.sh <version>"
  echo "Example: ./scripts/sync-version.sh 0.2.0"
  exit 1
fi

VERSION=$1

# Validate version format (semver)
if ! [[ $VERSION =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "Error: Version must be in format X.Y.Z (e.g., 0.2.0)"
  exit 1
fi

echo "Updating version to $VERSION..."

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_ROOT"

# Update pyproject.toml
if [[ "$OSTYPE" == "darwin"* ]]; then
  # macOS
  sed -i '' "s/^version = .*/version = \"$VERSION\"/" pyproject.toml
else
  # Linux
  sed -i "s/^version = .*/version = \"$VERSION\"/" pyproject.toml
fi

# Update package.json
if [[ "$OSTYPE" == "darwin"* ]]; then
  # macOS
  sed -i '' "s/\"version\": \"[^\"]*\"/\"version\": \"$VERSION\"/" package.json
else
  # Linux
  sed -i "s/\"version\": \"[^\"]*\"/\"version\": \"$VERSION\"/" package.json
fi

echo "✓ Updated version to $VERSION in:"
echo "  - pyproject.toml"
echo "  - package.json"
echo ""
echo "Next steps:"
echo "  1. Review changes: git diff"
echo "  2. Commit: git add pyproject.toml package.json && git commit -m 'Bump version to $VERSION'"
echo "  3. Tag: git tag v$VERSION"
echo "  4. Push: git push origin main --tags"
echo "  5. Publish: See PUBLISHING.md for details"