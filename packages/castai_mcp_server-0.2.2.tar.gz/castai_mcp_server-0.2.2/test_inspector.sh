#!/bin/bash
# Test script for CAST.AI MCP server with MCP Inspector
# Usage: ./test_inspector.sh YOUR_API_KEY

if [ -z "$1" ] && [ -z "$CASTAI_API_KEY" ]; then
    echo "Usage: ./test_inspector.sh YOUR_API_KEY"
    echo ""
    echo "Or set environment variable:"
    echo "  export CASTAI_API_KEY='your-key-here'"
    echo "  ./test_inspector.sh"
    exit 1
fi

API_KEY="${1:-$CASTAI_API_KEY}"

echo "=================================================="
echo "Testing CAST.AI MCP Server with Inspector"
echo "=================================================="
echo ""
echo "This will:"
echo "1. Start the MCP server with your API key"
echo "2. Launch a web UI at http://localhost:5173"
echo "3. Let you test all 5 cluster tools interactively"
echo ""
echo "Press Ctrl+C to stop when done testing."
echo ""
read -p "Press Enter to continue..."

export CASTAI_API_KEY="$API_KEY"
npx @modelcontextprotocol/inspector uv --directory $(pwd) run python main.py
