"""Lifespan manager: start and stop DependencyHealth together with FastAPI."""

from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI

from dephealth.api import DependencyHealth, _DependencySpec


def dephealth_lifespan(
    name: str,
    group: str,
    *specs: _DependencySpec,
    **kwargs: Any,  # noqa: ANN401
) -> object:
    """Lifespan factory for FastAPI.

    Returns a callable compatible with ``FastAPI(lifespan=...)``.

    Example::

        app = FastAPI(lifespan=dephealth_lifespan(
            "my-service",
            "my-team",
            http_check("payment", url="http://payment:8080", critical=True),
            postgres_check("db", url="postgres://db:5432/mydb", critical=True),
        ))
    """

    @asynccontextmanager
    async def _lifespan(app: FastAPI) -> AsyncIterator[dict[str, Any]]:
        dh = DependencyHealth(name, group, *specs, **kwargs)
        app.state.dephealth = dh
        await dh.start()
        try:
            yield {"dephealth": dh}
        finally:
            await dh.stop()

    return _lifespan
