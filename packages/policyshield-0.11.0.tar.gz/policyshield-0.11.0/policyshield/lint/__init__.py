"""Rule linter for PolicyShield — static analysis of YAML rules."""

from policyshield.lint.linter import LintWarning, RuleLinter

__all__ = ["RuleLinter", "LintWarning"]
