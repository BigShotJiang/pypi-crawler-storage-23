"""DevNarrate - MCP server for developer workflow automation."""

__version__ = "0.1.0a6"
