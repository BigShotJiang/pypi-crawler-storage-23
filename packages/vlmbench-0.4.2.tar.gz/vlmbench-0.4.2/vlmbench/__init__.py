from vlmbench.cli import VERSION as __version__

__all__ = ["__version__"]
