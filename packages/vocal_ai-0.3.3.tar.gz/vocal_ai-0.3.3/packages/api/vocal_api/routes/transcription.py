from typing import Annotated

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile

from ..config import settings
from ..dependencies import get_transcription_service
from ..models.transcription import (
    TranscriptionFormat,
    TranscriptionRequest,
    TranscriptionResponse,
)
from ..services import TranscriptionService

router = APIRouter(prefix="/v1/audio", tags=["transcription"])


@router.post(
    "/transcriptions",
    response_model=TranscriptionResponse,
    summary="Transcribe audio",
    description="Transcribe audio file to text using specified model",
)
async def create_transcription(
    file: Annotated[UploadFile, File(description="Audio file to transcribe")],
    model: Annotated[str, Form(description="Model ID")] = "Systran/faster-whisper-tiny",
    language: Annotated[str | None, Form(description="Language code")] = None,
    prompt: Annotated[str | None, Form(description="Style prompt")] = None,
    response_format: Annotated[TranscriptionFormat, Form(description="Output format")] = TranscriptionFormat.JSON,
    temperature: Annotated[float, Form(ge=0.0, le=1.0)] = 0.0,
    service: TranscriptionService = Depends(get_transcription_service),
) -> TranscriptionResponse:
    """
    Transcribe an audio file.

    **Supported formats:** mp3, mp4, wav, m4a, flac, ogg, webm
    **Max file size:** 25MB

    Returns transcription with optional word/segment timestamps.
    """
    file.file.seek(0, 2)
    size = file.file.tell()
    file.file.seek(0)

    if size > settings.MAX_UPLOAD_SIZE:
        raise HTTPException(400, f"File too large. Max {settings.MAX_UPLOAD_SIZE // (1024 * 1024)}MB.")

    request = TranscriptionRequest(
        model=model,
        language=language,
        prompt=prompt,
        response_format=response_format,
        temperature=temperature,
    )

    try:
        result = await service.transcribe(file, request)
        return result
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, f"Transcription failed: {str(e)}")


@router.post(
    "/translations",
    response_model=TranscriptionResponse,
    summary="Translate audio to English",
    description="Translate audio to English text",
)
async def create_translation(
    file: Annotated[UploadFile, File()],
    model: Annotated[str, Form()] = "Systran/faster-whisper-tiny",
    service: TranscriptionService = Depends(get_transcription_service),
) -> TranscriptionResponse:
    """Translate audio to English."""
    try:
        return await service.translate(file, model)
    except ValueError as e:
        raise HTTPException(400, str(e))
    except Exception as e:
        raise HTTPException(500, f"Translation failed: {str(e)}")
