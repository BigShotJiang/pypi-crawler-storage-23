import pyaudio
from orpheus_tts import OrpheusClient
import time

client = OrpheusClient(
    custom_endpoint="wss://canopy-labs--production-amu-voice-orpheus-v1-flash-nogat-93078b.us-west.modal.direct/ws/tts",
    voices=["amucx"],
)


client.connect()   

# Initialize PyAudio
p = pyaudio.PyAudio()
stream = p.open(
    format=pyaudio.paInt16,
    channels=1,
    rate=48000,
    output=True
)
first_chunk = True
prompt = "No that makes a lot of sense actually, and I'm glad you're bringing it up."
# Stream and play
start_time = time.perf_counter()
for chunk in client.stream(prompt, voice="amucx", temperature=1.98, repetition_penalty=1.05):
    if first_chunk:
        first_chunk = False
        print(f"Time to first chunk: {(time.perf_counter() - start_time) * 1000} milliseconds")
        continue
    stream.write(chunk)
stream.stop_stream()
stream.close()
p.terminate()
print(f"Total time: {(time.perf_counter() - start_time) * 1000} milliseconds")