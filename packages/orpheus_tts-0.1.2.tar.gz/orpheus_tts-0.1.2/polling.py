"""Poll every TTS endpoint every 15 seconds by sending a real request to keep them warm."""

import asyncio
import json
import time
import datetime

import websockets

_DEFAULT_POOL_SIZE = 1

# All unique WebSocket endpoints and a representative voice for each
_ENDPOINT_VOICES = {
    "endpoint_1":  ("wss://canopy-labs--production-group1-orpheus-v1-flash-nogatewa-c93837.us-west.modal.direct/ws/tts", "colin"),
    "endpoint_2":  ("wss://canopy-labs--production-group2-orpheus-v1-flash-nogatewa-7046d3.us-west.modal.direct/ws/tts", "dawn"),
    "endpoint_3":  ("wss://canopy-labs--production-group3-orpheus-v1-flash-nogatewa-0f7098.us-west.modal.direct/ws/tts", "pete"),
    "endpoint_4":  ("wss://canopy-labs--production-group4-orpheus-v1-flash-nogatewa-283527.us-west.modal.direct/ws/tts", "nathan"),
    "endpoint_5":  ("wss://canopy-labs--production-group5-orpheus-v1-flash-nogatewa-d1b42d.us-west.modal.direct/ws/tts", "diana"),
    "endpoint_6":  ("wss://canopy-labs--production-group6-orpheus-v1-flash-nogatewa-fa0042.us-west.modal.direct/ws/tts", "will"),
    "endpoint_7":  ("wss://canopy-labs--production-group7-orpheus-v1-flash-nogatewa-e66d47.us-west.modal.direct/ws/tts", "marco"),
    "endpoint_8":  ("wss://canopy-labs--production-group8-orpheus-v1-flash-nogatewa-6943c9.us-west.modal.direct/ws/tts", "max"),
    "endpoint_9":  ("wss://canopy-labs--production-group9-orpheus-v1-flash-nogatewa-7048a5.us-west.modal.direct/ws/tts", "kenji"),
    "endpoint_10": ("wss://canopy-labs--production-group10-orpheus-v1-flash-nogatew-84e8df.us-west.modal.direct/ws/tts", "alexei"),
    "endpoint_11": ("wss://canopy-labs--production-arabic-sawt-orpheus-v1-flash-nog-1cce8c.us-west.modal.direct/ws/tts", "aleen"),
}

POLL_INTERVAL = 15  # seconds
WARMUP_TEXT = "Hello. This is a warmup request."


async def _poll_endpoint(name: str, ws_url: str, voice: str) -> None:
    """Connect, send a short TTS request, measure TTFA, then drain and close."""
    try:
        ws = await asyncio.wait_for(
            websockets.connect(
                ws_url,
                max_size=16 * 1024 * 1024,
                ping_interval=None,
                close_timeout=5,
            ),
            timeout=10,
        )
    except Exception as e:
        print(f"[FAIL] {name:>12}  connect error: {e}")
        return

    try:
        request_body = {
            "prompt": WARMUP_TEXT,
            "voice": voice,
            "max_tokens": 200,
            "temperature": 1.0,
            "repetition_penalty": 1.1,
            "top_k": 20,
        }

        t_send = time.perf_counter()
        await ws.send(json.dumps(request_body))

        ttfa = None
        async for message in ws:
            if isinstance(message, bytes):
                if ttfa is None:
                    ttfa = (time.perf_counter() - t_send) * 1000  # ms
                # Keep draining so the server finishes cleanly
                continue
            else:
                try:
                    data = json.loads(message)
                    if data.get("done"):
                        break
                    if "error" in data:
                        print(f"[FAIL] {name:>12}  server error: {data['error']}")
                        return
                except json.JSONDecodeError:
                    pass

        if ttfa is not None:
            print(f"[OK]   {name:>12}  voice={voice:<8}  TTFA={ttfa:>7.0f}ms")
        else:
            print(f"[WARN] {name:>12}  no audio received")

    except Exception as e:
        print(f"[FAIL] {name:>12}  stream error: {e}")
    finally:
        await ws.close()


async def poll_all() -> None:
    """Send a real TTS request to every endpoint concurrently."""
    tasks = [
        _poll_endpoint(name, ws_url, voice)
        for name, (ws_url, voice) in _ENDPOINT_VOICES.items()
    ]
    await asyncio.gather(*tasks)


async def main() -> None:
    print(f"Polling {len(_ENDPOINT_VOICES)} endpoints every {POLL_INTERVAL}s to keep them warm...\n")
    while True:
        now = datetime.datetime.now().strftime("%H:%M:%S")
        print(f"--- {now} ---")
        await poll_all()
        print()
        await asyncio.sleep(POLL_INTERVAL)


if __name__ == "__main__":
    asyncio.run(main())
