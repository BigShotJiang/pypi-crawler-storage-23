"""Orpheus TTS Client - Stream speech from the Orpheus model."""

from __future__ import annotations

import asyncio
import json
import queue
import threading
import urllib.request
from typing import AsyncIterator, Iterator, Optional
from urllib.parse import urlparse, urlunparse

try:
    import websockets
    from websockets.exceptions import ConnectionClosed
except ImportError:
    raise ImportError(
        "websockets package is required. Install with: pip install orpheus-tts"
    )

from orpheus_tts.exceptions import (
    AuthenticationError,
    ConnectionError,
    OrpheusError,
    StreamingError,
)

# Internal endpoints - hidden from users
_VOICE_ENDPOINTS = {
    "endpoint_1": "wss://canopy-labs--production-group1-orpheus-v1-flash-nogatewa-c93837.us-west.modal.direct/ws/tts",
    # "endpoint_1": "ws://195.242.13.0:8003/ws/tts",
    "endpoint_2": "wss://canopy-labs--production-group2-orpheus-v1-flash-nogatewa-7046d3.us-west.modal.direct/ws/tts",
    "endpoint_3": "wss://canopy-labs--production-group3-orpheus-v1-flash-nogatewa-0f7098.us-west.modal.direct/ws/tts",
    "endpoint_4": "wss://canopy-labs--production-group4-orpheus-v1-flash-nogatewa-283527.us-west.modal.direct/ws/tts",
    "endpoint_5": "wss://canopy-labs--production-group5-orpheus-v1-flash-nogatewa-d1b42d.us-west.modal.direct/ws/tts",
    "endpoint_6": "wss://canopy-labs--production-group6-orpheus-v1-flash-nogatewa-fa0042.us-west.modal.direct/ws/tts",
    "endpoint_7": "wss://canopy-labs--production-group7-orpheus-v1-flash-nogatewa-e66d47.us-west.modal.direct/ws/tts",
    "endpoint_8": "wss://canopy-labs--production-group8-orpheus-v1-flash-nogatewa-6943c9.us-west.modal.direct/ws/tts",
    "endpoint_9": "wss://canopy-labs--production-group9-orpheus-v1-flash-nogatewa-7048a5.us-west.modal.direct/ws/tts",
    "endpoint_10": "wss://canopy-labs--production-group10-orpheus-v1-flash-nogatew-84e8df.us-west.modal.direct/ws/tts",
    "endpoint_11": "wss://canopy-labs--production-arabic-sawt-orpheus-v1-flash-nog-1cce8c.us-west.modal.direct/ws/tts",
}

# Display name -> endpoint mapping (users only see display names)
_VOICE_ENDPOINT_MAP = {
    # group1
    "colin": _VOICE_ENDPOINTS["endpoint_1"],
    # group2
    "dawn": _VOICE_ENDPOINTS["endpoint_2"],
    # group3
    "pete": _VOICE_ENDPOINTS["endpoint_3"],
    "zoe": _VOICE_ENDPOINTS["endpoint_3"],
    "andy": _VOICE_ENDPOINTS["endpoint_3"],
    "summer": _VOICE_ENDPOINTS["endpoint_3"],
    # group4
    "nathan": _VOICE_ENDPOINTS["endpoint_4"],
    "kai": _VOICE_ENDPOINTS["endpoint_4"],
    "dylan": _VOICE_ENDPOINTS["endpoint_4"],
    "audrey": _VOICE_ENDPOINTS["endpoint_4"],
    # group5
    "diana": _VOICE_ENDPOINTS["endpoint_5"],
    "alexis": _VOICE_ENDPOINTS["endpoint_5"],
    "michael": _VOICE_ENDPOINTS["endpoint_5"],
    "grace": _VOICE_ENDPOINTS["endpoint_5"],
    "brian": _VOICE_ENDPOINTS["endpoint_5"],
    # group6
    "will": _VOICE_ENDPOINTS["endpoint_6"],
    "melissa": _VOICE_ENDPOINTS["endpoint_6"],
    # group7
    "marco": _VOICE_ENDPOINTS["endpoint_7"],
    "nova": _VOICE_ENDPOINTS["endpoint_7"],
    "leo": _VOICE_ENDPOINTS["endpoint_7"],
    "santiago": _VOICE_ENDPOINTS["endpoint_7"],
    "sofia": _VOICE_ENDPOINTS["endpoint_7"],
    # group8
    "max": _VOICE_ENDPOINTS["endpoint_8"],
    "anna": _VOICE_ENDPOINTS["endpoint_8"],
    # group9
    "kenji": _VOICE_ENDPOINTS["endpoint_9"],
    "yuki": _VOICE_ENDPOINTS["endpoint_9"],
    "luke": _VOICE_ENDPOINTS["endpoint_9"],
    "jennie": _VOICE_ENDPOINTS["endpoint_9"],
    "lily": _VOICE_ENDPOINTS["endpoint_9"],
    "kevin": _VOICE_ENDPOINTS["endpoint_9"],
    # group10
    "alexei": _VOICE_ENDPOINTS["endpoint_10"],
    "claire": _VOICE_ENDPOINTS["endpoint_10"],
    "gautam": _VOICE_ENDPOINTS["endpoint_10"],
    "antoine": _VOICE_ENDPOINTS["endpoint_10"],
    
    # group11
    "aleen": _VOICE_ENDPOINTS["endpoint_11"],
}

_DEFAULT_POOL_SIZE = 16


def _get_endpoint(voice: str) -> str:
    """Resolve a display voice name to its WebSocket endpoint URL.

    Raises:
        ValueError: If the voice is not recognized.
    """
    key = voice.lower().strip()
    try:
        return _VOICE_ENDPOINT_MAP[key]
    except KeyError:
        valid = ", ".join(
            name.capitalize() for name in sorted(_VOICE_ENDPOINT_MAP.keys())
        )
        raise ValueError(
            f"Unknown voice '{voice}'. Valid voices: {valid}"
        )


def _get_health_url(endpoint: str) -> str:
    """Convert a WSS endpoint URL to its HTTPS /health URL."""
    parsed = urlparse(endpoint)
    scheme = "https" if parsed.scheme == "wss" else "http"
    return urlunparse((scheme, parsed.netloc, "/health", "", "", ""))


def _fire_health_ping(url: str) -> None:
    """Send a fire-and-forget GET to the health endpoint (runs in thread pool)."""
    try:
        urllib.request.urlopen(url, timeout=5)
    except Exception:
        pass


# Audio format constants
SAMPLE_RATE = 48000  # Hz
SAMPLE_WIDTH = 2  # bytes (int16)
CHANNELS = 1  # mono


class OrpheusClient:
    """
    Client for streaming speech from the Orpheus TTS model.

    Example:
        >>> from orpheus_tts import OrpheusClient
        >>>
        >>> # Option 1: Auto-connect (includes connection time in first request)
        >>> client = OrpheusClient()
        >>> for chunk in client.stream("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)
        >>>
        >>> # Option 2: Pre-connect for lowest latency (recommended)
        >>> client = OrpheusClient()
        >>> client.connect()  # Pool of 16 connections per endpoint
        >>> for chunk in client.stream("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)  # TTFA excludes handshake!
        >>> client.close()
        >>>
        >>> # Option 3: Async usage (same pool, same connect)
        >>> client = OrpheusClient()
        >>> client.connect()
        >>> async for chunk in client.stream_async("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)
        >>> client.close()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        max_tokens: int = 3000,
        temperature: float = 1.0,
        repetition_penalty: float = 1.1,
        top_k: int = 20,
    ):
        """
        Initialize the Orpheus TTS client.

        Args:
            api_key: API key for authentication (optional for now).
            max_tokens: Maximum tokens to generate (default: 3000).
            temperature: Sampling temperature (default: 1.0).
            repetition_penalty: Repetition penalty (default: 1.1).
            top_k: Top-k sampling (default: 20).
        """
        self.api_key = api_key
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.repetition_penalty = repetition_penalty
        self.top_k = top_k

        # Connection pool state (shared by sync and async)
        self._pools: dict[str, asyncio.Queue] = {}  # endpoint -> queue of ws (keyed by base endpoint)
        self._all_connections: list = []  # flat list for cleanup
        self._loop = None
        self._thread = None
        self._connected = False

    def _build_url(self, endpoint: str) -> str:
        """Append ?token=<api_key> to the endpoint URL if an API key is set."""
        if self.api_key:
            sep = "&" if "?" in endpoint else "?"
            return f"{endpoint}{sep}token={self.api_key}"
        return endpoint

    def connect(self, pool_size: int = _DEFAULT_POOL_SIZE) -> None:
        """
        Pre-establish a pool of WebSocket connections for lowest latency.

        Creates pool_size connections per unique endpoint. The pool is shared
        by both sync stream() and async stream_async() calls.

        Args:
            pool_size: Connections per endpoint (default: 16).

        Example:
            >>> client = OrpheusClient()
            >>> client.connect()  # 16 connections per endpoint
            >>> for chunk in client.stream("Hello!", voice="alexis"):
            ...     process(chunk)
        """
        if self._connected:
            return

        # Create background event loop
        self._loop = asyncio.new_event_loop()

        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop.run_forever()

        self._thread = threading.Thread(target=run_loop, daemon=True)
        self._thread.start()

        # Create connection pools on background loop
        future = asyncio.run_coroutine_threadsafe(
            self._create_pools(pool_size), self._loop
        )
        try:
            future.result(timeout=30.0)
            if not self._all_connections:
                raise ConnectionError("Failed to connect to any endpoint")
            self._connected = True
        except ConnectionError:
            self.close()
            raise
        except Exception as e:
            self.close()
            raise ConnectionError(f"Failed to connect: {e}") from e

    async def _create_pools(self, pool_size: int) -> None:
        """Internal: create connection pools for all unique endpoints."""
        endpoints = set(_VOICE_ENDPOINT_MAP.values())

        async def create_connection(endpoint: str, idx: int):
            try:
                ws = await websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                    close_timeout=5,
                )
                return (endpoint, ws)
            except Exception:
                return (endpoint, None)

        # Initialize queues
        for endpoint in endpoints:
            self._pools[endpoint] = asyncio.Queue()

        # Create all connections in parallel
        tasks = []
        for endpoint in endpoints:
            for i in range(pool_size):
                tasks.append(create_connection(endpoint, i))

        results = await asyncio.gather(*tasks)

        for endpoint, ws in results:
            if ws is not None:
                self._all_connections.append(ws)
                await self._pools[endpoint].put(ws)

    async def _acquire(self, voice: str):
        """Acquire a connection from the pool for the given voice."""
        endpoint = _get_endpoint(voice)
        pool = self._pools.get(endpoint)
        if pool is None:
            raise ConnectionError(
                f"No connection pool for voice '{voice}'. "
                f"Call connect() first or check voice name."
            )
        ws = await pool.get()
        return endpoint, ws

    async def _release(self, ws, endpoint: str):
        """Release a connection back to the pool, replacing it if dead."""
        try:
            is_open = not ws.closed if hasattr(ws, 'closed') else ws.open
        except Exception:
            is_open = False

        pool = self._pools.get(endpoint)
        if pool is None:
            return

        if is_open:
            await pool.put(ws)
        else:
            # Replace dead connection
            try:
                new_ws = await websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                )
                await pool.put(new_ws)
            except Exception:
                pass  # Pool will have one less connection

    def close(self) -> None:
        """Close all connections and cleanup resources."""
        if self._loop is not None and self._pools:
            async def _close_all():
                # Drain pools
                for pool in self._pools.values():
                    while not pool.empty():
                        try:
                            ws = pool.get_nowait()
                            if ws not in self._all_connections:
                                self._all_connections.append(ws)
                        except asyncio.QueueEmpty:
                            break

                # Close all connections
                close_tasks = []
                for ws in self._all_connections:
                    close_tasks.append(
                        asyncio.wait_for(ws.close(), timeout=2.0)
                    )
                if close_tasks:
                    await asyncio.gather(*close_tasks, return_exceptions=True)

                # Cancel any remaining tasks (e.g. keepalive) on this loop
                for task in asyncio.all_tasks(asyncio.get_running_loop()):
                    if task is not asyncio.current_task():
                        task.cancel()

                # Let cancellations propagate
                pending = [
                    t for t in asyncio.all_tasks(asyncio.get_running_loop())
                    if t is not asyncio.current_task()
                ]
                if pending:
                    await asyncio.gather(*pending, return_exceptions=True)

            try:
                future = asyncio.run_coroutine_threadsafe(_close_all(), self._loop)
                future.result(timeout=15.0)
            except Exception:
                pass

            self._all_connections.clear()
            self._pools.clear()

        if self._loop is not None:
            # Shut down async generators and the loop cleanly
            try:
                future = asyncio.run_coroutine_threadsafe(
                    self._loop.shutdown_asyncgens(), self._loop
                )
                future.result(timeout=5.0)
            except Exception:
                pass

            self._loop.call_soon_threadsafe(self._loop.stop)
            if self._thread is not None:
                self._thread.join(timeout=5.0)
            try:
                self._loop.close()
            except Exception:
                pass
            self._loop = None
            self._thread = None

        self._connected = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    async def _stream_on_connection(
        self,
        ws,
        text: str,
        voice: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> AsyncIterator[bytes]:
        """Internal: stream audio on an existing WebSocket connection."""
        request_body = {
            "prompt": text,
            "voice": voice,
            "max_tokens": max_tokens if max_tokens is not None else self.max_tokens,
            "temperature": temperature if temperature is not None else self.temperature,
            "repetition_penalty": repetition_penalty
            if repetition_penalty is not None
            else self.repetition_penalty,
            "top_k": top_k if top_k is not None else self.top_k,
        }

        await ws.send(json.dumps(request_body))

        # Fire-and-forget health ping for autoscaler tracking
        try:
            health_url = _get_health_url(_get_endpoint(voice))
            asyncio.get_running_loop().run_in_executor(None, _fire_health_ping, health_url)
        except Exception:
            pass

        async for message in ws:
            if isinstance(message, bytes):
                yield message
            else:
                try:
                    data = json.loads(message)
                    if "error" in data:
                        error_msg = data["error"]
                        if "auth" in error_msg.lower() or "key" in error_msg.lower():
                            raise AuthenticationError(error_msg)
                        raise StreamingError(error_msg)
                    if data.get("done"):
                        break
                except json.JSONDecodeError:
                    pass

    def stream(
        self,
        text: str,
        voice: str = "alexis",
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
    ) -> Iterator[bytes]:
        """
        Stream audio synchronously from the Orpheus TTS model.

        If connect() was called first, uses a pooled connection for lowest
        latency. Otherwise, creates a new connection per request.

        Args:
            text: The text to convert to speech.
            voice: Voice to use. See orpheus_tts.VOICES for options.
            max_tokens: Override default max_tokens.
            temperature: Override default temperature.
            repetition_penalty: Override default repetition_penalty.
            top_k: Override default top_k.

        Yields:
            bytes: Raw PCM audio chunks (int16, 48kHz, mono).

        Raises:
            ValueError: If voice is not recognized.
            AuthenticationError: If API key is invalid.
            ConnectionError: If connection to service fails.
            StreamingError: If an error occurs during streaming.
        """
        voice = voice.lower().strip()
        endpoint = _get_endpoint(voice)

        if self._connected and self._loop is not None:
            yield from self._stream_from_pool(
                endpoint, text, voice, max_tokens, temperature, repetition_penalty, top_k
            )
        else:
            yield from self._stream_with_new_connection(
                text, voice, endpoint, max_tokens, temperature, repetition_penalty, top_k
            )

    def _stream_from_pool(
        self,
        endpoint: str,
        text: str,
        voice: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> Iterator[bytes]:
        """Stream using a pooled connection (lowest latency)."""
        chunk_queue: queue.Queue = queue.Queue()
        error_holder: list = []

        async def _run():
            max_retries = 3
            for attempt in range(max_retries):
                ws = None
                try:
                    _, ws = await self._acquire(voice)
                    async for chunk in self._stream_on_connection(
                        ws, text, voice, max_tokens, temperature, repetition_penalty, top_k
                    ):
                        chunk_queue.put(chunk)
                    # Success
                    await self._release(ws, endpoint)
                    return
                except ConnectionClosed:
                    if ws is not None:
                        await self._release(ws, endpoint)
                    if attempt < max_retries - 1:
                        continue
                    raise ConnectionError(
                        "Connection closed unexpectedly after "
                        f"{max_retries} retries"
                    )
                except Exception:
                    if ws is not None:
                        await self._release(ws, endpoint)
                    raise

        async def _run_wrapper():
            try:
                await _run()
            except Exception as e:
                error_holder.append(e)
            finally:
                chunk_queue.put(None)

        future = asyncio.run_coroutine_threadsafe(_run_wrapper(), self._loop)

        while True:
            chunk = chunk_queue.get()
            if chunk is None:
                break
            yield chunk

        try:
            future.result(timeout=300.0)
        except Exception as e:
            if not error_holder:
                error_holder.append(e)

        if error_holder:
            raise error_holder[0]

    async def stream_async(
        self,
        text: str,
        voice: str = "alexis",
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream audio asynchronously from the Orpheus TTS model.

        If connect() was called first, uses a pooled connection for lowest
        latency. Otherwise, creates a new connection per request.

        Args:
            text: The text to convert to speech.
            voice: Voice to use. See orpheus_tts.VOICES for options.
            max_tokens: Override default max_tokens.
            temperature: Override default temperature.
            repetition_penalty: Override default repetition_penalty.
            top_k: Override default top_k.

        Yields:
            bytes: Raw PCM audio chunks (int16, 48kHz, mono).

        Raises:
            ValueError: If voice is not recognized.
            AuthenticationError: If API key is invalid.
            ConnectionError: If connection to service fails.
            StreamingError: If an error occurs during streaming.
        """
        voice = voice.lower().strip()
        endpoint = _get_endpoint(voice)

        if self._connected and self._loop is not None:
            # Use pool — stream on background loop, bridge chunks back
            chunk_queue: queue.Queue = queue.Queue()
            error_holder: list = []

            async def _run():
                max_retries = 3
                for attempt in range(max_retries):
                    ws = None
                    try:
                        _, ws = await self._acquire(voice)
                        async for chunk in self._stream_on_connection(
                            ws, text, voice, max_tokens, temperature,
                            repetition_penalty, top_k
                        ):
                            chunk_queue.put(chunk)
                        # Success
                        await self._release(ws, endpoint)
                        return
                    except ConnectionClosed:
                        if ws is not None:
                            await self._release(ws, endpoint)
                        if attempt < max_retries - 1:
                            continue
                        raise ConnectionError(
                            "Connection closed unexpectedly after "
                            f"{max_retries} retries"
                        )
                    except Exception:
                        if ws is not None:
                            await self._release(ws, endpoint)
                        raise

            async def _run_wrapper():
                try:
                    await _run()
                except Exception as e:
                    error_holder.append(e)
                finally:
                    chunk_queue.put(None)

            future = asyncio.run_coroutine_threadsafe(_run_wrapper(), self._loop)

            loop = asyncio.get_running_loop()
            while True:
                chunk = await loop.run_in_executor(None, chunk_queue.get)
                if chunk is None:
                    break
                yield chunk

            try:
                future.result(timeout=5.0)
            except Exception as e:
                if not error_holder:
                    error_holder.append(e)

            if error_holder:
                raise error_holder[0]
        else:
            # No pool - create new connection (higher latency)
            try:
                async with websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    async for chunk in self._stream_on_connection(
                        ws, text, voice, max_tokens, temperature,
                        repetition_penalty, top_k
                    ):
                        yield chunk

            except ConnectionClosed as e:
                raise ConnectionError(
                    f"Connection closed unexpectedly: {e}"
                ) from e
            except OSError as e:
                raise ConnectionError(
                    f"Failed to connect to TTS service: {e}"
                ) from e
            except (AuthenticationError, StreamingError):
                raise
            except Exception as e:
                raise OrpheusError(f"Unexpected error: {e}") from e

    def _stream_with_new_connection(
        self,
        text: str,
        voice: str,
        endpoint: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> Iterator[bytes]:
        """Stream with a fresh connection (includes handshake in latency)."""
        chunk_queue: queue.Queue = queue.Queue()
        error_holder: list = []

        async def collect():
            try:
                async with websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    async for chunk in self._stream_on_connection(
                        ws, text, voice, max_tokens, temperature,
                        repetition_penalty, top_k
                    ):
                        chunk_queue.put(chunk)
            except Exception as e:
                error_holder.append(e)
            finally:
                chunk_queue.put(None)

        def run_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(collect())
            finally:
                loop.run_until_complete(loop.shutdown_asyncgens())
                loop.close()

        thread = threading.Thread(target=run_async, daemon=True)
        thread.start()

        while True:
            chunk = chunk_queue.get()
            if chunk is None:
                break
            yield chunk

        thread.join(timeout=5.0)

        if error_holder:
            raise error_holder[0]

    def stream_to_bytes(
        self,
        text: str,
        voice: str = "alexis",
        **kwargs,
    ) -> bytes:
        """
        Generate complete audio and return as bytes.

        Convenience method that collects all streamed chunks.

        Args:
            text: The text to convert to speech.
            voice: Voice to use.
            **kwargs: Additional arguments passed to stream().

        Returns:
            bytes: Complete PCM audio (int16, 48kHz, mono).
        """
        chunks = list(self.stream(text, voice, **kwargs))
        return b"".join(chunks)

    async def stream_to_bytes_async(
        self,
        text: str,
        voice: str = "alexis",
        **kwargs,
    ) -> bytes:
        """
        Generate complete audio asynchronously and return as bytes.

        Args:
            text: The text to convert to speech.
            voice: Voice to use.
            **kwargs: Additional arguments passed to stream_async().

        Returns:
            bytes: Complete PCM audio (int16, 48kHz, mono).
        """
        chunks = []
        async for chunk in self.stream_async(text, voice, **kwargs):
            chunks.append(chunk)
        return b"".join(chunks)
