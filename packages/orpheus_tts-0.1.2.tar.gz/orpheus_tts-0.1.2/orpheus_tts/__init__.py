"""Orpheus TTS Python SDK - Stream high-quality speech from the Orpheus model."""

from orpheus_tts.client import OrpheusClient
from orpheus_tts.exceptions import OrpheusError, AuthenticationError

# Available voices (public display names)
VOICES = [
    "Alexei",
    "Alexis",
    "Andy",
    "Anna",
    "Antoine",
    "Audrey",
    "Brian",
    "Claire",
    "Dawn",
    "Diana",
    "Dylan",
    "Nova",
    "Gautam",
    "Grace",
    "Jennie",
    "Josh",
    "Kai",
    "Kenji",
    "Kevin",
    "Leo",
    "Lily",
    "Luke",
    "Marco",
    "Max",
    "Melissa",
    "Michael",
    "Nathan",
    "Pete",
    "Santiago",
    "Sofia",
    "Summer",
    "Will",
    "Yuki",
    "Zoe",
]

__all__ = ["OrpheusClient", "OrpheusError", "AuthenticationError", "VOICES"]
__version__ = "0.1.1"

