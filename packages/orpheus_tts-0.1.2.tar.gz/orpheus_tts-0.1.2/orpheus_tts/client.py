"""Orpheus TTS Client - Stream speech from the Orpheus model."""

from __future__ import annotations

import asyncio
import json
import queue
import struct
import threading
import urllib.request
from typing import AsyncIterator, Dict, Iterator, List, Optional
from urllib.parse import urlparse, urlunparse

try:
    import websockets
    from websockets.exceptions import ConnectionClosed
except ImportError:
    raise ImportError(
        "websockets package is required. Install with: pip install orpheus-tts"
    )

from orpheus_tts.exceptions import (
    AuthenticationError,
    ConnectionError,
    OrpheusError,
    StreamingError,
)

# Internal endpoints - hidden from users
_VOICE_ENDPOINTS = {
    "endpoint_1": "wss://canopy-labs--production-group1-orpheus-v1-flash-nogatewa-c93837.us-west.modal.direct/ws/tts",
    "endpoint_2": "wss://canopy-labs--production-group2-orpheus-v1-flash-nogatewa-7046d3.us-west.modal.direct/ws/tts",
    "endpoint_3": "wss://canopy-labs--production-group3-orpheus-v1-flash-nogatewa-0f7098.us-west.modal.direct/ws/tts",
    "endpoint_4": "wss://canopy-labs--production-group4-orpheus-v1-flash-nogatewa-283527.us-west.modal.direct/ws/tts",
    "endpoint_5": "wss://canopy-labs--production-group5-orpheus-v1-flash-nogatewa-d1b42d.us-west.modal.direct/ws/tts",
    "endpoint_6": "wss://canopy-labs--production-group6-orpheus-v1-flash-nogatewa-fa0042.us-west.modal.direct/ws/tts",
    "endpoint_7": "wss://canopy-labs--production-group7-orpheus-v1-flash-nogatewa-e66d47.us-west.modal.direct/ws/tts",
    "endpoint_8": "wss://canopy-labs--production-group8-orpheus-v1-flash-nogatewa-6943c9.us-west.modal.direct/ws/tts",
    "endpoint_9": "wss://canopy-labs--production-group9-orpheus-v1-flash-nogatewa-7048a5.us-west.modal.direct/ws/tts",
    "endpoint_10": "wss://canopy-labs--production-group10-orpheus-v1-flash-nogatew-84e8df.us-west.modal.direct/ws/tts",
    "endpoint_11": "wss://canopy-labs--production-arabic-sawt-orpheus-v1-flash-nog-1cce8c.us-west.modal.direct/ws/tts",
}

# Display name -> endpoint mapping (users only see display names)
_VOICE_ENDPOINT_MAP = {
    # group1
    "troy": _VOICE_ENDPOINTS["endpoint_1"],
    # group2
    "dawn": _VOICE_ENDPOINTS["endpoint_2"],
    # group3
    "pete": _VOICE_ENDPOINTS["endpoint_3"],
    "zoe": _VOICE_ENDPOINTS["endpoint_3"],
    "andy": _VOICE_ENDPOINTS["endpoint_3"],
    "summer": _VOICE_ENDPOINTS["endpoint_3"],
    # group4
    "nathan": _VOICE_ENDPOINTS["endpoint_4"],
    "kai": _VOICE_ENDPOINTS["endpoint_4"],
    "dylan": _VOICE_ENDPOINTS["endpoint_4"],
    "audrey": _VOICE_ENDPOINTS["endpoint_4"],
    # group5
    "diana": _VOICE_ENDPOINTS["endpoint_5"],
    "alexis": _VOICE_ENDPOINTS["endpoint_5"],
    "michael": _VOICE_ENDPOINTS["endpoint_5"],
    "grace": _VOICE_ENDPOINTS["endpoint_5"],
    "brian": _VOICE_ENDPOINTS["endpoint_5"],
    # group6
    "will": _VOICE_ENDPOINTS["endpoint_6"],
    "melissa": _VOICE_ENDPOINTS["endpoint_6"],
    # group7
    "marco": _VOICE_ENDPOINTS["endpoint_7"],
    "nova": _VOICE_ENDPOINTS["endpoint_7"],
    "leo": _VOICE_ENDPOINTS["endpoint_7"],
    "santiago": _VOICE_ENDPOINTS["endpoint_7"],
    "sofia": _VOICE_ENDPOINTS["endpoint_7"],
    # group8
    "max": _VOICE_ENDPOINTS["endpoint_8"],
    "anna": _VOICE_ENDPOINTS["endpoint_8"],
    # group9
    "kenji": _VOICE_ENDPOINTS["endpoint_9"],
    "yuki": _VOICE_ENDPOINTS["endpoint_9"],
    "luke": _VOICE_ENDPOINTS["endpoint_9"],
    "jennie": _VOICE_ENDPOINTS["endpoint_9"],
    "lily": _VOICE_ENDPOINTS["endpoint_9"],
    "kevin": _VOICE_ENDPOINTS["endpoint_9"],
    # group10
    "alexei": _VOICE_ENDPOINTS["endpoint_10"],
    "claire": _VOICE_ENDPOINTS["endpoint_10"],
    "gautam": _VOICE_ENDPOINTS["endpoint_10"],
    "antoine": _VOICE_ENDPOINTS["endpoint_10"],
    
    # group11
    "aleen": _VOICE_ENDPOINTS["endpoint_11"],
}

_DEFAULT_POOL_SIZE = 3


def _get_endpoint(voice: str) -> str:
    """Resolve a display voice name to its WebSocket endpoint URL.

    Raises:
        ValueError: If the voice is not recognized.
    """
    key = voice.lower().strip()
    try:
        return _VOICE_ENDPOINT_MAP[key]
    except KeyError:
        valid = ", ".join(
            name.capitalize() for name in sorted(_VOICE_ENDPOINT_MAP.keys())
        )
        raise ValueError(
            f"Unknown voice '{voice}'. Valid voices: {valid}"
        )


def _get_multiplex_url(endpoint: str) -> str:
    """Convert a /ws/tts endpoint URL to its /ws/tts/multiplex URL."""
    return endpoint.rstrip("/") + "/multiplex"


def _get_health_url(endpoint: str) -> str:
    """Convert a WSS endpoint URL to its HTTPS /health URL."""
    parsed = urlparse(endpoint)
    scheme = "https" if parsed.scheme == "wss" else "http"
    return urlunparse((scheme, parsed.netloc, "/health", "", "", ""))


def _fire_health_ping(url: str) -> None:
    """Send a fire-and-forget GET to the health endpoint (runs in thread pool)."""
    try:
        urllib.request.urlopen(url, timeout=5)
    except Exception:
        pass


# Audio format constants
SAMPLE_RATE = 48000  # Hz
SAMPLE_WIDTH = 2  # bytes (int16)
CHANNELS = 1  # mono


class _MultiplexedConnection:
    """
    A single WebSocket connection that handles many concurrent TTS requests
    via request_id-based multiplexing.

    Protocol:
    - Send: {"request_id": "...", "prompt": "...", "voice": "...", ...}
    - Receive binary: [4-byte server_request_id BE] + [PCM audio]
    - Receive JSON: {"type": "accepted", "server_request_id": N, "client_request_id": "..."}
    - Receive JSON: {"done": true, ...} or {"error": "..."}
    """

    def __init__(self, ws, endpoint: str):
        self.ws = ws
        self.endpoint = endpoint
        self._connected = True
        self._ref_count = 0

        # Request tracking
        self._request_counter = 0
        self._chunk_queues: Dict[str, asyncio.Queue] = {}
        self._request_errors: Dict[str, str] = {}

        # Server <-> client request ID mapping
        self._server_to_client: Dict[int, str] = {}
        self._client_to_server: Dict[str, int] = {}

        # Background receiver task
        self._receiver_task: Optional[asyncio.Task] = None

    @property
    def is_alive(self) -> bool:
        """Check if the connection is still usable.

        Uses only internal flags (not ws.closed/ws.open) so it works
        across all websockets versions (v12 legacy through v16+ new API).
        """
        if not self._connected:
            return False
        if self._receiver_task is not None and self._receiver_task.done():
            return False
        return True

    def start(self) -> None:
        """Start the background receive loop."""
        self._receiver_task = asyncio.create_task(self._receive_loop())

    async def close(self) -> None:
        """Close the connection and cancel the receiver."""
        self._connected = False
        if self._receiver_task:
            self._receiver_task.cancel()
            try:
                await self._receiver_task
            except asyncio.CancelledError:
                pass
            self._receiver_task = None
        if self.ws:
            try:
                await asyncio.wait_for(self.ws.close(), timeout=2.0)
            except Exception:
                pass

    async def _receive_loop(self) -> None:
        """Demultiplex incoming WebSocket messages to per-request queues."""
        try:
            async for message in self.ws:
                if isinstance(message, bytes):
                    # Binary: [4-byte server_request_id] + [PCM audio]
                    if len(message) < 4:
                        continue
                    server_id = struct.unpack(">I", message[:4])[0]
                    audio_bytes = message[4:]

                    client_id = self._server_to_client.get(server_id)
                    if client_id is None:
                        # Fallback: find an active request not yet mapped
                        for rid in self._chunk_queues:
                            if rid not in self._server_to_client.values():
                                client_id = rid
                                self._server_to_client[server_id] = rid
                                self._client_to_server[rid] = server_id
                                break
                        if client_id is None:
                            continue

                    q = self._chunk_queues.get(client_id)
                    if q is not None:
                        await q.put(audio_bytes)

                else:
                    # JSON control message
                    try:
                        data = json.loads(message)
                    except json.JSONDecodeError:
                        continue

                    msg_type = data.get("type")
                    server_request_id = data.get("server_request_id")
                    client_request_id = data.get("client_request_id")

                    # Backward compat: old servers send request_id as int
                    if server_request_id is None and isinstance(
                        data.get("request_id"), int
                    ):
                        server_request_id = data["request_id"]

                    # Handle "accepted" mapping
                    if msg_type == "accepted":
                        if (
                            server_request_id is not None
                            and client_request_id is not None
                        ):
                            cid = str(client_request_id)
                            sid = int(server_request_id)
                            self._server_to_client[sid] = cid
                            self._client_to_server[cid] = sid
                        continue

                    # Resolve which client request this message belongs to
                    resolved_id = None
                    if client_request_id is not None:
                        cid = str(client_request_id)
                        if cid in self._chunk_queues:
                            resolved_id = cid
                    if resolved_id is None and server_request_id is not None:
                        resolved_id = self._server_to_client.get(
                            int(server_request_id)
                        )
                    if resolved_id is None and isinstance(
                        data.get("request_id"), str
                    ):
                        rid = data["request_id"]
                        if rid in self._chunk_queues:
                            resolved_id = rid
                    if resolved_id is None and server_request_id is not None:
                        # Fallback heuristic for legacy servers
                        for rid in self._chunk_queues:
                            if rid not in self._server_to_client.values():
                                resolved_id = rid
                                sid = int(server_request_id)
                                self._server_to_client[sid] = rid
                                self._client_to_server[rid] = sid
                                break

                    if resolved_id is None:
                        continue

                    if data.get("done"):
                        q = self._chunk_queues.get(resolved_id)
                        if q is not None:
                            await q.put(None)  # Signal completion

                    elif data.get("error"):
                        error_msg = str(data.get("error", "Unknown error"))
                        self._request_errors[resolved_id] = error_msg
                        q = self._chunk_queues.get(resolved_id)
                        if q is not None:
                            await q.put(None)  # Signal completion with error

            # Normal exit: server closed the connection cleanly
            self._connected = False
            for rid, q in list(self._chunk_queues.items()):
                if rid not in self._request_errors:
                    self._request_errors[rid] = "Connection closed"
                try:
                    await q.put(None)
                except Exception:
                    pass

        except ConnectionClosed:
            self._connected = False
            for rid, q in list(self._chunk_queues.items()):
                if rid not in self._request_errors:
                    self._request_errors[rid] = "Connection closed"
                try:
                    await q.put(None)
                except Exception:
                    pass

        except asyncio.CancelledError:
            raise

        except Exception as e:
            self._connected = False
            for rid, q in list(self._chunk_queues.items()):
                if rid not in self._request_errors:
                    self._request_errors[rid] = f"Receiver error: {e}"
                try:
                    await q.put(None)
                except Exception:
                    pass

    async def stream_request(
        self, request_body: dict
    ) -> AsyncIterator[bytes]:
        """
        Submit a TTS request and yield audio chunks as they arrive.

        A unique request_id is added automatically. The caller does not need
        to manage acquire/release -- ref_count is handled internally.

        Args:
            request_body: Dict with prompt, voice, max_tokens, etc.

        Yields:
            bytes: Raw PCM audio chunks.

        Raises:
            AuthenticationError: If the server reports an auth error.
            StreamingError: If the server reports any other error or times out.
        """
        if not self.is_alive:
            raise ConnectionError("Multiplexed connection is not alive")

        # Generate unique request ID
        self._request_counter += 1
        request_id = f"req_{id(self)}_{self._request_counter}"

        # Create per-request queue
        chunk_queue: asyncio.Queue = asyncio.Queue()
        self._chunk_queues[request_id] = chunk_queue
        self._ref_count += 1

        try:
            # Send request with request_id
            request_data = {**request_body, "request_id": request_id}
            await self.ws.send(json.dumps(request_data))

            # Yield chunks as they arrive
            while True:
                try:
                    chunk = await asyncio.wait_for(
                        chunk_queue.get(), timeout=60.0
                    )
                except asyncio.TimeoutError:
                    raise StreamingError("Request timed out after 60s")

                if chunk is None:
                    # Stream complete -- check for errors
                    error = self._request_errors.pop(request_id, None)
                    if error:
                        if (
                            "auth" in error.lower()
                            or "key" in error.lower()
                        ):
                            raise AuthenticationError(error)
                        raise StreamingError(error)
                    break

                yield chunk

        finally:
            self._ref_count -= 1
            self._chunk_queues.pop(request_id, None)
            self._request_errors.pop(request_id, None)
            # Clean up server ID mapping
            server_id = self._client_to_server.pop(request_id, None)
            if server_id is not None:
                self._server_to_client.pop(server_id, None)


class OrpheusClient:
    """
    Client for streaming speech from the Orpheus TTS model.

    Uses multiplexed WebSocket connections so that many concurrent requests
    share a small pool of connections (default: 4 per endpoint).

    Example:
        >>> from orpheus_tts import OrpheusClient
        >>>
        >>> # Option 1: Auto-connect (includes connection time in first request)
        >>> client = OrpheusClient()
        >>> for chunk in client.stream("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)
        >>>
        >>> # Option 2: Pre-connect for lowest latency (recommended)
        >>> client = OrpheusClient()
        >>> client.connect()  # Pool of 4 multiplexed connections per endpoint
        >>> for chunk in client.stream("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)  # TTFA excludes handshake!
        >>> client.close()
        >>>
        >>> # Option 3: Async usage (same pool, same connect)
        >>> client = OrpheusClient()
        >>> client.connect()
        >>> async for chunk in client.stream_async("Hello!", voice="alexis"):
        ...     audio_player.write(chunk)
        >>> client.close()
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        max_tokens: int = 3000,
        temperature: float = 1.0,
        repetition_penalty: float = 1.1,
        top_k: int = 20,
        custom_endpoint: Optional[str] = None,
        voices: Optional[List[str]] = None,
    ):
        """
        Initialize the Orpheus TTS client.

        Args:
            api_key: API key for authentication (optional for now).
            max_tokens: Maximum tokens to generate (default: 3000).
            temperature: Sampling temperature (default: 1.0).
            repetition_penalty: Repetition penalty (default: 1.1).
            top_k: Top-k sampling (default: 20).
            custom_endpoint: A WebSocket TTS endpoint URL (e.g.
                ``"wss://my-server.example.com/ws/tts"``).  Must be
                provided together with *voices*.
            voices: List of voice names available on *custom_endpoint*.
                Must be provided together with *custom_endpoint*.
        """
        # Validate custom_endpoint / voices
        if custom_endpoint is not None and not voices:
            raise ValueError(
                "custom_endpoint was provided without voices. "
                "Pass a list of voice names available on the endpoint."
            )
        if voices is not None and custom_endpoint is None:
            raise ValueError(
                "voices was provided without custom_endpoint. "
                "Pass the WebSocket endpoint URL that serves these voices."
            )

        self.api_key = api_key
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.repetition_penalty = repetition_penalty
        self.top_k = top_k

        # Build instance-level voice -> endpoint map
        self._voice_endpoint_map: Dict[str, str] = dict(_VOICE_ENDPOINT_MAP)
        if custom_endpoint is not None and voices is not None:
            for v in voices:
                self._voice_endpoint_map[v.lower().strip()] = custom_endpoint

        # Connection pool state (shared by sync and async)
        self._pools: Dict[str, List[_MultiplexedConnection]] = {}
        self._pool_size: int = _DEFAULT_POOL_SIZE
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._thread: Optional[threading.Thread] = None
        self._health_task: Optional[asyncio.Task] = None
        self._connected = False
        self._last_connect_errors: Dict[str, str] = {}  # endpoint -> last error

    def _build_url(self, endpoint: str) -> str:
        """Append ?token=<api_key> to the endpoint URL if an API key is set."""
        if self.api_key:
            sep = "&" if "?" in endpoint else "?"
            return f"{endpoint}{sep}token={self.api_key}"
        return endpoint

    def _get_endpoint(self, voice: str) -> str:
        """Resolve a voice name to its WebSocket endpoint URL.

        Uses the instance-level ``_voice_endpoint_map`` which includes any
        custom endpoint/voices passed at construction time.

        Raises:
            ValueError: If the voice is not recognized.
        """
        key = voice.lower().strip()
        try:
            return self._voice_endpoint_map[key]
        except KeyError:
            valid = ", ".join(
                name.capitalize()
                for name in sorted(self._voice_endpoint_map.keys())
            )
            raise ValueError(
                f"Unknown voice '{voice}'. Valid voices: {valid}"
            )

    def connect(self, pool_size: int = _DEFAULT_POOL_SIZE) -> None:
        """
        Pre-establish a pool of multiplexed WebSocket connections for lowest
        latency.

        Each connection can handle many concurrent requests, so a small pool
        (default: 4) is sufficient even for high concurrency.

        Args:
            pool_size: Multiplexed connections per endpoint (default: 4).

        Example:
            >>> client = OrpheusClient()
            >>> client.connect()  # 4 multiplexed connections per endpoint
            >>> for chunk in client.stream("Hello!", voice="alexis"):
            ...     process(chunk)
        """
        if self._connected:
            return

        # Create background event loop
        self._loop = asyncio.new_event_loop()

        def run_loop():
            asyncio.set_event_loop(self._loop)
            self._loop.run_forever()

        self._thread = threading.Thread(target=run_loop, daemon=True)
        self._thread.start()

        self._pool_size = pool_size

        # Create connection pools on background loop
        future = asyncio.run_coroutine_threadsafe(
            self._create_pools(pool_size), self._loop
        )
        try:
            future.result(timeout=30.0)
            # Check that at least one endpoint has connections
            has_connections = any(
                len(conns) > 0 for conns in self._pools.values()
            )
            if not has_connections:
                # Build a useful error message with last connection errors
                details = "; ".join(
                    f"{ep} — {self._last_connect_errors.get(ep, 'unknown error')}"
                    for ep in self._pools
                )
                raise ConnectionError(
                    f"Failed to connect to any endpoint. "
                    f"The service may be down. Details: {details}"
                )
            self._connected = True

            # Start background health monitor
            self._health_task = asyncio.run_coroutine_threadsafe(
                self._start_health_monitor(), self._loop
            ).result(timeout=5.0)
        except ConnectionError:
            self.close()
            raise
        except Exception as e:
            self.close()
            raise ConnectionError(f"Failed to connect: {e}") from e

    async def _create_one_connection(
        self, endpoint: str
    ) -> Optional[_MultiplexedConnection]:
        """Create a single multiplexed WebSocket connection for the given endpoint.

        Returns the connection on success, or None if it failed.
        The last failure reason is stored in ``_last_connect_errors[endpoint]``.
        """
        multiplex_url = _get_multiplex_url(endpoint)
        try:
            ws = await websockets.connect(
                self._build_url(multiplex_url),
                max_size=16 * 1024 * 1024,
                ping_interval=30,
                ping_timeout=10,
                close_timeout=5,
            )
            conn = _MultiplexedConnection(ws, endpoint)
            conn.start()
            return conn
        except Exception as exc:
            self._last_connect_errors[endpoint] = str(exc)
            return None

    async def _create_pools(self, pool_size: int) -> None:
        """Internal: create multiplexed connection pools for all unique endpoints."""
        endpoints = set(self._voice_endpoint_map.values())

        # Initialize pool lists
        for endpoint in endpoints:
            self._pools[endpoint] = []

        # Create all connections in parallel
        tasks = []
        endpoint_list = []
        for endpoint in endpoints:
            for i in range(pool_size):
                tasks.append(self._create_one_connection(endpoint))
                endpoint_list.append(endpoint)

        results = await asyncio.gather(*tasks)

        for endpoint, conn in zip(endpoint_list, results):
            if conn is not None:
                self._pools[endpoint].append(conn)

    def _acquire(self, voice: str) -> _MultiplexedConnection:
        """Pick the least-loaded multiplexed connection for the given voice.

        This is a synchronous method (no awaiting needed) because we just
        pick the connection with the lowest ref_count.

        Raises:
            ConnectionError: If no connections are available.
        """
        endpoint = self._get_endpoint(voice)
        conns = self._pools.get(endpoint)
        if not conns:
            last_err = self._last_connect_errors.get(endpoint, "")
            detail = f" Last error: {last_err}" if last_err else ""
            raise ConnectionError(
                f"No connection pool for voice '{voice}'. "
                f"The endpoint may be down or unreachable.{detail}"
            )

        # Filter to alive connections
        alive = [c for c in conns if c.is_alive]
        if not alive:
            last_err = self._last_connect_errors.get(endpoint, "")
            detail = f" Last error: {last_err}" if last_err else ""
            raise ConnectionError(
                f"All connections for voice '{voice}' are dead. "
                f"The endpoint may be down or unreachable.{detail}"
            )

        # Pick least loaded
        return min(alive, key=lambda c: c._ref_count)

    async def _start_health_monitor(self) -> asyncio.Task:
        """Create and return the background health-check task."""
        return asyncio.create_task(self._health_loop())

    async def _health_loop(self) -> None:
        """Periodically check pool connections and replace dead ones."""
        try:
            while True:
                await asyncio.sleep(10)
                await self._replace_dead_connections()
        except asyncio.CancelledError:
            return

    async def _replace_dead_connections(self, endpoint: Optional[str] = None) -> None:
        """Remove dead connections and create replacements to restore pool size.

        Args:
            endpoint: If given, only heal this endpoint's pool.
                      If None, heal all endpoint pools.
        """
        endpoints = [endpoint] if endpoint else list(self._pools.keys())
        for ep in endpoints:
            conns = self._pools.get(ep)
            if conns is None:
                continue

            # Identify and remove dead connections
            alive = []
            dead = []
            for c in conns:
                if c.is_alive:
                    alive.append(c)
                else:
                    dead.append(c)

            # Close dead connections cleanly
            for c in dead:
                try:
                    await c.close()
                except Exception:
                    pass

            # Update pool to only alive connections
            self._pools[ep] = alive

            # Create replacements in parallel
            needed = self._pool_size - len(alive)
            if needed > 0:
                tasks = [self._create_one_connection(ep) for _ in range(needed)]
                results = await asyncio.gather(*tasks)
                for conn in results:
                    if conn is not None:
                        self._pools[ep].append(conn)

    def close(self) -> None:
        """Close all connections and cleanup resources."""
        if self._loop is not None and self._pools:
            async def _close_all():
                # Cancel the health monitor first so it doesn't create
                # new connections while we're shutting down
                if self._health_task is not None:
                    self._health_task.cancel()
                    try:
                        await self._health_task
                    except (asyncio.CancelledError, Exception):
                        pass
                    self._health_task = None

                # Close all multiplexed connections
                close_tasks = []
                for conns in self._pools.values():
                    for conn in conns:
                        close_tasks.append(conn.close())
                if close_tasks:
                    await asyncio.gather(*close_tasks, return_exceptions=True)

                # Cancel any remaining tasks on this loop
                for task in asyncio.all_tasks(asyncio.get_running_loop()):
                    if task is not asyncio.current_task():
                        task.cancel()

                # Let cancellations propagate
                pending = [
                    t for t in asyncio.all_tasks(asyncio.get_running_loop())
                    if t is not asyncio.current_task()
                ]
                if pending:
                    await asyncio.gather(*pending, return_exceptions=True)

            try:
                future = asyncio.run_coroutine_threadsafe(
                    _close_all(), self._loop
                )
                future.result(timeout=15.0)
            except Exception:
                pass

            self._pools.clear()

        if self._loop is not None:
            # Shut down async generators and the loop cleanly
            try:
                future = asyncio.run_coroutine_threadsafe(
                    self._loop.shutdown_asyncgens(), self._loop
                )
                future.result(timeout=5.0)
            except Exception:
                pass

            self._loop.call_soon_threadsafe(self._loop.stop)
            if self._thread is not None:
                self._thread.join(timeout=5.0)
            try:
                self._loop.close()
            except Exception:
                pass
            self._loop = None
            self._thread = None

        self._connected = False

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def _build_request_body(
        self,
        text: str,
        voice: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> dict:
        """Build the request body dict for a TTS request."""
        return {
            "prompt": text,
            "voice": voice,
            "max_tokens": max_tokens if max_tokens is not None else self.max_tokens,
            "temperature": (
                temperature if temperature is not None else self.temperature
            ),
            "repetition_penalty": (
                repetition_penalty
                if repetition_penalty is not None
                else self.repetition_penalty
            ),
            "top_k": top_k if top_k is not None else self.top_k,
        }

    async def _stream_on_connection(
        self,
        ws,
        text: str,
        voice: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> AsyncIterator[bytes]:
        """Internal: stream audio on a basic (non-multiplexed) WebSocket connection.

        Used only by the non-pool path (_stream_with_new_connection).
        """
        request_body = self._build_request_body(
            text, voice, max_tokens, temperature, repetition_penalty, top_k
        )

        await ws.send(json.dumps(request_body))

        # Fire-and-forget health ping for autoscaler tracking
        try:
            health_url = _get_health_url(self._get_endpoint(voice))
            asyncio.get_running_loop().run_in_executor(
                None, _fire_health_ping, health_url
            )
        except Exception:
            pass

        async for message in ws:
            if isinstance(message, bytes):
                yield message
            else:
                try:
                    data = json.loads(message)
                    if "error" in data:
                        error_msg = data["error"]
                        if (
                            "auth" in error_msg.lower()
                            or "key" in error_msg.lower()
                        ):
                            raise AuthenticationError(error_msg)
                        raise StreamingError(error_msg)
                    if data.get("done"):
                        break
                except json.JSONDecodeError:
                    pass

    def stream(
        self,
        text: str,
        voice: str = "alexis",
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
    ) -> Iterator[bytes]:
        """
        Stream audio synchronously from the Orpheus TTS model.

        If connect() was called first, uses a pooled multiplexed connection
        for lowest latency. Otherwise, creates a new connection per request.

        Args:
            text: The text to convert to speech.
            voice: Voice to use. See orpheus_tts.VOICES for options.
            max_tokens: Override default max_tokens.
            temperature: Override default temperature.
            repetition_penalty: Override default repetition_penalty.
            top_k: Override default top_k.

        Yields:
            bytes: Raw PCM audio chunks (int16, 48kHz, mono).

        Raises:
            ValueError: If voice is not recognized.
            AuthenticationError: If API key is invalid.
            ConnectionError: If connection to service fails.
            StreamingError: If an error occurs during streaming.
        """
        voice = voice.lower().strip()
        endpoint = self._get_endpoint(voice)

        if self._connected and self._loop is not None:
            yield from self._stream_from_pool(
                text, voice, max_tokens, temperature, repetition_penalty, top_k
            )
        else:
            yield from self._stream_with_new_connection(
                text, voice, endpoint, max_tokens, temperature,
                repetition_penalty, top_k
            )

    def _stream_from_pool(
        self,
        text: str,
        voice: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> Iterator[bytes]:
        """Stream using a pooled multiplexed connection (lowest latency)."""
        chunk_queue: queue.Queue = queue.Queue()
        error_holder: list = []

        async def _run():
            endpoint = self._get_endpoint(voice)
            request_body = self._build_request_body(
                text, voice, max_tokens, temperature,
                repetition_penalty, top_k
            )

            # Fire-and-forget health ping for autoscaler tracking
            try:
                health_url = _get_health_url(endpoint)
                asyncio.get_running_loop().run_in_executor(
                    None, _fire_health_ping, health_url
                )
            except Exception:
                pass

            last_error: Optional[Exception] = None
            for attempt in range(3):
                try:
                    conn = self._acquire(voice)
                    async for audio_chunk in conn.stream_request(request_body):
                        chunk_queue.put(audio_chunk)
                    return  # success
                except AuthenticationError:
                    raise  # never retry auth errors
                except (ConnectionError, StreamingError, ConnectionClosed) as e:
                    last_error = e
                    # Await pool repair so next retry has live connections
                    await self._replace_dead_connections(endpoint)
                    continue
            raise last_error  # type: ignore[misc]

        async def _run_wrapper():
            try:
                await _run()
            except Exception as e:
                error_holder.append(e)
            finally:
                chunk_queue.put(None)

        future = asyncio.run_coroutine_threadsafe(_run_wrapper(), self._loop)

        while True:
            chunk = chunk_queue.get()
            if chunk is None:
                break
            yield chunk

        try:
            future.result(timeout=300.0)
        except Exception as e:
            if not error_holder:
                error_holder.append(e)

        if error_holder:
            raise error_holder[0]

    async def stream_async(
        self,
        text: str,
        voice: str = "alexis",
        *,
        max_tokens: Optional[int] = None,
        temperature: Optional[float] = None,
        repetition_penalty: Optional[float] = None,
        top_k: Optional[int] = None,
    ) -> AsyncIterator[bytes]:
        """
        Stream audio asynchronously from the Orpheus TTS model.

        If connect() was called first, uses a pooled multiplexed connection
        for lowest latency. Otherwise, creates a new connection per request.

        Args:
            text: The text to convert to speech.
            voice: Voice to use. See orpheus_tts.VOICES for options.
            max_tokens: Override default max_tokens.
            temperature: Override default temperature.
            repetition_penalty: Override default repetition_penalty.
            top_k: Override default top_k.

        Yields:
            bytes: Raw PCM audio chunks (int16, 48kHz, mono).

        Raises:
            ValueError: If voice is not recognized.
            AuthenticationError: If API key is invalid.
            ConnectionError: If connection to service fails.
            StreamingError: If an error occurs during streaming.
        """
        voice = voice.lower().strip()
        endpoint = self._get_endpoint(voice)

        if self._connected and self._loop is not None:
            # Use pool — stream on background loop, bridge chunks back
            chunk_queue: queue.Queue = queue.Queue()
            error_holder: list = []

            async def _run():
                request_body = self._build_request_body(
                    text, voice, max_tokens, temperature,
                    repetition_penalty, top_k
                )

                # Fire-and-forget health ping
                try:
                    health_url = _get_health_url(endpoint)
                    asyncio.get_running_loop().run_in_executor(
                        None, _fire_health_ping, health_url
                    )
                except Exception:
                    pass

                last_error: Optional[Exception] = None
                for attempt in range(3):
                    try:
                        conn = self._acquire(voice)
                        async for audio_chunk in conn.stream_request(request_body):
                            chunk_queue.put(audio_chunk)
                        return  # success
                    except AuthenticationError:
                        raise  # never retry auth errors
                    except (ConnectionError, StreamingError, ConnectionClosed) as e:
                        last_error = e
                        # Await pool repair so next retry has live connections
                        await self._replace_dead_connections(endpoint)
                        continue
                raise last_error  # type: ignore[misc]

            async def _run_wrapper():
                try:
                    await _run()
                except Exception as e:
                    error_holder.append(e)
                finally:
                    chunk_queue.put(None)

            future = asyncio.run_coroutine_threadsafe(
                _run_wrapper(), self._loop
            )

            loop = asyncio.get_running_loop()
            while True:
                chunk = await loop.run_in_executor(None, chunk_queue.get)
                if chunk is None:
                    break
                yield chunk

            try:
                future.result(timeout=5.0)
            except Exception as e:
                if not error_holder:
                    error_holder.append(e)

            if error_holder:
                raise error_holder[0]
        else:
            # No pool - create new basic connection (higher latency)
            try:
                async with websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    async for chunk in self._stream_on_connection(
                        ws, text, voice, max_tokens, temperature,
                        repetition_penalty, top_k
                    ):
                        yield chunk

            except ConnectionClosed as e:
                raise ConnectionError(
                    f"Connection closed unexpectedly: {e}"
                ) from e
            except OSError as e:
                raise ConnectionError(
                    f"Failed to connect to TTS service: {e}"
                ) from e
            except (AuthenticationError, StreamingError):
                raise
            except Exception as e:
                raise OrpheusError(f"Unexpected error: {e}") from e

    def _stream_with_new_connection(
        self,
        text: str,
        voice: str,
        endpoint: str,
        max_tokens: Optional[int],
        temperature: Optional[float],
        repetition_penalty: Optional[float],
        top_k: Optional[int],
    ) -> Iterator[bytes]:
        """Stream with a fresh basic connection (includes handshake in latency)."""
        chunk_queue: queue.Queue = queue.Queue()
        error_holder: list = []

        async def collect():
            try:
                async with websockets.connect(
                    self._build_url(endpoint),
                    max_size=16 * 1024 * 1024,
                    ping_interval=30,
                    ping_timeout=10,
                    close_timeout=5,
                ) as ws:
                    async for chunk in self._stream_on_connection(
                        ws, text, voice, max_tokens, temperature,
                        repetition_penalty, top_k
                    ):
                        chunk_queue.put(chunk)
            except Exception as e:
                error_holder.append(e)
            finally:
                chunk_queue.put(None)

        def run_async():
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            try:
                loop.run_until_complete(collect())
            finally:
                loop.run_until_complete(loop.shutdown_asyncgens())
                loop.close()

        thread = threading.Thread(target=run_async, daemon=True)
        thread.start()

        while True:
            chunk = chunk_queue.get()
            if chunk is None:
                break
            yield chunk

        thread.join(timeout=5.0)

        if error_holder:
            raise error_holder[0]

    def stream_to_bytes(
        self,
        text: str,
        voice: str = "alexis",
        **kwargs,
    ) -> bytes:
        """
        Generate complete audio and return as bytes.

        Convenience method that collects all streamed chunks.

        Args:
            text: The text to convert to speech.
            voice: Voice to use.
            **kwargs: Additional arguments passed to stream().

        Returns:
            bytes: Complete PCM audio (int16, 48kHz, mono).
        """
        chunks = list(self.stream(text, voice, **kwargs))
        return b"".join(chunks)

    async def stream_to_bytes_async(
        self,
        text: str,
        voice: str = "alexis",
        **kwargs,
    ) -> bytes:
        """
        Generate complete audio asynchronously and return as bytes.

        Args:
            text: The text to convert to speech.
            voice: Voice to use.
            **kwargs: Additional arguments passed to stream_async().

        Returns:
            bytes: Complete PCM audio (int16, 48kHz, mono).
        """
        chunks = []
        async for chunk in self.stream_async(text, voice, **kwargs):
            chunks.append(chunk)
        return b"".join(chunks)
