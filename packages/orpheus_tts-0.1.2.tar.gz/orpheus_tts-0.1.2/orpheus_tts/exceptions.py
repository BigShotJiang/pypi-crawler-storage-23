"""Custom exceptions for the Orpheus TTS SDK."""


class OrpheusError(Exception):
    """Base exception for Orpheus TTS errors."""

    pass


class AuthenticationError(OrpheusError):
    """Raised when API key is missing or invalid."""

    pass


class ConnectionError(OrpheusError):
    """Raised when connection to the TTS service fails."""

    pass


class StreamingError(OrpheusError):
    """Raised when an error occurs during audio streaming."""

    pass

