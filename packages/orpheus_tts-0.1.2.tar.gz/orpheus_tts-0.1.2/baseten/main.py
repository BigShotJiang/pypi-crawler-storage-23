#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "httpx",
#     "numpy",
#     "websockets",
# ]
# ///
"""
TTS Benchmark Client - Tests TTS endpoints with sustained concurrency.

Supports four modes (all return raw PCM):
- local: Calls local gateway /tts endpoint (HTTP streaming)
- websocket: Calls local gateway /ws/tts endpoint (WebSocket streaming, lowest latency)
- direct: Calls per-LLM Baseten deployments directly
- gateway: Calls Canopy gateway API

Usage:
    python test_tts.py --mode local -n 10
    python test_tts.py --mode websocket -n 10
    python test_tts.py --mode direct -n 10
    python test_tts.py --mode gateway -n 10
"""

import asyncio
import argparse
import json
import random
import secrets
import time
from collections import defaultdict
from pathlib import Path
from typing import List, Optional, Tuple
import inspect

import httpx
import numpy as np
import os
import sys

os.environ["BASETEN_API_KEY"] = "GoAPmVhH.yP7CZhsYimcQo0rQP1CTaQrc4LMmXVE5"  # Place baseten api key here

try:
    import websockets
except ImportError:
    websockets = None


# =============================================================================
# Constants
# =============================================================================

SAMPLE_RATE = 48000  # Server outputs 48kHz PCM

# Endpoint URLs
# LOCAL_GATEWAY_URL = "http://localhost:8000"
LOCAL_GATEWAY_URL = "http://89.169.108.21:8000"
# WebSocket endpoint (use for mode=websocket when calling external Baseten WS)
WEBSOCKET_URL = "wss://model-yqvjenxq.api.baseten.co/environments/production/websocket"
USE_WS_POOL = False  # Set True to reuse connections; False = one connection per request
_BENCH_START = None
REMOTE_GATEWAY_URL = "https://api.canopylabs.ai/v1/audio/speech"
REMOTE_GATEWAY_MODEL = "canopylabs/orpheus-v1-english/colin"

# Direct Baseten deployment URL (single deployment serves all voices)
DIRECT_BASETEN_URL = "https://model-yqvjkrjq.api.baseten.co/deployment/3yd0gvk/predict"

# LLM to voices mapping
LLM_VOICES = [
    {
        "llm": "llm1",
        "voices": ["colin", "hannah_hayes", "lionel", "elisabeth_rudolph"]
    },
    {
        "llm": "llm2",
        "voices": ["austin_vanfleet", "chelsea_constantino", "daniel_smith", "chris_arias"]
    },
    {
        "llm": "llm3",
        "voices": ["sarah_partridge", "garan_patrick", "josh_musgrove", "artsitha", "dan_amerman"]
    },
    {
        "llm": "llm4",
        "voices": ["troy", "autumn", "diana"]
    },
]

# Build voice to LLM mapping
VOICE_TO_LLM = {}
for llm_config in LLM_VOICES:
    for voice in llm_config["voices"]:
        VOICE_TO_LLM[voice] = llm_config["llm"]

ALL_VOICES = list(VOICE_TO_LLM.keys())

# Test prompts
PROMPTS = [
    "Hello, this is a test of the text to speech system. We are evaluating clarity, pronunciation, and naturalness.",
    "The quick brown fox jumps over the lazy dog near the riverbank. A ripple in the water adds some suspense.",
    "Welcome to our audio streaming service. Discover new content, genres, and personalized recommendations.",
    "Artificial intelligence is changing how we interact with technology, driving smarter automation and better interfaces.",
    "The weather today is sunny with a chance of rain, so consider bringing an umbrella. Gentle breezes are expected.",
    "Subscribe to our channel for updates. Get notifications about new content and features in audio technology.",
    "Creativity knows no bounds. Imagination leads to innovation and transforms challenges into opportunities.",
    "Consistency and dedication lead to success. Keep improving even when progress is slow or obstacles appear.",
    "Music evokes emotion and brings people together, crossing language and cultural barriers to unite audiences.",
    "Thank you for listening and supporting us. Your feedback helps us improve and inspires us to create more.",
]


# =============================================================================
# Utility Functions
# =============================================================================

def get_api_key(mode: str) -> str | None:
    """Get the appropriate API key for the given mode."""
    if mode == "local":
        return None
    elif mode == "direct":
        key = os.getenv('BASETEN_API_KEY')
        if not key:
            print("ERROR: BASETEN_API_KEY environment variable not set")
            print("  export BASETEN_API_KEY=your_api_key")
            sys.exit(1)
        return key
    elif mode == "websocket":
        key = os.getenv('BASETEN_API_KEY')
        if not key:
            print("ERROR: BASETEN_API_KEY environment variable not set")
            print("  export BASETEN_API_KEY=your_api_key")
            sys.exit(1)
        return key
    elif mode == "gateway":
        key = os.getenv('CANOPY_GATEWAY_API_KEY')
        if not key:
            print("ERROR: CANOPY_GATEWAY_API_KEY environment variable not set")
            print("  export CANOPY_GATEWAY_API_KEY=your_api_key")
            sys.exit(1)
        return key
    return None


def make_unique_prompt(prompt: str) -> str:
    """Add random prefix to make prompt unique (avoids caching)."""
    rand_chars = ''.join(secrets.choice('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ') for _ in range(3))
    return f"{rand_chars}_{prompt}"


def save_wav(audio: np.ndarray, filepath: str, sample_rate: int = SAMPLE_RATE):
    """Save audio as WAV file."""
    import wave
    audio = np.clip(audio, -1.0, 1.0)
    audio_int16 = (audio * 32767).astype(np.int16)
    with wave.open(filepath, 'w') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        wav.writeframes(audio_int16.tobytes())


def avg(lst: List[float]) -> float:
    return sum(lst) / len(lst) if lst else 0


def percentile(lst: List[float], p: float) -> float:
    if not lst:
        return 0
    sorted_lst = sorted(lst)
    k = (len(sorted_lst) - 1) * (p / 100)
    f = int(k)
    c = f + 1 if f + 1 < len(sorted_lst) else f
    return sorted_lst[f] + (sorted_lst[c] - sorted_lst[f]) * (k - f)


# =============================================================================
# Stream TTS Audio (raw PCM)
# =============================================================================

async def stream_tts(
    client: httpx.AsyncClient,
    url: str,
    prompt: str,
    voice: str,
    stream_id: int,
    api_key: str | None,
    mode: str,
) -> Tuple[np.ndarray, dict]:
    """
    Stream audio from TTS endpoint. Returns raw PCM (int16, 44100 Hz, mono).
    """
    headers = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Api-Key {api_key}"

    request_body = {
        "prompt": prompt,
        "voice": voice,
        "max_tokens": 3000,
        "temperature": 1.0,
        "repetition_penalty": 1.1,
    }

    if mode == "gateway":
        request_body["model"] = REMOTE_GATEWAY_MODEL

    stats = {
        "voice": voice,
        # Client-side timing
        "client_ttfa_ms": None,
        # Server-side timing breakdown
        "server_prefill_ms": None,
        "server_decode_ready_ms": None,  # When enough tokens accumulated
        "server_token_accum_ms": None,   # Time from prefill to decode-ready (LLM token generation)
        "server_first_audio_ms": None,
        "server_tensor_ms": None,
        "server_batch_wait_ms": None,
        "server_gpu_ms": None,
        "server_cpu_ms": None,
        "server_batch_size": None,
        # Overall
        "total_ms": 0,
        "audio_duration_s": 0,
        "total_bytes": 0,
        "worker_id": None,
        "success": False,
    }

    audio_chunks = []
    request_start = time.perf_counter()
    first_audio_received = False
    timing_parsed = False  # Track if we've parsed the timing JSON

    try:
        # Use format=timed to get server timing (for local/direct modes)
        request_url = url
        if mode in ("local", "direct"):
            request_url = f"{url}?format=timed"
        
        async with client.stream("POST", request_url, headers=headers, json=request_body) as response:
            stats["worker_id"] = response.headers.get("X-Worker-Id")

            if response.status_code != 200:
                error_text = await response.aread()
                print(f"Stream {stream_id} [{voice}]: Error {response.status_code} - {error_text[:100]}")
                stats["total_ms"] = (time.perf_counter() - request_start) * 1000
                return np.array([], dtype=np.float32), stats

            buffer = b""
            async for chunk in response.aiter_bytes():
                if chunk:
                    # For timed format, first line is JSON timing
                    if mode in ("local", "direct") and not timing_parsed:
                        buffer += chunk
                        if b"\n" in buffer:
                            json_line, remainder = buffer.split(b"\n", 1)
                            try:
                                timing_data = json.loads(json_line.decode("utf-8"))
                                stats["server_prefill_ms"] = timing_data.get("prefill_ms")
                                stats["server_decode_ready_ms"] = timing_data.get("decode_ready_ms")
                                stats["server_token_accum_ms"] = timing_data.get("token_accum_ms")
                                stats["server_first_audio_ms"] = timing_data.get("first_audio_ms")
                                stats["server_tensor_ms"] = timing_data.get("tensor_ms")
                                stats["server_batch_wait_ms"] = timing_data.get("batch_wait_ms")
                                stats["server_gpu_ms"] = timing_data.get("gpu_ms")
                                stats["server_cpu_ms"] = timing_data.get("cpu_ms")
                                stats["server_batch_size"] = timing_data.get("batch_size")
                            except (json.JSONDecodeError, UnicodeDecodeError):
                                # If parsing fails, treat entire buffer as audio
                                remainder = buffer
                            timing_parsed = True
                            if remainder:
                                chunk = remainder
                            else:
                                continue
                        else:
                            continue
                    
                    if not first_audio_received:
                        stats["client_ttfa_ms"] = (time.perf_counter() - request_start) * 1000
                        first_audio_received = True
                        worker = stats["worker_id"] or "?"
                        prefill = stats.get("server_prefill_ms") or 0
                        srv_ttfa = stats.get("server_first_audio_ms") or 0
                        gpu = stats.get("server_gpu_ms") or 0
                        print(f"Stream {stream_id} [{voice}→{worker}]: cliTTFA={stats['client_ttfa_ms']:.1f}ms, prefill={prefill:.1f}ms, gpu={gpu:.1f}ms, srvTTFA={srv_ttfa:.1f}ms")
                    audio_chunks.append(chunk)

        stats["total_ms"] = (time.perf_counter() - request_start) * 1000

        if audio_chunks:
            pcm_bytes = b"".join(audio_chunks)
            # Truncate to even number of bytes (int16 = 2 bytes per sample)
            if len(pcm_bytes) % 2 != 0:
                pcm_bytes = pcm_bytes[:-1]
            if len(pcm_bytes) == 0:
                return np.array([], dtype=np.float32), stats
            audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
            audio = audio_int16.astype(np.float32) / 32768.0
            stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
            stats["total_bytes"] = len(pcm_bytes)
            stats["success"] = True
            print(f"Stream {stream_id} [{voice}]: Finished | {stats['audio_duration_s']:.2f}s audio | {stats['total_ms']:.0f}ms total")
            return audio, stats

        return np.array([], dtype=np.float32), stats

    except httpx.HTTPError as e:
        stats["total_ms"] = (time.perf_counter() - request_start) * 1000
        print(f"Stream {stream_id} [{voice}]: Connection error - {e}")
        return np.array([], dtype=np.float32), stats


# =============================================================================
# WebSocket Connection Pool
# =============================================================================

class WebSocketPool:
    """
    Pool of pre-established WebSocket connections for low-latency benchmarking.
    Connections are opened upfront to exclude handshake time from measurements.
    """
    
    def __init__(self, ws_url: str, pool_size: int, api_key: str | None = None):
        self.ws_url = ws_url
        self.pool_size = pool_size
        self.api_key = api_key
        self._connections: List = []
        self._available: asyncio.Queue = None
        self._lock = asyncio.Lock()
        self._created = 0
    
    def _connect_kwargs(self):
        headers = {"Authorization": f"Api-Key {self.api_key}"} if self.api_key else None
        kwargs = {
            "max_size": 16 * 1024 * 1024,
            # Keepalive pings so servers that expect them don't close idle conns
            "ping_interval": 20,
            "ping_timeout": 20,
            "close_timeout": 10,
        }

        if headers:
            params = inspect.signature(websockets.connect).parameters
            if "extra_headers" in params:
                kwargs["extra_headers"] = headers
            elif "additional_headers" in params:
                kwargs["additional_headers"] = headers
            else:
                kwargs["headers"] = headers

        return kwargs


def build_ws_connect_kwargs(api_key: str | None):
    headers = {"Authorization": f"Api-Key {api_key}"} if api_key else None
    kwargs = {
        "max_size": 16 * 1024 * 1024,
        "ping_interval": 20,
        "ping_timeout": 20,
        "close_timeout": 10,
    }
    if headers:
        params = inspect.signature(websockets.connect).parameters
        if "extra_headers" in params:
            kwargs["extra_headers"] = headers
        elif "additional_headers" in params:
            kwargs["additional_headers"] = headers
        else:
            kwargs["headers"] = headers
    return kwargs

    async def initialize(self):
        """Initialize pool; connections are created on-demand."""
        if websockets is None:
            raise ImportError("websockets package required for WebSocket mode. Install with: pip install websockets")
        
        self._available = asyncio.Queue()
        print(f"WebSocket pool ready (up to {self.pool_size} connections, created on demand)")
    
    async def acquire(self) -> "websockets.WebSocketClientProtocol":
        """Get a connection from the pool (blocks if none available)."""
        try:
            return self._available.get_nowait()
        except asyncio.QueueEmpty:
            pass

        async with self._lock:
            # Create a new connection if we haven't reached pool size
            if self._created < self.pool_size:
                try:
                    ws = await websockets.connect(
                        self.ws_url,
                        **self._connect_kwargs(),
                    )
                    self._connections.append(ws)
                    self._created += 1
                    return ws
                except Exception as e:
                    print(f"  Connection create failed: {e}")

        # Fall back to waiting for an available connection
        return await self._available.get()
    
    async def release(self, ws):
        """Return a connection to the pool."""
        # Check if connection is still open (websockets >= 10.0 uses .state, older uses .open)
        try:
            is_open = not ws.closed if hasattr(ws, 'closed') else ws.open
        except Exception:
            is_open = False
        
        if is_open:
            await self._available.put(ws)
        else:
            # Connection closed, create a new one
            try:
                new_ws = await websockets.connect(
                    self.ws_url,
                    **self._connect_kwargs(),
                )
                await self._available.put(new_ws)
            except Exception as e:
                print(f"Failed to reconnect: {e}")
    
    async def close_all(self):
        """Close all connections in the pool."""
        for ws in self._connections:
            try:
                await ws.close()
            except Exception:
                pass
        self._connections.clear()


# =============================================================================
# WebSocket TTS Streaming
# =============================================================================

async def stream_tts_websocket(
    ws_pool: WebSocketPool,
    prompt: str,
    voice: str,
    stream_id: int,
    ws_url: str | None = None,
    api_key: str | None = None,
) -> Tuple[np.ndarray, dict]:
    """
    Stream audio from TTS WebSocket endpoint using a pre-established connection.
    Returns raw PCM (int16, 48000 Hz, mono).
    
    Timing starts AFTER acquiring connection and sending request (excludes handshake).
    """
    stats = {
        "voice": voice,
        # Client-side timing
        "client_ttfa_ms": None,
        # Server-side timing breakdown
        "server_prefill_ms": None,
        "server_decode_ready_ms": None,  # When enough tokens accumulated
        "server_token_accum_ms": None,   # Time from prefill to decode-ready (LLM token generation)
        "server_first_audio_ms": None,
        "server_tensor_ms": None,
        "server_batch_wait_ms": None,
        "server_gpu_ms": None,
        "server_cpu_ms": None,
        "server_batch_size": None,
        # Overall
        "total_ms": 0,
        "audio_duration_s": 0,
        "total_bytes": 0,
        "worker_id": "ws",  # WebSocket mode has no worker ID header
        "success": False,
    }

    audio_chunks = []
    request_start = None
    ws = None
    owns_ws = False
    
    try:
        # Acquire pre-established connection from pool (or open a new one per request)
        if ws_pool is not None:
            ws = await ws_pool.acquire()
        else:
            t0 = time.perf_counter()
            bench_start = _BENCH_START if _BENCH_START is not None else t0
            print(f"Stream {stream_id}: opening WS at +{(t0 - bench_start)*1000:.1f}ms")
            ws = await websockets.connect(ws_url, **build_ws_connect_kwargs(api_key))
            owns_ws = True
            t1 = time.perf_counter()
            print(f"Stream {stream_id}: WS connected at +{(t1 - bench_start)*1000:.1f}ms")
        
        # Send request - timing starts HERE (connection already open!)
        request_body = {
            "prompt": prompt,
            "voice": voice,
            "max_tokens": 3000,
            "temperature": 1.0,
            "repetition_penalty": 1.1,
        }
        
        request_start = time.perf_counter()  # Timing starts with pre-opened connection
        await ws.send(json.dumps(request_body))
        
        first_audio_received = False
        
        # Receive streamed audio and final JSON
        async for message in ws:
            if isinstance(message, bytes):
                # Binary message = PCM audio data
                if not first_audio_received:
                    stats["client_ttfa_ms"] = (time.perf_counter() - request_start) * 1000
                    first_audio_received = True
                    print(f"Stream {stream_id} [{voice}->ws]: cliTTFA={stats['client_ttfa_ms']:.1f}ms")
                audio_chunks.append(message)
            else:
                # Text message = JSON (either error or completion)
                try:
                    data = json.loads(message)
                    
                    if "error" in data:
                        print(f"Stream {stream_id} [{voice}]: WebSocket error - {data['error']}")
                        stats["total_ms"] = (time.perf_counter() - request_start) * 1000
                        return np.array([], dtype=np.float32), stats
                    
                    if data.get("done"):
                        # Extract timing from completion message
                        timing = data.get("timing", {})
                        stats["server_prefill_ms"] = timing.get("prefill_ms")
                        stats["server_decode_ready_ms"] = timing.get("decode_ready_ms")
                        stats["server_token_accum_ms"] = timing.get("token_accum_ms")
                        stats["server_first_audio_ms"] = timing.get("first_audio_ms")
                        stats["server_tensor_ms"] = timing.get("tensor_ms")
                        stats["server_batch_wait_ms"] = timing.get("batch_wait_ms")
                        stats["server_gpu_ms"] = timing.get("gpu_ms")
                        stats["server_cpu_ms"] = timing.get("cpu_ms")
                        stats["server_batch_size"] = timing.get("batch_size")
                        break
                except json.JSONDecodeError:
                    pass
        
        stats["total_ms"] = (time.perf_counter() - request_start) * 1000
        
        if audio_chunks:
            pcm_bytes = b"".join(audio_chunks)
            # Truncate to even number of bytes (int16 = 2 bytes per sample)
            if len(pcm_bytes) % 2 != 0:
                pcm_bytes = pcm_bytes[:-1]
            if len(pcm_bytes) == 0:
                return np.array([], dtype=np.float32), stats
            audio_int16 = np.frombuffer(pcm_bytes, dtype=np.int16)
            audio = audio_int16.astype(np.float32) / 32768.0
            stats["audio_duration_s"] = len(audio) / SAMPLE_RATE
            stats["total_bytes"] = len(pcm_bytes)
            stats["success"] = True
            
            # Print final timing
            prefill = stats.get("server_prefill_ms") or 0
            srv_ttfa = stats.get("server_first_audio_ms") or 0
            gpu = stats.get("server_gpu_ms") or 0
            print(f"Stream {stream_id} [{voice}]: Finished | {stats['audio_duration_s']:.2f}s audio | {stats['total_ms']:.0f}ms total | prefill={prefill:.1f}ms, gpu={gpu:.1f}ms, srvTTFA={srv_ttfa:.1f}ms")
            return audio, stats
        
        return np.array([], dtype=np.float32), stats
        
    except Exception as e:
        if request_start:
            stats["total_ms"] = (time.perf_counter() - request_start) * 1000
        print(f"Stream {stream_id} [{voice}]: WebSocket error - {e}")
        return np.array([], dtype=np.float32), stats
    finally:
        # Return connection to pool
        if ws is not None:
            if owns_ws:
                try:
                    await ws.close()
                except Exception:
                    pass
            else:
                await ws_pool.release(ws)


# =============================================================================
# Health Check
# =============================================================================

async def check_health(client: httpx.AsyncClient, base_url: str) -> Tuple[bool, Optional[List[str]]]:
    """Check if server is healthy and get voice list."""
    health_url = base_url.rstrip("/") + "/health"
    try:
        response = await client.get(health_url, timeout=10.0)
        if response.status_code == 200:
            data = response.json()
            voices = data.get("voices", [])
            return True, voices
    except Exception as e:
        print(f"Health check failed: {e}")
    return False, None


# =============================================================================
# Main
# =============================================================================

async def main():
    parser = argparse.ArgumentParser(
        description="TTS Benchmark - test local, websocket, direct Baseten, or Canopy gateway",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Modes:
    local     - Local gateway /tts endpoint (HTTP streaming)
    websocket - Local gateway /ws/tts endpoint (WebSocket streaming, lowest latency)
    direct    - Per-LLM Baseten deployments directly
    gateway   - Canopy gateway API

Examples:
    python test_tts.py --mode local -n 10
    python test_tts.py --mode websocket -n 10
    python test_tts.py --mode direct -n 10 -c 4
    python test_tts.py --mode gateway -n 100 -c 8
        """
    )
    parser.add_argument("--mode", type=str, required=True, choices=["local", "websocket", "direct", "gateway"])
    parser.add_argument("-n", "--total", type=int, default=10, help="Total requests (default: 10)")
    parser.add_argument("-c", "--concurrency", type=int, default=4, help="Concurrent requests PER LLM (default: 4)")
    parser.add_argument("-s", "--stagger", type=float, default=10.0, help="Delay between requests in ms (default: 10)")
    parser.add_argument("-p", "--prompt", type=str, default=None, help="Custom prompt")
    parser.add_argument("-o", "--output-dir", type=str, default="./tts_benchmark_audio")
    parser.add_argument("--voice", type=str, default=None, help="Specific voice (default: round-robin across LLMs)")
    parser.add_argument("--local-url", type=str, default=LOCAL_GATEWAY_URL)
    parser.add_argument("--no-save", action="store_true")
    args = parser.parse_args()

    # Validate API key early
    api_key = get_api_key(args.mode)

    output_dir = Path(args.output_dir)
    if not args.no_save:
        output_dir.mkdir(exist_ok=True)

    num_llms = len(LLM_VOICES)
    max_concurrent = args.concurrency * num_llms

    # Validate websockets package for websocket mode
    if args.mode == "websocket" and websockets is None:
        print("ERROR: websockets package required for WebSocket mode")
        print("  pip install websockets")
        sys.exit(1)

    print("=" * 80)
    print("TTS BENCHMARK")
    print("=" * 80)
    print(f"Mode: {args.mode}")
    if args.mode == "local":
        print(f"Gateway URL: {args.local_url}/tts")
    elif args.mode == "websocket":
        print(f"WebSocket URL: {WEBSOCKET_URL}")
        print(f"Note: Timing excludes WebSocket handshake (starts after sending request)")
    elif args.mode == "direct":
        print(f"Per-LLM Baseten endpoints ({num_llms} LLMs)")
        print(f"API Key: BASETEN_API_KEY ({api_key[:8]}...)")
    else:
        print(f"Gateway URL: {REMOTE_GATEWAY_URL}")
        print(f"API Key: CANOPY_GATEWAY_API_KEY ({api_key[:8]}...)")
    print(f"Total requests: {args.total}")
    print(f"Concurrent per LLM: {args.concurrency}")
    print(f"Max simultaneous: {max_concurrent}")
    print(f"Stagger: {args.stagger}ms")
    print("-" * 80)

    # High connection limits with httpx
    limits = httpx.Limits(
        max_keepalive_connections=200,
        max_connections=500,
        keepalive_expiry=60.0,
    )

    timeout = httpx.Timeout(
        timeout=300.0,
        connect=10.0,
        read=120.0,
    )

    async with httpx.AsyncClient(limits=limits, timeout=timeout) as client:
        # Health check for local and websocket modes
        if args.mode in ("local", "websocket"):
            print("Checking server health...")
            healthy, available_voices = await check_health(client, args.local_url)
            if healthy:
                print(f"Server is healthy, voices: {available_voices}")
            else:
                print("Health check failed (continuing anyway)")

        # Show LLM mapping
        print(f"\nLLM to endpoint mapping:")
        for llm_config in LLM_VOICES:
            print(f"  {llm_config['llm']}: {llm_config['voices']}")
        print("-" * 80)

        # Create per-LLM semaphores (key difference from broken version!)
        llm_semaphores = {llm["llm"]: asyncio.Semaphore(args.concurrency) for llm in LLM_VOICES}
        llm_to_voices = {llm["llm"]: llm["voices"] for llm in LLM_VOICES}
        llm_names = list(llm_to_voices.keys())

        # For WebSocket mode: create connection pool BEFORE timing starts
        ws_pool = None
        if args.mode == "websocket" and USE_WS_POOL:
            # Pool size = max simultaneous requests
            pool_size = max_concurrent
            ws_pool = WebSocketPool(WEBSOCKET_URL, pool_size=pool_size, api_key=api_key)
            await ws_pool.initialize()
            print(f"WebSocket pool ready with up to {pool_size} connections")
            print("-" * 80)
        elif args.mode == "websocket":
            print("WebSocket pooling disabled (one connection per request)")
            print("-" * 80)

        results = []
        results_lock = asyncio.Lock()
        completed_count = [0]
        start_time = time.perf_counter()
        global _BENCH_START
        _BENCH_START = start_time
        inflight_count = 0
        max_inflight = 0
        inflight_lock = asyncio.Lock()

        async def run_request(stream_id: int, llm_name: str, stagger_delay_ms: float):
            """Run request with per-LLM semaphore control."""
            if stagger_delay_ms > 0:
                await asyncio.sleep(stagger_delay_ms / 1000)

            voice = args.voice if args.voice else random.choice(llm_to_voices[llm_name])

            # Use per-LLM semaphore
            async with llm_semaphores[llm_name]:
                nonlocal inflight_count, max_inflight
                async with inflight_lock:
                    inflight_count += 1
                    if inflight_count > max_inflight:
                        max_inflight = inflight_count
                    print(f"Stream {stream_id}: inflight={inflight_count} (max={max_inflight})")

                prompt = args.prompt if args.prompt else make_unique_prompt(PROMPTS[stream_id % len(PROMPTS)])
                
                if args.mode == "websocket":
                    # WebSocket mode - use pre-established connection pool
                    result = await stream_tts_websocket(
                        ws_pool,
                        prompt,
                        voice,
                        stream_id,
                        ws_url=WEBSOCKET_URL,
                        api_key=api_key,
                    )
                else:
                    # HTTP modes (local, direct, gateway)
                    if args.mode == "local":
                        endpoint_url = f"{args.local_url}/tts"
                    elif args.mode == "direct":
                        endpoint_url = DIRECT_BASETEN_URL
                    else:  # gateway
                        endpoint_url = REMOTE_GATEWAY_URL
                    
                    result = await stream_tts(client, endpoint_url, prompt, voice, stream_id, api_key, args.mode)

                async with results_lock:
                    results.append(result)
                    completed_count[0] += 1
                    elapsed = time.perf_counter() - start_time
                    print(f"  [{completed_count[0]}/{args.total}] completed in {elapsed:.1f}s")
                async with inflight_lock:
                    inflight_count -= 1
                    print(f"Stream {stream_id}: inflight={inflight_count} (max={max_inflight})")

                return result

        # Distribute requests round-robin across LLMs
        tasks = []
        for i in range(args.total):
            llm_name = llm_names[i % num_llms]
            stagger_delay = i * args.stagger
            tasks.append(run_request(i, llm_name, stagger_delay))

        # Show distribution
        print(f"\nRequest distribution ({args.total} total):")
        dist = defaultdict(int)
        for i in range(args.total):
            dist[llm_names[i % num_llms]] += 1
        for llm_name in sorted(dist.keys()):
            print(f"  {llm_name}: {dist[llm_name]} requests")
        print()

        print(f"Starting {args.total} requests...")
        print()

        try:
            await asyncio.gather(*tasks)
        finally:
            # Clean up WebSocket pool
            if ws_pool:
                await ws_pool.close_all()

        total_time = time.perf_counter() - start_time
        print()
        print(f"All {args.total} requests completed in {total_time:.1f}s")
        print(f"Max inflight: {max_inflight}")
        print(f"Throughput: {args.total / total_time:.2f} requests/sec")

    # Process results
    print("-" * 80)
    all_stats = []

    for i, (audio, stats) in enumerate(results):
        all_stats.append(stats)
        if len(audio) > 0 and not args.no_save:
            voice = stats.get("voice", "unknown")
            worker = stats.get("worker_id", "unknown") or "unknown"
            filepath = output_dir / f"{args.mode}_{voice}_{worker}_{i}.wav"
            save_wav(audio, str(filepath))
            print(f"Saved: {filepath} ({stats.get('audio_duration_s', 0):.2f}s)")
        elif len(audio) == 0:
            print(f"Stream {i} [{stats.get('voice', '?')}]: No audio received")

    # Statistics
    print()
    print("=" * 80)
    print("PER-VOICE STATISTICS")
    print("=" * 80)

    voice_stats = defaultdict(list)
    for stats in all_stats:
        voice_stats[stats.get("voice", "unknown")].append(stats)

    for voice in sorted(voice_stats.keys()):
        stats_list = voice_stats[voice]
        successful = [s for s in stats_list if s.get("success")]
        print(f"\nVoice: {voice} ({len(successful)}/{len(stats_list)} successful)")
        print("-" * 60)
        workers = set(s.get("worker_id") for s in stats_list if s.get("worker_id"))
        if workers:
            print(f"  Worker(s): {', '.join(str(w) for w in workers)}")
        client_ttfas = [s.get("client_ttfa_ms") for s in successful if s.get("client_ttfa_ms")]
        server_prefills = [s.get("server_prefill_ms") for s in successful if s.get("server_prefill_ms")]
        server_gpus = [s.get("server_gpu_ms") for s in successful if s.get("server_gpu_ms")]
        server_ttfas = [s.get("server_first_audio_ms") for s in successful if s.get("server_first_audio_ms")]
        totals = [s.get("total_ms") for s in successful if s.get("total_ms")]
        durations = [s.get("audio_duration_s") for s in successful if s.get("audio_duration_s")]
        if client_ttfas:
            print(f"  Client TTFA:  {avg(client_ttfas):>7.1f}ms avg ({min(client_ttfas):>6.1f} - {max(client_ttfas):>6.1f}ms)")
        if server_prefills:
            print(f"  Srv Prefill:  {avg(server_prefills):>7.1f}ms avg ({min(server_prefills):>6.1f} - {max(server_prefills):>6.1f}ms)")
        if server_gpus:
            print(f"  Srv GPU:      {avg(server_gpus):>7.1f}ms avg ({min(server_gpus):>6.1f} - {max(server_gpus):>6.1f}ms)")
        if server_ttfas:
            print(f"  Srv TTFA:     {avg(server_ttfas):>7.1f}ms avg ({min(server_ttfas):>6.1f} - {max(server_ttfas):>6.1f}ms)")
        if totals:
            print(f"  Total:        {avg(totals):>7.1f}ms avg ({min(totals):>6.1f} - {max(totals):>6.1f}ms)")
        if durations:
            print(f"  Audio:        {avg(durations):>7.2f}s  avg ({min(durations):>6.2f} - {max(durations):>6.2f}s)")
            rtfs = [(s.get("total_ms", 0) / 1000) / s.get("audio_duration_s", 1)
                    for s in successful if s.get("audio_duration_s", 0) > 0]
            if rtfs:
                print(f"  RTF:          {avg(rtfs):>7.2f}x  avg ({min(rtfs):>6.2f} - {max(rtfs):>6.2f}x)")

    # Overall
    print()
    print("=" * 180)
    print("OVERALL TIMING ANALYSIS")
    print("=" * 180)
    print()
    print(f"{'#':>3} {'Voice':>15} {'Wkr':>4} {'cliTTFA':>8} {'Prefill':>8} {'TokAcc':>8} {'Tensor':>7} {'Batch':>7} {'GPU':>7} {'CPU':>6} {'srvTTFA':>8} {'Total':>8} {'Audio':>6} {'RTF':>5} {'BS':>3}")
    print("-" * 180)

    all_client_ttfa = []
    all_server_prefill = []
    all_server_token_accum = []
    all_server_tensor = []
    all_server_batch_wait = []
    all_server_gpu = []
    all_server_cpu = []
    all_server_ttfa = []
    all_totals = []
    all_rtfs = []
    all_durations = []

    for i, stats in enumerate(all_stats):
        voice = stats.get("voice", "?")[:15]
        worker = (stats.get("worker_id") or "?")[:4]
        client_ttfa = stats.get("client_ttfa_ms") or 0
        server_prefill = stats.get("server_prefill_ms") or 0
        server_token_accum = stats.get("server_token_accum_ms") or 0
        server_tensor = stats.get("server_tensor_ms") or 0
        server_batch_wait = stats.get("server_batch_wait_ms") or 0
        server_gpu = stats.get("server_gpu_ms") or 0
        server_cpu = stats.get("server_cpu_ms") or 0
        server_ttfa = stats.get("server_first_audio_ms") or 0
        batch_size = stats.get("server_batch_size") or 0
        total = stats.get("total_ms") or 0
        audio_duration = stats.get("audio_duration_s") or 0
        rtf = (total / 1000) / audio_duration if audio_duration > 0 else 0

        if stats.get("success"):
            all_client_ttfa.append(client_ttfa)
            if server_prefill > 0: all_server_prefill.append(server_prefill)
            if server_token_accum > 0: all_server_token_accum.append(server_token_accum)
            if server_tensor > 0: all_server_tensor.append(server_tensor)
            if server_batch_wait > 0: all_server_batch_wait.append(server_batch_wait)
            if server_gpu > 0: all_server_gpu.append(server_gpu)
            if server_cpu > 0: all_server_cpu.append(server_cpu)
            if server_ttfa > 0: all_server_ttfa.append(server_ttfa)
            all_totals.append(total)
            all_durations.append(audio_duration)
            if audio_duration > 0:
                all_rtfs.append(rtf)
            print(f"{i:>3} {voice:>15} {worker:>4} {client_ttfa:>7.1f}ms {server_prefill:>7.1f}ms {server_token_accum:>7.1f}ms {server_tensor:>6.1f}ms {server_batch_wait:>6.1f}ms {server_gpu:>6.1f}ms {server_cpu:>5.1f}ms {server_ttfa:>7.1f}ms {total:>7.0f}ms {audio_duration:>5.2f}s {rtf:>4.2f}x {batch_size:>3}")
        else:
            print(f"{i:>3} {voice:>15} {worker:>4} {'FAILED':<130}")

    print()
    print("=" * 180)
    print("AGGREGATE SUMMARY")
    print("=" * 180)
    print()
    print(f"  Test parameters: n={args.total}, concurrency={args.concurrency}/LLM ({args.concurrency * num_llms} global), stagger={args.stagger}ms")
    print()

    successful = sum(1 for s in all_stats if s.get("success"))
    print(f"  Requests:       {successful}/{len(all_stats)} successful")
    print()

    if all_client_ttfa:
        print(f"  {'Metric':<14} {'Avg':>10} {'Min':>10} {'p50':>10} {'p90':>10} {'p95':>10} {'p99':>10} {'Max':>10}")
        print(f"  {'-'*14} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10} {'-'*10}")
        print(f"  {'Client TTFA':<14} {avg(all_client_ttfa):>9.1f}ms {min(all_client_ttfa):>9.1f}ms {percentile(all_client_ttfa, 50):>9.1f}ms {percentile(all_client_ttfa, 90):>9.1f}ms {percentile(all_client_ttfa, 95):>9.1f}ms {percentile(all_client_ttfa, 99):>9.1f}ms {max(all_client_ttfa):>9.1f}ms")
        if all_server_prefill:
            print(f"  {'Srv Prefill':<14} {avg(all_server_prefill):>9.1f}ms {min(all_server_prefill):>9.1f}ms {percentile(all_server_prefill, 50):>9.1f}ms {percentile(all_server_prefill, 90):>9.1f}ms {percentile(all_server_prefill, 95):>9.1f}ms {percentile(all_server_prefill, 99):>9.1f}ms {max(all_server_prefill):>9.1f}ms")
        if all_server_token_accum:
            print(f"  {'Srv TokAccum':<14} {avg(all_server_token_accum):>9.1f}ms {min(all_server_token_accum):>9.1f}ms {percentile(all_server_token_accum, 50):>9.1f}ms {percentile(all_server_token_accum, 90):>9.1f}ms {percentile(all_server_token_accum, 95):>9.1f}ms {percentile(all_server_token_accum, 99):>9.1f}ms {max(all_server_token_accum):>9.1f}ms")
        if all_server_tensor:
            print(f"  {'Srv Tensor':<14} {avg(all_server_tensor):>9.1f}ms {min(all_server_tensor):>9.1f}ms {percentile(all_server_tensor, 50):>9.1f}ms {percentile(all_server_tensor, 90):>9.1f}ms {percentile(all_server_tensor, 95):>9.1f}ms {percentile(all_server_tensor, 99):>9.1f}ms {max(all_server_tensor):>9.1f}ms")
        if all_server_batch_wait:
            print(f"  {'Srv BatchWait':<14} {avg(all_server_batch_wait):>9.1f}ms {min(all_server_batch_wait):>9.1f}ms {percentile(all_server_batch_wait, 50):>9.1f}ms {percentile(all_server_batch_wait, 90):>9.1f}ms {percentile(all_server_batch_wait, 95):>9.1f}ms {percentile(all_server_batch_wait, 99):>9.1f}ms {max(all_server_batch_wait):>9.1f}ms")
        if all_server_gpu:
            print(f"  {'Srv GPU':<14} {avg(all_server_gpu):>9.1f}ms {min(all_server_gpu):>9.1f}ms {percentile(all_server_gpu, 50):>9.1f}ms {percentile(all_server_gpu, 90):>9.1f}ms {percentile(all_server_gpu, 95):>9.1f}ms {percentile(all_server_gpu, 99):>9.1f}ms {max(all_server_gpu):>9.1f}ms")
        if all_server_cpu:
            print(f"  {'Srv CPU':<14} {avg(all_server_cpu):>9.1f}ms {min(all_server_cpu):>9.1f}ms {percentile(all_server_cpu, 50):>9.1f}ms {percentile(all_server_cpu, 90):>9.1f}ms {percentile(all_server_cpu, 95):>9.1f}ms {percentile(all_server_cpu, 99):>9.1f}ms {max(all_server_cpu):>9.1f}ms")
        if all_server_ttfa:
            print(f"  {'Srv TTFA':<14} {avg(all_server_ttfa):>9.1f}ms {min(all_server_ttfa):>9.1f}ms {percentile(all_server_ttfa, 50):>9.1f}ms {percentile(all_server_ttfa, 90):>9.1f}ms {percentile(all_server_ttfa, 95):>9.1f}ms {percentile(all_server_ttfa, 99):>9.1f}ms {max(all_server_ttfa):>9.1f}ms")
        print(f"  {'Total':<14} {avg(all_totals):>9.0f}ms {min(all_totals):>9.0f}ms {percentile(all_totals, 50):>9.0f}ms {percentile(all_totals, 90):>9.0f}ms {percentile(all_totals, 95):>9.0f}ms {percentile(all_totals, 99):>9.0f}ms {max(all_totals):>9.0f}ms")
        print(f"  {'Audio':<14} {avg(all_durations):>9.2f}s  {min(all_durations):>9.2f}s  {percentile(all_durations, 50):>9.2f}s  {percentile(all_durations, 90):>9.2f}s  {percentile(all_durations, 95):>9.2f}s  {percentile(all_durations, 99):>9.2f}s  {max(all_durations):>9.2f}s ")
        if all_rtfs:
            print(f"  {'RTF':<14} {avg(all_rtfs):>9.2f}x  {min(all_rtfs):>9.2f}x  {percentile(all_rtfs, 50):>9.2f}x  {percentile(all_rtfs, 90):>9.2f}x  {percentile(all_rtfs, 95):>9.2f}x  {percentile(all_rtfs, 99):>9.2f}x  {max(all_rtfs):>9.2f}x ")

    print()
    print("Done!")


if __name__ == "__main__":
    asyncio.run(main())