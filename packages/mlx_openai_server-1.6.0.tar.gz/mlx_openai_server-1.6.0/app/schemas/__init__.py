"""Pydantic schemas for OpenAI-compatible API."""
