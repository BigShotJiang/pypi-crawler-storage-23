"""API endpoints for the MLX OpenAI server."""
