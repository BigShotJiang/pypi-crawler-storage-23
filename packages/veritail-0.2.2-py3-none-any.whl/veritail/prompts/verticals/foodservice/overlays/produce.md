### Produce — Scoring Guidance

This query involves fruits, vegetables, and fresh produce.

**Critical distinctions to enforce:**

- **Fresh vs frozen**: Do not substitute when specified.
- **Organic vs conventional**: Hard constraint when specified.
- **Case pack and size**: Count, size grade, and pack are key.
