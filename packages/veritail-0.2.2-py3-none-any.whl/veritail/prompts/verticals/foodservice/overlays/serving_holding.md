### Serving and Holding — Scoring Guidance

This query involves equipment for holding and serving prepared food.

**Critical distinctions to enforce:**

- **Heated holding vs cooking**: Holding cabinets and heat lamps do not cook. Do not substitute.
- **Wet vs dry**: Steam tables and food wells differ (wet requires water). If query specifies wet/dry, treat as hard.
- **Sneeze guards and display**: Display cases may be heated or refrigerated; match temperature class.
