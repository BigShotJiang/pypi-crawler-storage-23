"""
Qdrant storage for row embeddings.
"""

from .write import Processor, run, default_ident
