"""
Qdrant row embeddings query service.
"""

from .service import Processor, run, default_ident
