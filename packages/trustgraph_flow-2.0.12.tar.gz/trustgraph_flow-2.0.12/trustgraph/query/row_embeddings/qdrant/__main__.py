
from .service import run

run()
