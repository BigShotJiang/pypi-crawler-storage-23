"""CSS design tokens and stylesheet — dark-only, refined from beautiful-html-report."""

FONT_LINK = (
    '<link rel="preconnect" href="https://fonts.googleapis.com">'
    '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>'
    '<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700'
    '&display=swap" rel="stylesheet">'
)

# ---------------------------------------------------------------------------
# Single CSS constant — dark palette + gold accent + React mockup refinements
# ---------------------------------------------------------------------------

CSS = """
:root {
    --bg-page: #0A0A0A;
    --bg-surface: #111113;
    --bg-surface-hover: rgba(255, 255, 255, 0.02);
    --bg-sidebar: #080808;
    --bg-inset: #0E0E10;
    --border: rgba(255, 255, 255, 0.06);
    --border-hover: rgba(255, 255, 255, 0.12);
    --text-primary: #F0EEE8;
    --text-secondary: #A8A8A0;
    --text-muted: #6B6B63;
    --accent: #B8974E;
    --status-running: #34d399;
    --status-reworking: #fb923c;
    --status-ready: #fbbf24;
    --status-failed: #f87171;
    --status-done: #6b7280;
    --radius-sm: 8px;
    --radius-md: 12px;
    --radius-lg: 16px;
    --font-main: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
}

* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: var(--font-main);
    background-color: var(--bg-page);
    color: var(--text-primary);
    line-height: 1.5;
    font-size: 14px;
    display: flex;
    height: 100vh;
    overflow: hidden;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
}

/* Typography */
h1, h2, h3, h4 {
    font-weight: 600;
    color: var(--text-primary);
    letter-spacing: -0.01em;
}

.small-caps {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 700;
    color: var(--text-muted);
}

/* ── Layout ────────────────────────────────────────────────────── */

.sidebar {
    width: 260px;
    background-color: var(--bg-sidebar);
    border-right: 1px solid var(--border);
    display: flex;
    flex-direction: column;
    padding: 24px 0;
    flex-shrink: 0;
}

.btn-logout {
    display: block;
    width: 100%;
    padding: 6px 12px;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    background: transparent;
    color: var(--text-secondary);
    font-size: 12px;
    cursor: pointer;
    transition: border-color 0.15s, color 0.15s;
}
.btn-logout:hover {
    border-color: var(--border-hover);
    color: var(--text-primary);
}

.main-content {
    flex: 1;
    overflow-y: auto;
    padding: 40px 48px;
    display: flex;
    flex-direction: column;
    gap: 40px;
}

/* ── Sidebar ───────────────────────────────────────────────────── */

.brand {
    padding: 0 24px;
    margin-bottom: 32px;
    display: flex;
    align-items: center;
    gap: 12px;
}

.brand-name {
    font-size: 14px;
    letter-spacing: 0.1em;
    color: var(--text-primary);
    font-weight: 700;
}

.status-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background-color: var(--status-running);
    box-shadow: 0 0 8px var(--status-running);
    flex-shrink: 0;
}

.status-dot.stopped {
    background-color: var(--text-muted);
    box-shadow: none;
}

.global-hud {
    padding: 0 24px;
    margin-bottom: 40px;
    display: flex;
    flex-direction: column;
    gap: 14px;
}

.hud-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 12px;
}

.hud-label {
    color: var(--text-muted);
}

.hud-value {
    color: var(--text-secondary);
    font-family: monospace;
    font-size: 12px;
}

.nav-menu {
    list-style: none;
    display: flex;
    flex-direction: column;
    padding: 0 12px;
    gap: 2px;
    margin-bottom: auto;
}

.nav-item {
    padding: 10px 16px;
    color: var(--text-muted);
    text-decoration: none;
    display: block;
    border-radius: var(--radius-md);
    transition: all 0.2s ease;
    cursor: pointer;
    font-size: 13px;
    font-weight: 600;
}

.nav-item:hover {
    color: var(--text-primary);
    background: var(--bg-surface-hover);
}

.nav-item.active {
    color: var(--text-primary);
    background: rgba(255, 255, 255, 0.06);
}

/* ── Panels ────────────────────────────────────────────────────── */

.panel {
    display: none;
    animation: fadeIn 0.3s ease;
}

.panel.active {
    display: block;
}

@keyframes fadeIn {
    from { opacity: 0; transform: translateY(4px); }
    to { opacity: 1; transform: translateY(0); }
}

.panel-header {
    margin-bottom: 28px;
    display: flex;
    justify-content: space-between;
    align-items: flex-end;
}

.panel-title {
    font-size: 22px;
    margin-bottom: 6px;
}

.panel-desc {
    color: var(--text-muted);
    font-size: 13px;
}

/* ── Cards ─────────────────────────────────────────────────────── */

.card {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 20px;
    transition: border-color 0.2s ease;
}

.card:hover {
    border-color: var(--border-hover);
}

.card-label {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: 0.08em;
    font-weight: 700;
    color: var(--text-muted);
    margin-bottom: 14px;
}

/* ── Bot Cards ─────────────────────────────────────────────────── */

.bot-matrix {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 16px;
}

.bot-card {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 16px;
    transition: border-color 0.2s ease;
}

.bot-card:hover {
    border-color: var(--border-hover);
}

.bot-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 14px;
    border-bottom: 1px solid var(--border);
}

.bot-name {
    font-size: 15px;
    font-weight: 600;
}

.bot-status {
    font-size: 11px;
    font-weight: 600;
    display: flex;
    align-items: center;
    gap: 6px;
}

.bot-details {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.bot-detail-row {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
}

.bot-detail-label {
    color: var(--text-muted);
}

.bot-detail-value {
    color: var(--text-secondary);
    font-family: monospace;
    font-size: 12px;
}

/* ── Status Pills ──────────────────────────────────────────────── */

.status-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 3px 10px;
    border-radius: 20px;
    font-size: 11px;
    font-weight: 600;
    letter-spacing: 0.02em;
    border: 1px solid transparent;
    white-space: nowrap;
}

.status-pill--running {
    color: var(--status-running);
    background: rgba(52, 211, 153, 0.08);
    border-color: rgba(52, 211, 153, 0.2);
}

.status-pill--reworking {
    color: var(--status-reworking);
    background: rgba(251, 146, 60, 0.08);
    border-color: rgba(251, 146, 60, 0.2);
}

.status-pill--ready {
    color: var(--status-ready);
    background: rgba(251, 191, 36, 0.08);
    border-color: rgba(251, 191, 36, 0.2);
}

.status-pill--failed {
    color: var(--status-failed);
    background: rgba(248, 113, 113, 0.08);
    border-color: rgba(248, 113, 113, 0.2);
}

.status-pill--done {
    color: var(--text-muted);
    background: rgba(107, 114, 128, 0.08);
    border-color: rgba(107, 114, 128, 0.2);
}

.status-pill--idle {
    color: var(--text-muted);
    background: transparent;
    border-color: var(--border);
}

.status-pill .pill-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
    flex-shrink: 0;
}

.status-pill--running .pill-dot {
    background: var(--status-running);
    box-shadow: 0 0 6px var(--status-running);
}

.status-pill--reworking .pill-dot { background: var(--status-reworking); }
.status-pill--ready .pill-dot { background: var(--status-ready); }
.status-pill--failed .pill-dot { background: var(--status-failed); }
.status-pill--done .pill-dot { background: var(--status-done); }
.status-pill--idle .pill-dot { background: var(--text-muted); }

/* ── Provider Connections ──────────────────────────────────────── */

.provider-row {
    border: 1px solid var(--border);
    background: var(--bg-surface);
    border-radius: var(--radius-md);
    padding: 16px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
    transition: border-color 0.2s ease;
}

.provider-row:hover {
    border-color: var(--border-hover);
}

.provider-name {
    font-weight: 600;
    font-size: 14px;
}

.provider-detail {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 3px;
}

/* ── Orchestration Panel ───────────────────────────────────────── */

/* Summary strip — one horizontal row of status counts */
.orch-summary-strip {
    display: flex;
    align-items: center;
    gap: 16px;
    flex-wrap: wrap;
    padding: 16px 20px;
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    margin-bottom: 20px;
}

.orch-summary-stat {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    font-weight: 600;
}

.orch-summary-stat .stat-count {
    font-family: monospace;
    font-size: 16px;
    font-weight: 700;
}

.orch-summary-stat .stat-label {
    color: var(--text-muted);
    font-size: 12px;
    font-weight: 500;
}

.orch-summary-sep {
    width: 1px;
    height: 20px;
    background: var(--border);
}

.orch-summary-updated {
    margin-left: auto;
    font-size: 11px;
    color: var(--text-muted);
    font-family: monospace;
}

/* Subagent pills — horizontal clickable row */
.orch-agents-bar {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    margin-bottom: 20px;
}

.orch-agent-pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 14px;
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s ease;
    color: var(--text-secondary);
}

.orch-agent-pill:hover {
    border-color: var(--border-hover);
    color: var(--text-primary);
}

.orch-agent-pill.active {
    border-color: var(--accent);
    color: var(--text-primary);
}

.orch-agent-pill .pill-dot {
    width: 6px;
    height: 6px;
    border-radius: 50%;
}

.orch-agent-count {
    font-family: monospace;
    font-size: 11px;
    color: var(--text-muted);
}

/* Jobs — grouped sections with status-first rows */
.orch-section {
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    margin-bottom: 16px;
    overflow: hidden;
}

.orch-section-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    cursor: pointer;
    user-select: none;
    transition: background 0.15s ease;
}

.orch-section-header:hover {
    background: var(--bg-surface-hover);
}

.orch-section-title {
    display: flex;
    align-items: center;
    gap: 10px;
    font-size: 12px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.06em;
    color: var(--text-muted);
}

.orch-section-title .section-count {
    font-family: monospace;
    font-size: 12px;
    background: rgba(255, 255, 255, 0.04);
    padding: 2px 8px;
    border-radius: 10px;
}

.orch-section-chevron {
    color: var(--text-muted);
    font-size: 12px;
    transition: transform 0.2s ease;
}

.orch-section.collapsed .orch-section-chevron {
    transform: rotate(-90deg);
}

.orch-section-body {
    border-top: 1px solid var(--border);
}

.orch-section.collapsed .orch-section-body {
    display: none;
}

/* Individual job row */
.orch-job-row {
    display: flex;
    align-items: flex-start;
    gap: 14px;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
    transition: background 0.15s ease;
}

.orch-job-row:last-child {
    border-bottom: none;
}

.orch-job-row:hover {
    background: var(--bg-surface-hover);
}

.orch-job-row {
    cursor: pointer;
}

.orch-job-status {
    flex-shrink: 0;
    margin-top: 2px;
}

.orch-job-log-open {
    display: inline-block;
    margin-left: 8px;
    font-size: 11px;
    color: var(--text-muted);
}

.orch-job-log-open:hover {
    color: var(--text-primary);
}
.orch-job-body {
    flex: 1;
    min-width: 0;
}

.orch-job-title {
    font-size: 13px;
    font-weight: 500;
    color: var(--text-primary);
    line-height: 1.4;
}

.orch-job-title .job-id {
    font-family: monospace;
    font-size: 11px;
    color: var(--text-muted);
    margin-left: 6px;
}

.orch-job-meta {
    display: flex;
    gap: 12px;
    margin-top: 4px;
    font-size: 11px;
    color: var(--text-muted);
    flex-wrap: wrap;
}

.orch-job-meta span {
    display: inline-flex;
    align-items: center;
    gap: 4px;
}

.orch-job-error {
    margin-top: 6px;
    font-size: 11px;
    color: var(--status-failed);
    font-family: monospace;
    opacity: 0.85;
}

.orch-jobs-empty {
    padding: 32px 20px;
    text-align: center;
    color: var(--text-muted);
    font-size: 13px;
}

/* Pagination */
.orch-pagination {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
    border-top: 1px solid var(--border);
    font-size: 12px;
    color: var(--text-muted);
}

.orch-pagination-btns {
    display: flex;
    gap: 6px;
}

/* Events — vertical timeline */
.orch-events-card {
    background: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    overflow: hidden;
}

.orch-events-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
}

.orch-events-body {
    max-height: 360px;
    overflow-y: auto;
    position: relative;
}

.orch-timeline {
    padding: 8px 0;
}

.orch-event {
    display: flex;
    align-items: flex-start;
    gap: 12px;
    padding: 8px 20px;
    position: relative;
    font-size: 12px;
}

.orch-event-time {
    flex-shrink: 0;
    width: 48px;
    font-family: monospace;
    font-size: 11px;
    color: var(--text-muted);
    text-align: right;
    padding-top: 1px;
}

.orch-event-dot-col {
    flex-shrink: 0;
    width: 16px;
    display: flex;
    flex-direction: column;
    align-items: center;
    position: relative;
}

.orch-event-dot {
    width: 7px;
    height: 7px;
    border-radius: 50%;
    background: var(--text-muted);
    margin-top: 4px;
    position: relative;
    z-index: 1;
    flex-shrink: 0;
}

.orch-event-dot.dot-active { background: var(--status-running); }
.orch-event-dot.dot-reworking { background: var(--status-reworking); }
.orch-event-dot.dot-failed { background: var(--status-failed); }
.orch-event-dot.dot-done { background: var(--status-done); }

/* Timeline connector line */
.orch-event:not(:last-child) .orch-event-dot-col::after {
    content: '';
    position: absolute;
    top: 14px;
    left: 50%;
    transform: translateX(-50%);
    width: 1px;
    height: calc(100% + 2px);
    background: var(--border);
}

.orch-event-text {
    flex: 1;
    color: var(--text-secondary);
    line-height: 1.4;
}

.orch-event-text strong {
    color: var(--text-primary);
    font-weight: 600;
}

.orch-event-text .ev-job {
    font-family: monospace;
    font-size: 11px;
    color: var(--text-muted);
}

/* ── Job Session Window ──────────────────────────────────────── */
.orch-job-log {
    margin-top: 16px;
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    background: var(--bg-surface);
    overflow: hidden;
}

.orch-job-log-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 14px 20px;
    border-bottom: 1px solid var(--border);
}

.orch-job-log-title {
    display: flex;
    gap: 8px;
    align-items: baseline;
}

.orch-job-log-title strong {
    color: var(--text-primary);
    font-size: 13px;
}

.orch-job-log-id {
    font-family: monospace;
    font-size: 12px;
    color: var(--text-muted);
}

.orch-job-log-controls {
    display: flex;
    align-items: center;
    gap: 8px;
}

.orch-job-log-auto {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    font-size: 11px;
    color: var(--text-muted);
}

.orch-job-log-body {
    padding: 14px 20px;
    display: grid;
    gap: 10px;
}

.orch-job-log-meta {
    font-size: 12px;
    color: var(--text-secondary);
}

.orch-job-log-error,
.orch-job-log-feedback {
    font-size: 11px;
    color: var(--text-muted);
    white-space: pre-wrap;
    line-height: 1.4;
}

.orch-job-log-error {
    color: var(--status-failed);
}

.orch-job-log-text {
    background: #090909;
    border: 1px solid var(--border);
    border-radius: 8px;
    padding: 12px;
    margin: 0;
    min-height: 180px;
    max-height: 240px;
    overflow-y: auto;
    color: var(--text-secondary);
    font-family: var(--font-main);
    font-size: 11px;
    line-height: 1.45;
    white-space: pre-wrap;
    word-break: break-all;
}

.orch-job-log-text:empty {
    display: none;
}

/* ── Configuration Panel ───────────────────────────────────────── */

.config-card {
    background-color: var(--bg-surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 28px;
    margin-bottom: 20px;
}

.config-section-label {
    margin-bottom: 24px;
}

.form-group {
    margin-bottom: 24px;
}

.form-group:last-child {
    margin-bottom: 0;
}

.form-label {
    display: block;
    margin-bottom: 8px;
    color: var(--text-muted);
    font-size: 12px;
    font-weight: 600;
}

.form-input {
    width: 100%;
    max-width: 400px;
    background-color: var(--bg-inset);
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    padding: 10px 14px;
    font-family: var(--font-main);
    font-size: 13px;
    outline: none;
    transition: border-color 0.2s;
}

.form-input:focus {
    border-color: var(--accent);
}

select.form-input {
    appearance: none;
    cursor: pointer;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 24 24' fill='none' stroke='%236B6B63' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'%3E%3C/polyline%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 12px center;
    padding-right: 32px;
}

/* ── Flash Messages ────────────────────────────────────────────── */

.flash-message {
    padding: 14px 18px;
    border-left: 3px solid var(--accent);
    border-radius: 0 var(--radius-sm) var(--radius-sm) 0;
    color: var(--text-primary);
    margin-bottom: 16px;
    font-size: 13px;
    background: var(--bg-surface);
}

/* ── Buttons ───────────────────────────────────────────────────── */

.btn {
    background: transparent;
    border: 1px solid var(--border);
    border-radius: var(--radius-sm);
    color: var(--text-primary);
    padding: 8px 20px;
    font-family: var(--font-main);
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.2s;
}

.btn:hover {
    border-color: var(--border-hover);
    background: var(--bg-surface-hover);
}

.btn:disabled {
    opacity: 0.35;
    cursor: default;
    pointer-events: none;
}

.btn-sm {
    padding: 5px 12px;
    font-size: 11px;
}

.btn-primary {
    border-color: var(--accent);
    color: var(--accent);
}

.btn-primary:hover {
    background-color: var(--accent);
    color: var(--bg-page);
}

.btn-danger {
    border-color: rgba(248, 113, 113, 0.3);
    color: var(--status-failed);
}

.btn-danger:hover {
    background: rgba(248, 113, 113, 0.1);
    border-color: rgba(248, 113, 113, 0.5);
}

/* ── Setup Wizard ──────────────────────────────────────────────── */

.wizard-container {
    display: none;
    position: fixed;
    top: 0; left: 0; right: 0; bottom: 0;
    background-color: var(--bg-page);
    z-index: 100;
    align-items: center;
    justify-content: center;
}

.wizard-container.active {
    display: flex;
}

.wizard-content {
    width: 100%;
    max-width: 480px;
}

.wizard-progress {
    display: flex;
    gap: 8px;
    margin-bottom: 48px;
}

.progress-step {
    flex: 1;
    height: 2px;
    background-color: var(--border);
    border-radius: 1px;
}

.progress-step.active {
    background-color: var(--accent);
}

.wizard-step {
    display: none;
}

.wizard-step.active {
    display: block;
    animation: fadeIn 0.4s ease;
}

.wizard-title {
    font-size: 24px;
    margin-bottom: 16px;
}

.wizard-desc {
    color: var(--text-muted);
    margin-bottom: 32px;
    line-height: 1.6;
}

.wizard-actions {
    margin-top: 48px;
    display: flex;
    justify-content: flex-end;
    gap: 16px;
}

/* ── Utility ───────────────────────────────────────────────────── */

.flex-between {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.empty-state {
    padding: 32px 24px;
    border: 1px dashed var(--border);
    border-radius: var(--radius-md);
    text-align: center;
    color: var(--text-muted);
    font-size: 13px;
}
"""
