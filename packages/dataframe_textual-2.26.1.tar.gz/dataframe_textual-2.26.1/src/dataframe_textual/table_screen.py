"""Modal screens for displaying data in tables (row details and frequency)."""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from .data_frame_table import DataFrameTable

from functools import partial

import polars as pl
from rich.text import Text
from textual.app import ComposeResult
from textual.coordinate import Coordinate
from textual.renderables.bar import Bar
from textual.screen import ModalScreen
from textual.widgets import DataTable

from .common import NULL, NULL_DISPLAY, RID, DtypeConfig, format_float
from .yes_no_screen import SaveFileScreen


class TableScreen(ModalScreen):
    """Base class for modal screens displaying data in a DataTable.

    Provides common functionality for screens that show tabular data with
    keyboard shortcuts and styling.
    """

    DEFAULT_CSS = """
        TableScreen {
            align: center middle;
        }

        TableScreen > DataTable {
            width: auto;
            height: auto;
            border: solid $primary;
            max-width: 100%;
            overflow: auto;
        }
    """

    def __init__(self, dftable: "DataFrameTable") -> None:
        """Initialize the table screen.

        Sets up the base modal screen with reference to the main DataFrameTable widget
        and stores the DataFrame for display.

        Args:
            dftable: Reference to the parent DataFrameTable widget.
        """
        super().__init__()
        self.dftable = dftable  # DataFrameTable
        self.df: pl.DataFrame = None  # DataFrame for this screen, to be set by subclasses
        self.thousand_separator = False  # Whether to use thousand separators in numbers

    def compose(self) -> ComposeResult:
        """Compose the table screen widget structure.

        Creates and yields a DataTable widget for displaying tabular data.
        Subclasses should override to customize table configuration.

        Yields:
            DataTable: The table widget for this screen.
        """
        self.table = DataTable(zebra_stripes=True)
        yield self.table

    def build_table(self) -> None:
        """Build the table content.

        Subclasses should implement this method to populate the DataTable
        with appropriate columns and rows based on the specific screen's purpose.
        """
        raise NotImplementedError("Subclasses must implement build_table method.")

    def on_key(self, event) -> None:
        """Handle key press events in the table screen.

        Provides keyboard shortcuts for navigation and interaction, including q/Escape to close.
        Prevents propagation of non-navigation keys to parent screens.

        Args:
            event: The key event object.
        """
        if event.key in ("q", "escape"):
            self.app.pop_screen()
            event.stop()
        elif event.key == "comma":
            self.thousand_separator = not self.thousand_separator
            self.build_table()
            event.stop()

    def filter_or_view_selected_value(self, cidx_name_value: tuple[int, str, Any] | None, action: str = "view") -> None:
        """Apply filter or view action by the selected value.

        Filters or views rows in the main table based on a selected value from
        this table (typically frequency or row detail). Updates the main table's display
        and notifies the user of the action.

        Args:
            col_name_value: Tuple of (column_name, column_value) to filter/view by, or None.
            action: Either "filter" to hide non-matching rows, or "view" to show matching rows. Defaults to "view".
        """
        if cidx_name_value is None:
            return
        cidx, col_name, col_value = cidx_name_value
        # self.log(f"Filtering or viewing by `{col_name} == {col_value}`")

        # Handle NULL values
        if col_value == NULL:
            # Create expression for NULL values
            expr = pl.col(col_name).is_null()
            value_display = f"[$success]{NULL_DISPLAY}[/]"
        else:
            # Create expression for the selected value
            expr = pl.col(col_name) == col_value
            value_display = f"[$success]{col_value}[/]"

        df_filtered = self.dftable.df.lazy().filter(expr).collect()
        # self.log(f"Filtered dataframe has {len(df_filtered)} rows")

        ok_rids = set(df_filtered[RID].to_list())
        if not ok_rids:
            self.notify(
                f"No matches found for [$warning]{col_name}[/] == {value_display}",
                title="No Matches",
                severity="warning",
            )
            return

        # Action filter
        if action == "filter":
            self.dftable.do_filter_rows(cidx, col_value)

        # Action view
        else:
            self.dftable.view_rows(
                {
                    "term": expr,
                    "cidx": cidx,
                    "match_nocase": False,
                    "match_whole": True,
                    "match_literal": True,
                    "match_reverse": False,
                }
            )

        # Dismiss modal screen(s) to return to main table
        while len(self.app._screen_stack) > 1:
            self.app.pop_screen()
            break

    def show_frequency(self, cidx_name_value: tuple[int, str, Any] | None) -> None:
        """Show frequency by the selected value.

        Args:
            col_name_value: Tuple of (column_name, column_value) to filter/view by, or None.
        """
        if cidx_name_value is None:
            return
        cidx, col_name, col_value = cidx_name_value
        # self.log(f"Showing frequency for `{col_name} == {col_value}`")

        # Do not dismiss the current modal screen so it can be returned to
        # when frequency screen is closed.
        # self.app.pop_screen()

        # Show frequency screen
        self.dftable.do_show_frequency(cidx)

    def show_statistics(self, cidx_name_value: tuple[int, str, Any] | None) -> None:
        """Show frequency by the selected value.

        Args:
            col_name_value: Tuple of (column_name, column_value) to filter/view by, or None.
        """
        if cidx_name_value is None:
            return
        cidx, col_name, col_value = cidx_name_value
        # self.log(f"Showing statistics for `{col_name} == {col_value}`")

        # Do not dismiss the current modal screen so it can be returned to
        # when frequency screen is closed.
        # self.app.pop_screen()

        # Show statistics screen
        self.dftable.do_show_statistics(cidx)


class RowDetailScreen(TableScreen):
    """Modal screen to display a single row's details."""

    def __init__(self, ridx: int, dftable):
        super().__init__(dftable)
        self.ridx = ridx

    def on_mount(self) -> None:
        """Initialize the row detail screen.

        Populates the table with column names and values from the selected row
        of the main DataFrame. Sets the table cursor type to "row".
        """
        self.build_table()

    def build_table(self) -> None:
        """Build the row detail table."""
        self.table.clear(columns=True)
        self.table.add_column("Column")
        self.table.add_column("Value")

        # Get all columns and values from the dataframe row
        for col, val, dtype in zip(self.dftable.df.columns, self.dftable.df.row(self.ridx), self.dftable.df.dtypes):
            if col in self.dftable.hidden_columns or col == RID:
                continue  # Skip RID column
            formatted_row = []
            formatted_row.append(col)

            dc = DtypeConfig(dtype)
            formatted_row.append(dc.format(val, justify="", thousand_separator=self.thousand_separator))
            self.table.add_row(*formatted_row)

        self.table.cursor_type = "row"

    def on_key(self, event) -> None:
        """Handle key press events on the row detail screen.

        Supported keys:
          - 'v': View the main table by the selected value.
          - '"': Filter the main table by the selected value.
          - '{': Move to the previous row.
          - '}': Move to the next row.
          - 'F': Show frequency for the selected value.
          - 's': Show statistics for the selected value.

        Args:
            event: The key event object.
        """
        if event.key == "v":
            # View the main table by the selected value
            self.filter_or_view_selected_value(self.get_cidx_name_value(), action="view")
            event.stop()
        elif event.key == "quotation_mark":  # '"'
            # Filter the main table by the selected value
            self.filter_or_view_selected_value(self.get_cidx_name_value(), action="filter")
            event.stop()
        elif event.key == "right_curly_bracket":  # '}'
            # Move to the next row
            ridx = self.ridx + 1
            if ridx < len(self.dftable.df):
                self.ridx = ridx
                self.dftable.move_cursor_to(self.ridx)
                self.build_table()
            event.stop()
        elif event.key == "left_curly_bracket":  # '{'
            # Move to the previous row
            ridx = self.ridx - 1
            if ridx >= 0:
                self.ridx = ridx
                self.dftable.move_cursor_to(self.ridx)
                self.build_table()
            event.stop()
        elif event.key == "F":
            # Show frequency for the selected value
            self.show_frequency(self.get_cidx_name_value())
            event.stop()
        elif event.key == "s":
            # Show statistics for the selected value
            self.show_statistics(self.get_cidx_name_value())
            event.stop()

    def get_cidx_name_value(self) -> tuple[int, str, Any] | None:
        """Get the current column info."""
        cidx = self.table.cursor_row
        if cidx >= len(self.dftable.df.columns):
            return None  # Invalid row

        col_name = self.dftable.df.columns[cidx]
        col_value = self.dftable.df.item(self.ridx, cidx)
        return cidx, col_name, col_value


class StatisticsScreen(TableScreen):
    """Modal screen to display statistics for a column or entire dataframe."""

    def __init__(self, dftable: "DataFrameTable", cidx: int | None = None):
        super().__init__(dftable)
        self.cidx = cidx  # None for dataframe statistics, otherwise column index
        self.df = self.build_df()

    def on_mount(self) -> None:
        """Create the statistics table."""
        self.build_table()

    def build_table(self) -> None:
        """Build the statistics table."""
        self.table.clear(columns=True)

        if self.cidx is None:
            # Dataframe statistics
            self.build_dataframe_stats()
            self.table.cursor_type = "column"
        else:
            # Column statistics
            self.build_column_stats()
            self.table.cursor_type = "row"

    def build_df(self) -> pl.DataFrame:
        """Get the dataframe to use for statistics, applying any necessary filters."""
        if self.cidx is None:
            lf = self.dftable.df.lazy().select(pl.exclude(RID))

            # Apply only to non-hidden columns
            if self.dftable.hidden_columns:
                lf = lf.select(pl.exclude(self.dftable.hidden_columns))

            # Get dataframe statistics
            stats_df = lf.describe()

            # total
            df_n_total = lf.select(pl.all().len()).collect()
            df_n_total.insert_column(0, pl.Series("statistic", ["n_total"]))
            df_n_total = df_n_total.cast(stats_df.schema)

            # unique count for each column
            df_n_unique = lf.select(pl.all().n_unique()).collect()
            df_n_unique.insert_column(0, pl.Series("statistic", ["n_unique"]))
            df_n_unique = df_n_unique.cast(stats_df.schema)

            # total first, then n_unique, then describe stats
            stats_df = df_n_total.vstack(df_n_unique).vstack(stats_df)
        else:
            col_name = self.dftable.df.columns[self.cidx]
            lf = self.dftable.df.lazy()

            # Get column statistics
            stats_df = lf.select(pl.col(col_name)).describe()
            if len(stats_df) == 0:
                return

            # unique count
            n_unique = lf.select(pl.col(col_name)).collect().n_unique()
            df_n_unique = pl.DataFrame({"statistic": ["n_unique"], col_name: n_unique}, schema=stats_df.schema)

            # total count
            n_total = len(self.dftable.df[col_name])
            df_n_total = pl.DataFrame({"statistic": ["n_total"], col_name: n_total}, schema=stats_df.schema)

            # total first, then n_unique, then describe stats
            stats_df = df_n_total.vstack(df_n_unique).vstack(stats_df)

        return stats_df

    def build_column_stats(self) -> None:
        """Build statistics for a single column."""
        col_name = self.dftable.df.columns[self.cidx]
        col_dtype = self.df.dtypes[1]  # 'value' column
        dc = DtypeConfig(col_dtype)

        # Add statistics label column
        self.table.add_column(Text("Statistic", justify="left"), key="statistic")

        # Add value column with appropriate styling
        self.table.add_column(Text(col_name, justify=dc.justify), key=col_name)

        # Add rows
        for idx, row in enumerate(self.df.rows()):
            stat_label, stat_value = row
            if idx < 4 and col_dtype == pl.String and self.thousand_separator:
                stat_value = f"{int(stat_value):,}"
            self.table.add_row(
                stat_label,
                dc.format(stat_value, thousand_separator=self.thousand_separator),
            )

    def build_dataframe_stats(self) -> None:
        """Build statistics for the entire dataframe."""
        # Add columns for each dataframe column with appropriate styling
        for idx, (col_name, col_dtype) in enumerate(zip(self.df.columns, self.df.dtypes), 0):
            if idx == 0:
                # Add statistics label column (first column, no styling)
                self.table.add_column("Statistic", key="statistic")
                continue

            dc = DtypeConfig(col_dtype)
            self.table.add_column(Text(col_name, justify=dc.justify), key=col_name)

        # Add rows
        for ridx, row in enumerate(self.df.rows()):
            formatted_row = []

            # Format remaining values with appropriate styling
            for idx, stat_value in enumerate(row):
                # First element is the statistic label
                if idx == 0:
                    formatted_row.append(stat_value)
                    continue

                col_dtype = self.df.dtypes[idx]
                dc = DtypeConfig(col_dtype)

                if ridx < 4 and col_dtype == pl.String and self.thousand_separator:
                    stat_value = f"{int(stat_value):,}"

                formatted_row.append(dc.format(stat_value, thousand_separator=self.thousand_separator))

            self.table.add_row(*formatted_row)


class FrequencyScreen(TableScreen):
    """Modal screen to display frequency of values in a column."""

    def __init__(self, cidx: int, dftable: "DataFrameTable") -> None:
        super().__init__(dftable)
        self.cidx = cidx
        self.sorted_columns = {1: True}  # Count sort by default
        self.total_count = len(dftable.df)

        col = dftable.df.columns[self.cidx]
        self.df: pl.DataFrame = dftable.df.lazy().select(pl.col(col).value_counts(sort=True)).unnest(col).collect()

    def on_mount(self) -> None:
        """Create the frequency table."""
        self.build_table()

    def on_key(self, event):
        if event.key == "left_square_bracket":  # '['
            # Sort by current column in ascending order
            self.sort_by_column(descending=False)
            event.stop()
        elif event.key == "right_square_bracket":  # ']'
            # Sort by current column in descending order
            self.sort_by_column(descending=True)
            event.stop()
        elif event.key == "v":
            # Filter the main table by the selected value
            self.filter_or_view_selected_value(self.get_cidx_name_value(), action="view")
            event.stop()
        elif event.key == "quotation_mark":  # '"'
            # Highlight the main table by the selected value
            self.filter_or_view_selected_value(self.get_cidx_name_value(), action="filter")
            event.stop()
        elif event.key == "ctrl+s":
            # Save the frequency table to file
            self.save_frequency_table()
            event.stop()

    def build_table(self) -> None:
        """Build the frequency table."""
        self.table.clear(columns=True)

        # Create frequency table
        column = self.dftable.df.columns[self.cidx]
        dtype = self.dftable.df.dtypes[self.cidx]
        dc = DtypeConfig(dtype)

        # Add column headers with sort indicators
        columns = [
            (column, "Value", 0),
            ("Count", "Count", 1),
            ("%", "%", 2),
            ("Histogram", "Histogram", 3),
        ]

        for display_name, key, col_idx_num in columns:
            # Check if this column is sorted and add indicator
            if col_idx_num in self.sorted_columns:
                descending = self.sorted_columns[col_idx_num]
                sort_indicator = " ▼" if descending else " ▲"
                header_text = display_name + sort_indicator
            else:
                header_text = display_name

            justify = dc.justify if col_idx_num == 0 else ("right" if col_idx_num in (1, 2) else "left")
            self.table.add_column(Text(header_text, justify=justify), key=key)

        # Get style config for Int64 and Float64
        dc_int = DtypeConfig(pl.Int64)
        dc_float = DtypeConfig(pl.Float64)

        # Add rows to the frequency table
        for row_idx, row in enumerate(self.df.rows()):
            column, count = row
            percentage = (count / self.total_count) * 100

            self.table.add_row(
                dc.format(column),
                dc_int.format(count, thousand_separator=self.thousand_separator),
                dc_float.format(percentage, thousand_separator=self.thousand_separator),
                Bar(
                    highlight_range=(0.0, percentage / 100 * 10),
                    width=10,
                ),
                key=str(row_idx + 1),
            )

        # Add a total row
        self.table.add_row(
            Text("Total", style="bold", justify=dc.justify),
            Text(
                f"{self.total_count:,}" if self.thousand_separator else str(self.total_count),
                style="bold",
                justify="right",
            ),
            Text(
                format_float(100.0, self.thousand_separator, precision=-2 if len(self.df) > 1 else 2),
                style="bold",
                justify="right",
            ),
            Bar(
                highlight_range=(0.0, 10),
                width=10,
            ),
            key="total",
        )

    def sort_by_column(self, descending: bool) -> None:
        """Sort the dataframe by the selected column and refresh the main table."""
        row_idx, col_idx = self.table.cursor_coordinate
        col_sort = col_idx

        if self.sorted_columns.get(col_sort) == descending:
            # self.notify("Already sorted in that order", title="Sort", severity="warning")
            return

        self.sorted_columns.clear()
        self.sorted_columns[col_sort] = descending

        # Percentage and Histogram use Count for sorting
        col_name = self.df.columns[col_sort if col_sort in (0, 1) else 1]
        self.df = self.df.sort(col_name, descending=descending, nulls_last=True)

        # Rebuild the frequency table
        self.table.clear(columns=True)
        self.build_table()

        self.table.move_cursor(row=row_idx, column=col_idx)

        # order = "desc" if descending else "asc"
        # self.notify(f"Sorted by [on $primary]{col_name}[/] ({order})", title="Sort")

    def get_cidx_name_value(self) -> tuple[str, str, str] | None:
        row_idx = self.table.cursor_row
        if row_idx >= len(self.df[:, 0]):  # first column
            return None  # Skip the last `Total` row

        col_name = self.dftable.df.columns[self.cidx]
        col_dtype = self.dftable.df.dtypes[self.cidx]

        cell_value = self.table.get_cell_at(Coordinate(row_idx, 0))
        col_value = NULL if cell_value.plain == NULL_DISPLAY else DtypeConfig(col_dtype).convert(cell_value.plain)

        return self.cidx, col_name, col_value

    def save_frequency_table(self) -> None:
        """Save the frequency table to file."""
        column = self.dftable.df.columns[self.cidx]
        filename = f"{column}_freq.csv"

        self.app.push_screen(
            SaveFileScreen(filename, all_tabs=False),
            callback=partial(self.app.save_to_file, use_df=self.df),
        )


class MetaShape(TableScreen):
    """Modal screen to display metadata about the dataframe."""

    def on_mount(self) -> None:
        """Initialize the metadata screen.

        Populates the table with metadata information about the dataframe,
        including row and column counts.
        """
        self.build_table()

    def build_table(self) -> None:
        """Build the metadata table."""
        self.table.clear(columns=True)
        self.table.add_column("")
        self.table.add_column(Text("Count", justify="right"))

        # Get shape information
        num_rows, num_cols = self.dftable.df.shape
        num_cols -= 1  # Exclude RID column
        dc_int = DtypeConfig(pl.Int64)

        # Add rows to the table
        self.table.add_row("Row", dc_int.format(num_rows, thousand_separator=self.thousand_separator))
        self.table.add_row("Column", dc_int.format(num_cols, thousand_separator=self.thousand_separator))

        self.table.cursor_type = "none"


class MetaColumnScreen(TableScreen):
    """Modal screen to display metadata about the columns in the dataframe."""

    def on_mount(self) -> None:
        """Initialize the column metadata screen.

        Populates the table with information about each column in the dataframe,
        including ID (1-based index), Name, and Type.
        """
        self.build_table()

    def on_key(self, event) -> None:
        """Handle key press events on the column metadata screen.

        Supports keys:
          - 'F': Show frequency for the selected value.
          - 's': Show statistics for the selected value.

        Args:
            event: The key event object.
        """
        if event.key == "F":
            # Show frequency for the selected value
            self.show_frequency(self.get_cidx_name_value())
            event.stop()
        elif event.key == "s":
            # Show statistics for the selected value
            self.show_statistics(self.get_cidx_name_value())
            event.stop()

    def build_table(self) -> None:
        """Build the column metadata table."""
        self.table.clear(columns=True)
        self.table.add_column("Column")
        self.table.add_column("Name")
        self.table.add_column("Type")

        # Get schema information
        schema = self.dftable.df.schema
        dc_int = DtypeConfig(pl.Int64)
        dc_str = DtypeConfig(pl.String)

        # Add a row for each column
        for idx, (col_name, col_type) in enumerate(schema.items(), 1):
            if col_name == RID:
                continue  # Skip RID column

            dc = DtypeConfig(col_type)
            self.table.add_row(
                dc_int.format(idx, thousand_separator=self.thousand_separator),
                col_name,
                dc_str.format("Datetime" if str(col_type).startswith("Datetime") else col_type, style=dc.style),
            )

        self.table.cursor_type = "row"

    def get_cidx_name_value(self) -> int | None:
        """Get the current column info."""
        cidx = self.table.cursor_row
        if cidx >= len(self.dftable.df.columns):
            return None  # Invalid row

        col_name = self.dftable.df.columns[cidx]
        col_value = None

        return cidx, col_name, col_value
