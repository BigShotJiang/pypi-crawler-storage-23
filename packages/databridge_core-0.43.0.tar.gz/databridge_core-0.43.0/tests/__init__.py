"""Tests for databridge-core library."""
