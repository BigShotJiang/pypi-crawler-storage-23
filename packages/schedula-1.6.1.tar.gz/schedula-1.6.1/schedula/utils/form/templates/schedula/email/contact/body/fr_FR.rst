
Cher/Chère *{{ data.name | safe }}*,

Merci de nous avoir contactés. Le {{ created | safe }} vous avez envoyé le message suivant :

**{{ data.message | safe }}**

Un de nos consultants vous contactera dès que possible.

Cordialement,

*Équipe*
