
Geagte *{{ data.name | safe }}*,

Dankie dat u ons gekontak het. Op {{ created | safe }} het u die volgende boodskap gestuur:

**{{ data.message | safe }}**

U sal so gou moontlik deur een van ons konsultante gekontak word.

Vriendelike groete,

*Team*
