
Beste *{{ data.name | safe }}*,

Bedankt voor uw contact. Op {{ created | safe }} stuurde u het volgende bericht:

**{{ data.message | safe }}**

Een van onze consultants zal zo spoedig mogelijk contact met u opnemen.

Met vriendelijke groet,

*Team*
