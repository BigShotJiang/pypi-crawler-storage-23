
Kedves *{{ data.name | safe }}*,

Köszönjük, hogy felvette velünk a kapcsolatot. Ezen a napon: {{ created | safe }} az alábbi üzenetet küldte:

**{{ data.message | safe }}**

Egyik tanácsadónk mielőbb felveszi Önnel a kapcsolatot.

Üdvözlettel,

*Csapat*
