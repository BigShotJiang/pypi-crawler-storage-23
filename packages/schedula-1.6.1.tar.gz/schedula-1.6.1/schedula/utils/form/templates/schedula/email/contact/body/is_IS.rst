
Kæri/Kæra *{{ data.name | safe }}*,

Takk fyrir að hafa samband við okkur. Þann {{ created | safe }} sendir þú eftirfarandi skilaboð:

**{{ data.message | safe }}**

Ráðgjafi okkar mun hafa samband við þig eins fljótt og auðið er.

Bestu kveðjur,

*Liðið*
