
Estimado/a *{{ data.name | safe }}*,

Gracias por contactarnos. El {{ created | safe }} enviaste el siguiente mensaje:

**{{ data.message | safe }}**

Uno de nuestros consultores se pondrá en contacto contigo lo antes posible.

Atentamente,

*Equipo*
