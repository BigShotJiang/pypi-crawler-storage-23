
尊敬的 *{{ data.name | safe }}*，

感谢您联系我们。{{ created | safe }} 您发送了以下消息：

**{{ data.message | safe }}**

我们的顾问会尽快与您联系。

此致，

*团队*
