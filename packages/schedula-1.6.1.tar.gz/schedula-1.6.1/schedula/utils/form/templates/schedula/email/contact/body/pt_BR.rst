
Prezado/Prezada *{{ data.name | safe }}*,

Obrigado/a por nos contatar. Em {{ created | safe }} você enviou a seguinte mensagem:

**{{ data.message | safe }}**

Um de nossos consultores entrará em contato com você o mais breve possível.

Atenciosamente,

*Equipe*
