
Kære *{{ data.name | safe }}*,

Tak for din henvendelse. Den {{ created | safe }} sendte du følgende besked:

**{{ data.message | safe }}**

En af vores konsulenter vil kontakte dig hurtigst muligt.

Med venlig hilsen,

*Teamet*
