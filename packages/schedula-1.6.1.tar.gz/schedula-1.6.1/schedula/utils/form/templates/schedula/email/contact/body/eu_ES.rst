
Ene *{{ data.name | safe }}*,

Eskerrik asko gurekin harremanetan jartzeagatik. {{ created | safe }} honetan ondorengo mezua bidali zenuen:

**{{ data.message | safe }}**

Gure aholkulari bat zurekin ahalik eta lasterren jarriko da harremanetan.

Agur bero bat,

*Taldea*
