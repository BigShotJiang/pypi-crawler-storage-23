
Dear *{{ data.name | safe }}*,

Thanks for contacting us. On {{ created | safe }} you sent the following message:

**{{ data.message | safe }}**

You will be contacted as soon as possible by one of our consultants.

Best regards,

*Team*
