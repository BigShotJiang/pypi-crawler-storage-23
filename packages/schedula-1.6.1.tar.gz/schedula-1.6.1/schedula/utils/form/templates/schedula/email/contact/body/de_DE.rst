
Sehr geehrte/r *{{ data.name | safe }}*,

vielen Dank für Ihre Kontaktaufnahme. Am {{ created | safe }} haben Sie die folgende Nachricht gesendet:

**{{ data.message | safe }}**

Einer unserer Berater wird sich so schnell wie möglich mit Ihnen in Verbindung setzen.

Mit freundlichen Grüßen,

*Team*
