export default function postSubmit(
    {data, input, formData, _, form, ...formProps}
) {
    return data
}