export default function preSubmit(
    {input, formData, _, form, ...formProps}
) {
    return input
}