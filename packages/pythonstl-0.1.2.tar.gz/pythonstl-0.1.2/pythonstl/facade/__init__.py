"""Facade layer for pystl data structures."""

from .stack import stack
from .queue import queue
from .vector import vector
from .set import stl_set
from .map import stl_map
from .priority_queue import priority_queue

__all__ = ['stack', 'queue', 'vector', 'stl_set', 'stl_map', 'priority_queue']
