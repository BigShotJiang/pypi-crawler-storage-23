"""Heap-based data structure implementations."""

from ._priority_queue_impl import _PriorityQueueImpl

__all__ = ['_PriorityQueueImpl']
