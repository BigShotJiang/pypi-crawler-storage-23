"""Linear data structure implementations."""

from ._stack_impl import _StackImpl
from ._queue_impl import _QueueImpl
from ._vector_impl import _VectorImpl

__all__ = ['_StackImpl', '_QueueImpl', '_VectorImpl']
