2026-02-08 Version: 2.10.0
- Support API CreateMaterialDirectory.
- Support API DeleteMaterialDirectory.
- Support API DeleteMaterialTask.
- Support API ExportMaterialFile.
- Support API ModifyMaterialDirectory.
- Support API ModifyMaterialFile.
- Support API ModifyMaterialFileStatus.
- Support API MoveMaterialDirectory.
- Support API MoveMaterialFile.
- Support API QueryMaterialDirectoryTree.
- Support API QueryMaterialFileDetail.
- Support API QueryMaterialFileList.
- Support API QueryMaterialFileSummaryInfo.
- Support API QueryMaterialTaskDetail.
- Support API QueryMaterialTaskList.
- Support API SubmitMaterialTask.
- Support API UploadMaterialFile.


2026-02-04 Version: 2.9.0
- Support API IntrospectAppInstanceTicketForPreview.


2026-01-19 Version: 2.8.3
- Update API RefundAppInstanceForPartner: add request parameters ClientToken.


2026-01-17 Version: 2.8.2
- Update API CreateAppInstance: add request parameters ResourceGroupId.
- Update API CreateAppInstance: add request parameters Tags.


2026-01-15 Version: 2.8.1
- Generated python 2025-04-29 for WebsiteBuild.

2026-01-15 Version: 2.8.0
- Support API RefundAppInstanceForPartner.


2026-01-15 Version: 2.7.3
- Generated python 2025-04-29 for WebsiteBuild.

2026-01-14 Version: 2.7.2
- Update API CreateAppInstance: add response parameters Body.Module.SiteHost.


2025-12-24 Version: 2.7.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-12-19 Version: 2.7.0
- Support API CreateAppInstance.
- Support API CreateAppInstanceTicket.
- Support API GetAppInstance.
- Support API ListAppInstances.
- Support API ModifyAppInstanceSpec.
- Support API RefreshAppInstanceTicket.
- Support API RenewAppInstance.


2025-11-06 Version: 2.6.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-11-06 Version: 2.6.0
- Support API DispatchConsoleAPIForPartner.
- Support API GetUserAccessTokenForPartner.


2025-09-19 Version: 2.5.0
- Support API BindAppDomain.
- Support API DeleteAppDomainCertificate.
- Support API DeleteAppDomainRedirect.
- Support API DescribeAppDomainDnsRecord.
- Support API ListAppDomainRedirectRecords.
- Support API ListAppInstanceDomains.
- Support API SetAppDomainCertificate.
- Support API UnbindAppDomain.


2025-09-12 Version: 2.4.0
- Support API GetDomainInfoForPartner.


2025-09-09 Version: 2.3.0
- Support API GetIcpFilingInfoForPartner.
- Support API GetUserTmpIdentityForPartner.


2025-08-01 Version: 2.2.0
- Support API SearchImage.


2025-07-23 Version: 2.1.0
- Support API SyncAppInstanceForPartner.


2025-07-10 Version: 2.0.0
- Update API CreateLogoTask: add request parameters LogoVersion.
- Update API CreateLogoTask: delete request parameters Version.


2025-06-25 Version: 1.2.1
- Generated python 2025-04-29 for WebsiteBuild.

2025-06-24 Version: 1.2.0
- Support API CreateLogoTask.
- Support API GetCreateLogoTask.


2025-06-12 Version: 1.1.0
- Support API OperateAppInstanceForPartner.


2025-05-24 Version: 1.0.0
- Generated python 2025-04-29 for WebsiteBuild.

