"""sage.common.protocols – L1 runtime-context contracts.

Pure :class:`typing.Protocol` definitions for runtime contexts consumed by
``sage-common`` base classes.  Concrete implementations (``ServiceContext``,
``TaskContext``) live in ``sage-kernel`` (L3) and satisfy these protocols
structurally – no explicit ``register``/``inherit`` call required.
"""

from sage.common.protocols.context_protocols import (
    RuntimeContextProtocol,
    ServiceContextProtocol,
    TaskContextProtocol,
)

__all__ = [
    "RuntimeContextProtocol",
    "ServiceContextProtocol",
    "TaskContextProtocol",
]
