"""版本信息"""

__version__ = "0.1.0"
__author__ = "YAFO-AI Team"
__description__ = "FastAPI基础类库，提供响应封装、中间件、ORM、日志等基础功能"
