from __future__ import annotations

from tema.cli import main

main()
