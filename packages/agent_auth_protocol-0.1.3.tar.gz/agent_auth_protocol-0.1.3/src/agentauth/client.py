import time
import httpx
from pydantic import BaseModel, Field
from typing import Optional, Dict

from .errors import AuthenticationError, NetworkError

class TokenResponse(BaseModel):
    """Strict validation for the Go Server's response."""
    access_token: str
    expires_in: int = Field(default=300)

class AgentAuthClient:
    def __init__(self, auth_server_url: str, agent_id: str):
        self.auth_server_url = auth_server_url.rstrip('/')
        self.agent_id = agent_id
        
        # Internal cache state
        self._token: Optional[str] = None
        self._expires_at: float = 0.0

    def register(self, public_key_hex: str) -> None:
        """Registers the agent's public key with the Go Server."""
        try:
            response = httpx.post(
                f"{self.auth_server_url}/register",
                json={
                    "agent_id": self.agent_id,
                    "public_key_hex": public_key_hex
                },
                timeout=10.0
            )
            response.raise_for_status()
        except httpx.RequestError as e:
            raise NetworkError(f"Failed to reach Auth Server: {str(e)}")
        except httpx.HTTPStatusError as e:
            raise AuthenticationError(f"Registration failed: {e.response.text}")

    def get_token(self) -> str:
        """Retrieves a valid JWT, using the cache if possible."""
        if self._token and self._expires_at > time.time() + 60:
            return self._token
        return self._fetch_new_token()

    def _fetch_new_token(self) -> str:
        """Requests a new JWT using the X-Agent-ID header."""
        try:
            response = httpx.post(
                f"{self.auth_server_url}/token",
                headers={"X-Agent-ID": self.agent_id},
                timeout=10.0
            )
        except httpx.RequestError as e:
            raise NetworkError(f"Failed to reach Auth Server: {str(e)}")

        if response.status_code in (401, 403):
            raise AuthenticationError(f"Auth failed: {response.text}")
        
        response.raise_for_status()

        # Validate the response payload with Pydantic
        data = TokenResponse(**response.json())
        
        # Update the cache
        self._token = data.access_token
        self._expires_at = time.time() + data.expires_in
        
        return self._token

    def get_auth_header(self) -> Dict[str, str]:
        """Returns the authorization header for LangChain/Requests."""
        token = self.get_token()
        return {"Authorization": f"Bearer {token}"}