class AgentAuthError(Exception):
    """Base exception for all AgentAuth SDK errors."""
    pass

class AuthenticationError(AgentAuthError):
    """Raised when the Go Server rejects the client credentials."""
    pass

class NetworkError(AgentAuthError):
    """Raised when the SDK cannot reach the Go Server."""
    pass