# agentauth-py 🛡️

[![PyPI Version](https://img.shields.io/pypi/v/agent-auth-protocol?color=blue&style=flat-square)](https://pypi.org/project/agent-auth-protocol/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/agent-auth-protocol?color=success&style=flat-square)](https://pypi.org/project/agent-auth-protocol/)
[![License](https://img.shields.io/pypi/l/agent-auth-protocol?style=flat-square)](https://github.com/agent-auth-protocol/agentauth-py/blob/main/LICENSE)

**The official Python client for the AgentAuth M2M Protocol.**

Autonomous AI agents (built with LangChain, LlamaIndex, or custom scripts) need a secure, human-free way to authenticate with backend infrastructure. This lightweight SDK allows your Python agents to register their cryptographic identity and securely fetch short-lived JSON Web Tokens (JWTs) from your AgentAuth Core server.

## ⚡ Features

- **Zero-Human Intervention:** Designed strictly for Machine-to-Machine (M2M) Auth.
- **Smart Caching:** Prevents DDOSing your own Auth Server by securely caching valid JWTs in memory and only requesting a new token when the current one is exactly 60 seconds from expiring.
- **Frictionless Injection:** Built-in helper methods to instantly generate `Authorization` headers for `httpx` or `requests`.

## 📦 Installation

```bash
pip install agentauth-py
```

## 🏗️ Flow

```mermaid
sequenceDiagram
    participant Agent as AI Agent (Python SDK)
    participant Core as Auth Server (Go Core)
    participant API as API Gateway (TS SDK)

    Note over Agent, Core: Phase 1: Identity Minting
    Agent->>Core: POST /register (Sends Ed25519 Public Key)
    Core-->>Agent: 201 Created (Agent Registered)

    Agent->>Core: POST /token (Header: X-Agent-ID)
    Core-->>Agent: Returns Signed JWT (5-min expiry)

    Note over Agent: SDK Caches JWT locally<br/>to prevent spamming Auth Server

    Note over Agent, API: Phase 2: Infrastructure Access
    Agent->>API: GET /protected-data (Header: Bearer <JWT>)

    Note over API: TS SDK mathematically verifies<br/>EdDSA signature offline using<br/>Core's Public Key.

    alt Token Valid & Not Expired
        API-->>Agent: 200 OK (Access Granted, Returns Data)
    else Token Forged or Expired
        API-->>Agent: 401 Unauthorized (Access Denied)
    end
```

## 🚀 Quick Start

```python
from agentauth import AgentAuthClient
import httpx

# 1. Initialize the client
client = AgentAuthClient(
    auth_server_url="[https://your-auth-server.com](https://your-auth-server.com)",
    agent_id="alpha-agent-001"
)

# 2. Register the agent's Public Key (Ed25519)
client.register(public_key_hex="YOUR_64_CHAR_HEX_PUBLIC_KEY")

# 3. Retrieve the JWT (Returns cached token if still valid)
token = client.get_token()

# 4. Inject straight into your API requests
response = httpx.get(
    "[https://api.your-infrastructure.com/data](https://api.your-infrastructure.com/data)",
    headers=client.get_auth_header()
)
```

---

_Built for the Agentic Era. Part of the AgentAuth Protocol Suite._
