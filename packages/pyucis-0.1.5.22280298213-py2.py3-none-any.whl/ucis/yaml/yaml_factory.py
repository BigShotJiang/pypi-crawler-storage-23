'''
Created on Jun 11, 2022

@author: mballance
'''
from ucis.ucis import UCIS

class YamlFactory():
    
    @staticmethod
    def read(file_or_filename) -> UCIS:
        pass
