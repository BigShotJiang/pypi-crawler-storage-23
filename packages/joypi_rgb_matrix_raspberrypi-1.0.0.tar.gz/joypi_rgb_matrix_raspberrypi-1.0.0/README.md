# JoyPi_RGB_Matrix_RaspberryPi
This library enables usage of RGB matrix with RP2040 microcontroller chip on the Raspberry Pi.

>[!WARNING]
> This library was written for the usage of the LED matrix of the Joy-Pi Advanced 2 and Joy-Pi Note 2. Both Joy-Pis have the RP2040 microcontroller chip to control the LED matrix. This is to ensure compatibility with the Raspberry Pi 5 because the library which was used beforehand is not compatible up to this date.

## Installation
You can install this library from PyPI.
To install it for the current user on your Raspberry Pi, use the following command:
```
pip install JoyPi_RGB_Matrix_RaspberryPi
```

## Library Guide
- `LEDMatrix( count = 64, brightness = 10, right_border = [7,15,23,31,39,47,55,63], left_border = [0,8,16,24,32,40,48,56])`- initialize LED matrix with default values for Joy-Pi
- `clean()` - clears the LED matrix
- `setPixel(position, colour)` - sets specific pixel to a selected colour
- `RGB_on(colour)` - sets the complete matrix to one selected colour
- `RGB_off()` - turns the complete matrix off
- `rainbow(wait_ms=20, iterations=1)` - rainbow effect on the whole matrix with default values
- `colourWipe(colour, wait_ms=50)` - Move selected colour pixel by pixel onto the matrix with default speed
- `theaterChase( colour, wait_ms=50, iterations=10)` - chaser animation with a selected colour with deafult speed
- `show()` - displays set pixels
- `demo1()` - demo program version 1
- `demo2()` - demo program version 2 