class LEDTransferData:
    """
    Data container class used to prepare and store parameters for I2C
    communication with the LED controller.

    This class encapsulates all fields required to build a command packet,
    including function identifiers, pixel position, color values, brightness,
    and range parameters for bulk operations.
    """
    def __init__(self, func=0, pos=0, r=0, g=0, b=0, w=0, c=0, bright=5, first=0, count=0):
        """
        Initialize the data structure for an LED control command
        
        :param func: Function ID (see FunctionEnum)
        :param pos: Pixel position index
        :param r: Red color component (0–255)
        :param g: Green color component (0–255)
        :param b: Blue color component (0–255)
        :param w: White color component (for RGBW LEDs)
        :param c: Additional color or control parameter (device-dependent)
        :param bright: Global brightness level
        :param first: First pixel index for range operations
        :param count: Number of pixels affected in range operations
        """
        self.func   = func
        self.pos    = pos
        self.r      = r
        self.g      = g
        self.b      = b
        self.w      = w
        self.c      = c
        self.bright = bright
        self.first  = first
        self.count  = count
        self.data   = 0
        self.data1  = 0

    def setFunc(self, func=0):
        """
        set Function ID

        :param func: Function ID - default = 0 - SHOW
        """
        self.func = func
    
    def setPos(self, pos=0):
        """
        set Pixel position index
        
        :param pos: Pixel position index - default = 0
        """
        self.pos = pos
    
    def setR(self, r=0):
        """
        set Red color component

        :param r: Red color component - default = 0
        """
        self.r = r
    
    def setG(self, g=0):
        """
        set Green color component 

        :param g: Green color component - default = 0
        """
        self.g = g
    
    def setB(self, b=0):
        """
        set Blue color component
        
        :param b: Blue color component - default = 0
        """
        self.b = b
    
    def setW(self, w=0):
        """
        set White color component
        
        :param w: White color component - default = 0
        """
        self.w = w
    
    def setC(self, c=0):
        """
        set Additional color or control parameter
        
        :param c: Additional color or control parameter - default = 0
        """
        self.c = c
    
    def setFirst(self, first=0):
        """
        set First pixel index for range operations
        
        :param first: First pixel index for range operations - default = 0
        """
        self.first = first
    
    def setCount(self, count=0):
        """
        set Number of pixels affected in range operations
        
        :param count: Number of pixels affected in range operations - default = 0
        """
        self.count = count
    
    def setBright(self, bright=0):
        """
        set Global brightness level

        :param bright: Global brightness level - default = 0
        """
        self.bright = bright
    
    def setData(self, data=0):
        """
        Sets the primary data value for the I²C command packet.

        This value is typically used to store a processed or combined
        parameter (e.g., color value, gamma result, or control data)
        before transmission.
        
        :param data: Integer value to be assigned to the primary data field - default = 0
        """
        self.data = data
    
    def setData1(self, data=0):
        """
        Sets the secondary data value for the I²C command packet.

        This field is commonly used for additional parameters such as
        high/low bytes, extended data, or supplementary command values.
        
        :param data: Integer value to be assigned to the secondary data field - default = 0
        """
        self.data1 = data

    def clean(self):
        """
        Reset all internal fields to zero after transmission
        """
        self.func   = 0
        self.pos    = 0
        self.r      = 0
        self.g      = 0
        self.b      = 0
        self.w      = 0
        self.c      = 0
        self.bright = 0
        self.first  = 0
        self.count  = 0
        self.data   = 0
        self.data1  = 0