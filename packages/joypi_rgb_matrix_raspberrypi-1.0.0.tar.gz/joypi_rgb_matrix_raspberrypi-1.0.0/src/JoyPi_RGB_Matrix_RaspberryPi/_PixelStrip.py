from ._LEDTransferData import LEDTransferData
from enum import Enum
import smbus2
import time

class FunctionEnum(Enum):
    """
    Enumeration of command identifiers used for controlling the LED matrix
    via I2C communication.

    Each value represents a specific function that can be executed by the
    LED controller firmware, such as pixel manipulation, brightness control,
    gamma correction, color conversion, or data transmission.
    """
    SHOW                = 0
    SETPIXELCOLOR       = 1
    FILL                = 2
    SETBRIGHTNESS       = 3
    WHITEOVERRAINBOW    = 4
    GAMMA8              = 5
    GAMMA32             = 6
    NUMPIXEL            = 7
    COLORHSV            = 8
    CLEAR               = 9
    SENDDATA2SHOW       = 10
    SENDALLPIXRGB0      = 11
    SENDALLPIXRGB1      = 12
    SENDALLPIXRGB2      = 13
    SENDALLPIXRGB3      = 14
    SENDALLPIXRGB4      = 15
    SENDALLPIXRGB5      = 16

class PixelStrip:
    """
    Controls a strip of LEDs (WS281x / SK6812) via I2C.
    """

    def __init__(self, num, brightness=255, bus = None, bus_id = 1, i2c_adress = 0x66):
        """
        initilize LED controll class
        
        :param num: amount of pixel to controll
        :param brightness: brightness of all pixels
        """
        self.num = num
        self.bus = bus if bus is not None else smbus2.SMBus(bus_id)
        self.Address = i2c_adress
        self.transfer_data = LEDTransferData()
        self.transfer_data.setBright(brightness)

    def begin(self):
        """
        Set the initial brightness on the hardware side via I2C
        """
        self.transfer_data.setFunc(FunctionEnum.SETBRIGHTNESS.value)
        self.send(0x00)

    def send(self, cmd):
        """
        Send a block of data to the device using I2C

        :param cmd: block of data to send
        """
        self.bus.write_block_data(
            self.Address, cmd, [
                self.transfer_data.func,
                self.transfer_data.pos,
                self.transfer_data.r,
                self.transfer_data.g,
                self.transfer_data.b,
                self.transfer_data.w,
                self.transfer_data.c,
                self.transfer_data.bright,
                self.transfer_data.first,
                self.transfer_data.count,
                self.transfer_data.data,
                self.transfer_data.data1
            ]
        )
        time.sleep(0.003)  # Hardware timing delay
        self.transfer_data.clean()

    def __len__(self):
        """
        Return the total number of pixels
        """
        return self.num

    def clear(self):
        """
        Clear the entire LED strip (turn off all pixels)
        """
        self.transfer_data.setFunc(FunctionEnum.CLEAR.value)
        self.send(0x00)

    def show(self):
        """
        Show updated pixel data on the LED strip
        """
        self.transfer_data.setFunc(FunctionEnum.SHOW.value)
        self.send(0x00)

    def getWRGB(self, color):
        """
        Extract W, R, G, B values from a single color int

        :param color: single color int
        """
        return (
            (color >> 24) & 0xff, 
            (color >> 16) & 0xff, 
            (color >> 8)  & 0xff, 
            color & 0xff
        )

    def setPixelColor(self, n, color):
        """
        Set a single pixel (at index n) to the specified 32-bit color

        :param n: Pixel position index
        :param color: 32-bit color or tupel of (r,g,b) or (r,g,b,w)
        """
        self.transfer_data.setPos(n)
        if isinstance(color, tuple):
            if len(color) == 3:
                r, g, b = color
                w = 0
            elif len(color) == 4:
                r, g, b, w = color
        else:
            w, r, g, b = self.getWRGB(color)
        self.setPixelColorRGB(n, r, g, b, w)

    def setPixelColorRGB(self, n, red, green, blue, white=0):
        """
        set Pixel colour at specific index

        :param n: Pixel position index
        :param red: colour value of red
        :param green: colour value of green
        :param blue: colour value of blue
        :param white: colour value of white - default 0
        """
        self.transfer_data.setPos(n)
        self.transfer_data.setR(red)
        self.transfer_data.setG(green)
        self.transfer_data.setB(blue)
        self.transfer_data.setW(white)
        self.transfer_data.setC(0)
        self.transfer_data.setFunc(FunctionEnum.SETPIXELCOLOR.value)
        self.send(0x00)

    def sendPos2Show(self, pos, r=0, g=0, b=0):
        """
        Sends color data to selected pixel positions and immediatly dislpays update
        
        :param pos: Pixel position index
        :param r: colour value of red
        :param g: colour value of green
        :param b: colour value of blue
        """
        self.transfer_data.setR(r)
        self.transfer_data.setG(g)
        self.transfer_data.setB(b)
        for i in pos:
            if 0 <= i <= 7:
                self.transfer_data.pos |= 1 << i
            elif 8 <= i <= 15:
                self.transfer_data.w |= 1 << (i - 8)
            elif 16 <= i <= 23:
                self.transfer_data.c |= 1 << (i - 16)
            elif 24 <= i <= 31:
                self.transfer_data.bright |= 1 << (i - 24)
            elif 32 <= i <= 39:
                self.transfer_data.first |= 1 << (i - 32)
            elif 40 <= i <= 47:
                self.transfer_data.count |= 1 << (i - 40)
            elif 48 <= i <= 55:
                self.transfer_data.data |= 1 << (i - 48)
            elif 56 <= i <= 63:
                self.transfer_data.data1 |= 1 << (i - 56)
        self.transfer_data.setFunc(FunctionEnum.SENDDATA2SHOW.value)
        self.send(0x00)

    def sendColor2Show(self, pos, color=0):
        """
        write RGB value onto pixel at specific index
        
        :param pos: Pixel position index
        :param color: RGB value to write onto pixel
        """
        w, r, g, b = self.getWRGB(color)
        self.transfer_data.setR(r)
        self.transfer_data.setG(g)
        self.transfer_data.setB(b)
        self.sendPos2Show(pos, r, g, b)

    def sendAllPixRGB(self, rgb):
        """
        Send large RGB data (6 chunks of 32 bytes each) to fill multiple pixels

        :param self: Description
        :param rgb: RGB value to write onto pixels
        """
        for i in range(6):
            start = 32 * i
            end = start + 32
            self.bus.write_block_data(
                self.Address,
                FunctionEnum.SENDALLPIXRGB0.value + i,
                rgb[start:end]
            )

    def fill(self, r=0, g=0, b=0, w=0, first=0, end=64):
        """
        write same RGB value from pixel with one index to another 

        :param r: colour value of red
        :param g: colour value of green
        :param b: colour value of blue
        :param w: colour value of white
        :param first: index of pixel to begin writing color on
        :param end: index of pixel to end writing colour on
        """
        self.transfer_data.setR(r)
        self.transfer_data.setG(g)
        self.transfer_data.setB(b)
        self.transfer_data.setW(w)
        self.transfer_data.setFirst(first)
        self.transfer_data.setCount(end - first)
        self.transfer_data.setFunc(FunctionEnum.FILL.value)
        self.send(0x00)

    def fillColor(self, color, first=0, end=63):
        """
        write same RGB value from pixel with one index to another 

        :param color: RGBW value to write onto pixels
        :param first: index of pixel to begin writing color on
        :param end: index of pixel to end writing colour on
        """
        w, r, g, b = self.getWRGB(color)
        self.fill(r, g, b, w, first, end)

    def setBrightness(self, brightness):
        """
        Set global brightness for all pixels
        
        :param brightness: set brightness to all pixels
        """
        self.transfer_data.setBright(brightness)
        self.transfer_data.setFunc(FunctionEnum.SETBRIGHTNESS.value)
        self.send(0x00)

    def numPixels(self):
        """
        Return the number of pixels in this strip
        """
        return self.num

    def getGamma8(self, x):
        """
        Applies 8-bit gamma correction to the given input value.

        :param x: 8-bit input value (0-255)
        """
        self.transfer_data.setFunc(FunctionEnum.GAMMA8.value)
        self.transfer_data.setData(x)
        self.send(0x01)
        return self.bus.read_byte(self.Address)

    def getGamma32(self, x):
        """
        Applies 32-bit gamma correction to the given input value.

        :param x: 32-bit input value
        """
        self.transfer_data.setFunc(FunctionEnum.GAMMA32.value)
        self.transfer_data.setData(x)
        self.send(0x01)
        return self.bus.read_byte(self.Address)

    def ColorHSV(self, x):
        """
        Converts an HSV color value into the device-specific RGB format.

        :param x: HSV input value (device-dependent encoding)
        """
        self.transfer_data.setFunc(FunctionEnum.COLORHSV.value)
        self.transfer_data.setData(x)
        self.send(0x01)
        return self.bus.read_byte(self.Address)