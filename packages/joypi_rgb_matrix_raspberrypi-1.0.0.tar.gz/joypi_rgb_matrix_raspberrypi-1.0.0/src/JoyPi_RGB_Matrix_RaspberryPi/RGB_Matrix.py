from ._RGBW import RGBW
from ._PixelStrip import PixelStrip
import time

class RGB_Matrix:
    """
    New version using the I2C-based PixelStrip instead of rpi_ws281x.
    """

    def __init__(self, bus = None, bus_id = 1, i2c_adress = 0x66, count = 64, brightness = 10, 
                 right_border = [7,15,23,31,39,47,55,63], left_border = [0,8,16,24,32,40,48,56]):
        """
        initiliaze LED matrix
        
        :param count: amount of LEDs in matrix
        :param brightness: brightness level of all pixels
        :param right_border: reference values for all pixel on the right side
        :param left_border: reference values for all pixel on the left side
        """
        # LED configuration
        self.LED_COUNT = count
        self.LED_BRIGHTNESS = brightness

        # For reference if needed
        self.RIGHT_BORDER = right_border
        self.LEFT_BORDER  = left_border

        # Create the I2C-based PixelStrip instance
        self.strip = PixelStrip(num=self.LED_COUNT, brightness=self.LED_BRIGHTNESS,
                                bus = bus, bus_id = bus_id, i2c_adress=i2c_adress)
        self.strip.begin()

    def clean(self):
        """
        Turn off all pixels
        """
        self.RGB_off()

    def setPixel(self, position, colour):
        """
        set pixel at position to colour
        
        :param position: Pixel position index
        :param colour: RGBW value 32 bit integer
        """
        self.strip.setPixelColor(position, colour)

    def RGB_on(self, colour):
        """
        set all pixel of matrix to colour
        
        :param colour: RGBW value 32 bit integer
        """
        for i in range(self.strip.numPixels()):
            self.strip.setPixelColor(i, colour)
        self.strip.show()

    def RGB_off(self):
        """
        turn all LEDs in matrix off
        """
        for i in range(self.strip.numPixels()):
            self.strip.setPixelColor(i, RGBW(0, 0, 0, 0))
        self.strip.show()

    def wheel(self, pos):
        """
        generate rainbow colours over positions 0-255

        :param pos: selected pixel
        """
        if pos < 85:
            return RGBW(pos * 3, 255 - pos * 3, 0, 0)
        elif pos < 170:
            pos -= 85
            return RGBW(255 - pos * 3, 0, pos * 3, 0)
        else:
            pos -= 170
            return RGBW(0, pos * 3, 255 - pos * 3, 0)

    def rainbow(self, wait_ms=20, iterations=1):
        """
        Rainbow effect on all LEDs

        :param wait_ms: time in between colour change per pixel
        :param iterations: iterations of animation
        """
        for j in range(256 * iterations):
            for i in range(self.strip.numPixels()):
                self.strip.setPixelColor(i, self.wheel((i + j) & 255))
            self.strip.show()
            time.sleep(wait_ms / 1000.0)

    def colourWipe(self, color, wait_ms=50):
        """
        Move colours pixel by pixel over the LEDs with a given colour

        :param color: RGB value to set pixels to
        :param wait_ms: time between each pixel
        """
        for i in range(self.strip.numPixels()):
            self.strip.setPixelColor(i, color)
            self.strip.show()
            time.sleep(wait_ms / 1000.0)

    def theaterChase(self, color, wait_ms=50, iterations=10):
        """
        Chaser animation with a given colour

        :param color: RGB value to set pixels to
        :param wait_ms: time in between colour change per pixel
        :param iterations: iterations of animation
        """
        for j in range(iterations):
            for q in range(3):
                for i in range(0, self.strip.numPixels(), 3):
                    self.strip.setPixelColor(i + q, color)
                self.strip.show()
                time.sleep(wait_ms / 1000.0)
                for i in range(0, self.strip.numPixels(), 3):
                    self.strip.setPixelColor(i + q, 0)

    def demo1(self):
        """
        Simple demo programm
        """
        self.theaterChase(RGBW(127, 127, 127, 0))  # White chaser
        self.theaterChase(RGBW(127, 0, 0, 0))  # Red chaser
        self.theaterChase(RGBW(0, 0, 127, 0)) # Blue chaser
        self.rainbow()
        self.clean()

    def show(self):
        """
        show changes on LED matrix
        """
        self.strip.show()

    def demo2(self):
        """
        More complex demo programm in a continuous loop
        """
        heart = [1,6,8,9,10,13,14,15,16,17,18,19,20,21,22,23,
                         24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,
                         41,42,43,44,45,46,50,51,52,53,59,60]
        try:
            for i in range(3):
                self.demo1()
            while True:
                for i in heart:
                    self.strip.setPixelColor(i, RGBW(255, 0, 0, 0))
                self.strip.show()
        except KeyboardInterrupt:
            self.clean()