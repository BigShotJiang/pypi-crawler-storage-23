class RGBW(int):
    """
    Represents a 32-bit RGBW color value.

    This class allows combining separate red, green, blue, and optional white
    components into a single 32-bit integer while still providing convenient
    access to each color channel via properties.

    Format (32-bit):
        [ W (8 bit) | R (8 bit) | G (8 bit) | B (8 bit) ]
    """

    def __new__(self, r, g=None, b=None, w=None):
        """
        Create a new RGBW color value. The object can be initialized in two ways:
        1) With a single integer: RGBW(0xWWRRGGBB)
        2) With individual color components: RGBW(r, g, b, w=0)

        :param r: Red value (0–255) or packed 32-bit integer
        :param g: Green value (0–255)
        :param b: Blue value (0–255)
        :param w: White value (0–255), optional (default = 0)
        """
        if (g, b, w) == (None, None, None):
            return int.__new__(self, r)
        else:
            if w is None:
                w = 0
            return int.__new__(self, (w << 24) | (r << 16) | (g << 8) | b)

    @property
    def getR(self):
        """
        get red value
        """
        return (self >> 16) & 0xff

    @property
    def getG(self):
        """
        get green value
        """
        return (self >> 8) & 0xff

    @property
    def getB(self):
        """
        get blue value
        """
        return self & 0xff

    @property
    def getW(self):
        """
        get white value
        """
        return (self >> 24) & 0xff
