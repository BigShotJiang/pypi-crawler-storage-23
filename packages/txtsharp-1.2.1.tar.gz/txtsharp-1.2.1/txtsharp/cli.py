# cli.py
import sys
from .core import Tsharp

def main():
    t = Tsharp()

    if len(sys.argv) > 1:
        filename = sys.argv[1]
        if not filename.endswith(".tsh"):
            print("Error: T# files must have a .tsh extension")
            sys.exit(1)
        t.run_file(filename)
    else:
        # No file passed → start REPL
        t.start_repl()

if __name__ == "__main__":
    main()