# core.py
import time
import random
import math
import sys

class Tsharp:
    def __init__(self):
        self.vars = {}
        self.lists = {}

    # -------------------------
    # Variable handling
    # -------------------------
    def get_var(self, name):
        return self.vars.get(name, 0)

    def set_var(self, name, value):
        self.vars[name] = value

    def eval_value(self, value):
        value = value.strip()
        if value.replace(".", "", 1).isdigit():
            if "." in value:
                return float(value)
            return int(value)
        if value in self.vars:
            return self.vars[value]
        return value

    # -------------------------
    # Main interpreter
    # -------------------------
    def run_line(self, line):
        line = line.strip()
        if not line or line.startswith("#"):
            return

        words = line.lower().split()

        # -------------------------
        # Variable assignment
        # -------------------------
        if line.lower().startswith("set "):
            parts = line[4:].split(" to ", 1)
            if len(parts) == 2:
                var_name = parts[0].strip()
                value = self.eval_value(parts[1])
                self.set_var(var_name, value)
            else:
                print(f"Invalid set command: {line}")
            return

        # -------------------------
        # Show / print
        # -------------------------
        if line.lower().startswith("show "):
            value = self.eval_value(line[5:])
            print(value)
            return

        # -------------------------
        # Ask input
        # -------------------------
        if line.lower().startswith("ask "):
            var_name = line[4:].strip()
            self.set_var(var_name, input(f"{var_name}: "))
            return

        # -------------------------
        # Math commands
        # -------------------------
        math_keywords = ["add","subtract","multiply","divide","mod","power","increment","decrement"]
        if words[0] in math_keywords:
            self._handle_math(words)
            return

        # -------------------------
        # Comparison commands
        # -------------------------
        compare_keywords = ["greater","less","equal","notequal"]
        if words[0] in compare_keywords:
            self._handle_compare(words)
            return

        # -------------------------
        # String operations
        # -------------------------
        string_keywords = ["concat","length","uppercase","lowercase","replace","substring","contains","startswith","endswith"]
        if words[0] in string_keywords:
            self._handle_string(words, line)
            return

        # -------------------------
        # List operations
        # -------------------------
        list_keywords = ["create","append","remove","pop","insert","showitem","listlength","findindex","shuffle"]
        if words[0] in list_keywords:
            self._handle_list(words, line)
            return

        # -------------------------
        # Random number
        # -------------------------
        if line.lower().startswith("random from"):
            self._handle_random(line)
            return

        # -------------------------
        # Time / sleep
        # -------------------------
        if line.lower().startswith("wait "):
            self._handle_wait(line)
            return

        # -------------------------
        # Clear screen
        # -------------------------
        if line.lower() == "clear":
            print("\033c", end="")
            return

        # -------------------------
        # Exit program
        # -------------------------
        if line.lower() == "exit":
            sys.exit()

        # -------------------------
        # Conditional
        # -------------------------
        if line.lower().startswith("if "):
            self._handle_if(line)
            return

        # -------------------------
        # Loops
        # -------------------------
        if line.lower().startswith("repeat "):
            self._handle_repeat(line)
            return

        # -------------------------
        # File operations
        # -------------------------
        if line.lower().startswith("read file "):
            self._handle_readfile(line)
            return
        if line.lower().startswith("write file "):
            self._handle_writefile(line)
            return
        if line.lower().startswith("append file "):
            self._handle_appendfile(line)
            return

        # -------------------------
        # Misc
        # -------------------------
        if line.lower().startswith("swap "):
            self._handle_swap(line)
            return
        if line.lower().startswith("copy "):
            self._handle_copy(line)
            return
        if line.lower().startswith("sqrt "):
            self._handle_sqrt(line)
            return
        if line.lower().startswith("round "):
            self._handle_round(line)
            return
        if line.lower().startswith("abs "):
            self._handle_abs(line)
            return
        if line.lower().startswith("floor "):
            self._handle_floor(line)
            return
        if line.lower().startswith("ceil "):
            self._handle_ceil(line)
            return

        print(f"Unknown command: {line}")

    # -------------------------
    # Run file
    # -------------------------
    def run_file(self, filename):
        try:
            with open(filename,"r") as f:
                for line in f:
                    self.run_line(line)
        except FileNotFoundError:
            print(f"File {filename} not found.")

    # -------------------------
    # REPL / Interactive mode
    # -------------------------
    def start_repl(self):
        print(r"""
___________         __     _  _   
\__    ___/__  ____/  |___| || |__
  |    |  \  \/  /\   __\   __   /
  |    |   >    <  |  |  |  ||  | 
  |____|  /__/\_ \ |__| /_  ~~  _\
                \/        |_||_|  
T# Interactive (type 'exit' to quit)
""")
        while True:
            try:
                line = input(">>> ")
                self.run_line(line)
            except KeyboardInterrupt:
                print("\nExiting T#")
                break
            except EOFError:
                print("\nExiting T#")
                break

    # -------------------------
    # Helper methods (math)
    # -------------------------
    def _handle_math(self, words):
        if "to" in words:
            idx = words.index("to")
            num = self.eval_value(" ".join(words[1:idx]))
            var = " ".join(words[idx+1:])
            if words[0] == "add":
                self.vars[var] = self.get_var(var) + num
            elif words[0] == "subtract":
                self.vars[var] = self.get_var(var) - num
            elif words[0] == "multiply":
                self.vars[var] = self.get_var(var) * num
            elif words[0] == "divide":
                self.vars[var] = self.get_var(var) / num
            elif words[0] == "mod":
                self.vars[var] = self.get_var(var) % num
            elif words[0] == "power":
                self.vars[var] = self.get_var(var) ** num
            return
        if words[0] == "increment":
            var = " ".join(words[1:])
            self.vars[var] = self.get_var(var) + 1
            return
        if words[0] == "decrement":
            var = " ".join(words[1:])
            self.vars[var] = self.get_var(var) - 1
            return

    # -------------------------
    # Helper methods (compare)
    # -------------------------
    def _handle_compare(self, words):
        if len(words) < 4:
            print("Invalid compare command")
            return
        left = self.eval_value(words[1])
        right = self.eval_value(words[3])
        var = words[-1]
        if words[0] == "greater":
            self.vars[var] = left > right
        elif words[0] == "less":
            self.vars[var] = left < right
        elif words[0] == "equal":
            self.vars[var] = left == right
        elif words[0] == "notequal":
            self.vars[var] = left != right

    # -------------------------
    # Helper methods (strings)
    # -------------------------
    def _handle_string(self, words, line):
        cmd = words[0]
        if cmd == "concat":
            parts = line[7:].split(" and ")
            if len(parts) >= 2:
                result = ""
                for part in parts[:-1]:
                    result += str(self.eval_value(part))
                var = parts[-1].strip()
                self.vars[var] = result
        elif cmd == "length":
            var = " ".join(words[1:-2])
            self.vars[words[-1]] = len(str(self.eval_value(var)))
        elif cmd == "uppercase":
            var = " ".join(words[1:-2])
            self.vars[words[-1]] = str(self.eval_value(var)).upper()
        elif cmd == "lowercase":
            var = " ".join(words[1:-2])
            self.vars[words[-1]] = str(self.eval_value(var)).lower()
        elif cmd == "replace":
            try:
                idx1 = words.index("with")
                idx2 = words.index("in")
                old = self.eval_value(" ".join(words[1:idx1]))
                new = self.eval_value(" ".join(words[idx1+1:idx2]))
                var = " ".join(words[idx2+1:])
                self.vars[var] = str(self.eval_value(var)).replace(old,new)
            except:
                print("Invalid replace command")
        elif cmd == "substring":
            try:
                idx1 = words.index("from")
                idx2 = words.index("to")
                var = " ".join(words[1:idx1])
                start = int(self.eval_value(words[idx1+1]))
                end = int(self.eval_value(words[idx2+1]))
                self.vars[words[-1]] = str(self.eval_value(var))[start:end]
            except:
                print("Invalid substring command")
        elif cmd == "contains":
            var = " ".join(words[1:-2])
            check = str(self.eval_value(words[-2]))
            self.vars[words[-1]] = check in str(self.eval_value(var))
        elif cmd == "startswith":
            var = " ".join(words[1:-2])
            check = str(self.eval_value(words[-2]))
            self.vars[words[-1]] = str(self.eval_value(var)).startswith(check)
        elif cmd == "endswith":
            var = " ".join(words[1:-2])
            check = str(self.eval_value(words[-2]))
            self.vars[words[-1]] = str(self.eval_value(var)).endswith(check)

    # -------------------------
    # Helper methods (lists)
    # -------------------------
    def _handle_list(self, words, line):
        cmd = words[0]
        if cmd == "create":
            self.lists[words[2]] = []
        elif cmd == "append":
            var = words[1]
            val = self.eval_value(" ".join(words[3:]))
            self.lists[var].append(val)
        elif cmd == "remove":
            var = words[1]
            val = self.eval_value(" ".join(words[3:]))
            if val in self.lists[var]:
                self.lists[var].remove(val)
        elif cmd == "pop":
            var = words[1]
            if self.lists[var]:
                self.lists[var].pop()
        elif cmd == "insert":
            var = words[1]
            idx = int(self.eval_value(words[3]))
            val = self.eval_value(" ".join(words[5:]))
            self.lists[var].insert(idx,val)
        elif cmd == "showitem":
            var = words[1]
            idx = int(self.eval_value(words[3]))
            print(self.lists[var][idx])
        elif cmd == "listlength":
            var = words[1]
            self.vars[words[-1]] = len(self.lists[var])
        elif cmd == "findindex":
            var = words[1]
            val = self.eval_value(" ".join(words[3:-2]))
            self.vars[words[-1]] = self.lists[var].index(val) if val in self.lists[var] else -1
        elif cmd == "shuffle":
            var = words[1]
            random.shuffle(self.lists[var])

    # -------------------------
    # Random, sleep, misc helpers
    # -------------------------
    def _handle_random(self,line):
        try:
            parts = line.split()
            start = int(self.eval_value(parts[2]))
            end = int(self.eval_value(parts[4]))
            var = parts[-1]
            self.vars[var] = random.randint(start,end)
        except:
            print("Invalid random command")

    def _handle_wait(self,line):
        try:
            secs = float(line[5:].split()[0])
            time.sleep(secs)
        except:
            print("Invalid wait command")

    def _handle_swap(self,line):
        try:
            var1 = line.split()[1]
            var2 = line.split()[3]
            self.vars[var1], self.vars[var2] = self.vars[var2], self.vars[var1]
        except:
            print("Invalid swap command")

    def _handle_copy(self,line):
        try:
            parts = line.split()
            self.vars[parts[1]] = self.get_var(parts[3])
        except:
            print("Invalid copy command")

    def _handle_sqrt(self,line):
        var = line.split()[1]
        self.vars[var] = math.sqrt(self.get_var(var))

    def _handle_round(self,line):
        var = line.split()[1]
        self.vars[var] = round(self.get_var(var))

    def _handle_abs(self,line):
        var = line.split()[1]
        self.vars[var] = abs(self.get_var(var))

    def _handle_floor(self,line):
        var = line.split()[1]
        self.vars[var] = math.floor(self.get_var(var))

    def _handle_ceil(self,line):
        var = line.split()[1]
        self.vars[var] = math.ceil(self.get_var(var))

    # -------------------------
    # File operations
    # -------------------------
    def _handle_readfile(self,line):
        try:
            parts = line.split()
            filename = parts[2]
            var = parts[-1]
            with open(filename,"r") as f:
                self.vars[var] = f.read()
        except:
            print("Invalid read file command")

    def _handle_writefile(self,line):
        try:
            parts = line.split()
            filename = parts[2]
            text = " ".join(parts[4:-2])
            with open(filename,"w") as f:
                f.write(text)
        except:
            print("Invalid write file command")

    def _handle_appendfile(self,line):
        try:
            parts = line.split()
            filename = parts[2]
            text = " ".join(parts[4:-2])
            with open(filename,"a") as f:
                f.write(text)
        except:
            print("Invalid append file command")

    # -------------------------
    # Placeholder for conditions / loops
    # -------------------------
    def _handle_if(self,line):
        # Placeholder for future if/else
        pass

    def _handle_repeat(self,line):
        # Placeholder for future repeat loops
        pass