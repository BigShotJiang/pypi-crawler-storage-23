from ursina import *
import ursina
from pathlib import Path
import os 

user_development_mode = None

if os.path.exists("C:\\workspace"):
    user_development_mode = True

def set_dev_mode(uservalue=None):
    global user_development_mode
    if uservalue == "true" or "True":
        user_development_mode = True
    elif uservalue == "false" or  "False":
        user_development_mode = False
    else:
        print("IF YOU ARE NOT SETTING A MODE THEN WHY DID YOU CALL THIS METHOD: pyropixel -2026")

# -----------------------------
# APP START (FIRST)
# -----------------------------
if user_development_mode == True:
    app = Ursina(development_mode=True, fullscreen=False)  # dev mode ON
elif user_development_mode == False:
    app = Ursina(development_mode=False, fullscreen=True)  # dev mode OFF
else:
    print("⚠ ERROR: user_development_mode is not set to True or False")
    exit(1)
window.title = "voxel"


# -----------------------------
# VOXEL MAKER
# -----------------------------

class MakeVoxel:
    @staticmethod
    def blockFaces(
        color=None,
        width=1,
        height=1,
        sxpos=0,
        sypos=0,
        szpos=0,
        texturefront=None,
        textureback=None,
        textureleft=None,
        textureright=None,
        textureup=None,
        texturedown=None,
        double_sided=True,
    ):
        use_textures = all(
            t is not None
            for t in [
                texturefront,
                textureback,
                textureleft,
                textureright,
                textureup,
                texturedown,
            ]
        )

        if color is None and not use_textures:
            raise ValueError("Provide either color OR all 6 textures.")

        # Check texture paths
        if use_textures:
            for t in [
                texturefront,
                textureback,
                textureleft,
                textureright,
                textureup,
                texturedown,
            ]:
                if not Path(t).exists():
                    print(f"⚠ Texture not found: {t}")

        common = {
            "model": "quad",
            "scale": (width, height),
            "double_sided": double_sided,
        }

        face_data = [
            ("right", (0, 90, 0), (sxpos + 0.5, sypos, szpos), textureright),
            ("left", (0, -90, 0), (sxpos - 0.5, sypos, szpos), textureleft),
            ("up", (-90, 180, 0), (sxpos, sypos + 0.5, szpos), textureup),
            ("down", (90, 0, 0), (sxpos, sypos - 0.5, szpos), texturedown),
            ("front", (0, 0, 0), (sxpos, sypos, szpos + 0.5), texturefront),
            ("back", (0, 180, 0), (sxpos, sypos, szpos - 0.5), textureback),
        ]

        faces = []

        for facetype, rot, pos, tex in face_data:
            kwargs = dict(common)
            kwargs["rotation"] = rot
            kwargs["position"] = pos

            if use_textures:
                kwargs["texture"] = ursina.load_texture(str(tex))
            else:
                kwargs["color"] = color

            faces.append(Entity(**kwargs))

        return tuple(faces)
# -----------------------------
# DATA STORAGE
# -----------------------------

building_blocks = []
ingredients = []
nature = []
technical_blocks = []
utility_blocks = []
voxels = []


def voxelData(blockname=None, blocktype=None):
    if blockname is None:
        return

    voxels.append(blockname)

    if blocktype == "building blocks":
        building_blocks.append(blockname)
    elif blocktype == "ingredients":
        ingredients.append(blockname)
    elif blocktype == "nature":
        nature.append(blockname)
    elif blocktype == "technical blocks":
        technical_blocks.append(blockname)
    elif blocktype == "utility blocks":
        utility_blocks.append(blockname)


# -----------------------------
# VOXEL CREATOR
# -----------------------------

def makeVoxel2(
    blockname=None,
    blocktype=None,
    texture1=None,
    texture2=None,
    texture3=None,
    texture4=None,
    texture5=None,
    texture6=None,
    sxpos=0,
    sypos=0,
    szpos=0,
):
    if blockname and blocktype:
        voxelData(blockname=blockname, blocktype=blocktype)

    if all(t is not None for t in [texture1, texture2, texture3, texture4, texture5, texture6]):
        return MakeVoxel.blockFaces(
            texturefront=texture1,
            textureback=texture2,
            textureup=texture3,
            texturedown=texture4,
            textureright=texture5,
            textureleft=texture6,
            double_sided=True,
            sxpos=sxpos,
            sypos=sypos,
            szpos=szpos,
        )

    return MakeVoxel.blockFaces(color=color.white, double_sided=True)


# -----------------------------
# GRID GENERATOR
# -----------------------------

def generateBlockGrid(
    size,
    origin,
    block,
    block_name2=None,
    block_type2=None,
    texture1=None,
    texture2=None,
    texture3=None,
    texture4=None,
    texture5=None,
    texture6=None,
):
    ox, oy, oz = origin

    for x in range(size):
        for z in range(size):
            makeVoxel2(
                blockname=block_name2,
                blocktype=block_type2,
                texture1=texture1,
                texture2=texture2,
                texture3=texture3,
                texture4=texture4,
                texture5=texture5,
                texture6=texture6,
                sxpos=ox + x,
                sypos=oy,
                szpos=oz + z,
            )

    print(f"Generated a grid of {size}x{size}, of {block} blocks, starting at {origin}.")

# -----------------------------
# RUN APP
# -----------------------------

app.run()