# gilas

Simple persistent Python data structures.

## Usage

```python
from gilas import plist, pdict

arr = plist()
arr.append(10)
arr.append(20)
print(arr[0])

items = pdict()
items["key"] = "value"
print(items["key"])
```

Each object stores its data in a local SQLite file named .gilas.db.
Objects keep a stable id you can use to reload them later in a new process.
