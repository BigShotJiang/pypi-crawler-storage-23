import re

def clean_string_columns(df, numerical_columns):
    """
    Function to clean columns of acquisition dataframe

    Parameters:
        df (Pandas Dataframe) - dataframe to clean
        numerical_columns (list) - list of numerical columns

    Outputs:
        dataframe where string values are in upper case and 
    """
    
    for col in df.select_dtypes(include='object').columns:
        

        # Remove all whitespace and convert to uppercase
        df[col] = df[col].apply(lambda x: re.sub(r'\s+', '', x).lower() if isinstance(x, str) else x)
    return df


def format_contrast_label(label):
  """
    Function to format contrast label to have spaces between number, ml, and type

    Parameters:
        label (str): label for contrast agent

    Outputs:
        str - formatted label 
    """
  if isinstance(label, str):
    label = label.strip().lower()
    match = re.match(r'(\d+)\s*ml\s*(.*)', label)
    if match:
      volume, agent = match.groups()
      return f"{volume} mL {agent.strip()}"
    return label
  return label

def remove_camel_case(label):
    """
    Removes camel case in label name, eg ContrastBolusVolume -> contrast bolus volume

    Parameters:
        label (str): label to remove camel case

    Returns:
        str: label without camel case
    """ 
    return re.sub(r'(?<!^)(?=[A-Z])', ' ', label).lower()

def clean_filename(filename):
  """
    Substitutes invalid characters in filename for _

    Parameters:
        filename (str): name of file

    Returns:
        filename with invalid characters substituted for _
    """ 
  return re.sub(r'[<>:"/\\|?*]', '_', filename)