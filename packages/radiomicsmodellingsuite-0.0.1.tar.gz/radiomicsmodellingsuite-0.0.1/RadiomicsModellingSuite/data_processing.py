from email.mime import image
import numpy as np
import os
import pandas as pd
import nibabel as nib
import dicom2nifti
import SimpleITK as sitk
from . import image_processing as ip
from datetime import datetime
import pydicom as dicom
from . import acquisition_parameters as ap
dicom2nifti.settings.disable_validate_slice_increment()

def manual_dicom_to_nifti(dicom_files):
  # Load DICOM files
  dicoms = [dicom.dcmread(f) for f in dicom_files]
  ds = dicoms[0]
  # Get pixel data and affine
  data = np.stack([d.pixel_array for d in dicoms], axis=-1)
  if ds.SliceThickness is None:
      ds.SliceThickness = abs(dicoms[1].ImagePositionPatient[2] - dicoms[0].ImagePositionPatient[2])
  affine = np.array([
        [ds.PixelSpacing[0], 0, 0, ds.ImagePositionPatient[0]],
        [0, ds.PixelSpacing[1], 0, ds.ImagePositionPatient[1]],
        [0, 0, ds.SliceThickness, ds.ImagePositionPatient[2]],
        [0, 0, 0, 1]
    ])

  # Create NIFTI
  nifti = nib.Nifti1Image(data, affine)
  nib.save(nifti, 'output.nii')

def dicom_to_nifti(subdir, patient, scan_type):
    """
    Converts DICOM files in folder_path to a NIfTI image.

    Parameters:

        * subdir (str): Path to the folder containing DICOM slices.

        * patient (int): Patient ID

        * scan_type (str): Scan modality


    Returns:
        * str: Output file name.
    """
    

    before = set(os.listdir("."))
    ds = dicom.dcmread(os.path.join(subdir, os.listdir(subdir)[0]))
    if ds['Modality'].value == 'PT': #convert PET gray levels to SUV
      
      output_path = os.path.join(subdir, "SUV_scaled")
      
      # Create the output directory if it doesn't exist
      os.makedirs(output_path, exist_ok=True)

      suv_scale = get_suv_bw_scale_factor(ds)
      # Convert pixel data to float and apply the scale
      for dir in os.listdir(subdir):
        if dir.endswith('.dcm'):
          ds = dicom.dcmread(os.path.join(subdir, dir))
          adjusted_pixels = ds.pixel_array.astype(np.float32) * suv_scale
          ds.PixelData = adjusted_pixels.astype(ds.pixel_array.dtype).tobytes()
          ds.save_as(os.path.join(output_path, f"suv_{dir}")) #save the adjusted DICOM file with a new name
    else:
      output_path = subdir
      if ds['Modality'].value == 'MR':
        if ds.EchoTime is None or ds.RepetitionTime is None:
          manual_dicom_to_nifti([os.path.join(subdir, name) for name in os.listdir(output_path)])
        else:
          dicom2nifti.convert_directory(output_path, ".")
    if ds['Modality'].value != 'MR':
      dicom2nifti.convert_directory(output_path, ".") #compile *.dcm into a nifti file
    after = set(os.listdir("."))
    file = list(after - before) #obtain the filename of the nifti   
    os.replace(file[0], f"{patient}_{scan_type}_{file[0]}") #rename file according to patient ID and scan type
    return f"{patient}_{scan_type}_{file[0]}"

def subdirs_intersection(subdirs, subdirs_list):
        """
    Extracts list of subdirectories for patient images and segmentations

    Parameters:

        * subdirs (list): list of subdirectories from current iteration

        * subdirs_list (list): cumulative list of subdirectories

    Returns:

        * matched_subdirs (list): list of subdirectories containing relevant scans

        * subdirs_list (list): updated cumulative list of subdirectories
    """
# Step 1: Trim the lowest-level directory
        trimmed_subdirs = [os.path.dirname(path) for path in subdirs]
        trimmed_subdirs_list = [os.path.dirname(path) for path in subdirs_list]

        # Step 2: Find the intersection
        intersection = [subdir for subdir in trimmed_subdirs if subdir in trimmed_subdirs_list]
        # Step 3: Extract original paths that contain any of the intersected paths
        matched_subdirs = [[path for path in subdirs_list if os.path.dirname(path) in intersection]] 
        matched_subdirs.append([path for path in subdirs if os.path.dirname(path) in intersection]) 
        matched_subdirs = list(np.transpose(np.array(matched_subdirs))) 
        matched_subdirs = [list(item) for item in matched_subdirs]  
        subdirs_list = [subdir for subdir in trimmed_subdirs_list if subdir in trimmed_subdirs]
        return matched_subdirs, subdirs_list 

def get_patients(parent_file_path, scan_types_dict, scan_types, segmentation_file_path, file_header, file_ender, author, manual_segmentation_file_path=None, clinical_path=None, clinical_features=None, objective=None, ignore_follow_up=True, latex_sections=['Information', 'Paragraphs', 'all_tables', 'Tables']):
    """
    Extracts list of subdirectories for patient images and segmentations

    Parameters:
    
        * parent_file_path (str): path to the parent directory for data
        
        * scan_types_dict (dict): dictionary of terms used to describe the same file type
        
        * scan_types (list[str]): list of scan types to be extracted
        
        * segmentation_file_path (str): file path for directory containing segmentations
        
        * file_header (str): part of file name before patient ID
        
        * file_ender (str): part of file name after patient ID

        * author (str): name of author for acquisition parameter report.
        
        * manual_segmentation_file_path (str): file path for directory containing manual segmentations; if patient segmentation is present then use that segmentation instead
        
        * clinical_path (str): file path for clinical data
        
        * clinical_features (list): list of clinical features to extract
        
        * objective (str): objective to predict

        * ignore_follow_up (bool): If True, ignores follow up scans (IDs containing '_21'). Default is True.

        * latex_sections (list[str]): list of sections to include in the latex output. Default is ['Information', 'Paragraphs', 'all_tables', 'Tables']

    Returns:
        
        * patients_list (list[str]): list of patient IDs
        
        * matched_subdirs (list[str]): list of subdirectories containing relevant scans
        
        * trimmed_segmentations_list (list[str]): list of segmentation directories
        
        * segmentations (list[NIfTI]): list of segmentation nifti files
        
        * auto_segmentations (list[str]): list of automatic segmentation directories
        
        * manual_segmentations (list[str]): list of manual segmentation directories
        
        * both_patients_list (list[str]): list of patient IDs with both automatic and manual segmentations
        
        * both_matched_subdirs (list[str]): list of subdirectories containing relevant scans with both automatic and manual segmentations
        
        * target (pandas DataFrame): DataFrame of target values. Returns an empty list if no target specified.
        
        * both_target (pandas DataFrame): DataFrame of target values for patients with both automatic and manual segmentations. Returns an empty list if no target specified.
        
        * clinical (pandas DataFrame): dataframe containing clinical features. Returns an empty list if no clinical features specified.

        * both_clinical (pandas DataFrame): dataframe containing clinical features for patients with both automatic and manual segmentations. Returns an empty list if no clinical features specified.
    """
    patients_list = []
    subdirs_list = []
    segmentations = []
    both_patients_list = []
    both_subdirs_list = []
    manual_segmentations = []
    auto_segmentations = []
    unavailable = ["Not Applicable", "Not Available", "Indeterminate", "NA", "NOS/NEC", np.nan] #list of descriptors for missing data
    segmentations_list = os.listdir(segmentation_file_path)  # Get the list of segmentation files
    trimmed_segmentations_list = []
    if manual_segmentation_file_path is not None:
      manual_segmentations_list = os.listdir(manual_segmentation_file_path) #obtain list of manual segmentation file names if file path specified
    else:
      manual_segmentations_list = []
    if clinical_path is not None:
      df = pd.read_csv(clinical_path)
      
      df.set_index('ID', inplace=True)
      if objective is not None: #save target values if objective specified
        if isinstance(objective, str):
          objective_list = [objective]
        else:
          objective_list = objective
        target = df.loc[:, objective_list]
        both_target = df.loc[:, objective_list]
        if ignore_follow_up: #remove follow up scans if specified      
          target = target[~target.index.str.contains('_21')] #remove follow up scans
      else:
         target = []
         both_target = []
      if clinical_features is not None: #save clinical features if specified
        clinical = df.loc[:, clinical_features]
        both_clinical = df.loc[:, clinical_features]
        if ignore_follow_up: #remove follow up scans if specified      
          clinical = clinical[~clinical.index.str.contains('_21')] #remove follow up scans
          both_clinical = both_clinical[~both_clinical.index.str.contains('_21')] #remove follow up scans
      else:
        clinical = None
        both_clinical = None
    else:
      clinical = None
      target = []
      both_target = []
      both_clinical = None
    ids_to_skip = []
    for i, scan in enumerate(scan_types): #loop through each scan type specified
      #initialising lists of subdirectories, patients, segmentations, manual segmentations, and automatic segmentations for each scan type
      subdirs = []
      patients = []
      both_subdirs = []
      both_patients = []
      manual_segs = []
      auto_segs = []
      trimmed_segs = []  
      for directory in os.listdir(parent_file_path):
          #loop through each directory in parent file path (corresponds to each patient)
          if 'NIfTI' in directory or directory.endswith('.csv') or directory == "LICENSE":
              continue  # Skip non patient directories
          id = directory[len(file_header):]
          if id in ids_to_skip:
             continue  # Skip if this patient ID has been skipped due to missing data
          if not any(id in segmentation for segmentation in segmentations_list):
              ids_to_skip.append(id)
              if objective is not None:                 
                  try:
                    target = target.drop(f"{file_header}{id}{file_ender}") #drop items from target if patient segmentation unavailable
                    both_target = both_target.drop(f"{file_header}{id}{file_ender}")
                  except KeyError:
                      pass
              if clinical is not None:
                  try:
                    clinical = clinical.drop(f"{file_header}{id}{file_ender}") #drop items from clinical if patient segmentation unavailable
                  except KeyError:
                      pass
              continue  # Skip if the segmentation file for this patient does not exist
          if objective is not None:
              if f"{file_header}{id}{file_ender}" in target.index and target.loc[f"{file_header}{id}{file_ender}"].isin(unavailable).any() and not any("survival" in obj.lower() for obj in objective_list):
                  ids_to_skip.append(id)
                  target = target.drop(f"{file_header}{id}{file_ender}") #skip patients with missing target data
                  both_target = both_target.drop(f"{file_header}{id}{file_ender}")
                  if clinical is not None:
                      clinical = clinical.drop(f"{file_header}{id}{file_ender}")
                  continue
          if clinical_features is not None:
             if f"{file_header}{id}{file_ender}" in clinical.index and clinical.loc[f"{file_header}{id}{file_ender}"].isin(unavailable).any() and not any("survival" in obj.lower() for obj in objective_list):
                  ids_to_skip.append(id)
                  clinical = clinical.drop(f"{file_header}{id}{file_ender}") #skip patients with missing clinical data
                  if objective is not None:
                      target = target.drop(f"{file_header}{id}{file_ender}")
                      both_target = both_target.drop(f"{file_header}{id}{file_ender}")
                  continue
          patient_path = os.path.join(parent_file_path, directory)
          for subdir in os.listdir(patient_path):
              #loop through each subdirectory in the patient folder (corresponds to each scan type)
              subdir_path = os.path.join(patient_path, subdir)
              for scan_type in scan_types_dict[scan]:
                  # print(scan_type.lower())
                  # print(subdir.lower())
                  # print()
                  if scan_type.lower() in subdir.lower():
                  #loop through each scan type in the scan types dictionary under the key of the specified scan type
                        if len(os.listdir(subdir_path)) < 3: #skip if there are too few scans
                          ids_to_skip.append(id)
                          if objective is not None:
                            target = target.drop(f"{file_header}{id}{file_ender}") #remove patient from target if there are too few scans
                            both_target = both_target.drop(f"{file_header}{id}{file_ender}")                           
                          if clinical is not None:
                            clinical = clinical.drop(f"{file_header}{id}{file_ender}") #remove patient from clinical if there are too few scans  
                          continue
                        subdirs.append(subdir_path)
                        patients.append(id)
                        
                        for filename in manual_segmentations_list: #check manual segmentation path for segmentation with patient ID
                          if id in filename:
                            full_path = os.path.join(manual_segmentation_file_path, filename)
                            trimmed_segs.append(full_path)
                            
                            for file in os.listdir(segmentation_file_path):
                              if id in file:
                                  manual_segs.append(full_path)
                                  both_patients.append(id)
                                  both_subdirs.append(subdir_path)
                                  auto_path = os.path.join(segmentation_file_path, file)
                                  auto_segs.append(auto_path)
                                  break
                                  
                            break
                        for filename in os.listdir(segmentation_file_path): #check default segmentation path for segmentation with patient ID
                          if id in filename:
                            full_path = os.path.join(segmentation_file_path, filename)
                            trimmed_segs.append(full_path)
                            break
                        break  # Found a match, break out of scan_type loop
              else:
                  continue  # Continue if inner loop wasn't broken
              break  # Break out of subdir loop if a match was found
      if i == 0:
        #if this is the first scan type, resultant lists to return are set equal to the list generated for that scan type
        patients_list = patients
        subdirs_list = subdirs
        both_patients_list = both_patients
        both_subdirs_list = both_subdirs
        matched_subdirs = [[item] for item in subdirs_list]
        both_matched_subdirs = [[item] for item in both_subdirs_list]
        manual_segmentations = manual_segs
        auto_segmentations = auto_segs
        trimmed_segmentations_list = trimmed_segs
      else:
         #otherwise, save across elements from resultant list and current list to resultant lists to return
        patients_list = [patient for patient in patients_list if patient in patients]
        both_patients_list = [patient for patient in both_patients_list if patient in both_patients]
        manual_segmentations = [seg for seg in manual_segmentations if seg in manual_segs]
        auto_segmentations = [seg for seg in auto_segmentations if seg in auto_segs]
        trimmed_segmentations_list = [seg for seg in trimmed_segmentations_list if seg in trimmed_segs]        
        matched_subdirs, subdirs_list = subdirs_intersection(subdirs, subdirs_list)    
        both_matched_subdirs, both_subdirs_list = subdirs_intersection(both_subdirs, both_subdirs_list)  
        valid_ids = [f"{file_header}{id}{file_ender}" for id in patients_list]
        both_valid_ids = [f"{file_header}{id}{file_ender}" for id in both_patients_list]
        if objective is not None:
            target = target.loc[target.index.intersection(valid_ids)]
            both_target = both_target.loc[target.index.intersection(both_valid_ids)]
        if clinical is not None:
            clinical = clinical.loc[clinical.index.intersection(valid_ids)]
            both_clinical = both_clinical.loc[both_clinical.index.intersection(both_valid_ids)]
    segmentations = [nib.load(path) for path in trimmed_segmentations_list]  
    ap.obtain_acquisition_parameters(matched_subdirs, scan_types, author, latex_sections=latex_sections) # Obtain acquisition parameters from the dicom files in the directory_list
    if len(manual_segmentations) > 0 and len(auto_segmentations) > 0:
       compare_segmentations(auto_segmentations, manual_segmentations, ['dice', 'jaccard', 'overlap'], 'segmentation_comparison')
    return patients_list, matched_subdirs, trimmed_segmentations_list, segmentations, auto_segmentations, manual_segmentations, both_patients_list, both_matched_subdirs, target, both_target, clinical, both_clinical

def cleanup(directory="."):  
  """'
  Empties a directory of all files

  Parameter: 

  * directory (str): directory to be cleaned
  """
# Loop through all files in the directory
  for filename in os.listdir(directory):
    file_path = os.path.join(directory, filename)

# Check if it's a file (not a folder)
    if os.path.isfile(file_path):
      os.remove(file_path)

def get_suv_bw_scale_factor(ds):
    
    '''
    Calculates the SUV body weight scale factor for individual PET axial slice.
    
    Inputs:

        * ds (pydicom.dataset): PyDicom dataset
        
    Returns: 

        * suv_bw_scale_factor (float): SUV scale factor to be applied to the images.
    '''
    radiopharm_info = ds.RadiopharmaceuticalInformationSequence[0]
    half_life = float(radiopharm_info.RadionuclideHalfLife)
    
    series_date_time = ds.SeriesDate + "_" + ds.SeriesTime
        
    if "." in series_date_time:
        series_date_time = series_date_time[:-(len(series_date_time) - series_date_time.index("."))]
        
    series_date_time = datetime.strptime(series_date_time, "%Y%m%d_%H%M%S")
        
    start_time = (ds.SeriesDate + "_" + radiopharm_info.RadiopharmaceuticalStartTime)    
        
    if "." in start_time:
        start_time = start_time[: -(len(start_time) - start_time.index("."))]
            
    start_time = datetime.strptime(start_time, "%Y%m%d_%H%M%S")
    
    decay_time = (series_date_time - start_time).seconds
    injected_dose = float(radiopharm_info.RadionuclideTotalDose)
    decayed_dose = injected_dose * pow(2, -decay_time / half_life)
    patient_weight = float(ds.PatientWeight)
    suv_bw_scale_factor = patient_weight * 1000 / decayed_dose
    
    return suv_bw_scale_factor

def extract_niftis(subdirs_list, patients_list, segmentations_list, segmentation_file_path, scan_types, nifti_directory=".\\raw_niftis"):
    """
    Extracts nifti images from each patient

    Parameters: 
    
    * subdirs_list (list[str]): list of subdirectories containing patient data
    
    * patients_list (list[str]): list of patient IDs
    
    * segmentations_list (list[str]): list of segmentation file names
    
    * segmentation_file_path (str): destination of segmentations
    
    * scan_types (list[str]): list of scan types
    
    * nifti_directory (str): directory to save nifti files

    Output:
    
    * niftis (list[str]): list of filenames of nifti images from each patient
    """
    niftis = []
    os.chdir(nifti_directory)
    
    for i, subdirs in enumerate(subdirs_list): #loop through each patient
        niftis_list = []
        for scan_type, subdir in zip(scan_types, subdirs):    #loop through each of the different scans of each patients 
          filename = dicom_to_nifti(subdir, patients_list[i], scan_type)
          if sitk.ReadImage(filename, sitk.sitkFloat32).GetSize()[2] < 4: #check if the nifti has enough slices
              continue
          else:
              niftis_list.append(register_nifti(filename, os.path.join(segmentation_file_path,segmentations_list[i]), scan_type, patients_list[i]))
        niftis.append(niftis_list)
    return niftis

def register_nifti(raw_nifti, segmentation, scan_type, patient_id):
  """
    Registers nifti of dicom image to match segmentation

    Parameters: 
    
    * raw_nifti (str): path to raw nifti
    
    * segmentation (str): path to segmentation
    
    * patient_id (str): patient ID

    Returns:
    
    * filename (str): path to registered nifti
  """
  raw_nifti = sitk.ReadImage(raw_nifti, sitk.sitkFloat32)  # Read the NIfTI file using SimpleITK
  segmentation = sitk.ReadImage(segmentation, sitk.sitkFloat32)

  # Initialize the registration method
  registration_method = sitk.ImageRegistrationMethod()

  # Similarity metric settings
  registration_method.SetMetricAsMattesMutualInformation(numberOfHistogramBins=50)
  registration_method.SetMetricSamplingStrategy(registration_method.RANDOM)
  registration_method.SetMetricSamplingPercentage(0.01)

  # Interpolator
  registration_method.SetInterpolator(sitk.sitkLinear)

  # Optimizer settings
  registration_method.SetOptimizerAsGradientDescent(learningRate=1.0, numberOfIterations=100,
                                                    convergenceMinimumValue=1e-6, convergenceWindowSize=10)
  registration_method.SetOptimizerScalesFromPhysicalShift()

  # Set the initial transform
  initial_transform = sitk.CenteredTransformInitializer(segmentation, 
                                                        raw_nifti, 
                                                        sitk.Euler3DTransform(), 
                                                        sitk.CenteredTransformInitializerFilter.GEOMETRY)
  registration_method.SetInitialTransform(initial_transform, inPlace=False)

  # Perform the registration
  final_transform = registration_method.Execute(segmentation, raw_nifti)

  # Resample the moving image
  nifti = sitk.Resample(raw_nifti, segmentation, final_transform,
                                  sitk.sitkLinear, 0.0, raw_nifti.GetPixelID())

  filename = f"aligned_{scan_type}_{patient_id}.nii.gz"
  sitk.WriteImage(nifti, filename)

  return filename

def compare_segmentations(auto_segmentations, manual_segmentations, methods, filename=None):
  """
    Compares automatic and manual segmentations

    Parameters: 
    
    * auto_segmentations (list[str]): list of file paths to automatic segmentations
    
    * manual_segmentations (list[str]): list of file paths to manual segmentations
    
    * methods (list[str]): methods of evaluating similarity

    * filename (str): name of file without extension to save summary of similarity scores to. If none, similarity scores are not saved to a file 

    Returns:
    
    * similarities (numpy array): list of similarity values

    Output:
    
    * text file with similarity summary statistics

    * csv file with similarity values
  """
  similarities = {method:[] for method in methods} #initialise list of similarity metrics
  for auto, manual in zip(auto_segmentations, manual_segmentations): #loop through each manual and auto segmentation
    auto = nib.load(auto)
    manual = nib.load(manual)
    if auto.get_fdata().shape != manual.get_fdata().shape: #check if auto and manual segmentations are same size
      auto = ip.resample_nifti(auto, manual.get_fdata().shape, discrete=True)       
    auto_data = np.asarray(auto.dataobj, dtype=bool).flatten()
    manual_data = np.asarray(manual.dataobj, dtype=bool).flatten()
    intersection = np.logical_and(auto_data, manual_data).sum()
    union = np.logical_or(auto_data, manual_data).sum()
    for method in methods:
      if method.lower() == 'dice':                                 
          score = 2. * intersection / (auto_data.sum() + manual_data.sum()) 
                
      elif method.lower() == 'jaccard':
        score = intersection / union
      elif method.lower() == 'overlap':
         score = intersection / min(auto_data.sum(), manual_data.sum())
      similarities[method].append(score)   
  similarities = {key:np.array(value) for key, value in similarities.items()}
  if filename is not None:
    with open(f"{filename}.txt",'w') as f:
       for method in methods:
        f.write(method.capitalize() + '\n')
        f.write(f"Min: {np.min(similarities[method])}\n")
        f.write(f"Median: {np.median(similarities[method])}\n")
        f.write(f"Mean: {np.mean(similarities[method])}\n")
        f.write(f"Max: {np.max(similarities[method])}\n")
        f.write("\n")
    similarities_df = pd.DataFrame(similarities)
    pd.DataFrame.to_csv(similarities_df, f"{filename}.csv", index=False)
  return similarities

def file_list_to_dict(images_list, num_start):
  """
  Converts list of files to dictionary with keys as patient IDs and values as list of files for that patient

  Parameters:
  
  * images_list (list[str]): list of image filenames
  
  * num_start (int): starting index of patient ID in filename

  Returns:
  
  * images_dict (dict{str: list[str]}): dictionary with patient IDs as keys and list of files as values
  """
  images_dict = {}
  for image in images_list:
    num = image[num_start:num_start+3]
    if num in images_dict:
        images_dict[num].append(image)
    else:
        images_dict[num] = [image]
  return images_dict