# -*- coding: utf-8 -*-
"""
Module domain.py
===========================================

Configuration module for...

# TODO: Add description of the module.

Classes:
    **UnitManager**: Manages units and their conversions, including validation and error handling.

*IMPORTANT:* Based on the theory from:

    # H.Gorter, *Dimensionalanalyse: Eine Theoririe der physikalischen Dimensionen mit Anwendungen*
"""
# TODO add UnitManager class
