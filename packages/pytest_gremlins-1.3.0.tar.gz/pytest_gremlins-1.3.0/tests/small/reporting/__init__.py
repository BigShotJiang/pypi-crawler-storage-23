"""Tests for the reporting module."""
