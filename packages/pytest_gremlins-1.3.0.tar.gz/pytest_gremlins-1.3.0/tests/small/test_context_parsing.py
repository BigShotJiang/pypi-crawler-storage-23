"""Tests for coverage context parsing in _extract_test_name_from_context.

The context format used by GremlinContextPlugin is:
    ``{nodeid}|{when}``  e.g. ``tests/test_foo.py::test_bar|run``

The nodeid part is ``tests/test_foo.py::test_bar`` and the function name is
extracted as the last ``::``-separated segment: ``test_bar``.

The old dynamic_context=test_function format (without ``|``) is also handled
as a fallback:
    ``test_bar``  -> ``test_bar``
    ``TestClass.test_method`` -> ``test_method``
"""

from __future__ import annotations

import pytest

from pytest_gremlins.plugin import _extract_test_name_from_context


@pytest.mark.small
class TestExtractTestNameFromContext:
    """_extract_test_name_from_context parses both old and new context formats."""

    def test_new_format_run_phase_returns_function_name(self) -> None:
        """New format 'nodeid|run' returns the test function name."""
        result = _extract_test_name_from_context('tests/test_foo.py::test_bar|run')
        assert result == 'test_bar'

    def test_new_format_setup_phase_returns_function_name(self) -> None:
        """New format 'nodeid|setup' still returns the test function name, not 'setup'."""
        result = _extract_test_name_from_context('tests/test_foo.py::test_bar|setup')
        assert result == 'test_bar'

    def test_new_format_teardown_phase_returns_function_name(self) -> None:
        """New format 'nodeid|teardown' still returns the test function name."""
        result = _extract_test_name_from_context('tests/test_foo.py::test_bar|teardown')
        assert result == 'test_bar'

    def test_new_format_with_class_returns_method_name(self) -> None:
        """New format with class::method extracts the method name."""
        result = _extract_test_name_from_context('tests/test_foo.py::TestFoo::test_bar|run')
        assert result == 'test_bar'

    def test_different_function_name_produces_different_result(self) -> None:
        """Different function names produce different results - rules out hardcoding."""
        result_a = _extract_test_name_from_context('tests/test_foo.py::test_alpha|run')
        result_b = _extract_test_name_from_context('tests/test_foo.py::test_beta|run')
        assert result_a == 'test_alpha'
        assert result_b == 'test_beta'

    def test_old_format_plain_name_returns_name(self) -> None:
        """Old dynamic_context format with plain function name passes through."""
        result = _extract_test_name_from_context('test_bar')
        assert result == 'test_bar'

    def test_old_format_dotted_name_returns_last_segment(self) -> None:
        """Old format 'Module.test_method' returns just 'test_method'."""
        result = _extract_test_name_from_context('TestClass.test_method')
        assert result == 'test_method'

    def test_old_format_double_colon_returns_last_segment(self) -> None:
        """Old format 'path::test_func' (no pipe) returns 'test_func'."""
        result = _extract_test_name_from_context('tests/test_foo.py::test_func')
        assert result == 'test_func'
