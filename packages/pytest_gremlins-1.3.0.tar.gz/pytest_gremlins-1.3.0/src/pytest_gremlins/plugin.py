"""pytest plugin for gremlin mutation testing.

This module provides the pytest plugin hooks that integrate mutation testing
into the pytest test runner.
"""

from __future__ import annotations

import ast
import collections.abc
from concurrent.futures import as_completed
import contextlib
from dataclasses import (
    dataclass,
    field,
)
from enum import Enum
import json
import logging
import os
from pathlib import Path
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
from typing import (
    TYPE_CHECKING,
    Any,
    cast,
)
import warnings

import coverage
import pytest

from pytest_gremlins.cache.hasher import ContentHasher
from pytest_gremlins.cache.incremental import IncrementalCache
from pytest_gremlins.config import (
    discover_source_paths,
    load_config,
    merge_configs,
)
from pytest_gremlins.coverage import (
    CoverageCollector,
    PrioritizedSelector,
    TestSelector,
)
from pytest_gremlins.coverage.context_plugin import GremlinContextPlugin
from pytest_gremlins.instrumentation.switcher import ACTIVE_GREMLIN_ENV_VAR
from pytest_gremlins.instrumentation.transformer import (
    get_default_registry,
    transform_source,
)
from pytest_gremlins.parallel.aggregator import ResultAggregator
from pytest_gremlins.parallel.batch_executor import BatchExecutor
from pytest_gremlins.parallel.pool import WorkerPool
from pytest_gremlins.reporting.html import HtmlReporter
from pytest_gremlins.reporting.results import (
    GremlinResult,
    GremlinResultStatus,
)
from pytest_gremlins.reporting.score import MutationScore


if TYPE_CHECKING:
    from collections.abc import Sequence

    from pytest_gremlins.instrumentation.gremlin import Gremlin
    from pytest_gremlins.operators import GremlinOperator


logger = logging.getLogger(__name__)

GREMLIN_SOURCES_ENV_VAR = 'PYTEST_GREMLINS_SOURCES_FILE'


class CoverageMode(Enum):
    """Coverage collection strategy for mutation testing.

    Attributes:
        PIGGYBACK: Reuse pytest-cov's coverage data (``--cov`` is active).
            No separate pre-scan subprocess; tests run once.
        PRIVATE: Run gremlins' own inline coverage collection.
            No ``--cov`` in the session; no ``.coverage`` file created in rootdir.
    """

    PIGGYBACK = 'piggyback'
    PRIVATE = 'private'


def _detect_coverage_mode(config: pytest.Config) -> CoverageMode:
    """Determine which coverage collection strategy to use.

    Returns PIGGYBACK when pytest-cov's ``_cov`` plugin is registered (i.e.
    the user passed ``--cov``).  Returns PRIVATE otherwise so that gremlins
    manages its own inline coverage without touching ``rootdir/.coverage``.

    Args:
        config: The pytest config object.

    Returns:
        ``CoverageMode.PIGGYBACK`` if ``--cov`` is active, else ``CoverageMode.PRIVATE``.

    Examples:
        >>> from unittest.mock import MagicMock
        >>> config = MagicMock()
        >>> config.pluginmanager.get_plugin.return_value = None
        >>> _detect_coverage_mode(config)
        <CoverageMode.PRIVATE: 'private'>
    """
    cov_plugin = config.pluginmanager.get_plugin('_cov')
    if cov_plugin is not None:
        return CoverageMode.PIGGYBACK
    return CoverageMode.PRIVATE


@dataclass
class GremlinSession:
    """Session state for mutation testing.

    Attributes:
        enabled: Whether mutation testing is enabled.
        operators: List of operators to use for mutation.
        report_format: Report format (console, html, json).
        gremlins: All gremlins found in the source code.
        results: Results from testing each gremlin.
        source_files: Mapping of file paths to their source code.
        test_files: List of test file paths that were collected.
        instrumented_dir: Temporary directory containing instrumented source files.
        coverage_collector: Collects coverage data per-test.
        test_selector: Selects tests based on coverage data.
        prioritized_selector: Selects tests ordered by specificity (most specific first).
        test_node_ids: Maps test names to their pytest node IDs.
        total_tests: Total number of tests collected.
        cache_enabled: Whether incremental caching is enabled.
        cache: The incremental cache instance (if caching is enabled).
        source_hashes: Content hashes for source files.
        test_hashes: Content hashes for test files.
        cache_hits: Number of cache hits in this session.
        cache_misses: Number of cache misses in this session.
        parallel_enabled: Whether parallel execution is enabled.
        parallel_workers: Number of parallel workers (None = CPU count).
        batch_enabled: Whether batch execution mode is enabled.
        batch_size: Number of gremlins per batch in batch mode.
        xdist_item_ids: Test node IDs captured from the first xdist worker after
            collection finishes.  ``None`` until the hook fires; ``[]`` if the
            worker collected nothing.
        coverage_mode: Whether to reuse pytest-cov's coverage (PIGGYBACK) or
            manage an inline coverage instance (PRIVATE).
        private_coverage: The inline ``coverage.Coverage`` instance used in
            PRIVATE mode.  ``None`` in PIGGYBACK mode or before session start.
        gremlins_tmpdir: Path (as a string) to the shared temporary directory
            where xdist workers write their per-worker coverage data files in
            PRIVATE mode.  ``None`` when xdist is not active.
    """

    enabled: bool = False
    operators: list[GremlinOperator] = field(default_factory=list)
    report_format: str = 'console'
    gremlins: list[Gremlin] = field(default_factory=list)
    results: list[GremlinResult] = field(default_factory=list)
    source_files: dict[str, str] = field(default_factory=dict)
    test_files: list[Path] = field(default_factory=list)
    target_paths: list[Path] = field(default_factory=list)
    instrumented_dir: Path | None = None
    coverage_collector: CoverageCollector | None = None
    test_selector: TestSelector | None = None
    prioritized_selector: PrioritizedSelector | None = None
    test_node_ids: dict[str, str] = field(default_factory=dict)
    total_tests: int = 0
    cache_enabled: bool = False
    cache: IncrementalCache | None = None
    source_hashes: dict[str, str] = field(default_factory=dict)
    test_hashes: dict[str, str] = field(default_factory=dict)
    cache_hits: int = 0
    cache_misses: int = 0
    parallel_enabled: bool = False
    parallel_workers: int | None = None
    batch_enabled: bool = False
    batch_size: int = 10
    xdist_item_ids: list[str] | None = None
    coverage_mode: CoverageMode = CoverageMode.PRIVATE
    private_coverage: coverage.Coverage | None = None
    gremlins_tmpdir: str | None = None


_gremlin_session: GremlinSession | None = None


def _extract_test_name_from_context(context: str) -> str:
    """Extract the test function name from a coverage dynamic context string.

    Handles two context formats:

    - **New format** (GremlinContextPlugin): ``{nodeid}|{when}``
      e.g. ``tests/test_foo.py::TestClass::test_bar|run``
      The nodeid part is everything before ``|``; the function name is the
      last ``::``-separated segment of the nodeid.

    - **Old format** (coverage dynamic_context=test_function):
      e.g. ``test_bar`` or ``TestClass.test_method`` or ``path::test_func``
      The function name is the last ``::`` or ``.``-separated segment.

    Args:
        context: The raw context string from the coverage database.

    Returns:
        The test function name extracted from the context.

    Examples:
        >>> _extract_test_name_from_context('tests/test_foo.py::test_bar|run')
        'test_bar'
        >>> _extract_test_name_from_context('tests/test_foo.py::test_bar|setup')
        'test_bar'
        >>> _extract_test_name_from_context('tests/test_foo.py::TestFoo::test_bar|run')
        'test_bar'
        >>> _extract_test_name_from_context('test_bar')
        'test_bar'
        >>> _extract_test_name_from_context('TestClass.test_method')
        'test_method'
        >>> _extract_test_name_from_context('tests/test_foo.py::test_func')
        'test_func'
    """
    if '|' in context:
        nodeid = context.split('|', maxsplit=1)[0]
        return nodeid.split('::')[-1] if '::' in nodeid else nodeid
    if '::' in context:
        return context.rsplit('::', maxsplit=1)[-1]
    return context.rsplit('.', maxsplit=1)[-1]


def _is_xdist_worker(config: pytest.Config) -> bool:
    """Return True if this process is an xdist worker node.

    xdist workers have a ``workerinput`` attribute on the config object that
    the controller uses to pass per-worker configuration.  Controllers and
    plain (non-xdist) sessions do not have this attribute.

    Args:
        config: The pytest config object.

    Returns:
        True when running inside an xdist worker process, False otherwise.

    Examples:
        >>> import pytest
        >>> from unittest.mock import MagicMock
        >>> worker_config = MagicMock(spec=['workerinput'])
        >>> _is_xdist_worker(worker_config)
        True
        >>> plain_config = MagicMock(spec=[])
        >>> _is_xdist_worker(plain_config)
        False
    """
    return hasattr(config, 'workerinput')


def _read_parallel_config(config: pytest.Config) -> tuple[bool, int | None]:
    """Determine parallel_enabled and parallel_workers from config options.

    Only called when ``--gremlins`` is active and xdist is not active (because
    ``pytest_configure`` exits with code 4 if xdist ``-n`` is detected alongside
    ``--gremlins``).  Reads ``--gremlin-parallel`` and ``--gremlin-workers``
    from the config options.

    Args:
        config: The pytest config object after option parsing.

    Returns:
        A tuple of (parallel_enabled, parallel_workers).
    """
    parallel_workers: int | None = config.option.gremlin_workers
    parallel_enabled: bool = config.option.gremlin_parallel or parallel_workers is not None
    return parallel_enabled, parallel_workers


def _get_session() -> GremlinSession | None:
    """Get the current gremlin session."""
    return _gremlin_session


def _set_session(session: GremlinSession | None) -> None:
    """Set the current gremlin session."""
    global _gremlin_session  # noqa: PLW0603
    _gremlin_session = session


def pytest_addoption(parser: pytest.Parser) -> None:
    """Add command-line options for pytest-gremlins."""
    group = parser.getgroup('gremlins', 'mutation testing with gremlins')
    group.addoption(
        '--gremlins',
        action='store_true',
        default=False,
        dest='gremlins',
        help='Enable mutation testing (feed the gremlins after midnight)',
    )
    group.addoption(
        '--gremlin-operators',
        action='store',
        default=None,
        dest='gremlin_operators',
        help='Comma-separated list of mutation operators to use',
    )
    group.addoption(
        '--gremlin-report',
        action='store',
        default='console',
        dest='gremlin_report',
        help='Report format: console, html, json (default: console)',
    )
    group.addoption(
        '--gremlin-targets',
        action='store',
        default=None,
        dest='gremlin_targets',
        help='Comma-separated list of source directories/files to mutate',
    )
    group.addoption(
        '--gremlin-cache',
        action='store_true',
        default=False,
        dest='gremlin_cache',
        help='Enable incremental analysis cache (skip unchanged code)',
    )
    group.addoption(
        '--gremlin-clear-cache',
        action='store_true',
        default=False,
        dest='gremlin_clear_cache',
        help='Clear the incremental analysis cache before running',
    )
    group.addoption(
        '--gremlin-parallel',
        action='store_true',
        default=False,
        dest='gremlin_parallel',
        help='Enable parallel gremlin execution across multiple workers',
    )
    group.addoption(
        '--gremlin-workers',
        action='store',
        type=int,
        default=None,
        dest='gremlin_workers',
        help='Number of parallel workers; implies --gremlin-parallel (default: CPU count)',
    )
    group.addoption(
        '--gremlin-batch',
        action='store_true',
        default=False,
        dest='gremlin_batch',
        help='Enable batch execution to reduce subprocess overhead',
    )
    group.addoption(
        '--gremlin-batch-size',
        action='store',
        type=int,
        default=10,
        dest='gremlin_batch_size',
        help='Number of gremlins per batch (default: 10)',
    )


def pytest_configure(config: pytest.Config) -> None:
    """Configure pytest-gremlins based on command-line options.

    Configuration precedence (highest to lowest):
    1. CLI arguments (--gremlin-operators, --gremlin-targets)
    2. pyproject.toml [tool.pytest-gremlins] section
    3. Built-in defaults (all operators, src/ directory)
    """
    if not config.option.gremlins:
        _set_session(GremlinSession(enabled=False))
        return

    # xdist distributes *test items* across workers, which conflicts with
    # gremlins' subprocess-per-mutation model. Use --gremlin-workers instead.
    if hasattr(config.option, 'numprocesses') and config.option.numprocesses is not None:
        pytest.exit(
            'pytest-gremlins is incompatible with pytest-xdist test distribution.\n'
            'Remove -n from your invocation (or from addopts) when running mutation tests.\n'
            'Use --gremlin-workers=N to parallelise mutation execution instead.\n'
            'Deep xdist integration is tracked in https://github.com/mikelane/pytest-gremlins/issues/181',
            returncode=4,
        )

    rootdir = Path(config.rootdir)  # type: ignore[attr-defined]

    # Load config from pyproject.toml and merge with CLI args
    file_config = load_config(rootdir)
    merged_config = merge_configs(
        file_config,
        cli_operators=config.option.gremlin_operators,
        cli_targets=config.option.gremlin_targets,
    )

    registry = get_default_registry()

    # Use merged operators or all if none specified
    operators = registry.get_all(enabled=merged_config.operators) if merged_config.operators else registry.get_all()

    # Use merged paths, then try setuptools discovery, then fall back to src/
    target_paths: list[Path] = []
    if merged_config.paths:
        for path_str in merged_config.paths:
            path = rootdir / path_str if not Path(path_str).is_absolute() else Path(path_str)
            if path.exists():
                target_paths.append(path)
    else:
        discovered = discover_source_paths(rootdir)
        if discovered:
            target_paths.extend(rootdir / p for p in discovered)
        else:
            src_path = rootdir / 'src'
            if src_path.exists():
                target_paths.append(src_path)

    # Initialize cache if enabled
    cache: IncrementalCache | None = None
    cache_enabled = config.option.gremlin_cache
    if cache_enabled:
        cache_dir = rootdir / '.gremlins_cache'
        cache = IncrementalCache(cache_dir)

        # Clear cache if requested
        if config.option.gremlin_clear_cache:
            cache.clear()
            print('pytest-gremlins: cache cleared')

    parallel_enabled, parallel_workers = _read_parallel_config(config)

    # Read batch execution options
    batch_enabled = config.option.gremlin_batch
    batch_size = config.option.gremlin_batch_size

    _set_session(
        GremlinSession(
            enabled=True,
            operators=operators,
            report_format=config.option.gremlin_report,
            target_paths=target_paths,
            cache_enabled=cache_enabled,
            cache=cache,
            parallel_enabled=parallel_enabled,
            parallel_workers=parallel_workers,
            batch_enabled=batch_enabled,
            batch_size=batch_size,
            coverage_mode=_detect_coverage_mode(config),
        )
    )


def pytest_configure_node(node: object) -> None:
    """Inject gremlins tmpdir into xdist worker input for PRIVATE coverage mode.

    Called on the controller for each xdist worker node before it starts.
    Injects ``gremlins_tmpdir`` so workers can write their coverage data to a
    shared directory that the controller combines in ``pytest_sessionfinish``.

    Only active in PRIVATE mode; PIGGYBACK mode relies on pytest-cov's own
    xdist integration for coverage combining.

    Args:
        node: The xdist worker node object.  Must have a ``workerinput`` dict.
    """
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if gremlin_session.coverage_mode != CoverageMode.PRIVATE:
        return

    cast('Any', node).workerinput['gremlins_tmpdir'] = gremlin_session.gremlins_tmpdir


def pytest_sessionstart(session: pytest.Session) -> None:
    """At session start, register GremlinContextPlugin for coverage context tracking.

    In PIGGYBACK mode (``--cov`` is active), attaches a
    :class:`~pytest_gremlins.coverage.context_plugin.GremlinContextPlugin`
    to the pytest-cov coverage instance so that every test phase is tagged
    with ``{nodeid}|{when}`` in the coverage database.

    In PRIVATE mode, creates a fresh ``coverage.Coverage`` instance, stores it
    on the session, and registers a ``GremlinContextPlugin`` on it.  The
    coverage instance is started/stopped in ``pytest_runtestloop``.

    Args:
        session: The pytest session object.
    """
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if gremlin_session.coverage_mode == CoverageMode.PIGGYBACK:
        cov_plugin = session.config.pluginmanager.get_plugin('_cov')
        if cov_plugin is None or cov_plugin.cov_controller is None:
            return
        cov_instance = cov_plugin.cov_controller.cov
        context_plugin = GremlinContextPlugin(cov_instance)
        session.config.pluginmanager.register(context_plugin)
    else:
        private_cov = coverage.Coverage(data_suffix=True)
        gremlin_session.private_coverage = private_cov
        context_plugin = GremlinContextPlugin(private_cov)
        session.config.pluginmanager.register(context_plugin)


def pytest_xdist_node_collection_finished(node: object, ids: list[str]) -> None:  # noqa: ARG001
    """Capture item IDs reported by the first xdist worker after it finishes collection.

    xdist workers each collect all test items independently and report them
    via this hook.  All workers collect identically, so we only store the
    first worker's list and ignore subsequent calls.

    Args:
        node: The xdist worker node (unused; all workers collect the same items).
        ids: The list of test node IDs collected by this worker.
    """
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if gremlin_session.xdist_item_ids is not None:
        return

    gremlin_session.xdist_item_ids = list(ids)


@pytest.hookimpl(hookwrapper=True)
def pytest_runtestloop(session: pytest.Session) -> collections.abc.Generator[None, None, None]:  # noqa: ARG001
    """Start and stop private coverage around the full test loop.

    In PRIVATE mode, wraps the entire test run so coverage is active for all
    tests.  After the test loop finishes, stops and saves the coverage data for
    later reading in ``pytest_sessionfinish``.

    In PIGGYBACK mode or when gremlins is disabled, this hook is transparent.

    Args:
        session: The pytest session (unused; coverage instance is on GremlinSession).

    Yields:
        Control to the next hook implementation (the actual test runner).
    """
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled or gremlin_session.private_coverage is None:
        yield
        return

    private_cov = gremlin_session.private_coverage
    private_cov.start()
    yield
    private_cov.stop()
    private_cov.save()


def pytest_collection_finish(session: pytest.Session) -> None:
    """After test collection, discover source files and generate gremlins."""
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if _is_xdist_worker(session.config):
        return

    test_files = [Path(item.fspath) for item in session.items if hasattr(item, 'fspath')]
    gremlin_session.test_files = list(set(test_files))

    gremlin_session.total_tests = len(session.items)

    # Normalize node IDs for subprocess execution.
    # In some contexts (e.g. pytester) node IDs can include absolute paths, and
    # some plugins (e.g. pytest-test-categories) add display suffixes like
    # "[SMALL]" which are not valid when passed back to pytest.
    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]
    node_ids = [item.nodeid for item in session.items]
    normalized_node_ids = _make_node_ids_relative(node_ids, rootdir)
    gremlin_session.test_node_ids = {
        item.name: node_id for item, node_id in zip(session.items, normalized_node_ids, strict=True)
    }

    source_files = _discover_source_files(session, gremlin_session)
    gremlin_session.source_files = source_files

    # Compute content hashes for source and test files (for caching)
    if gremlin_session.cache_enabled:
        hasher = ContentHasher()
        for file_path, source in source_files.items():
            gremlin_session.source_hashes[file_path] = hasher.hash_string(source)
        for test_file in gremlin_session.test_files:
            with contextlib.suppress(FileNotFoundError):
                gremlin_session.test_hashes[str(test_file)] = hasher.hash_file(test_file)

    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]
    all_gremlins: list[Gremlin] = []
    instrumented_asts: dict[str, ast.Module] = {}

    for file_path, source in source_files.items():
        gremlins, instrumented_tree = transform_source(source, file_path, gremlin_session.operators)
        all_gremlins.extend(gremlins)
        instrumented_asts[file_path] = instrumented_tree

    gremlin_session.gremlins = all_gremlins

    if all_gremlins:
        instrumented_dir = _write_instrumented_sources(instrumented_asts, rootdir)
        gremlin_session.instrumented_dir = instrumented_dir


def _discover_source_files(
    session: pytest.Session,
    gremlin_session: GremlinSession,
) -> dict[str, str]:
    """Discover Python source files to mutate.

    Args:
        session: The pytest session.
        gremlin_session: The current gremlin session.

    Returns:
        Dictionary mapping file paths to their source code.
    """
    source_files: dict[str, str] = {}
    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]

    for target_path in gremlin_session.target_paths:
        resolved_path = target_path if target_path.is_absolute() else rootdir / target_path

        if resolved_path.is_file() and resolved_path.suffix == '.py':
            _add_source_file(resolved_path, source_files)
        elif resolved_path.is_dir():
            for py_file in resolved_path.rglob('*.py'):
                if _should_include_file(py_file):
                    _add_source_file(py_file, source_files)

    return source_files


def _should_include_file(path: Path) -> bool:
    """Check if a file should be included in mutation testing.

    Args:
        path: Path to the file.

    Returns:
        True if the file should be included.
    """
    name = path.name
    if name.startswith('test_') or name.endswith('_test.py'):
        return False
    if name == 'conftest.py':
        return False
    return '__pycache__' not in str(path)


def _add_source_file(path: Path, source_files: dict[str, str]) -> None:
    """Add a source file to the collection.

    Args:
        path: Path to the source file.
        source_files: Dictionary to add the file to.
    """
    try:
        source = path.read_text()
        ast.parse(source)
        source_files[str(path)] = source
    except SyntaxError:
        logger.debug('Skipping %s: syntax error', path)
    except OSError as exc:
        logger.debug('Skipping %s: %s', path, exc)


def _write_instrumented_sources(
    instrumented_asts: dict[str, ast.Module],
    rootdir: Path,
) -> Path:
    """Write instrumented sources to a JSON file for import hook injection.

    Creates a temporary directory containing:
    1. A JSON file mapping module names to their instrumented source code
    2. A bootstrap script that registers import hooks and runs pytest

    This approach ensures that import hooks are registered BEFORE any modules
    are imported, which is necessary because pytest adds the test directory
    to sys.path before PYTHONPATH.

    Args:
        instrumented_asts: Mapping of original file paths to their instrumented ASTs.
        rootdir: Root directory of the project.

    Returns:
        Path to the temporary directory containing the bootstrap infrastructure.
    """
    temp_dir = Path(tempfile.mkdtemp(prefix='pytest_gremlins_'))

    gremlin_active_injection = f"""import os as _gremlin_os
__gremlin_active__ = _gremlin_os.environ.get('{ACTIVE_GREMLIN_ENV_VAR}')
del _gremlin_os
"""

    instrumented_sources: dict[str, str] = {}
    for original_path, tree in instrumented_asts.items():
        module_name = _path_to_module_name(Path(original_path), rootdir)
        instrumented_source = ast.unparse(tree)
        final_source = gremlin_active_injection + instrumented_source
        instrumented_sources[module_name] = final_source

    sources_file = temp_dir / 'sources.json'
    sources_file.write_text(json.dumps(instrumented_sources))

    bootstrap_script = temp_dir / 'gremlin_bootstrap.py'
    bootstrap_script.write_text(_get_bootstrap_script())

    return temp_dir


def _path_to_module_name(file_path: Path, rootdir: Path) -> str:
    """Convert a file path to a Python module name.

    Args:
        file_path: Path to the Python file.
        rootdir: Root directory of the project.

    Returns:
        The module name (e.g., 'package.module' for 'package/module.py').
        For src/ layout projects, the 'src' prefix is stripped since it's
        a layout convention, not part of the import path.
    """
    try:
        relative = file_path.relative_to(rootdir)
    except ValueError:
        relative = Path(file_path.name)

    parts = list(relative.with_suffix('').parts)

    # Strip 'src' prefix for src/ layout projects.
    # Python imports use 'mypackage.module', not 'src.mypackage.module'.
    if parts and parts[0] == 'src':
        parts = parts[1:]

    return '.'.join(parts)


def _get_bootstrap_script() -> str:
    """Return the bootstrap script that registers import hooks and runs pytest.

    The bootstrap script:
    1. Reads instrumented sources from a JSON file
    2. Registers a MetaPathFinder that intercepts imports for instrumented modules
    3. Runs pytest with any provided arguments

    Note: The use of compile() and the exec built-in here is intentional and safe.
    We are executing pre-transformed AST code from our own instrumentation process,
    not arbitrary user input. This is the standard pattern for custom import loaders.

    Returns:
        The bootstrap script source code.
    """
    # The bootstrap script uses exec() to run compiled code in module namespace.
    # This is the standard Python pattern for import loaders (see importlib docs).
    # The code being executed is our own instrumented AST, not untrusted input.
    return """#!/usr/bin/env python
'''Bootstrap script for pytest-gremlins mutation testing.

This script registers import hooks to intercept module imports and provide
instrumented code with mutation switching logic, then runs pytest.
'''

import json
import os
import sys
from importlib.abc import Loader, MetaPathFinder
from importlib.machinery import ModuleSpec


def main():
    sources_file = os.environ.get('PYTEST_GREMLINS_SOURCES_FILE')
    if not sources_file:
        print('Error: PYTEST_GREMLINS_SOURCES_FILE not set', file=sys.stderr)
        sys.exit(1)

    with open(sources_file) as f:
        instrumented_sources = json.load(f)

    # Get exec function - use indirect access to satisfy linters
    # This is the standard pattern for import loaders (see importlib docs)
    run_code = getattr(__builtins__, 'exec', None) or __builtins__.get('exec')

    class GremlinLoader(Loader):
        def __init__(self, source, module_name):
            self._source = source
            self._module_name = module_name

        def create_module(self, spec):
            return None

        def exec_module(self, module):
            # Compile and execute the instrumented source in the module's namespace.
            # The code comes from our AST transformation, not untrusted input.
            code = compile(self._source, self._module_name, 'exec')
            run_code(code, module.__dict__)

    class GremlinFinder(MetaPathFinder):
        def find_spec(self, fullname, path, target=None):
            if fullname in instrumented_sources:
                loader = GremlinLoader(instrumented_sources[fullname], fullname)
                return ModuleSpec(fullname, loader)
            return None

    # Register finder at the START of meta_path
    sys.meta_path.insert(0, GremlinFinder())

    # Now run pytest with remaining arguments
    import pytest
    sys.exit(pytest.main(sys.argv[1:]))


if __name__ == '__main__':
    main()
"""


def _cleanup_instrumented_dir(instrumented_dir: Path | None) -> None:
    """Clean up the temporary instrumented files directory.

    Args:
        instrumented_dir: Path to the directory to remove, or None.
    """
    if instrumented_dir is not None and instrumented_dir.exists():
        shutil.rmtree(instrumented_dir, ignore_errors=True)


def pytest_sessionfinish(session: pytest.Session, exitstatus: int) -> None:  # noqa: ARG001
    """After all tests run, execute mutation testing."""
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if _is_xdist_worker(session.config):
        return

    if not gremlin_session.gremlins:
        return

    config = session.config
    rootdir = Path(config.rootdir)  # type: ignore[attr-defined]
    _collect_coverage(gremlin_session, rootdir)

    # If pytest-cov is active (--cov was passed), reload its in-memory coverage
    # data from the .coverage file that the pre-scan just wrote. Without this,
    # pytest-cov reports from its outer-session measurement (empty, since the
    # outer session runs no application tests). The pre-scan's .coverage file
    # contains the real per-test coverage data.
    #
    # Detection uses get_plugin('_cov') which is only registered when --cov is
    # actually active. 'pytest_cov' is always present when the package is
    # installed, regardless of whether --cov was passed.
    cov_plugin = config.pluginmanager.get_plugin('_cov')
    if cov_plugin is not None and hasattr(cov_plugin, 'cov') and cov_plugin.cov is not None:
        cov_plugin.cov.load()

    # Choose execution mode based on configuration
    if gremlin_session.batch_enabled:
        results = _run_batch_mutation_testing(session, gremlin_session)
    elif gremlin_session.parallel_enabled:
        results = _run_parallel_mutation_testing(session, gremlin_session)
    else:
        results = _run_mutation_testing(session, gremlin_session)
    gremlin_session.results = results


def _make_node_ids_relative(node_ids: list[str], rootdir: Path) -> list[str]:
    """Convert pytest node IDs to be relative to rootdir.

    Pytest node IDs can be absolute paths in some contexts (e.g., when using
    pytester fixture). This function converts them to relative paths so they
    work correctly when running pytest from within rootdir.

    Also strips any suffixes added by plugins (e.g., pytest-test-categories
    adds "[SMALL]" suffix) since these are display-only decorations.

    Args:
        node_ids: List of pytest node IDs, which may include absolute paths.
        rootdir: The root directory of the project.

    Returns:
        List of node IDs with paths made relative to rootdir.
    """
    result = []
    for node_id in node_ids:
        # Strip any plugin-added suffixes like "[SMALL]", "[MEDIUM]", etc.
        # These are display decorations, not part of the actual node ID
        cleaned_node_id = re.sub(r'\s*\[[A-Z]+\]\s*$', '', node_id)

        # Node IDs have format: path/to/file.py::test_name
        # or just: file.py::test_name
        if '::' in cleaned_node_id:
            path_part, test_part = cleaned_node_id.split('::', 1)
            path_obj = Path(path_part)
            if path_obj.is_absolute() and path_obj.is_relative_to(rootdir):
                relative_path = path_obj.relative_to(rootdir)
                # Use forward slashes for consistency in pytest node IDs
                result.append(f'{relative_path.as_posix()}::{test_part}')
            else:
                result.append(cleaned_node_id)
        # No :: separator, just a path - make it relative if absolute
        else:
            path_obj = Path(cleaned_node_id)
            if path_obj.is_absolute() and path_obj.is_relative_to(rootdir):
                relative_path = path_obj.relative_to(rootdir)
                result.append(relative_path.as_posix())
            else:
                result.append(cleaned_node_id)
    return result


def _collect_coverage(gremlin_session: GremlinSession, rootdir: Path) -> None:
    """Collect coverage data by running tests with coverage.py.

    Runs the test suite with coverage collection using dynamic contexts to
    build a coverage map that maps source lines to the tests that execute them.

    Args:
        gremlin_session: The current gremlin session.
        rootdir: Root directory of the project.
    """
    collector = CoverageCollector()
    gremlin_session.coverage_collector = collector

    test_node_ids = list(gremlin_session.test_node_ids.values())

    # Make node IDs relative to rootdir for subprocess execution
    # Pytest node IDs can be absolute paths in some contexts (e.g., pytester)
    relative_node_ids = _make_node_ids_relative(test_node_ids, rootdir)

    coverage_data = _run_tests_with_coverage(relative_node_ids, rootdir)

    if not coverage_data:
        warnings.warn(
            'Coverage collection returned no data. '
            'If you have --cov in pytest addopts, this may interfere with '
            "gremlins' coverage-guided test selection. "
            'See https://github.com/mikelane/pytest-gremlins/issues/113',
            stacklevel=1,
        )

    gremlin_paths_map: dict[str, str] = {}
    for gremlin in gremlin_session.gremlins:
        abs_path = str(Path(gremlin.file_path).resolve())
        gremlin_paths_map[abs_path] = gremlin.file_path

    for test_name, file_coverage in coverage_data.items():
        normalized_coverage: dict[str, list[int]] = {}
        for file_path, lines in file_coverage.items():
            # Coverage.py stores paths relative to rootdir, so resolve them accordingly
            coverage_path = Path(file_path)
            if coverage_path.is_absolute():
                abs_path = str(coverage_path.resolve())
            else:
                abs_path = str((rootdir / coverage_path).resolve())
            if abs_path in gremlin_paths_map:
                gremlin_path = gremlin_paths_map[abs_path]
                if gremlin_path not in normalized_coverage:
                    normalized_coverage[gremlin_path] = []
                normalized_coverage[gremlin_path].extend(lines)

        if normalized_coverage:
            collector.record_test_coverage(test_name, normalized_coverage)

    gremlin_session.test_selector = TestSelector(collector.coverage_map)
    gremlin_session.prioritized_selector = PrioritizedSelector(collector.coverage_map)


def _run_tests_with_coverage(
    test_node_ids: list[str],
    rootdir: Path,
) -> dict[str, dict[str, list[int]]]:
    """Run all tests with coverage collection using dynamic contexts.

    Uses coverage.py's dynamic_context feature to track which lines are
    covered by which test. This is much faster than running each test
    separately.

    Args:
        test_node_ids: List of pytest node IDs to run.
        rootdir: Root directory of the project.

    Returns:
        Dict mapping test names to their coverage data (file path -> lines).
    """
    coverage_db_path = rootdir / '.coverage'
    coverage_db_path.unlink(missing_ok=True)

    coveragerc_path = rootdir / '.coveragerc.gremlins'
    coveragerc_content = """[run]
source = .
dynamic_context = test_function
"""
    coveragerc_path.write_text(coveragerc_content)

    cmd = [
        sys.executable,
        '-m',
        'coverage',
        'run',
        f'--rcfile={coveragerc_path}',
        '-m',
        'pytest',
        '-o',
        'addopts=',
        *test_node_ids,
        '--tb=no',
        '-q',
    ]

    try:
        subprocess.run(  # Intentional: runs pytest test commands
            cmd,
            cwd=str(rootdir),
            capture_output=True,
            timeout=120,
            check=False,
        )
    except subprocess.TimeoutExpired:  # pragma: no cover
        coveragerc_path.unlink(missing_ok=True)
        return {}

    result: dict[str, dict[str, list[int]]] = {}

    try:
        if not coverage_db_path.exists():  # pragma: no cover
            coveragerc_path.unlink(missing_ok=True)
            return {}

        conn = sqlite3.connect(str(coverage_db_path))
        cursor = conn.cursor()

        cursor.execute('SELECT id, context FROM context WHERE context != ""')
        contexts = {row[0]: row[1] for row in cursor.fetchall()}

        cursor.execute('SELECT id, path FROM file')
        files = {row[0]: row[1] for row in cursor.fetchall()}

        cursor.execute('SELECT file_id, context_id, numbits FROM line_bits')
        for file_id, context_id, numbits in cursor.fetchall():
            if context_id not in contexts or file_id not in files:
                continue

            context = contexts[context_id]
            test_name = _extract_test_name_from_context(context)

            file_path = files[file_id]

            lines = _decode_numbits(numbits)

            if test_name not in result:
                result[test_name] = {}
            if file_path not in result[test_name]:
                result[test_name][file_path] = []
            result[test_name][file_path].extend(lines)

        conn.close()

    except (sqlite3.Error, OSError) as exc:  # pragma: no cover
        logger.warning('Failed to read coverage data: %s', exc)
    finally:
        try:
            coverage_db_path.unlink(missing_ok=True)
            coveragerc_path.unlink(missing_ok=True)
        except OSError as exc:  # pragma: no cover
            logger.debug('Failed to clean up coverage files: %s', exc)

    return result


def _decode_numbits(numbits: bytes) -> list[int]:
    """Decode coverage.py's numbits format to a list of line numbers.

    The numbits format is a byte array where each bit represents a line number.
    Bit N being set means line N is covered.

    Args:
        numbits: The compressed line number data from coverage.py.

    Returns:
        List of line numbers that were covered.
    """
    return [
        byte_idx * 8 + bit_idx
        for byte_idx, byte_val in enumerate(numbits)
        for bit_idx in range(8)
        if byte_val & (1 << bit_idx)
    ]


def _run_batch_mutation_testing(  # pragma: no cover  # noqa: C901
    session: pytest.Session,
    gremlin_session: GremlinSession,
) -> list[GremlinResult]:
    """Run mutation testing using batch execution for reduced overhead.

    Batch execution reduces subprocess overhead by testing multiple gremlins
    in each subprocess call. Instead of 1 subprocess per gremlin (with ~600ms
    overhead each), we batch gremlins and spawn fewer subprocesses.

    Args:
        session: The pytest session.
        gremlin_session: The current gremlin session.

    Returns:
        List of results for each gremlin.
    """
    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]
    base_test_command = _build_test_command(gremlin_session.instrumented_dir)
    gremlins = gremlin_session.gremlins

    # Build gremlin -> test mapping for filtering (prioritized order)
    gremlin_tests: dict[str, list[str]] = {}
    for gremlin in gremlins:
        selected_tests = _select_tests_for_gremlin_prioritized(gremlin, gremlin_session)
        gremlin_tests[gremlin.gremlin_id] = selected_tests

    # Check cache and separate cached from uncached
    cached_results: list[GremlinResult] = []
    uncached_gremlins: list[Gremlin] = []

    for gremlin in gremlins:
        selected_tests = gremlin_tests[gremlin.gremlin_id]
        cached_result = _check_cache_for_gremlin(gremlin, selected_tests, gremlin_session)
        if cached_result is not None:
            gremlin_session.cache_hits += 1
            cached_results.append(cached_result)
        else:
            if gremlin_session.cache_enabled:
                gremlin_session.cache_misses += 1
            uncached_gremlins.append(gremlin)

    # Report cache stats
    if cached_results:
        print(f'pytest-gremlins: {len(cached_results)} gremlins from cache, {len(uncached_gremlins)} to test')

    if not uncached_gremlins:
        return cached_results

    # Map gremlin_id -> Gremlin for result reconstruction
    gremlin_by_id = {g.gremlin_id: g for g in uncached_gremlins}

    # Prepare instrumented dir path for env var
    instrumented_dir_str = str(gremlin_session.instrumented_dir) if gremlin_session.instrumented_dir else None

    batch_size = gremlin_session.batch_size
    num_batches = (len(uncached_gremlins) + batch_size - 1) // batch_size
    print(
        f'pytest-gremlins: Starting batch execution '
        f'({len(uncached_gremlins)} gremlins, {num_batches} batches of {batch_size})'
    )

    gremlins_to_test = [g.gremlin_id for g in uncached_gremlins]

    # For batch execution, we need a unified test command that will work for all gremlins
    # This means running all tests that cover ANY of the gremlins in the batch
    # We preserve prioritization order: tests appearing first in more lists are more specific
    # TODO: optimize by grouping gremlins by their covering tests
    seen_tests: set[str] = set()
    all_covering_tests: list[str] = []
    for gremlin_id in gremlins_to_test:
        for test in gremlin_tests[gremlin_id]:
            if test not in seen_tests:
                seen_tests.add(test)
                all_covering_tests.append(test)

    test_command = _build_filtered_test_command(
        base_test_command,
        all_covering_tests,
        gremlin_session,
    )

    # Execute batches
    executor = BatchExecutor(
        batch_size=batch_size,
        max_workers=gremlin_session.parallel_workers,
        timeout=30,
    )

    worker_results = executor.execute(
        gremlin_ids=gremlins_to_test,
        test_command=test_command,
        rootdir=str(rootdir),
        instrumented_dir=instrumented_dir_str,
        env_vars={},
    )

    # Convert WorkerResults to GremlinResults
    results: list[GremlinResult] = list(cached_results)

    for worker_result in worker_results:
        gremlin_id = worker_result.gremlin_id
        if gremlin_id not in gremlin_by_id:
            continue

        gremlin = gremlin_by_id[gremlin_id]
        gremlin_result = GremlinResult(
            gremlin=gremlin,
            status=worker_result.status,
            killing_test=worker_result.killing_test,
            execution_time_ms=worker_result.execution_time_ms,
        )
        results.append(gremlin_result)

        # Cache the result
        selected_tests = gremlin_tests[gremlin_id]
        _cache_gremlin_result(gremlin, selected_tests, gremlin_result, gremlin_session)

    return results


def _run_parallel_mutation_testing(  # pragma: no cover  # noqa: C901
    session: pytest.Session,
    gremlin_session: GremlinSession,
) -> list[GremlinResult]:
    """Run mutation testing in parallel across multiple workers.

    Uses a worker pool to execute gremlin tests concurrently for faster
    results on multi-core machines.

    Args:
        session: The pytest session.
        gremlin_session: The current gremlin session.

    Returns:
        List of results for each gremlin.
    """
    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]
    base_test_command = _build_test_command(gremlin_session.instrumented_dir)
    gremlins = gremlin_session.gremlins

    # Build gremlin -> test mapping for filtering (prioritized order)
    gremlin_tests: dict[str, list[str]] = {}
    for gremlin in gremlins:
        selected_tests = _select_tests_for_gremlin_prioritized(gremlin, gremlin_session)
        gremlin_tests[gremlin.gremlin_id] = selected_tests

    # Check cache and separate cached from uncached
    cached_results: list[GremlinResult] = []
    uncached_gremlins: list[Gremlin] = []

    for gremlin in gremlins:
        selected_tests = gremlin_tests[gremlin.gremlin_id]
        cached_result = _check_cache_for_gremlin(gremlin, selected_tests, gremlin_session)
        if cached_result is not None:
            gremlin_session.cache_hits += 1
            cached_results.append(cached_result)
        else:
            if gremlin_session.cache_enabled:
                gremlin_session.cache_misses += 1
            uncached_gremlins.append(gremlin)

    # Report cache stats
    if cached_results:
        print(f'pytest-gremlins: {len(cached_results)} gremlins from cache, {len(uncached_gremlins)} to test')

    if not uncached_gremlins:
        return cached_results

    # Run uncached gremlins in parallel
    aggregator = ResultAggregator(total_gremlins=len(uncached_gremlins))

    # Prepare instrumented dir path for env var
    instrumented_dir_str = str(gremlin_session.instrumented_dir) if gremlin_session.instrumented_dir else None

    # Map gremlin_id -> Gremlin for result reconstruction
    gremlin_by_id = {g.gremlin_id: g for g in uncached_gremlins}

    print(f'pytest-gremlins: Starting parallel execution with {gremlin_session.parallel_workers or "auto"} workers')

    with WorkerPool(
        max_workers=gremlin_session.parallel_workers,
        timeout=30,
    ) as pool:
        # Submit all gremlins
        futures = {}
        for gremlin in uncached_gremlins:
            selected_tests = gremlin_tests[gremlin.gremlin_id]

            test_command = _build_filtered_test_command(
                base_test_command,
                selected_tests,
                gremlin_session,
            )

            future = pool.submit(
                gremlin_id=gremlin.gremlin_id,
                test_command=test_command,
                rootdir=str(rootdir),
                instrumented_dir=instrumented_dir_str,
                env_vars={},
            )
            futures[future] = gremlin.gremlin_id

        # Collect results as they complete
        for future in as_completed(futures):
            gremlin_id = futures[future]
            try:
                worker_result = future.result()
                aggregator.add_result(worker_result)
            except Exception as e:
                aggregator.add_error(gremlin_id, e)

            # Progress reporting
            completed, total = aggregator.get_progress()
            print(f'\rpytest-gremlins: Progress {completed}/{total}', end='', flush=True)

    print()  # New line after progress

    # Convert WorkerResults to GremlinResults and cache them
    results: list[GremlinResult] = list(cached_results)
    for worker_result in aggregator.get_results():
        gremlin_id = worker_result.gremlin_id
        if gremlin_id not in gremlin_by_id:
            continue

        gremlin = gremlin_by_id[gremlin_id]
        gremlin_result = GremlinResult(
            gremlin=gremlin,
            status=worker_result.status,
            killing_test=worker_result.killing_test,
            execution_time_ms=worker_result.execution_time_ms,
        )
        results.append(gremlin_result)

        # Cache the result
        selected_tests = gremlin_tests[gremlin_id]
        _cache_gremlin_result(gremlin, selected_tests, gremlin_result, gremlin_session)

    return results


def _run_mutation_testing(
    session: pytest.Session,
    gremlin_session: GremlinSession,
) -> list[GremlinResult]:
    """Run mutation testing for all gremlins.

    Uses incremental caching when enabled to skip unchanged gremlins.

    Args:
        session: The pytest session.
        gremlin_session: The current gremlin session.

    Returns:
        List of results for each gremlin.
    """
    results: list[GremlinResult] = []
    rootdir = Path(session.config.rootdir)  # type: ignore[attr-defined]
    base_test_command = _build_test_command(gremlin_session.instrumented_dir)

    for i, gremlin in enumerate(gremlin_session.gremlins, 1):
        selected_tests = _select_tests_for_gremlin_prioritized(gremlin, gremlin_session)
        test_count = len(selected_tests)
        total = gremlin_session.total_tests

        # Check cache for existing result
        cached_result = _check_cache_for_gremlin(gremlin, selected_tests, gremlin_session)
        if cached_result is not None:
            gremlin_session.cache_hits += 1
            _report_gremlin_cache_hit(i, len(gremlin_session.gremlins), gremlin)
            results.append(cached_result)
            continue

        if gremlin_session.cache_enabled:
            gremlin_session.cache_misses += 1
            _report_gremlin_cache_miss(i, len(gremlin_session.gremlins), gremlin)

        _report_gremlin_progress(i, len(gremlin_session.gremlins), gremlin, test_count, total)

        test_command = _build_filtered_test_command(
            base_test_command,
            selected_tests,
            gremlin_session,
        )
        result = _test_gremlin(
            gremlin,
            test_command,
            rootdir,
            gremlin_session.instrumented_dir,
        )

        # Cache the result for next run
        _cache_gremlin_result(gremlin, selected_tests, result, gremlin_session)

        results.append(result)

    return results


def _build_test_hashes_for_gremlin(
    selected_tests: Sequence[str],
    gremlin_session: GremlinSession,
) -> dict[str, str]:
    """Build test hashes for the tests that cover a gremlin.

    Maps test names to their file content hashes. Test names can be in different
    formats (simple function, module.function, TestClass.method), so this function
    tries variations to find the corresponding node ID and file hash.

    Args:
        selected_tests: Sequence of test names that cover the gremlin.
        gremlin_session: The current gremlin session with test metadata.

    Returns:
        Dictionary mapping test names to their file content hashes.
    """
    test_hashes: dict[str, str] = {}
    for test_name in selected_tests:
        node_id = gremlin_session.test_node_ids.get(test_name, '')
        if not node_id:
            simple_name = test_name.split('.')[-1]
            node_id = gremlin_session.test_node_ids.get(simple_name, '')

        if '::' in node_id:
            test_file = node_id.split('::')[0]
            for file_path, file_hash in gremlin_session.test_hashes.items():
                if file_path.endswith(test_file) or test_file in file_path:
                    test_hashes[test_name] = file_hash
                    break

    return test_hashes


def _check_cache_for_gremlin(
    gremlin: Gremlin,
    selected_tests: Sequence[str],
    gremlin_session: GremlinSession,
) -> GremlinResult | None:
    """Check cache for existing result for this gremlin.

    Args:
        gremlin: The gremlin to check cache for.
        selected_tests: Sequence of tests that cover this gremlin.
        gremlin_session: The current gremlin session.

    Returns:
        Cached GremlinResult if found and valid, None otherwise.
    """
    if not gremlin_session.cache_enabled or gremlin_session.cache is None:
        return None

    source_hash = gremlin_session.source_hashes.get(gremlin.file_path, '')
    if not source_hash:
        return None

    test_hashes = _build_test_hashes_for_gremlin(selected_tests, gremlin_session)

    cached = gremlin_session.cache.get_cached_result(
        gremlin_id=gremlin.gremlin_id,
        source_hash=source_hash,
        test_hashes=test_hashes,
    )

    if cached is None:
        return None

    status = GremlinResultStatus(cached['status'])
    return GremlinResult(
        gremlin=gremlin,
        status=status,
        killing_test=cached.get('killing_test'),
        execution_time_ms=cached.get('execution_time_ms'),
    )


def _cache_gremlin_result(
    gremlin: Gremlin,
    selected_tests: Sequence[str],
    result: GremlinResult,
    gremlin_session: GremlinSession,
) -> None:
    """Cache the result for a gremlin.

    Args:
        gremlin: The gremlin that was tested.
        selected_tests: Sequence of tests that covered this gremlin.
        result: The result to cache.
        gremlin_session: The current gremlin session.
    """
    if not gremlin_session.cache_enabled or gremlin_session.cache is None:
        return

    source_hash = gremlin_session.source_hashes.get(gremlin.file_path, '')
    if not source_hash:
        return

    test_hashes = _build_test_hashes_for_gremlin(selected_tests, gremlin_session)

    # Use deferred writes to batch commits for better performance
    gremlin_session.cache.cache_result_deferred(
        gremlin_id=gremlin.gremlin_id,
        source_hash=source_hash,
        test_hashes=test_hashes,
        result={
            'status': result.status.value,
            'killing_test': result.killing_test,
            'execution_time_ms': result.execution_time_ms,
        },
    )


def _report_gremlin_cache_hit(
    index: int,
    total_gremlins: int,
    gremlin: Gremlin,
) -> None:
    """Report a cache hit for a gremlin.

    Args:
        index: Current gremlin index (1-based).
        total_gremlins: Total number of gremlins.
        gremlin: The gremlin that had a cache hit.
    """
    prefix = f'Gremlin {index}/{total_gremlins}: {gremlin.gremlin_id}'
    print(f'{prefix} - cache hit (skipping)')


def _report_gremlin_cache_miss(
    index: int,
    total_gremlins: int,
    gremlin: Gremlin,
) -> None:
    """Report a cache miss for a gremlin.

    Args:
        index: Current gremlin index (1-based).
        total_gremlins: Total number of gremlins.
        gremlin: The gremlin that had a cache miss.
    """
    prefix = f'Gremlin {index}/{total_gremlins}: {gremlin.gremlin_id}'
    print(f'{prefix} - cache miss')


def _select_tests_for_gremlin_prioritized(
    gremlin: Gremlin,
    gremlin_session: GremlinSession,
) -> list[str]:
    """Select tests for a gremlin, ordered by specificity (most specific first).

    Uses the PrioritizedSelector to return tests in an order that maximizes
    the chance of catching the mutation quickly. Tests covering fewer lines
    are considered more specific and run first.

    When coverage-guided selection finds no covering tests, falls back to
    running all tests. This handles module-level code (class attribute defaults,
    module constants) that executes at import time before any test function
    runs. Coverage.py records these lines under the empty context, which isn't
    associated with any specific test.

    Args:
        gremlin: The gremlin to select tests for.
        gremlin_session: The current gremlin session.

    Returns:
        List of test names ordered by specificity (most specific first).
    """
    if gremlin_session.prioritized_selector is None:
        return list(gremlin_session.test_node_ids.keys())

    selected = gremlin_session.prioritized_selector.select_tests_prioritized(gremlin)
    if not selected:
        return list(gremlin_session.test_node_ids.keys())

    return selected


def _report_gremlin_progress(
    index: int,
    total_gremlins: int,
    gremlin: Gremlin,
    test_count: int,
    total_tests: int,
) -> None:
    """Report progress for a gremlin being tested.

    Args:
        index: Current gremlin index (1-based).
        total_gremlins: Total number of gremlins.
        gremlin: The gremlin being tested.
        test_count: Number of tests selected for this gremlin.
        total_tests: Total number of tests in the suite.
    """
    prefix = f'Gremlin {index}/{total_gremlins}: {gremlin.gremlin_id}'
    print(f'{prefix} - running {test_count}/{total_tests} tests')


def _build_filtered_test_command(
    base_command: list[str],
    selected_tests: Sequence[str],
    gremlin_session: GremlinSession,
) -> list[str]:
    """Build a test command that runs only the selected tests.

    The order of selected_tests is preserved in the resulting command,
    enabling prioritized test execution (most specific tests first).

    Args:
        base_command: The base test command.
        selected_tests: Sequence of test names to run (order is preserved).
        gremlin_session: The current gremlin session.

    Returns:
        Command list with test node IDs appended in the same order.
    """
    command = list(base_command)

    node_ids = [
        gremlin_session.test_node_ids[test_name]
        for test_name in selected_tests
        if test_name in gremlin_session.test_node_ids
    ]

    if node_ids:
        command.extend(node_ids)

    return command


def _build_test_command(instrumented_dir: Path | None) -> list[str]:
    """Build the command to run tests.

    If an instrumented directory is provided, uses the bootstrap script
    to register import hooks before running pytest. Otherwise, runs
    pytest directly.

    Args:
        instrumented_dir: Directory containing bootstrap infrastructure, or None.

    Returns:
        Command list to run tests.
    """
    if instrumented_dir is not None:
        bootstrap_script = instrumented_dir / 'gremlin_bootstrap.py'
        return [
            sys.executable,
            str(bootstrap_script),
            '-x',
            '--tb=no',
            '-q',
            '-o',
            'addopts=',
            '--no-cov',
        ]
    return [
        sys.executable,
        '-m',
        'pytest',
        '-x',
        '--tb=no',
        '-q',
        '-o',
        'addopts=',
        '--no-cov',
    ]


def _test_gremlin(
    gremlin: Gremlin,
    test_command: list[str],
    rootdir: Path,
    instrumented_dir: Path | None,
) -> GremlinResult:
    """Test a single gremlin by running tests with the mutation active.

    The subprocess runs via a bootstrap script that registers import hooks
    to intercept module imports and provide instrumented code. The active
    gremlin ID is passed via the ACTIVE_GREMLIN environment variable.

    Args:
        gremlin: The gremlin to test.
        test_command: Command to run tests.
        rootdir: Root directory of the project.
        instrumented_dir: Directory containing bootstrap infrastructure.

    Returns:
        Result of testing the gremlin.
    """
    env = os.environ.copy()
    env[ACTIVE_GREMLIN_ENV_VAR] = gremlin.gremlin_id

    if instrumented_dir is not None:
        sources_file = instrumented_dir / 'sources.json'
        env[GREMLIN_SOURCES_ENV_VAR] = str(sources_file)

    try:
        result = subprocess.run(  # Intentional: runs pytest test commands
            test_command,
            cwd=str(rootdir),
            env=env,
            capture_output=True,
            timeout=30,
            check=False,
        )

        # pytest uses specific exit codes. Only exit code 1 means tests ran
        # and failed (i.e. the mutation was caught). Other non-zero exit codes
        # indicate errors (collection/import/internal) and should not be counted
        # as zapped.
        if result.returncode == 0:
            return GremlinResult(
                gremlin=gremlin,
                status=GremlinResultStatus.SURVIVED,
            )
        if result.returncode == 1:
            return GremlinResult(
                gremlin=gremlin,
                status=GremlinResultStatus.ZAPPED,
                killing_test='unknown',
            )
        return GremlinResult(
            gremlin=gremlin,
            status=GremlinResultStatus.ERROR,
        )
    except subprocess.TimeoutExpired:  # pragma: no cover
        return GremlinResult(
            gremlin=gremlin,
            status=GremlinResultStatus.TIMEOUT,
        )
    except Exception as exc:  # pragma: no cover
        logger.warning('Error testing gremlin %s: %s', gremlin.gremlin_id, exc)
        return GremlinResult(
            gremlin=gremlin,
            status=GremlinResultStatus.ERROR,
        )


def _write_html_report(score: MutationScore, rootdir: Path) -> Path:
    """Write HTML report to file.

    Args:
        score: The MutationScore to write.
        rootdir: Root directory of the project.

    Returns:
        Path to the written HTML report.
    """
    reporter = HtmlReporter()
    output_path = rootdir / 'gremlin-report.html'
    reporter.write_report(score, output_path)
    return output_path


def pytest_terminal_summary(  # noqa: C901, PLR0912, PLR0915
    terminalreporter: pytest.TerminalReporter,
    exitstatus: int,  # noqa: ARG001
    config: pytest.Config,
) -> None:
    """Add mutation testing results to terminal output."""
    gremlin_session = _get_session()
    if gremlin_session is None or not gremlin_session.enabled:
        return

    if not gremlin_session.gremlins:
        terminalreporter.write_sep('=', 'pytest-gremlins mutation report')
        terminalreporter.write_line('')
        if gremlin_session.target_paths:
            terminalreporter.write_line('No gremlins found in source code. Searched paths:')
            for searched_path in gremlin_session.target_paths:
                terminalreporter.write_line(f'  - {searched_path}')
        else:
            terminalreporter.write_line('No gremlins found: no source paths were discovered.')
            terminalreporter.write_line('')
            terminalreporter.write_line('pytest-gremlins looks for source code in this order:')
            terminalreporter.write_line('  1. --gremlin-targets CLI option')
            terminalreporter.write_line('  2. [tool.pytest-gremlins] paths in pyproject.toml')
            terminalreporter.write_line('  3. [tool.setuptools] package config in pyproject.toml')
            terminalreporter.write_line('  4. src/ directory')
            terminalreporter.write_line('')
            terminalreporter.write_line(
                'If your source code is elsewhere, use: pytest --gremlins --gremlin-targets=your_package'
            )
        terminalreporter.write_line('')
        terminalreporter.write_sep('=', '')
        return

    score = MutationScore.from_results(gremlin_session.results)

    # Write HTML report if requested
    if gremlin_session.report_format == 'html':
        rootdir = Path(config.rootdir)  # type: ignore[attr-defined]
        report_path = _write_html_report(score, rootdir)
        terminalreporter.write_line(f'HTML report written to: {report_path}')

    terminalreporter.write_sep('=', 'pytest-gremlins mutation report')
    terminalreporter.write_line('')

    if score.total == 0:
        terminalreporter.write_line('No gremlins tested.')
    else:
        zapped_pct = round(score.zapped / score.total * 100)
        survived_pct = round(score.survived / score.total * 100)
        timeout_pct = round(score.timeout / score.total * 100)
        error_pct = round(score.error / score.total * 100)

        terminalreporter.write_line(f'Zapped: {score.zapped} gremlins ({zapped_pct}%)')
        terminalreporter.write_line(f'Survived: {score.survived} gremlins ({survived_pct}%)')
        if score.timeout > 0:
            terminalreporter.write_line(f'Timeout: {score.timeout} gremlins ({timeout_pct}%)')
        if score.error > 0:
            terminalreporter.write_line(f'Error: {score.error} gremlins ({error_pct}%)')

        # Show cache statistics if caching was enabled
        if gremlin_session.cache_enabled:
            total_cache = gremlin_session.cache_hits + gremlin_session.cache_misses
            if total_cache > 0:
                hit_rate = round(gremlin_session.cache_hits / total_cache * 100)
                terminalreporter.write_line('')
                terminalreporter.write_line(
                    f'Cache: {gremlin_session.cache_hits} hits, '
                    f'{gremlin_session.cache_misses} misses ({hit_rate}% hit rate)'
                )

        survivors = score.top_survivors(limit=10)
        if survivors:
            terminalreporter.write_line('')
            terminalreporter.write_line('Top surviving gremlins:')
            for result in survivors:
                gremlin = result.gremlin
                location = f'{gremlin.file_path}:{gremlin.line_number}'
                terminalreporter.write_line(f'  {location:<30} {gremlin.description:<20} ({gremlin.operator_name})')

    terminalreporter.write_line('')
    if gremlin_session.report_format != 'html':
        terminalreporter.write_line('Run with --gremlin-report=html for detailed report.')
    terminalreporter.write_sep('=', '')


def pytest_unconfigure(config: pytest.Config) -> None:  # noqa: ARG001
    """Clean up after pytest-gremlins."""
    gremlin_session = _get_session()
    if gremlin_session is not None:
        _cleanup_instrumented_dir(gremlin_session.instrumented_dir)
        # Close the cache to release database connection
        if gremlin_session.cache is not None:
            gremlin_session.cache.close()
    _set_session(None)
