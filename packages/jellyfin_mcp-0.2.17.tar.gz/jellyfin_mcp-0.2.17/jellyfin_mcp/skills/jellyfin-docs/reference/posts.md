[Skip to main content](https://jellyfin.org/posts/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
Recent posts
### 2026
  * [State of the Fin 2026-01-06](https://jellyfin.org/posts/state-of-the-fin-2026-01-06)


### 2025
  * [Jellyfin for Android TV 0.19](https://jellyfin.org/posts/androidtv-v0.19.0)
  * [Jellyfin 10.11.0](https://jellyfin.org/posts/jellyfin-release-10.11.0)
  * [SQLite concurrency and why you should care about it](https://jellyfin.org/posts/SQLite-locking)
  * [Jellyfin for iOS 1.7.0](https://jellyfin.org/posts/ios-v1.7.0)


## [State of the Fin 2026-01-06](https://jellyfin.org/posts/state-of-the-fin-2026-01-06)
January 6, 2026 · 9 min read
[![Bill Thornton](https://avatars.githubusercontent.com/u/3450688?v=4)](https://jellyfin.org/posts/authors/thornbill)
[Bill Thornton](https://jellyfin.org/posts/authors/thornbill)
Core Team, Web and iOS Lead
[](https://github.com/thornbill "GitHub")[](https://fosstodon.org/@thornbill "Mastodon")
Happy New Year and welcome to the State of the Fin! This new blog series will regularly basis highlight the ongoing development of Jellyfin and our official clients. We aim to keep our community informed and engaged, so feel free to share your feedback or thoughts on our progress!
**Tags:**
  * [state-of-the-fin](https://jellyfin.org/posts/tags/state-of-the-fin)


[**Read more**](https://jellyfin.org/posts/state-of-the-fin-2026-01-06)
## [Jellyfin for Android TV 0.19](https://jellyfin.org/posts/androidtv-v0.19.0)
October 28, 2025 · 6 min read
[![Niels van Velzen](https://avatars.githubusercontent.com/u/2305178?v=4)](https://jellyfin.org/posts/authors/nielsvanvelzen)
[Niels van Velzen](https://jellyfin.org/posts/authors/nielsvanvelzen)
Core Team, Android Lead
[](https://github.com/nielsvanvelzen "GitHub")[](https://mastodon.social/@hetisniels "Mastodon")
From refreshed user interface elements to playback improvements, there are many changes across the board in the latest update of Jellyfin for Android TV.
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [android-tv](https://jellyfin.org/posts/tags/android-tv)


[**Read more**](https://jellyfin.org/posts/androidtv-v0.19.0)
## [Jellyfin 10.11.0](https://jellyfin.org/posts/jellyfin-release-10.11.0)
October 19, 2025 · 15 min read
[![Joshua Boniface](https://avatars.githubusercontent.com/u/4031396?v=4)](https://github.com/joshuaboniface)
[Joshua Boniface](https://github.com/joshuaboniface)
Project Leader
[](https://github.com/joshuaboniface "GitHub")[](https://social.bonifacelabs.ca/@joshuaboniface "Mastodon")[](https://reddit.com/u/djbon2112 "reddit")
We are pleased to bring you Jellyfin 10.11.0, our new stable release. This is probably one of, if not the, biggest and most impactful releases we've done yet, with some massive backend changes to improve performance and long-term expandability and maintainability. This release has been a long time coming, with over 6 months of development and another 6 months of RC testing, throwing our planned 6-month release schedule completely out of whack, but we definitely think the results are worth it - both for users right now, and for the long-term health of the project.
If you just want a quick summary of what you **need to know** (and you **DO** need to know!) to get your system upgraded and running, please read on to the "TL; DR" section just below, or keep reading for a full explanation of all the major features and improvements in Jellyfin 10.11.0! You can also view full changelogs on the [server](https://github.com/jellyfin/jellyfin/releases/tag/v10.11.0) and [web](https://github.com/jellyfin/jellyfin-web/releases/tag/v10.11.0) GitHub releases.
- Joshua
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [server](https://jellyfin.org/posts/tags/server)


[**Read more**](https://jellyfin.org/posts/jellyfin-release-10.11.0)
## [SQLite concurrency and why you should care about it](https://jellyfin.org/posts/SQLite-locking)
October 4, 2025 · 8 min read
[![Jean-Pierre Bachmann](https://avatars.githubusercontent.com/u/6794763?v=4)](https://github.com/JPVenson)
[Jean-Pierre Bachmann](https://github.com/JPVenson)
Server Team
SQLite is a powerful database engine, but due to its design, it has limitations that should not be overlooked.
Jellyfin has used a SQLite-based database for storing most of its data for years, but it has also encountered issues on many systems. In this blog post, I will explain how we address these limitations and how developers using SQLite can apply the same solutions.
This will be a technical blog post intended for developers and everyone wanting to learn about concurrency.
Also Jellyfin's implementation of locking for SQLite should be fairly easy to be implemented into another EF Core application if you are facing the same issue.
- JPVenson
**Tags:**
  * [SQLite](https://jellyfin.org/posts/tags/sq-lite)
  * [jellyfin](https://jellyfin.org/posts/tags/jellyfin)
  * [locked-database](https://jellyfin.org/posts/tags/locked-database)


[**Read more**](https://jellyfin.org/posts/SQLite-locking)
## [Jellyfin for iOS 1.7.0](https://jellyfin.org/posts/ios-v1.7.0)
September 30, 2025 · 4 min read
[![Bill Thornton](https://avatars.githubusercontent.com/u/3450688?v=4)](https://jellyfin.org/posts/authors/thornbill)
[Bill Thornton](https://jellyfin.org/posts/authors/thornbill)
Core Team, Web and iOS Lead
[](https://github.com/thornbill "GitHub")[](https://fosstodon.org/@thornbill "Mastodon")
Download support is (finally) coming to Jellyfin for iOS!
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [ios](https://jellyfin.org/posts/tags/ios)


[**Read more**](https://jellyfin.org/posts/ios-v1.7.0)
## [Jellyfin for Xbox 0.9.0](https://jellyfin.org/posts/xbox-v0.9.0)
April 15, 2025 · 2 min read
[![Jean-Pierre Bachmann](https://avatars.githubusercontent.com/u/6794763?v=4)](https://github.com/JPVenson)
[Jean-Pierre Bachmann](https://github.com/JPVenson)
Server Team
Better late then never. The Xbox app for Jellyfin now has a new maintainer and its first release in 5 years.
- JPVenson
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [xbox](https://jellyfin.org/posts/tags/xbox)
  * [uwp](https://jellyfin.org/posts/tags/uwp)


[**Read more**](https://jellyfin.org/posts/xbox-v0.9.0)
## [Roku Version 3.0.0](https://jellyfin.org/posts/roku-300)
March 28, 2025 · 7 min read
[![1hitsong](https://avatars.githubusercontent.com/u/3330318?v=4)](https://github.com/1hitsong)
[1hitsong](https://github.com/1hitsong)
Roku Team
You know the feeling when the assignment was to write a 500 word paper, but you have so much to cover that your first draft is 25,000 words?
...what? Just me?
That's exactly how I feel attempting to condense all the new features, bug fixes, refreshed UI components, and improvements found in Jellyfin for Roku 3.0.0 into a single blog post.
But I'll do my best, here goes.
- 1hitsong
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [roku](https://jellyfin.org/posts/tags/roku)


[**Read more**](https://jellyfin.org/posts/roku-300)
## [Jellyfin for iOS 1.6.0](https://jellyfin.org/posts/ios-v1.6.0)
February 28, 2025 · 5 min read
[![Bill Thornton](https://avatars.githubusercontent.com/u/3450688?v=4)](https://jellyfin.org/posts/authors/thornbill)
[Bill Thornton](https://jellyfin.org/posts/authors/thornbill)
Core Team, Web and iOS Lead
[](https://github.com/thornbill "GitHub")[](https://fosstodon.org/@thornbill "Mastodon")
Jellyfin for iOS is back with the first release in nearly 3 years!
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [ios](https://jellyfin.org/posts/tags/ios)


[**Read more**](https://jellyfin.org/posts/ios-v1.6.0)
## [EFCore refactoring is here](https://jellyfin.org/posts/efcore-refactoring)
January 25, 2025 · 3 min read
[![Jean-Pierre Bachmann](https://avatars.githubusercontent.com/u/6794763?v=4)](https://github.com/JPVenson)
[Jean-Pierre Bachmann](https://github.com/JPVenson)
Server Team
EFCore has landed in unstable, and this will have consequences.
We have finally reached our first milestone in cleaning up the legacy database access code. This means that all SQL builders that targeted SQLite directly have been removed from code. This marks the first step towards a completely new database design, but we now need to take a quick look ahead and see what's next.
Unstable builds will be temporarily turned off this week, skipping the 20250127 unstable to provide a full week of in-master testing, and will be re-enabled for the 20250203 unstable next week, so ensure you have backups ready this week if you run unstable builds.
Otherwise please read on to see what exactly that means and what the future brings.
- JPVenson
**Tags:**
  * [unstable](https://jellyfin.org/posts/tags/unstable)
  * [warning](https://jellyfin.org/posts/tags/warning)
  * [efcore](https://jellyfin.org/posts/tags/efcore)


[**Read more**](https://jellyfin.org/posts/efcore-refactoring)
## [Jellyfin for Android TV 0.18](https://jellyfin.org/posts/androidtv-v0.18.0)
November 30, 2024 · 6 min read
[![Niels van Velzen](https://avatars.githubusercontent.com/u/2305178?v=4)](https://jellyfin.org/posts/authors/nielsvanvelzen)
[Niels van Velzen](https://jellyfin.org/posts/authors/nielsvanvelzen)
Core Team, Android Lead
[](https://github.com/nielsvanvelzen "GitHub")[](https://mastodon.social/@hetisniels "Mastodon")
Version 0.18 of our Jellyfin for Android TV app is ready! Exciting features like lyrics and media segments are now available, along with significant improvements to subtitles and more.
**Tags:**
  * [release](https://jellyfin.org/posts/tags/release)
  * [android-tv](https://jellyfin.org/posts/tags/android-tv)


[**Read more**](https://jellyfin.org/posts/androidtv-v0.18.0)
[ Older entries](https://jellyfin.org/posts/page/2)
[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
