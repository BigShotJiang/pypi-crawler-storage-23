[Skip to main content](https://jellyfin.org/docs/general/installation/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
  * [Introduction](https://jellyfin.org/docs/)
  * [Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Quick Start](https://jellyfin.org/docs/general/quick-start)
  * [Installation](https://jellyfin.org/docs/general/installation/)
    * [Windows](https://jellyfin.org/docs/general/installation/windows)
    * [macOS](https://jellyfin.org/docs/general/installation/macos)
    * [Linux](https://jellyfin.org/docs/general/installation/linux)
    * [Container](https://jellyfin.org/docs/general/installation/container)
    * [Advanced Installation](https://jellyfin.org/docs/general/installation/)
  * [Post-Install Setup](https://jellyfin.org/docs/general/installation/)
  * [Administration](https://jellyfin.org/docs/general/installation/)
  * [Server Guide](https://jellyfin.org/docs/general/installation/)
  * [Clients](https://jellyfin.org/docs/general/clients/)
  * [About Jellyfin](https://jellyfin.org/docs/general/about)
  * [Community Standards](https://jellyfin.org/docs/general/community-standards/)
  * [FAQ](https://jellyfin.org/docs/general/faq)
  * [Contributing](https://jellyfin.org/docs/general/contributing/)
  * [Style Guides](https://jellyfin.org/docs/general/style-guides/)
  * [Testing](https://jellyfin.org/docs/general/testing/)
  * [API Documentation](https://api.jellyfin.org)


  * [](https://jellyfin.org/)
  * Installation


# Installation
The Jellyfin project and its contributors offer a number of pre-built binary packages to assist in getting Jellyfin up and running quickly on multiple systems.
[FreeBSD](https://www.freebsd.org/) and its derivatives, such as [TrueNAS CORE](https://www.truenas.com/truenas-core/), are **NOT** supported by Jellyfin due to .NET officially not being compatible with these platforms.
Even though there are builds available online for these platforms, they are unofficial and from [a separate project](https://github.com/Thefrank/jellyfin-server-freebsd). If you do encounter issues on these platforms, please ask for support in their respective support channels first.
[TrueNAS SCALE](https://www.truenas.com/truenas-scale/) is based on Linux and therefore officially supported. Please install the Jellyfin app from its app repository. This app is not officially maintained by the Jellyfin team, therefore please use the TrueNAS support channels for help first.
For info on selecting hardware for a Jellyfin server, please refer to the [Hardware Selection Guide](https://jellyfin.org/docs/general/administration/hardware-selection)
  * [Windows](https://jellyfin.org/docs/general/installation/windows)
  * [macOS](https://jellyfin.org/docs/general/installation/macos)
  * [Debian / Ubuntu](https://jellyfin.org/docs/general/installation/linux#debian--ubuntu-and-derivatives)
  * [Other Linux Distributions](https://jellyfin.org/docs/general/installation/linux#other-distributions)
  * [Docker / Kubernetes / Podman](https://jellyfin.org/docs/general/installation/container)
  * [Synology](https://jellyfin.org/docs/general/installation/advanced/synology)
  * [TrueNAS SCALE](https://jellyfin.org/docs/general/installation/advanced/truenas)
  * [Generic Linux](https://jellyfin.org/docs/general/installation/advanced/manual#portable-linux-install)
  * [Building from source](https://jellyfin.org/docs/general/installation/advanced/source).


[](https://github.com/jellyfin/jellyfin.org/edit/master/docs/general/installation/index.mdx)
[Previous Quick Start](https://jellyfin.org/docs/general/quick-start)[Next Windows](https://jellyfin.org/docs/general/installation/windows)
[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
