[Skip to main content](https://jellyfin.org/contact/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
# Contact
## Chat
### Matrix
Element
We primarily use [Element](https://element.io/get-started) to access the [Matrix](https://www.matrix.org) network. Find all the official rooms in the Jellyfin Space!
#### General Rooms
  * [#jellyfin](https://matrix.to/#/#jellyfin:matrix.org)
  * [#jellyfin-announce](https://matrix.to/#/#jellyfin-announce:matrix.org)
  * [#jellyfin-troubleshooting](https://matrix.to/#/#jellyfin-troubleshooting:matrix.org)
  * [#jellyfin-offtopic](https://matrix.to/#/#jellyfin-offtopic:matrix.org)
  * [#jellyfin-translate](https://matrix.to/#/#jellyfin-translate:matrix.org)


#### Development Rooms
  * [#jellyfin-documentation](https://matrix.to/#/#jellyfin-documentation:matrix.org)
  * [#jellyfin-dev](https://matrix.to/#/#jellyfin-dev:matrix.org)
  * [#jellyfin-dev-client](https://matrix.to/#/#jellyfin-dev-client:matrix.org)
  * [#jellyfin-dev-android](https://matrix.to/#/#jellyfin-dev-android:matrix.org)
  * [#jellyfin-dev-ios](https://matrix.to/#/#jellyfin-dev-ios:matrix.org)
  * [#jellyfin-vue](https://matrix.to/#/#jellyfin-vue:matrix.org)
  * [#jellyfin-dev-roku](https://matrix.to/#/#jellyfin-dev-roku:matrix.org)
  * [#jellyfin-dev-python](https://matrix.to/#/#jellyfin-dev-python:matrix.org)
  * [#jellyfin-ui-ux](https://matrix.to/#/#jellyfin-ui-ux:matrix.org)
  * [#jellyfin-hwa-tool](https://matrix.to/#/#jellyfin-hwa-tool:matrix.org)


[Join the Jellyfin Space](https://matrix.to/#/#jellyfinorg:matrix.org)
### Discord
Discord
The Jellyfin Discord server is bridged to the official Matrix rooms for convenience.
**NOTE:** Matrix is the preferred chat platform. Discord messages may be missed or delayed due to bridge instability.
[Join the Discord Server](https://discord.gg/zHBxVSXdBV)
Other
## Social
### Forum
Join us on our Forum for release announcements, troubleshooting, and development discussions.
[Jellyfin Forum](https://forum.jellyfin.org)
### Mastodon
Mastodon
Follow us on Mastodon for release announcements and more, just like our Twitter account.
[@jellyfin@mastodon.online](https://mastodon.online/@jellyfin)
### Twitter
X
Follow us on Twitter for release announcements and other updates, along with general musings.
[@jellyfin](https://www.twitter.com/jellyfin)
[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
