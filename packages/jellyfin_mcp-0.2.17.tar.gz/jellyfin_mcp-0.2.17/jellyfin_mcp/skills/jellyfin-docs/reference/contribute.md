[Skip to main content](https://jellyfin.org/contribute/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
# How to Contribute
Jellyfin is a community project run by volunteers. We're always looking for additional help.
## Find a way to contribute
If you are interested in helping the Jellyfin project, there are a few different ways to contribute depending on your skills and availability. Of course, simply using Jellyfin, finding issues, and reporting them, are a major help to our project, even if none of these apply to you!
Before contributing, please read over our [Community Standards](https://jellyfin.org/docs/general/community-standards) and [Contributing Guide](https://jellyfin.org/docs/general/contributing).
CodeTranslationsOther
* * *
## Meet the people that bring you Jellyfin
Jellyfin Contributors
### Sponsors
[JetBrainsJetBrains](https://www.jetbrains.com)
[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
