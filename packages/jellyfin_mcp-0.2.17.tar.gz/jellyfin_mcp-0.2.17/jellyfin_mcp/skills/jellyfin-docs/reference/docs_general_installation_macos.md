[Skip to main content](https://jellyfin.org/docs/general/installation/macos/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
  * [Introduction](https://jellyfin.org/docs/)
  * [Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Quick Start](https://jellyfin.org/docs/general/quick-start)
  * [Installation](https://jellyfin.org/docs/general/installation/)
    * [Windows](https://jellyfin.org/docs/general/installation/windows)
    * [macOS](https://jellyfin.org/docs/general/installation/macos)
    * [Linux](https://jellyfin.org/docs/general/installation/linux)
    * [Container](https://jellyfin.org/docs/general/installation/container)
    * [Advanced Installation](https://jellyfin.org/docs/general/installation/macos/)
  * [Post-Install Setup](https://jellyfin.org/docs/general/installation/macos/)
  * [Administration](https://jellyfin.org/docs/general/installation/macos/)
  * [Server Guide](https://jellyfin.org/docs/general/installation/macos/)
  * [Clients](https://jellyfin.org/docs/general/clients/)
  * [About Jellyfin](https://jellyfin.org/docs/general/about)
  * [Community Standards](https://jellyfin.org/docs/general/community-standards/)
  * [FAQ](https://jellyfin.org/docs/general/faq)
  * [Contributing](https://jellyfin.org/docs/general/contributing/)
  * [Style Guides](https://jellyfin.org/docs/general/style-guides/)
  * [Testing](https://jellyfin.org/docs/general/testing/)
  * [API Documentation](https://api.jellyfin.org)


  * [](https://jellyfin.org/)
  * [Installation](https://jellyfin.org/docs/general/installation/)
  * macOS


On this page
# macOS
## Installing on macOS[​](https://jellyfin.org/docs/general/installation/macos/#installing-on-macos "Direct link to Installing on macOS")
  1. Download the latest version DMG image from [the downloads page](https://jellyfin.org/downloads/macos). For Apple Silicon Macs below macOS 14, please update to a newer version of macOS or download the x86 release.
  2. Drag the `.app` package into the Applications folder.
  3. Start the application.
  4. Click the icon in the menu bar and select "Launch".


## Updating on macOS[​](https://jellyfin.org/docs/general/installation/macos/#updating-on-macos "Direct link to Updating on macOS")
  1. Download the latest version DMG image from [the downloads page](https://jellyfin.org/downloads/macos).
  2. Stop the currently running server either via the dashboard or using the menu bar icon.
  3. Drag the new `.app` package into the Applications folder and click yes to replace the files.
  4. Start the application.


## Uninstalling on macOS[​](https://jellyfin.org/docs/general/installation/macos/#uninstalling-on-macos "Direct link to Uninstalling on macOS")
  1. Stop the currently running server either via the dashboard or using the application icon.
  2. Move the `.app` package to the trash.


[](https://github.com/jellyfin/jellyfin.org/edit/master/docs/general/installation/macos.md)
[Previous Windows](https://jellyfin.org/docs/general/installation/windows)[Next Linux](https://jellyfin.org/docs/general/installation/linux)
  * [Installing on macOS](https://jellyfin.org/docs/general/installation/macos/#installing-on-macos)
  * [Updating on macOS](https://jellyfin.org/docs/general/installation/macos/#updating-on-macos)
  * [Uninstalling on macOS](https://jellyfin.org/docs/general/installation/macos/#uninstalling-on-macos)


[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
