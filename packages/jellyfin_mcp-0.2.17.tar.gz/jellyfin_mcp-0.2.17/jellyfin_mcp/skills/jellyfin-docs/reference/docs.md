[Skip to main content](https://jellyfin.org/docs/#__docusaurus_skipToContent_fallback)
[![Jellyfin Logo](https://jellyfin.org/images/logo.svg)](https://jellyfin.org/)
[Blog](https://jellyfin.org/posts)[Downloads](https://jellyfin.org/downloads)[Contribute](https://jellyfin.org/contribute)[Documentation](https://jellyfin.org/docs/)[Contact](https://jellyfin.org/contact)[Forum](https://forum.jellyfin.org)
`ctrl``K`
  * [Introduction](https://jellyfin.org/docs/)
  * [Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Quick Start](https://jellyfin.org/docs/general/quick-start)
  * [Installation](https://jellyfin.org/docs/general/installation/)
  * [Post-Install Setup](https://jellyfin.org/docs/)
  * [Administration](https://jellyfin.org/docs/)
  * [Server Guide](https://jellyfin.org/docs/)
  * [Clients](https://jellyfin.org/docs/general/clients/)
  * [About Jellyfin](https://jellyfin.org/docs/general/about)
  * [Community Standards](https://jellyfin.org/docs/general/community-standards/)
  * [FAQ](https://jellyfin.org/docs/general/faq)
  * [Contributing](https://jellyfin.org/docs/general/contributing/)
  * [Style Guides](https://jellyfin.org/docs/general/style-guides/)
  * [Testing](https://jellyfin.org/docs/general/testing/)
  * [API Documentation](https://api.jellyfin.org)


  * [](https://jellyfin.org/)
  * Introduction


On this page
# Welcome to the Jellyfin Documentation
[![GPL 2.0 License](https://img.shields.io/github/license/jellyfin/jellyfin.svg)](https://github.com/jellyfin/jellyfin)[![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg)](https://github.com/jellyfin/jellyfin/releases)[![Translations](https://translate.jellyfin.org/widgets/jellyfin/-/svg-badge.svg)](https://translate.jellyfin.org/engage/jellyfin/?utm_source=widget)[![Build Status](https://cloud.drone.io/api/badges/jellyfin/jellyfin/status.svg)](https://cloud.drone.io/jellyfin/jellyfin)[![Docker Pull Count](https://img.shields.io/docker/pulls/jellyfin/jellyfin.svg)](https://hub.docker.com/r/jellyfin/jellyfin)
[![Visit our Website](https://img.shields.io/website/http/jellyfin.org.svg?up_message=online&down_message=offline)](https://jellyfin.org)[![Join our Forum](https://img.shields.io/website/http/forum.jellyfin.org.svg?label=forum&up_message=online&down_message=offline)](https://forum.jellyfin.org)[![Chat on Matrix](https://img.shields.io/matrix/jellyfin:matrix.org.svg?logo=matrix)](https://matrix.to/#/+jellyfin:matrix.org)[![Donate](https://img.shields.io/opencollective/all/jellyfin.svg?label=backers)](https://opencollective.com/jellyfin)
Jellyfin is a Free Software Media System that puts you in control of managing and streaming your media. It is an alternative to the proprietary Emby and Plex, to provide media from a dedicated server to end-user devices via multiple apps. Jellyfin is descended from Emby's 3.5.2 release and ported to the .NET Core framework to enable full cross-platform support. There are no strings attached, no premium licenses or features, and no hidden agendas: just a team who want to build something better and work together to achieve it. We welcome anyone who is interested in joining us in our quest!
You can find a list of all [available clients here](https://jellyfin.org/downloads/clients). For more information please see our [about page](https://jellyfin.org/docs/general/about) or the [FAQ](https://jellyfin.org/docs/general/faq). If you are looking for help, [check out this page](https://jellyfin.org/docs/general/getting-help) for all the different communication channels we use.
Note: Jellyfin is a fast-moving project that is in its early stages, and this documentation as well as the code may change frequently. Please check back often and do not hesitate to contact us via our Matrix channels or Forum!
## Getting Started[​](https://jellyfin.org/docs/#getting-started "Direct link to Getting Started")
Want to get starting using Jellyfin right now? Check out the pages below for how to [install Jellyfin](https://jellyfin.org/docs/general/installation) on your machine.
  * [Windows](https://jellyfin.org/docs/general/installation/windows)
  * [macOS](https://jellyfin.org/docs/general/installation/macos)
  * [Debian / Ubuntu](https://jellyfin.org/docs/general/installation/linux#debian--ubuntu-and-derivatives)
  * [Other Linux Distributions](https://jellyfin.org/docs/general/installation/linux#other-distributions)
  * [Docker / Kubernetes / Podman](https://jellyfin.org/docs/general/installation/container)
  * [Synology](https://jellyfin.org/docs/general/installation/advanced/synology)
  * [TrueNAS SCALE](https://jellyfin.org/docs/general/installation/advanced/truenas)
  * [Generic Linux](https://jellyfin.org/docs/general/installation/advanced/manual#portable-linux-install)


Alternatively, Jellyfin may be built directly from the [source code](https://jellyfin.org/docs/general/installation/advanced/source).
## Administrator Documentation[​](https://jellyfin.org/docs/#administrator-documentation "Direct link to Administrator Documentation")
Want to know more about administering a Jellyfin server? Check out these pages!
  * [Migrating](https://jellyfin.org/docs/general/administration/migrate): How to migrate Jellyfin.
  * [Backup and Restore](https://jellyfin.org/docs/general/administration/backup-and-restore): How to back up or restore your Jellyfin metadata and configuration.
  * [Plugins](https://jellyfin.org/docs/general/server/plugins): How to install and manage plugins.
  * [Networking](https://jellyfin.org/docs/general/post-install/networking): Networking settings and troubleshooting.
  * [Monitoring](https://jellyfin.org/docs/general/post-install/networking/advanced/monitoring): Integration with external monitoring software.
  * [Hardware Acceleration](https://jellyfin.org/docs/general/post-install/transcoding/hardware-acceleration): Improve transcoding performance on supported hardware.


## Contributing to Jellyfin[​](https://jellyfin.org/docs/#contributing-to-jellyfin "Direct link to Contributing to Jellyfin")
Want to help out? Check out the pages below for how to contribute.
  * [Contribution Guide](https://jellyfin.org/docs/general/contributing): General information on contributing to Jellyfin.
  * [Plugin Guide](https://github.com/jellyfin/jellyfin-plugin-template): Documentation and resources to get started writing a plugin to extend Jellyfin functionality.
  * [Reporting Bugs](https://jellyfin.org/docs/general/contributing/issues#reporting-bugs): How to use our issue tracker on GitHub to report bugs.
  * [Requesting Features](https://jellyfin.org/docs/general/contributing/issues#requesting-features): How to use our issue tracker on GitHub to request new features or enhancements.


[](https://github.com/jellyfin/jellyfin.org/edit/master/docs/index.md)
[Next Getting Help](https://jellyfin.org/docs/general/getting-help)
  * [Getting Started](https://jellyfin.org/docs/#getting-started)
  * [Administrator Documentation](https://jellyfin.org/docs/#administrator-documentation)
  * [Contributing to Jellyfin](https://jellyfin.org/docs/#contributing-to-jellyfin)


[Documentation](https://jellyfin.org/docs)·[Feature Requests](https://features.jellyfin.org)·[Contribute](https://jellyfin.org/contribute)·[Status](https://status.jellyfin.org)·[Contact](https://jellyfin.org/contact)
![Jellyfin Logo](https://jellyfin.org/images/logo.svg)
[ ![Current Release](https://img.shields.io/github/release/jellyfin/jellyfin.svg) ](https://github.com/jellyfin/jellyfin/releases/latest)
Site content is licensed [CC-BY-ND-4.0](http://creativecommons.org/licenses/by-nd/4.0/)
