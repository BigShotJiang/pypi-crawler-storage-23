---
name: jellyfin-docs
description: Agent skill-graph for Jellyfin documentation (including API reference).
categories: [Documentation, Knowledge Base]
tags: [docs, jellyfin-docs, reference]
---

# Jellyfin Docs Documentation

Agent skill-graph for Jellyfin documentation (including API reference).

## Reference Files

- [Contact](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/contact.md)
- [How to Contribute](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/contribute.md)
- [Welcome to the Jellyfin Documentation](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs.md)
- [About Jellyfin](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_about.md)
- [Backup and Restore](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_administration_backup-and-restore.md)
- [Migrating](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_administration_migrate.md)
- [Clients](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_clients.md)
- [Jellyfin Community Standards](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_community-standards.md)
- [Contributing to Jellyfin](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_contributing.md)
- [Reporting Issues](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_contributing_issues.md)
- [Frequently Asked Questions](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_faq.md)
- [Getting Help](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_getting-help.md)
- [Installation](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation.md)
- [Manual Installation](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_advanced_manual.md)
- [Building from source](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_advanced_source.md)
- [Installation on Synology](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_advanced_synology.md)
- [TrueNAS SCALE](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_advanced_truenas.md)
- [Container](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_container.md)
- [Linux](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_linux.md)
- [macOS](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_macos.md)
- [Windows](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_installation_windows.md)
- [Networking](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_post-install_networking.md)
- [Monitoring](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_post-install_networking_advanced_monitoring.md)
- [Hardware Acceleration](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_post-install_transcoding_hardware-acceleration.md)
- [Quick Start](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_quick-start.md)
- [Plugins](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_server_plugins.md)
- [Style Guides](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_style-guides.md)
- [Testing Jellyfin](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/docs_general_testing.md)
- [Downloads](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/downloads.md)
- [Downloads](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/downloads_clients.md)
- [Jellyfin API (10.11.6)](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/index.md)
- [openapi_jellyfin-openapi-stable.json.md](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/openapi_jellyfin-openapi-stable.json.md)
- [posts.md](file:///home/genius/Workspace/agent-packages/universal-skills/universal_skills/skill-graphs/jellyfin-docs/reference/posts.md)
