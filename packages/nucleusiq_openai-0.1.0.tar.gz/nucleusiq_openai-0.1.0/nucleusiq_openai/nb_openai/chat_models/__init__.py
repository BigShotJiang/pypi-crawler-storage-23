"""
OpenAI chat models for NucleusIQ.

This package contains OpenAI chat model implementations.
"""
