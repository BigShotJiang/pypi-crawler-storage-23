"""
OpenAI embeddings for NucleusIQ.

This package contains OpenAI embedding model implementations.
"""
