### Examples:
Send email:
```
from djmail import mail_managers
mail_managers(
    subject=_('New product price offer #{}').format(obj.id),
    template='offers/email.html',
    context=context
)
```
Email template:
```
{% extends 'email.html' %}

{% block content %}
    content...
{% endblock %}
```
