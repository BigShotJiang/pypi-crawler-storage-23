from firexapp.application import main
main()
