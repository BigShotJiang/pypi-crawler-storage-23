# PEP0440 compatible formatted version, see:
# https://www.python.org/dev/peps/pep-0440/
#
# Final release markers:
#   X.Y.0   # For first release after an increment in Y
#   X.Y.Z   # For bugfix releases
#
# Admissible pre-release markers:
#   X.YaN   # Alpha release
#   X.YbN   # Beta release
#   X.YrcN  # Release Candidate
#
# Dev branch marker is: 'X.Y.dev' or 'X.Y.devN' where N is an integer.
# 'X.Y.dev0' is the canonical version of 'X.Y.dev'.
__version__ = '1.0.dev2'

# Public API of the optiprofiler package
from .opclasses import Feature, Problem, FeaturedProblem
from .profiles import benchmark
from .utils import show_versions

__all__ = [
    'Problem',
    'Feature',
    'FeaturedProblem',
    'benchmark',
    'show_versions',
]
