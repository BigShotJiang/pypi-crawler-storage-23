"""
Cognis - Long-Term Memory for Agents

Cognis gives your agents persistent memory across sessions.
Memories are automatically extracted from conversations and
retrieved when relevant.

Two ways to use Cognis:
  1. Standalone client - direct memory CRUD
  2. Via Studio - convenience methods on your Studio instance

Set your API key:
  export LYZR_API_KEY="your-api-key"
Or pass directly:
  Cognis(api_key="your-api-key")

Get your API key: https://studio.lyzr.ai
"""

from lyzr import Cognis, CognisMessage, Studio


# ── Standalone Client ─────────────────────────────────────────────

cog = Cognis()  # Uses LYZR_API_KEY env var

# Add conversation messages — Cognis extracts facts automatically
cog.add(
    messages=[
        CognisMessage(role="user", content="My name is Alice and I live in NYC"),
        CognisMessage(role="assistant", content="Nice to meet you, Alice!"),
    ],
    owner_id="alice",
    session_id="onboarding",
)

cog.add(
    messages=[
        CognisMessage(role="user", content="I work as a data scientist at Acme Corp"),
        CognisMessage(role="assistant", content="Data science is a great field!"),
    ],
    owner_id="alice",
    session_id="onboarding",
)

# Search memories by semantic meaning
results = cog.search(query="where does the user live?", owner_id="alice")
print("Search results:")
for r in results[:3]:
    print(f"  [{r.score:.2f}] {r.content}")

# List all memories for a user
memories = cog.get(owner_id="alice")
print(f"\nTotal memories: {len(memories)}")
for m in memories:
    print(f"  - {m.content}")

# Get a single memory by ID
if len(memories) > 0:
    single = cog.get_memory(memory_id=memories[0].id)
    print(f"\nSingle memory: {single.content}")

# Update a memory
if len(memories) > 0:
    updated = cog.update(
        memory_id=memories[0].id,
        content="Alice lives in San Francisco (moved from NYC)",
        owner_id="alice",
    )
    print(f"Updated: {updated.content}")


# ── Context Window ────────────────────────────────────────────────
# Build a context window with short-term + long-term memories
# for feeding into your LLM.

ctx = cog.context(
    current_messages=[
        CognisMessage(role="user", content="What do you know about me?"),
    ],
    owner_id="alice",
    session_id="onboarding",
)
print(f"\nContext: {ctx.get('long_term_count')} long-term, {ctx.get('short_term_count')} short-term")
for msg in ctx.get("context", []):
    print(f"  [{msg['role']}] {msg['content'][:80]}")


# ── Messages & Summaries ─────────────────────────────────────────

# Get raw conversation messages
msgs = cog.get_messages(owner_id="alice", session_id="onboarding")
print(f"\nMessages: {msgs.get('count', 0)}")

# Store a summary of the conversation
cog.store_summary(
    owner_id="alice",
    session_id="onboarding",
    content="Alice is a data scientist at Acme Corp, lives in NYC",
    messages_covered_count=4,
)

# Retrieve current summary
summary = cog.get_current_summary(owner_id="alice", session_id="onboarding")
print(f"Summary: {summary}")

# Search across summaries
found = cog.search_summaries(owner_id="alice", query="job")
print(f"Summary search: {found}")


# ── ID Flexibility ────────────────────────────────────────────────
# Use any combination of owner_id, agent_id, session_id.
# At least one is required.

# Agent-scoped memory (shared across all users of an agent)
cog.add(
    messages=[CognisMessage(role="user", content="Agent prefers formal tone")],
    agent_id="support-bot",
)

# Session-scoped memory (anonymous, tied to a session)
cog.add(
    messages=[CognisMessage(role="user", content="Discussing Q4 roadmap")],
    session_id="meeting-2024-q4",
)

# All three — most specific scope
cog.add(
    messages=[CognisMessage(role="user", content="Alice chatting with support bot")],
    owner_id="alice",
    agent_id="support-bot",
    session_id="ticket-123",
)


# ── Cleanup ───────────────────────────────────────────────────────

# Delete a specific memory
if len(memories) > 0:
    cog.delete(memory_id=memories[0].id, owner_id="alice")

# Delete an entire session
cog.delete_session(owner_id="alice", session_id="onboarding")

cog.close()


# ── Via Studio ────────────────────────────────────────────────────
# Studio exposes the same methods as convenience wrappers.

studio = Studio()  # Uses LYZR_API_KEY env var

studio.add_memory(
    messages=[CognisMessage(role="user", content="I prefer dark mode")],
    owner_id="bob",
    session_id="prefs",
)

results = studio.search_memories(query="preferences", owner_id="bob")
print(f"\nStudio search: {len(results)} results")

memories = studio.get_memories(owner_id="bob")
print(f"Studio memories: {len(memories)}")

ctx = studio.get_memory_context(
    current_messages=[CognisMessage(role="user", content="What are my settings?")],
    owner_id="bob",
    session_id="prefs",
)
print(f"Studio context: {ctx.get('success')}")

# Cleanup
studio.delete_memory_session(owner_id="bob", session_id="prefs")
studio.close()
