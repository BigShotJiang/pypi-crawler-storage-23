"""
Pydantic models for Cognis memory operations
"""

from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field, ConfigDict


class CognisMessage(BaseModel):
    """A single message in a conversation"""

    role: str = Field(..., description="Message role (user, assistant, system)")
    content: str = Field(..., description="Message content")

    model_config = ConfigDict(frozen=True)


class CognisMemoryRecord(BaseModel):
    """A memory record returned by the memory API"""

    id: str = Field(..., description="Memory record ID")
    memory_id: str = Field("", description="Memory record ID (alternate)")
    content: str = Field("", description="Memory content")
    owner_id: Optional[str] = Field(None, description="Owner ID")
    agent_id: Optional[str] = Field(None, description="Agent ID")
    session_id: Optional[str] = Field(None, description="Session ID")
    status: Optional[str] = Field(None, description="Memory status")
    is_current: Optional[bool] = Field(None, description="Whether this is the current version")
    version: Optional[int] = Field(None, description="Version number")
    salience_score: Optional[float] = Field(None, description="Importance score")
    decay_score: Optional[float] = Field(None, description="Temporal decay score")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    created_at: Optional[str] = Field(None, description="Creation timestamp")
    updated_at: Optional[str] = Field(None, description="Last update timestamp")

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True, extra="allow")

    @property
    def record_id(self) -> Optional[str]:
        """Get the memory record ID from either id or memory_id field"""
        return self.id or self.memory_id

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return self.model_dump(by_alias=False, exclude_none=True)


class CognisSearchResult(BaseModel):
    """A search result from memory search"""

    id: str = Field(..., description="Memory record ID")
    memory_id: str = Field("", description="Memory record ID (alternate)")
    content: str = Field("", description="Memory content")
    score: Optional[float] = Field(None, description="Relevance score")
    owner_id: Optional[str] = Field(None, description="Owner ID")
    agent_id: Optional[str] = Field(None, description="Agent ID")
    session_id: Optional[str] = Field(None, description="Session ID")
    metadata: Optional[Dict[str, Any]] = Field(None, description="Additional metadata")
    created_at: Optional[str] = Field(None, description="Creation timestamp")

    model_config = ConfigDict(populate_by_name=True, arbitrary_types_allowed=True, extra="allow")

    @property
    def record_id(self) -> Optional[str]:
        """Get the memory record ID from either id or memory_id field"""
        return self.id or self.memory_id


class CognisMemoryList(BaseModel):
    """List of memory records"""

    memories: List[CognisMemoryRecord] = Field(
        default_factory=list, description="List of memories"
    )
    total: Optional[int] = Field(None, description="Total count")

    def __iter__(self):
        return iter(self.memories)

    def __len__(self):
        return len(self.memories)

    def __getitem__(self, index):
        return self.memories[index]
