"""
Version information for Lyzr ADK
"""

__version__ = "0.1.7"
__author__ = "Lyzr"
__description__ = "Python ADK for Lyzr Agent API"
