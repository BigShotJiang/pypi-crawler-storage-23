#!/bin/bash env

rm -r dist/*
uv build
uv run twine upload dist/*

