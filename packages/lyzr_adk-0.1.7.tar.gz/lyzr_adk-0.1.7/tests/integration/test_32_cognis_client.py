"""
Test 32: Cognis Standalone Client
Tests the Cognis client wrapper, context managers, and repr.
"""

import pytest
from unittest.mock import MagicMock, AsyncMock, patch
from lyzr.cognis.client import Cognis
from lyzr.cognis.models import (
    CognisMessage,
    CognisMemoryRecord,
    CognisSearchResult,
    CognisMemoryList,
)
from lyzr.urls import get_urls


# ── Sample API Responses ──────────────────────────────────────────

SAMPLE_MEMORY = {
    "id": "mem_abc123",
    "content": "User likes hiking",
    "owner_id": "owner_1",
    "status": "CURRENT",
    "is_current": True,
    "version": 1,
    "created_at": "2026-01-01T00:00:00Z",
}

SAMPLE_ADD_RESPONSE = {"success": True, "session_id": "sess_1"}
SAMPLE_SEARCH_RESULT = {"id": "mem_abc123", "content": "User likes hiking", "score": 0.95}
SAMPLE_CONTEXT_RESPONSE = {"success": True, "has_long_term_memory": True, "long_term_count": 2}
SAMPLE_MESSAGES_RESPONSE = {"success": True, "messages": [], "count": 0}
SAMPLE_SUMMARY_RESPONSE = {"success": True, "summary_id": "sum_123"}


# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def mock_module():
    """Create a mock CognisModule."""
    module = MagicMock()
    # Sync methods
    module.add.return_value = SAMPLE_ADD_RESPONSE
    module.search.return_value = [CognisSearchResult(**SAMPLE_SEARCH_RESULT)]
    module.get.return_value = CognisMemoryList(
        memories=[CognisMemoryRecord(**SAMPLE_MEMORY)], total=1
    )
    module.get_memory.return_value = CognisMemoryRecord(**SAMPLE_MEMORY)
    module.update.return_value = CognisMemoryRecord(**SAMPLE_MEMORY)
    module.delete.return_value = True
    module.context.return_value = SAMPLE_CONTEXT_RESPONSE
    module.get_messages.return_value = SAMPLE_MESSAGES_RESPONSE
    module.store_summary.return_value = SAMPLE_SUMMARY_RESPONSE
    module.get_current_summary.return_value = {"success": True}
    module.search_summaries.return_value = {"success": True}
    module.delete_session.return_value = True

    # Async methods
    module.aadd = AsyncMock(return_value=SAMPLE_ADD_RESPONSE)
    module.asearch = AsyncMock(return_value=[CognisSearchResult(**SAMPLE_SEARCH_RESULT)])
    module.aget = AsyncMock(return_value=CognisMemoryList(
        memories=[CognisMemoryRecord(**SAMPLE_MEMORY)], total=1
    ))
    module.aget_memory = AsyncMock(return_value=CognisMemoryRecord(**SAMPLE_MEMORY))
    module.aupdate = AsyncMock(return_value=CognisMemoryRecord(**SAMPLE_MEMORY))
    module.adelete = AsyncMock(return_value=True)
    module.acontext = AsyncMock(return_value=SAMPLE_CONTEXT_RESPONSE)
    module.aget_messages = AsyncMock(return_value=SAMPLE_MESSAGES_RESPONSE)
    module.astore_summary = AsyncMock(return_value=SAMPLE_SUMMARY_RESPONSE)
    module.aget_current_summary = AsyncMock(return_value={"success": True})
    module.asearch_summaries = AsyncMock(return_value={"success": True})
    module.adelete_session = AsyncMock(return_value=True)

    module._async_http = None
    module._http = MagicMock()
    module._http.api_key = "sk-test"
    return module


@pytest.fixture
def cognis_client(mock_module):
    """Create Cognis client with mocked module."""
    with patch("lyzr.cognis.module.CognisModule.__init__", return_value=None):
        client = Cognis(api_key="sk-test")
        client._module = mock_module
        client.env_config = get_urls("prod")
        client.env = "prod"
        client._timeout = 30
    return client


# ── Init & Repr Tests ─────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisClientInit:
    """Tests for Cognis client initialization."""

    def test_repr(self, cognis_client):
        """repr shows env."""
        r = repr(cognis_client)
        assert "Cognis(" in r
        assert "env=" in r

    def test_default_env(self, cognis_client):
        """Default env is prod."""
        assert cognis_client.env == "prod"


# ── Sync Delegation Tests ────────────────────────────────────────

@pytest.mark.cognis
class TestCognisClientSync:
    """Tests that sync methods delegate to module."""

    def test_add(self, cognis_client, mock_module):
        """add() delegates to module.add()."""
        result = cognis_client.add(
            messages=[CognisMessage(role="user", content="Hello")],
            owner_id="owner_1",
        )
        assert result["success"] is True
        mock_module.add.assert_called_once()

    def test_search(self, cognis_client, mock_module):
        """search() delegates to module.search()."""
        results = cognis_client.search(query="hiking", owner_id="owner_1")
        assert len(results) == 1
        assert isinstance(results[0], CognisSearchResult)
        mock_module.search.assert_called_once()

    def test_get(self, cognis_client, mock_module):
        """get() delegates to module.get()."""
        memories = cognis_client.get(owner_id="owner_1")
        assert isinstance(memories, CognisMemoryList)
        assert len(memories) == 1
        mock_module.get.assert_called_once()

    def test_get_memory(self, cognis_client, mock_module):
        """get_memory() delegates to module.get_memory()."""
        memory = cognis_client.get_memory(memory_id="mem_abc123")
        assert isinstance(memory, CognisMemoryRecord)
        mock_module.get_memory.assert_called_once_with("mem_abc123", None)

    def test_update(self, cognis_client, mock_module):
        """update() delegates to module.update()."""
        result = cognis_client.update(
            memory_id="mem_abc123",
            content="Updated",
            owner_id="owner_1",
        )
        assert isinstance(result, CognisMemoryRecord)
        mock_module.update.assert_called_once()

    def test_delete(self, cognis_client, mock_module):
        """delete() delegates to module.delete()."""
        result = cognis_client.delete(memory_id="mem_abc123", owner_id="owner_1")
        assert result is True
        mock_module.delete.assert_called_once()

    def test_context(self, cognis_client, mock_module):
        """context() delegates to module.context()."""
        ctx = cognis_client.context(
            current_messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
            session_id="sess_1",
        )
        assert ctx["success"] is True
        mock_module.context.assert_called_once()

    def test_get_messages(self, cognis_client, mock_module):
        """get_messages() delegates to module.get_messages()."""
        msgs = cognis_client.get_messages(owner_id="owner_1", session_id="sess_1")
        assert msgs["success"] is True
        mock_module.get_messages.assert_called_once()

    def test_store_summary(self, cognis_client, mock_module):
        """store_summary() delegates to module.store_summary()."""
        result = cognis_client.store_summary(
            owner_id="owner_1",
            session_id="sess_1",
            content="Summary",
            messages_covered_count=4,
        )
        assert result["success"] is True
        mock_module.store_summary.assert_called_once()

    def test_get_current_summary(self, cognis_client, mock_module):
        """get_current_summary() delegates to module."""
        cognis_client.get_current_summary(owner_id="owner_1", session_id="sess_1")
        mock_module.get_current_summary.assert_called_once_with("owner_1", "sess_1")

    def test_search_summaries(self, cognis_client, mock_module):
        """search_summaries() delegates to module."""
        cognis_client.search_summaries(owner_id="owner_1", query="hiking")
        mock_module.search_summaries.assert_called_once()

    def test_delete_session(self, cognis_client, mock_module):
        """delete_session() delegates to module."""
        result = cognis_client.delete_session(owner_id="owner_1", session_id="sess_1")
        assert result is True
        mock_module.delete_session.assert_called_once()


# ── Async Delegation Tests ───────────────────────────────────────

@pytest.mark.cognis
class TestCognisClientAsync:
    """Tests that async methods delegate to module."""

    @pytest.mark.asyncio
    async def test_aadd(self, cognis_client, mock_module):
        """aadd() delegates to module.aadd()."""
        result = await cognis_client.aadd(
            messages=[{"role": "user", "content": "Hello"}],
            owner_id="owner_1",
        )
        assert result["success"] is True
        mock_module.aadd.assert_called_once()

    @pytest.mark.asyncio
    async def test_asearch(self, cognis_client, mock_module):
        """asearch() delegates to module.asearch()."""
        results = await cognis_client.asearch(query="hiking", owner_id="owner_1")
        assert len(results) == 1
        mock_module.asearch.assert_called_once()

    @pytest.mark.asyncio
    async def test_aget(self, cognis_client, mock_module):
        """aget() delegates to module.aget()."""
        memories = await cognis_client.aget(owner_id="owner_1")
        assert isinstance(memories, CognisMemoryList)
        mock_module.aget.assert_called_once()

    @pytest.mark.asyncio
    async def test_aget_memory(self, cognis_client, mock_module):
        """aget_memory() delegates to module.aget_memory()."""
        memory = await cognis_client.aget_memory(memory_id="mem_abc123")
        assert isinstance(memory, CognisMemoryRecord)
        mock_module.aget_memory.assert_called_once()

    @pytest.mark.asyncio
    async def test_aupdate(self, cognis_client, mock_module):
        """aupdate() delegates to module.aupdate()."""
        result = await cognis_client.aupdate(
            memory_id="mem_abc123",
            content="Updated",
        )
        assert isinstance(result, CognisMemoryRecord)
        mock_module.aupdate.assert_called_once()

    @pytest.mark.asyncio
    async def test_adelete(self, cognis_client, mock_module):
        """adelete() delegates to module.adelete()."""
        result = await cognis_client.adelete(memory_id="mem_abc123")
        assert result is True
        mock_module.adelete.assert_called_once()

    @pytest.mark.asyncio
    async def test_acontext(self, cognis_client, mock_module):
        """acontext() delegates to module.acontext()."""
        ctx = await cognis_client.acontext(
            current_messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
            session_id="sess_1",
        )
        assert ctx["success"] is True
        mock_module.acontext.assert_called_once()

    @pytest.mark.asyncio
    async def test_aget_messages(self, cognis_client, mock_module):
        """aget_messages() delegates to module.aget_messages()."""
        msgs = await cognis_client.aget_messages(owner_id="owner_1", session_id="sess_1")
        assert msgs["success"] is True
        mock_module.aget_messages.assert_called_once()

    @pytest.mark.asyncio
    async def test_astore_summary(self, cognis_client, mock_module):
        """astore_summary() delegates to module."""
        result = await cognis_client.astore_summary(
            owner_id="owner_1",
            session_id="sess_1",
            content="Summary",
            messages_covered_count=4,
        )
        assert result["success"] is True
        mock_module.astore_summary.assert_called_once()

    @pytest.mark.asyncio
    async def test_aget_current_summary(self, cognis_client, mock_module):
        """aget_current_summary() delegates to module."""
        await cognis_client.aget_current_summary(owner_id="owner_1", session_id="sess_1")
        mock_module.aget_current_summary.assert_called_once()

    @pytest.mark.asyncio
    async def test_asearch_summaries(self, cognis_client, mock_module):
        """asearch_summaries() delegates to module."""
        await cognis_client.asearch_summaries(owner_id="owner_1", query="hiking")
        mock_module.asearch_summaries.assert_called_once()

    @pytest.mark.asyncio
    async def test_adelete_session(self, cognis_client, mock_module):
        """adelete_session() delegates to module."""
        result = await cognis_client.adelete_session(
            owner_id="owner_1",
            session_id="sess_1",
        )
        assert result is True
        mock_module.adelete_session.assert_called_once()


# ── Context Manager Tests ────────────────────────────────────────

@pytest.mark.cognis
class TestCognisClientContextManager:
    """Tests for sync/async context managers."""

    def test_sync_context_manager(self, mock_module):
        """Sync context manager calls close()."""
        with patch("lyzr.cognis.module.CognisModule.__init__", return_value=None):
            with Cognis(api_key="sk-test") as cog:
                cog._module = mock_module
                assert cog is not None

            mock_module._http.close.assert_called_once()

    @pytest.mark.asyncio
    async def test_async_context_manager(self, mock_module):
        """Async context manager calls aclose()."""
        mock_module._async_http = None

        with patch("lyzr.cognis.module.CognisModule.__init__", return_value=None), \
             patch("lyzr.cognis.client.AsyncHTTPClient") as MockAsyncHTTP:
            mock_async_instance = AsyncMock()
            MockAsyncHTTP.return_value = mock_async_instance

            cog = Cognis(api_key="sk-test")
            cog._module = mock_module
            cog.env_config = get_urls("prod")
            cog.env = "prod"
            cog._timeout = 30

            async with cog:
                assert cog is not None

            mock_module._http.close.assert_called_once()


# ── Model Tests ──────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisModels:
    """Tests for Pydantic models."""

    def test_cognis_message(self):
        """CognisMessage creates correctly."""
        msg = CognisMessage(role="user", content="Hello")
        assert msg.role == "user"
        assert msg.content == "Hello"
        assert msg.model_dump() == {"role": "user", "content": "Hello"}

    def test_cognis_message_frozen(self):
        """CognisMessage is immutable."""
        msg = CognisMessage(role="user", content="Hello")
        with pytest.raises(Exception):
            msg.role = "assistant"

    def test_cognis_memory_record(self):
        """CognisMemoryRecord creates from API data."""
        record = CognisMemoryRecord(**SAMPLE_MEMORY)
        assert record.id == "mem_abc123"
        assert record.content == "User likes hiking"
        assert record.owner_id == "owner_1"
        assert record.is_current is True

    def test_cognis_memory_record_id(self):
        """record_id property uses id, falls back to memory_id."""
        record = CognisMemoryRecord(id="mem_123", memory_id="mem_alt", content="test")
        assert record.record_id == "mem_123"

    def test_cognis_memory_record_id_fallback(self):
        """record_id falls back to memory_id when id is empty."""
        record = CognisMemoryRecord(id="", memory_id="mem_123", content="test")
        assert record.record_id == "mem_123"

    def test_cognis_memory_record_to_dict(self):
        """to_dict() excludes None fields."""
        record = CognisMemoryRecord(id="mem_123", content="test")
        d = record.to_dict()
        assert d["id"] == "mem_123"
        assert d["content"] == "test"
        assert "owner_id" not in d

    def test_cognis_memory_record_extra_fields(self):
        """CognisMemoryRecord allows extra fields from API."""
        record = CognisMemoryRecord(
            id="mem_123",
            content="test",
            some_unknown_field="value",
        )
        assert record.id == "mem_123"

    def test_cognis_search_result(self):
        """CognisSearchResult creates from API data."""
        result = CognisSearchResult(**SAMPLE_SEARCH_RESULT)
        assert result.id == "mem_abc123"
        assert result.score == 0.95
        assert result.content == "User likes hiking"

    def test_cognis_memory_list_iteration(self):
        """CognisMemoryList supports len, iter, getitem."""
        records = [CognisMemoryRecord(**SAMPLE_MEMORY)]
        ml = CognisMemoryList(memories=records, total=1)

        assert len(ml) == 1
        assert ml[0].content == "User likes hiking"
        assert list(ml)[0].content == "User likes hiking"

    def test_cognis_memory_list_empty(self):
        """CognisMemoryList handles empty list."""
        ml = CognisMemoryList(memories=[], total=0)
        assert len(ml) == 0
        assert list(ml) == []
