"""
Test 30: Cognis Module (Sync)
Tests CognisModule sync CRUD, context, messages, and summary operations with mocked HTTP.
"""

import pytest
from unittest.mock import MagicMock, patch
from lyzr.http import HTTPClient
from lyzr.urls import ServiceURLs
from lyzr.cognis.module import CognisModule
from lyzr.cognis.models import (
    CognisMessage,
    CognisMemoryRecord,
    CognisSearchResult,
    CognisMemoryList,
)


# ── Sample API Responses ──────────────────────────────────────────

SAMPLE_MEMORY = {
    "id": "mem_abc123",
    "memory_id": "mem_abc123",
    "content": "User likes hiking",
    "owner_id": "owner_1",
    "agent_id": "agent_1",
    "session_id": "sess_1",
    "status": "CURRENT",
    "is_current": True,
    "version": 1,
    "created_at": "2026-01-01T00:00:00Z",
    "updated_at": "2026-01-01T00:00:00Z",
}

SAMPLE_MEMORY_2 = {
    "id": "mem_def456",
    "memory_id": "mem_def456",
    "content": "User lives in NYC",
    "owner_id": "owner_1",
    "session_id": "sess_1",
    "status": "CURRENT",
    "is_current": True,
    "version": 1,
    "created_at": "2026-01-01T00:00:00Z",
}

SAMPLE_SEARCH_RESULT = {
    "id": "mem_abc123",
    "memory_id": "mem_abc123",
    "content": "User likes hiking",
    "score": 0.95,
    "owner_id": "owner_1",
    "created_at": "2026-01-01T00:00:00Z",
}

SAMPLE_ADD_RESPONSE = {
    "success": True,
    "session_id": "sess_1",
    "messages_stored": 2,
}

SAMPLE_CONTEXT_RESPONSE = {
    "success": True,
    "has_long_term_memory": True,
    "short_term_count": 5,
    "long_term_count": 2,
    "context": [
        {"role": "system", "content": "Long-term memories: User likes hiking"},
        {"role": "user", "content": "What do I enjoy?"},
    ],
}

SAMPLE_MESSAGES_RESPONSE = {
    "success": True,
    "messages": [
        {"role": "user", "content": "Hello", "timestamp": "2026-01-01T00:00:00Z"},
        {"role": "assistant", "content": "Hi!", "timestamp": "2026-01-01T00:00:01Z"},
    ],
    "count": 2,
}

SAMPLE_SUMMARY_RESPONSE = {
    "success": True,
    "summary_id": "sum_123",
    "archived_previous": False,
}

SAMPLE_CURRENT_SUMMARY_RESPONSE = {
    "success": True,
    "summary": {
        "summary_id": "sum_123",
        "content": "User discussed hiking preferences",
        "messages_covered_count": 4,
    },
}

SAMPLE_SEARCH_SUMMARIES_RESPONSE = {
    "success": True,
    "results": [
        {"summary_id": "sum_123", "content": "User likes hiking", "score": 0.9},
    ],
    "count": 1,
}


# ── Fixtures ──────────────────────────────────────────────────────

@pytest.fixture
def mock_http():
    """Create mock sync HTTP client."""
    http = MagicMock(spec=HTTPClient)
    http.api_key = "sk-test"
    http.base_url = "https://memory.studio.lyzr.ai"
    http.timeout = 30
    return http


@pytest.fixture
def env_config():
    """Create environment config with memory API."""
    return ServiceURLs(
        agent_api="https://agent-prod.studio.lyzr.ai",
        rag_api="https://rag-prod.studio.lyzr.ai",
        rai_api="https://srs-prod.studio.lyzr.ai",
        memory_api="https://memory.studio.lyzr.ai",
    )


@pytest.fixture
def cognis_module(mock_http, env_config):
    """Create CognisModule with mocked HTTP."""
    with patch("lyzr.http.HTTPClient", return_value=mock_http):
        module = CognisModule(api_key="sk-test", env_config=env_config)
    module._http = mock_http
    return module


# ── Validation Tests ──────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisValidation:
    """Tests for ID validation."""

    def test_validate_ids_requires_at_least_one(self, cognis_module):
        """At least one of owner_id, agent_id, session_id is required."""
        with pytest.raises(ValueError, match="At least one"):
            cognis_module.add(messages=[{"role": "user", "content": "test"}])

    def test_validate_ids_owner_only(self, cognis_module, mock_http):
        """owner_id alone is valid."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE
        result = cognis_module.add(
            messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
        )
        assert result["success"] is True

    def test_validate_ids_agent_only(self, cognis_module, mock_http):
        """agent_id alone is valid."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE
        result = cognis_module.add(
            messages=[{"role": "user", "content": "test"}],
            agent_id="agent_1",
        )
        assert result["success"] is True

    def test_validate_ids_session_only(self, cognis_module, mock_http):
        """session_id alone is valid."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE
        result = cognis_module.add(
            messages=[{"role": "user", "content": "test"}],
            session_id="sess_1",
        )
        assert result["success"] is True

    def test_validate_ids_search_requires_id(self, cognis_module):
        """search() requires at least one ID."""
        with pytest.raises(ValueError, match="At least one"):
            cognis_module.search(query="test")

    def test_validate_ids_get_requires_id(self, cognis_module):
        """get() requires at least one ID."""
        with pytest.raises(ValueError, match="At least one"):
            cognis_module.get()

    def test_validate_ids_context_requires_owner_id(self, cognis_module):
        """context() requires owner_id (server requirement)."""
        with pytest.raises(ValueError, match="owner_id is required"):
            cognis_module.context(
                current_messages=[{"role": "user", "content": "test"}],
            )

    def test_validate_ids_get_messages_requires_id(self, cognis_module):
        """get_messages() requires at least one ID."""
        with pytest.raises(ValueError, match="At least one"):
            cognis_module.get_messages()


# ── Add Tests ─────────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisAdd:
    """Tests for add()."""

    def test_add_with_dict_messages(self, cognis_module, mock_http):
        """Add with plain dict messages."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE

        result = cognis_module.add(
            messages=[
                {"role": "user", "content": "Hello"},
                {"role": "assistant", "content": "Hi there!"},
            ],
            owner_id="owner_1",
        )

        assert result["success"] is True
        mock_http.post.assert_called_once()
        call_args = mock_http.post.call_args
        assert call_args[0][0] == "/v1/memories"
        body = call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert len(body["messages"]) == 2

    def test_add_with_cognis_messages(self, cognis_module, mock_http):
        """Add with CognisMessage objects."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE

        result = cognis_module.add(
            messages=[
                CognisMessage(role="user", content="Hello"),
                CognisMessage(role="assistant", content="Hi!"),
            ],
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert result["success"] is True
        body = mock_http.post.call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert body["session_id"] == "sess_1"
        assert body["messages"][0] == {"role": "user", "content": "Hello"}

    def test_add_with_all_ids(self, cognis_module, mock_http):
        """Add with owner_id + agent_id + session_id."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE

        cognis_module.add(
            messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
            agent_id="agent_1",
            session_id="sess_1",
        )

        body = mock_http.post.call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert body["agent_id"] == "agent_1"
        assert body["session_id"] == "sess_1"

    def test_add_with_agent_session_only(self, cognis_module, mock_http):
        """Add with agent_id + session_id (no owner_id)."""
        mock_http.post.return_value = SAMPLE_ADD_RESPONSE

        cognis_module.add(
            messages=[{"role": "user", "content": "test"}],
            agent_id="agent_1",
            session_id="sess_1",
        )

        body = mock_http.post.call_args[1]["json"]
        assert "owner_id" not in body
        assert body["agent_id"] == "agent_1"
        assert body["session_id"] == "sess_1"


# ── Search Tests ──────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisSearch:
    """Tests for search()."""

    def test_search_returns_search_results(self, cognis_module, mock_http):
        """search() returns list of CognisSearchResult."""
        mock_http.post.return_value = {"results": [SAMPLE_SEARCH_RESULT]}

        results = cognis_module.search(query="hiking", owner_id="owner_1")

        assert len(results) == 1
        assert isinstance(results[0], CognisSearchResult)
        assert results[0].content == "User likes hiking"
        assert results[0].score == 0.95

    def test_search_with_limit(self, cognis_module, mock_http):
        """search() passes limit parameter."""
        mock_http.post.return_value = {"results": []}

        cognis_module.search(query="test", owner_id="owner_1", limit=5)

        body = mock_http.post.call_args[1]["json"]
        assert body["limit"] == 5

    def test_search_with_cross_session(self, cognis_module, mock_http):
        """search() passes cross_session parameter."""
        mock_http.post.return_value = {"results": []}

        cognis_module.search(
            query="test",
            owner_id="owner_1",
            cross_session=True,
        )

        body = mock_http.post.call_args[1]["json"]
        assert body["cross_session"] is True

    def test_search_with_agent_session(self, cognis_module, mock_http):
        """search() with agent_id + session_id."""
        mock_http.post.return_value = {"results": [SAMPLE_SEARCH_RESULT]}

        results = cognis_module.search(
            query="test",
            agent_id="agent_1",
            session_id="sess_1",
        )

        body = mock_http.post.call_args[1]["json"]
        assert "owner_id" not in body
        assert body["agent_id"] == "agent_1"
        assert body["session_id"] == "sess_1"
        assert len(results) == 1

    def test_search_parses_list_response(self, cognis_module, mock_http):
        """search() handles list response format (no wrapper)."""
        mock_http.post.return_value = [SAMPLE_SEARCH_RESULT]

        results = cognis_module.search(query="hiking", owner_id="owner_1")

        assert len(results) == 1
        assert results[0].score == 0.95

    def test_search_empty_results(self, cognis_module, mock_http):
        """search() handles empty results."""
        mock_http.post.return_value = {"results": []}

        results = cognis_module.search(query="nonexistent", owner_id="owner_1")

        assert len(results) == 0


# ── Get Tests ─────────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisGet:
    """Tests for get() and get_memory()."""

    def test_get_returns_memory_list(self, cognis_module, mock_http):
        """get() returns CognisMemoryList."""
        mock_http.get.return_value = {"memories": [SAMPLE_MEMORY, SAMPLE_MEMORY_2]}

        memories = cognis_module.get(owner_id="owner_1")

        assert isinstance(memories, CognisMemoryList)
        assert len(memories) == 2
        assert isinstance(memories[0], CognisMemoryRecord)
        assert memories[0].content == "User likes hiking"

    def test_get_with_limit_and_offset(self, cognis_module, mock_http):
        """get() passes limit and offset parameters."""
        mock_http.get.return_value = {"memories": [SAMPLE_MEMORY]}

        cognis_module.get(owner_id="owner_1", limit=10, offset=5)

        params = mock_http.get.call_args[1]["params"]
        assert params["limit"] == 10
        assert params["offset"] == 5

    def test_get_with_agent_session(self, cognis_module, mock_http):
        """get() with agent_id + session_id."""
        mock_http.get.return_value = {"memories": [SAMPLE_MEMORY]}

        cognis_module.get(agent_id="agent_1", session_id="sess_1")

        params = mock_http.get.call_args[1]["params"]
        assert "owner_id" not in params
        assert params["agent_id"] == "agent_1"
        assert params["session_id"] == "sess_1"

    def test_get_iterable(self, cognis_module, mock_http):
        """CognisMemoryList supports iteration."""
        mock_http.get.return_value = {"memories": [SAMPLE_MEMORY, SAMPLE_MEMORY_2]}

        memories = cognis_module.get(owner_id="owner_1")

        contents = [m.content for m in memories]
        assert "User likes hiking" in contents
        assert "User lives in NYC" in contents

    def test_get_parses_list_response(self, cognis_module, mock_http):
        """get() handles list response format."""
        mock_http.get.return_value = [SAMPLE_MEMORY]

        memories = cognis_module.get(owner_id="owner_1")

        assert len(memories) == 1

    def test_get_memory_by_id(self, cognis_module, mock_http):
        """get_memory() returns single CognisMemoryRecord."""
        mock_http.get.return_value = SAMPLE_MEMORY

        memory = cognis_module.get_memory(memory_id="mem_abc123")

        assert isinstance(memory, CognisMemoryRecord)
        assert memory.id == "mem_abc123"
        assert memory.content == "User likes hiking"
        mock_http.get.assert_called_once_with(
            "/v1/memories/mem_abc123", params={}
        )

    def test_get_memory_with_owner(self, cognis_module, mock_http):
        """get_memory() passes owner_id."""
        mock_http.get.return_value = SAMPLE_MEMORY

        cognis_module.get_memory(memory_id="mem_abc123", owner_id="owner_1")

        params = mock_http.get.call_args[1]["params"]
        assert params["owner_id"] == "owner_1"


# ── Update Tests ──────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisUpdate:
    """Tests for update()."""

    def test_update_content(self, cognis_module, mock_http):
        """update() sends PATCH with new content."""
        updated = {**SAMPLE_MEMORY, "content": "User loves trail running"}
        mock_http.patch.return_value = {"success": True}
        mock_http.get.return_value = {"memory": updated}

        result = cognis_module.update(
            memory_id="mem_abc123",
            content="User loves trail running",
            owner_id="owner_1",
        )

        assert isinstance(result, CognisMemoryRecord)
        assert result.content == "User loves trail running"
        mock_http.patch.assert_called_once()
        call_args = mock_http.patch.call_args
        assert call_args[0][0] == "/v1/memories/mem_abc123"
        body = call_args[1]["json"]
        assert body["content"] == "User loves trail running"
        assert body["owner_id"] == "owner_1"

    def test_update_metadata(self, cognis_module, mock_http):
        """update() sends metadata."""
        mock_http.patch.return_value = {"success": True}
        mock_http.get.return_value = {"memory": SAMPLE_MEMORY}

        cognis_module.update(
            memory_id="mem_abc123",
            metadata={"category": "preference"},
        )

        body = mock_http.patch.call_args[1]["json"]
        assert body["metadata"] == {"category": "preference"}
        assert "content" not in body
        assert "owner_id" not in body

    def test_update_omits_none_fields(self, cognis_module, mock_http):
        """update() only sends non-None fields."""
        mock_http.patch.return_value = {"success": True}
        mock_http.get.return_value = {"memory": SAMPLE_MEMORY}

        cognis_module.update(memory_id="mem_abc123", content="new content")

        body = mock_http.patch.call_args[1]["json"]
        assert body == {"content": "new content"}


# ── Delete Tests ──────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisDelete:
    """Tests for delete() and delete_session()."""

    def test_delete_memory(self, cognis_module, mock_http):
        """delete() calls DELETE endpoint."""
        mock_http.delete.return_value = True

        result = cognis_module.delete(memory_id="mem_abc123", owner_id="owner_1")

        assert result is True
        mock_http.delete.assert_called_once()
        call_args = mock_http.delete.call_args
        assert call_args[0][0] == "/v1/memories/mem_abc123"
        assert call_args[1]["params"]["owner_id"] == "owner_1"

    def test_delete_without_owner(self, cognis_module, mock_http):
        """delete() works without owner_id."""
        mock_http.delete.return_value = True

        result = cognis_module.delete(memory_id="mem_abc123")

        assert result is True
        assert mock_http.delete.call_args[1]["params"] == {}

    def test_delete_session(self, cognis_module, mock_http):
        """delete_session() calls DELETE with body."""
        mock_http.delete.return_value = True

        result = cognis_module.delete_session(
            owner_id="owner_1",
            session_id="sess_1",
            agent_id="agent_1",
        )

        assert result is True
        call_args = mock_http.delete.call_args
        assert call_args[0][0] == "/v1/memories/session"
        body = call_args[1]["json_body"]
        assert body["owner_id"] == "owner_1"
        assert body["session_id"] == "sess_1"
        assert body["agent_id"] == "agent_1"


# ── Context Tests ─────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisContext:
    """Tests for context()."""

    def test_context_basic(self, cognis_module, mock_http):
        """context() returns context dict."""
        mock_http.post.return_value = SAMPLE_CONTEXT_RESPONSE

        ctx = cognis_module.context(
            current_messages=[{"role": "user", "content": "What do I enjoy?"}],
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert ctx["success"] is True
        assert ctx["has_long_term_memory"] is True
        assert ctx["short_term_count"] == 5
        assert ctx["long_term_count"] == 2
        assert len(ctx["context"]) == 2

    def test_context_with_cognis_messages(self, cognis_module, mock_http):
        """context() accepts CognisMessage objects."""
        mock_http.post.return_value = SAMPLE_CONTEXT_RESPONSE

        cognis_module.context(
            current_messages=[CognisMessage(role="user", content="test")],
            owner_id="owner_1",
            session_id="sess_1",
        )

        body = mock_http.post.call_args[1]["json"]
        assert body["current_messages"] == [{"role": "user", "content": "test"}]

    def test_context_with_parameters(self, cognis_module, mock_http):
        """context() passes all parameters."""
        mock_http.post.return_value = SAMPLE_CONTEXT_RESPONSE

        cognis_module.context(
            current_messages=[{"role": "user", "content": "test"}],
            owner_id="owner_1",
            session_id="sess_1",
            agent_id="agent_1",
            max_short_term_messages=50,
            enable_long_term_memory=False,
            cross_session=True,
        )

        body = mock_http.post.call_args[1]["json"]
        assert body["max_short_term_messages"] == 50
        assert body["enable_long_term_memory"] is False
        assert body["cross_session"] is True
        assert body["agent_id"] == "agent_1"

    def test_context_requires_owner_id(self, cognis_module):
        """context() with agent_id + session_id but no owner_id raises ValueError."""
        with pytest.raises(ValueError, match="owner_id is required"):
            cognis_module.context(
                current_messages=[{"role": "user", "content": "test"}],
                agent_id="agent_1",
                session_id="sess_1",
            )


# ── Messages Tests ────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisMessages:
    """Tests for get_messages()."""

    def test_get_messages_basic(self, cognis_module, mock_http):
        """get_messages() returns messages dict."""
        mock_http.get.return_value = SAMPLE_MESSAGES_RESPONSE

        msgs = cognis_module.get_messages(
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert msgs["success"] is True
        assert msgs["count"] == 2
        assert len(msgs["messages"]) == 2

    def test_get_messages_with_limit_and_latest(self, cognis_module, mock_http):
        """get_messages() passes limit and latest."""
        mock_http.get.return_value = SAMPLE_MESSAGES_RESPONSE

        cognis_module.get_messages(
            owner_id="owner_1",
            session_id="sess_1",
            limit=10,
            latest=True,
        )

        params = mock_http.get.call_args[1]["params"]
        assert params["limit"] == 10
        assert params["latest"] == "true"

    def test_get_messages_cross_session(self, cognis_module, mock_http):
        """get_messages() passes cross_session."""
        mock_http.get.return_value = SAMPLE_MESSAGES_RESPONSE

        cognis_module.get_messages(
            owner_id="owner_1",
            cross_session=True,
        )

        params = mock_http.get.call_args[1]["params"]
        assert params["cross_session"] == "true"


# ── Summaries Tests ───────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisSummaries:
    """Tests for summary operations."""

    def test_store_summary(self, cognis_module, mock_http):
        """store_summary() posts to summaries endpoint."""
        mock_http.post.return_value = SAMPLE_SUMMARY_RESPONSE

        result = cognis_module.store_summary(
            owner_id="owner_1",
            session_id="sess_1",
            content="User discussed hiking preferences",
            messages_covered_count=4,
            agent_id="agent_1",
        )

        assert result["success"] is True
        assert result["summary_id"] == "sum_123"

        body = mock_http.post.call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert body["session_id"] == "sess_1"
        assert body["content"] == "User discussed hiking preferences"
        assert body["messages_covered_count"] == 4
        assert body["agent_id"] == "agent_1"

    def test_store_summary_without_agent(self, cognis_module, mock_http):
        """store_summary() omits agent_id when not provided."""
        mock_http.post.return_value = SAMPLE_SUMMARY_RESPONSE

        cognis_module.store_summary(
            owner_id="owner_1",
            session_id="sess_1",
            content="Summary content",
            messages_covered_count=2,
        )

        body = mock_http.post.call_args[1]["json"]
        assert "agent_id" not in body

    def test_get_current_summary(self, cognis_module, mock_http):
        """get_current_summary() fetches current summary."""
        mock_http.get.return_value = SAMPLE_CURRENT_SUMMARY_RESPONSE

        result = cognis_module.get_current_summary(
            owner_id="owner_1",
            session_id="sess_1",
        )

        assert result["success"] is True
        assert result["summary"]["summary_id"] == "sum_123"

        params = mock_http.get.call_args[1]["params"]
        assert params["owner_id"] == "owner_1"
        assert params["session_id"] == "sess_1"

    def test_search_summaries(self, cognis_module, mock_http):
        """search_summaries() posts search query."""
        mock_http.post.return_value = SAMPLE_SEARCH_SUMMARIES_RESPONSE

        result = cognis_module.search_summaries(
            owner_id="owner_1",
            query="hiking",
            limit=3,
        )

        assert result["success"] is True
        assert result["count"] == 1

        body = mock_http.post.call_args[1]["json"]
        assert body["owner_id"] == "owner_1"
        assert body["query"] == "hiking"
        assert body["limit"] == 3

    def test_search_summaries_with_session(self, cognis_module, mock_http):
        """search_summaries() passes session_id."""
        mock_http.post.return_value = SAMPLE_SEARCH_SUMMARIES_RESPONSE

        cognis_module.search_summaries(
            owner_id="owner_1",
            query="hiking",
            session_id="sess_1",
        )

        body = mock_http.post.call_args[1]["json"]
        assert body["session_id"] == "sess_1"


# ── Helpers Tests ─────────────────────────────────────────────────

@pytest.mark.cognis
class TestCognisHelpers:
    """Tests for internal helper methods."""

    def test_normalize_messages_dicts(self):
        """_normalize_messages passes dicts through."""
        msgs = [{"role": "user", "content": "Hello"}]
        result = CognisModule._normalize_messages(msgs)
        assert result == [{"role": "user", "content": "Hello"}]

    def test_normalize_messages_cognis(self):
        """_normalize_messages converts CognisMessage to dict."""
        msgs = [CognisMessage(role="user", content="Hello")]
        result = CognisModule._normalize_messages(msgs)
        assert result == [{"role": "user", "content": "Hello"}]

    def test_normalize_messages_mixed(self):
        """_normalize_messages handles mixed list."""
        msgs = [
            {"role": "user", "content": "Hello"},
            CognisMessage(role="assistant", content="Hi!"),
        ]
        result = CognisModule._normalize_messages(msgs)
        assert result == [
            {"role": "user", "content": "Hello"},
            {"role": "assistant", "content": "Hi!"},
        ]

    def test_build_id_body_all(self):
        """_build_id_body includes all non-None IDs."""
        body = CognisModule._build_id_body("owner", "agent", "session")
        assert body == {"owner_id": "owner", "agent_id": "agent", "session_id": "session"}

    def test_build_id_body_partial(self):
        """_build_id_body omits None values."""
        body = CognisModule._build_id_body("owner", None, "session")
        assert body == {"owner_id": "owner", "session_id": "session"}
        assert "agent_id" not in body

    def test_build_id_body_empty(self):
        """_build_id_body returns empty dict when all None."""
        body = CognisModule._build_id_body(None, None, None)
        assert body == {}

    def test_parse_search_results_list(self):
        """_parse_search_results handles list response."""
        results = CognisModule._parse_search_results([SAMPLE_SEARCH_RESULT])
        assert len(results) == 1
        assert isinstance(results[0], CognisSearchResult)

    def test_parse_search_results_dict(self):
        """_parse_search_results handles dict response."""
        results = CognisModule._parse_search_results({"results": [SAMPLE_SEARCH_RESULT]})
        assert len(results) == 1

    def test_parse_memory_list_dict(self):
        """_parse_memory_list handles dict response."""
        records = CognisModule._parse_memory_list({"memories": [SAMPLE_MEMORY]})
        assert len(records) == 1
        assert isinstance(records[0], CognisMemoryRecord)

    def test_parse_memory_list_plain_list(self):
        """_parse_memory_list handles plain list response."""
        records = CognisModule._parse_memory_list([SAMPLE_MEMORY])
        assert len(records) == 1
