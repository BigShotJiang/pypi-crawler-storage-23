# vim: set filetype=python fileencoding=utf-8:
# -*- coding: utf-8 -*-

#============================================================================#
#                                                                            #
#  Licensed under the Apache License, Version 2.0 (the "License");           #
#  you may not use this file except in compliance with the License.          #
#  You may obtain a copy of the License at                                   #
#                                                                            #
#      http://www.apache.org/licenses/LICENSE-2.0                            #
#                                                                            #
#  Unless required by applicable law or agreed to in writing, software       #
#  distributed under the License is distributed on an "AS IS" BASIS,         #
#  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.  #
#  See the License for the specific language governing permissions and       #
#  limitations under the License.                                            #
#                                                                            #
#============================================================================#


''' Codex CLI renderer implementation.

    Provides path resolution and targeting mode validation for Codex CLI.
'''


from . import __
from .base import RENDERERS as _RENDERERS
from .base import ExplicitTargetMode as _ExplicitTargetMode
from .base import RendererBase as _RendererBase
from .base import extract_coder_configuration as _extract_coder_configuration


class CodexRenderer( _RendererBase ):
    ''' Renderer for Codex CLI coder.

        Supports both per-user and per-project configuration modes.

        Per-project mode stores configuration under
        `.auxiliary/configuration/coders/codex/` and exposes it via a
        `.codex` symlink at project root (created by population logic).

        Per-user mode respects CODEX_HOME environment variable with fallback
        to configuration overrides and default location.
    '''

    name = 'codex'
    modes_available = frozenset( ( 'per-user', 'per-project' ) )
    mode_default = 'per-project'
    memory_filename = 'AGENTS.md'
    item_types_available = frozenset( ( 'skills', ) )

    def get_template_flavor( self, item_type: str ) -> str:
        ''' Determines template flavor for Codex CLI.

            Codex uses same markdown format as Claude for all item types,
            so always returns 'claude' flavor.
        '''
        return 'claude'

    def provide_project_symlinks(
        self, target: __.Path
    ) -> __.cabc.Sequence[ tuple[ __.Path, __.Path ] ]:
        ''' Provides symlinks required for Codex CLI in per-project mode.

            Codex expects project configuration under `.codex/`. We keep the
            canonical configuration under `.auxiliary/configuration/` and
            expose it via the standard coder directory symlink.
        '''
        return super( ).provide_project_symlinks( target )

    def resolve_base_directory(
        self,
        mode: _ExplicitTargetMode,
        target: __.Path,
        configuration: __.cabc.Mapping[ str, __.typx.Any ],
        environment: __.cabc.Mapping[ str, str ],
    ) -> __.Path:
        ''' Resolves base output directory for Codex CLI.

            Per-project: `.auxiliary/configuration/coders/codex/`
            Per-user: respects precedence: CODEX_HOME environment variable,
            configuration file override (home key), or default `~/.codex`.
        '''
        self.validate_mode( mode )
        if mode == 'per-project':
            return target / ".auxiliary/configuration/coders/codex"
        if mode == 'per-user':
            return self._resolve_user_directory( configuration, environment )
        raise __.TargetModeNoSupport( self.name, mode )

    def _resolve_user_directory(
        self,
        configuration: __.cabc.Mapping[ str, __.typx.Any ],
        environment: __.cabc.Mapping[ str, str ],
    ) -> __.Path:
        ''' Resolves per-user directory following precedence rules.

            Precedence order:
            1. CODEX_HOME environment variable
            2. Configuration file override (home key for this coder)
            3. Default ~/.codex location
        '''
        if 'CODEX_HOME' in environment:
            directory = __.Path( environment[ 'CODEX_HOME' ] )
            return directory.expanduser( )
        coder_configuration = self._extract_coder_configuration(
            configuration )
        if 'home' in coder_configuration:
            directory = __.Path( coder_configuration[ 'home' ] )
            return directory.expanduser( )
        return __.Path.home( ) / '.codex'

    def _extract_coder_configuration(
        self, configuration: __.cabc.Mapping[ str, __.typx.Any ]
    ) -> __.cabc.Mapping[ str, __.typx.Any ]:
        ''' Extracts configuration for this specific coder.

            Looks for coder entry in configuration coders array by name.
        '''
        return _extract_coder_configuration( configuration, self.name )


_RENDERERS[ 'codex' ] = CodexRenderer( )
