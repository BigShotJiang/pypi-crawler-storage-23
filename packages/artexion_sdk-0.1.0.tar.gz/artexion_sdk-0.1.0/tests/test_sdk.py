"""
Artexion SDK Tests
==================
Unit tests for the Artexion Python SDK.
"""

from unittest.mock import Mock, patch

import httpx
import pytest

from artexion_sdk import Client, Task

VALID_API_KEY = "atx_test_1234567890abcdef1234567890"


SAMPLE_TASK_RESPONSE = {
    "task_id": "task_abc123",
    "status": "success",
    "result": "Summarized email content goes here",
    "error": None,
    "cost_usd": 0.015,
    "duration_seconds": 2.5,
}

SAMPLE_USAGE_RESPONSE = {
    "user_id": 123,
    "email": "user@example.com",
    "plan": "pro",
    "monthly_requests": 5000,
    "monthly_task_executions": 150,
    "total_usage_usd": 24.50,
    "rate_limit_per_minute": 100,
    "max_timeout_seconds": 300,
}


def _response(
    method: str,
    path: str,
    status_code: int = 200,
    json_payload=None,
    headers=None,
):
    request = httpx.Request(method, f"https://api.artexion.cloud{path}")
    return httpx.Response(status_code, json=json_payload, headers=headers, request=request)


class TestTask:
    def test_task_attributes(self):
        task = Task(SAMPLE_TASK_RESPONSE)

        assert task.id == "task_abc123"
        assert task.status == "success"
        assert task.result == "Summarized email content goes here"
        assert task.error is None
        assert task.cost_usd == 0.015

    def test_task_repr(self):
        task = Task(SAMPLE_TASK_RESPONSE)
        repr_str = repr(task)

        assert "task_abc123" in repr_str
        assert "success" in repr_str

    def test_task_with_error(self):
        error_response = {
            "task_id": "task_failed",
            "status": "failed",
            "result": None,
            "error": "API rate limit exceeded",
            "cost_usd": 0.0,
        }
        task = Task(error_response)

        assert task.status == "failed"
        assert task.error == "API rate limit exceeded"
        assert task.result is None


class TestClient:
    def test_client_initialization(self):
        client = Client(api_key=VALID_API_KEY)
        assert client.api_key == VALID_API_KEY
        assert client.base_url == "https://api.artexion.cloud"

    def test_client_initialization_custom_url(self):
        client = Client(api_key=VALID_API_KEY, base_url="https://localhost:8000")
        assert client.base_url == "https://localhost:8000"

    def test_client_initialization_missing_key(self):
        with pytest.raises(ValueError, match="api_key is required"):
            Client(api_key="")

    def test_client_initialization_invalid_key_format(self):
        with pytest.raises(ValueError, match="atx_live"):
            Client(api_key="invalid")

    def test_client_from_env(self, monkeypatch):
        monkeypatch.setenv("ARTEXION_API_KEY", VALID_API_KEY)
        client = Client.from_env()
        assert client.api_key == VALID_API_KEY

    @patch("artexion.client.httpx.Client")
    def test_run_task_sync(self, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "POST", "/api/v1/tasks/execute", json_payload=SAMPLE_TASK_RESPONSE
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        task = client.run("Summarize emails", max_steps=8, wait=True)

        assert task.id == "task_abc123"
        assert task.status == "success"
        assert task.result == "Summarized email content goes here"
        assert mock_http_instance.request.call_count == 1

    @patch("artexion.client.httpx.Client")
    def test_run_task_async(self, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "POST",
            "/api/v1/tasks/execute",
            json_payload={
                "task_id": "task_pending",
                "status": "queued",
                "result": None,
                "error": None,
                "cost_usd": 0.0,
            },
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        task = client.run("Process data", wait=False)

        assert task.id == "task_pending"
        assert task.status == "queued"

    @patch("artexion.client.httpx.Client")
    def test_get_task(self, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "GET", "/api/v1/tasks/task_abc123", json_payload=SAMPLE_TASK_RESPONSE
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        task = client.get_task("task_abc123")

        assert task.id == "task_abc123"
        assert task.status == "success"

    @patch("artexion.client.httpx.Client")
    def test_get_trace(self, mock_http_client):
        trace_data = {
            "task_id": "task_abc123",
            "steps": [
                {"action": "fetch_emails", "result": "Found 15 emails"},
                {"action": "summarize", "result": "Summary generated"},
            ],
        }
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "GET", "/api/v1/tasks/task_abc123/trace", json_payload=trace_data
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        trace = client.get_trace("task_abc123")

        assert len(trace["steps"]) == 2
        assert trace["steps"][0]["action"] == "fetch_emails"

    @patch("artexion.client.httpx.Client")
    def test_get_usage(self, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "GET", "/api/v1/tasks/usage", json_payload=SAMPLE_USAGE_RESPONSE
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        usage = client.get_usage()

        assert usage["email"] == "user@example.com"
        assert usage["plan"] == "pro"
        assert usage["total_usage_usd"] == 24.50

    @patch("artexion.client.httpx.Client")
    def test_context_manager(self, mock_http_client):
        mock_http_instance = Mock()
        mock_http_client.return_value = mock_http_instance

        with Client(api_key=VALID_API_KEY) as client:
            assert client is not None

        mock_http_instance.close.assert_called_once()

    @patch("artexion.client.httpx.Client")
    @patch("artexion.client.time.sleep")
    def test_wait_for_completion_timeout(self, mock_sleep, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "GET",
            "/api/v1/tasks/task_slow",
            json_payload={
                "task_id": "task_slow",
                "status": "queued",
                "result": None,
                "error": None,
                "cost_usd": 0.0,
            },
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)

        with pytest.raises(TimeoutError):
            client._wait_for_completion("task_slow", poll_interval=0.01, max_wait=0.02)

    @patch("artexion.client.httpx.Client")
    @patch("artexion.client.time.sleep")
    def test_retries_safe_get_requests(self, mock_sleep, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.side_effect = [
            _response("GET", "/api/v1/tasks/usage", status_code=503, json_payload={"detail": "busy"}),
            _response("GET", "/api/v1/tasks/usage", status_code=200, json_payload=SAMPLE_USAGE_RESPONSE),
        ]
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY, max_retries=2)
        usage = client.get_usage()

        assert usage["email"] == "user@example.com"
        assert mock_http_instance.request.call_count == 2

    @patch("artexion.client.httpx.Client")
    @patch("artexion.client.time.sleep")
    def test_does_not_retry_post_without_task_id(self, mock_sleep, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.return_value = _response(
            "POST", "/api/v1/tasks/execute", status_code=503, json_payload={"detail": "busy"}
        )
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY, max_retries=2)

        with pytest.raises(httpx.HTTPStatusError):
            client.run("do something", wait=False)

        assert mock_http_instance.request.call_count == 1

    @patch("artexion.client.httpx.Client")
    @patch("artexion.client.time.sleep")
    def test_retries_post_with_task_id(self, mock_sleep, mock_http_client):
        mock_http_instance = Mock()
        mock_http_instance.request.side_effect = [
            _response("POST", "/api/v1/tasks/execute", status_code=503, json_payload={"detail": "busy"}),
            _response("POST", "/api/v1/tasks/execute", status_code=200, json_payload=SAMPLE_TASK_RESPONSE),
        ]
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY, max_retries=2)
        task = client.run("do something", wait=False, task_id="retry-safe-task")

        assert task.id == "task_abc123"
        assert mock_http_instance.request.call_count == 2


class TestSDKIntegration:
    @patch("artexion.client.httpx.Client")
    def test_full_workflow(self, mock_http_client):
        task_response = SAMPLE_TASK_RESPONSE.copy()
        trace_response = {
            "task_id": "task_abc123",
            "steps": [
                {"action": "authenticate", "result": "Success"},
                {"action": "execute", "result": "Summary ready"},
            ],
        }

        mock_http_instance = Mock()
        mock_http_instance.request.side_effect = [
            _response("POST", "/api/v1/tasks/execute", json_payload=task_response),
            _response("GET", "/api/v1/tasks/task_abc123/trace", json_payload=trace_response),
        ]
        mock_http_client.return_value = mock_http_instance

        client = Client(api_key=VALID_API_KEY)
        task = client.run("Test task", wait=False)
        trace = client.get_trace(task.id)

        assert task.id == "task_abc123"
        assert len(trace["steps"]) == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
