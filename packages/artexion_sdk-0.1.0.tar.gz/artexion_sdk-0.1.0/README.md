# Artexion Python SDK

Official Python client for the Artexion Cloud API.

This package is safe to publish independently from your backend codebase.
It only ships the client library (`artexion`) and does not include server
implementation details.

## Install

```bash
pip install artexion-sdk
```

## Quick Start

```python
from artexion import Client

client = Client(api_key="atx_live_your_api_key_here")
task = client.run("Summarize my unread emails", max_steps=8)

print(task.id, task.status)
print(task.result)
```

## Backward-Compatible Import

```python
from artexion_sdk import Client
```

## Requirements

- Python 3.8+
- `httpx>=0.25.0,<1.0.0`

## Release

See `PUBLISH.md` for exact build and upload commands.

## License

Apache License 2.0 (`Apache-2.0`). See `LICENSE`.
