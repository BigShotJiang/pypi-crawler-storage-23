"""
Artexion Cloud Python SDK
=========================

Minimal, clean client library for Artexion Cloud API.

Example:
    from artexion import Client
    
    client = Client(api_key="atx_live_example_key_1234567890")
    task = client.run("Summarize my emails", max_steps=8)
    print(task.result)

Installation:
    pip install artexion-sdk

Documentation:
    https://docs.artexion.cloud/sdk
"""

__version__ = "0.1.0"
__author__ = "Artexion Team"
__license__ = "Apache-2.0"

from .client import Client, Task

__all__ = [
    "Client",
    "Task",
    "__version__",
]
