"""
Artexion Python SDK core client.
"""

from __future__ import annotations

import os
import re
import time
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from typing import Any, Dict, Optional, Union
from urllib.parse import urlparse

import httpx

_API_KEY_PATTERN = re.compile(r"^atx_(?:live|test)_[A-Za-z0-9_-]{20,256}$")
_TASK_ID_PATTERN = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")
_IN_PROGRESS_STATUSES = {"created", "planned", "queued", "running", "pending"}
_TERMINAL_STATUSES = {"success", "succeeded", "failed", "completed"}
_RETRYABLE_STATUS_CODES = {408, 429, 500, 502, 503, 504}


def _normalize_status(value: str) -> str:
    return value.strip().lower()


class Task:
    """Represents a task execution result."""

    def __init__(self, data: Dict[str, Any]):
        self._data = data

    @property
    def id(self) -> str:
        return str(self._data.get("task_id") or self._data.get("id", ""))

    @property
    def status(self) -> str:
        return str(self._data.get("status", ""))

    @property
    def result(self) -> Any:
        return self._data.get("result")

    @property
    def error(self) -> Optional[str]:
        error = self._data.get("error")
        return str(error) if error is not None else None

    @property
    def cost_usd(self) -> float:
        raw_cost = self._data.get("cost_usd", 0.0)
        try:
            return float(raw_cost)
        except (TypeError, ValueError):
            return 0.0

    @property
    def failure(self) -> Optional[Dict[str, Any]]:
        value = self._data.get("failure")
        return value if isinstance(value, dict) else None

    @property
    def raw(self) -> Dict[str, Any]:
        return dict(self._data)

    def __repr__(self) -> str:
        return f"Task(id={self.id}, status={self.status})"


class Client:
    """Artexion Cloud API client with production-safe defaults."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "https://api.artexion.cloud",
        timeout: Union[int, float, httpx.Timeout] = 60,
        max_retries: int = 2,
        retry_backoff_factor: float = 0.5,
        retry_max_backoff: float = 8.0,
    ) -> None:
        resolved_api_key = (api_key or os.getenv("ARTEXION_API_KEY", "")).strip()
        if not resolved_api_key:
            raise ValueError("api_key is required (or set ARTEXION_API_KEY)")
        if not _API_KEY_PATTERN.fullmatch(resolved_api_key):
            raise ValueError(
                "api_key must match atx_live_* or atx_test_* format with a secure token suffix"
            )

        self._validate_base_url(base_url)

        if max_retries < 0:
            raise ValueError("max_retries must be >= 0")
        if retry_backoff_factor < 0:
            raise ValueError("retry_backoff_factor must be >= 0")
        if retry_max_backoff <= 0:
            raise ValueError("retry_max_backoff must be > 0")

        self.api_key = resolved_api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self.max_retries = max_retries
        self.retry_backoff_factor = retry_backoff_factor
        self.retry_max_backoff = retry_max_backoff

        self._client = httpx.Client(
            base_url=self.base_url,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Accept": "application/json",
                "User-Agent": "artexion-sdk/0.1.0",
            },
            timeout=self._build_timeout(timeout),
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
        )

    @classmethod
    def from_env(cls, api_key_env: str = "ARTEXION_API_KEY", **kwargs: Any) -> "Client":
        api_key = os.getenv(api_key_env, "").strip()
        if not api_key:
            raise ValueError(f"{api_key_env} is not set")
        return cls(api_key=api_key, **kwargs)

    @staticmethod
    def _build_timeout(value: Union[int, float, httpx.Timeout]) -> httpx.Timeout:
        if isinstance(value, httpx.Timeout):
            return value
        if isinstance(value, (int, float)):
            timeout = float(value)
            if timeout <= 0:
                raise ValueError("timeout must be > 0")
            connect_timeout = min(timeout, 10.0)
            return httpx.Timeout(timeout=timeout, connect=connect_timeout)
        raise ValueError("timeout must be an int, float, or httpx.Timeout")

    @staticmethod
    def _validate_base_url(base_url: str) -> None:
        parsed = urlparse(base_url)
        if parsed.scheme not in {"http", "https"} or not parsed.netloc:
            raise ValueError("base_url must be a valid http(s) URL")

    @staticmethod
    def _parse_retry_after_seconds(value: Optional[str]) -> Optional[float]:
        if value is None:
            return None

        raw = value.strip()
        if not raw:
            return None

        try:
            seconds = float(raw)
            return max(0.0, seconds)
        except ValueError:
            pass

        try:
            retry_at = parsedate_to_datetime(raw)
            if retry_at.tzinfo is None:
                retry_at = retry_at.replace(tzinfo=timezone.utc)
            seconds = (retry_at - datetime.now(timezone.utc)).total_seconds()
            return max(0.0, seconds)
        except (TypeError, ValueError):
            return None

    def _retry_sleep(self, attempt: int, retry_after_seconds: Optional[float]) -> None:
        if retry_after_seconds is not None:
            delay = min(self.retry_max_backoff, retry_after_seconds)
        else:
            delay = min(self.retry_max_backoff, self.retry_backoff_factor * (2**attempt))

        if delay > 0:
            time.sleep(delay)

    @staticmethod
    def _extract_error_message(response: httpx.Response) -> str:
        raw = response.text.strip()
        if not raw:
            return f"Request failed with status {response.status_code}"

        try:
            payload = response.json()
        except ValueError:
            return raw

        if isinstance(payload, dict):
            detail = payload.get("detail")
            if isinstance(detail, str) and detail.strip():
                return detail.strip()

            message = payload.get("message")
            if isinstance(message, str) and message.strip():
                return message.strip()

        return raw

    def _raise_for_status(self, response: httpx.Response) -> None:
        message = self._extract_error_message(response)
        request = response.request
        enriched_message = f"{request.method} {request.url.path} -> {response.status_code}: {message}"
        raise httpx.HTTPStatusError(enriched_message, request=request, response=response)

    @staticmethod
    def _parse_json_or_raise(response: httpx.Response) -> Dict[str, Any]:
        try:
            payload = response.json()
        except ValueError as exc:
            raise RuntimeError(
                f"Invalid JSON response from {response.request.method} {response.request.url.path}"
            ) from exc

        if not isinstance(payload, dict):
            raise RuntimeError(
                f"Unexpected response shape from {response.request.method} {response.request.url.path}"
            )
        return payload

    def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[Dict[str, Any]] = None,
        retry_safe: bool = False,
    ) -> httpx.Response:
        attempt = 0

        while True:
            try:
                response = self._client.request(method=method, url=path, json=json)
            except httpx.RequestError:
                if retry_safe and attempt < self.max_retries:
                    self._retry_sleep(attempt, None)
                    attempt += 1
                    continue
                raise

            if response.status_code < 400:
                return response

            is_retryable_status = response.status_code in _RETRYABLE_STATUS_CODES
            if retry_safe and is_retryable_status and attempt < self.max_retries:
                retry_after = self._parse_retry_after_seconds(response.headers.get("Retry-After"))
                self._retry_sleep(attempt, retry_after)
                attempt += 1
                continue

            self._raise_for_status(response)

    def run(
        self,
        prompt: str,
        max_steps: int = 10,
        timeout_seconds: Optional[int] = None,
        wait: bool = True,
        poll_interval: float = 1.0,
        task_id: Optional[str] = None,
        resource_units: float = 1.0,
    ) -> Task:
        if not isinstance(prompt, str) or not prompt.strip():
            raise ValueError("prompt must be a non-empty string")
        if max_steps <= 0:
            raise ValueError("max_steps must be > 0")
        if timeout_seconds is not None and timeout_seconds <= 0:
            raise ValueError("timeout_seconds must be > 0")
        if poll_interval <= 0:
            raise ValueError("poll_interval must be > 0")
        if resource_units <= 0:
            raise ValueError("resource_units must be > 0")

        payload: Dict[str, Any] = {
            "prompt": prompt,
            "max_steps": max_steps,
            "resource_units": resource_units,
        }

        safe_task_id: Optional[str] = None
        if task_id is not None:
            safe_task_id = task_id.strip()
            if not _TASK_ID_PATTERN.fullmatch(safe_task_id):
                raise ValueError(
                    "task_id must be 1-128 chars and use only letters, digits, '.', '_', ':', or '-'"
                )
            payload["task_id"] = safe_task_id

        if timeout_seconds is not None:
            payload["timeout_seconds"] = timeout_seconds

        # POST retries are only safe when caller provides deterministic task_id (idempotency contract).
        response = self._request(
            "POST",
            "/api/v1/tasks/execute",
            json=payload,
            retry_safe=bool(safe_task_id),
        )
        task = Task(self._parse_json_or_raise(response))

        if wait and _normalize_status(task.status) in _IN_PROGRESS_STATUSES:
            task = self._wait_for_completion(task.id, poll_interval=poll_interval)
        return task

    def get_task(self, task_id: str) -> Task:
        response = self._request("GET", f"/api/v1/tasks/{task_id}", retry_safe=True)
        return Task(self._parse_json_or_raise(response))

    def get_trace(self, task_id: str) -> Dict[str, Any]:
        response = self._request("GET", f"/api/v1/tasks/{task_id}/trace", retry_safe=True)
        return self._parse_json_or_raise(response)

    def get_usage(self) -> Dict[str, Any]:
        response = self._request("GET", "/api/v1/tasks/usage", retry_safe=True)
        return self._parse_json_or_raise(response)

    def _wait_for_completion(
        self,
        task_id: str,
        poll_interval: float = 1.0,
        max_wait: float = 3600.0,
    ) -> Task:
        if poll_interval <= 0:
            raise ValueError("poll_interval must be > 0")
        if max_wait <= 0:
            raise ValueError("max_wait must be > 0")

        deadline = time.monotonic() + max_wait

        while time.monotonic() < deadline:
            task = self.get_task(task_id)
            if _normalize_status(task.status) in _TERMINAL_STATUSES:
                return task
            time.sleep(poll_interval)

        raise TimeoutError(f"Task {task_id} did not complete within {max_wait}s")

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "Client":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:  # noqa: ANN001
        self.close()


__all__ = ["Client", "Task"]
