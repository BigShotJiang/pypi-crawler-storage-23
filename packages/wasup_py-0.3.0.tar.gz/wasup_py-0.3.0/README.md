# wasup-py

A stateful WhatsApp API Wrapper for Python with built-in conversation flow management. Currently supports abstraction for Azure Communication Services.

## Example

```python
import os

from wasup import Bot
from wasup.bindings.azure import AzureBindingClient
from wasup.messages import TextMessage
from wasup.messages.dialogs import Dialog, DialogTurnResult, DialogTurnStatus, DialogContext

# initialize dialog with name and main flag
@Dialog.set(name="GreetingDialog", main=True)
class GreetingDialog(Dialog):
    """A simple greeting dialog that asks for the user's name."""

    @Dialog.step()
    @Dialog.store("user_name")
    async def ask_name(self, dc: DialogContext):
        """Ask the user for their name."""
        message = TextMessage(ctx=dc.ctx, message="Hello! 👋 What's your name?")
        await dc.message.send(message)
        return DialogTurnResult(DialogTurnStatus.Waiting)

    @Dialog.step()
    async def greet_user(self, dc: DialogContext):
        """Greet the user by name."""
        name = dc.get_value("user_name")
        message = TextMessage(ctx=dc.ctx, message=f"Nice to meet you, {name}! 😊")
        await dc.message.send(message)
        return DialogTurnResult(DialogTurnStatus.Complete)

# create bot instance
bot = Bot()

# load all dialogs
bot.load_dialog(GreetingDialog)

# initialize azure client
acs_client = NotificationMessagesClient.from_connection_string(os.getenv("AZURE_COMMUNICATION_ENDPOINT"))
azure_binding = AzureBindingClient(
    ctx=bot,
    client=acs_client,
    route="/api/whatsapp/events",
)

# run the bot with azure binding
bot.run(azure_binding)
```

## Installation

### Basic Installation

```bash
pip install wasup-py
```

### With Provider Support

**Azure Communication Services:**

```bash
pip install wasup-py[azure]
```

**Development:**

```bash
pip install wasup-py[dev]
```
