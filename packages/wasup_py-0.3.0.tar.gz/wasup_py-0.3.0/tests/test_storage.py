"""Unit tests for InMemoryStore: awaiting flag, correlation_id."""

import pytest

from whatsapp.middleware.storage import InMemoryStore


@pytest.fixture
def store():
    return InMemoryStore()


@pytest.mark.asyncio
async def test_awaiting_flag_defaults_false(store):
    assert await store.get_awaiting_flag("user-1") is False


@pytest.mark.asyncio
async def test_awaiting_flag_set_true(store):
    await store.set_awaiting_flag("user-2", True)
    assert await store.get_awaiting_flag("user-2") is True


@pytest.mark.asyncio
async def test_awaiting_flag_clear(store):
    await store.set_awaiting_flag("user-3", True)
    await store.set_awaiting_flag("user-3", False)
    assert await store.get_awaiting_flag("user-3") is False


@pytest.mark.asyncio
async def test_awaiting_flag_isolated_between_users(store):
    await store.set_awaiting_flag("user-4", True)
    assert await store.get_awaiting_flag("user-5") is False


@pytest.mark.asyncio
async def test_correlation_id_defaults_none(store):
    assert await store.get_correlation_id("user-6") is None


@pytest.mark.asyncio
async def test_correlation_id_round_trip(store):
    await store.set_correlation_id("user-7", "corr-abc-123")
    assert await store.get_correlation_id("user-7") == "corr-abc-123"


@pytest.mark.asyncio
async def test_correlation_id_overwrite(store):
    await store.set_correlation_id("user-8", "first")
    await store.set_correlation_id("user-8", "second")
    assert await store.get_correlation_id("user-8") == "second"


@pytest.mark.asyncio
async def test_correlation_id_isolated_between_users(store):
    await store.set_correlation_id("user-9", "corr-xyz")
    assert await store.get_correlation_id("user-10") is None
