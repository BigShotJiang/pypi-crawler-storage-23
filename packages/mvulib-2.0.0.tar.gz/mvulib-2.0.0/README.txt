Maximum Variance Unfolding (MVU) dimensionality reduction
algorithm implemented in MATLAB with use of SeDuMi 
(Self Dual Minimization) package for solving semidefinite
programming. MATLAB Runtime 24.1 installation is required. It 
can be downloaded from the following address:
https://www.mathworks.com/products/compiler/matlab-runtime.html.
Also, Runtime installation must be added to PATH. 
Supported Python versions are >=3.9.X, <=3.11.X. Package 
includes Mvu Python class that serves as an interface to 
MATLAB implementation. Upon installation the Mvu class is 
instantiated and operated in a way similar to that of other 
sklearn dimensionality reduction classes. For example:

from mvulib.mvu import Mvu
from sklearn.datasets import make_swiss_roll
X, t=make_swiss_roll(n_samples=800, random_state=0)
mvu=Mvu(n_neighbors=6, angles=2, slack=1)
Y=mvu.fit_transform(X, 2) # Two dimensional embedding.

NOTE: Implementation is based on the following paper
K.Q.Weinberger, L.K.Saul. "Unsupervised Learning of Image 
Manifolds by Semidefinite Programming".

NOTE: MVU is time consuming and it is best used on datasets
with relatively small number of samples n<=2000 and arbitrary 
number of features. Examples using "weak" angles=0 
graph construction complete in 10 minutes for datasets with 
n=800 samples. On datasets with higher number of samples
n>1000 and n<=2000 small neighborhoods are advised
similar to choice of k=6 in example above.
Datasets with n=2000 samples complete within 90 minutes 
on angles=0 setting. On angles=2 setting execution can take 
long time (but does eventually complete).

NOTE: This is "private build" in some sense and thus package
is not publicly documented. However, "documentation" .ipynb 
notebooks exist and can be obtained by contacting author on
following e-mail:
stanicrikard7@gmail.com.