Extending MPF
=============

These guides explain how to setup a dev environment for extending and adding to MPF itself, and how to add various
components to MPF.

.. toctree::
   :maxdepth: 1

   dev_environment
   plugins
   hardware
   event_annotations
