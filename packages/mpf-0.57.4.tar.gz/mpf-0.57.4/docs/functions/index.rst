Common functions to use in your code
====================================

.. toctree::
   :maxdepth: 1

   machine_variables
   player_variables
