mode_stop (BCP command)
=======================

Indicates the mode has stopped.

Origin
------
Pin controller

Parameters
----------

name
~~~~

Type: ``string``

The mode name.

Response
--------
None
