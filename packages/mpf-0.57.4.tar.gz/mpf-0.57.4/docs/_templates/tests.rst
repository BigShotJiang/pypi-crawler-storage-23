{name}
{module_underline}

.. autoclass:: {full_path_to_class}
   :members:
   :inherited-members:
   :show-inheritance:
   :exclude-members: addCleanup, addTypeEqualityFunc, debug, doCleanups, failureException, setUpClass, subTest, tearDownClass, configure_logging, debug_log, error_log, info_log

   .. rubric:: Methods & Attributes

   The {name} has the following methods & attributes available. Note that methods & attributes inherited from
   the base class are not included here.