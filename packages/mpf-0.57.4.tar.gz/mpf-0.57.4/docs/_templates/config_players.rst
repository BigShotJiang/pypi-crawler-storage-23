self.machine.{name}
{module_underline}

.. autoclass:: {full_path_to_class}
   :members:
   :show-inheritance:

   .. rubric:: Accessing the {name} in code

   The {name} is available via ``self.machine.{name}``.

   .. rubric:: Methods & Attributes

   The {name} has the following methods & attributes available. Note that methods & attributes inherited from
   the base class are not included here.