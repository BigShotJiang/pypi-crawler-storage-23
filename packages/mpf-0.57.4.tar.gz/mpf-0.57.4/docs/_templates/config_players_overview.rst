Config Players
==============

Config players are available as machine attributes in the form of their player name plus ``_player``, for example,
``self.machine.light_player`` or ``self.machine.score_player``.

.. toctree::

{config_players}