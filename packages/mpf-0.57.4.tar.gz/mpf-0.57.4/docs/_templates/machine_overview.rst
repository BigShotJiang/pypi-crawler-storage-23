Core Components
===============

Core MPF machine components, accessible to programmers at ``self.machine.*name*``. For example, the ball controller
is at ``self.machine.ball_controller``, the event manager is ``self.machine.events``, etc.

.. toctree::

{machine}