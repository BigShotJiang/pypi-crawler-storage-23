"""Penny K Pinball PKONE Hardware Platform."""
