"""LISY System 1/80 platform."""
