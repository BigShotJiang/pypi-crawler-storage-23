"""Stern SPIKE platform."""
