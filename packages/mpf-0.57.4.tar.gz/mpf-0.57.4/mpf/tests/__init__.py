"""Unit tests for the MPF framework."""
