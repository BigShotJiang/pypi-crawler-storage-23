"""Contains all MPF plugins."""
