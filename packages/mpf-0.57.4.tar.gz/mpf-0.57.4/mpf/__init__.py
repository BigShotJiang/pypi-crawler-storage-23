"""Contains "mpf" module path of the Mission Pinball Framework (MPF)."""
