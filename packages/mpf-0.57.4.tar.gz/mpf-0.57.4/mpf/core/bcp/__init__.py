"""Contains the BCP communications classes."""
