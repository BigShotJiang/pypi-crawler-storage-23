"""Code of the default game mode."""
