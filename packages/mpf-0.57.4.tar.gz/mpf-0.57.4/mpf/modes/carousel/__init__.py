"""Default carousel mode."""
