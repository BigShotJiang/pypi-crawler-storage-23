"""Code of the default carousel mode."""
