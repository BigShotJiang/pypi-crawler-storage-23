"""Default credits mode."""
