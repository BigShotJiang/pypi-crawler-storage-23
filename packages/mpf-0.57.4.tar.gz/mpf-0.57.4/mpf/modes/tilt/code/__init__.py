"""Code of the default tilt mode."""
