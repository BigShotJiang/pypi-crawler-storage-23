"""Code of the default service mode."""
