"""Code of the default attract mode."""
