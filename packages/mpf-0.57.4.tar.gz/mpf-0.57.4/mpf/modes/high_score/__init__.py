"""Default high score mode."""
