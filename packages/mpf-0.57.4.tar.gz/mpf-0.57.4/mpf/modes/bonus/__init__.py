"""Default bonus mode."""
