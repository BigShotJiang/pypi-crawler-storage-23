"""Module which contains custom exceptions."""
