See: https://missionpinball.org/about/contributing_to_mpf/
