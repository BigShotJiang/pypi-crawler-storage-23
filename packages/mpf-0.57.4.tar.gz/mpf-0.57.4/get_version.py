"""Return the short version string."""
from mpf._version import __short_version__
print("{}.x".format(__short_version__))
