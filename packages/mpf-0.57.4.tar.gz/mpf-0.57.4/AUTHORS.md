# Authors & Contributors

The following folks are the ones who've made MPF possible. Some big. Some small. All in
their spare time, unpaid, for the love of pinball!

 * Brian Madden <brian@missionpinball.org>
 * Jan Kantert <jan-mission-pinball@kantert.net>
 * Quinn Capen <qcapen@gmail.com>
 * John Marsh <john.marsh@gmail.com>
 * Scott Danesi <scott@scottdanesi.com>
 * Mark Incitti <markinc@gmail.com>
 * Brian Dominy <brian@oddchange.com>
 * Philip Dixon <epotech@ntlworld.com>
 * Thomas O'Connell <shastada@gmail.com>
 * Adina Shanholtz <ashanhol@gmail.com>
 * Andres Rosales <meepman32@gmail.com>
 * Fabian Gand <gandfabian@gmail.com>
 * Anthony van Winkle <mpf@anthonyvanwinkle.com>
 * Stewart Font <yensho@gmail.com>
 * Woosle Park <whyuwatchingthis@gmail.com>
 * Adam Dziedzic <dziedada@umich.edu>
 * Michael Fuegemann <mfuegemann@yahoo.de>
 * Pinki Mansukhani <birdsofpassage7@gmail.com>
 * Kevin Lee Drum <kevinleedrum@gmail.com>
 * Sean Irby <sean.t.irby@gmail.com>
 * Mark Seiden <thearrrrrcade@gmail.com>
 * Andrew Burch <andrewb@enteryourinitials.com>
 * Avery Tummons
 * James Cardona
 * Dave Ensminger <dave@ensadi.com>
 * Charles Duncan (nullbuilds)
 * Eric Selk <ericselk2018@gmail.com>
 * Jerome Vivien

MPF was inspired by pyprocgame which was written by:

 * Adam Preble
 * Gerry Stellenberg

Want to contribute to MPF? Get started here: https://missionpinball.org/about/contributing_to_mpf/
