See: https://missionpinball.org/versions/release_notes/
