"""GEO metadata extraction."""
