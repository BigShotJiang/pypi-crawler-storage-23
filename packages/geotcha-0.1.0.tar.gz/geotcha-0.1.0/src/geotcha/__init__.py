"""GEOtcha: Extract and harmonize RNA-seq metadata from NCBI GEO."""

__version__ = "0.1.0"
