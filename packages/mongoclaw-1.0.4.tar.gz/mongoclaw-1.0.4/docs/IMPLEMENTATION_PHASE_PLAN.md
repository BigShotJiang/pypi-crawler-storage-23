# MongoClaw Phase Plan (Post-README)

## Phase 1: Deterministic Core Hardening
Status: Completed (this pass)
- Enforce optimistic version guard in `strict_post_commit`.
- Increment `_mongoclaw_version` atomically on strict writes.
- Add metric: `mongoclaw_version_conflicts_total`.
- Apply retry delay before re-enqueue to reduce retry storms.
- Add metric: `mongoclaw_retries_scheduled_total`.

## Phase 2: Queue Fairness + Isolation
Status: Completed (core)
- Completed: rotating fair stream scheduling + per-stream dequeue cap + streams-per-cycle cap.
- Completed: per-agent stream pending/in-flight/starvation/saturation metrics.
- Completed: configurable max in-flight work per agent stream.

## Phase 3: Backpressure + Priority
Status: Completed (core)
- Integrate queue fullness feedback into dispatch path.
- Add priority-aware admission control.
- Define overflow behavior (`drop`, `defer`, `dlq`).

## Phase 4: Determinism Formalization
Status: Completed (core)
- Add execution lifecycle state model (`dispatched`, `running`, `write_skipped_conflict`, `written`).
- Persist decision reason for each execution outcome.
- Add optional document hash guard for stronger stale-write detection.

## Phase 5: Horizontal Scale Semantics
Status: Completed (core)
- Document and enforce at-least-once semantics with duplicate-safe write path.
- Add shard/partition strategy for streams and worker assignment.
- Validate multi-worker pod behavior with contention tests.

## Phase 6: Failure Isolation and SLOs
Status: Completed (core)
- Add per-agent error budgets and temporary quarantine/circuit behavior.
- Add latency/error SLO metrics and alert thresholds.
- Add resilience benchmark report (p50/p95/p99 + retry/DLQ rates).
