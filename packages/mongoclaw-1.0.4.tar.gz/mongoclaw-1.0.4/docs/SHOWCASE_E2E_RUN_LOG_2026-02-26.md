# Showcase E2E Run Log (2026-02-26)

## Scope
Execution started against `docs/COMPREHENSIVE_E2E_TEST_SHOWCASE.md` with focus on:
- Platform bring-up and readiness
- Method coverage (CLI, Python SDK, Node SDK, dynamic config path)
- Real enrichment writeback validation
- UI onboarding backend APIs (catalog/schema endpoints)
- Resilience workload evidence capture

## Environment
- API URL: `http://127.0.0.1:8000`
- Mongo URI: `mongodb://127.0.0.1:27017/mongoclaw?replicaSet=rs0`
- Redis URL: `redis://127.0.0.1:6379/0`
- API Key: `test-key`

## Critical Setup Finding (Resolved)
- Issue: local host `mongod` process on `127.0.0.1:27017` (standalone) conflicted with Docker MongoDB mapping.
- Symptom: runtime startup failure with `ReplicaSetNoPrimary`.
- Action:
  - identified listener via `lsof -nP -iTCP:27017 -sTCP:LISTEN`
  - stopped local process (`kill 4881`)
  - verified host `db.hello()` now shows `setName: rs0`.
- Result: runtime starts successfully and health checks pass.

## Executed Tests and Outcomes

### A1 Runtime boot and health
- Status: `PASS`
- Evidence:
  - `/health` => `{"status":"healthy"}`
  - `/health/ready` => `{"status":"ready","checks":{"mongodb":{"status":"healthy"}}}`

### A2 Metrics endpoint availability
- Status: `PASS`
- Evidence:
  - `/metrics` includes:
    - `mongoclaw_dlq_size 0.0`
    - `mongoclaw_agent_executions_total`
    - `mongoclaw_retries_scheduled_total{agent_id="bench_burst_agent_v2"...}`

### B1 CLI lifecycle
- Status: `PASS`
- Actions:
  - created `method_cli_agent` via CLI
  - disabled then enabled via CLI
- Evidence:
  - `✓ Created agent: method_cli_agent`
  - `✓ Disabled agent: method_cli_agent`
  - `✓ Enabled agent: method_cli_agent`

### B2 Python SDK lifecycle
- Status: `PASS`
- Actions:
  - executed `.tmp/e2e/e2e_python_sdk.py`
  - executed `.tmp/e2e/e2e_python_enable_disable.py`
- Evidence:
  - `AgentDetails / method_py_agent`
  - `disable_agent OK method_py_agent`
  - `enable_agent OK method_py_agent`

### B3 Node SDK lifecycle
- Status: `PASS`
- Actions:
  - executed `.tmp/e2e/e2e_node_sdk.mjs`
  - executed `.tmp/e2e/e2e_node_enable_disable.mjs`
- Evidence:
  - `CREATE_OK method_node_agent`
  - `disableAgent OK method_node_agent`
  - `enableAgent OK method_node_agent`

### C1/C2 Real insert-driven enrichment across methods
- Status: `PASS`
- Inserts:
  - `support_cli.tickets::_id=showcase-cli-1`
  - `support_py.tickets::_id=showcase-py-1`
  - `support_node.tickets::_id=showcase-node-1`
  - `support_dyn.tickets::_id=showcase-dyn-1`
- Evidence (post-poll):
  - CLI: `{category:'technical', priority:'high', has_meta:true}`
  - Python: `{category:'billing', priority:'urgent', has_meta:true}`
  - Node: `{category:'sales', priority:'medium', has_meta:true}`
  - Dynamic: `{category:'general', priority:'low', has_meta:true}`

### I3/I4 Collection explorer backend APIs
- Status: `PASS` (after fix)
- Endpoints:
  - `/api/v1/catalog/overview` => returns databases + collections
  - `/api/v1/catalog/collection-profile?...` => returns stats/schema/applied_agents
- Bug found and fixed during run:
  - `PydanticSerializationError` for raw `ObjectId` in collection-profile response
  - Fix applied in `src/mongoclaw/api/v1/catalog.py` (BSON sanitization)
  - Re-tested endpoint successfully after runtime restart

### F1/F2 Resilience workload evidence
- Status: `PASS` (activity observed and outcomes recorded)
- Benchmark agents:
  - `bench_baseline_agent_v2`
  - `bench_burst_agent_v2`
- Evidence (last ~30 min execution outcomes via Mongo):
  - baseline:
    - completed/written: `209`
    - skipped/strict_version_conflict: `83`
    - failed/agent_quarantined: `15`
  - burst:
    - completed/written: `146`
    - skipped/strict_version_conflict: `63`
    - failed/pipeline_error: `9`
    - failed/agent_quarantined: `4`

## In-Progress / Next Showcase Batches
- D-series strict consistency matrix (`eventual` vs `strict_post_commit` vs `shadow`) with explicit pass/fail thresholds
- E-series duplicate replay + idempotency controls
- G-series policy `enrich/block/tag` packs
- H-series full latency percentile and retry-rate extraction report

## Summary
Initial showcase run successfully validated platform readiness, method parity, real writeback enrichment, schema/catalog onboarding APIs, and resilience activity under load with concrete evidence. One production bug was discovered and fixed during execution (`collection-profile` BSON serialization).
