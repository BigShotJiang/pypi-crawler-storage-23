"""CLI entry point for MongoClaw."""

from mongoclaw.cli.main import cli

if __name__ == "__main__":
    cli()
