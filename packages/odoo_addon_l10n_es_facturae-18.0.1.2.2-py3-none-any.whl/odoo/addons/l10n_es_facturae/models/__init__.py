# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl.html).

from . import account_move
from . import l10n_es_facturae_attachment
from . import account_tax
from . import payment_mode
from . import res_company
from . import res_currency
from . import res_partner
from . import account_chart_template
