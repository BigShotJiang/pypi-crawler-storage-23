k = int(input())
ans = bin(k).replace("1", "2")
print(ans)
