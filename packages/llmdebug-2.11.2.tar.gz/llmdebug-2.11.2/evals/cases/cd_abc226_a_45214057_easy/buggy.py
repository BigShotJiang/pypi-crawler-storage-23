X = input()
print(int(float(X) + 1))
