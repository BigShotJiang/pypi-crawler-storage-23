a, b = map(int, input().split())

if b - a or b - a == 9:
    print("Yes")
else:
    print("No")
