# CHANGELOG

## Current (2.10.1)

- Latest local package version in `pyproject.toml`.
- Evidence-first retry protocol refinements in eval harness:
  - delta-first retry prompt packaging (`full|delta|auto`)
  - stable evidence IDs with dedup/reuse tracking
  - deterministic Stage-B prompt budget caps and telemetry
- Analyzer/stats improvements:
  - pairwise uplift matrix across discovered conditions
  - configurable condition-pair statistical reporting
- Add and update regression tests for retry deltas, evidence IDs, and matrix analysis.

## v2.8.4 (2026-02-16)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.3 (2026-02-15)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.2 (2026-02-14)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.1 (2026-02-14)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.8.0 (2026-02-13)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.7.0 (2026-02-13)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.6.0 (2026-02-11)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.5.1 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.5.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.4.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.3.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.2.0 (2026-02-10)

### Notes

- Maintenance release (detailed notes were not present in this changelog history).

## v2.0.1 (2026-02-08)

### Notes

- Patch release (detailed notes were not present in this changelog history).

## v2.1.0 (2026-02-08)

### Features

- **Layered snapshot disclosure**: Read-time filter with three detail levels (`crash`, `full`, `context`) to control token usage. Wired into CLI (`--detail` flag), MCP server (`detail` parameter), and Python API (`filter_snapshot()`)
- **Hypothesis generation engine**: 10 pattern detectors that auto-generate ranked debugging hypotheses from snapshot data. New CLI command (`hypothesize`) and MCP tool (`llmdebug_hypothesize`)
- **Coverage-guided snapshot enrichment**: Extracts pytest-cov execution data (executed/missing lines, branch stats) for stack trace files into snapshots under `pytest.coverage`. Gracefully degrades when pytest-cov is absent

### Bug Fixes

- Eliminate silent failures across capture pipeline: replace bare `except Exception: pass` blocks with error sentinels, warnings, and visible error reporting across 14 modules
- Bootstrap CI off-by-one fix in stats module
- ASGI server IndexError guard in middleware
- Negative index validation in snapshot_diff
- CLI clean command now reports failed deletions
- Stale latest.json warning and temp file cleanup in output module
- Path traversal guard in snapshot loader
- Query string PII redaction in WSGI/ASGI middleware

## v2.0.0 (2026-01-31)

### BREAKING CHANGES

- Default `output_format` changed from `"json"` to `"json_compact"`. Snapshots now use abbreviated keys by default for ~40% smaller files. Use `output_format="json"` or `LLMDEBUG_OUTPUT_FORMAT=json` to restore previous behavior.

### Features

- **Compact output formats**: `json_compact` (default, ~40% smaller) and `toon` (optional, ~50% smaller)
- **Git context capture**: commit hash, branch name, dirty status
- **Error categorization**: auto-classify exceptions with actionable suggestions
- **Async context capture**: asyncio task name and coroutine info
- **Function arguments**: captured separately from locals
- **Array statistics**: optional min/max/mean/std computation
- **Log capture**: capture recent log records for pre-crash context
- CLI for viewing and managing snapshots (`show`, `list`, `frames`, `clean`)
- MCP server for IDE integration (`llmdebug-mcp`) with 4 tools: `diagnose`, `show`, `list`, `frame`
- Snapshot diffing via CLI (`diff` command) and MCP (`llmdebug_diff`)
- Production exception hooks (`install_hooks` / `uninstall_hooks`) with rate limiting and PII redaction
- WSGI and ASGI middleware for web framework integration

## v1.0.1 (2026-01-28)

### Bug Fixes

- Set `major_on_zero=false` for proper semver during 0.x development

## v1.0.0 (2026-01-28)

### Features

- `max_snapshots` config for automatic storage cleanup (0 = unlimited)
- CI/CD pipeline with GitHub Actions

## v0.1.4 (2026-01-27)

### Features

- ML tensor introspection: NaN/Inf detection, device tracking, requires_grad
- Pytest-specific context capture: test nodeid, outcome, stdout/stderr
- Project logo

### Bug Fixes

- Deprecated datetime.utcnow() usage
- Handle None line numbers in frame extraction

## v0.1.0 (2026-01-27)

### Features

- Initial release
- Exception capture with structured JSON snapshots
- Pytest plugin for automatic capture on test failures
- Smart array summarization for NumPy arrays
- Atomic file writes for snapshot output
