<div align="center">
  <a href="https://wristband.dev">
    <picture>
      <img src="https://assets.wristband.dev/images/email_branding_logo_v1.png" alt="Wristband" width="297" height="64">
    </picture>
  </a>
  <p align="center">
    Enterprise-ready auth that is secure by default, truly multi-tenant, and ungated for small businesses.
  </p>
  <p align="center">
    <b>
      <a href="https://wristband.dev">Website</a> •
      <a href="https://docs.wristband.dev/">Documentation</a>
    </b>
  </p>
</div>

<br/>

---

<br/>

# Wristband Machine-to-Machine (M2M) Authentication SDK for Python

[![PyPI](https://img.shields.io/pypi/v/wristband-python-m2m-auth)](https://pypi.org/project/wristband-python-m2m-auth/)
[![version number](https://img.shields.io/github/v/release/wristband-dev/python-m2m-auth?color=green&label=version)](https://github.com/wristband-dev/python-m2m-auth/releases)
[![Actions Status](https://github.com/wristband-dev/python-m2m-auth/workflows/Test/badge.svg)](https://github.com/wristband-dev/python-m2m-auth/actions)
[![License](https://img.shields.io/github/license/wristband-dev/python-m2m-auth)](https://github.com/wristband-dev/python-m2m-auth/blob/main/LICENSE)

This Python SDK enables Wristband machine-to-machine (M2M) OAuth2 clients to securely retrieve, cache, and refresh access tokens. Designed for server-to-server communication, it automates M2M token management with zero user interaction.

Both synchronous and asynchronous clients are provided. Use whichever fits your framework (Django, FastAPI, etc.).

You can learn more about how authentication works in Wristband in our documentation:

- [Machine-to-machine Integration Pattern](https://docs.wristband.dev/docs/machine-to-machine-integration)

<br/>

---

## Table of Contents

- [Requirements](#requirements)
- [Usage](#usage)
  - [1) Installation](#1-installation)
  - [2) Wristband Configuration](#2-wristband-configuration)
  - [3) Configure the SDK](#3-configure-the-sdk)
  - [4) Prime the Token Cache on Server Startup](#4-prime-the-token-cache-on-server-startup)
  - [5) Use the Token](#5-use-the-token)
- [Token Caching and Refresh](#token-caching-and-refresh)
- [SDK Configuration Options](#sdk-configuration-options)
- [API](#api)
- [Related Wristband SDKs](#related-wristband-sdks)
- [Wristband Python M2M Demo App](#wristband-python-m2m-demo-app)
- [Questions](#questions)

<br/>

## Requirements

Before installing, ensure you have:

- [Python](https://www.python.org/) >= 3.10

<br/>

## Usage

### 1) Installation

Install the `wristband-python-m2m-auth` package from PyPI.

```bash
# With pip
pip install wristband-python-m2m-auth

# Or if using poetry
poetry add wristband-python-m2m-auth

# Or if using pipenv
pipenv install wristband-python-m2m-auth
```

<br/>

### 2) Wristband Configuration

1. First, make sure you have a Wristband account set up. You can [sign up here](https://dashboard-wristband.us.wristband.dev/signup).
2. From the Dashboard home page, add a new Application, and then navigate to the "Application Settings" side menu nav for that application. **Copy down the Application Vanity Domain from the top box.**
3. Next, navigate to the "OAuth2 Clients" side nav menu and create a Machine-to-Machine (M2M) OAuth2 Client. **Copy down the Client ID and Client Secret.**

<br/>

### 3) Configure the SDK

First, store your credentials securely. For local development, a `.env` file works well:

> [!NOTE]
> Never commit secrets to source control. Use environment variables or a secrets manager in production.

```
CLIENT_ID=<your-client-id>
CLIENT_SECRET=<your-client-secret>
APPLICATION_VANITY_DOMAIN=<your-domain.wristband.dev>
```

Then, instantiate the client once at module level so it is shared across requests.

#### Synchronous (Django, Flask, etc.)

```python
import os
from wristband.m2m_auth import WristbandM2MAuthClient, WristbandM2MAuthConfig

wristband_m2m_auth = WristbandM2MAuthClient(
    WristbandM2MAuthConfig(
        client_id=os.getenv("CLIENT_ID", ""),
        client_secret=os.getenv("CLIENT_SECRET", ""),
        wristband_application_vanity_domain=os.getenv("APPLICATION_VANITY_DOMAIN", ""),
    )
)
```

#### Asynchronous (FastAPI, etc.)

```python
import os
from wristband.m2m_auth import AsyncWristbandM2MAuthClient, WristbandM2MAuthConfig

wristband_m2m_auth = AsyncWristbandM2MAuthClient(
    WristbandM2MAuthConfig(
        client_id=os.getenv("CLIENT_ID", ""),
        client_secret=os.getenv("CLIENT_SECRET", ""),
        wristband_application_vanity_domain=os.getenv("APPLICATION_VANITY_DOMAIN", ""),
    )
)
```

#### Multiple Instances

If you need to communicate with multiple Wristband Applications or use different OAuth2 clients, simply instantiate the client multiple times:

```python
wristband_m2m_auth_01 = WristbandM2MAuthClient(WristbandM2MAuthConfig(...))
wristband_m2m_auth_02 = WristbandM2MAuthClient(WristbandM2MAuthConfig(...))
```

<br/>

### 4) Prime the Token Cache on Server Startup

Call `get_token()` during server startup to pre-load the token cache. This avoids a cold-start delay on the first request.

#### Synchronous (Django, Flask, etc.)

```python
# apps.py (Django)
from django.apps import AppConfig

class MyAppConfig(AppConfig):
    name = "my_app"

    def ready(self):
        from my_app.auth import wristband_m2m_auth
        try:
            wristband_m2m_auth.get_token()
        except Exception as e:
            print(f"[M2M AUTH] Failed to retrieve initial M2M token: {e}")
```

#### Asynchronous (FastAPI, etc.)

```python
# main.py (FastAPI)
from contextlib import asynccontextmanager
from fastapi import FastAPI

# Using FastAPI's lifespan handler
@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        await wristband_m2m_auth.get_token()
    except Exception as e:
        print(f"[M2M AUTH] Failed to retrieve initial M2M token: {e}")
    yield

app = FastAPI(lifespan=lifespan)
```

<br/>

### 5) Use the Token

Call `get_token()` before any authenticated downstream request and pass the result as a Bearer token. If a downstream API returns a `401`, call `clear_token()` to force a fresh token on the next call.

#### Synchronous

```python
import httpx

def call_protected_api():
    token = wristband_m2m_auth.get_token()

    response = httpx.get(
        "https://your-api.example.com/protected",
        headers={"Authorization": f"Bearer {token}"},
    )

    if response.status_code == 401:
        wristband_m2m_auth.clear_token()

    response.raise_for_status()
    return response.json()
```

#### Asynchronous

```python
import httpx

async def call_protected_api():
    token = await wristband_m2m_auth.get_token()

    async with httpx.AsyncClient() as client:
        response = await client.get(
            "https://your-api.example.com/protected",
            headers={"Authorization": f"Bearer {token}"},
        )

    if response.status_code == 401:
        wristband_m2m_auth.clear_token()

    response.raise_for_status()
    return response.json()
```

<br/>

## Token Caching and Refresh

The SDK automatically caches tokens in memory. On each `get_token()` call, the cached token is returned if still valid. When it expires, a new token is fetched automatically.

### Expiration Buffer

A buffer is subtracted from the token's expiration time to ensure the token is refreshed slightly before it actually expires. The default is 60 seconds.

```python
WristbandM2MAuthConfig(
    ...
    token_expiration_buffer=120,  # Refresh 2 minutes before actual expiration
)
```

### Background Refresh

You can optionally enable proactive background refreshing at a fixed interval, independent of request activity:

```python
WristbandM2MAuthConfig(
    ...
    background_token_refresh_interval=900,  # Refresh every 15 minutes
)
```

The sync client runs background refresh on a daemon thread. It will not block process shutdown and exits automatically when the process ends. The async client runs background refresh as an `asyncio.Task` that is cancelled automatically when the event loop shuts down. In both cases, no manual cleanup is required on exit.

<br/>

## SDK Configuration Options

| Option | Type | Required | Default | Description |
| ------ | ---- | -------- | ------- | ----------- |
| `client_id` | `str` | Yes | — | The client ID of the Wristband M2M OAuth2 Client. |
| `client_secret` | `str` | Yes | — | The client secret of the Wristband M2M OAuth2 Client. |
| `wristband_application_vanity_domain` | `str` | Yes | — | The vanity domain of the Wristband application. |
| `token_expiration_buffer` | `int` | No | `60` | Seconds to subtract from the token's expiration for early refresh. Must be >= 0. |
| `background_token_refresh_interval` | `int \| None` | No | `None` | Seconds between background refresh attempts. `None` disables background refresh. Minimum is 60 seconds when a value is provided. |

<br/>

## API

### `WristbandM2MAuthClient` / `AsyncWristbandM2MAuthClient`

#### `get_token()` / `await get_token()`

Returns a valid access token, fetching a new one if the cache is empty or expired. Retries up to 3 times on 5xx errors with 100ms between attempts. Fails immediately on 4xx errors.

```python
token = client.get_token()          # sync
token = await client.get_token()    # async
```

#### `clear_token()`

Clears the cached token. The next `get_token()` call will fetch a fresh one. Use this when a downstream API returns a `401`.

```python
client.clear_token()
```

<br/>

## Related Wristband SDKs

**[@wristband/python-jwt](https://github.com/wristband-dev/python-jwt)**

This SDK can work in tandem with the Wristband Python JWT SDK for JWT validation. It handles JWT signature verification, token parsing, and JWKS key management. Refer to that GitHub repository for more information on JWT validation configuration and options.

<br/>

## Wristband Python M2M Demo App

You can check out the [Wristband Python M2M demo app](https://github.com/wristband-dev/m2m-python-demo-app) to see this SDK in action. Refer to that GitHub repository for more information.

<br/>

## Questions

Reach out to the Wristband team at <support@wristband.dev> for any questions regarding this SDK.
