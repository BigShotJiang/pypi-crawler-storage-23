"""Synchronous Wristband M2M authentication client."""

import logging
import threading
import time
from typing import Any

import httpx

from .models import WristbandM2MAuthConfig
from .wristband_api_client import WristbandApiClient

logger = logging.getLogger(__name__)

_MAX_REFRESH_ATTEMPTS = 3
_RETRY_DELAY_SECONDS = 0.1
_FALLBACK_EXPIRATION_BUFFER_SECONDS = 60


class WristbandM2MAuthClient:
    """Synchronous client for Wristband machine-to-machine authentication.

    Handles token acquisition, in-memory caching, automatic expiration-based refresh,
    and optional background refresh at a fixed interval.

    Usage::

        from wristband.m2m_auth import WristbandM2MAuthClient, WristbandM2MAuthConfig

        client = WristbandM2MAuthClient(
            WristbandM2MAuthConfig(
                client_id="your-client-id",
                client_secret="your-client-secret",
                wristband_application_vanity_domain="your-domain.wristband.dev",
            )
        )

        token = client.get_token()
        client.clear_token()

    Can also be used as a context manager:

        with WristbandM2MAuthClient(config) as client:
            token = client.get_token()
    """

    def __init__(self, config: WristbandM2MAuthConfig) -> None:
        self._config = config
        self._api_client = WristbandApiClient(config)
        self._lock = threading.Lock()

        self._cached_token: str = ""
        self._token_expiration: float = 0.0

        self._stop_event = threading.Event()
        self._background_thread: threading.Thread | None = None

        if config.background_token_refresh_interval is not None:
            self._background_thread = threading.Thread(
                target=self._background_refresh_loop,
                args=(config.background_token_refresh_interval,),
                daemon=True,
            )
            self._background_thread.start()

    def get_token(self) -> str:
        """Retrieve a valid access token, refreshing if expired or missing.

        Returns:
            A valid Bearer access token string.

        Raises:
            httpx.HTTPStatusError: If the token request fails with a non-retryable error.
            httpx.RequestError: If a network-level error occurs and all retries are exhausted.
        """
        self._refresh_token()
        return self._cached_token

    def clear_token(self) -> None:
        """Clear the cached access token, forcing the next call to fetch a fresh one."""
        with self._lock:
            self._cached_token = ""  # nosec B105 - empty string to clear cache, not a password
            self._token_expiration = 0.0

    def __enter__(self) -> "WristbandM2MAuthClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self._stop_event.set()
        if self._background_thread is not None:
            self._background_thread.join()
        self._api_client.close()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _is_token_valid(self) -> bool:
        return bool(self._cached_token) and time.monotonic() <= self._token_expiration

    def _refresh_token(self) -> None:
        # Fast path: token still valid, no lock needed
        if self._is_token_valid():
            return

        with self._lock:
            # Double-checked locking: another thread may have refreshed already
            if self._is_token_valid():
                return

            last_exc: Exception | None = None

            for attempt in range(1, _MAX_REFRESH_ATTEMPTS + 1):
                try:
                    token_response = self._api_client.get_m2m_token()

                    # Apply expiration buffer with fallback if buffer >= expires_in
                    buffer = (
                        _FALLBACK_EXPIRATION_BUFFER_SECONDS
                        if token_response.expires_in <= self._config.token_expiration_buffer
                        else self._config.token_expiration_buffer
                    )
                    self._token_expiration = time.monotonic() + token_response.expires_in - buffer
                    self._cached_token = token_response.access_token
                    return

                except httpx.HTTPStatusError as exc:
                    # Only retry on 5xx server errors
                    if exc.response.status_code >= 500:
                        last_exc = exc
                        if attempt < _MAX_REFRESH_ATTEMPTS:
                            time.sleep(_RETRY_DELAY_SECONDS)
                        continue
                    raise

                except Exception:
                    raise

            # All retries exhausted
            if last_exc is not None:
                raise last_exc

    def _background_refresh_loop(self, interval_seconds: int) -> None:
        while not self._stop_event.wait(timeout=interval_seconds):
            try:
                self._refresh_token()
            except Exception as e:
                logger.debug("Background token refresh failed: %s", e)
