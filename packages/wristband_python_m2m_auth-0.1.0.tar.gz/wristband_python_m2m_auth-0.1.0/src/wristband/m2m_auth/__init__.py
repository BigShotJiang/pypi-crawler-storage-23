"""Wristband Machine-to-Machine (M2M) Authentication SDK for Python.

Provides sync and async clients for acquiring and caching access tokens
using the OAuth2 client credentials grant flow.

Usage (sync)::

    from wristband.m2m_auth import WristbandM2MAuthClient, WristbandM2MAuthConfig

    client = WristbandM2MAuthClient(
        WristbandM2MAuthConfig(
            client_id="your-client-id",
            client_secret="your-client-secret",
            wristband_application_vanity_domain="your-domain.wristband.dev",
        )
    )
    token = client.get_token()

Usage (async)::

    from wristband.m2m_auth import AsyncWristbandM2MAuthClient, WristbandM2MAuthConfig

    client = AsyncWristbandM2MAuthClient(
        WristbandM2MAuthConfig(
            client_id="your-client-id",
            client_secret="your-client-secret",
            wristband_application_vanity_domain="your-domain.wristband.dev",
        )
    )
    token = await client.get_token()
"""

import logging

from .m2m_client import WristbandM2MAuthClient
from .m2m_client_async import AsyncWristbandM2MAuthClient
from .models import WristbandM2MAuthConfig

# Prevent "No handlers could be found" warnings when the consuming application
# has not configured logging. The application is responsible for configuring
# log handlers if it wants to see SDK log output.
logging.getLogger(__name__).addHandler(logging.NullHandler())

__all__ = [
    "WristbandM2MAuthConfig",
    "WristbandM2MAuthClient",
    "AsyncWristbandM2MAuthClient",
]
