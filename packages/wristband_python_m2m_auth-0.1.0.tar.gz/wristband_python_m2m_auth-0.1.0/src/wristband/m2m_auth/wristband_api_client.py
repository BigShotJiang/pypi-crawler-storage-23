"""Internal HTTP clients for communicating with the Wristband token endpoint."""

import base64
from typing import Any

import httpx

from .models import TokenResponse, WristbandM2MAuthConfig

_TOKEN_PATH = "/api/v1/oauth2/token"  # nosec B105 - URL path, not a password
_DEFAULT_TIMEOUT = 30
_CLIENT_CREDENTIALS_DATA = {"grant_type": "client_credentials"}


def _build_base_url(config: WristbandM2MAuthConfig) -> str:
    return f"https://{config.wristband_application_vanity_domain}"


def _build_auth_header(config: WristbandM2MAuthConfig) -> str:
    credentials = f"{config.client_id}:{config.client_secret}"
    encoded = base64.b64encode(credentials.encode("utf-8")).decode("utf-8")
    return f"Basic {encoded}"


def _parse_token_response(data: dict[str, Any]) -> TokenResponse:
    return TokenResponse(
        access_token=data["access_token"],
        expires_in=data["expires_in"],
        token_type=data.get("token_type", "Bearer"),
    )


class WristbandApiClient:
    """Synchronous HTTP client for the Wristband token endpoint."""

    def __init__(self, config: WristbandM2MAuthConfig) -> None:
        self._client = httpx.Client(
            base_url=_build_base_url(config),
            headers={
                "Authorization": _build_auth_header(config),
                "Accept": "application/json",
            },
            timeout=_DEFAULT_TIMEOUT,
        )

    def get_m2m_token(self) -> TokenResponse:
        """Request a token from the Wristband token endpoint using client credentials grant."""
        response = self._client.post(_TOKEN_PATH, data=_CLIENT_CREDENTIALS_DATA)
        response.raise_for_status()
        return _parse_token_response(response.json())

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "WristbandApiClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncWristbandApiClient:
    """Asynchronous HTTP client for the Wristband token endpoint."""

    def __init__(self, config: WristbandM2MAuthConfig) -> None:
        self._client = httpx.AsyncClient(
            base_url=_build_base_url(config),
            headers={
                "Authorization": _build_auth_header(config),
                "Accept": "application/json",
            },
            timeout=_DEFAULT_TIMEOUT,
        )

    async def get_m2m_token(self) -> TokenResponse:
        """Request a token from the Wristband token endpoint using client credentials grant."""
        response = await self._client.post(_TOKEN_PATH, data=_CLIENT_CREDENTIALS_DATA)
        response.raise_for_status()
        return _parse_token_response(response.json())

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncWristbandApiClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
