"""Internal data models for the Wristband M2M Auth SDK."""

from dataclasses import dataclass


@dataclass
class WristbandM2MAuthConfig:
    """Configuration for the Wristband M2M authentication client.

    Args:
        client_id: The client ID of the Wristband M2M OAuth2 Client.
        client_secret: The client secret of the Wristband M2M OAuth2 Client.
        wristband_application_vanity_domain: The vanity domain of the Wristband application.
        token_expiration_buffer: Seconds to subtract from token expiration to ensure early refresh.
            Defaults to 60 seconds. Must be >= 0.
        background_token_refresh_interval: How often (in seconds) to proactively refresh
            the token in the background. If None, background refresh is disabled.
            Minimum is 60 seconds.
    """

    client_id: str
    client_secret: str
    wristband_application_vanity_domain: str
    token_expiration_buffer: int = 60
    background_token_refresh_interval: int | None = None

    def __post_init__(self) -> None:
        if not self.client_id or not self.client_id.strip():
            raise ValueError("client_id is required")
        if not self.client_secret or not self.client_secret.strip():
            raise ValueError("client_secret is required")
        if not self.wristband_application_vanity_domain or not self.wristband_application_vanity_domain.strip():
            raise ValueError("wristband_application_vanity_domain is required")
        if self.token_expiration_buffer < 0:
            raise ValueError("token_expiration_buffer cannot be negative")
        if self.background_token_refresh_interval is not None:
            if self.background_token_refresh_interval < 60:
                raise ValueError("background_token_refresh_interval must be at least 60 seconds")


@dataclass
class TokenResponse:
    """Represents the token response from the Wristband token endpoint."""

    access_token: str
    expires_in: int
    token_type: str = "Bearer"
