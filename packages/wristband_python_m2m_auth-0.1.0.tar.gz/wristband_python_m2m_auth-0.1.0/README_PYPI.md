# Wristband Machine-to-Machine (M2M) Authentication SDK for Python

Wristband provides enterprise-ready auth that is secure by default, truly multi-tenant, and ungated for small businesses.

- Website: [Wristband Website](https://wristband.dev)
- Documentation: [Wristband Docs](https://docs.wristband.dev/)

For detailed setup instructions and usage guidelines, visit the project's GitHub repository.

- [Python M2M Auth SDK - GitHub](https://github.com/wristband-dev/python-m2m-auth)


## Details

This SDK enables Wristband machine-to-machine (M2M) OAuth2 clients to securely retrieve, cache, and refresh access tokens in Python applications. It is supported for Python 3.10+ and provides both synchronous and asynchronous clients to fit any framework (Django, FastAPI, etc.). Key functionalities encompass the following:

- Fetching an access token from Wristband using the OAuth2 client credentials grant.
- Caching the access token in memory for the duration of its validity.
- Automatically refreshing the token when it expires or is nearing expiration.
- Optionally refreshing the token proactively in the background at a fixed interval.
- Clearing the cached token on demand (e.g. after receiving a 401 from a downstream API).

You can learn more about how M2M authentication works in Wristband in our documentation:

- [Machine-to-machine Integration Pattern](https://docs.wristband.dev/docs/machine-to-machine-integration)

## Questions

Reach out to the Wristband team at <support@wristband.dev> for any questions regarding this SDK.
