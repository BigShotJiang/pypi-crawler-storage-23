"""Tests for internal data models."""

import pytest

from wristband.m2m_auth.models import TokenResponse, WristbandM2MAuthConfig

# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - valid construction
# ---------------------------------------------------------------------------


def test_config_minimal_valid() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )
    assert config.client_id == "client-id"
    assert config.client_secret == "client-secret"
    assert config.wristband_application_vanity_domain == "test.wristband.dev"


def test_config_defaults() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )
    assert config.token_expiration_buffer == 60
    assert config.background_token_refresh_interval is None


def test_config_custom_token_expiration_buffer() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        token_expiration_buffer=120,
    )
    assert config.token_expiration_buffer == 120


def test_config_token_expiration_buffer_zero() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        token_expiration_buffer=0,
    )
    assert config.token_expiration_buffer == 0


def test_config_custom_background_refresh_interval() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        background_token_refresh_interval=900,
    )
    assert config.background_token_refresh_interval == 900


def test_config_background_refresh_interval_minimum() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        background_token_refresh_interval=60,
    )
    assert config.background_token_refresh_interval == 60


# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - client_id validation
# ---------------------------------------------------------------------------


def test_config_empty_client_id_raises() -> None:
    with pytest.raises(ValueError, match="client_id"):
        WristbandM2MAuthConfig(
            client_id="",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )


def test_config_whitespace_client_id_raises() -> None:
    with pytest.raises(ValueError, match="client_id"):
        WristbandM2MAuthConfig(
            client_id="   ",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
        )


# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - client_secret validation
# ---------------------------------------------------------------------------


def test_config_empty_client_secret_raises() -> None:
    with pytest.raises(ValueError, match="client_secret"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="",
            wristband_application_vanity_domain="test.wristband.dev",
        )


def test_config_whitespace_client_secret_raises() -> None:
    with pytest.raises(ValueError, match="client_secret"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="   ",
            wristband_application_vanity_domain="test.wristband.dev",
        )


# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - wristband_application_vanity_domain validation
# ---------------------------------------------------------------------------


def test_config_empty_domain_raises() -> None:
    with pytest.raises(ValueError, match="wristband_application_vanity_domain"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="",
        )


def test_config_whitespace_domain_raises() -> None:
    with pytest.raises(ValueError, match="wristband_application_vanity_domain"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="   ",
        )


# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - token_expiration_buffer validation
# ---------------------------------------------------------------------------


def test_config_negative_token_expiration_buffer_raises() -> None:
    with pytest.raises(ValueError, match="token_expiration_buffer"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
            token_expiration_buffer=-1,
        )


def test_config_large_negative_token_expiration_buffer_raises() -> None:
    with pytest.raises(ValueError, match="token_expiration_buffer"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
            token_expiration_buffer=-9999,
        )


# ---------------------------------------------------------------------------
# WristbandM2MAuthConfig - background_token_refresh_interval validation
# ---------------------------------------------------------------------------


def test_config_background_refresh_interval_below_minimum_raises() -> None:
    with pytest.raises(ValueError, match="background_token_refresh_interval"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
            background_token_refresh_interval=59,
        )


def test_config_background_refresh_interval_zero_raises() -> None:
    with pytest.raises(ValueError, match="background_token_refresh_interval"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
            background_token_refresh_interval=0,
        )


def test_config_background_refresh_interval_negative_raises() -> None:
    with pytest.raises(ValueError, match="background_token_refresh_interval"):
        WristbandM2MAuthConfig(
            client_id="client-id",
            client_secret="client-secret",
            wristband_application_vanity_domain="test.wristband.dev",
            background_token_refresh_interval=-1,
        )


def test_config_background_refresh_interval_none_is_valid() -> None:
    config = WristbandM2MAuthConfig(
        client_id="client-id",
        client_secret="client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        background_token_refresh_interval=None,
    )
    assert config.background_token_refresh_interval is None


# ---------------------------------------------------------------------------
# TokenResponse - valid construction
# ---------------------------------------------------------------------------


def test_token_response_required_fields() -> None:
    token = TokenResponse(access_token="my-token", expires_in=3600)
    assert token.access_token == "my-token"
    assert token.expires_in == 3600


def test_token_response_default_token_type() -> None:
    token = TokenResponse(access_token="my-token", expires_in=3600)
    assert token.token_type == "Bearer"


def test_token_response_custom_token_type() -> None:
    token = TokenResponse(access_token="my-token", expires_in=3600, token_type="MAC")
    assert token.token_type == "MAC"


def test_token_response_zero_expires_in() -> None:
    token = TokenResponse(access_token="my-token", expires_in=0)
    assert token.expires_in == 0
