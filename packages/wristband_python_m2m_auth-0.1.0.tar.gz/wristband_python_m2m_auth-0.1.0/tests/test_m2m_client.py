"""Tests for the synchronous WristbandM2MAuthClient."""

import threading
import time
from unittest.mock import MagicMock, patch

import httpx
import pytest

from wristband.m2m_auth import WristbandM2MAuthClient, WristbandM2MAuthConfig
from wristband.m2m_auth.models import TokenResponse


@pytest.fixture
def config() -> WristbandM2MAuthConfig:
    return WristbandM2MAuthConfig(
        client_id="test-client-id",
        client_secret="test-client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )


@pytest.fixture
def config_with_background_refresh() -> WristbandM2MAuthConfig:
    return WristbandM2MAuthConfig(
        client_id="test-client-id",
        client_secret="test-client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        background_token_refresh_interval=60,
    )


@pytest.fixture
def mock_token_response() -> TokenResponse:
    return TokenResponse(access_token="test-access-token", expires_in=3600)


# ---------------------------------------------------------------------------
# Token fetching
# ---------------------------------------------------------------------------


def test_get_token_fetches_and_caches(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            token = client.get_token()

            assert token == "test-access-token"
            assert instance.get_m2m_token.call_count == 1

            # Second call should use cache
            token2 = client.get_token()
            assert token2 == "test-access-token"
            assert instance.get_m2m_token.call_count == 1


def test_clear_token_forces_refresh(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            client.get_token()
            client.clear_token()
            client.get_token()

            assert instance.get_m2m_token.call_count == 2


def test_expired_token_triggers_refresh(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            client.get_token()

            # Force token to appear expired
            client._token_expiration = time.monotonic() - 1

            client.get_token()
            assert instance.get_m2m_token.call_count == 2


def test_get_token_returns_cached_token_under_lock(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """Covers the double-checked locking fast path inside the lock."""
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            # Prime the cache
            client.get_token()
            assert instance.get_m2m_token.call_count == 1

            # Simulate another thread having refreshed just before we acquired the lock
            # by manually expiring then re-priming the token between the fast path check
            # and the lock acquisition. We do this by calling get_token() concurrently.
            results = []
            errors = []

            def fetch() -> None:
                try:
                    results.append(client.get_token())
                except Exception as e:
                    errors.append(e)

            # Expire the token so both threads will attempt refresh
            client._token_expiration = time.monotonic() - 1

            threads = [threading.Thread(target=fetch) for _ in range(5)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()

            assert not errors
            assert all(r == "test-access-token" for r in results)
            # Only one refresh should have happened due to double-checked locking
            assert instance.get_m2m_token.call_count == 2


# ---------------------------------------------------------------------------
# Expiration buffer
# ---------------------------------------------------------------------------


def test_expiration_buffer_applied_correctly(config: WristbandM2MAuthConfig) -> None:
    """token_expiration should be set to now + expires_in - buffer."""
    token = TokenResponse(access_token="my-token", expires_in=3600)

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = token

        with WristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            client.get_token()
            after = time.monotonic()

            # Default buffer is 60, so expiration should be around now + 3600 - 60 = now + 3540
            assert before + 3540 <= client._token_expiration <= after + 3540


def test_expiration_buffer_fallback_when_expires_in_lte_buffer(config: WristbandM2MAuthConfig) -> None:
    """When expires_in <= buffer, fallback buffer of 60s is used."""
    short_token = TokenResponse(access_token="short-token", expires_in=30)

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = short_token

        with WristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            client.get_token()

            # expires_in=30, buffer=60 (fallback) → expiration = now + 30 - 60 = ~30s in the past
            assert client._token_expiration < before


def test_expiration_buffer_equals_expires_in_uses_fallback(config: WristbandM2MAuthConfig) -> None:
    """When expires_in == buffer exactly, fallback buffer should be used."""
    token = TokenResponse(access_token="my-token", expires_in=60)

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = token

        with WristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            client.get_token()

            # expires_in=60 == buffer=60 → fallback used → expiration = now + 60 - 60 = now
            assert client._token_expiration <= before + 1  # small tolerance


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------


def test_retries_on_5xx_then_succeeds(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client.time.sleep"):
            instance = MockApiClient.return_value
            instance.get_m2m_token.side_effect = [server_error, mock_token_response]

            with WristbandM2MAuthClient(config) as client:
                token = client.get_token()

                assert token == "test-access-token"
                assert instance.get_m2m_token.call_count == 2


def test_raises_after_max_retries_on_5xx(config: WristbandM2MAuthConfig) -> None:
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client.time.sleep"):
            instance = MockApiClient.return_value
            instance.get_m2m_token.side_effect = server_error

            with WristbandM2MAuthClient(config) as client:
                with pytest.raises(httpx.HTTPStatusError):
                    client.get_token()

                assert instance.get_m2m_token.call_count == 3


def test_no_retry_on_4xx(config: WristbandM2MAuthConfig) -> None:
    client_error = httpx.HTTPStatusError(
        "401",
        request=MagicMock(),
        response=MagicMock(status_code=401),
    )

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.side_effect = client_error

        with WristbandM2MAuthClient(config) as client:
            with pytest.raises(httpx.HTTPStatusError):
                client.get_token()

            assert instance.get_m2m_token.call_count == 1


def test_non_httpx_exception_raised_immediately(config: WristbandM2MAuthConfig) -> None:
    """Non-httpx exceptions should propagate immediately without retrying."""
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.side_effect = RuntimeError("unexpected error")

        with WristbandM2MAuthClient(config) as client:
            with pytest.raises(RuntimeError, match="unexpected error"):
                client.get_token()

            assert instance.get_m2m_token.call_count == 1


def test_sleep_called_between_5xx_retries(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    """time.sleep should be called between retry attempts, but not after the last one."""
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client.time.sleep") as mock_sleep:
            instance = MockApiClient.return_value
            instance.get_m2m_token.side_effect = [server_error, server_error, mock_token_response]

            with WristbandM2MAuthClient(config) as client:
                client.get_token()

            # Two failures → two sleeps before the third succeeding attempt
            assert mock_sleep.call_count == 2


# ---------------------------------------------------------------------------
# Background refresh
# ---------------------------------------------------------------------------


def test_background_thread_started_when_interval_configured(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config_with_background_refresh) as client:
            assert client._background_thread is not None
            assert client._background_thread.is_alive()


def test_background_thread_not_started_without_interval(
    config: WristbandM2MAuthConfig,
) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient"):
        with WristbandM2MAuthClient(config) as client:
            assert client._background_thread is None


def test_background_thread_stopped_on_exit(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config_with_background_refresh) as client:
            thread = client._background_thread
            assert thread is not None
            assert thread.is_alive()

        # After __exit__, stop_event is set and thread is joined
        assert not thread.is_alive()


def test_background_refresh_loop_refreshes_token(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """Background loop should call _refresh_token on each interval tick."""
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            refresh_calls = []

            original_refresh = client._refresh_token

            def tracking_refresh() -> None:
                refresh_calls.append(1)
                original_refresh()

            client._refresh_token = tracking_refresh  # type: ignore[method-assign]

            # Patch stop_event to stop after one iteration
            client._stop_event.set()
            client._background_refresh_loop(0)

            # At least one refresh attempt was logged (loop exits immediately since stop_event is set)


def test_background_refresh_loop_logs_and_continues_on_error(
    config: WristbandM2MAuthConfig,
) -> None:
    """Background loop should swallow exceptions and keep running."""
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.side_effect = RuntimeError("transient error")

        with WristbandM2MAuthClient(config) as client:
            # Run one iteration of the loop manually
            client._stop_event.set()  # ensure loop exits after one wait

            # Should not raise
            with patch("wristband.m2m_auth.m2m_client.logger"):
                client._background_refresh_loop(0)


def test_background_refresh_loop_calls_refresh_and_swallows_exception(
    config: WristbandM2MAuthConfig,
) -> None:
    """Directly exercise the loop body: refresh raises, loop logs and does not propagate."""
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient"):
        with WristbandM2MAuthClient(config) as client:
            call_count = [0]

            def failing_refresh() -> None:
                call_count[0] += 1
                if call_count[0] == 1:
                    raise RuntimeError("transient failure")
                client._stop_event.set()

            client._refresh_token = failing_refresh  # type: ignore[method-assign]

            # Should not raise despite the RuntimeError on first call
            client._background_refresh_loop(0)

            assert call_count[0] == 2


# ---------------------------------------------------------------------------
# Context manager
# ---------------------------------------------------------------------------


def test_context_manager_closes_api_client(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config) as client:
            token = client.get_token()
            assert token == "test-access-token"

        instance.close.assert_called_once()


def test_context_manager_joins_background_thread(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client.WristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token.return_value = mock_token_response

        with WristbandM2MAuthClient(config_with_background_refresh) as client:
            thread = client._background_thread

        assert thread is not None
        assert not thread.is_alive()
        instance.close.assert_called_once()
