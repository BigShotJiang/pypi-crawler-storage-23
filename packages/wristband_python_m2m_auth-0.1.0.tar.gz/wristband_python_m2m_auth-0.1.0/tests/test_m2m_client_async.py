"""Tests for the asynchronous AsyncWristbandM2MAuthClient."""

import asyncio
import time
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from wristband.m2m_auth import AsyncWristbandM2MAuthClient, WristbandM2MAuthConfig
from wristband.m2m_auth.models import TokenResponse


@pytest.fixture
def config() -> WristbandM2MAuthConfig:
    return WristbandM2MAuthConfig(
        client_id="test-client-id",
        client_secret="test-client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )


@pytest.fixture
def config_with_background_refresh() -> WristbandM2MAuthConfig:
    return WristbandM2MAuthConfig(
        client_id="test-client-id",
        client_secret="test-client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
        background_token_refresh_interval=60,
    )


@pytest.fixture
def mock_token_response() -> TokenResponse:
    return TokenResponse(access_token="test-access-token", expires_in=3600)


# ---------------------------------------------------------------------------
# Token fetching
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_get_token_fetches_and_caches(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            token = await client.get_token()

            assert token == "test-access-token"
            assert instance.get_m2m_token.call_count == 1

            # Second call should use cache
            token2 = await client.get_token()
            assert token2 == "test-access-token"
            assert instance.get_m2m_token.call_count == 1


@pytest.mark.asyncio
async def test_clear_token_forces_refresh(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            await client.get_token()
            client.clear_token()
            await client.get_token()

            assert instance.get_m2m_token.call_count == 2


@pytest.mark.asyncio
async def test_expired_token_triggers_refresh(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            await client.get_token()

            # Force token to appear expired
            client._token_expiration = time.monotonic() - 1

            await client.get_token()
            assert instance.get_m2m_token.call_count == 2


@pytest.mark.asyncio
async def test_get_token_double_checked_locking(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """Covers the double-checked locking fast path inside the async lock."""
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            # Prime the cache
            await client.get_token()
            assert instance.get_m2m_token.call_count == 1

            # Expire the token
            client._token_expiration = time.monotonic() - 1

            # Fire multiple coroutines concurrently — only one should refresh
            results = await asyncio.gather(*[client.get_token() for _ in range(5)])

            assert all(r == "test-access-token" for r in results)
            # Only one additional refresh due to double-checked locking
            assert instance.get_m2m_token.call_count == 2


# ---------------------------------------------------------------------------
# Expiration buffer
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_expiration_buffer_applied_correctly(config: WristbandM2MAuthConfig) -> None:
    token = TokenResponse(access_token="my-token", expires_in=3600)

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=token)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            await client.get_token()
            after = time.monotonic()

            # Default buffer is 60 → expiration should be around now + 3540
            assert before + 3540 <= client._token_expiration <= after + 3540


@pytest.mark.asyncio
async def test_expiration_buffer_fallback_when_expires_in_lte_buffer(config: WristbandM2MAuthConfig) -> None:
    """When expires_in <= buffer, fallback buffer of 60s is used."""
    short_token = TokenResponse(access_token="short-token", expires_in=30)

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=short_token)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            await client.get_token()

            # expires_in=30, buffer=60 (fallback) → expiration = now + 30 - 60 = ~30s in the past
            assert client._token_expiration < before


@pytest.mark.asyncio
async def test_expiration_buffer_equals_expires_in_uses_fallback(config: WristbandM2MAuthConfig) -> None:
    """When expires_in == buffer exactly, fallback buffer should be used."""
    token = TokenResponse(access_token="my-token", expires_in=60)

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=token)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            before = time.monotonic()
            await client.get_token()

            assert client._token_expiration <= before + 1


# ---------------------------------------------------------------------------
# Retry logic
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_retries_on_5xx_then_succeeds(config: WristbandM2MAuthConfig, mock_token_response: TokenResponse) -> None:
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client_async.asyncio.sleep", new_callable=AsyncMock):
            instance = MockApiClient.return_value
            instance.get_m2m_token = AsyncMock(side_effect=[server_error, mock_token_response])
            instance.close = AsyncMock()

            async with AsyncWristbandM2MAuthClient(config) as client:
                token = await client.get_token()

                assert token == "test-access-token"
                assert instance.get_m2m_token.call_count == 2


@pytest.mark.asyncio
async def test_raises_after_max_retries_on_5xx(config: WristbandM2MAuthConfig) -> None:
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client_async.asyncio.sleep", new_callable=AsyncMock):
            instance = MockApiClient.return_value
            instance.get_m2m_token = AsyncMock(side_effect=server_error)
            instance.close = AsyncMock()

            async with AsyncWristbandM2MAuthClient(config) as client:
                with pytest.raises(httpx.HTTPStatusError):
                    await client.get_token()

                assert instance.get_m2m_token.call_count == 3


@pytest.mark.asyncio
async def test_no_retry_on_4xx(config: WristbandM2MAuthConfig) -> None:
    client_error = httpx.HTTPStatusError(
        "401",
        request=MagicMock(),
        response=MagicMock(status_code=401),
    )

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(side_effect=client_error)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            with pytest.raises(httpx.HTTPStatusError):
                await client.get_token()

            assert instance.get_m2m_token.call_count == 1


@pytest.mark.asyncio
async def test_non_httpx_exception_raised_immediately(config: WristbandM2MAuthConfig) -> None:
    """Non-httpx exceptions should propagate immediately without retrying."""
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(side_effect=RuntimeError("unexpected error"))
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            with pytest.raises(RuntimeError, match="unexpected error"):
                await client.get_token()

            assert instance.get_m2m_token.call_count == 1


@pytest.mark.asyncio
async def test_sleep_called_between_5xx_retries(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """asyncio.sleep should be called between retry attempts but not after the last one."""
    server_error = httpx.HTTPStatusError(
        "500",
        request=MagicMock(),
        response=MagicMock(status_code=500),
    )

    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        with patch("wristband.m2m_auth.m2m_client_async.asyncio.sleep", new_callable=AsyncMock) as mock_sleep:
            instance = MockApiClient.return_value
            instance.get_m2m_token = AsyncMock(side_effect=[server_error, server_error, mock_token_response])
            instance.close = AsyncMock()

            async with AsyncWristbandM2MAuthClient(config) as client:
                await client.get_token()

            assert mock_sleep.call_count == 2


# ---------------------------------------------------------------------------
# Background refresh
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_background_task_started_when_interval_configured(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config_with_background_refresh) as client:
            assert client._background_task is not None
            assert not client._background_task.done()


@pytest.mark.asyncio
async def test_background_task_not_started_without_interval(config: WristbandM2MAuthConfig) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            assert client._background_task is None


@pytest.mark.asyncio
async def test_background_task_cancelled_on_exit(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config_with_background_refresh) as client:
            task = client._background_task
            assert task is not None
            assert not task.done()

        assert task.done()
        assert task.cancelled()


@pytest.mark.asyncio
async def test_background_task_not_started_twice_on_reenter(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """__aenter__ should not create a second task if one already exists."""
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        client = AsyncWristbandM2MAuthClient(config_with_background_refresh)
        await client.__aenter__()
        first_task = client._background_task

        await client.__aenter__()
        assert client._background_task is first_task

        await client.__aexit__(None, None, None)


@pytest.mark.asyncio
async def test_background_refresh_loop_swallows_exception(config: WristbandM2MAuthConfig) -> None:
    """Background loop should log and continue on refresh exceptions."""
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            call_count = [0]

            async def failing_then_stop() -> None:
                call_count[0] += 1
                if call_count[0] == 1:
                    raise RuntimeError("transient failure")
                # Cancel the task on second call to exit the loop
                raise asyncio.CancelledError()

            client._refresh_token = failing_then_stop  # type: ignore[method-assign]

            # Should not raise despite RuntimeError on first call
            with pytest.raises(asyncio.CancelledError):
                await client._background_refresh_loop(0)

            assert call_count[0] == 2


@pytest.mark.asyncio
async def test_background_refresh_loop_calls_refresh(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    """Background loop should call _refresh_token on each tick."""
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            call_count = [0]

            async def counting_refresh() -> None:
                call_count[0] += 1
                if call_count[0] >= 3:
                    raise asyncio.CancelledError()

            client._refresh_token = counting_refresh  # type: ignore[method-assign]

            with patch("wristband.m2m_auth.m2m_client_async.asyncio.sleep", new_callable=AsyncMock):
                with pytest.raises(asyncio.CancelledError):
                    await client._background_refresh_loop(0)

            assert call_count[0] == 3


# ---------------------------------------------------------------------------
# Async context manager
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_context_manager_closes_api_client(
    config: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config) as client:
            token = await client.get_token()
            assert token == "test-access-token"

        instance.close.assert_called_once()


@pytest.mark.asyncio
async def test_async_context_manager_cancels_and_closes(
    config_with_background_refresh: WristbandM2MAuthConfig, mock_token_response: TokenResponse
) -> None:
    with patch("wristband.m2m_auth.m2m_client_async.AsyncWristbandApiClient") as MockApiClient:
        instance = MockApiClient.return_value
        instance.get_m2m_token = AsyncMock(return_value=mock_token_response)
        instance.close = AsyncMock()

        async with AsyncWristbandM2MAuthClient(config_with_background_refresh) as client:
            task = client._background_task
            assert task is not None

        assert task.done()
        assert task.cancelled()
        instance.close.assert_called_once()
