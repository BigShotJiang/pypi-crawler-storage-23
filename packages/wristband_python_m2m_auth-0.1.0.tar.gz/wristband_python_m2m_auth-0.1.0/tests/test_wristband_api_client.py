"""Tests for the internal Wristband API clients."""

import base64
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest

from wristband.m2m_auth.models import TokenResponse, WristbandM2MAuthConfig
from wristband.m2m_auth.wristband_api_client import (
    AsyncWristbandApiClient,
    WristbandApiClient,
    _build_auth_header,
    _build_base_url,
    _parse_token_response,
)


@pytest.fixture
def config() -> WristbandM2MAuthConfig:
    return WristbandM2MAuthConfig(
        client_id="test-client-id",
        client_secret="test-client-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )


# ---------------------------------------------------------------------------
# _build_base_url
# ---------------------------------------------------------------------------


def test_build_base_url(config: WristbandM2MAuthConfig) -> None:
    assert _build_base_url(config) == "https://test.wristband.dev"


def test_build_base_url_uses_vanity_domain(config: WristbandM2MAuthConfig) -> None:
    config2 = WristbandM2MAuthConfig(
        client_id="id",
        client_secret="secret",
        wristband_application_vanity_domain="myapp.us.wristband.dev",
    )
    assert _build_base_url(config2) == "https://myapp.us.wristband.dev"


# ---------------------------------------------------------------------------
# _build_auth_header
# ---------------------------------------------------------------------------


def test_build_auth_header_format(config: WristbandM2MAuthConfig) -> None:
    header = _build_auth_header(config)
    assert header.startswith("Basic ")


def test_build_auth_header_encodes_credentials(config: WristbandM2MAuthConfig) -> None:
    header = _build_auth_header(config)
    encoded = header[len("Basic ") :]
    decoded = base64.b64decode(encoded).decode("utf-8")
    assert decoded == "test-client-id:test-client-secret"


def test_build_auth_header_different_credentials() -> None:
    config = WristbandM2MAuthConfig(
        client_id="my-id",
        client_secret="my-secret",
        wristband_application_vanity_domain="test.wristband.dev",
    )
    header = _build_auth_header(config)
    encoded = header[len("Basic ") :]
    decoded = base64.b64decode(encoded).decode("utf-8")
    assert decoded == "my-id:my-secret"


# ---------------------------------------------------------------------------
# _parse_token_response
# ---------------------------------------------------------------------------


def test_parse_token_response_full() -> None:
    data = {"access_token": "my-token", "expires_in": 3600, "token_type": "Bearer"}
    result = _parse_token_response(data)
    assert result.access_token == "my-token"
    assert result.expires_in == 3600
    assert result.token_type == "Bearer"


def test_parse_token_response_default_token_type() -> None:
    data = {"access_token": "my-token", "expires_in": 3600}
    result = _parse_token_response(data)
    assert result.token_type == "Bearer"


def test_parse_token_response_custom_token_type() -> None:
    data = {"access_token": "my-token", "expires_in": 3600, "token_type": "MAC"}
    result = _parse_token_response(data)
    assert result.token_type == "MAC"


def test_parse_token_response_returns_token_response_instance() -> None:
    data = {"access_token": "my-token", "expires_in": 3600}
    result = _parse_token_response(data)
    assert isinstance(result, TokenResponse)


# ---------------------------------------------------------------------------
# WristbandApiClient - token requests
# ---------------------------------------------------------------------------


def test_sync_client_get_m2m_token_success(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        MockClient.return_value.__enter__ = MagicMock(return_value=MockClient.return_value)
        MockClient.return_value.__exit__ = MagicMock(return_value=False)
        MockClient.return_value.post.return_value = mock_response

        client = WristbandApiClient(config)
        result = client.get_m2m_token()

        assert result.access_token == "my-token"
        assert result.expires_in == 3600


def test_sync_client_raises_on_4xx(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "401", request=MagicMock(), response=MagicMock(status_code=401)
    )

    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        MockClient.return_value.post.return_value = mock_response

        client = WristbandApiClient(config)
        with pytest.raises(httpx.HTTPStatusError):
            client.get_m2m_token()


def test_sync_client_raises_on_5xx(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "500", request=MagicMock(), response=MagicMock(status_code=500)
    )

    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        MockClient.return_value.post.return_value = mock_response

        client = WristbandApiClient(config)
        with pytest.raises(httpx.HTTPStatusError):
            client.get_m2m_token()


def test_sync_client_posts_to_correct_path(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        MockClient.return_value.post.return_value = mock_response

        client = WristbandApiClient(config)
        client.get_m2m_token()

        MockClient.return_value.post.assert_called_once_with(
            "/api/v1/oauth2/token", data={"grant_type": "client_credentials"}
        )


# ---------------------------------------------------------------------------
# WristbandApiClient - close and context manager
# ---------------------------------------------------------------------------


def test_sync_client_close(config: WristbandM2MAuthConfig) -> None:
    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        client = WristbandApiClient(config)
        client.close()
        MockClient.return_value.close.assert_called_once()


def test_sync_client_context_manager(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.Client") as MockClient:
        MockClient.return_value.post.return_value = mock_response

        with WristbandApiClient(config) as client:
            result = client.get_m2m_token()
            assert result.access_token == "my-token"

        MockClient.return_value.close.assert_called_once()


# ---------------------------------------------------------------------------
# AsyncWristbandApiClient - token requests
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_client_get_m2m_token_success(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.aclose = AsyncMock()

        client = AsyncWristbandApiClient(config)
        result = await client.get_m2m_token()

        assert result.access_token == "my-token"
        assert result.expires_in == 3600


@pytest.mark.asyncio
async def test_async_client_raises_on_4xx(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "401", request=MagicMock(), response=MagicMock(status_code=401)
    )

    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.aclose = AsyncMock()

        client = AsyncWristbandApiClient(config)
        with pytest.raises(httpx.HTTPStatusError):
            await client.get_m2m_token()


@pytest.mark.asyncio
async def test_async_client_raises_on_5xx(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.raise_for_status.side_effect = httpx.HTTPStatusError(
        "500", request=MagicMock(), response=MagicMock(status_code=500)
    )

    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.aclose = AsyncMock()

        client = AsyncWristbandApiClient(config)
        with pytest.raises(httpx.HTTPStatusError):
            await client.get_m2m_token()


@pytest.mark.asyncio
async def test_async_client_posts_to_correct_path(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.aclose = AsyncMock()

        client = AsyncWristbandApiClient(config)
        await client.get_m2m_token()

        MockClient.return_value.post.assert_called_once_with(
            "/api/v1/oauth2/token", data={"grant_type": "client_credentials"}
        )


# ---------------------------------------------------------------------------
# AsyncWristbandApiClient - close and context manager
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_async_client_close(config: WristbandM2MAuthConfig) -> None:
    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.aclose = AsyncMock()

        client = AsyncWristbandApiClient(config)
        await client.close()

        MockClient.return_value.aclose.assert_called_once()


@pytest.mark.asyncio
async def test_async_client_context_manager(config: WristbandM2MAuthConfig) -> None:
    mock_response = MagicMock()
    mock_response.json.return_value = {"access_token": "my-token", "expires_in": 3600}
    mock_response.raise_for_status = MagicMock()

    with patch("wristband.m2m_auth.wristband_api_client.httpx.AsyncClient") as MockClient:
        MockClient.return_value.post = AsyncMock(return_value=mock_response)
        MockClient.return_value.aclose = AsyncMock()

        async with AsyncWristbandApiClient(config) as client:
            result = await client.get_m2m_token()
            assert result.access_token == "my-token"

        MockClient.return_value.aclose.assert_called_once()
