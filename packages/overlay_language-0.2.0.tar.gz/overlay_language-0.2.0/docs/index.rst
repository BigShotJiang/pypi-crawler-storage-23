Overlay Language
================

A dependency injection framework with pytest-fixture syntax, plus a
configuration language for declarative programming.

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   tutorial
   overlay-language-tutorial
   specification
   API Reference <api/overlay.language>
