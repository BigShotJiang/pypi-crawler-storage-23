---
name: implement
description: Create an implementation based on a plan.
disable-model-invocation: true
---

# Create an implementation

Based on a plan make an implementation:

- You must add follow the plan, and read research if you have questions.
- Make a test for every section in your implementation using pytest.
