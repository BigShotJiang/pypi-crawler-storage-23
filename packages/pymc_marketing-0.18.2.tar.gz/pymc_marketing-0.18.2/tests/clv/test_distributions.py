#   Copyright 2022 - 2026 The PyMC Labs Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
import numpy as np
import pymc as pm
import pytensor
import pytensor.tensor as pt
import pytest
from lifetimes import BetaGeoBetaBinomFitter as BGBBF
from lifetimes import BetaGeoFitter as BG
from lifetimes import ModifiedBetaGeoFitter as MBG
from lifetimes import ParetoNBDFitter as PF
from lifetimes.generate_data import beta_geometric_beta_binom_model
from numpy.testing import assert_almost_equal
from pymc import Model
from pymc.logprob.utils import ParameterValueError
from pymc.testing import (
    BaseTestDistributionRandom,
    Nat,
    Rplus,
    assert_support_point_is_expected,
    check_selfconsistency_discrete_logcdf,
)

from pymc_marketing.clv.distributions import (
    BetaGeoBetaBinom,
    BetaGeoNBD,
    ModifiedBetaGeoNBD,
    ParetoNBD,
    ShiftedBetaGeometric,
)


class TestParetoNBD:
    @pytest.mark.parametrize(
        "value, r, alpha, s, beta, T",
        [
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                [0.71, 0.61],
                11.67,
                12,
            ),
            (
                np.array([[1.5, 1], [5.3, 4], [6, 2]]),
                0.55,
                11.67,
                0.61,
                10.58,
                [12, 10, 8],
            ),
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                np.full((5, 3), 11.67),
                12,
            ),
        ],
    )
    def test_pareto_nbd(self, value, r, alpha, s, beta, T):
        def lifetimes_wrapper(r, alpha, s, beta, freq, rec, T):
            """Simple wrapper for Vectorizing the lifetimes likelihood function."""
            return PF._conditional_log_likelihood((r, alpha, s, beta), freq, rec, T)

        vectorized_logp = np.vectorize(lifetimes_wrapper)

        with Model():
            pareto_nbd = ParetoNBD("pareto_nbd", r=r, alpha=alpha, s=s, beta=beta, T=T)
        pt = {"pareto_nbd": value}

        assert_almost_equal(
            pm.logp(pareto_nbd, value).eval(),
            vectorized_logp(r, alpha, s, beta, value[..., 1], value[..., 0], T),
            decimal=6,
            err_msg=str(pt),
        )

    def test_pareto_nbd_invalid(self):
        pareto_nbd = ParetoNBD.dist(r=0.55, alpha=10.58, s=0.61, beta=11.67, T=10)
        assert pm.logp(pareto_nbd, np.array([3, -1])).eval() == -np.inf
        assert pm.logp(pareto_nbd, np.array([-1, 1.5])).eval() == -np.inf
        assert pm.logp(pareto_nbd, np.array([11, 1.5])).eval() == -np.inf

    @pytest.mark.parametrize(
        "r_size, alpha_size, s_size, beta_size, pareto_nbd_size, expected_size",
        [
            (None, None, None, None, None, (2,)),
            ((5,), None, None, None, None, (5, 2)),
            (None, (5,), None, None, (5,), (5, 2)),
            (None, None, (5, 1), (1, 3), (5, 3), (5, 3, 2)),
            (None, None, None, None, (5, 3), (5, 3, 2)),
        ],
    )
    def test_pareto_nbd_sample_prior(
        self, r_size, alpha_size, s_size, beta_size, pareto_nbd_size, expected_size
    ):
        with Model():
            r = pm.Gamma(name="r", alpha=5, beta=1, size=r_size)
            alpha = pm.Gamma(name="alpha", alpha=5, beta=1, size=alpha_size)
            s = pm.Gamma(name="s", alpha=5, beta=1, size=s_size)
            beta = pm.Gamma(name="beta", alpha=5, beta=1, size=beta_size)

            T = pm.Data(name="T", value=np.array(10))

            ParetoNBD(
                name="pareto_nbd",
                r=r,
                alpha=alpha,
                s=s,
                beta=beta,
                T=T,
                size=pareto_nbd_size,
            )
            prior = pm.sample_prior_predictive(draws=100)

        assert prior["prior"]["pareto_nbd"][0].shape == (100, *expected_size)


class TestBetaGeoBetaBinom:
    @pytest.mark.parametrize("batch_shape", [(), (5,)])
    def test_logp_matches_lifetimes(self, batch_shape):
        rng = np.random.default_rng(269)

        alpha = pm.draw(
            pm.Gamma.dist(mu=1.2, sigma=3, shape=batch_shape), random_seed=rng
        )
        beta = pm.draw(
            pm.Gamma.dist(mu=0.75, sigma=3, shape=batch_shape), random_seed=rng
        )
        gamma = pm.draw(
            pm.Gamma.dist(mu=0.657, sigma=3, shape=(1,) * len(batch_shape)),
            random_seed=rng,
        )
        delta = pm.draw(pm.Gamma.dist(mu=2.783, sigma=3), random_seed=rng)
        T = pm.draw(pm.DiscreteUniform.dist(1, 10, shape=batch_shape), random_seed=rng)

        t_x = pm.draw(pm.DiscreteUniform.dist(0, T, shape=batch_shape), random_seed=rng)
        x = pm.draw(pm.DiscreteUniform.dist(0, t_x, shape=batch_shape), random_seed=rng)
        value = np.concatenate([t_x[..., None], x[..., None]], axis=-1)

        dist = BetaGeoBetaBinom.dist(alpha, beta, gamma, delta, T)
        np.testing.assert_allclose(
            pm.logp(dist, value).eval(),
            BGBBF._loglikelihood((alpha, beta, gamma, delta), x, t_x, T),
        )

    def test_logp_matches_excel(self):
        # Expected logp values can be found in excel file in http://brucehardie.com/notes/010/
        # Spreadsheet: Parameter estimate

        alpha = 1.204
        beta = 0.750
        gamma = 0.657
        delta = 2.783
        T = 6

        x = np.array([6, 5, 4, 3, 2, 1, 5, 4, 3, 2, 1, 4, 3, 2, 1, 3, 2, 1, 2, 1, 1, 0])
        t_x = np.array(
            [6, 6, 6, 6, 6, 6, 5, 5, 5, 5, 5, 4, 4, 4, 4, 3, 3, 3, 2, 2, 1, 0]
        )
        expected_logp = np.array(
            [
                -2.18167018824,
                -4.29485034929,
                -5.38473334360,
                -5.80915881601,
                -5.65172964525,
                -4.88370164695,
                -3.71682127437,
                -5.09558227343,
                -5.61576884108,
                -5.50636893346,
                -4.76723821904,
                -3.84829625138,
                -5.05936147828,
                -5.19562191019,
                -4.57070931973,
                -3.52745257839,
                -4.51620272962,
                -4.22465969453,
                -3.01199924784,
                -3.58817880928,
                -2.28882847451,
                -1.16751622367,
            ]
        )

        value = np.concatenate([t_x[:, None], x[:, None]], axis=-1)
        dist = BetaGeoBetaBinom.dist(
            alpha=alpha,
            beta=beta,
            gamma=gamma,
            delta=delta,
            T=T,
        )
        np.testing.assert_allclose(
            pm.logp(dist, value).eval(),
            expected_logp,
            rtol=1e-3,
        )

    def test_invalid_value_logp(self):
        beta_geo_beta_binom = BetaGeoBetaBinom.dist(
            alpha=1.20, beta=0.75, gamma=0.66, delta=2.78, T=6
        )
        value = pt.vector("value", shape=(2,))
        logp = pm.logp(beta_geo_beta_binom, value)

        logp_fn = pytensor.function([value], logp)
        assert logp_fn(np.array([3, -1])) == -np.inf
        assert logp_fn(np.array([-1, 1.5])) == -np.inf
        assert logp_fn(np.array([11, 1.5])) == -np.inf

    def test_notimplemented_logp(self):
        dist = BetaGeoBetaBinom.dist(alpha=1, beta=1, gamma=2, delta=2, T=10)
        invalid_value = np.broadcast_to([1, 3], (4, 3, 2))
        with pytest.raises(NotImplementedError):
            pm.logp(dist, invalid_value)

    @pytest.mark.parametrize(
        "alpha_size, beta_size, gamma_size, delta_size, beta_geo_beta_binom_size, expected_size",
        [
            (None, None, None, None, None, (2,)),
            ((5,), None, None, None, None, (5, 2)),
            (None, (5,), None, None, (5,), (5, 2)),
            (None, None, (5, 1), (1, 3), (5, 3), (5, 3, 2)),
            (None, None, None, None, (5, 3), (5, 3, 2)),
        ],
    )
    def test_beta_geo_beta_binom_sample_prior(
        self,
        alpha_size,
        beta_size,
        gamma_size,
        delta_size,
        beta_geo_beta_binom_size,
        expected_size,
    ):
        # Declare simulation params
        T_true = 60
        alpha_true = 1.204
        beta_true = 0.750
        gamma_true = 0.657
        delta_true = 2.783

        # Generate simulated data from lifetimes
        # Fixed seed for reproducibility
        np.random.seed(42)
        lt_bgbb = beta_geometric_beta_binom_model(
            N=T_true,
            alpha=alpha_true,
            beta=beta_true,
            gamma=gamma_true,
            delta=delta_true,
            size=1000,
        )
        lt_frequency = lt_bgbb["frequency"].values
        lt_recency = lt_bgbb["recency"].values

        with Model():
            alpha = pm.Normal(name="alpha", mu=alpha_true, sigma=1e-4, size=alpha_size)
            beta = pm.Normal(name="beta", mu=beta_true, sigma=1e-4, size=beta_size)
            gamma = pm.Normal(name="gamma", mu=gamma_true, sigma=1e-4, size=gamma_size)
            delta = pm.Normal(name="delta", mu=delta_true, sigma=1e-4, size=delta_size)

            T = pm.Data(name="T", value=np.array(T_true))

            BetaGeoBetaBinom(
                name="beta_geo_beta_binom",
                alpha=alpha,
                beta=beta,
                gamma=gamma,
                delta=delta,
                T=T,
                size=beta_geo_beta_binom_size,
            )
            prior = pm.sample_prior_predictive(draws=1000, random_seed=42)
            prior = prior["prior"]["beta_geo_beta_binom"][0]
            recency = prior[:, 0]
            frequency = prior[:, 1]

        assert prior.shape == (1000, *expected_size)

        # With fixed seeds for reproducibility, keeping original loose tolerance
        # due to sampling variance between two independent statistical samples
        np.testing.assert_allclose(lt_frequency.mean(), recency.mean(), rtol=0.9)
        np.testing.assert_allclose(lt_recency.mean(), frequency.mean(), rtol=0.9)


class TestBetaGeoNBD:
    @pytest.mark.parametrize(
        "value, r, alpha, a, b, T",
        [
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                [0.71, 0.61],
                11.67,
                12,
            ),
            (
                np.array([[1.5, 1], [5.3, 4], [6, 2]]),
                0.55,
                11.67,
                0.61,
                10.58,
                [12, 10, 8],
            ),
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                np.full((1), 11.67),
                12,
            ),
        ],
    )
    def test_bg_nbd(self, value, r, alpha, a, b, T):
        def lifetimes_wrapper(
            r, alpha, a, b, freq, rec, T, weights=np.array(1), penalizer_coef=0.0
        ):
            log_r = np.log(r)
            log_alpha = np.log(alpha)
            log_a = np.log(a)
            log_b = np.log(b)

            """Simple wrapper for Vectorizing the lifetimes likelihood function.
            Lifetimes uses the negative log likelihood, so we need to negate it to match PyMC3's logp.
            """
            return -1.0 * BG._negative_log_likelihood(
                (log_r, log_alpha, log_a, log_b), freq, rec, T, weights, penalizer_coef
            )

        vectorized_logp = np.vectorize(lifetimes_wrapper)

        with Model():
            bg_nbd = BetaGeoNBD("bg_nbd", a=a, b=b, r=r, alpha=alpha, T=T)
        pt = {"bg_nbd": value}

        assert_almost_equal(
            pm.logp(bg_nbd, value).eval(),
            vectorized_logp(r, alpha, a, b, value[..., 1], value[..., 0], T),
            decimal=6,
            err_msg=str(pt),
        )

    def test_logp_matches_excel(self):
        # Expected logp values can be found in excel file in http://brucehardie.com/notes/004/
        # Spreadsheet: BGNBD Estimation
        a = 0.793
        b = 2.426
        r = 0.243
        alpha = 4.414
        T = 38.86

        x = np.array([2, 1, 0, 0, 0, 7, 1, 0, 2, 0, 5, 0, 0, 0, 0, 0, 10, 1])
        t_x = np.array(
            [
                30.43,
                1.71,
                0.00,
                0.00,
                0.00,
                29.43,
                5.00,
                0.00,
                35.71,
                0.00,
                24.43,
                0.00,
                0.00,
                0.00,
                0.00,
                0.00,
                34.14,
                4.86,
            ]
        )
        expected_logp = np.array(
            [
                -9.4596,
                -4.4711,
                -0.5538,
                -0.5538,
                -0.5538,
                -21.8644,
                -4.8651,
                -0.5538,
                -9.5367,
                -0.5538,
                -17.3593,
                -0.5538,
                -0.5538,
                -0.5538,
                -0.5538,
                -0.5538,
                -27.3144,
                -4.8520,
            ]
        )

        value = np.concatenate([t_x[:, None], x[:, None]], axis=-1)
        dist = BetaGeoNBD.dist(
            a=a,
            b=b,
            r=r,
            alpha=alpha,
            T=T,
        )
        np.testing.assert_allclose(
            pm.logp(dist, value).eval(),
            expected_logp,
            rtol=2e-3,
        )

    def test_invalid_value_logp(self):
        bg_nbd = BetaGeoNBD.dist(a=1.20, b=0.75, r=0.66, alpha=2.78, T=6)
        value = pt.vector("value", shape=(2,))
        logp = pm.logp(bg_nbd, value)

        logp_fn = pytensor.function([value], logp)
        assert logp_fn(np.array([3, -1])) == -np.inf
        assert logp_fn(np.array([-1, 1.5])) == -np.inf
        assert logp_fn(np.array([11, 1.5])) == -np.inf

    def test_notimplemented_logp(self):
        dist = BetaGeoNBD.dist(a=1, b=1, r=2, alpha=2, T=10)
        invalid_value = np.broadcast_to([1, 3], (4, 3, 2))

        with pytest.raises(NotImplementedError):
            pm.logp(dist, invalid_value)

    @pytest.mark.parametrize(
        "a_size, b_size, r_size, alpha_size, bg_nbd_size, expected_size",
        [
            (None, None, None, None, None, (2,)),
            ((5,), None, None, None, None, (5, 2)),
            (None, (5,), None, None, (5,), (5, 2)),
            (None, None, (5, 1), (1, 3), (5, 3), (5, 3, 2)),
            (None, None, None, None, (5, 3), (5, 3, 2)),
        ],
    )
    def test_bg_nbd_sample_prior(
        self, a_size, b_size, r_size, alpha_size, bg_nbd_size, expected_size
    ):
        with Model():
            a = pm.HalfNormal(name="a", sigma=10, size=a_size)
            b = pm.HalfNormal(name="b", sigma=10, size=b_size)
            r = pm.HalfNormal(name="r", sigma=10, size=r_size)
            alpha = pm.HalfNormal(name="alpha", sigma=10, size=alpha_size)

            T = pm.Data(name="T", value=np.array(10))

            BetaGeoNBD(
                name="bg_nbd",
                a=a,
                b=b,
                r=r,
                alpha=alpha,
                T=T,
                size=bg_nbd_size,
            )
            prior = pm.sample_prior_predictive(draws=100)

        assert prior["prior"]["bg_nbd"][0].shape == (100, *expected_size)


class TestModifiedBetaGeoNBD:
    @pytest.mark.parametrize(
        "value, r, alpha, a, b, T",
        [
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                0.61,
                11.67,
                12,
            ),
            (
                np.array([1.5, 1]),
                [0.45, 0.55],
                10.58,
                [0.71, 0.61],
                11.67,
                12,
            ),
            (
                np.array([[1.5, 1], [5.3, 4], [6, 2]]),
                0.55,
                11.67,
                0.61,
                10.58,
                [12, 10, 8],
            ),
            (
                np.array([1.5, 1]),
                0.55,
                10.58,
                0.61,
                np.full((1), 11.67),
                12,
            ),
        ],
    )
    def test_mbg_nbd(self, value, r, alpha, a, b, T):
        def lifetimes_wrapper(
            r, alpha, a, b, freq, rec, T, weights=np.array(1), penalizer_coef=0.0
        ):
            log_r = np.log(r)
            log_alpha = np.log(alpha)
            log_a = np.log(a)
            log_b = np.log(b)

            """Simple wrapper for Vectorizing the lifetimes likelihood function.
            Lifetimes uses the negative log likelihood, so we need to negate it to match PyMC3's logp.
            """
            return -1.0 * MBG._negative_log_likelihood(
                (log_r, log_alpha, log_a, log_b), freq, rec, T, weights, penalizer_coef
            )

        vectorized_logp = np.vectorize(lifetimes_wrapper)

        with Model():
            mbg_nbd = ModifiedBetaGeoNBD("mbg_nbd", a=a, b=b, r=r, alpha=alpha, T=T)
        pt = {"mbg_nbd": value}

        assert_almost_equal(
            pm.logp(mbg_nbd, value).eval(),
            vectorized_logp(r, alpha, a, b, value[..., 1], value[..., 0], T),
            decimal=6,
            err_msg=str(pt),
        )

    @pytest.mark.parametrize(
        "a_size, b_size, r_size, alpha_size, mbg_nbd_size, expected_size",
        [
            (None, None, None, None, None, (2,)),
            ((5,), None, None, None, None, (5, 2)),
            (None, (5,), None, None, (5,), (5, 2)),
            (None, None, (5, 1), (1, 3), (5, 3), (5, 3, 2)),
            (None, None, None, None, (5, 3), (5, 3, 2)),
        ],
    )
    def test_mbg_nbd_sample_prior(
        self, a_size, b_size, r_size, alpha_size, mbg_nbd_size, expected_size
    ):
        with Model():
            a = pm.HalfNormal(name="a", sigma=10, size=a_size)
            b = pm.HalfNormal(name="b", sigma=10, size=b_size)
            r = pm.HalfNormal(name="r", sigma=10, size=r_size)
            alpha = pm.HalfNormal(name="alpha", sigma=10, size=alpha_size)

            T = pm.Data(name="T", value=np.array(10))

            ModifiedBetaGeoNBD(
                name="mbg_nbd",
                a=a,
                b=b,
                r=r,
                alpha=alpha,
                T=T,
                size=mbg_nbd_size,
            )
            prior = pm.sample_prior_predictive(draws=100)

        assert prior["prior"]["mbg_nbd"][0].shape == (100, *expected_size)

    def test_invalid_value_logp(self):
        mbg_nbd = ModifiedBetaGeoNBD.dist(a=1.20, b=0.75, r=0.66, alpha=2.78, T=6)
        value = pt.vector("value", shape=(2,))
        logp = pm.logp(mbg_nbd, value)

        logp_fn = pytensor.function([value], logp)
        assert logp_fn(np.array([3, -1])) == -np.inf
        assert logp_fn(np.array([-1, 1.5])) == -np.inf
        assert logp_fn(np.array([11, 1.5])) == -np.inf

    def test_notimplemented_logp(self):
        dist = ModifiedBetaGeoNBD.dist(a=1, b=1, r=2, alpha=2, T=10)
        invalid_value = np.broadcast_to([1, 3], (4, 3, 2))

        with pytest.raises(NotImplementedError):
            pm.logp(dist, invalid_value)


class TestShiftedBetaGeometric:
    class TestRandomVariable(BaseTestDistributionRandom):
        pymc_dist = ShiftedBetaGeometric
        pymc_dist_params = {"alpha": 1.0, "beta": 1.0}
        expected_rv_op_params = {"alpha": 1.0, "beta": 1.0}
        tests_to_run = [
            "check_pymc_params_match_rv_op",
            "check_rv_size",
        ]

        def test_random_basic_properties(self):
            """Test basic random sampling properties"""
            # Test with standard parameter values
            alpha_vals = [1.0, 0.5, 2.0]
            beta_vals = [0.5, 1.0, 2.0]

            for alpha in alpha_vals:
                for beta in beta_vals:
                    dist = self.pymc_dist.dist(alpha=alpha, beta=beta, size=1000)
                    draws = dist.eval()

                    # Check basic properties
                    assert np.all(draws > 0)
                    assert np.all(draws.astype(int) == draws)
                    assert np.mean(draws) > 0
                    assert np.var(draws) >= 0

        def test_random_edge_cases(self):
            """Test with very small and large beta and alpha values"""
            beta_vals = [1e10, 1e-10]
            alpha_vals = [1e10, 1e-10]

            for beta in beta_vals:
                for alpha in alpha_vals:
                    dist = self.pymc_dist.dist(alpha=alpha, beta=beta, size=1000)
                    draws = dist.eval()

                    # Check basic properties
                    assert np.all(draws > 0)
                    assert np.all(draws.astype(int) == draws)
                    assert np.mean(draws) >= 1
                    assert np.var(draws) >= 0

    def test_logp(self):
        alpha = pt.scalar("alpha")
        beta = pt.scalar("beta")
        value = pt.vector(dtype="int64")

        # Compile logp function for testing
        dist = ShiftedBetaGeometric.dist(alpha, beta)
        logp = pm.logp(dist, value)
        logp_fn = pytensor.function([value, alpha, beta], logp)

        # Test basic properties of logp
        test_value = np.array([1, 2, 3, 4, 5])
        logp_vals = logp_fn(test_value, 1.2, 3.4)
        assert not np.any(np.isnan(logp_vals))
        assert np.all(np.isfinite(logp_vals))

        neg_value = np.array([-1], dtype="int64")
        assert logp_fn(neg_value, alpha=5, beta=1)[0] == -np.inf

        # Check alpha/beta restrictions
        valid_value = np.array([1], dtype="int64")
        with pytest.raises(ParameterValueError):
            logp_fn(valid_value, alpha=-1, beta=2)  # invalid neg alpha
        with pytest.raises(ParameterValueError):
            logp_fn(valid_value, alpha=0, beta=0)  # invalid zero alpha and beta
        with pytest.raises(ParameterValueError):
            logp_fn(valid_value, alpha=1, beta=-1)  # invalid neg beta

    def test_logp_matches_paper(self):
        # Reference: Fader & Hardie (2007), Appendix B (Figure B1, cells B6:B12)
        # https://faculty.wharton.upenn.edu/wp-content/uploads/2012/04/Fader_hardie_jim_07.pdf
        alpha = 1.0
        beta = 1.0
        t_vec = np.array([1, 2, 3, 4, 5, 6, 7], dtype="int64")
        p_t = np.array([0.5, 0.167, 0.083, 0.05, 0.033, 0.024, 0.018], dtype="float64")
        expected = np.log(p_t)

        alpha_ = pt.scalar("alpha")
        beta_ = pt.scalar("beta")
        value = pt.vector(dtype="int64")
        logp = pm.logp(ShiftedBetaGeometric.dist(alpha_, beta_), value)
        logp_fn = pytensor.function([value, alpha_, beta_], logp)
        np.testing.assert_allclose(logp_fn(t_vec, alpha, beta), expected, rtol=1e-2)

    def test_logcdf(self):
        check_selfconsistency_discrete_logcdf(
            distribution=ShiftedBetaGeometric,
            domain=Nat,
            paramdomains={"alpha": Rplus, "beta": Rplus},
        )

    @pytest.mark.parametrize(
        "alpha, beta, size, expected_shape",
        [
            (1.0, 1.0, None, ()),  # Scalar output
            ([1.0, 2.0], 1.0, None, (2,)),  # Vector output from alpha
            (1.0, [1.0, 2.0], None, (2,)),  # Vector output from beta
            ([1.0, 2.0], [1.0, 2.0], None, (2,)),  # Vector output from alpha and beta
            (
                1.0,
                [1.0, 2.0],
                (1, 2),
                (1, 2),
            ),  # Explicit size with scalar alpha and vector beta
        ],
    )
    def test_support_point(self, alpha, beta, size, expected_shape):
        """Test that support_point returns reasonable values with correct shapes"""
        with pm.Model() as model:
            ShiftedBetaGeometric("x", alpha=alpha, beta=beta, size=size)

        init_point = model.initial_point()["x"]

        # Check shape
        assert init_point.shape == expected_shape

        # Check values are positive integers
        assert np.all(init_point > 0)
        assert np.all(init_point.astype(int) == init_point)

        # Check values are finite and reasonable
        assert np.all(np.isfinite(init_point))
        assert np.all(init_point < 1e6)  # Should not be extremely large

        assert_support_point_is_expected(model, init_point)
