"""whatdoing screens — each screen is a full-page view."""
