"""Tests for Headless Wheel Builder."""
