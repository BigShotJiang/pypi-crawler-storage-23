"""Enable running as python -m headless_wheel_builder."""

from headless_wheel_builder.cli.main import cli

if __name__ == "__main__":
    cli()
