#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for GitRepo class."""

import subprocess

import pytest

from bitbake_project.core import GitRepo


class TestGitRepoInit:
    """Tests for GitRepo initialization."""

    def test_stores_path(self):
        """GitRepo stores the provided path."""
        repo = GitRepo("/path/to/repo")
        assert repo.path == "/path/to/repo"


class TestGitRepoToplevel:
    """Tests for GitRepo.toplevel method."""

    def test_toplevel_returns_root(self, temp_git_repo):
        """toplevel returns repository root."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.toplevel()

        assert result is not None
        assert result.endswith("test_repo") or "test_repo" in result

    def test_toplevel_from_subdir(self, temp_git_repo):
        """toplevel works from subdirectory."""
        subdir = temp_git_repo / "subdir"
        subdir.mkdir()

        repo = GitRepo(str(subdir))
        result = repo.toplevel()

        assert result is not None
        assert "test_repo" in result

    def test_toplevel_nonrepo_returns_none(self, tmp_path):
        """toplevel returns None for non-git directory."""
        repo = GitRepo(str(tmp_path))
        result = repo.toplevel()

        assert result is None


class TestGitRepoCurrentBranch:
    """Tests for GitRepo.current_branch method."""

    def test_returns_branch_name(self, temp_git_repo):
        """current_branch returns the branch name."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.current_branch()

        # Default branch is usually 'master' or 'main'
        assert result in ("master", "main")

    def test_returns_none_on_detached(self, temp_git_repo):
        """current_branch returns None when HEAD is detached."""
        # Create a detached HEAD state
        subprocess.run(
            ["git", "checkout", "--detach"],
            cwd=temp_git_repo,
            check=True,
            capture_output=True
        )

        repo = GitRepo(str(temp_git_repo))
        result = repo.current_branch()

        assert result is None


class TestGitRepoCurrentHead:
    """Tests for GitRepo.current_head method."""

    def test_returns_commit_sha(self, temp_git_repo):
        """current_head returns the current commit SHA."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.current_head()

        assert result is not None
        assert len(result) == 40  # Full SHA length
        assert all(c in "0123456789abcdef" for c in result)

    def test_returns_none_for_nonrepo(self, tmp_path):
        """current_head returns None for non-git directory."""
        repo = GitRepo(str(tmp_path))
        result = repo.current_head()

        assert result is None


class TestGitRepoIsClean:
    """Tests for GitRepo.is_clean method."""

    def test_clean_repo(self, temp_git_repo):
        """is_clean returns True for clean repo."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.is_clean()

        assert result is True

    def test_dirty_with_modified_file(self, temp_git_repo):
        """is_clean returns False when file is modified."""
        readme = temp_git_repo / "README.md"
        readme.write_text("Modified content\n")

        repo = GitRepo(str(temp_git_repo))
        result = repo.is_clean()

        assert result is False

    def test_dirty_with_staged_file(self, temp_git_repo):
        """is_clean returns False when file is staged."""
        new_file = temp_git_repo / "new.txt"
        new_file.write_text("New content\n")
        subprocess.run(
            ["git", "add", "new.txt"],
            cwd=temp_git_repo,
            check=True,
            capture_output=True
        )

        repo = GitRepo(str(temp_git_repo))
        result = repo.is_clean()

        assert result is False

    def test_untracked_files_ignored(self, temp_git_repo):
        """is_clean ignores untracked files."""
        untracked = temp_git_repo / "untracked.txt"
        untracked.write_text("Untracked content\n")

        repo = GitRepo(str(temp_git_repo))
        result = repo.is_clean()

        assert result is True


class TestGitRepoConfigGet:
    """Tests for GitRepo.config_get method."""

    def test_get_existing_config(self, temp_git_repo):
        """config_get returns existing config value."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.config_get("user.email")

        assert result == "test@test.com"

    def test_get_nonexistent_config(self, temp_git_repo):
        """config_get returns None for nonexistent key."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.config_get("nonexistent.key")

        assert result is None


class TestGitRepoConfigSet:
    """Tests for GitRepo.config_set method."""

    def test_set_config(self, temp_git_repo):
        """config_set sets a config value."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.config_set("test.key", "test_value")

        assert result is True

        # Verify it was set
        value = repo.config_get("test.key")
        assert value == "test_value"


class TestGitRepoCheckOutput:
    """Tests for GitRepo.check_output method."""

    def test_runs_git_command(self, temp_git_repo):
        """check_output runs git command and returns output."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.check_output(["status", "--short"])

        # Clean repo should return empty string
        assert result == ""

    def test_returns_stripped_output(self, temp_git_repo):
        """check_output strips whitespace from output."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.check_output(["rev-parse", "--short", "HEAD"])

        # Should be abbreviated SHA with no whitespace
        assert len(result) >= 7
        assert "\n" not in result


class TestGitRepoRun:
    """Tests for GitRepo.run method."""

    def test_run_returns_completed_process(self, temp_git_repo):
        """run returns CompletedProcess object."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.run(["status"], capture_output=True)

        assert hasattr(result, "returncode")
        assert result.returncode == 0

    def test_run_check_raises_on_error(self, temp_git_repo):
        """run with check=True raises on non-zero exit."""
        repo = GitRepo(str(temp_git_repo))

        with pytest.raises(subprocess.CalledProcessError):
            repo.run(["checkout", "nonexistent-branch"], capture_output=True)


class TestGitRepoRevListCount:
    """Tests for GitRepo.rev_list_count method."""

    def test_count_commits(self, temp_git_repo):
        """rev_list_count returns commit count."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.rev_list_count("HEAD")

        assert result >= 1  # At least the initial commit

    def test_count_with_range(self, temp_git_repo):
        """rev_list_count works with range spec."""
        # Add another commit
        new_file = temp_git_repo / "file2.txt"
        new_file.write_text("content")
        subprocess.run(["git", "add", "file2.txt"], cwd=temp_git_repo, check=True, capture_output=True)
        subprocess.run(["git", "commit", "-m", "Second commit"], cwd=temp_git_repo, check=True, capture_output=True)

        repo = GitRepo(str(temp_git_repo))
        total = repo.rev_list_count("HEAD")

        assert total == 2


class TestGitRepoLog:
    """Tests for GitRepo.log method."""

    def test_log_returns_commit_info(self, temp_git_repo):
        """log returns commit information."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.log(["-1", "--oneline"])

        assert "Initial commit" in result

    def test_log_with_format(self, temp_git_repo):
        """log works with custom format."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.log(["-1", "--format=%s"])

        assert result == "Initial commit"


class TestGitRepoOriginUrl:
    """Tests for GitRepo.origin_url method."""

    def test_no_origin_returns_none(self, temp_git_repo):
        """origin_url returns None when no origin is configured."""
        repo = GitRepo(str(temp_git_repo))
        result = repo.origin_url()

        assert result is None

    def test_returns_origin_url(self, temp_git_repo_with_remote):
        """origin_url returns the remote URL."""
        repo_path, remote_path = temp_git_repo_with_remote

        repo = GitRepo(str(repo_path))
        result = repo.origin_url()

        assert result is not None
        assert "remote_repo" in result
