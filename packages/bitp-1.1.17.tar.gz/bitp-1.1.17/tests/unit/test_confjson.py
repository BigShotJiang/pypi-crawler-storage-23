#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for confjson parser - bitbake-setup .conf.json files."""

import json
import os
import tempfile

import pytest

from bitbake_project.commands.confjson import (
    ConfConfig,
    ConfJson,
    ConfOneOfCategory,
    ConfOneOfOption,
    ConfSource,
    discover_registry,
    find_registry_dirs,
    flatten_configurations,
    parse_conf_json,
)


# =============================================================================
# Sample data
# =============================================================================

NESTED_CONF_JSON = {
    "description": "Yocto configurations with nested configs",
    "sources": {
        "bitbake": {
            "git-remote": {
                "remotes": {
                    "origin": {
                        "uri": "git://git.openembedded.org/bitbake"
                    }
                },
                "rev": "master"
            },
            "path": "bitbake"
        },
        "openembedded-core": {
            "git-remote": {
                "remotes": {
                    "origin": {
                        "uri": "git://git.openembedded.org/openembedded-core"
                    }
                },
                "rev": "master"
            },
            "path": "openembedded-core"
        },
        "meta-yocto": {
            "git-remote": {
                "remotes": {
                    "origin": {
                        "uri": "git://git.yoctoproject.org/meta-yocto"
                    }
                },
                "rev": "master"
            },
            "path": "meta-yocto"
        },
    },
    "bitbake-setup": {
        "configurations": [
            {
                "bb-layers": ["openembedded-core/meta", "meta-yocto/meta-yocto-bsp", "meta-yocto/meta-poky"],
                "oe-fragments": ["core/yocto/sstate-mirror-cdn"],
                "configurations": [
                    {
                        "name": "qemux86-64-poky",
                        "description": "Poky for qemux86-64",
                        "oe-fragments": ["machine/qemux86-64", "distro/poky"]
                    },
                    {
                        "name": "qemuarm64-poky",
                        "description": "Poky for qemuarm64",
                        "oe-fragments": ["machine/qemuarm64", "distro/poky"]
                    },
                ]
            }
        ]
    },
    "version": "1.0"
}


OPTIONS_CONF_JSON = {
    "description": "Yocto configurations with options",
    "sources": {
        "bitbake": {
            "git-remote": {
                "uri": "https://git.openembedded.org/bitbake",
                "branch": "master",
                "rev": "master"
            },
            "path": "bitbake"
        },
        "openembedded-core": {
            "git-remote": {
                "uri": "https://git.openembedded.org/openembedded-core",
                "branch": "master",
                "rev": "master"
            },
            "path": "openembedded-core"
        },
    },
    "bitbake-setup": {
        "configurations": [
            {
                "name": "poky",
                "description": "Poky reference distro",
                "bb-layers": ["openembedded-core/meta"],
                "oe-fragments": ["core/yocto/sstate-mirror-cdn"],
                "oe-fragments-one-of": {
                    "machine": {
                        "description": "Available machines",
                        "options": ["machine/qemux86-64", "machine/qemuarm64"]
                    },
                    "distro": {
                        "description": "Available distros",
                        "options": [
                            {"name": "distro/poky", "description": "Reference distro"},
                            {"name": "distro/poky-tiny", "description": "Tiny distro"},
                        ]
                    }
                }
            }
        ]
    },
    "version": "1.0"
}


LOCAL_SOURCE_CONF_JSON = {
    "description": "Config with local source",
    "sources": {
        "bitbake": {
            "git-remote": {
                "uri": "https://git.openembedded.org/bitbake",
                "branch": "master",
                "rev": "master"
            },
            "path": "bitbake"
        },
        "my-layer": {
            "local": {
                "path": "~/my-layers/my-layer"
            }
        },
    },
    "bitbake-setup": {
        "configurations": [
            {
                "name": "my-build",
                "description": "My build",
                "bb-layers": ["openembedded-core/meta", "my-layer"],
            }
        ]
    },
    "version": "1.0"
}


MULTI_REMOTE_CONF_JSON = {
    "description": "Config with multiple remotes",
    "sources": {
        "bitbake": {
            "git-remote": {
                "remotes": {
                    "origin": {"uri": "https://git.openembedded.org/bitbake"},
                    "contrib": {"uri": "https://git.openembedded.org/bitbake-contrib"},
                },
                "branch": "master",
                "rev": "master"
            },
            "path": "bitbake"
        },
    },
    "bitbake-setup": {
        "configurations": [
            {
                "name": "test",
                "description": "Test",
                "bb-layers": [],
            }
        ]
    },
    "version": "1.0"
}


# =============================================================================
# Fixtures
# =============================================================================

@pytest.fixture
def tmp_dir():
    """Create a temp directory for test files."""
    with tempfile.TemporaryDirectory() as d:
        yield d


def _write_conf_json(tmp_dir, filename, data):
    """Write a .conf.json file and return its path."""
    path = os.path.join(tmp_dir, filename)
    with open(path, "w") as f:
        json.dump(data, f)
    return path


# =============================================================================
# Tests: parse_conf_json
# =============================================================================

class TestParseConfJson:
    """Tests for parse_conf_json function."""

    def test_parse_nested_configs(self, tmp_dir):
        """Nested configs are flattened with parent layers/fragments inherited."""
        path = _write_conf_json(tmp_dir, "nested.conf.json", NESTED_CONF_JSON)
        result = parse_conf_json(path)

        assert result.version == "1.0"
        assert result.description == "Yocto configurations with nested configs"
        assert len(result.sources) == 3
        assert len(result.configurations) == 2

        # Check first config inherits parent layers + its own fragments
        cfg0 = result.configurations[0]
        assert cfg0.name == "qemux86-64-poky"
        assert cfg0.description == "Poky for qemux86-64"
        assert cfg0.bb_layers == ["openembedded-core/meta", "meta-yocto/meta-yocto-bsp", "meta-yocto/meta-poky"]
        assert cfg0.oe_fragments == ["core/yocto/sstate-mirror-cdn", "machine/qemux86-64", "distro/poky"]

        # Check second config
        cfg1 = result.configurations[1]
        assert cfg1.name == "qemuarm64-poky"
        assert cfg1.oe_fragments == ["core/yocto/sstate-mirror-cdn", "machine/qemuarm64", "distro/poky"]

    def test_parse_options_config(self, tmp_dir):
        """Config with oe-fragments-one-of is parsed correctly."""
        path = _write_conf_json(tmp_dir, "options.conf.json", OPTIONS_CONF_JSON)
        result = parse_conf_json(path)

        assert len(result.configurations) == 1
        cfg = result.configurations[0]
        assert cfg.name == "poky"
        assert cfg.bb_layers == ["openembedded-core/meta"]
        assert cfg.oe_fragments == ["core/yocto/sstate-mirror-cdn"]

        # Check one-of categories
        assert "machine" in cfg.oe_fragments_one_of
        assert "distro" in cfg.oe_fragments_one_of

        machine = cfg.oe_fragments_one_of["machine"]
        assert machine.description == "Available machines"
        assert len(machine.options) == 2
        assert machine.options[0].name == "machine/qemux86-64"
        assert machine.options[0].description == ""  # Simple string format

        distro = cfg.oe_fragments_one_of["distro"]
        assert distro.description == "Available distros"
        assert len(distro.options) == 2
        assert distro.options[0].name == "distro/poky"
        assert distro.options[0].description == "Reference distro"

    def test_parse_sources_direct_uri(self, tmp_dir):
        """Sources with direct URI format are parsed correctly."""
        path = _write_conf_json(tmp_dir, "options.conf.json", OPTIONS_CONF_JSON)
        result = parse_conf_json(path)

        bitbake_src = next(s for s in result.sources if s.name == "bitbake")
        assert bitbake_src.git_url == "https://git.openembedded.org/bitbake"
        assert bitbake_src.branch == "master"
        assert bitbake_src.rev == "master"
        assert bitbake_src.path == "bitbake"
        assert not bitbake_src.is_local

    def test_parse_sources_remotes(self, tmp_dir):
        """Sources with remotes dict are parsed correctly."""
        path = _write_conf_json(tmp_dir, "nested.conf.json", NESTED_CONF_JSON)
        result = parse_conf_json(path)

        bitbake_src = next(s for s in result.sources if s.name == "bitbake")
        assert bitbake_src.git_url == "git://git.openembedded.org/bitbake"
        assert bitbake_src.remotes == {"origin": "git://git.openembedded.org/bitbake"}

    def test_parse_multiple_remotes(self, tmp_dir):
        """Sources with multiple remotes are parsed correctly."""
        path = _write_conf_json(tmp_dir, "multi.conf.json", MULTI_REMOTE_CONF_JSON)
        result = parse_conf_json(path)

        bitbake_src = next(s for s in result.sources if s.name == "bitbake")
        assert len(bitbake_src.remotes) == 2
        assert "origin" in bitbake_src.remotes
        assert "contrib" in bitbake_src.remotes
        # git_url should be the first one (origin)
        assert bitbake_src.git_url in (
            "https://git.openembedded.org/bitbake",
            "https://git.openembedded.org/bitbake-contrib",
        )

    def test_parse_local_source(self, tmp_dir):
        """Local sources are parsed as is_local with expanded path."""
        path = _write_conf_json(tmp_dir, "local.conf.json", LOCAL_SOURCE_CONF_JSON)
        result = parse_conf_json(path)

        local_src = next(s for s in result.sources if s.name == "my-layer")
        assert local_src.is_local
        assert local_src.local_path == os.path.expanduser("~/my-layers/my-layer")
        assert local_src.git_url == ""

    def test_parse_version(self, tmp_dir):
        """Version field is parsed."""
        path = _write_conf_json(tmp_dir, "test.conf.json", NESTED_CONF_JSON)
        result = parse_conf_json(path)
        assert result.version == "1.0"

    def test_parse_missing_file(self, tmp_dir):
        """FileNotFoundError for missing file."""
        with pytest.raises(FileNotFoundError):
            parse_conf_json(os.path.join(tmp_dir, "nonexistent.conf.json"))

    def test_parse_invalid_json(self, tmp_dir):
        """JSONDecodeError for invalid JSON."""
        path = os.path.join(tmp_dir, "bad.conf.json")
        with open(path, "w") as f:
            f.write("not json {{{")
        with pytest.raises(json.JSONDecodeError):
            parse_conf_json(path)

    def test_parse_empty_config(self, tmp_dir):
        """Empty configurations list results in empty configurations."""
        data = {
            "description": "empty",
            "sources": {},
            "bitbake-setup": {"configurations": []},
            "version": "1.0",
        }
        path = _write_conf_json(tmp_dir, "empty.conf.json", data)
        result = parse_conf_json(path)
        assert result.configurations == []
        assert result.sources == []

    def test_parse_no_bitbake_setup_section(self, tmp_dir):
        """Missing bitbake-setup section results in empty configurations."""
        data = {
            "description": "no bitbake-setup",
            "sources": {},
            "version": "1.0",
        }
        path = _write_conf_json(tmp_dir, "no-setup.conf.json", data)
        result = parse_conf_json(path)
        assert result.configurations == []


# =============================================================================
# Tests: flatten_configurations
# =============================================================================

class TestFlattenConfigurations:
    """Tests for flatten_configurations function."""

    def test_flat_single_config(self):
        """Single named config with no nesting."""
        configs = [
            {
                "name": "test",
                "description": "A test config",
                "bb-layers": ["layer/a", "layer/b"],
                "oe-fragments": ["frag/x"],
            }
        ]
        result = flatten_configurations(configs)
        assert len(result) == 1
        assert result[0].name == "test"
        assert result[0].bb_layers == ["layer/a", "layer/b"]
        assert result[0].oe_fragments == ["frag/x"]

    def test_nested_inheritance(self):
        """Child configs inherit parent layers and fragments."""
        configs = [
            {
                "bb-layers": ["parent-layer"],
                "oe-fragments": ["parent-frag"],
                "configurations": [
                    {
                        "name": "child1",
                        "description": "Child 1",
                        "bb-layers": ["child-layer"],
                        "oe-fragments": ["child-frag"],
                    },
                    {
                        "name": "child2",
                        "description": "Child 2",
                        "oe-fragments": ["other-frag"],
                    },
                ]
            }
        ]
        result = flatten_configurations(configs)
        assert len(result) == 2

        # child1 inherits parent + its own
        assert result[0].name == "child1"
        assert result[0].bb_layers == ["parent-layer", "child-layer"]
        assert result[0].oe_fragments == ["parent-frag", "child-frag"]

        # child2 inherits parent layers (even though it has none of its own)
        assert result[1].name == "child2"
        assert result[1].bb_layers == ["parent-layer"]
        assert result[1].oe_fragments == ["parent-frag", "other-frag"]

    def test_one_of_inheritance(self):
        """oe-fragments-one-of merges from parent to child."""
        configs = [
            {
                "oe-fragments-one-of": {
                    "machine": {
                        "description": "Machines",
                        "options": ["machine/a", "machine/b"],
                    }
                },
                "configurations": [
                    {
                        "name": "child",
                        "description": "Child",
                        "oe-fragments-one-of": {
                            "distro": {
                                "description": "Distros",
                                "options": ["distro/x"],
                            }
                        },
                    }
                ]
            }
        ]
        result = flatten_configurations(configs)
        assert len(result) == 1
        assert "machine" in result[0].oe_fragments_one_of
        assert "distro" in result[0].oe_fragments_one_of

    def test_deep_nesting(self):
        """Three levels of nesting works correctly."""
        configs = [
            {
                "bb-layers": ["L1"],
                "configurations": [
                    {
                        "bb-layers": ["L2"],
                        "configurations": [
                            {
                                "name": "leaf",
                                "description": "Leaf config",
                                "bb-layers": ["L3"],
                            }
                        ]
                    }
                ]
            }
        ]
        result = flatten_configurations(configs)
        assert len(result) == 1
        assert result[0].name == "leaf"
        assert result[0].bb_layers == ["L1", "L2", "L3"]

    def test_unnamed_parent_unnamed_children(self):
        """Unnamed parent with unnamed children produces no configs."""
        configs = [
            {
                "bb-layers": ["layer1"],
                "configurations": [
                    {"bb-layers": ["layer2"]},
                    {"bb-layers": ["layer3"]},
                ]
            }
        ]
        result = flatten_configurations(configs)
        assert len(result) == 0

    def test_named_parent_with_named_children(self):
        """Named parent with named children: parent is non-leaf, children are leaves."""
        configs = [
            {
                "name": "parent",
                "description": "Parent",
                "bb-layers": ["parent-layer"],
                "configurations": [
                    {
                        "name": "child1",
                        "description": "Child 1",
                    },
                    {
                        "name": "child2",
                        "description": "Child 2",
                    },
                ]
            }
        ]
        result = flatten_configurations(configs)
        # Parent is non-leaf because children have names
        assert len(result) == 2
        assert result[0].name == "child1"
        assert result[0].bb_layers == ["parent-layer"]

    def test_empty_configs(self):
        """Empty configuration list returns empty."""
        result = flatten_configurations([])
        assert result == []

    def test_multiple_top_level(self):
        """Multiple top-level configs are all processed."""
        configs = [
            {"name": "a", "description": "A"},
            {"name": "b", "description": "B"},
        ]
        result = flatten_configurations(configs)
        assert len(result) == 2
        assert result[0].name == "a"
        assert result[1].name == "b"


# =============================================================================
# Tests: discover_registry
# =============================================================================

class TestDiscoverRegistry:
    """Tests for discover_registry function."""

    def test_discover_finds_conf_json_files(self, tmp_dir):
        """Finds .conf.json files recursively."""
        # Create some files
        _write_conf_json(tmp_dir, "poky.conf.json", NESTED_CONF_JSON)

        subdir = os.path.join(tmp_dir, "subdir")
        os.makedirs(subdir)
        _write_conf_json(subdir, "other.conf.json", OPTIONS_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert len(results) == 2

        filenames = [r[0] for r in results]
        assert "other.conf.json" in filenames
        assert "poky.conf.json" in filenames

    def test_discover_skips_non_conf_json(self, tmp_dir):
        """Non-.conf.json files are skipped."""
        _write_conf_json(tmp_dir, "poky.conf.json", NESTED_CONF_JSON)
        # Write a regular JSON file
        with open(os.path.join(tmp_dir, "other.json"), "w") as f:
            json.dump({"foo": "bar"}, f)

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        assert results[0][0] == "poky.conf.json"

    def test_discover_skips_invalid_files(self, tmp_dir):
        """Invalid JSON files are skipped."""
        _write_conf_json(tmp_dir, "good.conf.json", NESTED_CONF_JSON)
        bad_path = os.path.join(tmp_dir, "bad.conf.json")
        with open(bad_path, "w") as f:
            f.write("not json {{{")

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        assert results[0][0] == "good.conf.json"

    def test_discover_empty_dir(self, tmp_dir):
        """Empty directory returns empty list."""
        results = discover_registry(tmp_dir)
        assert results == []

    def test_discover_nonexistent_dir(self, tmp_dir):
        """Nonexistent directory returns empty list."""
        results = discover_registry(os.path.join(tmp_dir, "nope"))
        assert results == []

    def test_discover_returns_relative_path(self, tmp_dir):
        """Relative path is relative to the registry dir."""
        subdir = os.path.join(tmp_dir, "a", "b")
        os.makedirs(subdir)
        _write_conf_json(subdir, "test.conf.json", NESTED_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        assert results[0][2] == os.path.join("a", "b", "test.conf.json")

    def test_discover_returns_full_path(self, tmp_dir):
        """Full path is absolute."""
        subdir = os.path.join(tmp_dir, "a", "b")
        os.makedirs(subdir)
        _write_conf_json(subdir, "test.conf.json", NESTED_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        full_path = results[0][1]
        assert os.path.isabs(full_path)
        assert full_path.endswith("test.conf.json")

    def test_discover_parsed_result(self, tmp_dir):
        """Parsed result contains correct ConfJson data."""
        _write_conf_json(tmp_dir, "poky.conf.json", NESTED_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        fname, full_path, rel_path, conf, source_label = results[0]
        assert isinstance(conf, ConfJson)
        assert conf.version == "1.0"
        assert len(conf.sources) == 3
        assert len(conf.configurations) == 2
        assert source_label == ""

    def test_discover_returns_5_tuples(self, tmp_dir):
        """Each result is a 5-tuple with source_label as the last element."""
        _write_conf_json(tmp_dir, "test.conf.json", NESTED_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert len(results) == 1
        assert len(results[0]) == 5

    def test_discover_source_label_propagation(self, tmp_dir):
        """source_label parameter is propagated to all results."""
        _write_conf_json(tmp_dir, "a.conf.json", NESTED_CONF_JSON)
        _write_conf_json(tmp_dir, "b.conf.json", OPTIONS_CONF_JSON)

        results = discover_registry(tmp_dir, source_label="Built-in")
        assert len(results) == 2
        for r in results:
            assert r[4] == "Built-in"

    def test_discover_default_source_label_empty(self, tmp_dir):
        """Default source_label is empty string."""
        _write_conf_json(tmp_dir, "test.conf.json", NESTED_CONF_JSON)

        results = discover_registry(tmp_dir)
        assert results[0][4] == ""


# =============================================================================
# Tests: find_registry_dirs
# =============================================================================

class TestFindRegistryDirs:
    """Tests for find_registry_dirs function."""

    def test_returns_list(self):
        """Always returns a list of tuples (may be empty)."""
        result = find_registry_dirs()
        assert isinstance(result, list)
        for entry in result:
            assert isinstance(entry, tuple)
            assert len(entry) == 2
            path, label = entry
            assert isinstance(path, str)
            assert label in ("Built-in", "User")


# =============================================================================
# Tests: Source parsing edge cases
# =============================================================================

class TestSourceParsing:
    """Tests for source parsing edge cases."""

    def test_source_with_no_path(self, tmp_dir):
        """Source without explicit path uses name as path."""
        data = {
            "description": "test",
            "sources": {
                "myrepo": {
                    "git-remote": {
                        "uri": "https://example.com/myrepo",
                        "branch": "main",
                        "rev": "main"
                    }
                }
            },
            "bitbake-setup": {"configurations": []},
            "version": "1.0",
        }
        path = _write_conf_json(tmp_dir, "test.conf.json", data)
        result = parse_conf_json(path)

        src = result.sources[0]
        assert src.name == "myrepo"
        assert src.path == "myrepo"  # Defaults to name

    def test_source_with_empty_remotes(self, tmp_dir):
        """Source with empty remotes dict."""
        data = {
            "description": "test",
            "sources": {
                "myrepo": {
                    "git-remote": {
                        "remotes": {},
                        "branch": "main",
                        "rev": "abc123"
                    },
                    "path": "myrepo"
                }
            },
            "bitbake-setup": {"configurations": []},
            "version": "1.0",
        }
        path = _write_conf_json(tmp_dir, "test.conf.json", data)
        result = parse_conf_json(path)

        src = result.sources[0]
        assert src.git_url == ""
        assert src.remotes == {}
        assert src.rev == "abc123"
