#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for CLI argument parsing."""

import pytest

from bitbake_project.cli import build_parser, COMMAND_TREE, COMMANDS


class TestBuildParser:
    """Tests for build_parser function."""

    @pytest.fixture
    def parser(self):
        """Create a fresh parser for each test."""
        parser, _ = build_parser()
        return parser

    def test_parser_created(self, parser):
        """Parser is successfully created."""
        assert parser is not None

    def test_completion_flag(self, parser):
        """--completion flag is recognized."""
        args = parser.parse_args(["--completion"])
        assert args.completion is True

    def test_bblayers_option(self, parser):
        """--bblayers option is recognized."""
        args = parser.parse_args(["--bblayers", "/path/to/bblayers.conf", "status"])
        assert args.bblayers == "/path/to/bblayers.conf"

    def test_defaults_file_option(self, parser):
        """--defaults-file option is recognized."""
        args = parser.parse_args(["--defaults-file", "/path/to/.defaults", "status"])
        assert args.defaults_file == "/path/to/.defaults"

    def test_all_flag(self, parser):
        """--all / -a flag is recognized."""
        args = parser.parse_args(["--all", "status"])
        assert args.all is True

        args = parser.parse_args(["-a", "status"])
        assert args.all is True


class TestUpdateCommand:
    """Tests for 'update' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_update_basic(self, parser):
        """Basic update command."""
        args = parser.parse_args(["update"])
        assert args.command == "update"

    def test_update_alias(self, parser):
        """'u' alias for update."""
        args = parser.parse_args(["u"])
        assert args.command == "u"

    def test_update_with_repo(self, parser):
        """Update with specific repo."""
        args = parser.parse_args(["update", "meta-oe"])
        assert args.repo == "meta-oe"

    def test_update_dry_run(self, parser):
        """Update with --dry-run."""
        args = parser.parse_args(["update", "--dry-run"])
        assert args.dry_run is True

    def test_update_resume(self, parser):
        """Update with --resume."""
        args = parser.parse_args(["update", "--resume"])
        assert args.resume is True

    def test_update_resume_file(self, parser):
        """Update with custom resume file."""
        args = parser.parse_args(["update", "--resume-file", "custom.resume"])
        assert args.resume_file == "custom.resume"


class TestExploreCommand:
    """Tests for 'explore' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_explore_basic(self, parser):
        """Basic explore command."""
        args = parser.parse_args(["explore"])
        assert args.command == "explore"

    def test_explore_alias(self, parser):
        """'x' alias for explore."""
        args = parser.parse_args(["x"])
        assert args.command == "x"

    def test_explore_with_repo(self, parser):
        """Explore specific repo."""
        args = parser.parse_args(["explore", "OE-core"])
        assert args.repo == "OE-core"

    def test_explore_status_flag(self, parser):
        """Explore with --status flag."""
        args = parser.parse_args(["explore", "--status"])
        assert args.status is True

    def test_explore_verbose(self, parser):
        """Explore with -v flag."""
        args = parser.parse_args(["explore", "-v"])
        assert args.verbose == 1

        args = parser.parse_args(["explore", "-vv"])
        assert args.verbose == 2

    def test_explore_refresh(self, parser):
        """Explore with --refresh."""
        args = parser.parse_args(["explore", "--refresh"])
        assert args.refresh is True


class TestConfigCommand:
    """Tests for 'config' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_config_basic(self, parser):
        """Basic config command."""
        args = parser.parse_args(["config"])
        assert args.command == "config"

    def test_config_alias(self, parser):
        """'c' alias for config."""
        args = parser.parse_args(["c"])
        assert args.command == "c"

    def test_config_with_repo(self, parser):
        """Config for specific repo."""
        args = parser.parse_args(["config", "1"])
        assert args.repo == "1"

    def test_config_display_name(self, parser):
        """Config with --display-name."""
        args = parser.parse_args(["config", "1", "--display-name", "MyRepo"])
        assert args.display_name == "MyRepo"

    def test_config_update_default(self, parser):
        """Config with --update-default."""
        args = parser.parse_args(["config", "1", "--update-default", "rebase"])
        assert args.update_default == "rebase"


class TestBranchCommand:
    """Tests for 'branch' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_branch_basic(self, parser):
        """Basic branch command."""
        args = parser.parse_args(["branch"])
        assert args.command == "branch"

    def test_branch_alias(self, parser):
        """'b' alias for branch."""
        args = parser.parse_args(["b"])
        assert args.command == "b"

    def test_branch_with_repo_and_target(self, parser):
        """Branch with repo and target branch."""
        args = parser.parse_args(["branch", "1", "kirkstone"])
        assert args.repo == "1"
        assert args.target_branch == "kirkstone"

    def test_branch_all_repos(self, parser):
        """Branch with --all flag."""
        args = parser.parse_args(["branch", "--all", "kirkstone"])
        assert args.all_repos is True
        assert args.repo == "kirkstone"


class TestDepsCommand:
    """Tests for 'deps' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_deps_basic(self, parser):
        """Basic deps command."""
        args = parser.parse_args(["deps"])
        assert args.command == "deps"

    def test_deps_alias(self, parser):
        """'d' alias for deps."""
        args = parser.parse_args(["d"])
        assert args.command == "d"

    def test_deps_layers(self, parser):
        """Deps layers subcommand."""
        args = parser.parse_args(["deps", "layers"])
        assert args.deps_command == "layers"

    def test_deps_layers_with_layer(self, parser):
        """Deps layers with specific layer."""
        args = parser.parse_args(["deps", "layers", "meta-oe"])
        assert args.layer == "meta-oe"

    def test_deps_layers_reverse(self, parser):
        """Deps layers with --reverse."""
        args = parser.parse_args(["deps", "layers", "--reverse", "meta-oe"])
        assert args.reverse is True


class TestExportCommand:
    """Tests for 'export' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_export_basic(self, parser):
        """Basic export command."""
        args = parser.parse_args(["export", "--target-dir", "/tmp/patches"])
        assert args.command == "export"
        assert args.target_dir == "/tmp/patches"

    def test_export_layout(self, parser):
        """Export with --layout."""
        args = parser.parse_args(["export", "--target-dir", "/tmp", "--layout", "per-repo"])
        assert args.layout == "per-repo"

    def test_export_pick(self, parser):
        """Export with --pick."""
        args = parser.parse_args(["export", "--target-dir", "/tmp", "--pick"])
        assert args.pick is True

    def test_export_prep_subcommand(self, parser):
        """Export prep subcommand."""
        args = parser.parse_args(["export", "prep"])
        assert args.export_command == "prep"


class TestProjectsCommand:
    """Tests for 'projects' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_projects_basic(self, parser):
        """Basic projects command."""
        args = parser.parse_args(["projects"])
        assert args.command == "projects"

    def test_projects_alias(self, parser):
        """'p' alias for projects."""
        args = parser.parse_args(["p"])
        assert args.command == "p"

    def test_projects_add(self, parser):
        """Projects add subcommand."""
        args = parser.parse_args(["projects", "add", "/path/to/project"])
        assert args.projects_command == "add"
        assert args.path == "/path/to/project"

    def test_projects_add_with_name(self, parser):
        """Projects add with --name."""
        args = parser.parse_args(["projects", "add", "-n", "MyProject"])
        assert args.name == "MyProject"

    def test_projects_remove(self, parser):
        """Projects remove subcommand."""
        args = parser.parse_args(["projects", "remove", "/path/to/project"])
        assert args.projects_command == "remove"
        assert args.path == "/path/to/project"

    def test_projects_list(self, parser):
        """Projects list subcommand."""
        args = parser.parse_args(["projects", "list"])
        assert args.projects_command == "list"


class TestRecipesCommand:
    """Tests for 'recipes' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_recipes_basic(self, parser):
        """Basic recipes command."""
        args = parser.parse_args(["recipes"])
        assert args.command == "recipes"

    def test_recipes_alias(self, parser):
        """'r' alias for recipes."""
        args = parser.parse_args(["r"])
        assert args.command == "r"

    def test_recipes_with_query(self, parser):
        """Recipes with search query."""
        args = parser.parse_args(["recipes", "linux"])
        assert args.query == "linux"

    def test_recipes_browse(self, parser):
        """Recipes with --browse."""
        args = parser.parse_args(["recipes", "--browse"])
        assert args.browse is True


class TestFragmentsCommand:
    """Tests for 'fragments' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_fragments_basic(self, parser):
        """Basic fragments command."""
        args = parser.parse_args(["fragments"])
        assert args.command == "fragments"

    def test_fragments_aliases(self, parser):
        """'f' and 'frags' aliases for fragments."""
        args = parser.parse_args(["f"])
        assert args.command == "f"

        args = parser.parse_args(["frags"])
        assert args.command == "frags"

    def test_fragments_list(self, parser):
        """Fragments list subcommand."""
        args = parser.parse_args(["fragments", "list"])
        assert args.fragment_command == "list"

    def test_fragments_enable(self, parser):
        """Fragments enable subcommand."""
        args = parser.parse_args(["fragments", "enable", "meta/yocto/feature"])
        assert args.fragment_command == "enable"
        assert "meta/yocto/feature" in args.fragmentname


class TestInfoCommand:
    """Tests for 'info' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_info_basic(self, parser):
        """Basic info command."""
        args = parser.parse_args(["info"])
        assert args.command == "info"

    def test_info_alias(self, parser):
        """'i' alias for info."""
        args = parser.parse_args(["i"])
        assert args.command == "i"

    def test_info_layers(self, parser):
        """Info layers subcommand."""
        args = parser.parse_args(["info", "layers"])
        assert args.info_command == "layers"

    def test_info_vars(self, parser):
        """Info vars subcommand."""
        args = parser.parse_args(["info", "vars"])
        assert args.info_command == "vars"


class TestCommandTree:
    """Tests for COMMAND_TREE structure."""

    def test_command_tree_not_empty(self):
        """COMMAND_TREE has commands."""
        assert len(COMMAND_TREE) > 0

    def test_commands_list_includes_subcommands(self):
        """COMMANDS list includes subcommands."""
        # Find a command with subcommands
        cmd_with_subs = None
        for cmd, desc, subs in COMMAND_TREE:
            if subs:
                cmd_with_subs = (cmd, subs)
                break

        assert cmd_with_subs is not None
        parent_cmd, subcommands = cmd_with_subs

        # Check that subcommands are in COMMANDS
        for subcmd, subdesc in subcommands:
            matching = [c for c, d in COMMANDS if c == subcmd]
            assert len(matching) > 0, f"Subcommand {subcmd} not in COMMANDS"

    def test_all_commands_have_descriptions(self):
        """All commands have descriptions."""
        for cmd, desc, _ in COMMAND_TREE:
            assert desc, f"Command {cmd} has no description"

    def test_expected_commands_present(self):
        """Expected core commands are present."""
        cmd_names = [cmd for cmd, _, _ in COMMAND_TREE]

        expected = ["update", "explore", "config", "branch", "status", "export", "info", "setup", "layer-index"]
        for expected_cmd in expected:
            assert expected_cmd in cmd_names, f"Expected command {expected_cmd} missing"

    def test_create_command_removed(self):
        """'create' is no longer a top-level command."""
        cmd_names = [cmd for cmd, _, _ in COMMAND_TREE]
        assert "create" not in cmd_names

    def test_setup_subcommands_present(self):
        """Setup has all expected subcommands."""
        setup_entry = None
        for cmd, desc, subs in COMMAND_TREE:
            if cmd == "setup":
                setup_entry = (cmd, desc, subs)
                break
        assert setup_entry is not None

        sub_names = [s[0] for s in setup_entry[2]]
        for expected in ["setup shell", "setup clone", "setup configs", "setup apply", "setup registry-copy"]:
            assert expected in sub_names, f"Subcommand {expected} missing from setup"


class TestSetupCloneCommand:
    """Tests for 'setup clone' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_setup_clone_basic(self, parser):
        """Basic setup clone command."""
        args = parser.parse_args(["setup", "clone"])
        assert args.command == "setup"
        assert args.init_command == "clone"

    def test_setup_clone_doit(self, parser):
        """Setup clone with --doit."""
        args = parser.parse_args(["setup", "clone", "--doit"])
        assert args.doit is True

    def test_setup_clone_branch(self, parser):
        """Setup clone with --branch."""
        args = parser.parse_args(["setup", "clone", "-b", "scarthgap"])
        assert args.branch == "scarthgap"

    def test_setup_clone_name(self, parser):
        """Setup clone with --name."""
        args = parser.parse_args(["setup", "clone", "-n", "my-project"])
        assert args.name == "my-project"

    def test_setup_clone_config(self, parser):
        """Setup clone with --config file."""
        args = parser.parse_args(["setup", "clone", "--config", "poky.conf.json"])
        assert args.config == "poky.conf.json"

    def test_setup_clone_config_browse(self, parser):
        """Setup clone with --config (no file = browse)."""
        args = parser.parse_args(["setup", "clone", "--config"])
        assert args.config == ""


class TestSetupRegistryCopyCommand:
    """Tests for 'setup registry-copy' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_setup_registry_copy_basic(self, parser):
        """Basic setup registry-copy command."""
        args = parser.parse_args(["setup", "registry-copy", "myconfig.conf.json"])
        assert args.command == "setup"
        assert args.init_command == "registry-copy"
        assert args.file == "myconfig.conf.json"

    def test_setup_registry_copy_force(self, parser):
        """Setup registry-copy with --force."""
        args = parser.parse_args(["setup", "registry-copy", "--force", "myconfig.conf.json"])
        assert args.force is True

    def test_setup_registry_copy_as(self, parser):
        """Setup registry-copy with --as."""
        args = parser.parse_args(["setup", "registry-copy", "--as", "my-build", "myconfig.conf.json"])
        assert args.as_name == "my-build"
        assert args.file == "myconfig.conf.json"


class TestSetupConfigsCommand:
    """Tests for 'setup configs' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_setup_configs_basic(self, parser):
        """Basic setup configs command."""
        args = parser.parse_args(["setup", "configs"])
        assert args.command == "setup"
        assert args.init_command == "configs"

    def test_setup_configs_layers_dir(self, parser):
        """Setup configs with --layers-dir."""
        args = parser.parse_args(["setup", "configs", "--layers-dir", "my-layers"])
        assert args.layers_dir == "my-layers"


class TestSetupExportCommand:
    """Tests for 'setup export' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_setup_export_basic(self, parser):
        """Basic setup export command."""
        args = parser.parse_args(["setup", "export"])
        assert args.command == "setup"
        assert args.init_command == "export"
        assert args.output is None
        assert args.registry is False
        assert args.project is None

    def test_setup_export_output(self, parser):
        """Setup export with output path."""
        args = parser.parse_args(["setup", "export", "my.conf.json"])
        assert args.output == "my.conf.json"

    def test_setup_export_registry(self, parser):
        """Setup export with --registry."""
        args = parser.parse_args(["setup", "export", "--registry"])
        assert args.registry is True

    def test_setup_export_project(self, parser):
        """Setup export with --project."""
        args = parser.parse_args(["setup", "export", "--project", "my-build"])
        assert args.project == "my-build"

    def test_setup_export_all_options(self, parser):
        """Setup export with all options."""
        args = parser.parse_args(["setup", "export", "--project", "/tmp/proj",
                                  "--registry", "out.conf.json"])
        assert args.project == "/tmp/proj"
        assert args.registry is True
        assert args.output == "out.conf.json"


class TestProjectContextResolution:
    """Tests for project context auto-resolution in main().

    Commands like 'setup clone' create new projects and should NOT auto-resolve
    to the active project. Other commands should resolve as normal.
    """

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_setup_clone_is_new_project_cmd(self, parser):
        """setup clone should be detected as a new-project command."""
        args = parser.parse_args(["setup", "clone", "--config", "--doit"])
        init_cmd = getattr(args, "init_command", None)
        is_new_project_cmd = (
            args.command == "bootstrap"
            or (args.command in ("setup", "init") and init_cmd == "clone")
        )
        assert is_new_project_cmd is True

    def test_bootstrap_is_new_project_cmd(self, parser):
        """bootstrap should be detected as a new-project command."""
        args = parser.parse_args(["bootstrap", "--doit"])
        is_new_project_cmd = (
            args.command == "bootstrap"
            or (args.command in ("setup", "init") and getattr(args, "init_command", None) == "clone")
        )
        assert is_new_project_cmd is True

    def test_setup_apply_is_not_new_project_cmd(self, parser):
        """setup apply should NOT be a new-project command (needs project context)."""
        args = parser.parse_args(["setup", "apply"])
        init_cmd = getattr(args, "init_command", None)
        is_new_project_cmd = (
            args.command == "bootstrap"
            or (args.command in ("setup", "init") and init_cmd == "clone")
        )
        assert is_new_project_cmd is False

    def test_setup_export_is_not_new_project_cmd(self, parser):
        """setup export should NOT be a new-project command."""
        args = parser.parse_args(["setup", "export"])
        init_cmd = getattr(args, "init_command", None)
        is_new_project_cmd = (
            args.command == "bootstrap"
            or (args.command in ("setup", "init") and init_cmd == "clone")
        )
        assert is_new_project_cmd is False

    def test_update_is_not_new_project_cmd(self, parser):
        """update should NOT be a new-project command."""
        args = parser.parse_args(["update"])
        is_new_project_cmd = (
            args.command == "bootstrap"
            or (args.command in ("setup", "init") and getattr(args, "init_command", None) == "clone")
        )
        assert is_new_project_cmd is False
