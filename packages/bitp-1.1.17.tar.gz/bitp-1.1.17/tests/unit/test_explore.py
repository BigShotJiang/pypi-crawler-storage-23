#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for explore command pure functions."""

import pytest

from bitbake_project.commands.explore import (
    _build_file_tree,
    _build_tree_menu_lines,
    _format_refs,
    _parse_commit_browser_output,
)


# ────────────────────────────────────────────────────────────────────
# _format_refs
# ────────────────────────────────────────────────────────────────────

class TestFormatRefs:
    """Tests for tig-style ref decoration formatting."""

    def test_empty_refs(self):
        assert _format_refs([]) == ""

    def test_local_branch(self):
        assert _format_refs([("main", "local")]) == "[main]"

    def test_remote_ref(self):
        assert _format_refs([("origin/main", "remote")]) == "{origin/main}"

    def test_tag(self):
        assert _format_refs([("v1.0", "tag")]) == "<v1.0>"

    def test_mixed_refs(self):
        refs = [("main", "local"), ("origin/main", "remote"), ("v1.0", "tag")]
        assert _format_refs(refs) == "[main] {origin/main} <v1.0>"

    def test_multiple_same_type(self):
        refs = [("main", "local"), ("develop", "local")]
        assert _format_refs(refs) == "[main] [develop]"

    def test_unknown_type_ignored(self):
        refs = [("main", "local"), ("something", "unknown")]
        assert _format_refs(refs) == "[main]"


# ────────────────────────────────────────────────────────────────────
# _build_file_tree
# ────────────────────────────────────────────────────────────────────

class TestBuildFileTree:
    """Tests for building tree structure from flat file paths."""

    def test_single_file_at_root(self):
        tree = _build_file_tree(["README.md"])
        assert tree[""] == [("README.md", False)]

    def test_single_file_in_dir(self):
        tree = _build_file_tree(["src/main.py"])
        # Root has one dir
        assert tree[""] == [("src", True)]
        # src/ has one file
        assert tree["src"] == [("main.py", False)]

    def test_dirs_sorted_before_files(self):
        tree = _build_file_tree([
            "README.md",
            "src/main.py",
        ])
        root = tree[""]
        names = [name for name, _ in root]
        types = [is_dir for _, is_dir in root]
        # src/ (dir) should come before README.md (file)
        assert names == ["src", "README.md"]
        assert types == [True, False]

    def test_alphabetical_within_type(self):
        tree = _build_file_tree([
            "zebra.txt",
            "alpha.txt",
            "lib/foo.py",
            "docs/bar.md",
        ])
        root = tree[""]
        names = [name for name, _ in root]
        # Dirs first (alphabetical), then files (alphabetical)
        assert names == ["docs", "lib", "alpha.txt", "zebra.txt"]

    def test_nested_directories(self):
        tree = _build_file_tree(["a/b/c/file.txt"])
        assert tree[""] == [("a", True)]
        assert tree["a"] == [("b", True)]
        assert tree["a/b"] == [("c", True)]
        assert tree["a/b/c"] == [("file.txt", False)]

    def test_multiple_files_same_dir(self):
        tree = _build_file_tree([
            "src/alpha.py",
            "src/beta.py",
        ])
        children = tree["src"]
        names = [name for name, _ in children]
        assert names == ["alpha.py", "beta.py"]

    def test_sibling_dirs_and_files(self):
        tree = _build_file_tree([
            "meta-oe/recipes/rocksdb/files/patch.diff",
            "meta-oe/recipes/rocksdb/rocksdb_1.0.bb",
        ])
        rocksdb = tree["meta-oe/recipes/rocksdb"]
        names = [name for name, _ in rocksdb]
        types = [is_dir for _, is_dir in rocksdb]
        # files/ dir before rocksdb_1.0.bb file
        assert names == ["files", "rocksdb_1.0.bb"]
        assert types == [True, False]

    def test_empty_file_list(self):
        tree = _build_file_tree([])
        assert tree == {}

    def test_case_insensitive_sort(self):
        tree = _build_file_tree(["Makefile", "README.md", "configure"])
        root = tree[""]
        names = [name for name, _ in root]
        assert names == ["configure", "Makefile", "README.md"]


# ────────────────────────────────────────────────────────────────────
# _build_tree_menu_lines
# ────────────────────────────────────────────────────────────────────

class TestBuildTreeMenuLines:
    """Tests for rendering tree structure as fzf menu lines."""

    def _ids(self, output: str):
        """Extract identifier column from tab-separated output."""
        return [line.split("\t")[0] for line in output.splitlines()]

    def test_single_file(self):
        tree = _build_file_tree(["README.md"])
        output = _build_tree_menu_lines(tree, set())
        ids = self._ids(output)
        assert ids == ["FILE:README.md"]

    def test_collapsed_dir(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs=set())
        ids = self._ids(output)
        # Dir collapsed — only the dir entry, no children
        assert ids == ["DIR:src"]

    def test_expanded_dir(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs={"src"})
        ids = self._ids(output)
        assert ids == ["DIR:src", "FILE:src/main.py"]

    def test_nested_expansion(self):
        tree = _build_file_tree(["a/b/file.txt"])
        # Only expand a, not a/b
        output = _build_tree_menu_lines(tree, expanded_dirs={"a"})
        ids = self._ids(output)
        assert ids == ["DIR:a", "DIR:a/b"]

        # Expand both levels
        output = _build_tree_menu_lines(tree, expanded_dirs={"a", "a/b"})
        ids = self._ids(output)
        assert ids == ["DIR:a", "DIR:a/b", "FILE:a/b/file.txt"]

    def test_expanded_file_no_commits(self):
        tree = _build_file_tree(["f.txt"])
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"},
        )
        ids = self._ids(output)
        # File expanded but no commits loaded — shows "(no commits)"
        assert ids == ["FILE:f.txt", "COMMIT:none:f.txt"]

    def test_expanded_file_with_commits(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "first commit"), ("def456", "second")]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        ids = self._ids(output)
        assert ids == [
            "FILE:f.txt",
            "COMMIT:abc123:f.txt",
            "COMMIT:def456:f.txt",
        ]

    def test_file_commits_has_more(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "commit msg")]}
        output = _build_tree_menu_lines(
            tree, set(),
            expanded_files={"f.txt"},
            file_commits=commits,
            file_has_more={"f.txt": True},
        )
        ids = self._ids(output)
        assert ids == ["FILE:f.txt", "COMMIT:abc123:f.txt", "MORE:f.txt"]

    def test_file_commits_no_more(self):
        tree = _build_file_tree(["f.txt"])
        commits = {"f.txt": [("abc123", "commit msg")]}
        output = _build_tree_menu_lines(
            tree, set(),
            expanded_files={"f.txt"},
            file_commits=commits,
            file_has_more={"f.txt": False},
        )
        ids = self._ids(output)
        # No MORE entry when has_more is False
        assert "MORE:f.txt" not in ids

    def test_highlight_files_colors_name(self):
        tree = _build_file_tree(["f.txt"])
        output_plain = _build_tree_menu_lines(tree, set())
        output_highlight = _build_tree_menu_lines(
            tree, set(), highlight_files={"f.txt"},
        )
        # Highlighted version should contain ANSI yellow escape
        assert "\033[33m" in output_highlight
        assert "\033[33m" not in output_plain

    def test_highlight_only_specified_files(self):
        tree = _build_file_tree(["a.txt", "b.txt"])
        output = _build_tree_menu_lines(
            tree, set(), highlight_files={"a.txt"},
        )
        lines = output.splitlines()
        a_line = [l for l in lines if l.startswith("FILE:a.txt")][0]
        b_line = [l for l in lines if l.startswith("FILE:b.txt")][0]
        assert "\033[33m" in a_line
        assert "\033[33m" not in b_line

    def test_collapsed_marker(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs=set())
        # Collapsed dir uses right-pointing triangle
        assert "\u25b6" in output

    def test_expanded_marker(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, expanded_dirs={"src"})
        # Expanded dir uses down-pointing triangle
        assert "\u25be" in output

    def test_empty_tree(self):
        output = _build_tree_menu_lines({}, set())
        assert output == ""

    def test_dir_trailing_slash(self):
        tree = _build_file_tree(["src/main.py"])
        output = _build_tree_menu_lines(tree, set())
        # Display text should show dir name with trailing slash
        display = output.split("\t")[1]
        assert "src/" in display

    def test_commit_hash_truncated_to_10(self):
        tree = _build_file_tree(["f.txt"])
        full_hash = "abcdef1234567890"
        commits = {"f.txt": [(full_hash, "msg")]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        # ID preserves full hash
        assert f"COMMIT:{full_hash}:f.txt" in output
        # Display truncates to 10 chars
        lines = output.splitlines()
        commit_line = [l for l in lines if l.startswith("COMMIT:")][0]
        display = commit_line.split("\t")[1]
        assert "abcdef1234" in display
        # Full hash should NOT appear in display text
        assert full_hash not in display

    def test_subject_truncated_to_60(self):
        tree = _build_file_tree(["f.txt"])
        long_subject = "A" * 80
        commits = {"f.txt": [("abc123", long_subject)]}
        output = _build_tree_menu_lines(
            tree, set(), expanded_files={"f.txt"}, file_commits=commits,
        )
        lines = output.splitlines()
        commit_line = [l for l in lines if l.startswith("COMMIT:")][0]
        display = commit_line.split("\t")[1]
        assert "A" * 60 in display
        assert "A" * 61 not in display


# ────────────────────────────────────────────────────────────────────
# _parse_commit_browser_output
# ────────────────────────────────────────────────────────────────────

class TestParseCommitBrowserOutput:
    """Tests for parsing fzf output from the commit browser."""

    def test_back(self):
        assert _parse_commit_browser_output("BACK", [], [], []) == ("back", [])

    def test_quit(self):
        assert _parse_commit_browser_output("QUIT", [], [], []) == ("quit", [])

    def test_unknown_output_returns_back(self):
        assert _parse_commit_browser_output("UNKNOWN_ACTION", [], [], []) == ("back", [])

    def test_empty_output_returns_back(self):
        assert _parse_commit_browser_output("", [], [], []) == ("back", [])

    # -- COPY --

    def test_copy_commit(self):
        assert _parse_commit_browser_output("COPY abc123", [], [], []) == ("copy", ["abc123"])

    def test_copy_separator_ignored(self):
        assert _parse_commit_browser_output("COPY ---", [], [], []) == ("copy", [])

    def test_copy_dirty_ignored(self):
        assert _parse_commit_browser_output("COPY DIRTY", [], [], []) == ("copy", [])

    def test_copy_empty_hash(self):
        assert _parse_commit_browser_output("COPY ", [], [], []) == ("copy", [])

    # -- TIG --

    def test_tig_commit(self):
        assert _parse_commit_browser_output("TIG abc123", [], [], []) == ("tig", ["abc123"])

    def test_tig_separator_ignored(self):
        assert _parse_commit_browser_output("TIG ---", [], [], []) == ("tig", [])

    def test_tig_empty(self):
        assert _parse_commit_browser_output("TIG ", [], [], []) == ("tig", [])

    # -- TREE_MODE --

    def test_tree_mode_with_commit(self):
        action, hashes = _parse_commit_browser_output("TREE_MODE abc123", [], [], [])
        assert action == "tree_mode"
        assert hashes == ["abc123"]

    def test_tree_mode_no_commit(self):
        assert _parse_commit_browser_output("TREE_MODE", [], [], []) == ("tree_mode", [])

    def test_tree_mode_separator_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE ---", [], [], []) == ("tree_mode", [])

    def test_tree_mode_dirty_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE DIRTY", [], [], []) == ("tree_mode", [])

    def test_tree_mode_load_more_skipped(self):
        assert _parse_commit_browser_output("TREE_MODE LOAD_MORE", [], [], []) == ("tree_mode", [])

    # -- LOAD_MORE --

    def test_load_more(self):
        assert _parse_commit_browser_output("LOAD_MORE", [], [], []) == ("load_more", [])

    def test_load_more_with_tab_suffix(self):
        # fzf outputs entire line including tab-separated display text
        assert _parse_commit_browser_output("LOAD_MORE\t   (load more...)", [], [], []) == ("load_more", [])

    # -- Simple actions --

    def test_rebase_interactive(self):
        assert _parse_commit_browser_output("REBASE_INTERACTIVE", [], [], []) == ("rebase_interactive", [])

    def test_layer_view(self):
        assert _parse_commit_browser_output("LAYER_VIEW", [], [], []) == ("layer_view", [])

    # -- EXPORT --

    def test_export_single_hash(self):
        all_hashes = ["aaa111bbb222ccc333"]
        action, hashes = _parse_commit_browser_output("EXPORT aaa111bbb2", all_hashes, [], [])
        assert action == "export"
        assert hashes == ["aaa111bbb222ccc333"]

    def test_export_multiple_hashes(self):
        all_hashes = ["aaa111", "bbb222", "ccc333"]
        action, hashes = _parse_commit_browser_output("EXPORT aaa111 ccc333", all_hashes, [], [])
        assert action == "export"
        assert "aaa111" in hashes
        assert "ccc333" in hashes

    def test_export_filters_separators(self):
        action, hashes = _parse_commit_browser_output("EXPORT --- abc1234 DIRTY", [], [], [])
        assert action == "export"
        # --- and DIRTY should be filtered out; abc1234 kept as-is (len >= 7)
        assert hashes == ["abc1234"]

    def test_export_range_markers(self):
        all_hashes = ["aaa", "bbb", "ccc", "ddd", "eee"]
        # Range markers select from bbb to ddd
        action, hashes = _parse_commit_browser_output(
            "EXPORT aaa", all_hashes, [], ["bbb", "ddd"],
        )
        assert action == "export"
        # Should include range bbb..ddd plus individually selected aaa
        assert "aaa" in hashes
        assert "bbb" in hashes
        assert "ccc" in hashes
        assert "ddd" in hashes

    def test_export_upstream_hash_resolution(self):
        all_upstream = ["upstream_abc123def456"]
        action, hashes = _parse_commit_browser_output(
            "EXPORT upstream_abc12", [], all_upstream, [],
        )
        assert action == "export"
        assert hashes == ["upstream_abc123def456"]

    def test_export_unknown_long_hash_kept(self):
        # Hash not in any list but >= 7 chars — kept as-is
        action, hashes = _parse_commit_browser_output("EXPORT abcdef1", [], [], [])
        assert action == "export"
        assert hashes == ["abcdef1"]

    def test_export_short_hash_dropped(self):
        # Hash < 7 chars and not in any list — dropped
        action, hashes = _parse_commit_browser_output("EXPORT abc", [], [], [])
        assert action == "export"
        assert hashes == []


# ────────────────────────────────────────────────────────────────────
# fzf_remote_commit_browser — upstream classification
# ────────────────────────────────────────────────────────────────────

class TestRemoteCommitBrowserUpstreamClassification:
    """Tests for commit provenance classification in fzf_remote_commit_browser."""

    @pytest.fixture(autouse=True)
    def _setup_mocks(self, monkeypatch):
        """Patch SSH and git helpers so no real I/O occurs."""
        from unittest.mock import MagicMock, patch
        self._patches = []

        # Mock subprocess.check_output for local git calls
        self._local_git_outputs = {}
        def fake_check_output(cmd, **kwargs):
            cmd_str = " ".join(cmd) if isinstance(cmd, list) else cmd
            for key, val in self._local_git_outputs.items():
                if key in cmd_str:
                    return val
            return ""
        p = patch("subprocess.check_output", side_effect=fake_check_output)
        self._patches.append(p)
        p.start()

        # Mock ssh_get_commit_log (patched where it lives — imported locally)
        self._remote_ahead = []
        p2 = patch("bitbake_project.commands.ssh_remote.ssh_get_commit_log",
                    side_effect=lambda *a, **kw: list(self._remote_ahead))
        self._patches.append(p2)
        self._mock_ssh_log = p2.start()

        # Mock ssh_run for base_context
        self._base_context_stdout = ""
        def fake_ssh_run(user, host, cmd, **kwargs):
            return MagicMock(returncode=0, stdout=self._base_context_stdout)
        p3 = patch("bitbake_project.commands.ssh_remote.ssh_run",
                    side_effect=fake_ssh_run)
        self._patches.append(p3)
        p3.start()

        # Mock _ssh_mux_opts
        p4 = patch("bitbake_project.commands.ssh_remote._ssh_mux_opts",
                    return_value=["-o", "ControlMaster=auto"])
        self._patches.append(p4)
        p4.start()

        # Mock current_branch
        p5 = patch("bitbake_project.commands.explore.current_branch",
                    return_value="master")
        self._patches.append(p5)
        p5.start()

        # Mock fzf_explore_commits to capture its args
        self._explore_calls = []
        def fake_explore(**kwargs):
            self._explore_calls.append(kwargs)
            return ("back", [])
        p6 = patch("bitbake_project.commands.explore.fzf_explore_commits",
                    side_effect=fake_explore)
        self._patches.append(p6)
        p6.start()

        # Mock os.remove
        p7 = patch("os.remove")
        self._patches.append(p7)
        p7.start()

        yield

        for p in self._patches:
            p.stop()

    def _run_browser(self, local_head="aaa111", upstream_behind=None,
                     remote_ahead=None, base_context=""):
        from bitbake_project.commands.explore import fzf_remote_commit_browser

        # Setup local HEAD
        self._local_git_outputs["rev-parse HEAD"] = local_head + "\n"

        # Setup upstream_behind (git log HEAD..@{upstream})
        if upstream_behind:
            lines = "\n".join(f"{h} {s}" for h, s in upstream_behind)
            self._local_git_outputs["HEAD..@{upstream}"] = lines + "\n"
        else:
            self._local_git_outputs["HEAD..@{upstream}"] = ""

        # Setup remote_ahead
        self._remote_ahead = remote_ahead or []

        # Setup base_context
        self._base_context_stdout = base_context

        return fzf_remote_commit_browser(
            "bruce", "build4", "/opt/poky/meta-virt", "master",
            local_repo="/home/user/meta-virt",
        )

    def test_upstream_on_remote_classified(self):
        """Commits both upstream-behind and on remote get upstream_on_remote tag."""
        self._run_browser(
            upstream_behind=[("uuu111", "upstream commit 1")],
            remote_ahead=[("uuu111", "upstream commit 1"), ("rrr222", "remote only")],
        )
        assert len(self._explore_calls) == 1
        call = self._explore_calls[0]
        assert "uuu111" in call["upstream_on_remote"]
        assert call["upstream_only"] == []

    def test_upstream_only_classified(self):
        """Commits upstream-behind but NOT on remote go to upstream_only."""
        self._run_browser(
            upstream_behind=[("uuu111", "only on upstream")],
            remote_ahead=[("rrr222", "remote only commit")],
        )
        call = self._explore_calls[0]
        assert call["upstream_on_remote"] == set()
        assert call["upstream_only"] == [("uuu111", "only on upstream")]

    def test_mixed_upstream_classification(self):
        """Mix of upstream-on-remote and upstream-only commits."""
        self._run_browser(
            upstream_behind=[
                ("uuu111", "shared with remote"),
                ("uuu222", "only on upstream"),
            ],
            remote_ahead=[
                ("uuu111", "shared with remote"),
                ("rrr333", "remote-only commit"),
            ],
        )
        call = self._explore_calls[0]
        assert "uuu111" in call["upstream_on_remote"]
        assert ("uuu222", "only on upstream") in call["upstream_only"]
        assert len(call["upstream_only"]) == 1

    def test_no_upstream_behind(self):
        """When local is up-to-date with upstream, no upstream_only/on_remote."""
        self._run_browser(
            upstream_behind=[],
            remote_ahead=[("rrr111", "remote commit")],
        )
        call = self._explore_calls[0]
        assert call["upstream_on_remote"] == set()
        assert call["upstream_only"] == []

    def test_base_context_passed_as_local_commits(self):
        """Base context from SSH is passed as local_commits for shared display."""
        self._run_browser(
            remote_ahead=[("rrr111", "remote commit")],
            base_context="bbb111 base commit 1\nbbb222 base commit 2\n",
        )
        call = self._explore_calls[0]
        assert call["local_commits"] == [
            ("bbb111", "base commit 1"),
            ("bbb222", "base commit 2"),
        ]

    def test_behind_count_in_base_ref(self):
        """When behind upstream, base_ref includes ↓N indicator."""
        self._run_browser(
            upstream_behind=[("u1", "c1"), ("u2", "c2")],
            remote_ahead=[("r1", "remote")],
        )
        call = self._explore_calls[0]
        assert "\u2193" in call["base_ref"]  # ↓ character
        assert "2" in call["base_ref"]

    def test_remote_mode_enabled(self):
        """Browser passes remote_mode=True and remote_host to explore_commits."""
        self._run_browser(remote_ahead=[("r1", "commit")])
        call = self._explore_calls[0]
        assert call["remote_mode"] is True
        assert call["remote_host"] == "build4"

    def test_no_remote_commits_returns_back(self):
        """When remote has no new commits, returns (back, [])."""
        from unittest.mock import patch as _patch
        with _patch("bitbake_project.commands.explore.log_message"):
            action, hashes = self._run_browser(remote_ahead=[])
        assert action == "back"
        assert hashes == []
        assert len(self._explore_calls) == 0


# ────────────────────────────────────────────────────────────────────
# select_action_dialog — default_value parameter
# ────────────────────────────────────────────────────────────────────

class TestSelectActionDialogDefaultValue:
    """Tests for select_action_dialog default_value positioning."""

    def test_default_value_marks_option_selected(self):
        from bitbake_project.tui.explore_dialogs import select_action_dialog
        dlg = select_action_dialog(
            "Pick method",
            options=[("am", "Apply", ""), ("fetch", "Fetch", ""), ("save", "Save", "")],
            default_value="fetch",
        )
        selected = [o for o in dlg.options if o.selected]
        assert len(selected) == 1
        assert selected[0].value == "fetch"

    def test_no_default_value_no_selection(self):
        from bitbake_project.tui.explore_dialogs import select_action_dialog
        dlg = select_action_dialog(
            "Pick",
            options=[("a", "A", ""), ("b", "B", "")],
        )
        selected = [o for o in dlg.options if o.selected]
        assert len(selected) == 0

    def test_default_value_not_in_options(self):
        from bitbake_project.tui.explore_dialogs import select_action_dialog
        dlg = select_action_dialog(
            "Pick",
            options=[("a", "A", ""), ("b", "B", "")],
            default_value="nonexistent",
        )
        selected = [o for o in dlg.options if o.selected]
        assert len(selected) == 0

    def test_default_value_first_option(self):
        from bitbake_project.tui.explore_dialogs import select_action_dialog
        dlg = select_action_dialog(
            "Pick",
            options=[("a", "A", ""), ("b", "B", ""), ("c", "C", "")],
            default_value="a",
        )
        assert dlg.options[0].selected is True
        assert dlg.options[1].selected is False
        assert dlg.options[2].selected is False

    def test_default_value_last_option(self):
        from bitbake_project.tui.explore_dialogs import select_action_dialog
        dlg = select_action_dialog(
            "Pick",
            options=[("a", "A", ""), ("b", "B", ""), ("c", "C", "")],
            default_value="c",
        )
        assert dlg.options[0].selected is False
        assert dlg.options[2].selected is True


# ────────────────────────────────────────────────────────────────────
# ExploreMenuState — dialog line reversal for default layout
# ────────────────────────────────────────────────────────────────────

class TestDialogLineReversalDefaultLayout:
    """Tests for dialog line reversal when prepending to default layout."""

    def test_dialog_lines_reversed_for_default_layout(self):
        """In default layout, dialog lines are reversed before prepending."""
        from bitbake_project.tui.explore_dialogs import (
            ExploreMenuState,
            select_action_dialog,
        )
        state = ExploreMenuState()
        dlg = select_action_dialog(
            "Test Dialog",
            options=[("a", "Option A", ""), ("b", "Option B", "")],
        )
        state.show_dialog(dlg)

        # Get original dialog lines
        original_lines = state.get_dialog_menu_lines()
        assert len(original_lines) > 0

        # Simulate what explore.py does for default layout:
        # reverse lines before prepending
        reversed_lines = list(reversed(original_lines))

        # First line of original should be last of reversed (title/header at top)
        assert original_lines[0] == reversed_lines[-1]
        assert original_lines[-1] == reversed_lines[0]

    def test_cursor_position_adjusted_for_reversal(self):
        """Cursor position is flipped for reversed dialog lines."""
        from bitbake_project.tui.explore_dialogs import (
            ExploreMenuState,
            select_action_dialog,
        )
        state = ExploreMenuState()
        dlg = select_action_dialog(
            "Test",
            options=[("a", "A", ""), ("b", "B", ""), ("c", "C", "")],
            default_value="b",
        )
        state.show_dialog(dlg)

        default_line = state.get_default_cursor_line()
        total_dialog = len(state.get_dialog_menu_lines())

        # Adjusted position for reversed lines
        if default_line:
            adjusted = total_dialog - default_line + 1
            assert 1 <= adjusted <= total_dialog

    def test_dialog_state_cleared(self):
        """clear_dialog resets state."""
        from bitbake_project.tui.explore_dialogs import (
            ExploreMenuState,
            select_action_dialog,
        )
        state = ExploreMenuState()
        dlg = select_action_dialog("Test", options=[("a", "A", "")])
        state.show_dialog(dlg)
        assert state.has_dialog() is True

        state.clear_dialog()
        assert state.has_dialog() is False
        assert state.get_dialog_menu_lines() == []
        assert state.get_default_cursor_line() is None
