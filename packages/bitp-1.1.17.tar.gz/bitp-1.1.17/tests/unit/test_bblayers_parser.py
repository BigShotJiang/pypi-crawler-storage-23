#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for BblayersParser class."""

import os

import pytest

from bitbake_project.commands.common import BblayersParser


class TestBblayersParserInit:
    """Tests for BblayersParser initialization."""

    def test_sets_conf_path(self, tmp_path):
        """Parser stores absolute conf path."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text("BBLAYERS = ''")

        parser = BblayersParser(str(bblayers))

        assert parser.conf_path == str(bblayers)
        assert os.path.isabs(parser.conf_path)

    def test_derives_build_dir(self, tmp_path):
        """Parser derives build directory from conf path."""
        build_dir = tmp_path / "build"
        conf_dir = build_dir / "conf"
        conf_dir.mkdir(parents=True)
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text("BBLAYERS = ''")

        parser = BblayersParser(str(bblayers))

        assert parser.build_dir == str(build_dir)

    def test_initializes_topdir(self, tmp_path):
        """TOPDIR is initialized to build directory."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text("BBLAYERS = ''")

        parser = BblayersParser(str(bblayers))

        assert parser.variables["TOPDIR"] == str(tmp_path)

    def test_initializes_bspdir(self, tmp_path):
        """BSPDIR is initialized to parent of build directory."""
        build_dir = tmp_path / "build"
        conf_dir = build_dir / "conf"
        conf_dir.mkdir(parents=True)
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text("BBLAYERS = ''")

        parser = BblayersParser(str(bblayers))

        assert parser.variables["BSPDIR"] == str(tmp_path)


class TestBblayersParserSimpleAssignment:
    """Tests for simple BBLAYERS assignment."""

    def test_parse_simple_quoted(self, tmp_path):
        """Parse simple quoted BBLAYERS value."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('BBLAYERS = "/path/to/layer1 /path/to/layer2"')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert "/path/to/layer1" in parser.bblayers
        assert "/path/to/layer2" in parser.bblayers

    def test_parse_default_assignment(self, tmp_path):
        """Parse ?= default assignment."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('BBLAYERS ?= "/path/to/layer"')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert "/path/to/layer" in parser.bblayers

    def test_parse_weak_default(self, tmp_path):
        """Parse ??= weak default assignment."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('BBLAYERS ??= "/path/to/layer"')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert "/path/to/layer" in parser.bblayers


class TestBblayersParserLineContinuation:
    """Tests for backslash line continuation."""

    def test_parse_multiline(self, tmp_path):
        """Parse BBLAYERS with line continuations."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS ?= " \\
    /path/to/layer1 \\
    /path/to/layer2 \\
    /path/to/layer3 \\
"
''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert len(parser.bblayers) == 3
        assert "/path/to/layer1" in parser.bblayers
        assert "/path/to/layer2" in parser.bblayers
        assert "/path/to/layer3" in parser.bblayers


class TestBblayersParserVariableExpansion:
    """Tests for ${VAR} variable expansion."""

    def test_expand_topdir(self, tmp_path):
        """${TOPDIR} expands to build directory."""
        build_dir = tmp_path / "build"
        conf_dir = build_dir / "conf"
        conf_dir.mkdir(parents=True)
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('BBLAYERS = "${TOPDIR}/../layers/meta"')

        parser = BblayersParser(str(bblayers))
        layers = parser.parse()

        # TOPDIR is build_dir, so ${TOPDIR}/../layers/meta should expand
        # The expanded path contains TOPDIR value
        assert len(layers) == 1
        assert "layers/meta" in layers[0]

    def test_expand_custom_variable(self, tmp_path):
        """Custom variables are expanded."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''MYLAYERS = "/opt/layers"
BBLAYERS = "${MYLAYERS}/meta"
''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert "/opt/layers/meta" in parser.bblayers

    def test_expand_env_variable(self, tmp_path, monkeypatch):
        """Environment variables are available for expansion."""
        monkeypatch.setenv("MY_CUSTOM_PATH", "/my/custom/path")

        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('BBLAYERS = "${HOME}/layers/meta"')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        # HOME should be expanded
        home = os.environ.get("HOME", "")
        if home:
            expected = f"{home}/layers/meta"
            assert expected in parser.bblayers


class TestBblayersParserAppendOperators:
    """Tests for append operators (+=, :append)."""

    def test_plus_equals_appends(self, tmp_path):
        """BBLAYERS += appends to existing."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS = "/path/to/layer1"
BBLAYERS += "/path/to/layer2"
''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert len(parser.bblayers) == 2
        assert "/path/to/layer1" in parser.bblayers
        assert "/path/to/layer2" in parser.bblayers

    def test_colon_append(self, tmp_path):
        """BBLAYERS:append = appends to existing."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS = "/path/to/layer1"
BBLAYERS:append = " /path/to/layer2"
''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert "/path/to/layer1" in parser.bblayers
        assert "/path/to/layer2" in parser.bblayers


class TestBblayersParserRemoveOperator:
    """Tests for :remove operator."""

    def test_colon_remove(self, tmp_path):
        """BBLAYERS:remove removes layer."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS = "/path/to/layer1 /path/to/layer2"
BBLAYERS:remove = "/path/to/layer2"
''')

        parser = BblayersParser(str(bblayers))
        layers = parser.parse()

        assert "/path/to/layer1" in layers
        assert "/path/to/layer2" not in layers


class TestBblayersParserComments:
    """Tests for comment handling."""

    def test_skip_comment_lines(self, tmp_path):
        """Lines starting with # are skipped."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''# This is a comment
BBLAYERS = "/path/to/layer"
# Another comment
''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert len(parser.bblayers) == 1
        assert "/path/to/layer" in parser.bblayers

    def test_skip_empty_lines(self, tmp_path):
        """Empty lines are skipped."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''

BBLAYERS = "/path/to/layer"

''')

        parser = BblayersParser(str(bblayers))
        parser.parse()

        assert len(parser.bblayers) == 1


class TestBblayersParserParse:
    """Tests for parse() method returning final layers."""

    def test_parse_applies_remove(self, tmp_path):
        """parse() applies :remove filtering."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS = "/layer1 /layer2 /layer3"
BBLAYERS:remove = "/layer2"
''')

        parser = BblayersParser(str(bblayers))
        layers = parser.parse()

        assert "/layer1" in layers
        assert "/layer2" not in layers
        assert "/layer3" in layers

    def test_parse_dedupes(self, tmp_path):
        """parse() removes duplicates."""
        conf_dir = tmp_path / "conf"
        conf_dir.mkdir()
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''BBLAYERS = "/layer1"
BBLAYERS += "/layer1"
''')

        parser = BblayersParser(str(bblayers))
        layers = parser.parse()

        # Should only have one /layer1
        assert layers.count("/layer1") == 1


class TestBblayersParserRealWorldConfigs:
    """Tests with realistic bblayers.conf files."""

    def test_poky_style_config(self, tmp_path):
        """Parse Poky-style bblayers.conf."""
        build_dir = tmp_path / "build"
        conf_dir = build_dir / "conf"
        conf_dir.mkdir(parents=True)
        bblayers = conf_dir / "bblayers.conf"
        bblayers.write_text('''# POKY_BBLAYERS_CONF_VERSION is increased each time build/conf/bblayers.conf
# changes incompatibly
POKY_BBLAYERS_CONF_VERSION = "2"

BBPATH = "${TOPDIR}"
BBFILES ?= ""

BBLAYERS ?= " \\
  /home/user/poky/meta \\
  /home/user/poky/meta-poky \\
  /home/user/poky/meta-yocto-bsp \\
  "
''')

        parser = BblayersParser(str(bblayers))
        layers = parser.parse()

        assert len(layers) == 3
        assert "/home/user/poky/meta" in layers
        assert "/home/user/poky/meta-poky" in layers
        assert "/home/user/poky/meta-yocto-bsp" in layers
