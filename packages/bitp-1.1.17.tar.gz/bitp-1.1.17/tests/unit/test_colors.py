#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for Colors class ANSI formatting."""

import pytest

from bitbake_project.core import Colors


class TestColorsConstants:
    """Test that color constants are properly defined."""

    def test_green_constant(self):
        assert Colors.GREEN == "\033[32m"

    def test_yellow_constant(self):
        assert Colors.YELLOW == "\033[33m"

    def test_red_constant(self):
        assert Colors.RED == "\033[31m"

    def test_cyan_constant(self):
        assert Colors.CYAN == "\033[36m"

    def test_magenta_constant(self):
        assert Colors.MAGENTA == "\033[35m"

    def test_bold_constant(self):
        assert Colors.BOLD == "\033[1m"

    def test_dim_constant(self):
        assert Colors.DIM == "\033[2m"

    def test_reset_constant(self):
        assert Colors.RESET == "\033[0m"


class TestColorsFormatting:
    """Test color formatting methods."""

    def test_green_wraps_text(self):
        result = Colors.green("hello")
        assert result == "\033[32mhello\033[0m"

    def test_yellow_wraps_text(self):
        result = Colors.yellow("warning")
        assert result == "\033[33mwarning\033[0m"

    def test_red_wraps_text(self):
        result = Colors.red("error")
        assert result == "\033[31merror\033[0m"

    def test_cyan_wraps_text(self):
        result = Colors.cyan("info")
        assert result == "\033[36minfo\033[0m"

    def test_magenta_wraps_text(self):
        result = Colors.magenta("special")
        assert result == "\033[35mspecial\033[0m"

    def test_dim_wraps_text(self):
        result = Colors.dim("faded")
        assert result == "\033[2mfaded\033[0m"

    def test_bold_wraps_text(self):
        result = Colors.bold("important")
        assert result == "\033[1mimportant\033[0m"


class TestColorsEdgeCases:
    """Test edge cases for color methods."""

    def test_empty_string(self):
        result = Colors.green("")
        assert result == "\033[32m\033[0m"

    def test_string_with_spaces(self):
        result = Colors.green("hello world")
        assert result == "\033[32mhello world\033[0m"

    def test_string_with_special_chars(self):
        result = Colors.green("test\n\ttab")
        assert result == "\033[32mtest\n\ttab\033[0m"

    def test_unicode_string(self):
        result = Colors.green("✓ success")
        assert result == "\033[32m✓ success\033[0m"

    def test_nested_escapes_preserved(self):
        # Colors don't nest, but existing escapes should be preserved
        text = "\033[1mbold\033[0m"
        result = Colors.green(text)
        assert result == f"\033[32m{text}\033[0m"
