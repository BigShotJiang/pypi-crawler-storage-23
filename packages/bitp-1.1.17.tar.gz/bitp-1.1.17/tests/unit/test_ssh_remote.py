#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for SSH remote project support."""

import json
import os
import subprocess
from unittest.mock import MagicMock, patch

import pytest

from bitbake_project.commands.ssh_remote import (
    parse_remote_uri,
    format_remote_uri,
    is_remote_project,
    _parse_summary_output,
    ssh_check_connection,
    ssh_path_exists,
    ssh_get_git_repos,
    ssh_current_branch,
    ssh_get_commit_log,
    ssh_get_branch_info,
    ssh_format_patch_stdout,
    ssh_run_single_repo_update,
    remote_has_bit_cached,
    _ssh_connection_cache,
    _bit_cache,
    _remote_has_tmux,
    _tmux_cache,
    _tmux_session_name,
    _tmux_wrap,
    get_tmux_prefix,
    set_tmux_prefix,
    _log_ssh_stderr,
)
from bitbake_project.commands.projects import (
    _parse_action_key,
    _project_key_valid,
    add_remote_project,
    load_projects,
    save_projects,
    get_current_project,
    set_current_project,
)


class TestParseRemoteUri:
    """Tests for parse_remote_uri."""

    def test_full_uri(self):
        assert parse_remote_uri("bruce@buildhost:/opt/poky") == ("bruce", "buildhost", "/opt/poky")

    def test_no_user(self):
        """When user is omitted, falls back to $USER."""
        with patch.dict(os.environ, {"USER": "testuser"}):
            result = parse_remote_uri("buildhost:/opt/poky")
        assert result == ("testuser", "buildhost", "/opt/poky")

    def test_deep_path(self):
        assert parse_remote_uri("alice@server:/home/alice/yocto/build") == (
            "alice", "server", "/home/alice/yocto/build"
        )

    def test_invalid_no_colon(self):
        assert parse_remote_uri("/local/path") is None

    def test_invalid_empty(self):
        assert parse_remote_uri("") is None

    def test_invalid_colon_no_path(self):
        assert parse_remote_uri("host:") is None

    def test_whitespace_stripped(self):
        assert parse_remote_uri("  bruce@host:/path  ") == ("bruce", "host", "/path")

    def test_hostname_with_domain(self):
        assert parse_remote_uri("user@build.example.com:/opt/yocto") == (
            "user", "build.example.com", "/opt/yocto"
        )


class TestFormatRemoteUri:
    """Tests for format_remote_uri."""

    def test_basic(self):
        assert format_remote_uri("bruce", "host", "/path") == "bruce@host:/path"

    def test_roundtrip(self):
        uri = "alice@server:/opt/yocto"
        user, host, path = parse_remote_uri(uri)
        assert format_remote_uri(user, host, path) == uri


class TestIsRemoteProject:
    """Tests for is_remote_project."""

    def test_remote(self):
        assert is_remote_project({"host": "buildhost", "user": "bruce"}) is True

    def test_local(self):
        assert is_remote_project({"name": "poky"}) is False

    def test_empty(self):
        assert is_remote_project({}) is False

    def test_host_empty_string(self):
        assert is_remote_project({"host": ""}) is False


class TestProjectKeyValid:
    """Tests for _project_key_valid."""

    def test_local_exists(self, tmp_path):
        path = str(tmp_path)
        projects = {path: {"name": "test"}}
        assert _project_key_valid(path, projects) is True

    def test_local_missing(self):
        projects = {"/nonexistent/path": {"name": "test"}}
        assert _project_key_valid("/nonexistent/path", projects) is False

    def test_remote_always_valid(self):
        key = "bruce@host:/opt/poky"
        projects = {key: {"name": "poky", "host": "host", "user": "bruce"}}
        assert _project_key_valid(key, projects) is True

    def test_not_registered(self):
        assert _project_key_valid("/some/path", {}) is False


class TestParseSummaryOutput:
    """Tests for _parse_summary_output."""

    def test_full_output(self):
        output = (
            "REPO_COUNT=5\n"
            "DIRTY_COUNT=2\n"
            "AHEAD=3\n"
            "BEHIND=1\n"
            "BRANCH=master\n"
            "PATH_EXISTS=true\n"
        )
        result = _parse_summary_output(output)
        assert result == {
            "repo_count": 5,
            "dirty_count": 2,
            "ahead": 3,
            "behind": 1,
            "branch": "master",
            "needs_setup": False,
            "exists": True,
        }

    def test_path_not_exists(self):
        output = (
            "REPO_COUNT=0\n"
            "DIRTY_COUNT=0\n"
            "AHEAD=0\n"
            "BEHIND=0\n"
            "BRANCH=\n"
            "NEEDS_SETUP=false\n"
            "PATH_EXISTS=false\n"
        )
        result = _parse_summary_output(output)
        assert result["exists"] is False
        assert result["repo_count"] == 0

    def test_empty_output(self):
        result = _parse_summary_output("")
        assert result["repo_count"] == 0
        assert result["branch"] == ""
        assert result["exists"] is True

    def test_partial_output(self):
        result = _parse_summary_output("REPO_COUNT=3\nBRANCH=kirkstone\n")
        assert result["repo_count"] == 3
        assert result["branch"] == "kirkstone"
        assert result["dirty_count"] == 0

    def test_ignores_non_kv_lines(self):
        output = "some debug line\nREPO_COUNT=1\nmore junk\n"
        result = _parse_summary_output(output)
        assert result["repo_count"] == 1


class TestSshCheckConnection:
    """Tests for ssh_check_connection with mocked SSH."""

    def setup_method(self):
        _ssh_connection_cache.clear()

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert ssh_check_connection("bruce", "host") is True

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert ssh_check_connection("bruce", "host") is False

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_timeout(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired("ssh", 10)
        assert ssh_check_connection("bruce", "host") is False

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_cached(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        ssh_check_connection("bruce", "host")
        ssh_check_connection("bruce", "host")
        # Should only call SSH once due to cache
        assert mock_run.call_count == 1


class TestSshPathExists:
    """Tests for ssh_path_exists."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_exists(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert ssh_path_exists("bruce", "host", "/opt/poky") is True

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_not_exists(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert ssh_path_exists("bruce", "host", "/nonexistent") is False


class TestSshGetGitRepos:
    """Tests for ssh_get_git_repos."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_finds_repos(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout=".\npoky\nlayers/meta-custom\n",
        )
        repos = ssh_get_git_repos("bruce", "host", "/opt/yocto")
        assert "/opt/yocto" in repos
        assert "/opt/yocto/poky" in repos
        assert "/opt/yocto/layers/meta-custom" in repos

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_empty_on_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        assert ssh_get_git_repos("bruce", "host", "/opt") == []


class TestSshCurrentBranch:
    """Tests for ssh_current_branch."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_returns_branch(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="kirkstone\n")
        assert ssh_current_branch("bruce", "host", "/opt/poky") == "kirkstone"

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_returns_none_on_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        assert ssh_current_branch("bruce", "host", "/opt/poky") is None


class TestSshRunSingleRepoUpdate:
    """Tests for ssh_run_single_repo_update."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_rebase_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert ssh_run_single_repo_update("bruce", "host", "/opt/poky", "master", "rebase") is True
        # Check that --rebase was in the command
        cmd = mock_run.call_args[0][2]
        assert "--rebase" in cmd

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_merge_success(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert ssh_run_single_repo_update("bruce", "host", "/opt/poky", "master", "merge") is True
        cmd = mock_run.call_args[0][2]
        assert "--rebase" not in cmd

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_failure(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert ssh_run_single_repo_update("bruce", "host", "/opt/poky", "master", "rebase") is False

    def test_invalid_action(self):
        assert ssh_run_single_repo_update("bruce", "host", "/opt/poky", "master", "invalid") is False

    def test_no_branch(self):
        assert ssh_run_single_repo_update("bruce", "host", "/opt/poky", "", "rebase") is False


class TestRemoteHasBitCached:
    """Tests for remote_has_bit_cached."""

    def setup_method(self):
        _bit_cache.clear()

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_has_bit(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert remote_has_bit_cached("bruce", "host") is True

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_no_bit(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert remote_has_bit_cached("bruce", "host") is False


class TestAddRemoteProject:
    """Tests for add_remote_project."""

    def test_invalid_uri(self, tmp_path, monkeypatch):
        monkeypatch.setenv("HOME", str(tmp_path))
        assert add_remote_project("/local/path") is False

    @patch("bitbake_project.commands.projects.ssh_check_connection", return_value=True)
    @patch("bitbake_project.commands.projects.ssh_path_exists", return_value=True)
    def test_success(self, mock_exists, mock_conn, tmp_path, monkeypatch):
        config_dir = tmp_path / ".config" / "bit"
        config_dir.mkdir(parents=True)
        projects_file = config_dir / "projects.json"
        projects_file.write_text("{}")
        monkeypatch.setattr(
            "bitbake_project.commands.projects._get_projects_file",
            lambda: str(projects_file),
        )
        assert add_remote_project("bruce@host:/opt/poky") is True
        data = json.loads(projects_file.read_text())
        key = "bruce@host:/opt/poky"
        assert key in data
        assert data[key]["host"] == "host"
        assert data[key]["user"] == "bruce"
        assert data[key]["remote_path"] == "/opt/poky"

    @patch("bitbake_project.commands.projects.ssh_check_connection", return_value=False)
    def test_connection_failure(self, mock_conn, tmp_path, monkeypatch):
        config_dir = tmp_path / ".config" / "bit"
        config_dir.mkdir(parents=True)
        projects_file = config_dir / "projects.json"
        projects_file.write_text("{}")
        monkeypatch.setattr(
            "bitbake_project.commands.projects._get_projects_file",
            lambda: str(projects_file),
        )
        assert add_remote_project("bruce@host:/opt/poky") is False


class TestGetSetCurrentProjectRemote:
    """Test get/set current project with remote URIs."""

    def test_set_remote_preserves_uri(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".config" / "bit"
        config_dir.mkdir(parents=True)
        projects_file = config_dir / "projects.json"
        # Pre-register a remote project
        data = {
            "bruce@host:/opt/poky": {
                "name": "poky",
                "host": "host",
                "user": "bruce",
                "remote_path": "/opt/poky",
            }
        }
        projects_file.write_text(json.dumps(data))
        monkeypatch.setattr(
            "bitbake_project.commands.projects._get_projects_file",
            lambda: str(projects_file),
        )
        set_current_project("bruce@host:/opt/poky")
        result = json.loads(projects_file.read_text())
        assert result["__current_project_yocto__"] == "bruce@host:/opt/poky"

    def test_get_remote_current(self, tmp_path, monkeypatch):
        config_dir = tmp_path / ".config" / "bit"
        config_dir.mkdir(parents=True)
        projects_file = config_dir / "projects.json"
        data = {
            "__current_project__": "bruce@host:/opt/poky",
            "bruce@host:/opt/poky": {
                "name": "poky",
                "host": "host",
                "user": "bruce",
                "remote_path": "/opt/poky",
            }
        }
        projects_file.write_text(json.dumps(data))
        monkeypatch.setattr(
            "bitbake_project.commands.projects._get_projects_file",
            lambda: str(projects_file),
        )
        assert get_current_project() == "bruce@host:/opt/poky"


class TestParseActionKey:
    """Tests for _parse_action_key — ACTION:path:cmd parsing with remote URIs."""

    def test_local_path(self):
        path, cmd = _parse_action_key("ACTION:/opt/bruce/poky:explore")
        assert path == "/opt/bruce/poky"
        assert cmd == "explore"

    def test_remote_uri(self):
        path, cmd = _parse_action_key("ACTION:bruce@xps:/home/bruce/poky/:explore")
        assert path == "bruce@xps:/home/bruce/poky/"
        assert cmd == "explore"

    def test_remote_uri_no_trailing_slash(self):
        path, cmd = _parse_action_key("ACTION:bruce@xps:/home/bruce/poky:update")
        assert path == "bruce@xps:/home/bruce/poky"
        assert cmd == "update"

    def test_remote_uri_shell(self):
        path, cmd = _parse_action_key("ACTION:alice@build.example.com:/opt/yocto:shell")
        assert path == "alice@build.example.com:/opt/yocto"
        assert cmd == "shell"

    def test_non_action_key(self):
        path, cmd = _parse_action_key("/opt/bruce/poky")
        assert path == "/opt/bruce/poky"
        assert cmd is None

    def test_non_action_remote_uri(self):
        path, cmd = _parse_action_key("bruce@xps:/home/bruce/poky/")
        assert path == "bruce@xps:/home/bruce/poky/"
        assert cmd is None


class TestLogSshStderr:
    """Tests for _log_ssh_stderr handling both bytes and str."""

    @patch("bitbake_project.commands.ssh_remote.log_message", create=True)
    def test_handles_bytes(self, mock_log):
        with patch("bitbake_project.commands.ssh_remote._log_ssh_stderr.__module__",
                    "bitbake_project.commands.ssh_remote"):
            _log_ssh_stderr(b"some error\n")

    def test_handles_empty_bytes(self):
        _log_ssh_stderr(b"")

    def test_handles_empty_str(self):
        _log_ssh_stderr("")

    def test_handles_none(self):
        _log_ssh_stderr(None)


class TestRemoteHasTmux:
    """Tests for _remote_has_tmux."""

    def setup_method(self):
        _tmux_cache.clear()

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_has_tmux(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        assert _remote_has_tmux("bruce", "host") is True

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_no_tmux(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1)
        assert _remote_has_tmux("bruce", "host") is False

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_cached(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0)
        _remote_has_tmux("bruce", "host")
        _remote_has_tmux("bruce", "host")
        assert mock_run.call_count == 1

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_timeout(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired("ssh", 10)
        assert _remote_has_tmux("bruce", "host") is False


class TestTmuxSessionName:
    """Tests for _tmux_session_name."""

    def test_simple_path(self):
        assert _tmux_session_name("/home/bruce/yocto-build") == "bit-yocto-build"

    def test_trailing_slash(self):
        assert _tmux_session_name("/opt/poky/") == "bit-poky"

    def test_special_chars(self):
        assert _tmux_session_name("/opt/my project.v2") == "bit-my-project-v2"

    def test_underscores_preserved(self):
        assert _tmux_session_name("/opt/my_build") == "bit-my_build"

    def test_hyphens_preserved(self):
        assert _tmux_session_name("/opt/yocto-kirkstone") == "bit-yocto-kirkstone"


class TestTmuxWrap:
    """Tests for _tmux_wrap."""

    def test_contains_has_session_check(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore")
        assert "tmux has-session" in result
        assert "bit-poky" in result

    def test_contains_new_window(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore")
        assert "tmux new-window" in result
        assert "explore" in result

    def test_contains_new_session(self):
        result = _tmux_wrap("bit-poky", "shell", "bash -l")
        assert "tmux new-session" in result
        assert "shell" in result

    def test_contains_attach(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore")
        assert "tmux attach-session" in result

    def test_no_prefix(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore")
        assert "set-option" not in result

    def test_with_prefix(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore", prefix="C-a")
        assert "set-option" in result
        assert "C-a" in result
        # New session should be detached when prefix is set
        assert "new-session -d" in result

    def test_prefix_only_on_new_session(self):
        result = _tmux_wrap("bit-poky", "explore", "bit explore", prefix="C-a")
        # set-option should appear after new-session, not in the has-session branch
        has_session_branch = result.split("else")[0]
        assert "set-option" not in has_session_branch


class TestTmuxPrefixConfig:
    """Tests for get_tmux_prefix / set_tmux_prefix."""

    def test_default_prefix(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "bitbake_project.commands.ssh_remote._BIT_CONFIG_DIR",
            str(tmp_path),
        )
        assert get_tmux_prefix() == "C-a"

    def test_set_and_get(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "bitbake_project.commands.ssh_remote._BIT_CONFIG_DIR",
            str(tmp_path),
        )
        set_tmux_prefix("C-s")
        assert get_tmux_prefix() == "C-s"

    def test_preserves_other_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "bitbake_project.commands.ssh_remote._BIT_CONFIG_DIR",
            str(tmp_path),
        )
        config_file = tmp_path / "projects.json"
        config_file.write_text(json.dumps({"__other_key__": "value"}))
        set_tmux_prefix("C-a")
        data = json.loads(config_file.read_text())
        assert data["__other_key__"] == "value"
        assert data["__tmux_prefix__"] == "C-a"

    def test_reads_from_existing_config(self, tmp_path, monkeypatch):
        monkeypatch.setattr(
            "bitbake_project.commands.ssh_remote._BIT_CONFIG_DIR",
            str(tmp_path),
        )
        config_file = tmp_path / "projects.json"
        config_file.write_text(json.dumps({"__tmux_prefix__": "C-q"}))
        assert get_tmux_prefix() == "C-q"


class TestSshGetCommitLog:
    """Tests for ssh_get_commit_log."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_parses_commit_lines(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="abc123def456 First commit\nfed654cba321 Second commit\n",
        )
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo", count=10)
        assert len(result) == 2
        assert result[0] == ("abc123def456", "First commit")
        assert result[1] == ("fed654cba321", "Second commit")

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_empty_output(self, mock_run):
        mock_run.return_value = MagicMock(returncode=0, stdout="")
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo")
        assert result == []

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_failure_returns_empty(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo")
        assert result == []

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_timeout_returns_empty(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="ssh", timeout=30)
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo")
        assert result == []

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_hash_only_line(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="abc123def456\n",
        )
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo")
        assert len(result) == 1
        assert result[0] == ("abc123def456", "")

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_since_uses_range_spec(self, mock_run):
        """When since is set, use hash..HEAD range instead of -count."""
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="abc123 New commit\n",
        )
        result = ssh_get_commit_log("bruce", "host", "/path/to/repo",
                                     since="deadbeef")
        assert len(result) == 1
        # Verify the command used range spec, not -count
        cmd_arg = mock_run.call_args[0][2]
        assert "deadbeef..HEAD" in cmd_arg
        assert "-200" not in cmd_arg


class TestSshGetBranchInfo:
    """Tests for ssh_get_branch_info."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_branch_and_upstream(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="BRANCH=main\nUPSTREAM=origin/main\n",
        )
        branch, upstream = ssh_get_branch_info("bruce", "host", "/repo")
        assert branch == "main"
        assert upstream == "origin/main"

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_branch_no_upstream(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="BRANCH=feature\n",
        )
        branch, upstream = ssh_get_branch_info("bruce", "host", "/repo")
        assert branch == "feature"
        assert upstream == ""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_timeout_returns_empty(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="ssh", timeout=15)
        branch, upstream = ssh_get_branch_info("bruce", "host", "/repo")
        assert branch == ""
        assert upstream == ""


class TestSshFormatPatchStdout:
    """Tests for ssh_format_patch_stdout."""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_single_commit(self, mock_run):
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="From abc123\nSubject: test\n---\ndiff\n",
        )
        result = ssh_format_patch_stdout("bruce", "host", "/repo", ["abc123"])
        assert "From abc123" in result

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_empty_commits(self, mock_run):
        result = ssh_format_patch_stdout("bruce", "host", "/repo", [])
        assert result == ""
        mock_run.assert_not_called()

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_failure_returns_empty(self, mock_run):
        mock_run.return_value = MagicMock(returncode=1, stdout="")
        result = ssh_format_patch_stdout("bruce", "host", "/repo", ["abc123"])
        assert result == ""

    @patch("bitbake_project.commands.ssh_remote.ssh_run")
    def test_timeout_returns_empty(self, mock_run):
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="ssh", timeout=120)
        result = ssh_format_patch_stdout("bruce", "host", "/repo", ["abc123"])
        assert result == ""


class TestSplitMboxToFiles:
    """Tests for _split_mbox_to_files."""

    def test_split_two_patches(self, tmp_path):
        from bitbake_project.commands.common import _split_mbox_to_files
        mbox = (
            "From abc123\n"
            "Subject: [PATCH 1/2] First change\n"
            "---\ndiff --git a/f b/f\n"
            "From def456\n"
            "Subject: [PATCH 2/2] Second change\n"
            "---\ndiff --git a/g b/g\n"
        )
        files = _split_mbox_to_files(mbox, str(tmp_path / "patches"))
        assert len(files) == 2
        assert "0001-" in os.path.basename(files[0])
        assert "0002-" in os.path.basename(files[1])
        # Verify content
        with open(files[0]) as f:
            assert "First change" in f.read()

    def test_single_patch(self, tmp_path):
        from bitbake_project.commands.common import _split_mbox_to_files
        mbox = "From abc123\nSubject: Fix bug\n---\ndiff\n"
        files = _split_mbox_to_files(mbox, str(tmp_path / "out"))
        assert len(files) == 1

    def test_empty_mbox(self, tmp_path):
        from bitbake_project.commands.common import _split_mbox_to_files
        files = _split_mbox_to_files("", str(tmp_path / "empty"))
        assert files == []


class TestMatchLocalRepo:
    """Tests for _match_local_repo."""

    def test_basename_match(self):
        from bitbake_project.commands.common import _match_local_repo
        projects = {
            "/home/user/linux-yocto": {"name": "linux-yocto"},
            "/home/user/meta-oe": {"name": "meta-oe"},
        }
        matches = _match_local_repo("/build/linux-yocto", projects)
        assert matches == ["/home/user/linux-yocto"]

    def test_no_match(self):
        from bitbake_project.commands.common import _match_local_repo
        projects = {
            "/home/user/meta-oe": {"name": "meta-oe"},
        }
        matches = _match_local_repo("/build/linux-yocto", projects)
        assert matches == []

    def test_skip_remote_projects(self):
        from bitbake_project.commands.common import _match_local_repo
        projects = {
            "/build/linux-yocto": {"name": "linux-yocto", "host": "remote"},
            "/home/user/linux-yocto": {"name": "linux-yocto"},
        }
        matches = _match_local_repo("/build/linux-yocto", projects)
        assert matches == ["/home/user/linux-yocto"]


class TestHandlePullPatches:
    """Tests for _handle_pull_patches in explore.py."""

    @patch("bitbake_project.commands.projects.load_projects")
    def test_no_remotes_shows_message(self, mock_load):
        """When no remote projects exist, show a message."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "/home/user/poky": {"name": "poky"},
        }
        dialog_state = MagicMock()
        repo_info = {}

        with patch("bitbake_project.commands.explore.log_message") as mock_log:
            _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)
            mock_log.assert_called_once()
            assert "No remote projects" in mock_log.call_args[0][0]

    @patch("bitbake_project.commands.projects.load_projects")
    @patch("bitbake_project.commands.ssh_remote.ssh_check_connection")
    @patch("bitbake_project.commands.ssh_remote.ssh_get_git_repos")
    @patch("bitbake_project.commands.ssh_remote.ssh_current_branch")
    @patch("bitbake_project.commands.explore.fzf_remote_commit_browser")
    def test_single_remote_auto_selects(self, mock_browser, mock_branch,
                                         mock_repos, mock_conn, mock_load):
        """When one remote exists, skip picker and go straight to it."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "/home/user/poky": {"name": "poky"},
            "bruce@build4:/opt/bruce/poky": {
                "name": "poky", "host": "build4",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
        }
        mock_conn.return_value = True
        mock_repos.return_value = ["/opt/bruce/poky/meta-virt"]
        mock_branch.return_value = "master"
        mock_browser.return_value = ("back", [])

        dialog_state = MagicMock()
        repo_info = {}

        _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)

        # Should auto-select the single remote, find matching repo, browse
        mock_conn.assert_called_once_with("bruce", "build4")
        mock_repos.assert_called_once_with("bruce", "build4", "/opt/bruce/poky")
        mock_browser.assert_called_once_with("bruce", "build4",
                                              "/opt/bruce/poky/meta-virt", "master",
                                              local_repo="/home/user/meta-virt")

    @patch("bitbake_project.commands.projects.load_projects")
    @patch("bitbake_project.commands.ssh_remote.ssh_check_connection")
    @patch("bitbake_project.commands.ssh_remote.ssh_get_git_repos")
    def test_no_repos_on_remote_shows_message(self, mock_repos, mock_conn, mock_load):
        """When remote has no repos, show a message."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "bruce@build4:/opt/bruce/poky": {
                "name": "poky", "host": "build4",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
        }
        mock_conn.return_value = True
        mock_repos.return_value = []

        dialog_state = MagicMock()
        repo_info = {}

        with patch("bitbake_project.commands.explore.log_message") as mock_log:
            _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)
            # Last call should be the error (first is "Connecting to...")
            assert mock_log.call_count == 2
            assert "No git repos" in mock_log.call_args_list[-1][0][0]

    @patch("bitbake_project.commands.projects.load_projects")
    @patch("bitbake_project.commands.ssh_remote.ssh_check_connection")
    def test_ssh_connection_failure(self, mock_conn, mock_load):
        """When SSH connection fails, show error."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "bruce@build4:/opt/bruce/poky": {
                "name": "poky", "host": "build4",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
        }
        mock_conn.return_value = False

        dialog_state = MagicMock()
        repo_info = {}

        with patch("bitbake_project.commands.explore.log_message") as mock_log:
            _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)
            assert mock_log.call_count == 2
            assert "Cannot connect" in mock_log.call_args_list[-1][0][0]

    @patch("bitbake_project.commands.projects.load_projects")
    def test_multiple_remotes_shows_picker(self, mock_load):
        """When multiple remotes exist, show inline picker dialog."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "bruce@build4:/opt/bruce/poky": {
                "name": "poky", "host": "build4",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
            "bruce@build5:/opt/bruce/poky": {
                "name": "poky", "host": "build5",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
        }
        dialog_state = MagicMock()
        repo_info = {}

        _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)

        # Should show a dialog to pick remote
        dialog_state.show_dialog.assert_called_once()

    @patch("bitbake_project.commands.projects.load_projects")
    @patch("bitbake_project.commands.ssh_remote.ssh_check_connection")
    @patch("bitbake_project.commands.ssh_remote.ssh_get_git_repos")
    @patch("bitbake_project.commands.ssh_remote.ssh_current_branch")
    @patch("bitbake_project.commands.explore.fzf_remote_commit_browser")
    @patch("bitbake_project.commands.common.import_remote_patches")
    def test_export_shows_method_picker(self, mock_import, mock_browser,
                                         mock_branch, mock_repos, mock_conn,
                                         mock_load):
        """When user exports commits, show method picker dialog."""
        from bitbake_project.commands.explore import _handle_pull_patches

        mock_load.return_value = {
            "bruce@build4:/opt/bruce/poky": {
                "name": "poky", "host": "build4",
                "user": "bruce", "remote_path": "/opt/bruce/poky",
            },
        }
        mock_conn.return_value = True
        mock_repos.return_value = ["/opt/bruce/poky/meta-virt"]
        mock_branch.return_value = "master"
        mock_browser.return_value = ("export", ["abc123", "def456"])

        dialog_state = MagicMock()
        repo_info = {}

        _handle_pull_patches("/home/user/meta-virt", dialog_state, repo_info)

        # Should show method picker dialog after export
        dialog_state.show_dialog.assert_called_once()
