#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Generic multi-repo persona for bit.

Discovers repos by scanning directories for .git/ — no bblayers.conf
or Yocto tooling required.  Useful for monitoring, browsing, and
updating any collection of git repos.
"""

import os
import subprocess
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from ...persona import Persona


@dataclass
class RepoSets:
    """Tracks different categories of repos (generic persona)."""
    discovered: Set[str]
    external: Set[str]
    hidden: Set[str]
    configured_layers: Set[str]


def _find_git_repos(
    base_dir: str,
    max_depth: int = 3,
    exclude_repos: Optional[Set[str]] = None,
) -> List[str]:
    """Find git repos by walking directories up to *max_depth* levels.

    Args:
        base_dir: Root directory to scan.
        max_depth: How many directory levels to descend (default 3).
        exclude_repos: Repo paths to skip.

    Returns:
        List of absolute git toplevel paths.
    """
    exclude_repos = exclude_repos or set()
    repos: List[str] = []
    seen: Set[str] = set()

    skip_dirs = {
        '.git', 'build', 'builds', 'tmp', 'node_modules',
        '__pycache__', '.tox', '.venv', 'venv',
        'downloads', 'sstate-cache', 'cache',
    }

    base = os.path.abspath(base_dir)
    if not os.path.isdir(base):
        return repos

    for root, dirs, _files in os.walk(base):
        rel = root[len(base):]
        depth = rel.count(os.sep) if rel else 0

        if depth >= max_depth:
            dirs[:] = []
            continue

        dirs[:] = [d for d in dirs if d not in skip_dirs]

        if os.path.isdir(os.path.join(root, ".git")):
            try:
                toplevel = subprocess.check_output(
                    ["git", "-C", root, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL,
                ).strip()
            except (subprocess.CalledProcessError, FileNotFoundError):
                toplevel = root

            toplevel = os.path.realpath(toplevel)
            if toplevel not in seen and toplevel not in exclude_repos:
                seen.add(toplevel)
                repos.append(toplevel)
            dirs[:] = []  # don't descend into git repos

    return repos


class GenericPersona(Persona):
    """Generic multi-repo persona — discovers repos by scanning for .git/."""

    name = "generic"
    description = "Generic multi-repo project (scan for .git/ directories)"

    # ---- Repo discovery ----

    def resolve_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = True,
        discover_all: bool = True,
    ) -> Tuple[List[Tuple[str, str]], RepoSets]:
        """Discover repos by scanning the current directory for .git/.

        *config_path* is ignored (no bblayers.conf needed).
        Each repo acts as its own "layer" (pair = (repo, repo)).
        """
        defaults = defaults or {}

        extra_repos = defaults.get("__extra_repos__", [])
        hidden_repos = set(defaults.get("__hidden_repos__", []))

        repos = _find_git_repos(".")
        known: Set[str] = set()
        pairs: List[Tuple[str, str]] = []

        for repo in repos:
            pairs.append((repo, repo))
            known.add(repo)

        # Add extra repos from config
        for repo_path in extra_repos:
            repo_path = os.path.realpath(repo_path)
            if os.path.isdir(repo_path) and repo_path not in known:
                pairs.append((repo_path, repo_path))
                known.add(repo_path)

        if not pairs:
            import sys
            sys.exit("No git repositories found in the current directory tree.")

        return pairs, RepoSets(
            discovered=set(),
            external=set(),
            hidden=hidden_repos,
            configured_layers=set(),
        )

    def collect_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = False,
        discover_all: bool = False,
    ) -> Tuple[List[str], RepoSets]:
        pairs, repo_sets = self.resolve_repos(
            config_path, defaults, include_external, discover_all,
        )
        seen: Set[str] = set()
        repos: List[str] = []
        for _, repo in pairs:
            if repo not in seen:
                seen.add(repo)
                repos.append(repo)
        return repos, repo_sets

    # ---- Command tree (no extra commands for generic) ----

    def get_commands(self) -> List[tuple]:
        return []

    def get_command_categories(self) -> Dict[str, tuple]:
        return {}

    # ---- Project detection ----

    def matches_project(self, path: str) -> float:
        has_git = False
        repo_count = 0
        has_yocto_markers = False
        try:
            for entry in os.scandir(path):
                if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                    if os.path.isdir(os.path.join(entry.path, ".git")):
                        repo_count += 1
                    if os.path.isfile(os.path.join(entry.path, "conf", "layer.conf")):
                        has_yocto_markers = True
                if entry.name == "poky" and entry.is_dir(follow_symlinks=False):
                    has_yocto_markers = True
        except OSError:
            pass
        # Check for bblayers.conf
        for subdir in ("conf", "build/conf"):
            if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
                has_yocto_markers = True
        # Single repo (the dir itself)
        if os.path.isdir(os.path.join(path, ".git")):
            has_git = True
        has_git = has_git or repo_count > 0

        if not has_git:
            return 0.0
        if has_yocto_markers:
            return 0.2  # Has git but also Yocto markers — low confidence
        # Git repos with NO Yocto markers — strong signal for generic
        return 0.6

    # ---- Dashboard integration ----

    def detect_project_info(self, path: str) -> dict:
        info: dict = {"type": "generic", "has_bblayers": False}
        # Count git repos in immediate subdirectories
        repo_count = 0
        try:
            for entry in os.scandir(path):
                if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                    if os.path.isdir(os.path.join(entry.path, ".git")):
                        repo_count += 1
        except OSError:
            pass
        info["repo_count"] = repo_count
        return info
