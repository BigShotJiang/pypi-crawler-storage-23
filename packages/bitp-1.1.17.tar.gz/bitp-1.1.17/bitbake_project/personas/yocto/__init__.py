#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Yocto/BitBake persona for bit.

Provides repo discovery via bblayers.conf, layer management, and
Yocto-specific commands (recipes, deps, fragments, setup, etc.).
"""

from typing import Dict, List, Optional, Tuple

from ...persona import Persona
from .layers import RepoSets, resolve_base_and_layers, collect_repos


class YoctoPersona(Persona):
    """Yocto/BitBake persona — discovers repos via bblayers.conf."""

    name = "yocto"
    description = "Yocto/BitBake project (layers from bblayers.conf)"

    # ---- Repo discovery ----

    def resolve_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = True,
        discover_all: bool = True,
    ) -> Tuple[List[Tuple[str, str]], RepoSets]:
        return resolve_base_and_layers(
            config_path, defaults, include_external, discover_all,
        )

    def collect_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = False,
        discover_all: bool = False,
    ) -> Tuple[List[str], RepoSets]:
        return collect_repos(
            config_path, defaults, include_external, discover_all,
        )

    # ---- Command tree (Yocto-specific commands) ----

    def get_commands(self) -> List[tuple]:
        return [
            ("deps", "Show layer and recipe dependencies", [
                ("deps layers", "Show layer dependency tree"),
                ("deps recipe", "Show recipe dependency tree"),
            ]),
            ("patches", "Explore and manage patches across layers", []),
            ("fragments", "Browse and manage OE configuration fragments", [
                ("fragments list", "List all available fragments"),
                ("fragments enable", "Enable a fragment"),
                ("fragments disable", "Disable a fragment"),
                ("fragments show", "Show fragment content"),
            ]),
            ("info", "Show build configuration and layer status", [
                ("info layers", "Show layer branch and commit info"),
                ("info vars", "Show key BitBake variables"),
            ]),
            ("setup", "Set up build environment, clone repos, manage configs", [
                ("setup shell", "Start a shell with build environment pre-sourced"),
                ("setup clone", "Clone repos and register project"),
                ("setup configs", "Browse and manage saved configurations"),
                ("setup apply", "Apply layers and fragments from saved config"),
                ("setup registry-copy", "Copy a .conf.json file to the user registry"),
                ("setup export", "Export build state as .conf.json"),
            ]),
            ("recipes", "Search and browse BitBake recipes", []),
            ("layer-index", "Search and browse OpenEmbedded Layer Index", []),
        ]

    def get_command_categories(self) -> Dict[str, tuple]:
        return {
            "config": ("Configuration", ["fragments", "info", "setup"]),
            "discovery": ("Discovery", ["recipes", "deps", "layer-index", "patches"]),
        }

    # ---- CLI integration ----

    def add_global_args(self, parser) -> None:
        parser.add_argument(
            "--bblayers",
            default=None,
            help="Path to bblayers.conf (auto-detects conf/bblayers.conf or build/conf/bblayers.conf if omitted)",
        )

    # ---- Command dispatch ----

    def get_command_dispatch(self) -> dict:
        """Return a mapping of command name to handler function."""
        from .commands import (
            run_init, run_init_shell, run_bootstrap,
            run_setup_clone, run_setup_apply, run_setup_registry_copy,
            run_setup_export, run_setup_configs,
            run_recipe, run_fragment, run_deps,
            run_patches, run_info, run_search,
        )
        return {
            "setup": run_init,
            "setup_shell": run_init_shell,
            "setup_clone": run_setup_clone,
            "setup_apply": run_setup_apply,
            "setup_registry_copy": run_setup_registry_copy,
            "setup_export": run_setup_export,
            "setup_configs": run_setup_configs,
            "bootstrap": run_bootstrap,
            "recipes": run_recipe,
            "fragments": run_fragment,
            "deps": run_deps,
            "patches": run_patches,
            "info": run_info,
            "layer-index": run_search,
        }

    # ---- Project detection ----

    def matches_project(self, path: str) -> float:
        import os
        # Strong signal: bblayers.conf exists
        for subdir in ("conf", "build/conf"):
            if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
                return 1.0
        # Medium signal: has layer.conf files (could be a layer collection)
        for subdir in ("", "layers"):
            check = os.path.join(path, subdir) if subdir else path
            if os.path.isdir(check):
                try:
                    for entry in os.scandir(check):
                        if entry.is_dir(follow_symlinks=False):
                            if os.path.isfile(os.path.join(entry.path, "conf", "layer.conf")):
                                return 0.7
                except OSError:
                    pass
        # Weak signal: poky/ directory
        if os.path.isdir(os.path.join(path, "poky")):
            return 0.5
        return 0.0

    # ---- Dashboard integration ----

    def detect_project_info(self, path: str) -> dict:
        import os
        info = {"type": "yocto", "has_bblayers": False}
        for subdir in ("conf", "build/conf"):
            if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
                info["has_bblayers"] = True
                break
        return info
