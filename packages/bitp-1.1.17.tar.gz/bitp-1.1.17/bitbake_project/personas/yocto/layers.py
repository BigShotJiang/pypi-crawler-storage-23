#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Layer discovery and management for Yocto persona.

Provides layer discovery (via conf/layer.conf), repo discovery,
layer metadata parsing, bblayers.conf manipulation, and the core
resolve_base_and_layers() function that underpins all commands.
"""

import os
import re
import shutil
import subprocess
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Set, Tuple

from ...core import git_toplevel
from .bblayers import resolve_bblayers_path, extract_layer_paths


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class RepoSets:
    """Tracks different categories of repos and layers."""
    discovered: Set[str]  # Discovered repos (magenta, "(?)")
    external: Set[str]    # Non-layer git repos (cyan, "(ext)")
    hidden: Set[str]      # Hidden repos (not shown unless toggled)
    configured_layers: Set[str]  # Layers from bblayers.conf (vs discovered)


@dataclass
class LayerInfo:
    """Layer metadata from layer.conf."""
    name: str              # Collection name from BBFILE_COLLECTIONS
    path: str              # Filesystem path to the layer
    depends: List[str]     # Required dependencies from LAYERDEPENDS
    recommends: List[str]  # Optional dependencies from LAYERRECOMMENDS
    priority: int          # Layer priority from BBFILE_PRIORITY


# ---------------------------------------------------------------------------
# Layer discovery
# ---------------------------------------------------------------------------

def discover_layers(
    base_dir: str = ".",
    max_depth: int = 3,
    exclude_layers: Optional[Set[str]] = None,
    peer_dirs: Optional[Set[str]] = None,
) -> List[Tuple[str, str]]:
    """
    Discover layers by finding conf/layer.conf files.

    Args:
        base_dir: Directory to start searching from
        max_depth: Maximum directory depth to search (default 3)
        exclude_layers: Set of layer paths to skip (e.g., already in bblayers.conf)
        peer_dirs: Additional directories to search (e.g., parent dirs of known repos)

    Returns:
        List of (layer_path, repo_path) tuples
    """
    exclude_layers = exclude_layers or set()
    peer_dirs = peer_dirs or set()
    results = []
    seen_layers: Set[str] = set()

    # Directories to skip (won't contain layers)
    skip_dirs = {
        '.git', 'build', 'builds', 'tmp', 'tmp-glibc', 'tmp-musl',
        'downloads', 'sstate-cache', 'cache', 'node_modules',
        '__pycache__', '.tox', '.venv', 'venv',
    }

    def search_from(start_dir: str) -> None:
        """Search for layers starting from a directory."""
        base = os.path.abspath(start_dir)
        if not os.path.isdir(base):
            return

        for root, dirs, _files in os.walk(base):
            # Calculate depth from base
            rel_path = root[len(base):]
            if rel_path:
                depth = rel_path.count(os.sep)
            else:
                depth = 0

            if depth >= max_depth:
                dirs[:] = []  # Don't descend further
            else:
                # Prune directories that won't contain layers
                dirs[:] = [d for d in dirs if d not in skip_dirs]

            # Check for layer.conf (standard BitBake layer structure)
            layer_conf = os.path.join(root, "conf", "layer.conf")
            if os.path.isfile(layer_conf):
                # Use realpath to resolve symlinks and match bblayers.conf paths
                layer_path = os.path.realpath(root)
                if layer_path in exclude_layers or layer_path in seen_layers:
                    continue
                repo_path = git_toplevel(layer_path)
                if repo_path:
                    results.append((layer_path, repo_path))
                    seen_layers.add(layer_path)

    # Search from base directory
    search_from(base_dir)

    # Also search from peer directories
    for peer_dir in peer_dirs:
        search_from(peer_dir)

    return results


def discover_git_repos(
    base_dir: str = ".",
    max_depth: int = 3,
    exclude_repos: Optional[Set[str]] = None,
    peer_dirs: Optional[Set[str]] = None,
) -> List[str]:
    """
    Discover git repositories that are NOT layers (no conf/layer.conf).

    Args:
        base_dir: Directory to start searching from
        max_depth: Maximum directory depth to search (default 3)
        exclude_repos: Set of repo paths to skip (e.g., already known repos)
        peer_dirs: Additional directories to check for repos (e.g., parents of known repos)

    Returns:
        List of repo paths (git toplevels)
    """
    exclude_repos = exclude_repos or set()
    peer_dirs = peer_dirs or set()
    results: Set[str] = set()

    # Directories to skip
    skip_dirs = {
        '.git', 'build', 'builds', 'tmp', 'tmp-glibc', 'tmp-musl',
        'downloads', 'sstate-cache', 'cache', 'node_modules',
        '__pycache__', '.tox', '.venv', 'venv',
    }

    def is_non_layer_repo(path: str) -> Optional[str]:
        """Check if path is a git repo without conf/layer.conf. Returns repo path or None."""
        git_dir = os.path.join(path, ".git")
        if os.path.exists(git_dir):
            repo_path = git_toplevel(path)
            if repo_path and repo_path not in exclude_repos:
                # Check it's NOT a layer
                layer_conf = os.path.join(repo_path, "conf", "layer.conf")
                if not os.path.isfile(layer_conf):
                    return repo_path
        return None

    # First, check peer directories (one level deep)
    for peer_dir in peer_dirs:
        if not os.path.isdir(peer_dir):
            continue
        # Check the peer dir itself
        repo = is_non_layer_repo(peer_dir)
        if repo:
            results.add(repo)
        # Check immediate children
        try:
            for entry in os.listdir(peer_dir):
                if entry in skip_dirs:
                    continue
                child = os.path.join(peer_dir, entry)
                if os.path.isdir(child):
                    repo = is_non_layer_repo(child)
                    if repo:
                        results.add(repo)
        except PermissionError:
            pass

    # Then do the normal walk from base_dir
    base = os.path.abspath(base_dir)
    for root, dirs, _files in os.walk(base):
        # Calculate depth from base
        rel_path = root[len(base):]
        if rel_path:
            depth = rel_path.count(os.sep)
        else:
            depth = 0

        if depth >= max_depth:
            dirs[:] = []  # Don't descend further
        else:
            # Prune directories that won't contain repos
            dirs[:] = [d for d in dirs if d not in skip_dirs]

        # Check if this is a git repo
        repo = is_non_layer_repo(root)
        if repo:
            results.add(repo)
            # Don't descend into git repos
            dirs[:] = []
        elif os.path.exists(os.path.join(root, ".git")):
            # It's a git repo but excluded or is a layer - still don't descend
            dirs[:] = []

    return list(results)


# ---------------------------------------------------------------------------
# Layer collection mapping
# ---------------------------------------------------------------------------

def build_layer_collection_map(layer_paths: List[str]) -> Dict[str, str]:
    """
    Build a map from layer collection names to layer paths.

    Parses BBFILE_COLLECTIONS from each layer's conf/layer.conf.

    Args:
        layer_paths: List of layer directory paths

    Returns:
        Dict mapping collection name to layer path
    """
    collection_map: Dict[str, str] = {}

    for layer_path in layer_paths:
        layer_conf = os.path.join(layer_path, "conf", "layer.conf")
        if not os.path.isfile(layer_conf):
            continue

        try:
            with open(layer_conf, 'r') as f:
                content = f.read()
            # Parse BBFILE_COLLECTIONS += "name" or BBFILE_COLLECTIONS = "name"
            for match in re.finditer(r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]+)"', content):
                collection_name = match.group(1).strip()
                if collection_name:
                    collection_map[collection_name] = layer_path
        except (IOError, OSError):
            pass

    return collection_map


# ---------------------------------------------------------------------------
# Layer manipulation (add/remove via bitbake-layers)
# ---------------------------------------------------------------------------

def add_layer_to_bblayers(
    layer_path: str,
    bblayers_conf: str,
    collection_map: Dict[str, str],
    init_script: Optional[str] = None,
) -> Tuple[bool, str, List[str]]:
    """
    Add a layer to bblayers.conf using bitbake-layers, resolving dependencies.

    Args:
        layer_path: Path to the layer to add
        bblayers_conf: Path to bblayers.conf
        collection_map: Map from collection names to layer paths
        init_script: Optional path to oe-init-build-env script

    Returns:
        Tuple of (success, message, layers_added)
    """
    # Ensure absolute path for bblayers.conf to correctly compute build_dir
    bblayers_conf = os.path.abspath(bblayers_conf)
    build_dir = os.path.dirname(os.path.dirname(bblayers_conf))  # conf/ -> build/

    if not build_dir or not os.path.isdir(build_dir):
        return False, f"Invalid build directory: {build_dir}", []

    layers_added: List[str] = []
    layers_to_add: List[str] = [os.path.abspath(layer_path)]
    max_iterations = 20  # Prevent infinite loops

    # Check if bitbake-layers is already available in PATH
    bitbake_layers_cmd = shutil.which("bitbake-layers")
    use_direct = bitbake_layers_cmd is not None

    # If not in PATH, find init script
    if not use_direct and not init_script:
        # Look for oe-init-build-env in parent directories
        search_dir = os.path.dirname(build_dir)
        for _ in range(3):
            candidate = os.path.join(search_dir, "oe-init-build-env")
            if os.path.isfile(candidate):
                init_script = candidate
                break
            # Also check in layers subdirectory
            for subdir in ["layers", "poky", "openembedded-core"]:
                candidate = os.path.join(search_dir, subdir, "oe-init-build-env")
                if os.path.isfile(candidate):
                    init_script = candidate
                    break
                # Check deeper
                candidate = os.path.join(search_dir, subdir, "openembedded-core", "oe-init-build-env")
                if os.path.isfile(candidate):
                    init_script = candidate
                    break
            if init_script:
                break
            search_dir = os.path.dirname(search_dir)

    if not use_direct and not init_script:
        return False, "Could not find oe-init-build-env script or bitbake-layers in PATH", []

    iteration = 0
    attempted: Set[str] = set()  # Track layers we've attempted to avoid infinite loops

    while layers_to_add and iteration < max_iterations:
        iteration += 1
        current_layer = layers_to_add.pop(0)

        if current_layer in layers_added:
            continue

        # Track how many times we've tried this layer
        attempt_key = current_layer
        if attempt_key in attempted:
            # We've already tried this layer once, something is wrong
            continue
        attempted.add(attempt_key)

        try:
            # Use direct bitbake-layers if available, otherwise source init script
            if use_direct:
                result = subprocess.run(
                    ["bitbake-layers", "add-layer", current_layer],
                    capture_output=True,
                    text=True,
                    cwd=build_dir,
                )
            else:
                cmd = f'source "{init_script}" "{build_dir}" > /dev/null 2>&1 && bitbake-layers add-layer "{current_layer}" 2>&1'
                result = subprocess.run(
                    cmd,
                    shell=True,
                    executable='/bin/bash',
                    capture_output=True,
                    text=True,
                    cwd=build_dir,
                )

            output = result.stdout + result.stderr

            if result.returncode == 0:
                layers_added.append(current_layer)
            elif "already in" in output.lower() or "already enabled" in output.lower():
                # Layer is already in bblayers.conf - treat as success
                layers_added.append(current_layer)
            else:
                # Parse dependency errors
                # Format: ERROR: Layer 'X' depends on layer 'Y', but this layer is not enabled
                dep_pattern = r"ERROR: Layer '[^']+' depends on layer '([^']+)', but this layer is not enabled"
                missing_deps = re.findall(dep_pattern, output)

                if missing_deps:
                    # Check if the "missing" dependency is actually the layer we're adding
                    # This happens when bitbake-layers complains about pre-existing issues
                    # e.g., "networking-layer depends on meta-python" when adding meta-python
                    current_layer_name = None
                    layer_conf = os.path.join(current_layer, "conf", "layer.conf")
                    if os.path.isfile(layer_conf):
                        try:
                            with open(layer_conf, 'r') as f:
                                content = f.read()
                            match = re.search(r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]+)"', content)
                            if match:
                                current_layer_name = match.group(1).strip()
                        except (IOError, OSError):
                            pass

                    # Filter out deps that are the current layer itself
                    real_missing_deps = [d for d in missing_deps if d != current_layer_name]

                    if not real_missing_deps:
                        # The only "missing" dep is the layer we're adding - this is a pre-existing
                        # dependency issue in bblayers.conf. bitbake-layers can't add the layer
                        # because it validates all existing layers first.
                        # Suggest manual fix.
                        layer_name = os.path.basename(current_layer)
                        return False, f"Pre-existing dependency issue prevents add. Add {layer_name} manually or fix bblayers.conf", layers_added

                    # Remove from attempted so we can retry after adding deps
                    attempted.discard(current_layer)
                    # Add current layer back to try after dependencies
                    layers_to_add.append(current_layer)

                    # Find and add missing dependencies
                    added_any_dep = False
                    for dep_name in real_missing_deps:
                        if dep_name in collection_map:
                            dep_path = collection_map[dep_name]
                            if dep_path not in layers_added and dep_path not in layers_to_add:
                                # Insert at beginning so deps are added first
                                layers_to_add.insert(0, dep_path)
                                added_any_dep = True
                        else:
                            return False, f"Missing dependency '{dep_name}' not found in available layers", layers_added

                    # If we didn't add any new deps, we're stuck
                    if not added_any_dep:
                        deps_status = [f"{d}" for d in real_missing_deps]
                        return False, f"Dependencies already queued but still failing: {', '.join(deps_status)}", layers_added
                else:
                    # Unknown error
                    error_msg = result.stderr.strip() or result.stdout.strip()
                    if not error_msg:
                        error_msg = "bitbake-layers not available (is bitbake installed/cloned?)"
                    return False, f"Failed to add layer: {error_msg}", layers_added

        except Exception as e:
            return False, f"Error running bitbake-layers: {e}", layers_added

    if iteration >= max_iterations:
        return False, "Too many dependency iterations - possible circular dependency", layers_added

    # Build summary of what was added
    if layers_added:
        added_names = [os.path.basename(l) for l in layers_added]
        return True, f"Added: {', '.join(added_names)}", layers_added
    return True, "No layers added", layers_added


def remove_layer_from_bblayers(
    layer_path: str,
    bblayers_conf: str,
) -> Tuple[bool, str]:
    """
    Remove a layer from bblayers.conf using bitbake-layers.

    Args:
        layer_path: Path to the layer to remove
        bblayers_conf: Path to bblayers.conf

    Returns:
        Tuple of (success, message)
    """
    # Ensure absolute path for bblayers.conf to correctly compute build_dir
    bblayers_conf = os.path.abspath(bblayers_conf)
    build_dir = os.path.dirname(os.path.dirname(bblayers_conf))

    if not build_dir or not os.path.isdir(build_dir):
        return False, f"Invalid build directory: {build_dir}"

    layer_path = os.path.abspath(layer_path)
    layer_name = os.path.basename(layer_path)

    # Check if bitbake-layers is already available in PATH
    bitbake_layers_cmd = shutil.which("bitbake-layers")

    try:
        if bitbake_layers_cmd:
            result = subprocess.run(
                ["bitbake-layers", "remove-layer", layer_path],
                capture_output=True,
                text=True,
                cwd=build_dir,
            )
        else:
            # Try to find and source oe-init-build-env
            init_script = None
            search_dir = os.path.dirname(build_dir)
            for _ in range(3):
                for candidate_path in [
                    os.path.join(search_dir, "oe-init-build-env"),
                    os.path.join(search_dir, "layers", "oe-init-build-env"),
                    os.path.join(search_dir, "poky", "oe-init-build-env"),
                ]:
                    if os.path.isfile(candidate_path):
                        init_script = candidate_path
                        break
                if init_script:
                    break
                search_dir = os.path.dirname(search_dir)

            if not init_script:
                return False, "Could not find oe-init-build-env script or bitbake-layers in PATH"

            cmd = f'source "{init_script}" "{build_dir}" > /dev/null 2>&1 && bitbake-layers remove-layer "{layer_path}" 2>&1'
            result = subprocess.run(
                cmd,
                shell=True,
                executable='/bin/bash',
                capture_output=True,
                text=True,
                cwd=build_dir,
            )

        if result.returncode == 0:
            return True, f"Removed: {layer_name}"
        else:
            error_msg = result.stderr.strip() or result.stdout.strip()
            return False, f"Failed to remove layer: {error_msg}"

    except Exception as e:
        return False, f"Error running bitbake-layers: {e}"


# ---------------------------------------------------------------------------
# Layer metadata parsing
# ---------------------------------------------------------------------------

def parse_layer_conf(layer_path: str) -> Optional[LayerInfo]:
    """
    Parse a layer's conf/layer.conf to extract dependency information.

    Returns LayerInfo with collection name, dependencies, and priority,
    or None if the layer.conf doesn't exist or can't be parsed.
    """
    conf_path = os.path.join(layer_path, "conf", "layer.conf")
    if not os.path.isfile(conf_path):
        return None

    try:
        with open(conf_path, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return None

    # Handle line continuations
    content = content.replace("\\\n", " ")

    # Extract BBFILE_COLLECTIONS (the layer's collection name)
    # Format: BBFILE_COLLECTIONS += "layer-name"
    collection_match = re.search(
        r'BBFILE_COLLECTIONS\s*\+?=\s*"([^"]*)"', content
    )
    collection_name = ""
    if collection_match:
        collection_name = collection_match.group(1).strip()

    if not collection_name:
        # Try to derive from layer path as fallback
        collection_name = os.path.basename(layer_path)
        if collection_name.startswith("meta-"):
            collection_name = collection_name[5:]

    # Extract LAYERDEPENDS_<collection> (required dependencies)
    # Format: LAYERDEPENDS_<collection> = "dep1 dep2:version dep3 (>= 4)"
    # Version constraints can be "layer:version" or "(>= version)" after a layer name
    depends = []
    depends_pattern = re.compile(
        r'LAYERDEPENDS_' + re.escape(collection_name) + r'\s*\+?=\s*"([^"]*)"'
    )
    for match in depends_pattern.finditer(content):
        deps_str = match.group(1).strip()
        # Remove parenthetical version constraints like "(>= 12)" or "(< 5)"
        deps_str = re.sub(r'\([^)]*\)', '', deps_str)
        for dep in deps_str.split():
            # Strip version constraints (e.g., "core:4" -> "core")
            dep_name = dep.split(":")[0].strip()
            # Skip empty strings and things that look like version numbers
            if dep_name and dep_name not in depends and not dep_name.isdigit():
                depends.append(dep_name)

    # Extract LAYERRECOMMENDS_<collection> (optional dependencies)
    recommends = []
    recommends_pattern = re.compile(
        r'LAYERRECOMMENDS_' + re.escape(collection_name) + r'\s*\+?=\s*"([^"]*)"'
    )
    for match in recommends_pattern.finditer(content):
        rec_str = match.group(1).strip()
        # Remove parenthetical version constraints
        rec_str = re.sub(r'\([^)]*\)', '', rec_str)
        for rec in rec_str.split():
            rec_name = rec.split(":")[0].strip()
            if rec_name and rec_name not in recommends and not rec_name.isdigit():
                recommends.append(rec_name)

    # Extract BBFILE_PRIORITY_<collection>
    # Format: BBFILE_PRIORITY_<collection> = "6"
    priority = 0
    priority_pattern = re.compile(
        r'BBFILE_PRIORITY_' + re.escape(collection_name) + r'\s*=\s*"?(\d+)"?'
    )
    priority_match = priority_pattern.search(content)
    if priority_match:
        try:
            priority = int(priority_match.group(1))
        except ValueError:
            pass

    return LayerInfo(
        name=collection_name,
        path=layer_path,
        depends=depends,
        recommends=recommends,
        priority=priority,
    )


# ---------------------------------------------------------------------------
# Layer display helpers
# ---------------------------------------------------------------------------

def layer_display_name(layer: str) -> str:
    """Get display name for a layer (just the directory name)."""
    return os.path.basename(layer.rstrip("/"))


def commit_to_layer(repo: str, commit: str, layers: List[str]) -> Optional[str]:
    """
    Determine which layer a commit belongs to.
    Returns the layer path if commit touches exactly one layer,
    None if commit touches no layers or multiple layers.
    """
    from ...commands.common import commit_files

    files = commit_files(repo, commit)
    if not files:
        return None

    # Get relative paths of layers within the repo
    layer_relpaths = []
    for layer in layers:
        try:
            relpath = os.path.relpath(layer, repo)
            layer_relpaths.append((layer, relpath))
        except ValueError:
            continue

    # Find which layers this commit touches
    touched_layers = set()
    for filepath in files:
        for layer, relpath in layer_relpaths:
            if filepath.startswith(relpath + "/") or filepath == relpath:
                touched_layers.add(layer)
                break

    if len(touched_layers) == 1:
        return touched_layers.pop()
    return None


def group_commits_by_layer(repo: str, commits: List[str], layers: List[str]) -> Tuple[Dict[str, List[str]], List[str], List[str]]:
    """
    Group commits by which layer they touch.
    Returns (layer_commits dict, list of commits touching multiple layers, list of commits touching no layers).
    """
    from ...commands.common import commit_files

    layer_commits: Dict[str, List[str]] = {}
    cross_layer_commits: List[str] = []
    no_layer_commits: List[str] = []

    for commit in commits:
        layer = commit_to_layer(repo, commit, layers)
        if layer is None:
            # Check if it touches multiple layers or no layers
            files = commit_files(repo, commit)
            layer_relpaths = []
            for l in layers:
                try:
                    relpath = os.path.relpath(l, repo)
                    layer_relpaths.append((l, relpath))
                except ValueError:
                    continue

            touched = set()
            for filepath in files:
                for l, relpath in layer_relpaths:
                    if filepath.startswith(relpath + "/") or filepath == relpath:
                        touched.add(l)
                        break

            if len(touched) > 1:
                cross_layer_commits.append(commit)
            elif len(touched) == 1:
                layer = touched.pop()
                layer_commits.setdefault(layer, []).append(commit)
            else:
                no_layer_commits.append(commit)
        else:
            layer_commits.setdefault(layer, []).append(commit)

    return layer_commits, cross_layer_commits, no_layer_commits


def get_upstream_layer_counts(repo: str, branch: str, layers: List[str]) -> Dict[str, int]:
    """Get per-layer count of upstream commits efficiently.

    Uses git rev-list --count with path filtering — one call per layer.
    Only meaningful after a fetch (requires commit objects locally).
    """
    from ...commands.branch import get_upstream_ref

    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return {}

    counts: Dict[str, int] = {}
    for layer in layers:
        try:
            relpath = os.path.relpath(layer, repo)
        except ValueError:
            continue
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--count", f"HEAD..{remote_ref}", "--", f"{relpath}/"],
                text=True, stderr=subprocess.DEVNULL,
            )
            count = int(out.strip())
            if count > 0:
                counts[layer] = count
        except (subprocess.CalledProcessError, ValueError):
            continue
    return counts


# ---------------------------------------------------------------------------
# Core repo resolution
# ---------------------------------------------------------------------------

def resolve_base_and_layers(
    path_opt: Optional[str],
    defaults: Optional[dict] = None,
    include_external: bool = True,
    discover_all: bool = True,
) -> Tuple[List[Tuple[str, str]], RepoSets]:
    """
    Resolve layers from bblayers.conf and discover additional layers/repos.

    Args:
        path_opt: Path to bblayers.conf (or None for auto-detect)
        defaults: Defaults dict (for extra_repos and hidden_repos)
        include_external: Whether to discover non-layer git repos
        discover_all: Whether to discover layers not in bblayers.conf

    Returns:
        Tuple of (pairs, repo_sets) where:
        - pairs: List of (layer_path, repo_path) tuples
        - repo_sets: RepoSets with discovered, external, and hidden repo sets
    """
    from ...commands.common import get_extra_repos, get_hidden_repos

    defaults = defaults or {}
    pairs: List[Tuple[str, str]] = []
    bblayers_layer_paths: Set[str] = set()
    known_repos: Set[str] = set()
    discovered_repos: Set[str] = set()
    external_repos: Set[str] = set()

    extra_repos_list = get_extra_repos(defaults)
    hidden_repos_set = set(get_hidden_repos(defaults))

    # Try to get layers from bblayers.conf
    bblayers = resolve_bblayers_path(path_opt)
    if bblayers:
        layers = extract_layer_paths(bblayers)
        for layer in layers:
            # Normalize path with realpath to resolve symlinks and avoid duplicates
            layer = os.path.realpath(layer)
            repo = git_toplevel(layer)
            if not repo:
                print(f"Warning: {layer} is not inside a git repo; skipping.")
                continue
            pairs.append((layer, repo))
            bblayers_layer_paths.add(layer)
            known_repos.add(repo)

    # Add extra repos from config (these are tracked, not external)
    for repo_path in extra_repos_list:
        repo_path = os.path.realpath(repo_path)
        if os.path.isdir(repo_path) and repo_path not in known_repos:
            repo = git_toplevel(repo_path)
            if repo:
                # Add as a pseudo-layer (repo path is both layer and repo)
                pairs.append((repo, repo))
                known_repos.add(repo)

    # Collect parent directories of known repos to check for peer repos/layers
    # e.g., if layers are in /path/project/layers/, also check /path/project/
    # But avoid searching from overly broad directories like home or root
    home_dir = os.path.expanduser("~")
    too_broad = {"/", "/home", "/opt", "/usr", home_dir}
    peer_dirs: Set[str] = set()
    for repo in known_repos:
        parent = os.path.dirname(repo)
        if parent and parent not in too_broad:
            peer_dirs.add(parent)

    # Auto-detect bitbake repo as a peer of known layer repos.
    # bitbake is not a layer (no conf/layer.conf) but is essential to Yocto.
    for peer in list(peer_dirs):
        bitbake_candidate = os.path.join(peer, "bitbake")
        if os.path.isdir(bitbake_candidate) and bitbake_candidate not in known_repos:
            bb_repo = git_toplevel(bitbake_candidate)
            if bb_repo and bb_repo not in known_repos:
                pairs.append((bb_repo, bb_repo))
                known_repos.add(bb_repo)
                break

    # Discover additional layers not in bblayers.conf (only if discover_all is True)
    if discover_all:
        discovered = discover_layers(exclude_layers=bblayers_layer_paths, peer_dirs=peer_dirs)
        for layer, repo in discovered:
            # Add all discovered layers to pairs
            pairs.append((layer, repo))
            # But only mark repo as discovered once
            if repo not in known_repos:
                discovered_repos.add(repo)
                known_repos.add(repo)

    # Discover external git repos (non-layers) - only if discovery is enabled
    if include_external:
        external = discover_git_repos(exclude_repos=known_repos, peer_dirs=peer_dirs)
        for repo in external:
            external_repos.add(repo)

    if not pairs and not external_repos:
        if bblayers:
            sys.exit("No git repositories found for the configured layers.")
        else:
            sys.exit("No layers found. Provide --bblayers, or use -a to discover layers in the current directory.")

    repo_sets = RepoSets(
        discovered=discovered_repos,
        external=external_repos,
        hidden=hidden_repos_set,
        configured_layers=bblayers_layer_paths,
    )
    return pairs, repo_sets


def collect_repos(
    path_opt: Optional[str],
    defaults: Optional[dict] = None,
    include_external: bool = False,
    discover_all: bool = False,
) -> Tuple[List[str], RepoSets]:
    """
    Collect unique repos from bblayers.conf and discovered layers.

    Args:
        path_opt: Path to bblayers.conf (or None for auto-detect)
        defaults: Defaults dict (for extra_repos and hidden_repos)
        include_external: Whether to discover non-layer git repos
        discover_all: Whether to discover layers not in bblayers.conf

    Returns:
        Tuple of (repos, repo_sets) where:
        - repos: Deduplicated list of repo paths
        - repo_sets: RepoSets with discovered, external, and hidden repo sets
    """
    from ...commands.common import dedupe_preserve_order

    pairs, repo_sets = resolve_base_and_layers(path_opt, defaults, include_external, discover_all=discover_all)
    repos = dedupe_preserve_order(repo for _, repo in pairs)
    return repos, repo_sets
