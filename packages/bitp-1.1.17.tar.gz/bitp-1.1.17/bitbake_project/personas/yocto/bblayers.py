#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
BBLayers parsing for Yocto persona.

Handles bblayers.conf discovery, parsing (with full BitBake syntax support),
and layer path extraction.
"""

import os
import re
import sys
from typing import Dict, List, Optional, Set, Tuple


def resolve_bblayers_path(path_opt: Optional[str]) -> Optional[str]:
    """Find bblayers.conf path, or return None if not found and not specified."""
    if path_opt:
        return path_opt
    candidates = ["conf/bblayers.conf", "build/conf/bblayers.conf"]
    for cand in candidates:
        if os.path.exists(cand):
            return cand
    return None


class BblayersParser:
    """
    Parse bblayers.conf with proper BitBake syntax support.

    Handles:
    - Line continuations (backslash)
    - Assignment operators: =, ?=, ??=, :=, ::=
    - Append/prepend: +=, .=, =+, =., :append, :prepend
    - Remove: :remove
    - Variable expansion: ${VAR}
    - Include/require statements
    - Comments (# lines)
    """

    def __init__(self, conf_path: str):
        self.conf_path = os.path.abspath(conf_path)
        self.conf_dir = os.path.dirname(self.conf_path)
        # Build dir is typically parent of conf/
        self.build_dir = os.path.dirname(self.conf_dir)

        # Variable storage
        self.variables: Dict[str, str] = {}
        self.bblayers: List[str] = []
        self.bblayers_remove: Set[str] = set()

        # Initialize common variables
        self._init_common_variables()

    def _init_common_variables(self) -> None:
        """Initialize commonly used variables that we can infer."""
        # TOPDIR is the build directory (where conf/ lives)
        self.variables['TOPDIR'] = self.build_dir

        # Try to find OEROOT/COREBASE by looking for oe-init-build-env
        # Usually it's a sibling or parent directory
        for search_dir in [
            os.path.dirname(self.build_dir),  # Parent of build
            self.build_dir,
        ]:
            if os.path.isfile(os.path.join(search_dir, 'oe-init-build-env')):
                self.variables['OEROOT'] = search_dir
                self.variables['COREBASE'] = search_dir
                break

        # BSPDIR is often the project root (parent of build dir)
        self.variables['BSPDIR'] = os.path.dirname(self.build_dir)

        # Environment variables can also be referenced
        for env_var in ['HOME', 'PWD', 'USER']:
            if env_var in os.environ:
                self.variables[env_var] = os.environ[env_var]

    def _expand_variables(self, value: str) -> str:
        """Expand ${VAR} references in a string."""
        if '${' not in value:
            return value

        # Iteratively expand variables (handles nested refs)
        max_iterations = 10
        for _ in range(max_iterations):
            original = value
            for var_name, var_value in self.variables.items():
                value = value.replace(f'${{{var_name}}}', var_value)
            if value == original:
                break

        return value

    def _join_continued_lines(self, content: str) -> List[str]:
        """Join lines that end with backslash continuation."""
        lines = content.splitlines()
        result = []
        current_line = ""

        for line in lines:
            # Strip trailing whitespace but preserve leading
            line_stripped = line.rstrip()

            if line_stripped.endswith('\\'):
                # Continuation - append without the backslash
                current_line += line_stripped[:-1]
            else:
                current_line += line_stripped
                result.append(current_line)
                current_line = ""

        # Don't forget last line if file doesn't end with newline
        if current_line:
            result.append(current_line)

        return result

    def _extract_quoted_value(self, value_part: str) -> str:
        """Extract value from quoted string (handles both " and ')."""
        value_part = value_part.strip()

        # Try double quotes first
        match = re.match(r'^"(.*)"', value_part, re.DOTALL)
        if match:
            return match.group(1)

        # Try single quotes
        match = re.match(r"^'(.*)'", value_part, re.DOTALL)
        if match:
            return match.group(1)

        # Unquoted value (take until comment or end)
        match = re.match(r'^([^#\s]+)', value_part)
        if match:
            return match.group(1)

        return value_part

    def _parse_assignment(self, line: str) -> Optional[Tuple[str, str, str]]:
        """
        Parse a variable assignment line.

        Returns: (var_name, operator, value) or None if not an assignment.
        Operator includes any suffix like :append, :remove, etc.
        """
        # Skip comments and empty lines
        stripped = line.strip()
        if not stripped or stripped.startswith('#'):
            return None

        # Match variable assignment patterns
        # Handles: VAR =, VAR ?=, VAR ??=, VAR +=, VAR .=, VAR :=, VAR ::=
        # Also: VAR:append =, VAR:prepend =, VAR:remove =
        pattern = r'^([A-Za-z_][A-Za-z0-9_]*)((?::[a-z]+)?)\s*(\?\?=|\?=|:=|::=|\+=|\.=|=\+|=\.|=)\s*(.*)$'
        match = re.match(pattern, stripped)

        if not match:
            return None

        var_name = match.group(1)
        var_suffix = match.group(2)  # :append, :remove, etc.
        operator = match.group(3)
        value_part = match.group(4)

        # Extract the actual value (may be quoted)
        value = self._extract_quoted_value(value_part)

        # Combine suffix into operator for easier handling
        full_operator = var_suffix + operator if var_suffix else operator

        return (var_name, full_operator, value)

    def _apply_assignment(self, var_name: str, operator: str, value: str) -> None:
        """Apply a variable assignment based on the operator."""
        # Expand variables in the value
        expanded_value = self._expand_variables(value)

        if var_name == 'BBLAYERS':
            self._apply_bblayers_assignment(operator, expanded_value)
        else:
            # Track other variables for potential expansion
            self._apply_variable_assignment(var_name, operator, expanded_value)

    def _apply_variable_assignment(self, var_name: str, operator: str, value: str) -> None:
        """Apply assignment to a regular variable."""
        if operator in ('=', ':=', '::='):
            # Direct assignment
            self.variables[var_name] = value
        elif operator == '?=':
            # Default assignment (only if not set)
            if var_name not in self.variables:
                self.variables[var_name] = value
        elif operator == '??=':
            # Weak default (we treat same as ?= for simplicity)
            if var_name not in self.variables:
                self.variables[var_name] = value
        elif operator in ('+=', ':append='):
            # Append with space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = current + ' ' + value if current else value
        elif operator in ('.=', ):
            # Append without space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = current + value
        elif operator in ('=+', ':prepend='):
            # Prepend with space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = value + ' ' + current if current else value
        elif operator == '=.':
            # Prepend without space
            current = self.variables.get(var_name, '')
            self.variables[var_name] = value + current

    def _apply_bblayers_assignment(self, operator: str, value: str) -> None:
        """Apply assignment specifically to BBLAYERS."""
        # Extract paths from the value
        paths = self._extract_paths_from_value(value)

        if operator == ':remove=':
            # Add to remove set
            for path in paths:
                self.bblayers_remove.add(path)
        elif operator in ('=', ':=', '::='):
            # Direct assignment - replace
            self.bblayers = paths
        elif operator == '?=':
            # Default - only if empty
            if not self.bblayers:
                self.bblayers = paths
        elif operator == '??=':
            # Weak default
            if not self.bblayers:
                self.bblayers = paths
        elif operator in ('+=', ':append='):
            # Append
            self.bblayers.extend(paths)
        elif operator in ('.=',):
            # Append (same effect for lists)
            self.bblayers.extend(paths)
        elif operator in ('=+', ':prepend='):
            # Prepend
            self.bblayers = paths + self.bblayers
        elif operator == '=.':
            # Prepend
            self.bblayers = paths + self.bblayers

    def _extract_paths_from_value(self, value: str) -> List[str]:
        """Extract layer paths from a BBLAYERS value string."""
        paths = []
        for token in value.split():
            # Skip empty tokens
            if not token:
                continue
            # Skip obvious non-paths
            if '/' not in token and not token.startswith('$'):
                continue
            # Expand any remaining variables
            expanded = self._expand_variables(token)
            # Skip if still has unexpanded variables
            if '${' in expanded:
                # Try to warn but still include partial path
                # This helps with debugging
                pass
            if expanded and '/' in expanded:
                # Normalize the path
                if os.path.isabs(expanded):
                    paths.append(os.path.normpath(expanded))
                else:
                    # Relative to build dir
                    paths.append(os.path.normpath(os.path.join(self.build_dir, expanded)))
        return paths

    def _process_include(self, line: str) -> None:
        """Process include or require statement."""
        stripped = line.strip()

        match = re.match(r'^(include|require)\s+(.+)$', stripped)
        if not match:
            return

        directive = match.group(1)
        include_path = match.group(2).strip()

        # Expand variables in include path
        include_path = self._expand_variables(include_path)

        # Still has unexpanded variables - skip
        if '${' in include_path:
            return

        # Resolve relative paths
        if not os.path.isabs(include_path):
            include_path = os.path.join(self.conf_dir, include_path)

        # For 'include', file is optional; for 'require', it must exist
        if os.path.isfile(include_path):
            self._parse_file(include_path)
        elif directive == 'require':
            # Required file missing - in real bitbake this is an error
            # We just skip it silently
            pass

    def _parse_file(self, file_path: str) -> None:
        """Parse a single conf file."""
        if not os.path.isfile(file_path):
            return

        try:
            with open(file_path, encoding='utf-8') as f:
                content = f.read()
        except (IOError, OSError):
            return

        # Join continued lines
        lines = self._join_continued_lines(content)

        for line in lines:
            stripped = line.strip()

            # Skip empty and comment lines
            if not stripped or stripped.startswith('#'):
                continue

            # Check for include/require
            if stripped.startswith('include ') or stripped.startswith('require '):
                self._process_include(line)
                continue

            # Try to parse as assignment
            assignment = self._parse_assignment(line)
            if assignment:
                var_name, operator, value = assignment
                self._apply_assignment(var_name, operator, value)

    def parse(self) -> List[str]:
        """Parse bblayers.conf and return list of layer paths."""
        if not os.path.exists(self.conf_path):
            return []

        self._parse_file(self.conf_path)

        # Apply removes
        final_layers = []
        seen = set()
        for layer in self.bblayers:
            # Normalize for comparison
            normalized = os.path.realpath(layer) if os.path.exists(layer) else layer
            if normalized in self.bblayers_remove:
                continue
            if normalized in seen:
                continue
            seen.add(normalized)
            final_layers.append(layer)

        return final_layers


def extract_layer_paths(conf_path: str) -> List[str]:
    """
    Extract layer paths from bblayers.conf.

    Uses BblayersParser for robust parsing with support for:
    - Variable expansion (${TOPDIR}, etc.)
    - Append/prepend operators (+=, :append, etc.)
    - Remove operator (:remove)
    - Include/require statements
    """
    if not os.path.exists(conf_path):
        sys.exit(f"bblayers.conf not found: {conf_path}")

    parser = BblayersParser(conf_path)
    return parser.parse()
