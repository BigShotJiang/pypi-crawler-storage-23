#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Persona system for bit.

Personas allow bit to work with different project types (Yocto, generic
multi-repo, etc.) by abstracting repo discovery and command registration.
"""
