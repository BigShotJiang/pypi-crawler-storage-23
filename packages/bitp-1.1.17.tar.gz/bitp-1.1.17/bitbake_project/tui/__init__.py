#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
TUI abstraction layer for bitbake-project.

Provides a backend-agnostic interface for interactive menus, prompts, and
selection dialogs. Supports multiple backends:
- fzf: Minimal dependency, fast, familiar
- textual: Rich TUI with modals, dialogs, better interactivity

Usage:
    from bitbake_project.tui import get_backend, MenuConfig, MenuItem

    backend = get_backend()  # Auto-selects based on availability/config

    result = backend.select_one(
        items=[MenuItem("opt1", "Option 1"), MenuItem("opt2", "Option 2")],
        config=MenuConfig(header="Select an option", preview_cmd="echo {}")
    )
"""

from .base import (
    MenuItem,
    MenuConfig,
    MenuResult,
    MenuBackend,
    PromptResult,
)
from .factory import get_backend, set_preferred_backend, available_backends
from .dialogs import (
    Dialog,
    DialogType,
    DialogOption,
    DialogResult,
    DialogRenderer,
    DialogBuilder,
    FzfDialogRenderer,
    dialog,
)
from .explore_dialogs import (
    ExploreMenuState,
    branch_all_dialog,
    create_branch_dialog,
    confirm_update_dialog,
    select_branch_dialog,
    add_repo_dialog,
    confirm_delete_dialog,
    confirm_action_dialog,
    text_input_dialog,
    custom_command_dialog,
    rename_dialog,
    select_action_dialog,
    update_repo_dialog,
    build_menu_with_dialog,
    get_dialog_header_override,
    get_dialog_expect_keys,
)
from .inline_options import (
    ToggleOption,
    OptionAction,
    OptionsSection,
    InlineOptionsMenu,
    OptionsResult,
    InlineOptionsState,
    build_recipe_options_menu,
    build_patches_search_menu,
    build_patches_filter_menu,
    build_lore_search_menu,
    InlineSelectorItem,
    InlineSelector,
)

__all__ = [
    # Menu abstraction
    "MenuItem",
    "MenuConfig",
    "MenuResult",
    "MenuBackend",
    "PromptResult",
    "get_backend",
    "set_preferred_backend",
    "available_backends",
    # Dialog abstraction
    "Dialog",
    "DialogType",
    "DialogOption",
    "DialogResult",
    "DialogRenderer",
    "DialogBuilder",
    "FzfDialogRenderer",
    "dialog",
    # Explore integration
    "ExploreMenuState",
    "branch_all_dialog",
    "create_branch_dialog",
    "confirm_update_dialog",
    "select_branch_dialog",
    "add_repo_dialog",
    "confirm_delete_dialog",
    "confirm_action_dialog",
    "text_input_dialog",
    "custom_command_dialog",
    "rename_dialog",
    "select_action_dialog",
    "update_repo_dialog",
    "build_menu_with_dialog",
    "get_dialog_header_override",
    "get_dialog_expect_keys",
    # Inline options menu
    "ToggleOption",
    "OptionAction",
    "OptionsSection",
    "InlineOptionsMenu",
    "OptionsResult",
    "InlineOptionsState",
    "build_recipe_options_menu",
    "build_patches_search_menu",
    "build_patches_filter_menu",
    "build_lore_search_menu",
    # Inline selector
    "InlineSelectorItem",
    "InlineSelector",
]
