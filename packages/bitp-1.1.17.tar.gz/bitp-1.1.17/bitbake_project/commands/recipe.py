#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Recipe command - search and browse BitBake recipes."""

import glob
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.request
import urllib.error
import urllib.parse
from typing import Dict, List, Optional, Tuple

from ..core import Colors, fzf_available, get_fzf_color_args, get_fzf_preview_resize_bindings, load_defaults
from ..fzf_bindings import (
    get_action_binding,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_preview_toggle_binding,
    get_position_binding,
)
from ..tui import (
    InlineOptionsState,
    build_recipe_options_menu,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    dedupe_preserve_order,
    layer_display_name,
    extract_layer_paths,
    get_project_header_prefix,
)
from .projects import get_preview_window_arg, get_recipe_use_bitbake_layers


# =============================================================================
# Column widths for display
# =============================================================================

COL_PN = 30      # Recipe name
COL_PV = 15      # Version
COL_LAYER = 20   # Layer name
COL_SECTION = 15 # Section


# =============================================================================
# Cache Management
# =============================================================================

def _get_recipe_cache_dir() -> str:
    """Get path to recipe cache directory."""
    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    return cache_dir


def _get_cache_hash(layer_paths: List[str]) -> str:
    """Generate cache hash from sorted layer paths."""
    sorted_paths = sorted(layer_paths)
    content = "\n".join(sorted_paths)
    return hashlib.md5(content.encode()).hexdigest()[:12]


def _load_recipe_cache(layer_paths: List[str]) -> Optional[List[dict]]:
    """Load recipe cache if valid (< 5 minutes old)."""
    cache_dir = _get_recipe_cache_dir()
    cache_hash = _get_cache_hash(layer_paths)
    cache_path = os.path.join(cache_dir, f"recipe-index-{cache_hash}.json")

    if not os.path.isfile(cache_path):
        return None

    try:
        cache_age = time.time() - os.path.getmtime(cache_path)
        if cache_age > 300:  # 5 minutes TTL
            return None

        with open(cache_path, "r") as f:
            data = json.load(f)
            return data.get("recipes")
    except (json.JSONDecodeError, OSError, KeyError):
        return None


def _save_recipe_cache(layer_paths: List[str], recipes: List[dict]) -> None:
    """Save recipe cache."""
    cache_dir = _get_recipe_cache_dir()
    cache_hash = _get_cache_hash(layer_paths)
    cache_path = os.path.join(cache_dir, f"recipe-index-{cache_hash}.json")

    try:
        with open(cache_path, "w") as f:
            json.dump({
                "timestamp": time.time(),
                "recipes": recipes,
            }, f)
    except OSError:
        pass


# =============================================================================
# Recipe Metadata Parsing
# =============================================================================

def _parse_recipe_metadata(filepath: str) -> dict:
    """
    Extract metadata from a .bb recipe file using regex.

    Returns dict with:
    - SUMMARY, DESCRIPTION, LICENSE, HOMEPAGE, SECTION, DEPENDS
    """
    metadata = {
        "SUMMARY": "",
        "DESCRIPTION": "",
        "LICENSE": "",
        "HOMEPAGE": "",
        "SECTION": "",
        "DEPENDS": "",
    }

    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return metadata

    # Parse each variable
    for var in metadata.keys():
        # Match VAR = "value" or VAR = 'value'
        # Also handle ?= and ??= but prefer =
        patterns = [
            rf'^{var}\s*=\s*"([^"]*)"',
            rf"^{var}\s*=\s*'([^']*)'",
            rf'^{var}\s*\?=\s*"([^"]*)"',
            rf"^{var}\s*\?=\s*'([^']*)'",
        ]

        for pattern in patterns:
            match = re.search(pattern, content, re.MULTILINE)
            if match:
                metadata[var] = match.group(1).strip()
                break

    return metadata


def _extract_pn_pv(filename: str) -> Tuple[str, str]:
    """
    Extract PN (recipe name) and PV (version) from filename.

    Handles:
    - recipe_version.bb -> (recipe, version)
    - recipe.bb -> (recipe, "")
    - recipe-name_1.2.3.bb -> (recipe-name, 1.2.3)
    - recipe_%.bbappend -> (recipe, %) for version-wildcard appends
    - recipe.bbappend -> (recipe, "")
    """
    # Remove .bb or .bbappend extension
    if filename.endswith(".bbappend"):
        basename = filename[:-9]
    elif filename.endswith(".bb"):
        basename = filename[:-3]
    else:
        basename = filename

    # Split on underscore for version
    if "_" in basename:
        parts = basename.rsplit("_", 1)
        pn = parts[0]
        pv = parts[1] if len(parts) > 1 else ""
    else:
        pn = basename
        pv = ""

    return pn, pv


# =============================================================================
# Recipe Scanning
# =============================================================================

def _scan_recipes_from_layers(
    layer_paths: List[str],
    force: bool = False,
    progress: bool = True,
) -> List[dict]:
    """
    Scan layers for recipes using file glob.

    Returns list of recipe dicts with:
    - pn, pv, path, layer, layer_name
    - SUMMARY, DESCRIPTION, LICENSE, HOMEPAGE, SECTION, DEPENDS
    """
    if not force:
        cached = _load_recipe_cache(layer_paths)
        if cached is not None:
            return cached

    recipes = []
    seen_recipes = set()  # Track (pn, layer) to avoid duplicates

    if progress:
        print(Colors.dim("Scanning recipes..."), end=" ", flush=True)

    total_layers = len(layer_paths)

    for idx, layer_path in enumerate(layer_paths):
        layer_name = layer_display_name(layer_path)

        # Glob for recipes: recipes-*/*/*.bb and recipes-*/*/*.bbappend
        pattern = os.path.join(layer_path, "recipes-*", "*", "*.bb")
        bb_files = glob.glob(pattern)

        # Also check for recipes directly in recipes-*/*.bb (less common)
        pattern2 = os.path.join(layer_path, "recipes-*", "*.bb")
        bb_files.extend(glob.glob(pattern2))

        # Also glob for bbappend files
        pattern_append = os.path.join(layer_path, "recipes-*", "*", "*.bbappend")
        bb_files.extend(glob.glob(pattern_append))
        pattern_append2 = os.path.join(layer_path, "recipes-*", "*.bbappend")
        bb_files.extend(glob.glob(pattern_append2))

        for bb_path in bb_files:
            filename = os.path.basename(bb_path)

            # Determine if this is a recipe or append
            is_append = filename.endswith(".bbappend")

            pn, pv = _extract_pn_pv(filename)

            # Track unique entries per layer (separate tracking for recipes vs appends)
            entry_type = "append" if is_append else "recipe"
            key = (pn, layer_path, entry_type)
            if key in seen_recipes:
                continue
            seen_recipes.add(key)

            # Parse metadata
            metadata = _parse_recipe_metadata(bb_path)

            recipes.append({
                "pn": pn,
                "pv": pv,
                "path": bb_path,
                "layer": layer_path,
                "layer_name": layer_name,
                "type": entry_type,
                **metadata,
            })

    if progress:
        print(Colors.dim(f"{len(recipes)} recipes found"))

    # Save to cache
    _save_recipe_cache(layer_paths, recipes)

    return recipes


def _scan_configured_recipes(
    bblayers_path: str,
    force: bool = False,
    use_bitbake_layers: bool = True,
) -> Tuple[List[dict], List[str]]:
    """
    Get recipes from configured layers.

    First tries bitbake-layers show-recipes if available and use_bitbake_layers is True,
    then falls back to file scan.

    Args:
        bblayers_path: Path to bblayers.conf
        force: Force cache rebuild
        use_bitbake_layers: If True, try bitbake-layers first (default True)

    Returns (recipes, layer_paths).
    """
    # Get configured layer paths
    try:
        from .common import extract_layer_paths
        layer_paths = extract_layer_paths(bblayers_path)
    except SystemExit:
        return [], []

    # Try bitbake-layers if available and enabled (more accurate, includes bbappends)
    if use_bitbake_layers and shutil.which("bitbake-layers") and not force:
        recipes = _try_bitbake_layers_recipes()
        if recipes:
            return recipes, layer_paths

    # Fall back to file scan
    recipes = _scan_recipes_from_layers(layer_paths, force=force)
    return recipes, layer_paths


def _try_bitbake_layers_recipes() -> Optional[List[dict]]:
    """
    Try to get recipes via bitbake-layers show-recipes.

    Returns list of recipe dicts or None if unavailable/failed.
    """
    try:
        result = subprocess.run(
            ["bitbake-layers", "show-recipes", "-f"],
            capture_output=True,
            text=True,
            timeout=60,
        )
        if result.returncode != 0:
            return None

        # Parse output - format is:
        # recipe-name:
        #   layer-name version
        recipes = []
        current_pn = None
        for line in result.stdout.splitlines():
            line = line.rstrip()
            if not line:
                continue
            if line.endswith(":") and not line.startswith(" "):
                current_pn = line[:-1].strip()
            elif line.startswith("  ") and current_pn:
                # Parse "  layer-name version"
                parts = line.strip().split()
                if len(parts) >= 2:
                    layer_name = parts[0]
                    pv = parts[1]
                    recipes.append({
                        "pn": current_pn,
                        "pv": pv,
                        "path": "",  # bitbake-layers doesn't give path
                        "layer": "",
                        "layer_name": layer_name,
                        "SUMMARY": "",
                        "DESCRIPTION": "",
                        "LICENSE": "",
                        "HOMEPAGE": "",
                        "SECTION": "",
                        "DEPENDS": "",
                    })

        return recipes if recipes else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


# =============================================================================
# Layer Index API
# =============================================================================

def _get_recipe_index_cache_path(branch: str) -> str:
    """Get path to recipe index API cache file."""
    cache_dir = _get_recipe_cache_dir()
    return os.path.join(cache_dir, f"recipe-api-{branch}.json")


def _fetch_recipe_index(branch: str = "master", force: bool = False, search: str = "") -> Optional[List[dict]]:
    """
    Fetch recipes from layers.openembedded.org API.

    Args:
        branch: Branch to filter by (default: master)
        force: Force refresh, ignore cache
        search: Optional search query (sent to API for server-side filtering)

    Returns list of recipe dicts or None on error.
    """
    # Only use cache for full fetches (no search query)
    cache_path = _get_recipe_index_cache_path(branch)
    cache_max_age = 2 * 60 * 60  # 2 hours

    if not search and not force and os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    data = json.load(f)
                    return data.get("recipes")
        except (json.JSONDecodeError, OSError, KeyError):
            pass

    # Fetch from API
    # The recipes endpoint is paginated, we need to fetch all pages
    api_base = "https://layers.openembedded.org/layerindex/api/recipes/"
    all_recipes = []

    # Build URL with optional search parameter
    if search:
        encoded_search = urllib.parse.quote(search)
        next_url = f"{api_base}?format=json&search={encoded_search}"
        print(Colors.dim(f"Searching index for '{search}'..."), end=" ", flush=True)
    else:
        next_url = f"{api_base}?format=json"
        print(Colors.dim("Fetching recipe index..."), end=" ", flush=True)

    try:
        page = 0
        while next_url and page < 50:  # Safety limit
            page += 1
            with urllib.request.urlopen(next_url, timeout=30) as resp:
                data = json.loads(resp.read().decode())

            # API may return paginated results
            if isinstance(data, list):
                all_recipes.extend(data)
                next_url = None
            elif isinstance(data, dict):
                results = data.get("results", data.get("objects", []))
                all_recipes.extend(results)
                next_url = data.get("next")
            else:
                break

        print(Colors.dim(f"{len(all_recipes)} recipes"))

        # Transform to our format
        recipes = []
        for entry in all_recipes:
            # Get branch info - filter by branch
            lb = entry.get("layerbranch", {})
            branch_info = lb.get("branch", {}) if isinstance(lb, dict) else {}
            entry_branch = branch_info.get("name", "") if isinstance(branch_info, dict) else ""

            # The API structure varies - adapt as needed
            pn = entry.get("pn", entry.get("name", ""))
            pv = entry.get("pv", "")
            summary = entry.get("summary", "")
            description = entry.get("description", "")
            section = entry.get("section", "")
            license_val = entry.get("license", "")
            homepage = entry.get("homepage", "")

            # Get layer name from layerbranch
            layer_name = ""
            if isinstance(lb, dict):
                layer_info = lb.get("layer", {})
                if isinstance(layer_info, dict):
                    layer_name = layer_info.get("name", "")

            if pn:
                recipes.append({
                    "pn": pn,
                    "pv": pv,
                    "path": "",  # Remote, no local path
                    "layer": "",
                    "layer_name": layer_name,
                    "SUMMARY": summary,
                    "DESCRIPTION": description,
                    "LICENSE": license_val,
                    "HOMEPAGE": homepage,
                    "SECTION": section,
                    "DEPENDS": "",
                    "source": "index",
                    "branch": entry_branch,
                })

        # Save to cache
        try:
            with open(cache_path, "w") as f:
                json.dump({"timestamp": time.time(), "recipes": recipes}, f)
        except OSError:
            pass

        return recipes

    except urllib.error.URLError as e:
        print(Colors.dim("failed"))
        # Try stale cache
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r") as f:
                    data = json.load(f)
                    if data.get("recipes"):
                        print(Colors.yellow(f"Using cached data (network error)"))
                        return data["recipes"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass
        print(f"Error fetching recipe index: {e}")
        return None
    except json.JSONDecodeError as e:
        print(Colors.dim("failed"))
        print(f"Error parsing response: {e}")
        return None


# =============================================================================
# FZF Browser
# =============================================================================

def _build_recipe_menu(
    recipes: List[dict],
    source_name: str,
) -> str:
    """Build fzf menu input for recipe list."""
    if not recipes:
        return ""

    # Separate recipes from appends
    regular_recipes = [r for r in recipes if r.get("type") != "append"]
    append_recipes = [r for r in recipes if r.get("type") == "append"]

    # Calculate column widths across all entries
    all_recipes = regular_recipes + append_recipes
    max_pn_len = max(len(r["pn"]) for r in all_recipes) if all_recipes else 20
    max_pn_len = min(max_pn_len, 30)
    max_pv_len = max(len(r.get("pv", "")) for r in all_recipes) if all_recipes else 10
    max_pv_len = min(max_pv_len, 15)
    max_layer_len = max(len(r.get("layer_name", "")) for r in all_recipes) if all_recipes else 15
    max_layer_len = min(max_layer_len, 20)

    menu_lines = []

    def format_recipe(recipe, is_append=False):
        pn = recipe["pn"][:30]
        pv = recipe.get("pv", "")[:15]
        layer_name = recipe.get("layer_name", "")[:20]
        summary = recipe.get("SUMMARY", "")[:50]
        path = recipe.get("path", "")

        # Color based on type and source
        is_remote = recipe.get("source") == "index"
        if is_append:
            # Appends shown in yellow/magenta
            colored_pn = Colors.yellow(f"{pn:<{max_pn_len}}")
            type_marker = Colors.dim("(append)")
        elif is_remote:
            colored_pn = Colors.cyan(f"{pn:<{max_pn_len}}")
            type_marker = ""
        else:
            colored_pn = Colors.green(f"{pn:<{max_pn_len}}")
            type_marker = ""

        if type_marker:
            line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {type_marker} {summary}"
        else:
            line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {summary}"
        return line

    # Add regular recipes first
    for recipe in regular_recipes:
        menu_lines.append(format_recipe(recipe, is_append=False))

    # Add separator if we have both types
    if regular_recipes and append_recipes:
        # fzf separator line (non-selectable)
        menu_lines.append(f"---\t{Colors.dim('── Appends (' + str(len(append_recipes)) + ') ──')}")

    # Add appends
    for recipe in append_recipes:
        menu_lines.append(format_recipe(recipe, is_append=True))

    return "\n".join(menu_lines)


def _format_recipe_line(recipe: dict, max_pn_len: int = COL_PN, max_pv_len: int = COL_PV, max_layer_len: int = COL_LAYER) -> str:
    """Format a single recipe line for fzf menu."""
    pn = recipe["pn"][:max_pn_len]
    pv = recipe.get("pv", "")[:max_pv_len]
    layer_name = recipe.get("layer_name", "")[:max_layer_len]
    summary = recipe.get("SUMMARY", "")[:50]
    path = recipe.get("path", "")
    is_append = recipe.get("type") == "append"
    is_remote = recipe.get("source") == "index"

    if is_append:
        colored_pn = Colors.yellow(f"{pn:<{max_pn_len}}")
        type_marker = Colors.dim("(append)")
    elif is_remote:
        colored_pn = Colors.cyan(f"{pn:<{max_pn_len}}")
        type_marker = ""
    else:
        colored_pn = Colors.green(f"{pn:<{max_pn_len}}")
        type_marker = ""

    if type_marker:
        line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {type_marker} {summary}"
    else:
        line = f"{path}\t{colored_pn}  {pv:<{max_pv_len}}  {layer_name:<{max_layer_len}}  {summary}"
    return line


def _get_all_recipe_groups(recipes: List[dict], group_by: str) -> set:
    """Get all group names for recipes based on grouping mode."""
    groups = set()
    for r in recipes:
        if group_by == "layer":
            groups.add(r.get("layer_name", "(unknown)"))
        elif group_by == "section":
            groups.add(r.get("SECTION", "") or "(no section)")
    return groups


def _build_recipe_menu_by_layer(
    recipes: List[dict],
    collapsed: set = None,
) -> str:
    """Build fzf menu input with recipes grouped by layer.

    Args:
        recipes: List of recipes to display
        collapsed: Set of group names that are collapsed (show only header)
    """
    lines = []
    collapsed = collapsed or set()

    # Group by layer
    by_layer: Dict[str, List[dict]] = {}
    for r in recipes:
        layer = r.get("layer_name", "(unknown)")
        by_layer.setdefault(layer, []).append(r)

    for layer_name in sorted(by_layer.keys()):
        layer_recipes = by_layer[layer_name]
        is_collapsed = layer_name in collapsed

        # Prefix: + for collapsed (expandable), - for expanded
        prefix = "+" if is_collapsed else "-"

        # Use display name from config if available
        display_name = layer_display_name(layer_name)

        # Group header line - use GROUP: prefix so we can identify it
        # Store original layer_name as the key, but show display_name
        header_text = f"{prefix} {display_name} ({len(layer_recipes)})"
        lines.append(f"GROUP:{layer_name}\t{Colors.cyan(header_text)}")

        # Only show recipes if group is expanded
        if not is_collapsed:
            for r in sorted(layer_recipes, key=lambda x: x.get("pn", "")):
                lines.append(_format_recipe_line(r))

    return "\n".join(lines)


def _build_recipe_menu_by_section(
    recipes: List[dict],
    collapsed: set = None,
) -> str:
    """Build fzf menu input with recipes grouped by SECTION.

    Args:
        recipes: List of recipes to display
        collapsed: Set of group names that are collapsed (show only header)
    """
    lines = []
    collapsed = collapsed or set()

    # Group by section
    by_section: Dict[str, List[dict]] = {}
    for r in recipes:
        section = r.get("SECTION", "") or "(no section)"
        by_section.setdefault(section, []).append(r)

    for section_name in sorted(by_section.keys()):
        section_recipes = by_section[section_name]
        is_collapsed = section_name in collapsed

        # Prefix: + for collapsed (expandable), - for expanded
        prefix = "+" if is_collapsed else "-"

        # Group header line
        header_text = f"{prefix} {section_name} ({len(section_recipes)})"
        lines.append(f"GROUP:{section_name}\t{Colors.cyan(header_text)}")

        # Only show recipes if group is expanded
        if not is_collapsed:
            for r in sorted(section_recipes, key=lambda x: x.get("pn", "")):
                lines.append(_format_recipe_line(r))

    return "\n".join(lines)


def _build_recipe_menu_flat(
    recipes: List[dict],
    expanded_deps: Dict[str, Tuple[List[str], List[str]]] = None,
    recipes_by_pn: Dict[str, dict] = None,
) -> str:
    """Build fzf menu input as a flat list (no grouping).

    Args:
        recipes: List of recipes to display
        expanded_deps: Dict mapping recipe path to (depends, rdepends) for expanded recipes
        recipes_by_pn: Dict mapping recipe name (pn) to recipe dict for looking up deps
    """
    lines = []
    expanded_deps = expanded_deps or {}
    recipes_by_pn = recipes_by_pn or {}

    # Separate recipes from appends
    regular_recipes = [r for r in recipes if r.get("type") != "append"]
    append_recipes = [r for r in recipes if r.get("type") == "append"]

    def add_dep_tree(r: dict, depth: int, dep_type: str = "build", visited: set = None, is_last_sibling: bool = True):
        """Add a dependency and its sub-dependencies recursively.

        Args:
            r: Recipe dict for the dependency
            depth: Current indentation depth
            dep_type: "build" for DEPENDS, "runtime" for RDEPENDS
            visited: Set of already-visited paths to prevent circular dependency loops
            is_last_sibling: Whether this is the last sibling at this level
        """
        if visited is None:
            visited = set()

        path = r.get("path", r.get("pn", ""))
        pn = r.get("pn", "")
        pv = r.get("pv", "")[:10]
        layer = r.get("layer_name", "")[:15]
        indent = "  " * depth
        is_expanded = path in expanded_deps
        prefix = "-" if is_expanded else "+"

        # Check for circular dependency
        is_circular = path in visited
        if is_circular:
            prefix = "○"  # Circular indicator

        # Format line based on dep type
        if dep_type == "runtime":
            line_prefix = "RDEP"
            name_display = Colors.magenta(f"{pn:<25}")
            suffix = " (runtime)"
        else:
            line_prefix = "DEP"
            name_display = f"{pn:<25}"
            suffix = ""

        if is_circular:
            suffix += " (circular)"

        connector = "└─" if is_last_sibling else "├─"
        lines.append(f"{line_prefix}:{path}:{depth}\t{indent}{connector} {prefix} {name_display} {pv:<10} {layer}{suffix}")

        # Don't recurse if circular or not expanded
        if is_circular or not is_expanded:
            return

        # Mark as visited for this branch
        visited = visited | {path}  # Create new set to not affect siblings

        sub_depends, sub_rdepends = expanded_deps[path]

        # Combine build + runtime deps to determine last-sibling status
        all_sub_deps = [(name, "build") for name in sorted(sub_depends)] + \
                       [(name, "runtime") for name in sorted(sub_rdepends)]
        for idx, (dep_name, dtype) in enumerate(all_sub_deps):
            is_last = (idx == len(all_sub_deps) - 1)
            sub_dep_recipe = recipes_by_pn.get(dep_name)
            if sub_dep_recipe:
                add_dep_tree(sub_dep_recipe, depth + 1, dtype, visited, is_last_sibling=is_last)
            else:
                sub_indent = "  " * (depth + 1)
                connector = "└─" if is_last else "├─"
                if dtype == "runtime":
                    lines.append(f"RDEP_EXT:{dep_name}:{depth+1}\t{sub_indent}{connector}   {Colors.dim(dep_name)} (runtime, external)")
                else:
                    lines.append(f"DEP_EXT:{dep_name}:{depth+1}\t{sub_indent}{connector}   {Colors.dim(dep_name)} (external)")

    def add_recipe_with_deps(r: dict):
        """Add a top-level recipe line and its expanded dependencies."""
        path = r.get("path", r.get("pn", ""))

        # Top-level recipe - show expand/collapse indicator
        is_expanded = path in expanded_deps
        prefix = "-" if is_expanded else "+"
        line = _format_recipe_line(r)
        # Insert prefix after the path\t
        parts = line.split("\t", 1)
        if len(parts) == 2:
            lines.append(f"{parts[0]}\t{prefix} {parts[1]}")
        else:
            lines.append(f"{path}\t{prefix} {line}")

        # If expanded, show dependencies
        if is_expanded:
            depends, rdepends = expanded_deps[path]
            # Start visited set with the root recipe to detect circular deps
            visited = {path}

            # Combine build + runtime deps to determine last-sibling status
            all_deps = [(name, "build") for name in sorted(depends)] + \
                       [(name, "runtime") for name in sorted(rdepends)]
            for idx, (dep_name, dtype) in enumerate(all_deps):
                is_last = (idx == len(all_deps) - 1)
                dep_recipe = recipes_by_pn.get(dep_name)
                if dep_recipe:
                    add_dep_tree(dep_recipe, 1, dtype, visited, is_last_sibling=is_last)
                else:
                    connector = "└─" if is_last else "├─"
                    if dtype == "runtime":
                        lines.append(f"RDEP_EXT:{dep_name}:1\t  {connector}   {Colors.dim(dep_name)} (runtime, external)")
                    else:
                        lines.append(f"DEP_EXT:{dep_name}:1\t  {connector}   {Colors.dim(dep_name)} (external)")

    # Add regular recipes first, sorted by name
    for r in sorted(regular_recipes, key=lambda x: x.get("pn", "")):
        add_recipe_with_deps(r)

    # Add separator if we have both types
    if regular_recipes and append_recipes:
        lines.append(f"---\t{Colors.dim('── Appends (' + str(len(append_recipes)) + ') ──')}")

    # Add appends
    for r in sorted(append_recipes, key=lambda x: x.get("pn", "")):
        add_recipe_with_deps(r)

    return "\n".join(lines)


def _build_recipe_preview(recipe: dict) -> str:
    """Build preview content for a recipe."""
    lines = []

    pn = recipe.get("pn", "")
    pv = recipe.get("pv", "")
    layer_name = recipe.get("layer_name", "")
    path = recipe.get("path", "")

    lines.append(f"{Colors.bold(pn)}")
    if pv:
        lines.append(f"Version: {pv}")
    lines.append(f"Layer: {layer_name}")
    if path:
        lines.append(f"Path: {path}")
    lines.append("")

    summary = recipe.get("SUMMARY", "")
    if summary:
        lines.append(f"{Colors.cyan('Summary:')}")
        lines.append(f"  {summary}")
        lines.append("")

    description = recipe.get("DESCRIPTION", "")
    if description:
        lines.append(f"{Colors.cyan('Description:')}")
        # Word wrap
        for line in description.split("\n"):
            lines.append(f"  {line}")
        lines.append("")

    license_val = recipe.get("LICENSE", "")
    if license_val:
        lines.append(f"{Colors.cyan('License:')} {license_val}")

    homepage = recipe.get("HOMEPAGE", "")
    if homepage:
        lines.append(f"{Colors.cyan('Homepage:')} {homepage}")

    section = recipe.get("SECTION", "")
    if section:
        lines.append(f"{Colors.cyan('Section:')} {section}")

    depends = recipe.get("DEPENDS", "")
    if depends:
        lines.append(f"{Colors.cyan('Depends:')} {depends}")

    return "\n".join(lines)


def _recipe_fzf_browser(
    recipes: List[dict],
    source_name: str,
    query: str = "",
    allow_source_switch: bool = True,
    is_remote: bool = False,
    available_sources: List[str] = None,
    group_by: str = "flat",
):
    """
    Interactive fzf browser for recipes.

    Key bindings:
    - Enter: View recipe in $EDITOR or less (or toggle group)
    - \\: Toggle group (on group header) or toggle all (on item)
    - ctrl-e: Edit recipe in $EDITOR (disabled for remote)
    - alt-c: Copy path to clipboard
    - ctrl-f: Show full file in preview
    - ctrl-i: Show metadata info in preview
    - alt-s: Cycle through sources (Configured → Local → Index)
    - ctrl-g: Toggle grouping (flat → layer → section)
    - ctrl-s: Search/filter dialog
    - ctrl-r: Reset filter
    - alt-up/down: Scroll preview by pages
    - alt-j/k: Scroll preview by lines
    - ?: Toggle preview
    - esc: Quit (or cancel dialog)

    Returns:
    - 0: Normal exit
    - 1: Error
    - ("switch", source): Switch to specified source
    """
    if not recipes:
        print("No recipes found.")
        return 1

    if not fzf_available():
        # Fall back to text list
        for recipe in recipes:
            pn = recipe.get("pn", "")
            pv = recipe.get("pv", "")
            layer_name = recipe.get("layer_name", "")
            print(f"  {Colors.green(pn):<30}  {pv:<15}  {layer_name}")
        return 0

    # Build preview script
    # We'll use temp files - one for data, one for the preview script
    import tempfile
    preview_data = {r.get("path", r.get("pn", "")): r for r in recipes}
    preview_data_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(preview_data, preview_data_file)
    preview_data_file.close()

    # Create a preview script file to avoid shell escaping issues
    preview_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_script.write(f'''#!/usr/bin/env python3
import json
import sys

key = sys.argv[1] if len(sys.argv) > 1 else ""
# Strip any surrounding quotes that fzf might add
key = key.strip("'\\\"")

# Handle DEP:/RDEP: prefixed keys (dependency lines)
# Format: DEP:path:depth or RDEP:path:depth
if key.startswith("DEP:") or key.startswith("RDEP:") or key.startswith("DEP_EXT:") or key.startswith("RDEP_EXT:"):
    parts = key.split(":", 2)
    if len(parts) >= 2:
        key = parts[1]  # Extract the actual path

with open("{preview_data_file.name}", "r") as f:
    data = json.load(f)

recipe = data.get(key, {{}})
if not recipe:
    print(f"No data for: {{key}}")
    sys.exit(0)

pn = recipe.get("pn", "")
pv = recipe.get("pv", "")
layer_name = recipe.get("layer_name", "")
path = recipe.get("path", "")
summary = recipe.get("SUMMARY", "")
description = recipe.get("DESCRIPTION", "")
license_val = recipe.get("LICENSE", "")
homepage = recipe.get("HOMEPAGE", "")
section = recipe.get("SECTION", "")
depends = recipe.get("DEPENDS", "")

print(f"\\033[1m{{pn}}\\033[0m")
if pv:
    print(f"Version: {{pv}}")
print(f"Layer: {{layer_name}}")
if path:
    print(f"Path: {{path}}")
print()
if summary:
    print("\\033[36mSummary:\\033[0m")
    print(f"  {{summary}}")
    print()
if description:
    print("\\033[36mDescription:\\033[0m")
    for line in description.split("\\n"):
        print(f"  {{line}}")
    print()
if license_val:
    print(f"\\033[36mLicense:\\033[0m {{license_val}}")
if homepage:
    print(f"\\033[36mHomepage:\\033[0m {{homepage}}")
if section:
    print(f"\\033[36mSection:\\033[0m {{section}}")
if depends:
    print(f"\\033[36mDepends:\\033[0m {{depends}}")
''')
    preview_script.close()

    # Create deps preview script
    preview_deps_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_deps_script.write(f'''#!/usr/bin/env python3
import json
import os
import re
import sys

key = sys.argv[1] if len(sys.argv) > 1 else ""
key = key.strip("'\\"")

if key.startswith("DEP:") or key.startswith("RDEP:") or key.startswith("DEP_EXT:") or key.startswith("RDEP_EXT:"):
    parts = key.split(":", 2)
    if len(parts) >= 2:
        key = parts[1]

with open("{preview_data_file.name}", "r") as f:
    data = json.load(f)

recipe = data.get(key, {{}})
if not recipe:
    print(f"No data for: {{key}}")
    sys.exit(0)

pn = recipe.get("pn", "")
path = recipe.get("path", "")

def clean_deps(s):
    s = re.sub(r'\\${{[^}}]*}}', ' ', s)
    return s

def parse_deps(filepath):
    depends, rdepends = [], []
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            content = f.read()
    except (OSError, IOError):
        return depends, rdepends
    content = content.replace("\\\\\\n", " ")
    for m in re.finditer(r'^DEPENDS\\s*[+:]?=\\s*"([^"]*)"', content, re.MULTILINE):
        for dep in clean_deps(m.group(1)).split():
            if dep and re.match(r'^[a-zA-Z0-9]', dep) and dep not in depends:
                depends.append(dep)
    for m in re.finditer(r'^RDEPENDS[:\\w${{}}\\-]*\\s*[+:]?=\\s*"([^"]*)"', content, re.MULTILINE):
        for dep in clean_deps(m.group(1)).split():
            if dep and re.match(r'^[a-zA-Z0-9]', dep) and dep not in rdepends:
                rdepends.append(dep)
    return depends, rdepends

print(f"\\033[1m{{pn}}\\033[0m")
print(f"Layer: {{recipe.get('layer_name', '')}}")
if path:
    print(f"Path: {{path}}")
print()

if path and os.path.isfile(path):
    depends, rdepends = parse_deps(path)
    if depends:
        print(f"\\033[36mBuild dependencies (DEPENDS):\\033[0m")
        for i, dep in enumerate(sorted(depends)):
            conn = "\\u2514\\u2500\\u2500 " if i == len(depends) - 1 and not rdepends else "\\u251c\\u2500\\u2500 "
            print(f"  {{conn}}{{dep}}")
    else:
        print(f"\\033[36mBuild dependencies (DEPENDS):\\033[0m (none)")
    print()
    if rdepends:
        print(f"\\033[36mRuntime dependencies (RDEPENDS):\\033[0m")
        for i, dep in enumerate(sorted(rdepends)):
            conn = "\\u2514\\u2500\\u2500 " if i == len(rdepends) - 1 else "\\u251c\\u2500\\u2500 "
            print(f"  {{conn}}{{dep}}")
    else:
        print(f"\\033[36mRuntime dependencies (RDEPENDS):\\033[0m (none)")
else:
    print("Remote recipe - no local file available for dependency parsing")
''')
    preview_deps_script.close()

    # Preview commands - metadata view, full file view, and deps tree view
    # Note: fzf's {1} is already shell-quoted, don't add extra quotes
    preview_metadata = f'python3 "{preview_script.name}" {{1}}'
    preview_deps = f'python3 "{preview_deps_script.name}" {{1}}'
    # For file preview, extract path from DEP:/RDEP: prefixed strings first
    # Format: DEP:path:depth or RDEP:path:depth -> extract path
    preview_file = r'''
        key={1}
        # Remove quotes if present
        key="${key#\'}"
        key="${key%\'}"
        # Extract path from DEP:/RDEP: prefix if present
        case "$key" in
            DEP:*|RDEP:*|DEP_EXT:*|RDEP_EXT:*)
                # Split on : and get second field (the path)
                path=$(echo "$key" | cut -d: -f2)
                ;;
            *)
                path="$key"
                ;;
        esac
        if [ -f "$path" ]; then
            cat "$path"
        else
            echo "Remote recipe - no local file available"
            echo ""
            echo "Path: $path"
        fi
    '''

    preview_window = get_preview_window_arg("50%")

    # State for the browser loop
    current_group_by = group_by
    current_query = query
    original_recipes = recipes  # Keep original for reset
    filtered_recipes = recipes

    # Collapsed groups - start collapsed
    collapsed_groups: set = _get_all_recipe_groups(recipes, group_by) if group_by != "flat" else set()

    # Expanded dependencies - maps recipe path to (depends, rdepends) tuples
    expanded_deps: Dict[str, Tuple[List[str], List[str]]] = {}

    # Build recipe lookup by name for dependency resolution
    recipes_by_pn: Dict[str, dict] = {}
    for r in recipes:
        pn = r.get("pn", "")
        if pn and pn not in recipes_by_pn:
            recipes_by_pn[pn] = r

    # Options menu state using TUI abstraction
    show_options = False
    has_local = "configured" in available_sources or "local" in available_sources
    options_menu = build_recipe_options_menu(available_sources, has_local=has_local)
    options_state = InlineOptionsState(options_menu)

    # Track last selection for cursor positioning after expand/collapse
    last_selected: Optional[str] = None

    try:
        while True:
            # Build menu based on grouping mode
            if current_group_by == "layer":
                base_menu_input = _build_recipe_menu_by_layer(filtered_recipes, collapsed_groups)
            elif current_group_by == "section":
                base_menu_input = _build_recipe_menu_by_section(filtered_recipes, collapsed_groups)
            else:  # flat
                base_menu_input = _build_recipe_menu_flat(filtered_recipes, expanded_deps, recipes_by_pn)

            # Build recipe-to-group mapping for toggling group when recipe selected
            recipe_to_group = {}
            for r in filtered_recipes:
                path = r.get("path", r.get("pn", ""))
                if current_group_by == "layer":
                    recipe_to_group[path] = r.get("layer_name", "(unknown)")
                elif current_group_by == "section":
                    recipe_to_group[path] = r.get("SECTION", "") or "(no section)"

            # Add separator lines for grouped modes
            if current_group_by != "flat":
                # Top and bottom separators - selecting toggles all groups
                sep_line = "─" * 60
                top_sep = f"TOGGLE_ALL\t{Colors.dim(sep_line)}"
                bottom_sep = f"TOGGLE_ALL\t{Colors.dim(sep_line)}"
                menu_input = top_sep + "\n" + base_menu_input + "\n" + bottom_sep
            else:
                menu_input = base_menu_input

            # Build options menu if active using TUI abstraction
            if show_options:
                options_lines = options_state.build_menu_lines()
                menu_input = menu_input + "\n" + "\n".join(options_lines)

            # Find position of last_selected for cursor positioning
            cursor_pos = None
            if last_selected and not show_options:
                menu_lines = menu_input.split("\n")
                for i, line in enumerate(menu_lines):
                    # Check if this line starts with the selected key
                    line_key = line.split("\t")[0] if "\t" in line else line
                    if line_key == last_selected:
                        cursor_pos = i + 1  # fzf uses 1-based positions
                        break

            # Build header
            group_indicator = f"group:{current_group_by}"
            filter_indicator = ""
            count_indicator = f"({len(filtered_recipes)}/{len(original_recipes)})" if len(filtered_recipes) != len(original_recipes) else f"({len(filtered_recipes)})"

            if show_options:
                header = "Space=toggle | Enter=select | Type query for Search | Esc=close"
            else:
                header_line1_base = f"{get_project_header_prefix()}[{source_name}] {count_indicator} {group_indicator}{filter_indicator}"
                header_line1_info = f"{header_line1_base} preview:info"
                header_line1_file = f"{header_line1_base} preview:file"
                header_line1_deps = f"{header_line1_base} preview:deps"
                if current_group_by != "flat":
                    header_line2_info = "Enter/→=expand | ←=collapse | ctrl-e=view/edit | alt-c=copy | alt-d=deps | ctrl-f=file"
                    header_line2_file = "Enter/→=expand | ←=collapse | ctrl-e=view/edit | alt-c=copy | alt-d=deps | ctrl-i=info"
                    header_line2_deps = "Enter/→=expand | ←=collapse | ctrl-e=view/edit | alt-c=copy | ctrl-i=info | ctrl-f=file"
                    header_line3 = "ctrl-g=group | ctrl-s=search | ctrl-r=reset | esc=quit"
                else:
                    header_line2_info = "Enter/→=expand | ←=collapse | ctrl-v=view | "
                    header_line2_file = "Enter/→=expand | ←=collapse | ctrl-v=view | "
                    header_line2_deps = "Enter/→=expand | ←=collapse | ctrl-v=view | "
                    if not is_remote:
                        header_line2_info += "ctrl-e=edit | "
                        header_line2_file += "ctrl-e=edit | "
                        header_line2_deps += "ctrl-e=edit | "
                    header_line2_info += "alt-c=copy | alt-d=deps | ctrl-f=file"
                    header_line2_file += "alt-c=copy | alt-d=deps | ctrl-i=info"
                    header_line2_deps += "alt-c=copy | ctrl-i=info | ctrl-f=file"
                    header_line3 = "ctrl-g=group | ctrl-s=search | ctrl-r=reset | esc=quit"
                header_line4 = get_preview_header_suffix()
                header = f"{header_line1_info}\n{header_line2_info}\n{header_line3}\n{header_line4}"
                header_file = f"{header_line1_file}\n{header_line2_file}\n{header_line3}\n{header_line4}"
                header_deps = f"{header_line1_deps}\n{header_line2_deps}\n{header_line3}\n{header_line4}"

            # Pad to fill terminal height so list top-aligns with preview top
            try:
                term_lines = os.get_terminal_size().lines
            except OSError:
                term_lines = 40
            header_line_count = header.count('\n') + 1
            chrome_lines = header_line_count + 2  # header + prompt + info line
            if preview_window.startswith("right"):
                available = term_lines - chrome_lines
            else:
                available = (term_lines // 2) - chrome_lines
            menu_line_count = menu_input.count('\n') + 1
            if menu_line_count < available:
                menu_input += "\n" + "\n".join("---\t" for _ in range(available - menu_line_count))

            # Build fzf command
            fzf_cmd = [
                "fzf",
                "--no-multi",
                "--ansi",
                "--height", "100%",
                "--layout=reverse-list",
                "--no-hscroll",
                "--header", header,
                "--prompt", "Query: " if show_options else f"Recipe ({source_name}): ",
                "--with-nth", "2..",
                "--delimiter", "\t",
                "--preview", preview_metadata,
                "--preview-window", preview_window,
                "--bind", f"ctrl-f:change-preview({preview_file})+change-header({header_file})",
                "--bind", f"ctrl-i:change-preview({preview_metadata})+change-header({header})",
                "--bind", f"alt-d:change-preview({preview_deps})+change-header({header_deps})",
            ]
            fzf_cmd.extend(get_preview_toggle_binding())
            fzf_cmd.extend(get_preview_scroll_bindings(include_half_page=False))

            if show_options:
                # Options mode - use TUI abstraction for fzf args
                fzf_cmd.extend(options_state.get_fzf_args())
            else:
                # Normal mode bindings
                fzf_cmd.extend(["--bind", "esc:abort"])
                fzf_cmd.extend(get_action_binding("right", "RIGHT {1}"))
                fzf_cmd.extend(get_action_binding("left", "LEFT {1}"))
                # Keep --expect for ctrl/alt keys that don't conflict
                expect_keys = ["ctrl-e", "ctrl-v", "alt-c", "ctrl-s", "ctrl-g", "ctrl-r", "\\"]
                fzf_cmd.extend(["--expect", ",".join(expect_keys)])

            # Add initial query if provided
            if current_query and not show_options:
                fzf_cmd.extend(["--query", current_query])

            # Position cursor at last selected item if available
            if cursor_pos and not show_options:
                fzf_cmd.extend(get_position_binding(cursor_pos))

            fzf_cmd.extend(get_fzf_preview_resize_bindings())
            fzf_cmd.extend(get_fzf_color_args())

            result = subprocess.run(
                fzf_cmd,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )

            # Handle interrupt (Esc)
            if result.returncode != 0:
                if show_options:
                    # Esc in options mode just closes options
                    show_options = False
                    continue
                break

            if not result.stdout.strip():
                if show_options:
                    show_options = False
                    continue
                break

            # Parse output - different format when show_options (has --print-query)
            lines = result.stdout.split("\n")
            if show_options:
                # Use TUI abstraction to parse options selection
                opt_result = options_state.parse_selection(result.stdout, result.returncode)

                if opt_result.cancelled:
                    show_options = False
                    continue

                # Handle toggle
                if opt_result.toggled:
                    # State already updated by parse_selection
                    continue

                # Handle actions
                if opt_result.action == "browse":
                    show_options = False
                    continue

                if opt_result.action == "search":
                    show_options = False
                    # Apply search with typed query
                    if opt_result.query.strip():
                        search_term = opt_result.query.strip().lower()
                        states = options_state.get_all_states()
                        def matches_recipe(r, term):
                            if states.get("name") and term in r.get("pn", "").lower():
                                return True
                            if states.get("summary") and term in r.get("SUMMARY", "").lower():
                                return True
                            if states.get("description") and term in r.get("DESCRIPTION", "").lower():
                                return True
                            return False
                        filtered_recipes = [r for r in original_recipes if matches_recipe(r, search_term)]
                        if current_group_by != "flat":
                            collapsed_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                    continue

                continue

            # Handle become() action bindings (right/left arrow) before --expect parsing
            output = result.stdout.strip()
            if output.startswith("RIGHT "):
                selected = output[6:].strip()
                if selected.startswith("---") or not selected:
                    continue
                if selected.startswith("GROUP:"):
                    # Expand group
                    group_name = selected[6:]
                    collapsed_groups.discard(group_name)
                elif selected == "TOGGLE_ALL":
                    all_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                    if collapsed_groups:
                        collapsed_groups = set()
                    else:
                        collapsed_groups = all_groups
                elif selected.startswith("DEP:") or selected.startswith("RDEP:"):
                    # Expand dep
                    parts = selected.split(":", 2)
                    if len(parts) >= 2:
                        dep_path = parts[1]
                        last_selected = selected
                        if dep_path not in expanded_deps:
                            dep_recipe = None
                            for r in original_recipes:
                                if r.get("path") == dep_path:
                                    dep_recipe = r
                                    break
                            if dep_recipe and dep_recipe.get("path") and os.path.isfile(dep_recipe["path"]):
                                from .deps import _parse_recipe_depends
                                depends, rdepends = _parse_recipe_depends(dep_recipe["path"])
                                expanded_deps[dep_path] = (depends, rdepends)
                elif selected.startswith("DEP_EXT:") or selected.startswith("RDEP_EXT:"):
                    pass  # External deps can't expand
                elif current_group_by != "flat" and selected in recipe_to_group:
                    # In grouped mode, expand the group this recipe belongs to
                    group_name = recipe_to_group[selected]
                    collapsed_groups.discard(group_name)
                else:
                    # Flat mode: expand deps (same as Enter)
                    path = selected
                    last_selected = path
                    if path and path not in expanded_deps:
                        if os.path.isfile(path):
                            from .deps import _parse_recipe_depends
                            depends, rdepends = _parse_recipe_depends(path)
                            expanded_deps[path] = (depends, rdepends)
                continue

            if output.startswith("LEFT "):
                selected = output[5:].strip()
                if selected.startswith("---") or not selected:
                    break  # Nothing to collapse, exit
                if selected.startswith("GROUP:"):
                    # Collapse group
                    group_name = selected[6:]
                    collapsed_groups.add(group_name)
                elif selected == "TOGGLE_ALL":
                    all_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                    if collapsed_groups:
                        collapsed_groups = set()
                    else:
                        collapsed_groups = all_groups
                elif selected.startswith("DEP:") or selected.startswith("RDEP:"):
                    # Collapse dep
                    parts = selected.split(":", 2)
                    if len(parts) >= 2:
                        dep_path = parts[1]
                        last_selected = selected
                        if dep_path in expanded_deps:
                            del expanded_deps[dep_path]
                elif selected.startswith("DEP_EXT:") or selected.startswith("RDEP_EXT:"):
                    pass  # External deps can't collapse
                elif current_group_by != "flat" and selected in recipe_to_group:
                    # In grouped mode, collapse the group this recipe belongs to
                    group_name = recipe_to_group[selected]
                    collapsed_groups.add(group_name)
                else:
                    # Flat mode: collapse deps
                    path = selected
                    last_selected = path
                    if path and path in expanded_deps:
                        del expanded_deps[path]
                    else:
                        break  # Nothing to collapse, exit browser
                continue

            key = lines[0].strip() if lines else ""
            selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

            # Handle key actions first (before checking selected)
            if key == "ctrl-g":
                # Toggle grouping mode
                if current_group_by == "flat":
                    current_group_by = "layer"
                elif current_group_by == "layer":
                    current_group_by = "section"
                else:
                    current_group_by = "flat"
                # Collapse all groups when switching modes (except flat)
                if current_group_by != "flat":
                    collapsed_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                else:
                    collapsed_groups = set()
                continue

            if key == "ctrl-r":
                # Reset filter
                filtered_recipes = original_recipes
                current_query = ""
                if current_group_by != "flat":
                    collapsed_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                else:
                    collapsed_groups = set()
                continue

            if key == "ctrl-s":
                # Show inline options menu
                show_options = True
                continue

            if key == "\\":
                # Toggle expand/collapse
                if selected.startswith("GROUP:"):
                    # Toggle single group
                    group_name = selected[6:]
                    if group_name in collapsed_groups:
                        collapsed_groups.remove(group_name)
                    else:
                        collapsed_groups.add(group_name)
                elif selected == "TOGGLE_ALL":
                    # Toggle all groups
                    all_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                    if collapsed_groups:
                        collapsed_groups = set()  # Expand all
                    else:
                        collapsed_groups = all_groups  # Collapse all
                elif selected in recipe_to_group:
                    # Toggle the group this recipe belongs to
                    group_name = recipe_to_group[selected]
                    if group_name in collapsed_groups:
                        collapsed_groups.remove(group_name)
                    else:
                        collapsed_groups.add(group_name)
                else:
                    # Toggle all groups - expand if any collapsed, collapse if all expanded
                    all_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                    if collapsed_groups:
                        collapsed_groups = set()  # Expand all
                    else:
                        collapsed_groups = all_groups  # Collapse all
                continue

            # Handle TOGGLE_ALL separator line selection (Enter)
            if selected == "TOGGLE_ALL":
                all_groups = _get_all_recipe_groups(filtered_recipes, current_group_by)
                if collapsed_groups:
                    collapsed_groups = set()  # Expand all
                else:
                    collapsed_groups = all_groups  # Collapse all
                continue

            # Handle group header selection (toggle collapse)
            if selected.startswith("GROUP:"):
                group_name = selected[6:]  # Remove "GROUP:" prefix
                if group_name in collapsed_groups:
                    collapsed_groups.remove(group_name)
                else:
                    collapsed_groups.add(group_name)
                continue

            if not selected or selected.startswith("---"):
                continue

            if key == "esc":
                break

            # Handle DEP: or RDEP: prefixed selections (dependency lines)
            if selected.startswith("DEP:") or selected.startswith("RDEP:"):
                # Format: DEP:path:depth or RDEP:path:depth
                parts = selected.split(":", 2)
                if len(parts) >= 2:
                    dep_path = parts[1]
                    # Remember selection for cursor positioning
                    last_selected = selected
                    # Toggle expansion of this dependency
                    if dep_path in expanded_deps:
                        del expanded_deps[dep_path]
                    else:
                        # Find the recipe for this dep - search all recipes, not just filtered
                        dep_recipe = None
                        for r in original_recipes:
                            if r.get("path") == dep_path:
                                dep_recipe = r
                                break
                        if dep_recipe and dep_recipe.get("path") and os.path.isfile(dep_recipe["path"]):
                            from .deps import _parse_recipe_depends
                            depends, rdepends = _parse_recipe_depends(dep_recipe["path"])
                            expanded_deps[dep_path] = (depends, rdepends)
                continue

            # Handle external dep selections (no expansion possible)
            if selected.startswith("DEP_EXT:") or selected.startswith("RDEP_EXT:"):
                continue

            # In grouped mode, Enter on a recipe toggles its group
            if current_group_by != "flat" and selected in recipe_to_group and not key:
                group_name = recipe_to_group[selected]
                if group_name in collapsed_groups:
                    collapsed_groups.remove(group_name)
                else:
                    collapsed_groups.add(group_name)
                continue

            # Find the selected recipe
            recipe = None
            for r in filtered_recipes:
                if r.get("path") == selected or r.get("pn") == selected:
                    recipe = r
                    break

            if not recipe:
                continue

            # Handle recipe actions
            if key == "alt-c":
                path = recipe.get("path", recipe.get("pn", ""))
                if path:
                    _copy_to_clipboard(path)
                    print(f"Copied: {path}")
                    input("Press Enter to continue...")
                continue

            if key == "ctrl-e" and not is_remote:
                # Edit in $EDITOR
                path = recipe.get("path", "")
                if path and os.path.isfile(path):
                    from .projects import resolve_editor
                    editor = resolve_editor()
                    subprocess.run([editor, path])
                continue

            if key == "ctrl-v":
                # View recipe in $PAGER
                path = recipe.get("path", "")
                if path and os.path.isfile(path):
                    pager = os.environ.get("PAGER", "less")
                    subprocess.run([pager, path])
                else:
                    preview = _build_recipe_preview(recipe)
                    pager = os.environ.get("PAGER", "less")
                    subprocess.run([pager], input=preview, text=True)
                continue

            # Enter in flat mode - toggle inline dependency expansion
            if current_group_by == "flat" and not key:
                path = recipe.get("path", "")
                if path:
                    # Remember selection for cursor positioning
                    last_selected = path
                    if path in expanded_deps:
                        # Collapse - remove from expanded
                        del expanded_deps[path]
                    else:
                        # Expand - fetch deps and add to expanded
                        if os.path.isfile(path):
                            from .deps import _parse_recipe_depends
                            depends, rdepends = _parse_recipe_depends(path)
                            expanded_deps[path] = (depends, rdepends)
                continue

            # Enter in grouped mode without key - handled above (toggle group)
            # Enter with explicit view request - use pager
            path = recipe.get("path", "")
            if path and os.path.isfile(path):
                pager = os.environ.get("PAGER", "less")
                subprocess.run([pager, path])
            else:
                preview = _build_recipe_preview(recipe)
                pager = os.environ.get("PAGER", "less")
                subprocess.run([pager], input=preview, text=True)

    except FileNotFoundError:
        return 1
    finally:
        # Clean up temp files
        for f in [preview_data_file.name, preview_script.name, preview_deps_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass

    return 0


def _copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard."""
    clipboard_cmds = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
        ["pbcopy"],
    ]

    for cmd in clipboard_cmds:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text, text=True, check=True)
                return True
            except subprocess.CalledProcessError:
                continue
    return False


# =============================================================================
# Source Selection Menu
# =============================================================================

def _source_selection_menu(has_local: bool = True) -> Optional[Tuple[str, str, List[str], List[str], str]]:
    """
    Show unified source selection menu with toggles and browse/search options.

    Returns:
    - Tuple of (action, query, sources, search_fields, sort_by) where:
      - action: "browse" or "search"
      - query: what was typed in the prompt
      - sources: list of enabled sources ["configured", "local", "index"]
      - search_fields: list of fields to search ["name", "summary", "description"]
      - sort_by: "name" or "layer"
    - None: Cancelled
    """
    if not fzf_available():
        # Text-based fallback
        print("\nRecipe Search:")
        if has_local:
            print("  Sources: configured layers, local layers")
            source = input("Enter search term (or empty to browse all): ").strip()
            if source:
                return ("search", source, ["configured", "local"], ["name"], "name")
            return ("browse", "", ["configured", "local"], ["name"], "name")
        else:
            print("  Source: layer index (no local project)")
            source = input("Enter search term (or empty to browse all): ").strip()
            if source:
                return ("search", source, ["index"], ["name"], "name")
            return ("browse", "", ["index"], ["name"], "name")

    # Build menu with toggles and actions
    menu_lines = []

    # Source toggles (selected by default based on has_local)
    if has_local:
        menu_lines.append("toggle:configured\t  [x] Configured      (layers in bblayers.conf)")
        menu_lines.append("toggle:local\t  [x] Local           (configured + discovered)")
    menu_lines.append("toggle:index\t  [ ] Layer index     (remote API)")

    # Separator and actions
    menu_lines.append("---\t  " + "─" * 45)
    menu_lines.append("browse\t  > Browse            (show all, type to filter)")
    menu_lines.append("search\t  > Search            (type query above, Enter to search)")

    menu_input = "\n".join(menu_lines)

    # Track toggle states - sources, search fields, and sort
    toggle_states = {
        "configured": has_local,
        "local": has_local,
        "index": not has_local,
        "name": True,        # Search recipe name (default on)
        "summary": False,    # Search SUMMARY field
        "description": False, # Search DESCRIPTION field
        "sort_by_layer": False,  # Sort by layer instead of name
    }

    # Create temp files for dynamic menu reload
    import tempfile

    state_file = tempfile.NamedTemporaryFile(mode='w', suffix='.state', delete=False)
    menu_script = tempfile.NamedTemporaryFile(mode='w', suffix='.sh', delete=False)

    # Write initial state
    json.dump(toggle_states, state_file)
    state_file.close()

    # Write menu generation script
    # Order: first items appear at bottom (near prompt) in default fzf layout
    menu_script.write(f'''#!/bin/bash
state=$(cat "{state_file.name}")
configured=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('configured') else '[ ]')")
local=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('local') else '[ ]')")
index=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('index') else '[ ]')")
name=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('name') else '[ ]')")
summary=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('summary') else '[ ]')")
description=$(echo "$state" | python3 -c "import sys,json; print('[x]' if json.load(sys.stdin).get('description') else '[ ]')")
sort_layer=$(echo "$state" | python3 -c "import sys,json; d=json.load(sys.stdin); print('layer' if d.get('sort_by_layer') else 'name')")
# Actions first (at bottom, near prompt)
echo "search	  > Search            (type query below, Enter)"
echo "browse	  > Browse            (show all, filter in browser)"
echo "---	  ── Actions ─────────────────────────────────"
# Sort option
echo "toggle:sort_by_layer	  Sort: $sort_layer"
echo "---	  ── Options ─────────────────────────────────"
# Source toggles (middle section)
echo "toggle:index	  $index Index   (remote API)"
''')
    if has_local:
        menu_script.write('''echo "toggle:local	  $local Local   (configured + discovered)"
echo "toggle:configured	  $configured Config (layers in bblayers.conf)"
''')
    menu_script.write('''echo "---	  ── Sources ─────────────────────────────────"
# Search field toggles (at top)
echo "toggle:description	  $description Description"
echo "toggle:summary	  $summary Summary"
echo "toggle:name	  $name Name"
echo "---	  ── Search In ───────────────────────────────"
''')
    menu_script.close()
    os.chmod(menu_script.name, 0o755)

    # Write toggle script
    toggle_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    toggle_script.write(f'''#!/usr/bin/env python3
import sys, json
key = sys.argv[1] if len(sys.argv) > 1 else ""
if key.startswith("toggle:"):
    source = key.replace("toggle:", "")
    with open("{state_file.name}", "r") as f:
        state = json.load(f)
    state[source] = not state.get(source, False)
    with open("{state_file.name}", "w") as f:
        json.dump(state, f)
''')
    toggle_script.close()
    os.chmod(toggle_script.name, 0o755)

    try:
        # Generate initial menu
        initial_menu = subprocess.check_output(["bash", menu_script.name], text=True)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--disabled",  # Disable filtering - query is just captured, not used to filter
            "--height", "~20",
            "--header", "Space=toggle | Enter=select | Type query for Search | Esc=quit",
            "--prompt", "Query: ",
            "--print-query",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--bind", f"space:execute-silent(python3 {toggle_script.name} {{1}})+reload(bash {menu_script.name})",
            "--bind", "esc:abort",
        ]
        fzf_args.extend(get_fzf_color_args())

        result = subprocess.run(
            fzf_args,
            input=initial_menu,
            stdout=subprocess.PIPE,
            text=True,
        )

        if result.returncode != 0:
            return None

        # Read final toggle state
        with open(state_file.name, "r") as f:
            toggle_states = json.load(f)

        # Parse output: query on first line, selection on second
        lines = result.stdout.split("\n")
        query = lines[0].strip() if len(lines) > 0 else ""
        selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

        # Handle separator - user somehow selected it, ignore
        if selected == "---" or selected.startswith("toggle:"):
            return None

        # Handle browse/search actions
        sort_by = "layer" if toggle_states.get("sort_by_layer") else "name"
        if selected == "browse":
            sources = [s for s, enabled in toggle_states.items() if enabled and s in ("configured", "local", "index")]
            search_fields = [s for s, enabled in toggle_states.items() if enabled and s in ("name", "summary", "description")]
            if not sources:
                print("No sources selected. Enable at least one source.")
                return None
            return ("browse", query, sources, search_fields or ["name"], sort_by)
        elif selected == "search":
            sources = [s for s, enabled in toggle_states.items() if enabled and s in ("configured", "local", "index")]
            search_fields = [s for s, enabled in toggle_states.items() if enabled and s in ("name", "summary", "description")]
            if not sources:
                print("No sources selected. Enable at least one source.")
                return None
            if not query:
                print("No query entered. Type a search term first.")
                return None
            return ("search", query, sources, search_fields or ["name"], sort_by)

        return None

    finally:
        # Clean up temp files
        for f in [state_file.name, menu_script.name, toggle_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass


# =============================================================================
# Main Entry Point
# =============================================================================

def run_recipe(args) -> int:
    """
    Main entry point for recipe command.

    Args:
        args: Parsed command line arguments with:
            - query: Optional search query
            - browse: Browse all local recipes
            - configured: Search configured layers only
            - local: Search all local layers
            - index: Search layer index API
            - layer: Filter to specific layer
            - section: Filter by SECTION
            - list: Text output (no fzf)
            - force: Rebuild cache
            - branch: Branch for layer index (default: master)
    """
    query = getattr(args, "query", None) or ""
    browse_mode = getattr(args, "browse", False)
    configured_mode = getattr(args, "configured", False)
    local_mode = getattr(args, "local", False)
    index_mode = getattr(args, "index", False)
    layer_filter = getattr(args, "layer", None)
    section_filter = getattr(args, "section", None)
    list_mode = getattr(args, "list", False)
    force = getattr(args, "force", False)
    branch = getattr(args, "branch", "master")
    bblayers = getattr(args, "bblayers", None)

    # Load defaults for configuration options
    defaults_file = getattr(args, "defaults_file", ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # Configuration: use bitbake-layers for configured recipes (default: True)
    # Configurable via 'bit config' -> Settings -> Recipe Scan
    use_bitbake_layers = get_recipe_use_bitbake_layers()

    # Search field options from CLI
    search_name = getattr(args, "name", False)
    search_summary = getattr(args, "summary", False)
    search_description = getattr(args, "description", False)

    # Sort option from CLI
    sort_by = getattr(args, "sort", None) or "name"  # default: sort by name

    # Check if we have a local project context
    bblayers_path = resolve_bblayers_path(bblayers)
    has_local = bblayers_path is not None

    # Determine mode from CLI flags or show unified menu
    action = "browse"  # default
    sources = []
    search_fields = ["name"]  # default: search name only

    # Build search_fields from CLI options (if any specified)
    if search_name or search_summary or search_description:
        search_fields = []
        if search_name:
            search_fields.append("name")
        if search_summary:
            search_fields.append("summary")
        if search_description:
            search_fields.append("description")

    # Determine grouping mode from CLI
    group_by = getattr(args, "group", None) or "flat"

    # Determine sources - go directly to browse (no source selection menu)
    if browse_mode:
        action = "browse"
        sources = ["configured", "local"] if has_local else ["index"]
    elif configured_mode:
        # If query provided, use search action to pre-filter
        action = "search" if query else "browse"
        sources = ["configured"]
    elif local_mode:
        action = "search" if query else "browse"
        sources = ["local"]
    elif index_mode:
        action = "search" if query else "browse"
        sources = ["index"]
    elif not has_local:
        # No local context - auto-select index
        action = "browse"
        sources = ["index"]
        print(Colors.dim("No local project found, using layer index."))
    else:
        # Default: go directly to browse with local sources
        action = "browse"
        sources = ["configured", "local"]

    # Fetch recipes from all enabled sources
    all_recipes = []
    source_names = []
    is_remote = False

    # Helper to detect if query looks like a regex pattern
    def looks_like_regex(q: str) -> bool:
        regex_chars = set('^$.*+?[](){}|\\')
        return any(c in regex_chars for c in q)

    def fetch_from_source(src: str) -> List[dict]:
        nonlocal is_remote
        if src == "index":
            is_remote = True
            # Pass query for server-side search (only for search action)
            api_search = query if action == "search" else ""
            # Warn if query looks like regex (index API doesn't support regex)
            if api_search and looks_like_regex(api_search):
                print(Colors.yellow(f"Warning: Index API doesn't support regex. '{api_search}' will be treated as literal text."))
            return _fetch_recipe_index(branch, force, search=api_search) or []
        elif src == "local":
            if has_local:
                pairs, _ = resolve_base_and_layers(bblayers_path, defaults, discover_all=True)
                layer_paths = dedupe_preserve_order(layer for layer, _ in pairs)
                return _scan_recipes_from_layers(layer_paths, force=force)
            return []
        elif src == "configured":
            if has_local:
                recipes, _ = _scan_configured_recipes(bblayers_path, force=force, use_bitbake_layers=use_bitbake_layers)
                return recipes
            return []
        return []

    for src in sources:
        recipes = fetch_from_source(src)
        all_recipes.extend(recipes)
        source_names.append(src.capitalize())

    # Dedupe by (pn, layer_name)
    seen = set()
    unique_recipes = []
    for r in all_recipes:
        key = (r.get("pn", ""), r.get("layer_name", ""))
        if key not in seen:
            seen.add(key)
            unique_recipes.append(r)
    recipes = unique_recipes

    source_name = "+".join(source_names) if source_names else "Local"

    # Apply filters
    if layer_filter:
        layer_filter_lower = {f.lower() for f in layer_filter}
        recipes = [r for r in recipes if r.get("layer_name", "").lower() in layer_filter_lower]

    if section_filter:
        recipes = [r for r in recipes if section_filter.lower() in r.get("SECTION", "").lower()]

    # Helper to check if recipe matches query based on search_fields (supports regex)
    def recipe_matches(r: dict, q: str) -> bool:
        try:
            pattern = re.compile(q, re.IGNORECASE)
        except re.error:
            # Fall back to literal match if invalid regex
            q_lower = q.lower()
            if "name" in search_fields and q_lower in r.get("pn", "").lower():
                return True
            if "summary" in search_fields and q_lower in r.get("SUMMARY", "").lower():
                return True
            if "description" in search_fields and q_lower in r.get("DESCRIPTION", "").lower():
                return True
            return False

        if "name" in search_fields and pattern.search(r.get("pn", "")):
            return True
        if "summary" in search_fields and pattern.search(r.get("SUMMARY", "")):
            return True
        if "description" in search_fields and pattern.search(r.get("DESCRIPTION", "")):
            return True
        return False

    # For "search" action, filter by query before showing
    if action == "search" and query:
        pre_filter_count = len(recipes)
        recipes = [r for r in recipes if recipe_matches(r, query)]
        fields_str = "+".join(search_fields)
        print(f"Search '{query}' in [{fields_str}]: {len(recipes)} matches (from {pre_filter_count} recipes)")
        initial_query = ""  # Don't re-filter in browser
    elif list_mode and query:
        # For --list mode, also filter
        recipes = [r for r in recipes if recipe_matches(r, query)]
        initial_query = ""
    else:
        initial_query = query

    # Sort recipes
    if sort_by == "layer":
        # Sort by layer name, then by recipe name within each layer
        recipes = sorted(recipes, key=lambda r: (r.get("layer_name", "").lower(), r.get("pn", "").lower()))
    else:
        # Sort by recipe name A-Z (default)
        recipes = sorted(recipes, key=lambda r: r.get("pn", "").lower())

    # Output
    if list_mode:
        # Text output
        if not recipes:
            print("No recipes found.")
            return 1

        for recipe in recipes:
            pn = recipe.get("pn", "")
            pv = recipe.get("pv", "")
            layer_name = recipe.get("layer_name", "")
            path = recipe.get("path", "")
            print(f"{pn:<30}  {pv:<15}  {layer_name:<20}  {path}")
        return 0

    # Determine available sources for cycling
    available_sources = []
    if has_local:
        available_sources.extend(["configured", "local"])
    available_sources.append("index")

    # FZF browser with source cycling
    current_source_name = source_name
    current_recipes = recipes
    current_is_remote = is_remote

    while True:
        browser_result = _recipe_fzf_browser(
            current_recipes,
            current_source_name,
            query=initial_query,
            allow_source_switch=has_local,
            is_remote=current_is_remote,
            available_sources=available_sources,
            group_by=group_by,
        )

        # Check if user wants to switch source inline
        if isinstance(browser_result, tuple) and browser_result[0] == "switch":
            next_source = browser_result[1]
            print(f"Switching to {next_source.capitalize()}...")

            # Fetch from the new source
            current_is_remote = (next_source == "index")
            current_recipes = fetch_from_source(next_source)

            # Apply filters
            if layer_filter:
                layer_filter_lower = {f.lower() for f in layer_filter}
                current_recipes = [r for r in current_recipes if r.get("layer_name", "").lower() in layer_filter_lower]
            if section_filter:
                current_recipes = [r for r in current_recipes if section_filter.lower() in r.get("SECTION", "").lower()]

            # Sort
            if sort_by == "layer":
                current_recipes = sorted(current_recipes, key=lambda r: (r.get("layer_name", "").lower(), r.get("pn", "").lower()))
            else:
                current_recipes = sorted(current_recipes, key=lambda r: r.get("pn", "").lower())

            current_source_name = next_source.capitalize()
            continue  # Re-show browser with new source

        # Normal exit
        return browser_result if isinstance(browser_result, int) else 0
