#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Repos command - list layer repositories."""

import os
import subprocess
import sys
from typing import List, Optional, Tuple

from ..core import Colors, current_branch, load_defaults, repo_is_clean, terminal_color
from .common import (
    resolve_base_and_layers,
    repo_display_name,
    get_upstream_count_ls_remote,
)

from .update import fetch_repo, get_upstream_commits

def run_repos(args) -> int:
    """List repos, optionally with one-liner status."""
    defaults = load_defaults(args.defaults_file)
    pairs, repo_sets = resolve_base_and_layers(args.bblayers, defaults)

    repo_layers: Dict[str, List[str]] = {}
    for layer, repo in pairs:
        repo_layers.setdefault(repo, []).append(layer)

    show_status = args.repos_command == "status"
    do_fetch = show_status and getattr(args, "fetch", False)

    # Optionally fetch first
    if do_fetch:
        print("Fetching from origin...")
        for repo in repo_layers.keys():
            if defaults.get(repo, "rebase") != "skip":
                fetch_repo(repo)

    for repo in repo_layers.keys():
        is_discovered = repo in repo_sets.discovered
        discovered_marker = " (?)" if is_discovered else ""

        if not show_status:
            # Simple list mode
            print(f"{repo}{discovered_marker}")
            continue

        # Status mode: one-liner per repo
        default_action = defaults.get(repo, "rebase")
        if default_action == "skip":
            print(f"→ {repo}{discovered_marker}: default=skip")
            continue

        branch = current_branch(repo)
        if not branch:
            is_clean = repo_is_clean(repo)
            worktree_status = Colors.green("[clean]") if is_clean else Colors.red("[DIRTY]")
            print(f"→ {repo}{discovered_marker}: detached HEAD {worktree_status}")
            continue

        remote_ref = f"origin/{branch}"
        remote_exists = (
            subprocess.run(
                ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode
            == 0
        )

        # Get commit counts
        local_count = 0
        upstream_count = 0
        upstream_unknown = False

        if remote_exists:
            # Local commits (always use local refs)
            try:
                out = subprocess.check_output(
                    ["git", "-C", repo, "rev-list", "--count", f"{remote_ref}..HEAD"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                )
                local_count = int(out.strip())
            except (subprocess.CalledProcessError, ValueError):
                pass

            # Upstream commits - use ls-remote unless we just fetched
            if do_fetch:
                try:
                    out = subprocess.check_output(
                        ["git", "-C", repo, "rev-list", "--count", f"HEAD..{remote_ref}"],
                        text=True,
                        stderr=subprocess.DEVNULL,
                    )
                    upstream_count = int(out.strip())
                except (subprocess.CalledProcessError, ValueError):
                    pass
            else:
                result = get_upstream_count_ls_remote(repo, branch)
                if result is None:
                    pass  # No remote tracking
                elif result == -1:
                    upstream_unknown = True  # Has changes but can't count
                else:
                    upstream_count = result

        is_clean = repo_is_clean(repo)

        # Build status parts
        status_parts = []
        if local_count:
            status_parts.append(f"{local_count} local commit(s)")
        if upstream_unknown:
            status_parts.append(terminal_color("upstream", "upstream has changes"))
        elif upstream_count:
            status_parts.append(terminal_color("upstream", f"{upstream_count} to pull"))
        if not status_parts:
            status_parts.append("up-to-date")

        # Format with colors
        if is_clean:
            if is_discovered:
                repo_display = terminal_color("repo_discovered", f"{repo}{discovered_marker}")
                worktree_status = terminal_color("clean", "[clean]")
            else:
                repo_display = terminal_color("repo", f"{repo}{discovered_marker}")
                worktree_status = terminal_color("clean", "[clean]")
        else:
            repo_display = f"{repo}{discovered_marker}"
            worktree_status = terminal_color("dirty", "[DIRTY]")

        branch_display = Colors.bold(branch)
        print(f"→ {repo_display}: {', '.join(status_parts)} on {branch_display} {worktree_status}")

    return 0


def diffstat_for_range(repo: str, range_spec: str) -> str:
    try:
        if range_spec == "--root":
            empty = subprocess.check_output(
                ["git", "-C", repo, "hash-object", "-t", "tree", "/dev/null"], text=True
            ).strip()
            return subprocess.check_output(
                ["git", "-C", repo, "diff", "--stat", f"{empty}..HEAD"], text=True
            ).strip()
        return subprocess.check_output(["git", "-C", repo, "diff", "--stat", range_spec], text=True).strip()
    except subprocess.CalledProcessError:
        return ""


