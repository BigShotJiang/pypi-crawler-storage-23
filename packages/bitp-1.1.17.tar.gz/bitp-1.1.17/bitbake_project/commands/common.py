#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Shared utilities for bit commands.

This module contains all run_* functions and their supporting utilities.
"""

import json
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid
from dataclasses import dataclass
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Set, Tuple

from ..core import (
    Colors,
    GitRepo,
    FzfMenu,
    fzf_available,
    fzf_expandable_menu,
    activate_custom_command,
    delete_custom_command,
    get_active_custom_name,
    get_custom_command,
    get_custom_commands,
    get_fzf_color_args,
    get_saved_custom_command,
    is_custom_default,
    save_custom_command,
    parse_help_options,
    git_toplevel,
    current_branch,
    current_head,
    repo_is_clean,
    load_defaults,
    save_defaults,
    load_prep_state,
    save_prep_state,
    load_export_state,
    save_export_state,
    terminal_color,
    get_terminal_color,
    ANSI_COLORS,
)
from ..tui import ExploreMenuState, text_input_dialog
from ..fzf_bindings import get_action_binding, get_exit_bindings, get_preview_header_suffix, get_toggle_binding

# ---------------------------------------------------------------------------
# Backward-compatible re-exports from personas/yocto/
# ---------------------------------------------------------------------------
# These symbols were moved to their canonical home in the yocto persona
# modules but are re-exported here so existing ``from .common import X``
# statements continue to work unchanged.

from ..personas.yocto.bblayers import (       # noqa: F401 — re-export
    BblayersParser,
    extract_layer_paths,
    resolve_bblayers_path,
)
from ..personas.yocto.layers import (         # noqa: F401 — re-export
    RepoSets,
    LayerInfo,
    discover_layers,
    discover_git_repos,
    build_layer_collection_map,
    add_layer_to_bblayers,
    remove_layer_from_bblayers,
    parse_layer_conf,
    resolve_base_and_layers,
    collect_repos,
    commit_to_layer,
    layer_display_name,
    group_commits_by_layer,
    get_upstream_layer_counts,
)


# ---------------------------------------------------------------------------
# Session message store
# ---------------------------------------------------------------------------
# Captures status messages (e.g. "✓ Activated: poky") so they can be shown
# in the fzf header for one redraw cycle and reviewed later via M key.

_messages: List[Tuple[float, str]] = []   # (timestamp, text)
_pending_message: str = ""                # consumed once per header render


def log_message(text: str):
    """Store *text* for header display and later review."""
    global _pending_message
    _messages.append((time.time(), text))
    _pending_message = text


def consume_header_message() -> str:
    """Return pending message (once), then clear it."""
    global _pending_message
    msg = _pending_message
    _pending_message = ""
    return msg


def get_messages() -> List[Tuple[float, str]]:
    """Return all stored messages."""
    return list(_messages)


def clear_messages():
    """Clear message history."""
    global _pending_message
    _messages.clear()
    _pending_message = ""


def fzf_message_viewer():
    """Show message log in a read-only fzf browser."""
    messages = get_messages()
    if not messages:
        subprocess.run(
            ["fzf", "--ansi", "--no-sort", "--layout=reverse",
             "--height=~30%", "--border=rounded",
             "--header", "No messages yet | q=close",
             "--disabled",
             *get_exit_bindings(mode="abort")],
            input="", text=True,
        )
        return
    lines = []
    for ts, text in messages:
        t = time.strftime("%H:%M:%S", time.localtime(ts))
        clean = text.replace("\n", " ").strip()
        lines.append(f"{Colors.dim(t)}  {clean}")
    lines.reverse()  # newest first
    subprocess.run(
        ["fzf", "--ansi", "--no-sort", "--layout=reverse",
         "--height=~50%", "--border=rounded",
         "--header", "Messages (newest first) | q=close",
         "--disabled",
         *get_exit_bindings(mode="abort")],
        input="\n".join(lines), text=True,
    )

def dedupe_preserve_order(items: Iterable[str]) -> List[str]:
    seen: Set[str] = set()
    out: List[str] = []
    for item in items:
        if item in seen:
            continue
        seen.add(item)
        out.append(item)
    return out


def run_cmd(repo: str, args, dry_run: bool, *, shell: bool = False) -> None:
    if dry_run:
        cmd = args if shell else " ".join(shlex.quote(str(a)) for a in args)
        print(f"[dry-run] (cd {shlex.quote(repo)} && {cmd})")
        return
    subprocess.run(args, check=True, cwd=repo, shell=shell)


def get_upstream_count_ls_remote(repo: str, branch: str, timeout: int = 5) -> Optional[int]:
    """Get upstream commit count using ls-remote (no local modification).

    Returns:
        None: no remote tracking, timeout, or error
        -1: remote has changes but can't count (not fetched)
        0+: exact count of commits to pull
    """
    # Suppress all interactive prompts — this may run in a background thread
    # while fzf owns the terminal.
    env = os.environ.copy()
    env["GIT_TERMINAL_PROMPT"] = "0"
    env["SSH_ASKPASS_REQUIRE"] = "never"
    env.pop("SSH_ASKPASS", None)
    env["GIT_SSH_COMMAND"] = "ssh -o BatchMode=yes"

    try:
        # Get remote SHA via ls-remote (with timeout to avoid hanging)
        out = subprocess.check_output(
            ["git", "-C", repo, "ls-remote", "origin", branch],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=timeout,
            env=env,
        )
        if not out.strip():
            return None
        remote_sha = out.split()[0]

        # Check if we have this commit locally
        exists = subprocess.run(
            ["git", "-C", repo, "cat-file", "-e", remote_sha],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0

        if not exists:
            # Remote has commits we don't have locally - can't count without fetch
            return -1  # Signal "unknown but has changes"

        # Count commits between HEAD and remote
        out = subprocess.check_output(
            ["git", "-C", repo, "rev-list", "--count", f"HEAD..{remote_sha}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return int(out.strip())
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, ValueError):
        return None


def fzf_custom_command_picker(repo: str, defaults: dict, mode: str = "activate") -> Optional[Tuple[str, ...]]:
    """Show fzf picker for named custom commands.

    *mode* is ``"activate"`` (set default) or ``"run"`` (execute now).

    Returns:
    - ``("activate", name)`` — user picked a command to activate as default
    - ``("add", name, cmd)`` — user added a new command
    - ``("run", name, cmd)`` — user picked a command to run now
    - ``None`` — cancelled
    """
    display_name = repo_display_name(repo)
    confirm_delete = None  # name pending confirmation

    while True:
        commands = get_custom_commands(defaults, repo)
        active_name = get_active_custom_name(defaults, repo)

        if confirm_delete:
            # Inline confirmation — framed dialog
            menu_lines = build_confirm_delete_lines(
                confirm_delete, reverse_list=False,
            )
            header = "Esc=cancel"
            fzf_extra = []
        else:
            menu_lines = []
            for name, cmd in commands.items():
                marker = "●" if name == active_name else "○"
                menu_lines.append(f"{name}\t{marker} {name:<18} {cmd}")
            menu_lines.append("──────────────────")
            menu_lines.append("__ADD__\t  Add new command...")
            header = f"Custom commands for {display_name}  x=delete | Enter=select | Esc=back"
            fzf_extra = get_action_binding("x", "DELETE {1}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~12",
                    "--header", header,
                    "--prompt", "Command: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + fzf_extra + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None

        if result.returncode != 0 or not result.stdout.strip():
            if confirm_delete:
                confirm_delete = None
                continue
            return None

        output = result.stdout.strip()

        # Handle confirmation result
        if confirm_delete:
            selected = output.split("\t")[0]
            if selected == "yes":
                delete_custom_command(defaults, repo, name=confirm_delete)
            confirm_delete = None
            continue

        # Handle delete keybinding
        if output.startswith("DELETE "):
            del_name = output[len("DELETE "):].strip()
            if del_name and del_name != "__ADD__" and del_name in commands:
                confirm_delete = del_name
            continue

        selected = output.split("\t")[0]

        if selected == "__ADD__":
            # Two-step add dialog: name, then command
            add_result = _fzf_add_custom_command(display_name)
            if add_result is None:
                continue
            new_name, new_cmd = add_result
            save_custom_command(defaults, repo, new_cmd, name=new_name)
            if mode == "run":
                return ("run", new_name, new_cmd)
            return ("add", new_name, new_cmd)

        if selected in commands:
            if mode == "run":
                return ("run", selected, commands[selected])
            return ("activate", selected)

    return None


def _fzf_add_custom_command(display_name: str) -> Optional[Tuple[str, str]]:
    """Two-step fzf dialog to add a named custom command.

    Returns ``(name, cmd)`` or ``None`` if cancelled.
    """
    # Step 1: Name
    try:
        name_result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--height", "~4",
                "--header", f"Name for custom command ({display_name})  Esc=cancel",
                "--prompt", "Name: ",
                "--disabled",
                "--print-query",
            ] + get_fzf_color_args(),
            input="",
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None
    if name_result.returncode != 0:
        return None
    lines = name_result.stdout.strip().split("\n")
    name = lines[0].strip() if lines else ""
    if not name or ":" in name or name == "__active__":
        return None

    # Step 2: Command
    try:
        cmd_result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--height", "~4",
                "--header", f"Command for '{name}' ({display_name})  Esc=cancel",
                "--prompt", "Command: ",
                "--disabled",
                "--print-query",
            ] + get_fzf_color_args(),
            input="",
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None
    if cmd_result.returncode != 0:
        return None
    lines = cmd_result.stdout.strip().split("\n")
    cmd = lines[0].strip() if lines else ""
    if not cmd:
        return None

    return (name, cmd)


def fzf_prompt_action(repo: str, branch: str, default_action: str, upstream_info: Optional[str] = None, saved_default: Optional[str] = None, defaults: Optional[dict] = None) -> Optional[Tuple[str, str, Optional[str]]]:
    """Use fzf to prompt for update action."""
    display_name = repo_display_name(repo)
    dialog_state = ExploreMenuState()
    if defaults is None:
        defaults = {}

    # Build menu options
    from .branch import get_upstream_ref
    upstream = get_upstream_ref(repo, branch) or f"origin/{branch}"
    saved_cmd = get_saved_custom_command(defaults, repo)
    active_name = get_active_custom_name(defaults, repo)
    all_commands = get_custom_commands(defaults, repo)
    num_commands = len(all_commands)
    if is_custom_default(default_action):
        cmd = saved_cmd or (get_custom_command(default_action) if default_action.startswith("custom:") else None)
        if cmd and active_name and active_name != "default":
            default_label = f"custom ({active_name})"
        elif cmd:
            default_label = f"custom ({cmd})"
        else:
            default_label = "custom (no command saved)"
    else:
        default_label = {"rebase": "pull --rebase", "merge": "pull (merge)", "skip": "skip"}.get(default_action, default_action)
    # When up-to-date auto-skip overrides the saved default, show both
    if saved_default and saved_default != default_action and default_action == "skip":
        saved_label = f"custom ({get_custom_command(saved_default)})" if is_custom_default(saved_default) else saved_default
        default_label += f" (up-to-date, default: {saved_label})"

    has_saved_custom = saved_cmd is not None
    custom_active = is_custom_default(default_action)

    def _build_base_menu():
        lines = [
            f"►► Use default: {default_label}",
            f"   Pull --rebase {upstream}",
            f"   Pull (merge) {upstream}",
        ]
        # Custom command... — opens picker if commands exist, else text input
        if num_commands > 0:
            lines.append(f"   Custom command... ({num_commands} saved)")
        else:
            lines.append("   Custom command...")
        lines.extend([
            "── Set default ──",
            "   Set default: rebase",
            "   Set default: merge",
            "   Set default: skip",
        ])
        # Set default: custom — show active name or count
        if has_saved_custom and not custom_active:
            if active_name and active_name != "default":
                lines.append(f"   Set default: custom ({active_name})")
            else:
                lines.append(f"   Set default: custom ({saved_cmd})")
        elif num_commands > 1:
            lines.append(f"   Set default: custom... ({num_commands} saved)")
        else:
            lines.append("   Set default: custom...")
        lines.extend([
            "──────────────────",
            "   Skip this repo (s)",
            "   Quit (q)",
        ])
        return lines

    base_menu_lines = _build_base_menu()

    # Build header with repo name prominent at top
    header = f"{Colors.BOLD}{Colors.GREEN}→ {display_name}{Colors.RESET}\n"
    tracking_info = ""
    if not upstream.startswith("origin/"):
        tracking_info = f"  tracking: {upstream}"
    display_default = saved_default if saved_default else default_action
    header += f"  branch: {Colors.BOLD}{branch}{Colors.RESET}{tracking_info}  default: {display_default}"
    if upstream_info:
        upstream_color = ANSI_COLORS.get(get_terminal_color("upstream"), Colors.YELLOW)
        header += f"  {upstream_color}{upstream_info}{Colors.RESET}"

    setting_custom_default = False  # flag: dialog is for "Set default: custom"

    while True:
        has_dialog = dialog_state.has_dialog()

        # Build menu lines with dialog items prepended if active
        if has_dialog:
            dialog_items = dialog_state.get_dialog_menu_lines()
            menu_lines = [f"{item[0]}\t{item[1]}" for item in dialog_items] + base_menu_lines
            header_text = header + "\n  Type command in query, Enter=confirm | Esc=cancel"
        else:
            menu_lines = base_menu_lines
            header_text = header + "\n  Enter=select | s=skip | q=quit"

        # Build fzf command - conditional bindings based on dialog state
        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--no-info",
            "--ansi",
            "--height", "~18",
            "--header", header_text,
            "--prompt", "Command: " if has_dialog else "Action: ",
        ]

        if has_dialog:
            fzf_cmd.extend(["--disabled", "--print-query", "--bind", "esc:abort"])
        else:
            fzf_cmd.extend(
                get_action_binding("s", "SKIP") +
                get_action_binding("q", "QUIT")
            )

        fzf_cmd.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_cmd,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None  # fzf not available

        # Parse output based on dialog state
        if has_dialog:
            lines = result.stdout.strip().split("\n") if result.stdout else []
            query = lines[0] if lines else ""
            selected = lines[1] if len(lines) > 1 else ""
        else:
            query = ""
            selected = result.stdout.strip() if result.stdout else ""

        # Handle interrupt (Esc)
        if result.returncode != 0:
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            print(f"Skipping {repo}.")
            return ("skip", branch, None)

        # Handle dialog selection — extract value from tab-delimited line
        selected_value = selected.split("\t")[0] if has_dialog else selected
        if has_dialog and dialog_state._renderer.is_dialog_item(selected_value):
            dlg_result = dialog_state.handle_dialog_selection(selected_value, query)
            if dlg_result.confirmed and dlg_result.value:
                custom_cmd = dlg_result.value.strip()
                dialog_state.clear_dialog()
                if custom_cmd:
                    if setting_custom_default:
                        setting_custom_default = False
                        print(f"Setting default for {repo} to custom: {custom_cmd}")
                        return ("custom", custom_cmd, f"custom:{custom_cmd}")
                    return ("custom", custom_cmd, None)
                print(f"No command provided, skipping {repo}.")
                setting_custom_default = False
                return ("skip", branch, None)
            dialog_state.clear_dialog()
            setting_custom_default = False
            continue

        if selected == "SKIP" or "Skip this repo" in selected:
            print(f"Skipping {repo}.")
            return ("skip", branch, None)

        if selected == "QUIT" or "Quit" in selected:
            return ("quit", branch, None)

        if "Use default" in selected:
            if is_custom_default(default_action):
                cmd = get_saved_custom_command(defaults, repo)
                if not cmd and default_action.startswith("custom:"):
                    cmd = get_custom_command(default_action)
                if cmd:
                    return ("custom", cmd, None)
                return ("skip", branch, None)
            return (default_action, branch, None)

        if "Pull --rebase" in selected:
            return ("rebase", branch, None)

        if "Pull (merge)" in selected:
            return ("merge", branch, None)

        if "Custom command" in selected and "Delete" not in selected:
            commands = get_custom_commands(defaults, repo)
            if commands:
                picker_result = fzf_custom_command_picker(repo, defaults, mode="run")
                if picker_result is not None:
                    if picker_result[0] == "run":
                        return ("custom", picker_result[2], None)
                    elif picker_result[0] == "add":
                        return ("custom", picker_result[2], None)
                # Picker cancelled — rebuild menu in case commands changed
                base_menu_lines = _build_base_menu()
                continue
            # No commands saved — fall back to text input dialog
            dialog_state.show_dialog(text_input_dialog("Enter command:"))
            continue

        if "Set default: rebase" in selected:
            print(f"Setting default for {repo} to rebase.")
            return ("rebase", branch, "rebase")

        if "Set default: merge" in selected:
            print(f"Setting default for {repo} to merge.")
            return ("merge", branch, "merge")

        if "Set default: skip" in selected:
            print(f"Setting default for {repo} to skip.")
            return ("skip", branch, "skip")

        if "Set default: custom" in selected:
            commands = get_custom_commands(defaults, repo)
            if commands:
                picker_result = fzf_custom_command_picker(repo, defaults, mode="activate")
                if picker_result is not None:
                    if picker_result[0] == "activate":
                        activate_custom_command(defaults, repo, picker_result[1])
                        cmd = get_saved_custom_command(defaults, repo)
                        print(f"Setting default for {repo} to custom: {picker_result[1]}")
                        return ("custom", cmd, f"custom:{picker_result[1]}:{cmd}")
                    elif picker_result[0] == "add":
                        cmd = picker_result[2]
                        print(f"Setting default for {repo} to custom: {picker_result[1]}")
                        return ("custom", cmd, f"custom:{picker_result[1]}:{cmd}")
                # Picker cancelled — rebuild menu
                base_menu_lines = _build_base_menu()
                continue
            # No commands — open name+command dialog
            setting_custom_default = True
            dialog_state.show_dialog(text_input_dialog("Set custom default:"))
            continue

        return ("skip", branch, None)


def prompt_action(repo: str, branch: Optional[str], default_action: str, defaults: Optional[dict] = None, use_fzf: bool = True) -> Optional[Tuple[str, str, Optional[str]]]:
    if not branch:
        print(f"Skipping {repo} (detached HEAD or no branch).")
        return None
    if defaults is None:
        defaults = {}

    # Get upstream status
    upstream_info = ""
    upstream_count = get_upstream_count_ls_remote(repo, branch)
    if upstream_count is not None:
        if upstream_count == -1:
            upstream_info = "↓ upstream has changes"
        elif upstream_count > 0:
            upstream_info = f"↓ {upstream_count} to pull"
        elif upstream_count == 0:
            upstream_info = "up-to-date"

    # If up-to-date, default to skip (but don't change saved default)
    effective_default = default_action
    if upstream_count == 0:
        effective_default = "skip"

    # Try fzf first (unless disabled)
    if use_fzf and fzf_available():
        saved = default_action if effective_default != default_action else None
        result = fzf_prompt_action(repo, branch, effective_default, upstream_info or None, saved_default=saved, defaults=defaults)
        if result is not None:
            return result

    # Fall back to text-based prompt
    print(f"\n╭─ {repo}")
    print(f"│   branch: {branch}")
    upstream_line = f"  ({upstream_info})" if upstream_info else ""
    if is_custom_default(effective_default):
        cmd = get_saved_custom_command(defaults, repo)
        if not cmd and effective_default.startswith("custom:"):
            cmd = get_custom_command(effective_default)
        default_display = f"custom ({cmd})" if cmd else "custom (no command saved)"
    else:
        default_display = effective_default
    if effective_default != default_action:
        default_display = f"{effective_default} (up-to-date, default: {default_action})"
    print(f"│   Default: {default_display}{upstream_line}")
    print("│   Actions: [Enter] default | r [br] pull --rebase | m [br] pull | c <cmd> custom | d <skip|rebase|merge|custom name:cmd|delete-custom [name]> set default | s skip | q quit")
    choice = input("╰─ choice: ").strip()

    if not choice:
        if is_custom_default(effective_default):
            cmd = get_saved_custom_command(defaults, repo)
            if not cmd and effective_default.startswith("custom:"):
                cmd = get_custom_command(effective_default)
            if cmd:
                return ("custom", cmd, None)
            return ("skip", branch, None)
        return (effective_default, branch, None)

    if choice.lower() in {"s", "n"}:
        print(f"Skipping {repo}.")
        return ("skip", branch, None)

    if choice.lower() == "q":
        return ("quit", branch, None)

    if choice.lower() == "d delete-custom":
        print(f"Deleted all custom commands for {repo}.")
        return ("rebase", branch, "delete-custom")

    if choice.lower().startswith("d delete-custom "):
        del_name = choice[16:].strip()
        if del_name:
            print(f"Deleted custom command '{del_name}' for {repo}.")
            return ("rebase", branch, f"delete-custom:{del_name}")
        print(f"Deleted all custom commands for {repo}.")
        return ("rebase", branch, "delete-custom")

    if choice.lower().startswith("d custom "):
        rest = choice[9:].strip()
        if not rest:
            print("No custom command provided, keeping current default.")
            return None
        # Check for name:cmd format
        if ":" in rest:
            name, cmd = rest.split(":", 1)
            name = name.strip()
            cmd = cmd.strip()
            if name and cmd:
                new_default = f"custom:{name}:{cmd}"
                print(f"Setting default for {repo} to custom ({name}: {cmd})")
                return ("custom", cmd, new_default)
        # Name-only → activate existing, or treat as legacy command
        commands = get_custom_commands(defaults, repo)
        if rest in commands:
            cmd = commands[rest]
            print(f"Setting default for {repo} to custom ({rest})")
            return ("custom", cmd, f"custom:{rest}")
        # Legacy: treat as command string
        new_default = f"custom:{rest}"
        print(f"Setting default for {repo} to custom: {rest}")
        return ("custom", rest, new_default)

    if choice.lower() == "d custom":
        # Activate existing saved command (no new command provided)
        saved_cmd = get_saved_custom_command(defaults, repo)
        if saved_cmd:
            active = get_active_custom_name(defaults, repo)
            print(f"Setting default for {repo} to custom: {saved_cmd}")
            if active and active != "default":
                return ("custom", saved_cmd, f"custom:{active}")
            return ("custom", saved_cmd, f"custom:{saved_cmd}")
        print("No custom command saved. Use 'd custom name:cmd' to set one.")
        return None

    if choice.lower().startswith("d "):
        parts = choice.split(maxsplit=1)
        new_default = parts[1].strip().lower() if len(parts) > 1 else ""
        if new_default not in {"skip", "rebase", "merge"}:
            print(f"Unrecognized default '{new_default}', keeping current default.")
            return None
        print(f"Setting default for {repo} to {new_default}.")
        return (new_default, branch, new_default)

    if choice.lower().startswith("c "):
        custom_cmd = choice[2:].strip()
        if not custom_cmd:
            print(f"No custom command provided, skipping {repo}.")
            return None
        return ("custom", custom_cmd, None)

    parts = choice.split(maxsplit=1)
    action = parts[0].lower()
    target = branch
    if len(parts) > 1 and parts[1]:
        target = parts[1]

    if action == "r":
        return ("rebase", target, None)
    if action == "m":
        return ("merge", target, None)

    print(f"Unrecognized input '{choice}', skipping {repo}.")
    return None


def repo_display_name(repo: str) -> str:
    """
    Get display name for a repo. Checks git config for override first,
    then derives from origin URL, falling back to basename.

    To set a custom name: git -C <repo> config bit.display-name "OE-core"
    """
    # Check for user override in git config
    try:
        override = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "bit.display-name"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
        if override:
            return override
    except subprocess.CalledProcessError:
        pass

    # Derive from origin URL
    try:
        url = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        url = ""

    candidate = url
    if candidate:
        candidate = candidate.rstrip("/")
        # handle scp-like git@host:org/repo.git
        if ":" in candidate and "://" not in candidate:
            candidate = candidate.split(":", 1)[1]
        candidate = candidate.split("/")[-1]
        if candidate.endswith(".git"):
            candidate = candidate[:-4]
    if not candidate:
        candidate = os.path.basename(repo.rstrip("/")) or repo
    return candidate


def build_inline_dialog_lines(
    title: str,
    items: List[Tuple[str, str]],
    *,
    reverse_list: bool = True,
    annotation: str = "",
    width: int = 40,
) -> List[str]:
    """Build box-drawing inline dialog lines for fzf menus.

    Produces a header (``┌─ title ───``) and item lines (``│  display``)
    in the correct order for the caller's fzf layout.

    Args:
        title: Clean title text (used for dash-padding calculation).
        items: ``(key, display)`` pairs.  Keys starting with ``---``
            render as separator lines (``│  ────``).
        reverse_list: True for ``--layout=reverse-list`` (header first,
            items last — APPEND to menu_lines).  False for default layout
            (items first, header last — PREPEND to menu_lines).
        annotation: Optional extra text appended to the header before the
            trailing dashes (may contain ANSI codes).
        width: Target width for the trailing dashes.

    Returns:
        List of tab-delimited ``key\\tdisplay`` strings ready for fzf.
    """
    header = f"┌─ {title} "
    if annotation:
        header += annotation + " "
    header += "─" * max(0, width - len(title))
    header_line = f"---\t{Colors.cyan(header)}"

    item_lines: List[str] = []
    for key, display in items:
        if key.startswith("---"):
            item_lines.append(
                f"---\t{Colors.cyan('│')}  {Colors.dim('───────────────────')}"
            )
        else:
            item_lines.append(f"{key}\t{Colors.cyan('│')}  {display}")

    if reverse_list:
        # Header first (visually above), items last (near prompt)
        return [header_line] + item_lines
    else:
        # Items first (near prompt in default layout), header last
        return item_lines + [header_line]


def build_confirm_delete_lines(
    name: str,
    *,
    reverse_list: bool = True,
    yes_key: str = "yes",
    no_key: str = "no",
) -> List[str]:
    """Build framed inline confirmation dialog for deleting a named item.

    Uses ``build_inline_dialog_lines`` with coloured Yes / No buttons
    matching the project's dialog style.
    """
    return build_inline_dialog_lines(
        f"Delete '{name}'?",
        [
            (yes_key, Colors.green("[ ✓ Yes ]")),
            (no_key, Colors.yellow("[ ✗ No ]")),
        ],
        reverse_list=reverse_list,
    )


def get_project_header_prefix() -> str:
    """Return formatted '[ProjectName] ' for fzf headers, or '' if no project.

    When running inside a bit-spawned SSH session (detected via
    ``BIT_REMOTE_HOST``), prepends a ``⇄ hostname`` indicator.
    """
    from .projects import find_project_for_directory, load_projects
    parts = []

    # Remote session indicator — only when bit spawned the SSH session
    # (BIT_REMOTE_HOST is set explicitly by ssh_remote.py).
    # We intentionally don't check SSH_CONNECTION because most users
    # are SSH'd in already and that would always trigger.
    remote_host = os.environ.get("BIT_REMOTE_HOST", "")
    if remote_host:
        parts.append(terminal_color("project_remote", f"⇄ {remote_host}"))

    proj_path = find_project_for_directory()
    if proj_path:
        projects = load_projects()
        name = projects.get(proj_path, {}).get("name", os.path.basename(proj_path))
        parts.append(Colors.bold(terminal_color("project_active", f"[{name}]")))

    if not parts:
        return ""
    return " ".join(parts) + " "


def repo_origin_url(repo: str) -> Optional[str]:
    """Get the origin URL for a repo."""
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        return None


def commit_files(repo: str, commit: str) -> List[str]:
    """Get list of files changed in a commit."""
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "show", "--name-only", "--format=", commit],
            text=True,
        )
        return [f for f in output.strip().splitlines() if f]
    except subprocess.CalledProcessError:
        return []


def create_pull_branch(repo: str, branch_name: str, base_ref: str, range_spec: str, force: bool) -> Tuple[bool, str]:
    """
    Create a branch with the selected commits for pulling.
    The branch is created from the parent of the first commit in range_spec,
    then all commits are cherry-picked onto it.
    Returns (success, message).
    """
    # Check if branch exists
    branch_exists = subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", branch_name],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    if branch_exists:
        if force:
            subprocess.run(["git", "-C", repo, "branch", "-D", branch_name], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            return False, f"Branch '{branch_name}' already exists (use --force to overwrite)"

    # Get the commits in the range
    try:
        if range_spec == "--root":
            # All commits from root - just create branch at HEAD
            subprocess.run(
                ["git", "-C", repo, "branch", branch_name, "HEAD"],
                check=True,
            )
        else:
            # Get list of commits in range
            commits = subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--reverse", range_spec],
                text=True,
            ).strip().splitlines()

            if not commits:
                return False, "No commits in range"

            # Get parent of first commit
            first_commit = commits[0]
            try:
                first_parent = subprocess.check_output(
                    ["git", "-C", repo, "rev-parse", f"{first_commit}^"],
                    text=True,
                    stderr=subprocess.DEVNULL,
                ).strip()
            except subprocess.CalledProcessError:
                # First commit has no parent (root commit), use base_ref as fallback
                first_parent = base_ref

            # Check if first_parent is in upstream (base_ref), or if there are
            # intermediate local commits between upstream and our selection
            is_upstream = subprocess.run(
                ["git", "-C", repo, "merge-base", "--is-ancestor", first_parent, base_ref],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            ).returncode == 0

            extra_count = 0
            if is_upstream:
                # Parent is upstream, we can branch from it directly
                branch_base = first_parent
            else:
                # Parent is a local commit - find commits between upstream and first selected
                try:
                    extra_commits = subprocess.check_output(
                        ["git", "-C", repo, "rev-list", "--reverse", f"{base_ref}..{first_parent}"],
                        text=True,
                    ).strip().splitlines()
                except subprocess.CalledProcessError:
                    extra_commits = []

                if extra_commits:
                    # Include the extra local commits so the branch is pullable
                    extra_count = len(extra_commits)
                    commits = extra_commits + commits
                    branch_base = base_ref
                else:
                    branch_base = first_parent

            # Create branch at the determined base
            subprocess.run(
                ["git", "-C", repo, "branch", branch_name, branch_base],
                check=True,
            )

            # Cherry-pick commits onto the branch
            # First checkout the branch
            original_branch = subprocess.check_output(
                ["git", "-C", repo, "symbolic-ref", "--short", "HEAD"],
                text=True,
            ).strip()

            subprocess.run(["git", "-C", repo, "checkout", branch_name], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            cherry_pick_failed = False
            failed_commit = None
            for commit in commits:
                result = subprocess.run(
                    ["git", "-C", repo, "cherry-pick", commit],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                if result.returncode != 0:
                    cherry_pick_failed = True
                    failed_commit = commit[:12]
                    break

            if cherry_pick_failed:
                # Abort cherry-pick and clean up
                subprocess.run(["git", "-C", repo, "cherry-pick", "--abort"],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["git", "-C", repo, "checkout", original_branch],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                subprocess.run(["git", "-C", repo, "branch", "-D", branch_name],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                return False, f"Cherry-pick failed on {failed_commit} (conflict with {base_ref}?)"

            # Switch back to original branch
            subprocess.run(["git", "-C", repo, "checkout", original_branch], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        if range_spec != "--root" and extra_count > 0:
            return True, f"Created branch '{branch_name}' (included {extra_count} additional local commit(s) before selection)"
        return True, f"Created branch '{branch_name}'"
    except subprocess.CalledProcessError as e:
        return False, f"Failed to create branch: {e}"


def author_ident(repo: str) -> Tuple[str, str]:
    fallback = ("nobody", "nobody@localhost")
    try:
        ident = subprocess.check_output(
            ["git", "-C", repo, "var", "GIT_AUTHOR_IDENT"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()
        # Format: "Name <email> timestamp timezone"
        if "<" in ident and ">" in ident:
            name = ident.split("<", 1)[0].strip()
            email = ident.split("<", 1)[1].split(">", 1)[0].strip()
            return name or fallback[0], email or fallback[1]
    except subprocess.CalledProcessError:
        pass
    return fallback


def patch_subject(patch_path: str) -> str:
    try:
        with open(patch_path, encoding="utf-8") as f:
            for line in f:
                if line.lower().startswith("subject:"):
                    subj = line.split(":", 1)[1].strip()
                    if subj.startswith("[PATCH"):
                        end = subj.find("]")
                        if end != -1:
                            subj = subj[end + 1 :].strip()
                    return subj
    except Exception:
        pass
    return os.path.basename(patch_path)


def git_version() -> str:
    try:
        out = subprocess.check_output(["git", "--version"], text=True).strip()
        # format: git version X.Y.Z
        parts = out.split()
        if len(parts) >= 3:
            return parts[2]
    except Exception:
        pass
    return "unknown"


def git_request_pull(
    repo: str,
    base_ref: str,
    push_url: str,
    local_ref: str,
    remote_branch: str,
) -> Optional[str]:
    """
    Generate a git request-pull message.
    Returns the request-pull output (without diffstat), or None on error.
    """
    try:
        # Format: git request-pull <start> <url> <local>:<remote>
        cmd = ["git", "-C", repo, "request-pull", base_ref, push_url, f"{local_ref}:{remote_branch}"]
        output = subprocess.check_output(cmd, text=True, stderr=subprocess.STDOUT)
        # Remove the diffstat portion (everything after the first file stats line)
        # The format is: URL line, then empty line, then diffstat
        lines = output.splitlines()
        result_lines = []
        for line in lines:
            # Stop before diffstat (lines with file changes like " file | N +++ ---")
            if re.match(r"^\s+\S+.*\|\s+\d+", line):
                break
            # Also stop at "N files changed" summary
            if re.match(r"^\s*\d+ files? changed", line):
                break
            result_lines.append(line)
        # Remove trailing empty lines
        while result_lines and not result_lines[-1].strip():
            result_lines.pop()
        return "\n".join(result_lines)
    except subprocess.CalledProcessError as e:
        return None


def push_branch_to_target(
    repo: str,
    push_url: str,
    local_ref: str,
    remote_branch: str,
    force: bool = False,
) -> Tuple[bool, str]:
    """
    Push a branch to the push target.
    Returns (success, message).
    """
    try:
        cmd = ["git", "-C", repo, "push", push_url, f"{local_ref}:{remote_branch}"]
        if force:
            cmd.insert(3, "--force")
        subprocess.run(cmd, check=True, capture_output=True, text=True)
        return True, f"Pushed {local_ref} to {push_url} {remote_branch}"
    except subprocess.CalledProcessError as e:
        return False, f"Push failed: {e.stderr.strip() or e.stdout.strip() or str(e)}"


def clean_title(subject: str) -> str:
    s = subject.strip()
    # Drop leading bracketed tokens like [PATCH 1/2], [repo], etc.
    s = re.sub(r"^(?:\[[^\]]*\]\s*)+", "", s)
    return s.strip()


def rewrite_patch_subject(patch_path: str, repo_name: str) -> None:
    """
    Normalize Subject to: [NN/MM][repo] title
    """
    try:
        with open(patch_path, encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        return

    new_lines = []
    changed = False
    subj_re_patch = re.compile(r"Subject:\s*(?:\[[^\]]*\]\s*)*\[PATCH\s+(\d+)/(\d+)\]\s*(.*)", re.IGNORECASE)
    subj_re_repo_num = re.compile(r"Subject:\s*\[+([^\]]+?)\]+\s*\[?(\d+)/(\d+)\]?\s*(.*)", re.IGNORECASE)
    subj_re_num_repo = re.compile(r"Subject:\s*\[?(\d+)/(\d+)\]?\s*\[+([^\]]+?)\]+\s*(.*)", re.IGNORECASE)
    for line in lines:
        if not changed and line.lower().startswith("subject:"):
            m = subj_re_patch.match(line)
            repo = repo_name
            if m:
                num, den, rest = m.groups()
            else:
                m = subj_re_repo_num.match(line)
                if m:
                    repo, num, den, rest = m.groups()
                    repo = repo.strip("[]") or repo_name
                else:
                    m = subj_re_num_repo.match(line)
                    if m:
                        num, den, repo, rest = m.groups()
                        repo = repo.strip("[]") or repo_name
                    else:
                        new_lines.append(line)
                        continue

            # strip any leading bracket tokens from rest
            while rest.startswith("[") and "]" in rest:
                rest = rest.split("]", 1)[1].strip()
            new_line = f"Subject: [{repo}][PATCH {num}/{den}] {rest}\n"
            new_lines.append(new_line)
            changed = True
            continue
        new_lines.append(line)

    if changed:
        try:
            with open(patch_path, "w", encoding="utf-8") as f:
                f.writelines(new_lines)
        except Exception:
            pass


def load_resume(resume_file: str) -> Optional[Tuple[int, List[str]]]:
    if not os.path.exists(resume_file):
        return None
    with open(resume_file, encoding="utf-8") as f:
        lines = [line.rstrip("\n") for line in f]
    if not lines:
        return None
    try:
        idx = int(lines[0])
    except ValueError:
        return None
    return idx, lines[1:]


def save_resume(resume_file: str, next_idx: int, repos: List[str]) -> None:
    with open(resume_file, "w", encoding="utf-8") as f:
        f.write(f"{next_idx}\n")
        for repo in repos:
            f.write(f"{repo}\n")


def get_extra_repos(defaults: dict) -> List[str]:
    """Get list of extra repos from defaults."""
    return defaults.get("__extra_repos__", [])


def get_hidden_repos(defaults: dict) -> List[str]:
    """Get list of hidden repos from defaults."""
    return defaults.get("__hidden_repos__", [])


def write_ignore_file(project_dir: str) -> bool:
    """Write a .ignore file to exclude build directories from search tools.

    Writes 'build*/' so ripgrep, fd, etc. skip build directories.
    Returns True if the file was written, False if it already existed.
    """
    ignore_path = os.path.join(project_dir, ".ignore")
    if os.path.exists(ignore_path):
        return False
    try:
        with open(ignore_path, "w") as f:
            f.write("build*/\n")
        return True
    except OSError:
        return False


def add_extra_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Add a repo to the extra repos list and save."""
    extra = defaults.get("__extra_repos__", [])
    if repo_path not in extra:
        extra.append(repo_path)
        defaults["__extra_repos__"] = extra
        save_defaults(defaults_file, defaults)


def add_hidden_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Add a repo to the hidden repos list and save."""
    hidden = defaults.get("__hidden_repos__", [])
    if repo_path not in hidden:
        hidden.append(repo_path)
        defaults["__hidden_repos__"] = hidden
        save_defaults(defaults_file, defaults)


def remove_hidden_repo(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Remove a repo from the hidden repos list and save."""
    hidden = defaults.get("__hidden_repos__", [])
    if repo_path in hidden:
        hidden.remove(repo_path)
        defaults["__hidden_repos__"] = hidden
        save_defaults(defaults_file, defaults)


def get_push_target(defaults: dict, repo_path: str) -> Optional[Dict[str, str]]:
    """Get push target config for a repo. Returns dict with push_url, branch_prefix, or None."""
    targets = defaults.get("__push_targets__", {})
    return targets.get(repo_path)


def set_push_target(
    defaults_file: str,
    defaults: dict,
    repo_path: str,
    push_url: str,
    branch_prefix: str = "",
) -> None:
    """Set push target config for a repo."""
    targets = defaults.get("__push_targets__", {})
    targets[repo_path] = {
        "push_url": push_url,
        "branch_prefix": branch_prefix,
    }
    defaults["__push_targets__"] = targets
    save_defaults(defaults_file, defaults)


def remove_push_target(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Remove push target config for a repo."""
    targets = defaults.get("__push_targets__", {})
    if repo_path in targets:
        del targets[repo_path]
        defaults["__push_targets__"] = targets
        save_defaults(defaults_file, defaults)


def get_repo_commit_info(repo: str) -> Tuple[Optional[str], bool, str, int, str, str]:
    branch = current_branch(repo)
    if not branch:
        return None, False, "", 0, "", "detached head"

    remote_ref = f"origin/{branch}"
    remote_exists = (
        subprocess.run(
            ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode
        == 0
    )

    if remote_exists:
        count = int(
            subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--count", f"{remote_ref}..HEAD"],
                text=True,
            ).strip()
        )
        range_spec = f"{remote_ref}..HEAD"
        desc = f"local commits vs {remote_ref}"
    else:
        count = int(subprocess.check_output(["git", "-C", repo, "rev-list", "--count", "HEAD"], text=True).strip())
        range_spec = "--root"
        desc = "commits from root (no origin/<branch>)"

    return branch, remote_exists, remote_ref, count, range_spec, desc


def show_log_for_pick(repo: str, max_entries: int = 30) -> None:
    try:
        out = subprocess.check_output(
            [
                "git",
                "-C",
                repo,
                "log",
                "--oneline",
                "--decorate",
                f"-n{max_entries}",
            ],
            text=True,
        )
    except subprocess.CalledProcessError:
        print(f"{repo}: failed to read log for pick mode.")
        return
    print(out.rstrip())


# Shared command list for menus - add new commands here
COMMANDS = [
    ("explore", "Interactively explore commits in layer repos"),
    ("update", "Update git repos referenced by layers in bblayers.conf"),
    ("status", "Show local commit summary for layer repos"),
    ("config", "View and configure repo/layer settings"),
    ("branch", "View and switch branches across repos"),
    ("export", "Export patches from layer repos"),
    ("repos", "List layer repos"),
    ("setup", "Set up build environment, clone repos, manage configs"),
    ("setup shell", "Start a shell with build environment pre-sourced"),
    ("setup clone", "Clone repos and register project"),
    ("setup configs", "Browse and manage saved configurations"),
    ("setup apply", "Apply layers and fragments from saved config"),
    ("setup save", "Save a config file to the user registry"),
    ("layer-index", "Search and browse OpenEmbedded Layer Index"),
]


def fzf_command_menu() -> Optional[str]:
    """Show fzf menu to select a subcommand. Returns command name or None if cancelled."""
    # Commands with their subcommands (alphabetical order)
    commands = [
        ("branch", "View and switch branches across repos", []),
        ("config", "View and configure repo/layer settings", []),
        ("export", "Export patches from layer repos", [
            ("export prep", "Prepare commits for export (reorder/group)"),
        ]),
        ("explore", "Interactively explore commits in layer repos", []),
        ("help", "Browse help for all commands", []),
        ("setup", "Set up build environment, clone repos, manage configs", [
            ("setup shell", "Start a shell with build environment pre-sourced"),
            ("setup clone", "Clone repos and register project"),
            ("setup configs", "Browse and manage saved configurations"),
            ("setup apply", "Apply layers and fragments from saved config"),
            ("setup save", "Save a config file to the user registry"),
        ]),
        ("repos", "List layer repos", [
            ("repos status", "Show one-liner status for each repo"),
        ]),
        ("layer-index", "Search and browse OpenEmbedded Layer Index", []),
        ("status", "Show local commit summary for layer repos", []),
        ("update", "Update git repos referenced by layers in bblayers.conf", []),
    ]

    return fzf_expandable_menu(
        commands,
        header="Enter/←/→/\\=fold | q=quit",
        prompt="bit ",
        height="~80%",
    )


def fzf_help_browser() -> Optional[str]:
    """
    Interactive help browser with preview pane.
    Returns command name to run, or None to exit.
    """
    # Get the script path for preview commands
    script_path = os.path.abspath(sys.argv[0])

    # Commands with their subcommands (alphabetical order)
    commands = [
        ("(general)", "Overview and global options", []),
        ("branch", "View and switch branches across repos", []),
        ("config", "View and configure repo/layer settings", []),
        ("export", "Export patches from layer repos", [
            ("export prep", "Prepare commits for export (reorder/group)"),
        ]),
        ("explore", "Interactively explore commits in layer repos", []),
        ("help", "Browse help for all commands", []),
        ("setup", "Set up build environment, clone repos, manage configs", [
            ("setup shell", "Start a shell with build environment pre-sourced"),
            ("setup clone", "Clone repos and register project"),
            ("setup configs", "Browse and manage saved configurations"),
            ("setup apply", "Apply layers and fragments from saved config"),
            ("setup save", "Save a config file to the user registry"),
        ]),
        ("repos", "List layer repos", [
            ("repos status", "Show one-liner status for each repo"),
        ]),
        ("layer-index", "Search and browse OpenEmbedded Layer Index", []),
        ("status", "Show local commit summary for layer repos", []),
        ("update", "Update git repos referenced by layers in bblayers.conf", []),
    ]

    # Preview command: show help for the selected command
    preview_cmd = (
        f'cmd={{1}}; '
        f'if [ "$cmd" = "(general)" ]; then '
        f'  "{script_path}" --help 2>&1; '
        f'elif [ "$cmd" = "export prep" ]; then '
        f'  "{script_path}" export prep --help 2>&1; '
        f'elif [ "$cmd" = "setup shell" ]; then '
        f'  "{script_path}" setup shell --help 2>&1; '
        f'elif [ "$cmd" = "repos status" ]; then '
        f'  "{script_path}" repos status --help 2>&1; '
        f'else '
        f'  "{script_path}" "$cmd" --help 2>&1; '
        f'fi'
    )

    # Options provider: parse --help output for command options
    def get_options(cmd: str) -> List[Tuple[str, str]]:
        if cmd == "(general)":
            return parse_help_options(script_path, "")
        return parse_help_options(script_path, cmd)

    selected = fzf_expandable_menu(
        commands,
        header=f"Enter/←/→/\\=fold | v=options | ?=preview | q=quit\n{get_preview_header_suffix()}",
        prompt="Select command: ",
        height="100%",
        preview_cmd=preview_cmd,
        preview_window="right,60%,wrap",
        options_provider=get_options,
    )

    if not selected:
        return None

    # Don't try to "run" general help
    if selected == "(general)":
        return None
    # For subcommands, return the parent command
    if selected == "export prep":
        return "export"
    if selected == "setup shell":
        return "setup"
    if selected == "repos status":
        return "repos"

    return selected


def fzf_pick_range(repo: str, branch: str, default_range: Optional[str] = None,
                   prev_range: Optional[str] = None, max_entries: int = 100,
                   prev_was_skip: bool = False) -> Optional[str]:
    """
    Use fzf to interactively select a commit range.
    Returns a git range string like 'abc123^..def456', or:
    - None if cancelled (Escape)
    - "SKIP" if user wants to skip this repo
    - "SKIP_REST" if user wants to skip all remaining repos
    - "USE_DEFAULT" to use the default range (all local commits)
    - "USE_PREVIOUS" to use the previous range

    If prev_was_skip is True, the skip option is shown first as the default.
    """
    # Only show commits not in origin (local commits)
    remote_ref = f"origin/{branch}"
    remote_exists = subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0

    try:
        if remote_exists:
            # Show only commits not in origin
            log_output = subprocess.check_output(
                ["git", "-C", repo, "log", "--oneline", "--decorate", f"{remote_ref}..HEAD"],
                text=True,
            )
        else:
            # No remote, show recent commits
            log_output = subprocess.check_output(
                ["git", "-C", repo, "log", "--oneline", "--decorate", f"-n{max_entries}"],
                text=True,
            )
    except subprocess.CalledProcessError:
        return None

    if not log_output.strip():
        print(f"{repo}: no local commits to export.")
        return "SKIP"

    # Count local commits
    local_count = len(log_output.strip().splitlines())

    # Build menu with options at top
    menu_lines = []

    skip_line = "►► Skip this repo (s)"
    skip_all_line = "── [S] Skip all remaining repos ──"

    # If previously skipped, show skip as first option (default)
    if prev_was_skip:
        menu_lines.append(skip_line)

    # Add "use previous" option if we have a previous range from last export
    if prev_range and prev_range != default_range:
        menu_lines.append(f"►► Use previous: {prev_range}")

    # Add "include all" option
    if remote_exists:
        menu_lines.append(f"►► Include all {local_count} local commits ({remote_ref}..HEAD)")
    else:
        menu_lines.append(f"►► Include all {local_count} commits")

    # If not previously skipped, show skip after include options
    if not prev_was_skip:
        menu_lines.append(skip_line)
    menu_lines.append(skip_all_line)

    menu_input = "\n".join(menu_lines) + "\n" + log_output

    header = f"repo: {repo}  branch: {branch}\n"
    header += "Space=range | Tab=single | s=skip | S=skip all | Enter=confirm"

    # Temp file for tracking range markers (consistent with prep command)
    range_file = f"/tmp/fzf_range_{os.getpid()}"
    if os.path.exists(range_file):
        os.remove(range_file)

    # Shell script to build prompt showing range marker count
    prompt_script = (
        f'rng=; '
        f'[ -f {range_file} ] && {{ n=$(wc -l < {range_file}); [ "$n" -gt 0 ] && rng="[range:$n]"; }}; '
        f'echo "Select$rng: "'
    )

    try:
        result = subprocess.run(
            [
                "fzf",
                "--multi",
                "--no-sort",
                "--height", "~50%",  # Inline, fit content up to 50% of terminal
                "--header", header,
                "--prompt", "Select: ",
                "--color", "header:italic",
                # Space binding has complex action - preserved as custom
                "--bind", f"space:toggle+execute-silent(echo {{}} >> {range_file})+transform-prompt({prompt_script})+down",  # Space marks range
            ] + get_toggle_binding() +  # Tab for single commit toggle
            get_action_binding("s", "SKIP_THIS") +  # Shortcut for skip
            get_action_binding("S", "SKIP_REST") +  # Shortcut for skip all
            get_fzf_color_args(),
            input=menu_input,
            stdout=subprocess.PIPE,  # Capture selection output
            # Don't capture stderr - let fzf render to terminal
            text=True,
        )
    except FileNotFoundError:
        if os.path.exists(range_file):
            os.remove(range_file)
        return None

    # Clean up range file
    if os.path.exists(range_file):
        os.remove(range_file)

    if result.returncode != 0 or not result.stdout.strip():
        # Escape pressed or no selection
        return None

    selected = result.stdout.strip().splitlines()
    if not selected:
        return None

    # Check for shortcut keys and menu options
    for sel in selected:
        if sel.strip() == "SKIP_THIS":
            return "SKIP"
        if sel.strip() == "SKIP_REST":
            return "SKIP_REST"
        if "Use previous:" in sel:
            return "USE_PREVIOUS"
        if "Include all" in sel:
            return "USE_DEFAULT"
        if "Skip this repo" in sel:
            return "SKIP"
        if "Skip all remaining" in sel:
            return "SKIP_REST"

    # Extract commit hashes from selected lines
    log_lines = log_output.strip().splitlines()
    hash_to_pos = {}
    for i, line in enumerate(log_lines):
        parts = line.split(maxsplit=1)
        if parts:
            hash_to_pos[parts[0]] = i

    commits = []
    for line in selected:
        parts = line.split(maxsplit=1)
        if parts and parts[0] in hash_to_pos:
            commits.append(parts[0])

    if not commits:
        return None

    if len(commits) == 1:
        # Single commit selected
        return f"{commits[0]}^..{commits[0]}"

    # Multiple commits - sort by position (lower = newer in git log)
    commits_sorted = sorted(commits, key=lambda c: hash_to_pos.get(c, 0))
    newest = commits_sorted[0]
    oldest = commits_sorted[-1]
    return f"{oldest}^..{newest}"


def prepare_target_dir(target: str, force: bool) -> None:
    if not os.path.exists(target):
        os.makedirs(target, exist_ok=True)
        return

    if not os.path.isdir(target):
        sys.exit(f"Target path '{target}' exists and is not a directory.")

    existing = os.listdir(target)
    if existing and force:
        for entry in existing:
            entry_path = os.path.join(target, entry)
            if os.path.isdir(entry_path):
                shutil.rmtree(entry_path)
            else:
                os.remove(entry_path)
    elif existing and not force:
        # Prompt user to clear directory
        print(f"Target directory '{target}' contains {len(existing)} file(s).")
        choice = input("Remove existing files? [y/N]: ").strip().lower()
        if choice == 'y':
            for entry in existing:
                entry_path = os.path.join(target, entry)
                if os.path.isdir(entry_path):
                    shutil.rmtree(entry_path)
                else:
                    os.remove(entry_path)
            print(f"Cleared {len(existing)} file(s) from {target}")
        else:
            sys.exit("Aborted.")


def prompt_export(repo: str, layer: str, info: Tuple[Optional[str], bool, str, int, str, str], default_include: bool, display_name: str = None) -> Tuple[bool, bool]:
    branch, remote_exists, remote_ref, count, _range, desc = info
    name = display_name or repo
    if count == 0:
        print(f"{name}: no local commits to export.")
        return False, False
    if not branch:
        print(f"{name}: detached HEAD; skipping.")
        return False, False

    default_hint = "Y/n" if default_include else "y/N"
    prompt = f"Include {name} ({repo}) [{desc}, {count} commits]? ({default_hint}, S=skip rest) "
    resp = input(prompt).strip()
    if not resp:
        return default_include, False
    if resp == "S":
        return False, True
    if resp.lower().startswith("y"):
        return True, False
    if resp.lower() in {"n", "s"}:
        return False, False
    return default_include, False


# ------------------------ Commands ------------------------


def copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard using available clipboard tool. Returns True on success."""
    import shutil

    # Try different clipboard commands
    clipboard_cmds = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
        ["pbcopy"],  # macOS
    ]

    for cmd in clipboard_cmds:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text, text=True, check=True)
                return True
            except subprocess.CalledProcessError:
                continue
    return False



def find_repo_by_identifier(repos: List[str], identifier: str, defaults: Dict[str, str]) -> Optional[str]:
    """
    Find a repo by index, display name, path, or partial match.
    Returns the repo path or None if not found.
    """
    # Try as index
    try:
        idx = int(identifier)
        if 1 <= idx <= len(repos):
            return repos[idx - 1]
        return None
    except ValueError:
        pass

    # Try matching by display name (case-insensitive)
    for repo in repos:
        if repo_display_name(repo).lower() == identifier.lower():
            return repo

    # Try as absolute/relative path
    if os.path.isdir(identifier):
        abs_path = os.path.abspath(identifier)
        if abs_path in repos:
            return abs_path

    # Try partial path match
    for repo in repos:
        if identifier in repo or repo.endswith(identifier):
            return repo

    return None




def export_single_patch(repo: str, commit: str, target_dir: str = ".") -> Optional[str]:
    """Export a single commit as a .patch file using git format-patch. Returns full path or None on error."""
    try:
        # Use git format-patch to create file with standard naming (0001-subject.patch)
        output = subprocess.check_output(
            ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir],
            text=True,
        ).strip()
        # git format-patch outputs the created filename
        return output
    except subprocess.CalledProcessError:
        return None


def export_commits_from_explore(repo: str, commits: List[str]) -> None:
    """Export one or more commits as patch files. Prompts for directory if multiple."""
    if not commits:
        return

    # Get current directory for display
    cwd = os.getcwd()

    if len(commits) == 1:
        # Single commit - export to current directory
        print(f"\nExporting to {cwd}...")
        filepath = export_single_patch(repo, commits[0], cwd)
        if filepath:
            print(f"  {os.path.basename(filepath)}")
        else:
            print(f"  Failed to export {commits[0][:8]}")
        input("Press Enter to continue...")
        return

    # Multiple commits - prompt for target directory
    print(f"\nExporting {len(commits)} commits...")
    try:
        default_target = os.path.expanduser("~/patches")
        target_dir = input(f"Target directory [{default_target}]: ").strip()
        if not target_dir:
            target_dir = default_target
        target_dir = os.path.expanduser(target_dir)
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return

    # Create directory if needed
    os.makedirs(target_dir, exist_ok=True)

    print(f"Exporting to {target_dir}...")

    # Export each commit using git format-patch (standard naming)
    exported = []
    for i, commit in enumerate(commits, 1):
        try:
            # Use git format-patch with start-number for proper sequencing
            output = subprocess.check_output(
                ["git", "-C", repo, "format-patch", "-1", commit, "-o", target_dir,
                 f"--start-number={i}"],
                text=True,
            ).strip()
            exported.append(os.path.basename(output))
            print(f"  {os.path.basename(output)}")
        except subprocess.CalledProcessError as e:
            print(f"  Failed: {commit[:8]}")

    print(f"Exported {len(exported)} patch(es)")
    input("Press Enter to continue...")


# --- Remote patch import helpers ---

def _split_mbox_to_files(mbox_text: str, target_dir: str) -> List[str]:
    """Split concatenated mbox output into individual ``.patch`` files.

    Splits on ``^From `` boundaries (standard git format-patch mbox separator).
    Returns list of created file paths.
    """
    os.makedirs(target_dir, exist_ok=True)
    patches = []
    current: List[str] = []

    for line in mbox_text.splitlines(keepends=True):
        if line.startswith("From ") and current:
            patches.append("".join(current))
            current = [line]
        else:
            current.append(line)
    if current:
        patches.append("".join(current))

    created = []
    for i, patch_text in enumerate(patches, 1):
        # Extract subject for filename (best-effort)
        subject = ""
        for line in patch_text.splitlines():
            if line.lower().startswith("subject:"):
                subject = line.split(":", 1)[1].strip()
                # Remove [PATCH N/M] prefix
                subject = re.sub(r'^\[PATCH[^\]]*\]\s*', '', subject)
                break
        # Sanitize for filename
        if subject:
            safe = re.sub(r'[^a-zA-Z0-9._-]', '-', subject)[:60].strip('-')
        else:
            safe = "patch"
        filename = f"{i:04d}-{safe}.patch"
        filepath = os.path.join(target_dir, filename)
        with open(filepath, "w") as f:
            f.write(patch_text)
        created.append(filepath)

    return created


def _match_local_repo(remote_repo: str, local_projects: dict) -> List[str]:
    """Match a remote repo to local projects by basename.

    Returns list of local project paths whose basename matches the
    remote repo basename.  Caller shows these as candidates in a picker.
    """
    remote_base = os.path.basename(remote_repo.rstrip("/"))
    if not remote_base:
        return []

    candidates = []
    for proj_path, proj_info in local_projects.items():
        if proj_info.get("host"):
            continue  # skip remote projects
        # Check basename of project path
        local_base = os.path.basename(proj_path.rstrip("/"))
        if local_base == remote_base:
            candidates.append(proj_path)
            continue
        # Check if any repo inside the project matches
        # (repo paths are not stored in project info, so just check project basename)
    return candidates


def import_remote_patches(user: str, host: str, remote_repo: str,
                          commits: List[str], local_repo: str,
                          method: str, branch: Optional[str] = None) -> str:
    """Import patches from a remote repo to a local repo.

    Args:
        user: SSH username.
        host: SSH hostname.
        remote_repo: Path to the remote git repo.
        commits: List of commit hashes to import.
        local_repo: Local git repo path (or directory for save method).
        method: One of ``"am"``, ``"fetch"``, ``"save"``.
        branch: Remote branch name (used for fetch method).

    Returns a status message string.
    """
    from .ssh_remote import ssh_format_patch_stdout

    if method == "am":
        patch_data = ssh_format_patch_stdout(user, host, remote_repo, commits)
        if not patch_data:
            return f"{Colors.red('✗')} Failed to fetch patches from {host}"
        try:
            r = subprocess.run(
                ["git", "-C", local_repo, "am"],
                input=patch_data,
                text=True,
                capture_output=True,
            )
            if r.returncode == 0:
                return f"{Colors.green('✓')} Applied {len(commits)} patch(es) to {os.path.basename(local_repo)}"
            else:
                err = r.stderr.strip().splitlines()
                hint = err[0] if err else "conflict"
                return (f"{Colors.red('✗')} git am failed: {hint}\n"
                        f"  Run: git -C {local_repo} am --abort  (to undo)\n"
                        f"  Or:  git -C {local_repo} am --skip   (to skip this patch)\n"
                        f"  Or:  git -C {local_repo} am --continue  (after resolving)")
        except (subprocess.CalledProcessError, OSError) as e:
            return f"{Colors.red('✗')} git am error: {e}"

    elif method == "fetch":
        if not branch:
            branch = "HEAD"
        remote_name = f"bit-import-{host}"
        remote_url = f"ssh://{user}@{host}{remote_repo}"
        try:
            # Add transient remote, or update URL if it already exists
            r_add = subprocess.run(
                ["git", "-C", local_repo, "remote", "add", remote_name, remote_url],
                capture_output=True, text=True,
            )
            if r_add.returncode != 0:
                subprocess.run(
                    ["git", "-C", local_repo, "remote", "set-url", remote_name, remote_url],
                    capture_output=True, text=True,
                )
            # Fetch the branch
            r = subprocess.run(
                ["git", "-C", local_repo, "fetch", remote_name, branch],
                capture_output=True, text=True, timeout=120,
            )
            if r.returncode == 0:
                # Cherry-pick the selected commits onto current branch
                picked = 0
                errors = []
                for h in commits:
                    cp = subprocess.run(
                        ["git", "-C", local_repo, "cherry-pick", h],
                        capture_output=True, text=True,
                    )
                    if cp.returncode == 0:
                        picked += 1
                    else:
                        err_line = (cp.stderr.strip().splitlines() or ["conflict"])[0]
                        errors.append(f"  {h[:12]}: {err_line}")
                        # Abort the failed cherry-pick so the repo is clean
                        subprocess.run(
                            ["git", "-C", local_repo, "cherry-pick", "--abort"],
                            capture_output=True, text=True,
                        )
                        break
                if errors:
                    return (f"{Colors.green('✓')} Applied {picked}/{len(commits)} commit(s) "
                            f"to {os.path.basename(local_repo)}\n"
                            f"{Colors.red('✗')} Cherry-pick failed:\n" + "\n".join(errors))
                return (f"{Colors.green('✓')} Applied {len(commits)} commit(s) "
                        f"to {os.path.basename(local_repo)} (fetch + cherry-pick)")
            else:
                err = r.stderr.strip().splitlines()
                return f"{Colors.red('✗')} git fetch failed: {err[0] if err else 'unknown error'}"
        except (subprocess.TimeoutExpired, OSError) as e:
            return f"{Colors.red('✗')} git fetch error: {e}"

    elif method == "save":
        patch_data = ssh_format_patch_stdout(user, host, remote_repo, commits)
        if not patch_data:
            return f"{Colors.red('✗')} Failed to fetch patches from {host}"
        created = _split_mbox_to_files(patch_data, local_repo)
        return f"{Colors.green('✓')} Saved {len(created)} patch(es) to {local_repo}"

    else:
        return f"{Colors.red('✗')} Unknown import method: {method}"


# ---------------------------------------------------------------------------
# Shared inline config dialog helpers
# ---------------------------------------------------------------------------
# Used by both config.py (reverse-list layout) and explore.py (default layout)
# to build repo configuration dialogs, handle text input results, manage
# default selection, and build/handle branch filter dialogs.


def get_repo_display_info(repo: str) -> Tuple[str, bool]:
    """Get display name and whether it's a custom (user-set) name.

    Returns:
        ``(display_name, is_custom)`` where *is_custom* is True when the
        user has explicitly set ``bit.display-name`` in git config.
    """
    display = repo_display_name(repo)
    try:
        custom = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "bit.display-name"],
            stderr=subprocess.DEVNULL, text=True,
        ).strip()
        is_custom = bool(custom)
    except subprocess.CalledProcessError:
        is_custom = False
    return display, is_custom


def build_repo_config_items(
    repo: str,
    defaults: dict,
    prefix: str,
) -> List[Tuple[str, str]]:
    """Build config dialog items in **natural visual order**.

    Items are returned Display-name first, Edit last.  The caller should
    reverse or reorder as needed for its fzf layout:

    * ``reverse-list`` layout (config.py) — use directly
    * ``default`` layout (explore.py) — reverse the list, then prepend
      caller-specific extras (BRANCH_FILTER, DONE)

    Args:
        repo: Absolute repo path.
        defaults: Loaded defaults dict.
        prefix: Item key prefix (e.g. ``"RACT:"`` or ``"CFG:"``).
    """
    display_name, is_custom = get_repo_display_info(repo)
    update_default = defaults.get(repo, "rebase")
    push_target = get_push_target(defaults, repo)
    push_status = push_target.get("push_url", "")[:40] if push_target else "(not configured)"
    display_suffix = " (custom)" if is_custom else " (auto)"

    current_for_radio = "custom" if is_custom_default(update_default) else update_default

    def _radio(opt):
        return "\u25cf" if current_for_radio == opt else "\u25cb"

    all_cmds = get_custom_commands(defaults, repo)
    active_name = get_active_custom_name(defaults, repo)

    items: List[Tuple[str, str]] = [
        (f"{prefix}DISPLAY", f"Display name     {display_name}{display_suffix}"),
        (f"{prefix}DEFAULT_rebase", f"Update default   {_radio('rebase')} rebase"),
        (f"{prefix}DEFAULT_merge", f"                 {_radio('merge')} merge"),
        (f"{prefix}DEFAULT_skip", f"                 {_radio('skip')} skip"),
    ]
    if all_cmds:
        for cname, cmd in all_cmds.items():
            is_active = (current_for_radio == "custom" and cname == active_name)
            marker = "\u25cf" if is_active else "\u25cb"
            if cname == "default":
                label = f"custom ({cmd})"
            else:
                label = f"custom ({cname}: {cmd})"
            items.append((f"{prefix}DEFAULT_custom_{cname}", f"                 {marker} {label}"))
    else:
        items.append((f"{prefix}DEFAULT_custom", f"                 {_radio('custom')} custom..."))
    items.extend([
        (f"{prefix}PUSH", f"Push target      {push_status}"),
        (f"{prefix}EDIT", f"Edit layer.conf  \u2192"),
    ])
    return items


def apply_config_text_result(
    action: str,
    query: str,
    repo: str,
    defaults: dict,
    defaults_file: str,
    pending_push_url: Optional[str],
) -> Tuple[str, str, Optional[str]]:
    """Handle text-input results for the inline config dialog.

    Processes display-name set/unset, push URL save/chain, push prefix
    save, and custom-default save.

    Returns:
        ``(next_text_action, next_text_query, updated_pending_push_url)``
        — when *next_text_action* is non-empty the caller should remain
        in text-input mode with the returned action/query.
    """
    next_action = ""
    next_query = ""

    if action == "display":
        _display, is_custom = get_repo_display_info(repo)
        if query == "" and is_custom:
            try:
                subprocess.run(
                    ["git", "-C", repo, "config", "--unset", "bit.display-name"],
                    check=True,
                )
            except subprocess.CalledProcessError:
                pass
        elif query:
            subprocess.run(
                ["git", "-C", repo, "config", "bit.display-name", query],
                check=True,
            )
    elif action == "push":
        if not query:
            remove_push_target(defaults_file, defaults, repo)
        else:
            pending_push_url = query
            pt = get_push_target(defaults, repo)
            current_prefix = pt.get("branch_prefix", "") if pt else ""
            next_action = "push_prefix"
            next_query = current_prefix
    elif action == "push_prefix":
        if pending_push_url:
            set_push_target(defaults_file, defaults, repo, pending_push_url, query or "")
            pending_push_url = None
    elif action == "custom_default":
        if query:
            save_custom_command(defaults, repo, query)
            save_defaults(defaults_file, defaults)

    return next_action, next_query, pending_push_url


def handle_config_default_selection(
    action_suffix: str,
    repo: str,
    defaults: dict,
    defaults_file: str,
) -> Tuple[str, str]:
    """Handle DEFAULT_* selection from the config dialog.

    Saves immediately for radio-button selections (rebase/merge/skip)
    and named custom commands.

    Args:
        action_suffix: The part after ``DEFAULT_`` (e.g. ``"rebase"``,
            ``"custom_foo"``, or bare ``"custom"``).

    Returns:
        ``(text_action, text_query)`` — non-empty only for the bare
        ``"custom"`` case that needs text input.
    """
    if action_suffix in ("rebase", "merge", "skip"):
        defaults[repo] = action_suffix
        save_defaults(defaults_file, defaults)
        return "", ""
    elif action_suffix.startswith("custom_"):
        cname = action_suffix[len("custom_"):]
        activate_custom_command(defaults, repo, cname)
        save_defaults(defaults_file, defaults)
        return "", ""
    elif action_suffix == "custom":
        return "custom_default", ""
    return "", ""


def build_branch_filter_items(
    pending_priorities: List[str],
    pending_excludes: List[str],
    prefix: str,
    stale_days: int = 365,
) -> List[Tuple[str, str]]:
    """Build branch filter dialog items in **natural visual order**.

    Items are returned Priorities-header first, Save-and-return last.
    The caller reverses for default layout.
    """
    items: List[Tuple[str, str]] = []
    items.append(("---", "\u2500\u2500 Priorities \u2500\u2500"))
    for i, pattern in enumerate(pending_priorities):
        items.append((f"{prefix}BP:{i}", f"{Colors.red('x')} {Colors.cyan(pattern)}"))
    items.append((f"{prefix}ADD_PRIORITY", f"{Colors.green('+')} Add priority"))
    items.append((f"{prefix}BROWSE_PRIORITY", f"{Colors.green('\u2295')} Browse"))
    items.append(("---", "\u2500\u2500 Excludes \u2500\u2500"))
    for i, pattern in enumerate(pending_excludes):
        items.append((f"{prefix}BX:{i}", f"{Colors.red('x')} {Colors.red('!' + pattern)}"))
    items.append((f"{prefix}ADD_EXCLUDE", f"{Colors.green('+')} Add exclude"))
    items.append((f"{prefix}BROWSE_EXCLUDE", f"{Colors.green('\u2295')} Browse"))
    items.append(("---", "\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500"))
    stale_label = "off" if stale_days == 0 else f"{stale_days} days"
    items.append((f"{prefix}STALE", f"Stale cutoff    {stale_label}"))
    items.append((f"{prefix}DONE", f"{Colors.green('\u2713')} Save and return"))
    return items


def handle_branch_filter_selection(
    selected: str,
    query: str,
    pending_priorities: List[str],
    pending_excludes: List[str],
    repos: List[str],
    prefix: str,
    pending_stale_days: Optional[List[int]] = None,
) -> Optional[str]:
    """Dispatch a branch-filter dialog selection.

    Mutates *pending_priorities* and *pending_excludes* in place.
    Launches a subprocess for BROWSE_* selections.

    Returns:
        ``"done"`` when the user confirms (DONE),
        ``"stale_input"`` when the user selects STALE (caller should switch to text input),
        ``None`` otherwise.
    """
    from ..fzf_bindings import get_exit_bindings

    if selected == f"{prefix}DONE":
        return "done"

    if selected == f"{prefix}STALE":
        return "stale_input"

    if selected == f"{prefix}ADD_PRIORITY" and query:
        if query not in pending_priorities:
            pending_priorities.append(query)
    elif selected == f"{prefix}ADD_EXCLUDE" and query:
        if query not in pending_excludes:
            pending_excludes.append(query)
    elif selected in (f"{prefix}BROWSE_PRIORITY", f"{prefix}BROWSE_EXCLUDE"):
        from .branch import collect_union_branches
        union = collect_union_branches(repos)
        total = len(repos)
        branch_lines = []
        for name, count in union:
            label = f"{name:<30} ({count}/{total} repos)"
            branch_lines.append(f"{name}\t{label}")
        if branch_lines:
            browse_result = subprocess.run(
                ["fzf", "--multi", "--ansi", "--no-sort",
                 "--height", "~50%",
                 "--header", "Select branch(es) | Enter=select | Esc=cancel",
                 "--prompt", "Branch: ",
                 "--with-nth", "2..",
                 "--delimiter", "\t",
                 ] + get_exit_bindings(mode="abort") + get_fzf_color_args(),
                input="\n".join(branch_lines),
                stdout=subprocess.PIPE, text=True,
            )
            if browse_result.returncode == 0 and browse_result.stdout.strip():
                is_priority = selected == f"{prefix}BROWSE_PRIORITY"
                target = pending_priorities if is_priority else pending_excludes
                for line in browse_result.stdout.strip().splitlines():
                    branch = line.split("\t")[0]
                    if branch and branch not in target:
                        target.append(branch)
    elif selected.startswith(f"{prefix}BP:"):
        try:
            idx = int(selected[len(f"{prefix}BP:"):])
            if 0 <= idx < len(pending_priorities):
                pending_priorities.pop(idx)
        except (ValueError, IndexError):
            pass
    elif selected.startswith(f"{prefix}BX:"):
        try:
            idx = int(selected[len(f"{prefix}BX:"):])
            if 0 <= idx < len(pending_excludes):
                pending_excludes.pop(idx)
        except (ValueError, IndexError):
            pass

    return None
