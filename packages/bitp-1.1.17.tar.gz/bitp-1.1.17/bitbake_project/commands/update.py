#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Update command - git pull/rebase layer repositories."""

import subprocess
import sys
from typing import List, Optional, Tuple

from ..core import (
    Colors,
    activate_custom_command,
    current_branch,
    delete_custom_command,
    get_custom_command,
    get_custom_commands,
    get_saved_custom_command,
    is_custom_default,
    load_defaults,
    save_custom_command,
    save_defaults,
)
from .common import (
    collect_repos,
    find_repo_by_identifier,
    load_resume,
    save_resume,
    prompt_action,
    run_cmd,
    repo_display_name,
)

def get_pull_args(repo: str, branch: str, rebase: bool) -> Tuple[List[str], str]:
    """Build git pull command args, using upstream tracking when available.

    Returns (cmd_args, description) where cmd_args is the full command list
    and description is a human-readable string of what will run.
    """
    from .branch import get_upstream_ref

    upstream = get_upstream_ref(repo, branch)
    cmd = ["git", "pull"]
    if rebase:
        cmd.append("--rebase")

    # If upstream is configured and isn't origin/{branch}, let git use
    # the tracking info (bare pull). Otherwise specify explicitly.
    if upstream and upstream != f"origin/{branch}":
        verb = "pull --rebase" if rebase else "pull"
        desc = f"git {verb}  (tracking: {upstream})"
    else:
        cmd.extend(["origin", branch])
        verb = "pull --rebase" if rebase else "pull"
        desc = f"git {verb} origin/{branch}"

    return cmd, desc


def run_update(args) -> int:
    defaults = load_defaults(args.defaults_file)
    discover_all = getattr(args, 'all', False)

    # Use persona-aware repo discovery
    persona = getattr(args, 'effective_persona', None)
    if persona and persona.name != "yocto":
        repos_list, repo_sets = persona.collect_repos(
            None, defaults, include_external=True, discover_all=discover_all,
        )
        repos = repos_list
    else:
        repos, repo_sets = collect_repos(args.bblayers, defaults, include_external=True, discover_all=discover_all)

    # Include non-layer repos (e.g. bitbake) — same pattern as explore.py:3078
    for ext_repo in repo_sets.external:
        if ext_repo not in repos:
            repos.append(ext_repo)

    # If specific repo requested, filter to just that one
    if getattr(args, 'repo', None):
        target_repo = find_repo_by_identifier(repos, args.repo, defaults)
        if not target_repo:
            print(f"Repo not found: {args.repo}")
            return 1
        repos = [target_repo]

    resume_state = load_resume(args.resume_file) if args.resume else None
    next_idx = 0
    if resume_state:
        saved_idx, saved_repos = resume_state
        if saved_repos == repos and 0 <= saved_idx < len(repos):
            next_idx = saved_idx
            print(f"Resuming from index {next_idx+1}/{len(repos)} using {args.resume_file}.")
        else:
            print("Resume data does not match current layer repos; starting over.")

    if args.resume:
        save_resume(args.resume_file, next_idx, repos)

    completed = False
    idx = next_idx - 1
    try:
        for idx in range(next_idx, len(repos)):
            repo = repos[idx]
            default_action = defaults.get(repo, "rebase")
            branch = current_branch(repo)
            if is_custom_default(default_action) and getattr(args, 'yes', False):
                custom_cmd = get_saved_custom_command(defaults, repo)
                if not custom_cmd:
                    # Legacy inline fallback
                    custom_cmd = get_custom_command(default_action) if default_action.startswith("custom:") else None
                if not custom_cmd:
                    print(f"Skipping {repo} (custom default set but no command saved).")
                    continue
                if not branch:
                    print(f"Skipping {repo} (detached HEAD or no branch).")
                    continue
                print(f"{repo_display_name(repo)}: custom ({custom_cmd})")
                action = ("custom", custom_cmd, None)
            elif getattr(args, 'yes', False):
                if not branch:
                    print(f"Skipping {repo} (detached HEAD or no branch).")
                    continue
                print(f"{repo_display_name(repo)}: {default_action} (branch: {branch})")
                action = (default_action, branch, None)
            else:
                action = prompt_action(repo, branch, default_action, defaults=defaults, use_fzf=not args.plain)
            if action is None:
                continue
            op, target, new_default = action

            if new_default:
                if new_default.startswith("custom:"):
                    rest = new_default[len("custom:"):]
                    if ":" in rest:
                        cname, cmd = rest.split(":", 1)
                        save_custom_command(defaults, repo, cmd, name=cname)
                    else:
                        # Name-only → activate existing; if not found, treat as legacy cmd
                        if not activate_custom_command(defaults, repo, rest):
                            save_custom_command(defaults, repo, rest)  # legacy: saves as "default"
                elif new_default.startswith("delete-custom:"):
                    dname = new_default[len("delete-custom:"):]
                    delete_custom_command(defaults, repo, name=dname)
                elif new_default == "delete-custom":
                    delete_custom_command(defaults, repo)
                else:
                    defaults[repo] = new_default
                save_defaults(args.defaults_file, defaults)

            if op == "quit":
                print("Aborting on user request.")
                break
            if op == "skip":
                if args.resume:
                    save_resume(args.resume_file, idx + 1, repos)
                continue

            if op == "custom":
                print(f"Custom command in {repo}")
                run_cmd(repo, target, args.dry_run, shell=True)
            else:
                cmd, desc = get_pull_args(repo, target, rebase=(op == "rebase"))
                print(f"Updating {repo}: {desc}")
                run_cmd(repo, cmd, args.dry_run)

            if args.resume:
                save_resume(args.resume_file, idx + 1, repos)
        else:
            completed = True
    except subprocess.CalledProcessError as exc:
        print(f"Command failed in {repo}: {exc}")
        return exc.returncode or 1

    if args.resume and completed and os.path.exists(args.resume_file):
        os.remove(args.resume_file)

    return 0


def get_repo_log(repo: str, branch: str, remote_exists: bool, max_commits: int, show_all: bool) -> Tuple[str, List[str]]:
    from .branch import get_upstream_ref
    remote_ref = get_upstream_ref(repo, branch) or f"origin/{branch}"
    log_args = ["git", "-C", repo, "log", "--oneline"]
    desc = ""
    if remote_exists:
        log_args.append(f"{remote_ref}..HEAD")
        desc = f"local commits vs {remote_ref}"
    else:
        log_args.extend(["-n", str(max_commits if not show_all else 1000000)])
        desc = f"recent commits (no {remote_ref})"

    try:
        out = subprocess.check_output(log_args, text=True)
    except subprocess.CalledProcessError:
        return "failed to read log", []

    lines = [line for line in out.strip().splitlines() if line.strip()]
    return desc, lines


def get_upstream_commits(repo: str, branch: str) -> List[str]:
    """Get commits in upstream tracking ref that are not in HEAD (pending upstream changes)."""
    from .branch import get_upstream_ref
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return []
    try:
        out = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"HEAD..{remote_ref}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
        return [line for line in out.strip().splitlines() if line.strip()]
    except subprocess.CalledProcessError:
        return []


def fetch_repo(repo: str) -> bool:
    """Fetch from the tracking remote (or origin if none configured)."""
    from .branch import get_upstream_ref
    branch = current_branch(repo)
    remote = "origin"
    if branch:
        upstream = get_upstream_ref(repo, branch)
        if upstream and "/" in upstream:
            remote = upstream.split("/")[0]
    try:
        subprocess.run(
            ["git", "-C", repo, "fetch", remote],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return True
    except subprocess.CalledProcessError:
        return False



def run_single_repo_update(repo: str, branch: str, action: str) -> bool:
    """Run update for a single repo. action: 'rebase' or 'merge'. Returns True on success."""
    if not branch:
        print(f"  No branch (detached HEAD)")
        return False

    if action not in ("rebase", "merge"):
        return False

    try:
        cmd, desc = get_pull_args(repo, branch, rebase=(action == "rebase"))
        print(f"  {desc}")
        subprocess.run(
            ["git", "-C", repo] + cmd[1:],
            check=True,
        )
        print(f"  Done.")
        return True
    except subprocess.CalledProcessError as e:
        print(f"  Failed: {e}")
        return False


