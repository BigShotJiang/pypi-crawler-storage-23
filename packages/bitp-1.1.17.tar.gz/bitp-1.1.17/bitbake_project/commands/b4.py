#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""b4 command - mail-based patch management (apply, send, trailers, diff)."""

import gzip
import hashlib
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import List, Optional, Tuple

from ..core import (
    Colors,
    fzf_available,
    get_fzf_color_args,
    load_defaults,
    save_defaults,
)

import json
from ..fzf_bindings import (
    get_action_binding,
    get_browser_bindings,
    get_position_binding,
    get_preview_header_suffix,
)
from .common import (
    build_inline_dialog_lines,
    resolve_bblayers_path,
    resolve_base_and_layers,
    repo_display_name,
)
from ..tui.inline_options import InlineOptionsState, build_lore_search_menu


# =============================================================================
# Tool Detection
# =============================================================================

def b4_available() -> bool:
    """Check if b4 is installed."""
    return shutil.which("b4") is not None


def _require_b4() -> bool:
    """Check if b4 is installed, printing an error if not. Returns True if available."""
    if not b4_available():
        print(f"{Colors.yellow('b4 is not installed.')} Install with: pip install b4")
        return False
    return True


def lei_available() -> bool:
    """Check if lei (public-inbox indexer) is installed."""
    return shutil.which("lei") is not None


# =============================================================================
# Known Mailing Lists
# =============================================================================

# Curated list of mailing lists commonly used in Yocto/OE/kernel development.
# Each entry: (list_address, lore_archive_name, description)
KNOWN_MAILING_LISTS = [
    ("openembedded-core@lists.openembedded.org", "openembedded-core", "OE-Core patches"),
    ("openembedded-devel@lists.openembedded.org", "openembedded-devel", "OE meta-layer patches"),
    ("yocto@lists.yoctoproject.org", "yocto", "Yocto Project general"),
    ("linux-yocto@lists.yoctoproject.org", "linux-yocto", "linux-yocto kernel patches"),
    ("bitbake-devel@lists.openembedded.org", "bitbake-devel", "BitBake development"),
    ("yocto-patches@lists.yoctoproject.org", "yocto-patches", "Yocto patches"),
    ("linux-kernel@vger.kernel.org", "linux-kernel", "Linux kernel (LKML)"),
    ("linux-arm-kernel@lists.infradead.org", "linux-arm-kernel", "ARM kernel"),
    ("linux-riscv@lists.infradead.org", "linux-riscv", "RISC-V kernel"),
    ("devicetree@vger.kernel.org", "devicetree", "Device Tree"),
    ("netdev@vger.kernel.org", "netdev", "Networking"),
    ("linux-wireless@vger.kernel.org", "linux-wireless", "Wireless"),
]

# Map repo URL patterns to likely mailing lists (index into KNOWN_MAILING_LISTS)
_REPO_LIST_HINTS = [
    (r"openembedded-core|oe-core|poky", 0),   # -> openembedded-core
    (r"meta-openembedded|meta-oe", 1),          # -> openembedded-devel
    (r"bitbake", 4),                            # -> bitbake-devel
    (r"linux-yocto|yocto-kernel", 3),           # -> linux-yocto
    (r"yocto", 2),                              # -> yocto general
    (r"linux", 6),                              # -> LKML (generic fallback for linux repos)
]


def _get_lore_manifest_cache_path() -> str:
    """Get path to lore manifest cache file."""
    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, "lore-manifest.json")


def _parse_lore_manifest(raw_data: bytes) -> dict:
    """Parse gzipped lore manifest into {list_name: description}.

    The manifest keys look like "/openembedded-core/git/0.git" — extract the
    list name and deduplicate across epochs (git/0.git, git/1.git are same list).
    """
    data = gzip.decompress(raw_data)
    # manifest.js.gz wraps JSON in a JS assignment: var defined = {...};
    text = data.decode("utf-8")
    # Strip JS wrapper to get raw JSON
    start = text.index("{")
    end = text.rindex("}") + 1
    manifest = json.loads(text[start:end])

    result = {}
    for key, info in manifest.items():
        # key like "/openembedded-core/git/0.git" or "/openembedded-core/"
        parts = key.strip("/").split("/")
        if not parts:
            continue
        name = parts[0]
        if name in result:
            continue  # Already seen (dedup epochs)
        desc = info.get("description", "")
        # Strip "[epoch N]" suffix from descriptions
        desc = re.sub(r"\s*\[epoch \d+\]\s*$", "", desc)
        result[name] = desc
    return result


def _fetch_lore_manifest(force: bool = False) -> Optional[dict]:
    """Fetch and cache the lore manifest. Returns {list_name: description} or None."""
    import urllib.error

    cache_path = _get_lore_manifest_cache_path()
    cache_max_age = 86400  # 24 hours

    # Check cache
    if not force and os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        return cache_data["data"]
        except (json.JSONDecodeError, OSError, KeyError):
            pass  # Cache invalid, fetch fresh

    # Fetch from lore
    url = "https://lore.kernel.org/manifest.js.gz"
    try:
        print(Colors.dim("Fetching lore manifest..."), end=" ", flush=True)
        with urllib.request.urlopen(url, timeout=30) as resp:
            raw = resp.read()
        result = _parse_lore_manifest(raw)
        print(Colors.dim("done"))

        # Save to cache
        try:
            with open(cache_path, "w") as f:
                json.dump({"timestamp": time.time(), "data": result}, f)
        except OSError:
            pass
        return result
    except (urllib.error.URLError, OSError) as e:
        print(Colors.dim("failed"))
        # Try stale cache
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        print(Colors.yellow(f"Using cached manifest (network error: {e})"))
                        return cache_data["data"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass
        return None
    except (ValueError, json.JSONDecodeError) as e:
        print(Colors.dim("failed"))
        print(f"Error parsing lore manifest: {e}")
        return None


def get_lore_manifest() -> dict:
    """Get the full lore manifest as {list_name: description}.

    Falls back to KNOWN_MAILING_LISTS if network and cache both fail.
    """
    result = _fetch_lore_manifest()
    if result is not None:
        return result
    return {lore: desc for _, lore, desc in KNOWN_MAILING_LISTS}


def _get_list_for_repo(repo: str, defaults: Optional[dict] = None) -> Optional[str]:
    """Get the lore mailing list name for a repo.

    Checks configured b4 repo config first, falls back to auto-detection
    from remote URL. Returns lore list name (e.g., "openembedded-core") or None.
    """
    if defaults is not None:
        cfg = get_b4_repo_config(defaults, repo)
        if cfg:
            lore_name = cfg.get("lore_name", "")
            if lore_name:
                return lore_name

    detected = _detect_lists_from_repo(repo, use_manifest=True)
    if detected:
        return detected[0][1]  # lore_name from first match

    return None


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class LoreResult:
    """A search result from lore.kernel.org."""
    msgid: str
    subject: str
    author: str
    date: str
    url: str
    content: str = ""  # Email body/summary from Atom feed


@dataclass
class LoreSearchContext:
    """Holds search parameters for load-more re-fetches."""
    query: str
    max_results: int = 20
    list_name: Optional[str] = None
    search_type: str = "subject"
    time_range: str = "2.years.ago.."
    threads: bool = False


# =============================================================================
# Lore Search Infrastructure
# =============================================================================

def _extract_msgid_from_url(url: str) -> str:
    """Extract message-id from a lore.kernel.org URL."""
    # https://lore.kernel.org/all/<msgid>/
    # https://lore.kernel.org/linux-kernel/<msgid>/
    m = re.search(r"lore\.kernel\.org/[^/]+/([^/]+)", url)
    if m:
        return urllib.parse.unquote(m.group(1))
    return url


def _normalize_msgid(msgid_or_url: str) -> str:
    """Normalize a message-id or URL to a bare message-id."""
    msgid_or_url = msgid_or_url.strip()
    if "lore.kernel.org" in msgid_or_url:
        return _extract_msgid_from_url(msgid_or_url)
    # Strip angle brackets
    return msgid_or_url.strip("<>")


def _parse_atom_entries(data: bytes, max_results: int = 20) -> List[LoreResult]:
    """Parse Atom XML data into LoreResult list."""
    results = []
    try:
        root = ET.fromstring(data)
        ns = {"atom": "http://www.w3.org/2005/Atom"}
        for entry in root.findall("atom:entry", ns)[:max_results]:
            title_el = entry.find("atom:title", ns)
            author_el = entry.find("atom:author/atom:name", ns)
            updated_el = entry.find("atom:updated", ns)
            link_el = entry.find("atom:link", ns)

            content_el = entry.find("atom:content", ns)

            title = title_el.text if title_el is not None and title_el.text else ""
            author = author_el.text if author_el is not None and author_el.text else ""
            date = updated_el.text if updated_el is not None and updated_el.text else ""
            if date and "T" in date:
                date = date.split("T")[0]
            link_url = link_el.get("href", "") if link_el is not None else ""
            msgid = _extract_msgid_from_url(link_url) if link_url else ""
            content = ""
            if content_el is not None:
                # type="xhtml" has content in child elements (div/pre),
                # itertext() extracts all nested text
                content = "".join(content_el.itertext()).strip()

            if msgid and title:
                results.append(LoreResult(
                    msgid=msgid, subject=title, author=author,
                    date=date, url=link_url, content=content,
                ))
    except ET.ParseError:
        pass
    return results


def _fetch_atom(url: str) -> bytes:
    """Fetch URL content. Returns bytes or empty on error."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "bit/1.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            return resp.read()
    except Exception:
        return b""


def _search_lore_atom(query: str, max_results: int = 20, list_name: str = "all",
                      search_type: str = "subject") -> List[LoreResult]:
    """Search lore.kernel.org via Atom feed (no dependencies needed).

    search_type: "subject" -> s: prefix, "filename" -> dfn: prefix, "body" -> b: prefix,
                 "any" -> no prefix (full-text search)
    """
    prefix_map = {"subject": "s:", "filename": "dfn:", "body": "b:", "any": ""}
    prefix = prefix_map.get(search_type, "s:")
    encoded = urllib.parse.quote(f"{prefix}{query}")
    url = f"https://lore.kernel.org/{list_name}/?q={encoded}&x=A"
    data = _fetch_atom(url)
    return _parse_atom_entries(data, max_results) if data else []


def _search_lei(query: str, max_results: int = 20, list_name: Optional[str] = None,
                search_type: str = "subject", time_range: str = "2.years.ago..",
                threads: bool = False) -> List[LoreResult]:
    """Search using lei (public-inbox local index) if available.

    list_name: scope to specific lore list (e.g., "openembedded-core") or None for "all"
    search_type: "subject" -> s:, "filename" -> dfn:, "body" -> b:, "any" -> no prefix
    time_range: lei rt: range (e.g., "2.years.ago..", "5.years.ago..", or "")
    threads: if True, pass --threads to lei for full thread expansion
    """
    if not lei_available():
        return []

    lore_url = f"https://lore.kernel.org/{list_name or 'all'}/"
    prefix_map = {"subject": "s:", "filename": "dfn:", "body": "b:", "any": ""}
    prefix = prefix_map.get(search_type, "s:")

    try:
        cmd = ["lei", "q", "-I", lore_url, "--format=json", "--sort=relevance",
               f"--limit={max_results}"]
        if threads:
            cmd.append("--threads")
        cmd.append(f"{prefix}{query}")
        if time_range:
            cmd.extend(["AND", f"rt:{time_range}"])
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        if result.returncode != 0:
            return []

        entries = json.loads(result.stdout)
        results = []
        for entry in entries[:max_results]:
            if not isinstance(entry, dict):
                continue
            subject = entry.get("Subject", "")
            msgid = entry.get("Message-ID", entry.get("m", ""))
            if isinstance(msgid, list):
                msgid = msgid[0] if msgid else ""
            msgid = msgid.strip("<>")
            author = entry.get("From", "")
            date = entry.get("Date", "")
            if date and " " in date:
                parts = date.split()
                date = " ".join(parts[:4]) if len(parts) >= 4 else date
            url_list = list_name or "all"
            url = f"https://lore.kernel.org/{url_list}/{urllib.parse.quote(msgid)}/"
            if msgid and subject:
                results.append(LoreResult(
                    msgid=msgid, subject=subject, author=author,
                    date=date, url=url,
                ))
        return results
    except Exception:
        return []


def lore_search(query: str, max_results: int = 20, list_name: Optional[str] = None,
                search_type: str = "subject", time_range: str = "2.years.ago..",
                threads: bool = False) -> List[LoreResult]:
    """Search lore.kernel.org. Tries lei first, falls back to Atom feed."""
    results = _search_lei(query, max_results, list_name=list_name,
                          search_type=search_type, time_range=time_range,
                          threads=threads)
    if results:
        return results
    # Atom fallback ignores time_range/threads — not supported
    return _search_lore_atom(query, max_results, list_name=list_name or "all",
                             search_type=search_type)


def _search_with_context(ctx: LoreSearchContext) -> List[LoreResult]:
    """Run lore_search using parameters from a LoreSearchContext."""
    return lore_search(ctx.query, max_results=ctx.max_results,
                       list_name=ctx.list_name, search_type=ctx.search_type,
                       time_range=ctx.time_range, threads=ctx.threads)


def _html_unescape(text: str) -> str:
    """Decode HTML entities like &#34; &#246; &amp; etc."""
    import html
    return html.unescape(text)


def _parse_lore_html_results(html: str, list_name: str, max_results: int) -> List[LoreResult]:
    """Parse lore.kernel.org HTML search results into LoreResult list."""
    results = []
    # Pattern: href="MSGID/">Subject</a> ... by Author @ YYYY-MM-DD HH:MM UTC
    # re.DOTALL so .*? crosses newlines between </a> and "by"
    for m in re.finditer(
        r'href="([^"]+)/"[^>]*>([^<]+)</a>.{0,200}?'
        r'by\s+(.+?)\s+@\s+(\d{4}-\d{2}-\d{2})',
        html,
        re.DOTALL,
    ):
        raw_msgid = m.group(1)
        subject = _html_unescape(m.group(2).strip())
        author = _html_unescape(m.group(3).strip().strip('"'))
        date = m.group(4)

        # Skip navigation links (start with _ or ? or #, or no @ and not numeric)
        if raw_msgid.startswith(("_", "?", "#")):
            continue
        if "@" not in raw_msgid and not re.match(r"^\d{14}", raw_msgid):
            continue

        msgid = urllib.parse.unquote(raw_msgid)
        # raw_msgid is already URL-safe (from the HTML href attribute),
        # so use it directly — re-encoding would double-encode %XX sequences
        url = f"https://lore.kernel.org/{list_name}/{raw_msgid}/"

        results.append(LoreResult(
            msgid=msgid, subject=subject, author=author,
            date=date, url=url,
        ))
        if len(results) >= max_results:
            break
    return results


def lore_browse_list(list_name: str, max_results: int = 200, days: int = 14) -> List[LoreResult]:
    """Browse recent activity on a specific lore.kernel.org mailing list.

    Uses HTML search with date range for proper history depth.
    Falls back to Atom feed if HTML parsing fails.
    """
    # Try HTML search with date range (much better coverage than /new.atom)
    encoded_q = urllib.parse.quote(f"d:{days}d..")
    url = f"https://lore.kernel.org/{list_name}/?q={encoded_q}"
    data = _fetch_atom(url)  # reuse fetcher, returns bytes
    if data:
        html = data.decode("utf-8", errors="replace")
        results = _parse_lore_html_results(html, list_name, max_results)
        if results:
            return results

    # Fallback to Atom feed (only returns very recent posts)
    atom_url = f"https://lore.kernel.org/{list_name}/new.atom"
    data = _fetch_atom(atom_url)
    return _parse_atom_entries(data, max_results) if data else []


def lore_search_for_commit(repo: str, commit_hash: str,
                           defaults: Optional[dict] = None) -> Tuple[Optional[str], List[LoreResult]]:
    """Search lore for a commit. Returns (direct_msgid_if_found, search_results).

    Checks commit body for Link: or Message-Id: headers first.
    Uses repo context to scope search to the appropriate mailing list.
    """
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "-1", "--format=%s%n%n%b", commit_hash],
            text=True,
        )
    except subprocess.CalledProcessError:
        return None, []

    lines = output.strip().split("\n")
    subject = lines[0] if lines else ""
    body = "\n".join(lines[1:]) if len(lines) > 1 else ""

    # Check for existing Link: or Message-Id: in commit body
    for line in body.split("\n"):
        line = line.strip()
        if line.startswith("Link:") and "lore.kernel.org" in line:
            url = line.split("Link:", 1)[1].strip()
            msgid = _extract_msgid_from_url(url)
            if msgid:
                return msgid, []
        if line.startswith("Message-Id:") or line.startswith("Message-ID:"):
            msgid = line.split(":", 1)[1].strip().strip("<>")
            if msgid:
                return msgid, []

    # Search by subject, scoped to repo's mailing list
    if subject:
        list_name = _get_list_for_repo(repo, defaults)
        results = lore_search(subject, max_results=20, list_name=list_name)
        return None, results

    return None, []


def lore_search_for_file(repo: str, filepath: str,
                         defaults: Optional[dict] = None) -> List[LoreResult]:
    """Search lore for patches that touch a specific file.

    Uses dfn: (filename) search type with lei, falls back to basename
    keyword search for Atom feed (full paths don't match well).
    """
    list_name = _get_list_for_repo(repo, defaults)
    basename = os.path.basename(filepath)

    # Try filename search with lei first (supports dfn: natively)
    if lei_available():
        results = _search_lei(basename, max_results=20, list_name=list_name,
                              search_type="filename")
        if results:
            return results

    # Atom fallback: use basename as keyword (dfn: works in lore web search too)
    return _search_lore_atom(basename, max_results=20,
                             list_name=list_name or "all",
                             search_type="filename")


# =============================================================================
# Mailing List Discovery
# =============================================================================

def _detect_lists_from_repo(repo: str, use_manifest: bool = False) -> List[Tuple[str, str, str]]:
    """Auto-detect likely mailing lists from repo remote URL.

    Stage 1: Match against _REPO_LIST_HINTS (fast, offline, authoritative).
    Stage 2 (use_manifest=True): Match repo basename against lore manifest keys.
              Only used when the user takes an action that needs the list —
              never during menu/display rendering to avoid blocking on fetch.

    Returns list of (address, lore_name, description) tuples.
    """
    try:
        url = subprocess.check_output(
            ["git", "-C", repo, "config", "--get", "remote.origin.url"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        return []

    # Stage 1: known hints (fast, offline)
    detected = []
    url_lower = url.lower()
    for pattern, list_idx in _REPO_LIST_HINTS:
        if re.search(pattern, url_lower):
            detected.append(KNOWN_MAILING_LISTS[list_idx])
            break  # Use best match only
    if detected:
        return detected

    if not use_manifest:
        return []

    # Stage 2: match against lore manifest
    manifest = get_lore_manifest()
    if not manifest:
        return []

    basename = os.path.basename(repo.rstrip("/"))
    candidates = [
        basename,                    # exact match
        f"yocto-{basename}",        # e.g., repo "docs" → "yocto-docs"
        f"{basename}-devel",         # e.g., repo "foo" → "foo-devel"
    ]
    for name in candidates:
        if name in manifest:
            addr = f"{name}@lists"
            return [(addr, name, manifest[name])]
    return []


def _get_recent_lists(defaults_file: str = ".bit.defaults") -> List[str]:
    """Get recently used mailing lists from config."""
    defaults = load_defaults(defaults_file)
    recent = defaults.get("b4_recent_lists", "")
    if recent:
        return [l.strip() for l in recent.split(",") if l.strip()]
    return []


def _save_recent_list(list_address: str, defaults_file: str = ".bit.defaults") -> None:
    """Save a mailing list to the recently-used list."""
    defaults = load_defaults(defaults_file)
    recent = defaults.get("b4_recent_lists", "")
    items = [l.strip() for l in recent.split(",") if l.strip()]
    # Remove if already there, then prepend
    items = [l for l in items if l != list_address]
    items.insert(0, list_address)
    items = items[:5]  # Keep at most 5
    defaults["b4_recent_lists"] = ",".join(items)
    save_defaults(defaults_file, defaults)


def fzf_pick_mailing_list(repo: Optional[str] = None) -> Optional[Tuple[str, str]]:
    """Interactive mailing list picker. Returns (address, lore_archive_name) or None.

    Shows: auto-detected lists for repo, recently used, then full curated list.
    """
    if not fzf_available():
        # Text fallback
        print("\nMailing lists:")
        for i, (addr, lore, desc) in enumerate(KNOWN_MAILING_LISTS, 1):
            print(f"  {i:2d}. {desc:30s} {addr}")
        try:
            choice = input("\nSelect number (or Enter to cancel): ").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(KNOWN_MAILING_LISTS):
                entry = KNOWN_MAILING_LISTS[int(choice) - 1]
                return entry[0], entry[1]
        except (EOFError, KeyboardInterrupt):
            pass
        return None

    # Build sections: detected, recent, all known
    menu_lines = []
    seen_addrs = set()

    # Section 1: auto-detected from repo
    if repo:
        detected = _detect_lists_from_repo(repo, use_manifest=True)
        if detected:
            menu_lines.append("---\t" + Colors.bold("  Detected for this repo"))
            for addr, lore, desc in detected:
                menu_lines.append(f"{addr}\t{lore}\t{Colors.green(desc):30s}  {addr}")
                seen_addrs.add(addr)

    # Section 2: recently used
    recent = _get_recent_lists()
    if recent:
        menu_lines.append("---\t" + Colors.bold("  Recently used"))
        for addr in recent:
            if addr in seen_addrs:
                continue
            # Look up description
            entry = next((e for e in KNOWN_MAILING_LISTS if e[0] == addr), None)
            if entry:
                menu_lines.append(f"{addr}\t{entry[1]}\t{entry[2]:30s}  {addr}")
            else:
                # Custom list not in known list
                lore = addr.split("@")[0] if "@" in addr else addr
                menu_lines.append(f"{addr}\t{lore}\t{'(custom)':30s}  {addr}")
            seen_addrs.add(addr)

    # Section 3: all lore mailing lists (from manifest, fallback to known)
    manifest = get_lore_manifest()
    menu_lines.append("---\t" + Colors.bold("  All lore mailing lists"))
    for name in sorted(manifest):
        desc = manifest[name]
        # Build an address placeholder for manifest entries
        addr_key = f"{name}@lists"
        if addr_key in seen_addrs:
            continue
        # Also skip if the known-list address was already shown
        known_match = next((e for e in KNOWN_MAILING_LISTS if e[1] == name), None)
        if known_match and known_match[0] in seen_addrs:
            continue
        menu_lines.append(f"{addr_key}\t{name}\t{desc:30s}  {name}")

    # Section 4: custom entry option
    menu_lines.append("---\t" + Colors.dim("  ───────────────────"))
    menu_lines.append(f"CUSTOM\t_custom\t{'Enter a custom address...':30s}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort",
                "--no-multi",
                "--ansi",
                "--height", "~20",
                "--header", "Select mailing list (type to filter)",
                "--prompt", "List: ",
                "--with-nth", "3..",
                "--delimiter", "\t",
            ] + get_browser_bindings() + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    output = result.stdout.strip()
    if output == "BACK":
        return None

    parts = output.split("\t")
    addr = parts[0]
    lore_name = parts[1] if len(parts) > 1 else ""

    if addr in ("---", ""):
        return None

    if addr == "CUSTOM":
        try:
            addr = input("Mailing list address: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if not addr:
            return None
        lore_name = addr.split("@")[0] if "@" in addr else addr

    _save_recent_list(addr)
    return addr, lore_name


# =============================================================================
# Global B4 Config (~/.config/bit/b4.json)
# =============================================================================

def _get_global_b4_config_path() -> str:
    """Return path to global b4 config, creating directory if needed."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "b4.json")


def load_global_b4_config() -> dict:
    """Load global b4 defaults from ~/.config/bit/b4.json."""
    path = _get_global_b4_config_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (json.JSONDecodeError, OSError):
        return {}


def save_global_b4_config(config: dict) -> None:
    """Save global b4 defaults to ~/.config/bit/b4.json."""
    path = _get_global_b4_config_path()
    with open(path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2, sort_keys=True)


def get_b4_setting(defaults: dict, key: str) -> str:
    """Get a b4 setting, trying project config first, then global defaults.

    Portable keys (b4_default_list, b4_midmask, b4_auto_trailers) are stored
    as strings in .bit.defaults.  Global fallbacks are in ~/.config/bit/b4.json.
    """
    val = defaults.get(key, "")
    if val:
        return val
    # Fall back to global
    global_cfg = load_global_b4_config()
    # Map project key names to global key names (strip "b4_" prefix)
    global_key = key.replace("b4_", "", 1) if key.startswith("b4_") else key
    return str(global_cfg.get(global_key, ""))


# =============================================================================
# Per-Project Repo ↔ Mailing List Config (__b4_repos__)
# =============================================================================

def get_b4_repo_config(defaults: dict, repo_path: str) -> Optional[dict]:
    """Get b4 config for a specific repo. Returns dict or None.

    Stored in __b4_repos__[repo_path] = {"mailing_list": ..., "lore_name": ...}
    """
    repos = defaults.get("__b4_repos__", {})
    return repos.get(repo_path)


def set_b4_repo_config(
    defaults_file: str,
    defaults: dict,
    repo_path: str,
    mailing_list: str,
    lore_name: str,
) -> None:
    """Save b4 config for a specific repo."""
    repos = defaults.get("__b4_repos__", {})
    repos[repo_path] = {
        "mailing_list": mailing_list,
        "lore_name": lore_name,
    }
    defaults["__b4_repos__"] = repos
    save_defaults(defaults_file, defaults)


def remove_b4_repo_config(defaults_file: str, defaults: dict, repo_path: str) -> None:
    """Remove b4 config for a specific repo."""
    repos = defaults.get("__b4_repos__", {})
    if repo_path in repos:
        del repos[repo_path]
        defaults["__b4_repos__"] = repos
        save_defaults(defaults_file, defaults)


def _get_configured_repos(defaults: dict) -> dict:
    """Get all configured b4 repos. Returns {repo_path: {mailing_list, lore_name}}."""
    return defaults.get("__b4_repos__", {})


def _repo_branch(repo: str) -> str:
    """Get current branch name for a repo."""
    try:
        return subprocess.check_output(
            ["git", "-C", repo, "branch", "--show-current"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        return ""


# =============================================================================
# Message-ID Discovery
# =============================================================================

def _get_recent_commits(repo: str, count: int = 30) -> List[Tuple[str, str, str]]:
    """Get recent commit hashes, subjects, and authors from a repo.

    Returns list of (hash, subject, author_date) tuples.
    """
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", f"-{count}", "--format=%H\t%s\t%ad",
             "--date=short"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        return []

    commits = []
    for line in output.split("\n"):
        if not line.strip():
            continue
        parts = line.split("\t", 2)
        if len(parts) >= 2:
            h = parts[0]
            subj = parts[1]
            date = parts[2] if len(parts) > 2 else ""
            commits.append((h, subj, date))
    return commits


def fzf_discover_msgid(repo: Optional[str] = None) -> Optional[str]:
    """Interactive message-id discovery. Returns a message-id string or None.

    Offers multiple ways to find a patch series:
    - Search lore by keyword
    - Pick from recent repo commits (and search lore for the subject)
    - Browse recent activity on a mailing list
    - Enter a message-id / URL directly
    """
    if not fzf_available():
        # Text fallback: just search or manual
        try:
            print("\n1. Search lore by keyword")
            print("2. Enter message-id or URL")
            choice = input("Choice [1]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if choice == "2":
            try:
                return input("Message-Id or lore URL: ").strip() or None
            except (EOFError, KeyboardInterrupt):
                print()
                return None
        try:
            query = input("Search terms: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return None
        if not query:
            return None
        print("Searching...")
        results = lore_search(query)
        selected = fzf_pick_lore_result(results)
        return selected.msgid if selected else None

    # Build the discovery method picker
    methods = [
        "SEARCH\tSearch lore.kernel.org by keyword",
    ]
    if repo:
        methods.append("COMMITS\tPick from recent commits in this repo")
    methods.append("BROWSE\tBrowse recent mailing list activity")
    methods.append("DIRECT\tEnter message-id or URL directly")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort",
                "--no-multi",
                "--height", "~8",
                "--header", "How to find the patch series?",
                "--prompt", "> ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_browser_bindings() + get_fzf_color_args(),
            input="\n".join(methods),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    output = result.stdout.strip()
    if output == "BACK":
        return None

    method = output.split("\t")[0]

    if method == "SEARCH":
        return _discover_via_search()
    elif method == "COMMITS":
        return _discover_via_commits(repo)
    elif method == "BROWSE":
        return _discover_via_browse(repo)
    elif method == "DIRECT":
        return _discover_via_direct_input()

    return None


def _discover_via_search() -> Optional[str]:
    """Search lore by keyword and pick a result."""
    try:
        query = input("Search lore.kernel.org: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    if not query:
        return None
    print("Searching...")
    results = lore_search(query)
    selected = fzf_pick_lore_result(results)
    return selected.msgid if selected else None


def _discover_via_commits(repo: str) -> Optional[str]:
    """Pick a recent commit, then search lore for its subject."""
    commits = _get_recent_commits(repo, count=40)
    if not commits:
        print("No commits found in repo")
        return None

    menu_lines = []
    for h, subj, date in commits:
        menu_lines.append(f"{h}\t{date}  {subj}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort",
                "--no-multi",
                "--ansi",
                "--height", "~20",
                "--header", "Pick a commit to search lore for its subject",
                "--prompt", "Commit: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
                "--preview", f"git -C {repo} log -1 --stat {{1}}",
                "--preview-window", "right:50%:wrap",
            ] + get_browser_bindings() + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None
    output = result.stdout.strip()
    if output == "BACK":
        return None

    commit_hash = output.split("\t")[0]

    # Search lore for this commit
    print("Searching lore...")
    direct_msgid, results = lore_search_for_commit(repo, commit_hash)
    if direct_msgid:
        print(f"Found message-id in commit: {direct_msgid}")
        return direct_msgid

    selected = fzf_pick_lore_result(results)
    return selected.msgid if selected else None


def _discover_via_browse(repo: Optional[str] = None) -> Optional[str]:
    """Browse recent mailing list activity and pick a thread."""
    picked = fzf_pick_mailing_list(repo=repo)
    if not picked:
        return None

    _addr, lore_name = picked
    print(f"Fetching recent posts from {lore_name}...")
    results = lore_browse_list(lore_name)
    if not results:
        print(f"No results from {lore_name}")
        return None

    selected = fzf_pick_lore_result(results)
    return selected.msgid if selected else None


def _discover_via_direct_input() -> Optional[str]:
    """Manual message-id / URL entry."""
    try:
        val = input("Message-Id or lore URL: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return None
    return val if val else None


# =============================================================================
# fzf Pickers
# =============================================================================

def _build_lore_menu_data(
    results: List[LoreResult],
) -> Tuple[List[str], str]:
    """Build fzf menu lines and preview infrastructure for lore results.

    Returns (menu_lines, preview_dir).  Caller must clean up preview_dir.
    """
    preview_dir = tempfile.mkdtemp(prefix="b4-preview-")

    # Threading heuristic: normalize subjects (strip Re:, list tags like
    # [PATCH v2 3/5], version suffixes) to a base key, then group replies
    # under their parent.  Depth is capped at 3 to keep display readable.
    def _thread_key(subject: str) -> str:
        s = subject.strip()
        s = re.sub(r'^(Re|Fwd):\s*', '', s, flags=re.IGNORECASE)
        s = re.sub(r'^(Re|Fwd):\s*', '', s, flags=re.IGNORECASE)
        s = re.sub(r'\[[\w/. -]*\]\s*', '', s)
        return s.strip().lower()

    thread_roots: dict = {}
    thread_depth: dict = {}
    for i, r in enumerate(results):
        key = _thread_key(r.subject)
        is_reply = bool(re.match(r'^(Re|Fwd):', r.subject, re.IGNORECASE))
        if key in thread_roots and is_reply:
            depth = len(re.findall(r'(?:Re|Fwd):\s*', r.subject, re.IGNORECASE))
            thread_depth[i] = min(depth, 3)
        else:
            if key not in thread_roots:
                thread_roots[key] = i
            thread_depth[i] = 0

    menu_lines = []
    for i, r in enumerate(results):
        depth = thread_depth.get(i, 0)
        indent = "  " * depth
        display = f"{r.date}  {indent}{r.subject}  ({r.author})"
        menu_lines.append(f"{i}\t{display}")

        with open(os.path.join(preview_dir, f"{i}.url"), "w") as pf:
            pf.write(f"{r.url}raw\n")
        with open(os.path.join(preview_dir, f"{i}.info"), "w") as pf:
            pf.write(f"Subject: {r.subject}\n")
            pf.write(f"From: {r.author}\n")
            pf.write(f"Date: {r.date}\n")
            pf.write(f"URL: {r.url}\n")
            if r.content:
                pf.write(f"\n{r.content}\n")

    # Reverse so newest is at visual top
    menu_lines.reverse()

    # Python preview fetcher — decodes MIME, filters verbose headers
    bat_cmd = shutil.which("bat") or shutil.which("batcat") or ""
    fetch_script = os.path.join(preview_dir, "fetch.py")
    with open(fetch_script, "w") as fs:
        fs.write(f"""#!/usr/bin/env python3
import sys, os, email, email.policy

_KEEP = ("From", "To", "Cc", "Subject", "Date", "Message-Id",
         "In-Reply-To", "List-Id")

def _decode_email(raw_bytes):
    msg = email.message_from_bytes(raw_bytes, policy=email.policy.default)
    hdr_lines = []
    for name in _KEEP:
        val = msg.get(name)
        if val:
            hdr_lines.append(f"{{name}}: {{val}}")
    body = ""
    if msg.is_multipart():
        for part in msg.walk():
            if part.get_content_type() == "text/plain":
                payload = part.get_content()
                if isinstance(payload, str):
                    body = payload
                    break
    else:
        payload = msg.get_content()
        if isinstance(payload, str):
            body = payload
    return "\\n".join(hdr_lines) + "\\n\\n" + body

idx = sys.argv[1] if len(sys.argv) > 1 else ""
base = {preview_dir!r}
url_file = os.path.join(base, idx + ".url")
info_file = os.path.join(base, idx + ".info")
if os.path.isfile(url_file):
    with open(url_file) as f:
        url = f.read().strip()
    if url:
        try:
            import urllib.request
            req = urllib.request.Request(url, headers={{"User-Agent": "bit/1.0"}})
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw_bytes = resp.read()
            sys.stdout.write(_decode_email(raw_bytes))
            sys.exit(0)
        except Exception:
            pass
if os.path.isfile(info_file):
    with open(info_file) as f:
        sys.stdout.write(f.read())
""")
    os.chmod(fetch_script, 0o755)

    preview_script = os.path.join(preview_dir, "preview.sh")
    with open(preview_script, "w") as ps:
        ps.write("#!/bin/sh\n")
        if bat_cmd:
            ps.write(f'python3 "{fetch_script}" "$1" 2>/dev/null | '
                     f'{bat_cmd} --style=plain --color=always --language=Email 2>/dev/null\n')
        else:
            ps.write(f'python3 "{fetch_script}" "$1" 2>/dev/null\n')
    os.chmod(preview_script, 0o755)

    return menu_lines, preview_dir


# Actions for the inline action dialog in the lore browser
_LORE_ACTIONS = [
    ("VIEW", "View full thread"),
    ("APPLY", "Apply patch series (b4 am + git am)"),
    ("SHAZAM", "Apply directly (b4 shazam)"),
    ("PR", "Fetch pull request (b4 pr)"),
    ("MBOX", "Download thread as mbox"),
    ("TRAILERS", "Show collected trailers (Reviewed-by, Acked-by)"),
    ("CHECK", "Check for newer version of this series"),
    ("DIFF", "Compare with another series version"),
    ("COPY", "Copy message-id to clipboard"),
]

# Post-mbox-download actions (replace _LORE_ACTIONS after download)
_MBOX_ACTIONS = [
    ("MBOX_APPLY", "Apply as clean series (b4 am)"),
    ("MBOX_RAW", "Apply raw mbox (git am)"),
    ("MBOX_DONE", "Done, keep files only"),
]

# Post-PR-fetch actions (replace _LORE_ACTIONS after b4 pr)
_PR_ACTIONS = [
    ("PR_MERGE", "Merge FETCH_HEAD into current branch"),
    ("PR_LOG", "View fetched commits (git log FETCH_HEAD)"),
    ("PR_DONE", "Done, keep in FETCH_HEAD only"),
]

_LORE_ACT_PREFIX = "LOREACT:"
_SEARCH_OPT_PREFIX = "SOPT:"

# Search scope options: (key, time_range, threads, search_type, label)
_SEARCH_SCOPE_OPTIONS = [
    ("any_2yr", "2.years.ago..", False, "any",      "Any field — last 2 years"),
    ("any_5yr", "5.years.ago..", False, "any",      "Any field — last 5 years"),
    ("any_all", "",              False, "any",      "Any field — all time"),
    ("---1",    "",              False, "",          ""),
    ("sub_2yr", "2.years.ago..", False, "subject",  "Subject only — last 2 years"),
    ("sub_5yr", "5.years.ago..", False, "subject",  "Subject only — last 5 years"),
    ("sub_all", "",              False, "subject",  "Subject only — all time"),
    ("---2",    "",              False, "",          ""),
    ("thr_2yr", "2.years.ago..", True,  "any",      "Any field + threads — last 2 years"),
    ("thr_5yr", "5.years.ago..", True,  "any",      "Any field + threads — last 5 years"),
    ("thr_all", "",              True,  "any",      "Any field + threads — all time"),
]


def fzf_pick_lore_result(results: List[LoreResult]) -> Optional[LoreResult]:
    """Simple lore picker (no actions). Used by callers without repo context."""
    if not results:
        print("No results found on lore.kernel.org")
        return None

    if not fzf_available():
        print("\nSearch results:")
        for i, r in enumerate(results, 1):
            print(f"  {i}. [{r.date}] {r.subject}")
            print(f"     {r.author}")
        try:
            choice = input("\nSelect number (or Enter to cancel): ").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(results):
                return results[int(choice) - 1]
        except (EOFError, KeyboardInterrupt):
            pass
        return None

    menu_lines, preview_dir = _build_lore_menu_data(results)
    preview_script = os.path.join(preview_dir, "preview.sh")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort", "--ansi", "--height", "100%",
                "--header", f"Lore — newest first (Enter=select, q=back)\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", "Result: ",
                "--with-nth", "2..", "--delimiter", "\t",
                "--preview", f"{preview_script} {{1}}",
                "--preview-window", "right:50%:wrap",
                "--bind", "load:last",
            ] + get_browser_bindings() + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE, text=True,
        )
    except FileNotFoundError:
        return None
    finally:
        import shutil as _shutil
        _shutil.rmtree(preview_dir, ignore_errors=True)

    if result.returncode != 0 or not result.stdout.strip():
        return None
    output = result.stdout.strip()
    if output == "BACK":
        return None
    try:
        return results[int(output.split("\t")[0])]
    except (ValueError, IndexError):
        return None


def fzf_lore_browser(results: List[LoreResult], repo: str,
                     search_context: Optional[LoreSearchContext] = None) -> None:
    """Full lore browser with inline action dialog.

    Browse results → select a message → inline action items pop up from
    bottom of the same list → execute action → return to browse.
    Same pattern as the recipe options / repo action dialog.

    search_context: if provided, a "(load more results...)" entry appears when
    result count reaches the limit; selecting it doubles the limit and re-fetches.
    """
    if not results:
        from .common import log_message
        log_message("No results found on lore.kernel.org")
        return

    if not fzf_available():
        selected = fzf_pick_lore_result(results)
        if selected:
            print(f"\nMessage-Id: {selected.msgid}\nURL: {selected.url}")
            input("Press Enter to continue...")
        return

    menu_lines, preview_dir = _build_lore_menu_data(results)
    if search_context:
        if len(results) >= search_context.max_results:
            menu_lines.insert(0, f"LOAD_MORE\t{Colors.magenta('(load more results...)')}")
        menu_lines.insert(0, f"SEARCH_OPTIONS\t{Colors.magenta('(search options...)')}")
    preview_script = os.path.join(preview_dir, "preview.sh")

    has_b4 = b4_available()
    show_actions = False
    show_search_options = False
    selected_result: Optional[LoreResult] = None
    current_actions = None  # which action list to show
    action_header = ""      # extra context line for action menu
    mbox_tmpdir = None      # set after mbox download

    try:
      while True:
        # Build fzf input: action dialog (if active) + lore results
        fzf_input_lines = list(menu_lines)

        if show_search_options:
            # Search options inline popup (same pattern as action dialog)
            opt_lines = []
            for skey, _tr, _th, _st, label in _SEARCH_SCOPE_OPTIONS:
                if skey.startswith("---"):
                    opt_lines.append(f"---\t{Colors.cyan('│')}  ──────────────────")
                else:
                    opt_lines.append(f"{_SEARCH_OPT_PREFIX}{skey}\t{Colors.cyan('│')}  {label}")
            opt_lines.append(f"---\t{Colors.cyan('┌─ Search options ' + '─' * 30)}")
            fzf_input_lines = opt_lines + fzf_input_lines
        elif show_actions and selected_result:
            # Pick action list
            if current_actions is None:
                actions = _LORE_ACTIONS if has_b4 else [_LORE_ACTIONS[0], _LORE_ACTIONS[-1]]
            else:
                actions = current_actions

            # Prepend action lines (first in input = visual bottom, near prompt)
            act_lines = []
            for key, label in actions:
                act_lines.append(f"{_LORE_ACT_PREFIX}{key}\t{Colors.cyan('│')}  {label}")
            subj_short = selected_result.subject[:50]
            act_lines.append(f"---\t{Colors.cyan(f'┌─ {subj_short} ' + '─' * max(0, 40 - len(subj_short)))}")
            fzf_input_lines = act_lines + fzf_input_lines

        fzf_cmd = [
            "fzf",
            "--no-sort", "--ansi", "--height", "100%",
            "--with-nth", "2..", "--delimiter", "\t",
            "--preview", f"{preview_script} {{1}}",
            "--preview-window", "right:50%:wrap",
        ]

        if show_search_options:
            fzf_cmd.extend([
                "--disabled",
                "--header", f"Select search scope — Esc=back\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", "Option: ",
            ])
        elif show_actions:
            header_parts = []
            if action_header:
                header_parts.append(action_header)
            header_parts.append(f"Message-Id: {selected_result.msgid[:72]}")
            header_parts.append("Select action — Esc=back")
            header_parts.append(get_preview_header_suffix())
            fzf_cmd.extend([
                "--disabled",
                "--header", "\n".join(header_parts),
                "--prompt", "Action: ",
            ])
        else:
            fzf_cmd.extend([
                "--header", f"Lore — newest first (Enter=actions, q=quit)\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", "Result: ",
                "--bind", "load:last",
            ])

        fzf_cmd.extend(get_browser_bindings())
        fzf_cmd.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_cmd,
                input="\n".join(fzf_input_lines),
                stdout=subprocess.PIPE, text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            if show_search_options:
                show_search_options = False
                continue
            if show_actions:
                # Esc in sub-action menu → back to main actions
                if current_actions is not None:
                    current_actions = None
                    action_header = ""
                    continue
                show_actions = False
                continue
            return

        output = result.stdout.strip()
        if output == "BACK":
            if show_search_options:
                show_search_options = False
                continue
            if show_actions:
                if current_actions is not None:
                    current_actions = None
                    action_header = ""
                    continue
                show_actions = False
                continue
            return

        key = output.split("\t")[0]

        if show_search_options:
            if key.startswith(_SEARCH_OPT_PREFIX):
                opt_key = key[len(_SEARCH_OPT_PREFIX):]
                for skey, tr, th, st, _label in _SEARCH_SCOPE_OPTIONS:
                    if skey == opt_key:
                        search_context.time_range = tr
                        search_context.threads = th
                        search_context.search_type = st
                        search_context.max_results = 20
                        print(f"Searching ({_label})...")
                        results = _search_with_context(search_context)
                        import shutil as _shutil
                        _shutil.rmtree(preview_dir, ignore_errors=True)
                        menu_lines, preview_dir = _build_lore_menu_data(results)
                        if search_context:
                            if len(results) >= search_context.max_results:
                                menu_lines.insert(0, f"LOAD_MORE\t{Colors.magenta('(load more results...)')}")
                            menu_lines.insert(0, f"SEARCH_OPTIONS\t{Colors.magenta('(search options...)')}")
                        preview_script = os.path.join(preview_dir, "preview.sh")
                        break
            show_search_options = False
            continue

        if show_actions:
            if key.startswith(_LORE_ACT_PREFIX):
                action = key[len(_LORE_ACT_PREFIX):]

                # Post-mbox actions stay in-menu
                if action == "MBOX_APPLY":
                    show_actions = False
                    current_actions = None
                    action_header = ""
                    b4_apply(repo, _normalize_msgid(selected_result.msgid), method="am")
                    input("Press Enter to continue...")
                    continue
                elif action == "MBOX_RAW":
                    show_actions = False
                    current_actions = None
                    action_header = ""
                    if mbox_tmpdir:
                        mbox_files = [f for f in os.listdir(mbox_tmpdir) if f.endswith((".mbx", ".mbox"))]
                        if mbox_files:
                            mbox_path = os.path.join(mbox_tmpdir, mbox_files[0])
                            print(f"\nApplying {mbox_files[0]}...")
                            am_result = subprocess.run(["git", "am", mbox_path], cwd=repo)
                            if am_result.returncode != 0:
                                print(f"\n{Colors.yellow('git am failed. You may need to resolve conflicts.')}")
                                print(f"  git am --abort   # to abort")
                                print(f"  git am --skip    # to skip this patch")
                                print(f"  git am --continue  # after resolving")
                            input("Press Enter to continue...")
                    continue
                elif action == "MBOX_DONE":
                    current_actions = None
                    action_header = ""
                    show_actions = False
                    continue

                # MBOX action: download, then swap to post-mbox menu
                if action == "MBOX":
                    tmpdir = b4_mbox(repo, _normalize_msgid(selected_result.msgid))
                    if tmpdir:
                        mbox_tmpdir = tmpdir
                        files = sorted(os.listdir(tmpdir))
                        action_header = "Downloaded: " + ", ".join(
                            f for f in files if f.endswith((".mbx", ".mbox"))
                        )
                        current_actions = _MBOX_ACTIONS
                    else:
                        show_actions = False
                    continue

                # PR action: fetch, then swap to post-PR menu
                if action == "PR":
                    rc = b4_pr(repo, _normalize_msgid(selected_result.msgid))
                    if rc == 0:
                        # Show what was fetched
                        log_result = subprocess.run(
                            ["git", "log", "--oneline", "-10", "FETCH_HEAD"],
                            cwd=repo, capture_output=True, text=True,
                        )
                        commits = log_result.stdout.strip() if log_result.returncode == 0 else ""
                        count = len(commits.splitlines()) if commits else 0
                        action_header = f"Fetched {count} commit(s) to FETCH_HEAD"
                        current_actions = _PR_ACTIONS
                    else:
                        show_actions = False
                    continue

                # Post-PR actions
                if action == "PR_MERGE":
                    show_actions = False
                    current_actions = None
                    action_header = ""
                    display = repo_display_name(repo)
                    print(f"\nMerging FETCH_HEAD into current branch in {Colors.bold(display)}...")
                    merge_result = subprocess.run(
                        ["git", "merge", "FETCH_HEAD", "--no-edit"],
                        cwd=repo,
                    )
                    if merge_result.returncode != 0:
                        print(f"\n{Colors.yellow('Merge failed. You may need to resolve conflicts.')}")
                        print(f"  git merge --abort   # to abort")
                    input("Press Enter to continue...")
                    continue
                elif action == "PR_LOG":
                    subprocess.run(
                        ["git", "log", "--oneline", "FETCH_HEAD"],
                        cwd=repo,
                    )
                    input("Press Enter to continue...")
                    continue
                elif action == "PR_DONE":
                    current_actions = None
                    action_header = ""
                    show_actions = False
                    continue

                # All other actions
                show_actions = False
                current_actions = None
                action_header = ""
                _execute_lore_action(action, repo, selected_result)
        else:
            if key in ("---", ""):
                continue
            if key == "SEARCH_OPTIONS" and search_context:
                show_search_options = True
                continue
            if key == "LOAD_MORE" and search_context:
                search_context.max_results *= 2
                print(f"Loading more (up to {search_context.max_results})...")
                new_results = _search_with_context(search_context)
                if len(new_results) > len(results):
                    results = new_results
                    import shutil as _shutil
                    _shutil.rmtree(preview_dir, ignore_errors=True)
                    menu_lines, preview_dir = _build_lore_menu_data(results)
                    if search_context:
                        if len(results) >= search_context.max_results:
                            menu_lines.insert(0, f"LOAD_MORE\t{Colors.magenta('(load more results...)')}")
                        menu_lines.insert(0, f"SEARCH_OPTIONS\t{Colors.magenta('(search options...)')}")
                    preview_script = os.path.join(preview_dir, "preview.sh")
                continue
            try:
                idx = int(key)
                selected_result = results[idx]
                show_actions = True
                current_actions = None
                action_header = ""
            except (ValueError, IndexError):
                continue
    finally:
        import shutil as _shutil
        _shutil.rmtree(preview_dir, ignore_errors=True)


def _view_thread_terminal(url: str) -> None:
    """Fetch and display a full lore thread in the terminal via a pager.

    Fetches the thread mbox from lore (t.mbox.gz), decodes each message
    (quoted-printable/base64), filters verbose headers, and pages the
    output through bat or less.
    """
    import email as _email
    import email.policy as _policy
    import gzip

    # Headers to show per message
    keep_headers = ("From", "To", "Cc", "Subject", "Date", "Message-Id",
                    "In-Reply-To", "List-Id")

    # Construct thread mbox URL
    thread_url = url.rstrip("/") + "/t.mbox.gz"

    print("Fetching thread...")
    try:
        req = urllib.request.Request(thread_url, headers={"User-Agent": "bit/1.0"})
        with urllib.request.urlopen(req, timeout=30) as resp:
            compressed = resp.read()
    except Exception as e:
        print(f"Failed to fetch thread: {e}")
        input("Press Enter to continue...")
        return

    try:
        mbox_data = gzip.decompress(compressed)
    except Exception:
        # Maybe it wasn't gzipped (some endpoints return plain mbox)
        mbox_data = compressed

    # Split mbox into individual messages (each starts with "From " at line start)
    raw_messages = re.split(rb'^From [^\n]+\n', mbox_data, flags=re.MULTILINE)
    raw_messages = [m for m in raw_messages if m.strip()]

    if not raw_messages:
        print("No messages found in thread")
        input("Press Enter to continue...")
        return

    # Decode each message and build output
    output_parts = []
    separator = "═" * 72

    for i, raw in enumerate(raw_messages):
        try:
            msg = _email.message_from_bytes(raw, policy=_policy.default)
        except Exception:
            continue

        # Filtered headers
        hdr_lines = []
        for name in keep_headers:
            val = msg.get(name)
            if val:
                hdr_lines.append(f"{name}: {val}")

        # Decoded body
        body = ""
        if msg.is_multipart():
            for part in msg.walk():
                if part.get_content_type() == "text/plain":
                    payload = part.get_content()
                    if isinstance(payload, str):
                        body = payload
                        break
        else:
            try:
                payload = msg.get_content()
                if isinstance(payload, str):
                    body = payload
            except Exception:
                body = "(could not decode body)"

        part_text = separator + "\n"
        part_text += "\n".join(hdr_lines) + "\n\n"
        part_text += body.rstrip() + "\n"
        output_parts.append(part_text)

    full_output = f"\n{len(raw_messages)} message(s) in thread\n\n"
    full_output += "\n".join(output_parts)

    # Page through bat or less
    bat_cmd = shutil.which("bat") or shutil.which("batcat")
    if bat_cmd:
        pager = [bat_cmd, "--style=plain", "--color=always",
                 "--language=Email", "--paging=always"]
    elif os.environ.get("PAGER"):
        pager = [os.environ["PAGER"]]
    else:
        pager = ["less", "-R"]

    try:
        subprocess.run(pager, input=full_output, text=True)
    except FileNotFoundError:
        # No pager available, just print
        print(full_output)
        input("Press Enter to continue...")


def _view_thread_browser(url: str) -> None:
    """Open a lore thread URL in the system web browser."""
    try:
        subprocess.run(["xdg-open", url], stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL)
    except FileNotFoundError:
        try:
            subprocess.run(["open", url], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            print(f"\n{url}")
    input("Press Enter to continue...")


def _execute_lore_action(action: str, repo: str, result: LoreResult) -> None:
    """Execute an action from the lore browser action dialog."""
    msgid = _normalize_msgid(result.msgid)
    url = result.url

    if action == "VIEW":
        defaults = load_defaults(".bit.defaults")
        viewer = get_b4_setting(defaults, "b4_thread_viewer") or "terminal"
        if viewer == "browser":
            _view_thread_browser(url)
        else:
            _view_thread_terminal(url)
    elif action == "APPLY":
        b4_apply(repo, msgid, method="am")
        input("Press Enter to continue...")
    elif action == "SHAZAM":
        b4_apply(repo, msgid, method="shazam")
        input("Press Enter to continue...")
    elif action == "TRAILERS":
        b4_collect_trailers(repo, msgid)
        input("Press Enter to continue...")
    elif action == "CHECK":
        subprocess.run(["b4", "am", "--check-newer-revisions", msgid], cwd=repo)
        input("Press Enter to continue...")
    elif action == "DIFF":
        print("\nSelect the other series version to compare:")
        msgid2 = fzf_discover_msgid(repo)
        if msgid2:
            b4_diff_versions(msgid, msgid2)
        input("Press Enter to continue...")
    elif action == "COPY":
        for cmd in [["xclip", "-selection", "clipboard"],
                    ["xsel", "--clipboard", "--input"],
                    ["wl-copy"], ["pbcopy"]]:
            try:
                subprocess.run(cmd, input=msgid, text=True,
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                print(f"Copied: {msgid}")
                break
            except FileNotFoundError:
                continue
        else:
            print(f"\nMessage-Id: {msgid}")
        input("Press Enter to continue...")


def _fzf_pick_repo(repos: List[str]) -> Optional[str]:
    """Pick a repo from a list using fzf. Returns repo path or None."""
    if len(repos) == 1:
        return repos[0]

    if not fzf_available():
        print("\nRepositories:")
        for i, r in enumerate(repos, 1):
            print(f"  {i}. {repo_display_name(r)}")
        try:
            choice = input("Select: ").strip()
            if choice.isdigit() and 1 <= int(choice) <= len(repos):
                return repos[int(choice) - 1]
        except (EOFError, KeyboardInterrupt):
            pass
        return None

    menu_lines = []
    for r in repos:
        menu_lines.append(f"{r}\t{repo_display_name(r)}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-sort",
                "--no-multi",
                "--height", "~10",
                "--header", "Select repository",
                "--prompt", "Repo: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_browser_bindings() + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    output = result.stdout.strip()
    if output == "BACK":
        return None

    return output.split("\t")[0]


def _get_repos(args) -> List[str]:
    """Get list of repos from project context."""
    defaults = load_defaults(getattr(args, "defaults_file", ".bit.defaults"))
    bblayers = getattr(args, "bblayers", None)
    try:
        pairs, _repo_sets = resolve_base_and_layers(bblayers, defaults)
    except SystemExit:
        return []
    seen = set()
    repos = []
    for _layer, repo in pairs:
        if repo not in seen:
            seen.add(repo)
            repos.append(repo)
    return repos


# =============================================================================
# b4 Apply
# =============================================================================

def b4_apply(repo: str, msgid: str, method: str = "am") -> int:
    """Apply patches from lore using b4.

    method: "am" for b4 am + git am, "shazam" for b4 shazam (direct apply).
    """
    if not _require_b4():
        return 1

    msgid = _normalize_msgid(msgid)
    display = repo_display_name(repo)

    if method == "shazam":
        print(f"\nApplying via b4 shazam to {Colors.bold(display)}...")
        result = subprocess.run(
            ["b4", "shazam", msgid],
            cwd=repo,
        )
        return result.returncode

    # b4 am method: fetch mbox first, then git am
    tmpdir = tempfile.mkdtemp(prefix="b4-am-")
    print(f"\nFetching series {msgid}...")
    result = subprocess.run(
        ["b4", "am", "-o", tmpdir, msgid],
        cwd=repo,
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        print(f"{Colors.red('Failed to fetch series:')}")
        if result.stderr:
            print(result.stderr)
        return 1

    if result.stdout:
        print(result.stdout)

    # Find the mbox file
    mbox_files = [f for f in os.listdir(tmpdir) if f.endswith((".mbx", ".mbox"))]
    if not mbox_files:
        print(f"{Colors.yellow('No mbox file found in b4 output')}")
        return 1

    mbox_path = os.path.join(tmpdir, mbox_files[0])

    # Check for newer revisions
    check_result = subprocess.run(
        ["b4", "am", "--check-newer-revisions", msgid],
        cwd=repo, capture_output=True, text=True,
    )
    if check_result.stdout and "newer" in check_result.stdout.lower():
        print(f"\n{Colors.yellow('Note:')} {check_result.stdout.strip()}")

    # Confirm
    try:
        confirm = input(f"\nApply to {display}? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return 0
    if confirm in ("n", "no"):
        return 0

    print(f"Applying patches to {display}...")
    am_result = subprocess.run(
        ["git", "am", mbox_path],
        cwd=repo,
    )
    if am_result.returncode != 0:
        print(f"\n{Colors.yellow('git am failed. You may need to resolve conflicts.')}")
        print(f"  git am --abort   # to abort")
        print(f"  git am --skip    # to skip this patch")
        print(f"  git am --continue  # after resolving")

    return am_result.returncode


# =============================================================================
# b4 Send
# =============================================================================

def b4_send(patch_dir: str, send_to: Optional[str] = None) -> int:
    """Send patches via b4 send."""
    if not _require_b4():
        return 1

    cmd = ["b4", "send", "--no-sign"]
    if send_to:
        cmd.extend(["--to", send_to])

    patches = sorted(f for f in os.listdir(patch_dir) if f.endswith(".patch"))
    if not patches:
        print("No .patch files found in directory")
        return 1

    print(f"\nSending {len(patches)} patch(es) via b4...")
    for p in patches:
        print(f"  {p}")

    try:
        confirm = input("\nProceed? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nCancelled.")
        return 0
    if confirm not in ("y", "yes"):
        return 0

    result = subprocess.run(
        cmd + [os.path.join(patch_dir, p) for p in patches],
    )
    return result.returncode


# =============================================================================
# b4 Trailers
# =============================================================================

def b4_collect_trailers(repo: str, msgid_or_commit: str, update: bool = False) -> int:
    """Show trailers collected from mailing list replies.

    Args:
        repo: Repository path
        msgid_or_commit: Message-id, URL, or commit hash
        update: If True, also update local commits with trailers (b4 trailers -u).
                Only works for series where you are the committer.
    """
    if not _require_b4():
        return 1

    msgid = msgid_or_commit.strip()

    # If it looks like a commit hash, try to extract message-id
    if re.match(r'^[0-9a-f]{7,40}$', msgid):
        direct_msgid, _results = lore_search_for_commit(repo, msgid)
        if direct_msgid:
            msgid = direct_msgid
        else:
            print(f"{Colors.yellow('No message-id found for commit')} {msgid[:8]}")
            print("Provide a message-id or lore URL instead.")
            return 1

    msgid = _normalize_msgid(msgid)

    print(f"\nCollecting trailers for {msgid}...")

    cmd = ["b4", "trailers"]
    if update:
        cmd.append("-u")
    cmd.append(msgid)

    result = subprocess.run(cmd, cwd=repo)
    if result.returncode != 0:
        print(f"\n{Colors.yellow('b4 trailers returned non-zero exit code.')}")

    return result.returncode


# =============================================================================
# b4 Diff (Series Version Comparison)
# =============================================================================

def b4_diff_versions(msgid: str, msgid2: Optional[str] = None) -> int:
    """Compare versions of a patch series using b4 diff."""
    if not _require_b4():
        return 1

    msgid = _normalize_msgid(msgid)

    cmd = ["b4", "diff"]
    if msgid2:
        cmd.extend([_normalize_msgid(msgid2), msgid])
    else:
        cmd.append(msgid)

    print(f"\nComparing series versions...")
    result = subprocess.run(cmd)
    return result.returncode


# =============================================================================
# b4 Prep
# =============================================================================

def b4_prep(repo: str) -> int:
    """Initialize b4 prep in a repo."""
    if not _require_b4():
        return 1

    display = repo_display_name(repo)
    print(f"\nInitializing b4 prep in {Colors.bold(display)}...")
    result = subprocess.run(["b4", "prep"], cwd=repo)
    return result.returncode


def b4_prep_status(repo: str) -> int:
    """Show b4 prep status for a repo."""
    if not _require_b4():
        return 1

    result = subprocess.run(
        ["b4", "prep", "--show-info"],
        cwd=repo,
    )
    return result.returncode


# =============================================================================
# b4 Mbox
# =============================================================================

def b4_mbox(repo: str, msgid: str) -> Optional[str]:
    """Download a thread as mbox using b4 mbox.

    Returns the tmpdir path on success, None on failure.
    """
    if not _require_b4():
        return None

    msgid = _normalize_msgid(msgid)
    tmpdir = tempfile.mkdtemp(prefix="b4-mbox-")
    print(f"\nDownloading thread to mbox...")
    result = subprocess.run(
        ["b4", "mbox", "-o", tmpdir, msgid],
        cwd=repo,
    )
    if result.returncode != 0:
        return None
    return tmpdir


# =============================================================================
# b4 Thank You
# =============================================================================

def b4_ty(repo: str) -> int:
    """Send thank-you messages to contributors using b4 ty."""
    if not _require_b4():
        return 1

    display = repo_display_name(repo)
    print(f"\nb4 ty — send thank-you messages for {Colors.bold(display)}")

    # Show what's tracked first
    subprocess.run(["b4", "ty", "-l"], cwd=repo)

    try:
        confirm = input("\nSend thank-you messages? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return 0
    if confirm not in ("y", "yes"):
        return 0

    result = subprocess.run(["b4", "ty", "-a"], cwd=repo)
    return result.returncode


# =============================================================================
# b4 Pull Request
# =============================================================================

def b4_pr(repo: str, msgid: str) -> int:
    """Fetch a pull request using b4 pr."""
    if not _require_b4():
        return 1

    msgid = _normalize_msgid(msgid)
    display = repo_display_name(repo)

    print(f"\nFetching pull request to FETCH_HEAD in {Colors.bold(display)}...")
    result = subprocess.run(
        ["b4", "pr", msgid],
        cwd=repo,
    )
    return result.returncode


# =============================================================================
# Patch Lookup (from commit browser)
# =============================================================================

def b4_patch_lookup(repo: str, commit: str) -> None:
    """Find the patch series a commit came from on lore.kernel.org.

    Called from explore.py commit browser "p" key.
    """
    from .common import log_message
    log_message(f"Looking up patch series for {commit[:12]}...")

    direct_msgid, results = lore_search_for_commit(repo, commit)

    if direct_msgid:
        log_message(f"Found message-id in commit: {direct_msgid}")
        url = f"https://lore.kernel.org/all/{urllib.parse.quote(direct_msgid)}/"
        # Wrap direct hit as a single-result list for the browser
        direct_result = LoreResult(
            msgid=direct_msgid, subject=commit[:12], author="",
            date="", url=url,
        )
        fzf_lore_browser([direct_result], repo)
        return

    if not results:
        log_message("No results found on lore.kernel.org")
        return

    # Build search context for load-more (re-derive subject from commit)
    try:
        subject = subprocess.check_output(
            ["git", "-C", repo, "log", "-1", "--format=%s", commit],
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        subject = ""
    ctx = None
    if subject:
        list_name = _get_list_for_repo(repo)
        ctx = LoreSearchContext(query=subject, list_name=list_name)
    fzf_lore_browser(results, repo, search_context=ctx)


def b4_file_lookup(repo: str, filepath: str) -> None:
    """Search lore for patches touching a file.

    Called from explore.py tree view "p" key on a FILE entry.
    """
    from .common import log_message
    basename = os.path.basename(filepath)
    log_message(f"Searching lore for patches touching {basename}...")

    list_name = _get_list_for_repo(repo)
    ctx = LoreSearchContext(query=basename, search_type="filename",
                            list_name=list_name)
    results = lore_search_for_file(repo, filepath)

    if not results:
        log_message(f"No patches found on lore for {basename}")
        return

    fzf_lore_browser(results, repo, search_context=ctx)


# =============================================================================
# Interactive b4 Menu
# =============================================================================

_ACTION_PREFIX = "B4ACT:"
_GLOBAL_PREFIX = "B4GLB:"

# Repo-specific actions (shown in inline dialog after selecting a repo)
# Browse and Search are the primary discovery paths — they open the lore
# browser (fzf_lore_browser) with inline actions on the selected message.
_REPO_ACTIONS = [
    ("BROWSE", "Browse mailing list activity"),
    ("SEARCH", "Search lore.kernel.org"),
    ("DIRECT", "Enter message-id or URL directly"),
    ("---1", ""),
    ("TY", "Send thank-you (b4 ty)"),
    ("PREP", "Prep new series (b4 prep)"),
    ("STATUS", "Show prep status"),
]

# Actions that require a mailing list to be meaningful
_LORE_DEPENDENT_ACTIONS = {"BROWSE", "SEARCH"}

# Global actions (shown in main repo list, not repo-specific)
_GLOBAL_ACTIONS = [
    ("SEND", "Send patches (b4 send)"),
]


def _build_action_dialog_lines(repo: str, has_lore: bool = True) -> List[str]:
    """Build fzf menu lines for the action dialog prepended at the bottom.

    Uses fzf default layout (reverse_list=False): items first (near prompt),
    header last (visually above).

    When has_lore=False, lore-dependent actions (BROWSE, SEARCH) are hidden.
    """
    display = repo_display_name(repo)
    items = []
    for key, label in _REPO_ACTIONS:
        if key.startswith("---"):
            items.append(("---", ""))
        elif not has_lore and key in _LORE_DEPENDENT_ACTIONS:
            continue
        else:
            items.append((f"{_ACTION_PREFIX}{key}", label))

    annotation = ""
    if not has_lore:
        annotation = Colors.dim("(no mailing list — use DIRECT for message-id)")

    return build_inline_dialog_lines(
        display, items, reverse_list=False, annotation=annotation,
    )


def _build_repo_preview(repos: List[str], defaults: dict) -> Tuple[str, str]:
    """Build preview data for repo list: mailing list activity + repo info.

    Pre-fetches recent lore posts for each configured/detected repo and
    writes them to cache files.  Returns (preview_dir, preview_command)
    where preview_command is the fzf --preview string.
    """
    preview_dir = tempfile.mkdtemp(prefix="b4-menu-preview-")
    configured = _get_configured_repos(defaults)

    for repo in repos:
        display = repo_display_name(repo)
        cache_file = os.path.join(preview_dir, hashlib.md5(repo.encode()).hexdigest())

        # Determine mailing list for this repo
        cfg = configured.get(repo)
        lore_name = ""
        ml = ""
        if cfg:
            lore_name = cfg.get("lore_name", "")
            ml = cfg.get("mailing_list", "")
        if not lore_name:
            detected = _detect_lists_from_repo(repo)
            if detected:
                ml, lore_name = detected[0][0], detected[0][1]

        # Build preview content
        lines = []
        lines.append(f"Repository: {display}")
        try:
            branch = subprocess.check_output(
                ["git", "-C", repo, "branch", "--show-current"],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            if branch:
                lines.append(f"Branch:     {branch}")
        except subprocess.CalledProcessError:
            pass
        if ml:
            lines.append(f"List:       {ml}")
        if lore_name:
            lines.append(f"Lore:       https://lore.kernel.org/{lore_name}/")
        lines.append("")

        # Fetch recent mailing list activity
        if lore_name:
            lines.append(f"Recent mailing list activity ({lore_name}):")
            lines.append("─" * 60)
            try:
                results = lore_browse_list(lore_name, max_results=30, days=7)
                if results:
                    for r in results:
                        is_reply = r.subject.lower().startswith("re:")
                        indent = "  " if is_reply else ""
                        lines.append(f"  {r.date}  {indent}{r.subject}")
                        lines.append(f"            {r.author}")
                else:
                    lines.append("  (no recent activity)")
            except Exception:
                lines.append("  (could not fetch)")
        else:
            # No mailing list — show recent commits as fallback
            lines.append("Recent commits:")
            lines.append("─" * 60)
            try:
                log = subprocess.check_output(
                    ["git", "-C", repo, "log", "--format=  %h %s (%an, %ar)", "-20"],
                    text=True, stderr=subprocess.DEVNULL,
                ).strip()
                lines.append(log if log else "  (no commits)")
            except subprocess.CalledProcessError:
                lines.append("  (not a git repo)")

        with open(cache_file, "w") as f:
            f.write("\n".join(lines) + "\n")

    # Preview script: look up the cache file by repo path hash
    preview_script = os.path.join(preview_dir, "preview.sh")
    with open(preview_script, "w") as ps:
        ps.write("#!/bin/sh\n")
        ps.write("key=$(echo \"$1\" | sed 's/^[[:space:]]*//')\n")
        ps.write(f'hash=$(echo -n "$key" | md5sum | cut -d" " -f1)\n')
        ps.write(f'cache="{preview_dir}/$hash"\n')
        ps.write('[ -f "$cache" ] && cat "$cache" || echo "No preview available"\n')
    os.chmod(preview_script, 0o755)

    preview_cmd = f"{preview_script} {{1}}"
    return preview_dir, preview_cmd


def _match_repo(name: str, repos: List[str], defaults: dict) -> Optional[str]:
    """Match a user-supplied name to a repo path.

    Tries (case-insensitive substring) against:
    1. repo_display_name  (e.g., "openembedded-core")
    2. os.path.basename   (e.g., "openembedded-core-contrib")
    3. lore list name     (e.g., "openembedded-core")
    Returns the first matching repo path, or None.
    """
    needle = name.lower()
    configured = _get_configured_repos(defaults)
    for repo in repos:
        display = repo_display_name(repo).lower()
        basename = os.path.basename(repo.rstrip("/")).lower()
        cfg = configured.get(repo)
        lore = (cfg.get("lore_name", "") if cfg else "").lower()
        if not lore:
            detected = _detect_lists_from_repo(repo)
            lore = detected[0][1].lower() if detected else ""
        if needle in display or needle in basename or (lore and needle in lore):
            return repo
    return None


def fzf_b4_menu(repos: List[str], defaults_file: str = ".bit.defaults",
                initial_repo: Optional[str] = None) -> int:
    """b4 menu: repo list with inline action dialog.

    Shows a tall repo list with preview.  When Enter is pressed on a repo,
    action items are appended at the bottom of the same list as an inline
    dialog (same pattern as the recipe search options).  Esc dismisses the
    dialog and returns to the repo list.

    If initial_repo is set, skip straight to the action dialog for that repo.
    """
    if not fzf_available():
        print("fzf is required for the interactive b4 menu.")
        print("Use subcommands instead: bit b4 apply, bit b4 send, etc.")
        return 1

    b4_status = Colors.green("available") if b4_available() else Colors.red("not found")
    defaults = load_defaults(defaults_file)

    show_actions = bool(initial_repo)
    search_mode = False
    search_query_prefill = ""
    search_cursor_key = None  # OPT: key to restore cursor position after toggle
    search_options = InlineOptionsState(build_lore_search_menu())
    selected_repo = initial_repo

    # Pre-fetch mailing list activity for preview (done once, cached in temp dir)
    print("Loading preview data...")
    preview_dir, preview_cmd = _build_repo_preview(repos, defaults)

    try:
      while True:
        defaults = load_defaults(defaults_file)
        configured = _get_configured_repos(defaults)

        # Build menu: global actions first (visual bottom), then repos (visual top)
        menu_lines = []

        # Global actions (first in input = visual bottom, near prompt)
        for key, label in _GLOBAL_ACTIONS:
            menu_lines.append(f"{_GLOBAL_PREFIX}{key}\t  {label}")
        menu_lines.append(f"---\t{Colors.dim('  ─────────────────')}")

        # Calculate column widths for alignment
        repo_info = []
        for repo in repos:
            display = repo_display_name(repo)
            cfg = configured.get(repo)
            list_info = ""
            if cfg:
                lore = cfg.get("lore_name", "")
                ml = cfg.get("mailing_list", "")
                list_info = lore or ml
            if not list_info:
                detected = _detect_lists_from_repo(repo)
                if detected:
                    list_info = detected[0][1]
            branch = _repo_branch(repo)
            repo_info.append((repo, display, list_info, branch))

        name_width = max((len(d) for _, d, _, _ in repo_info), default=20)
        list_width = max((len(l) for _, _, l, _ in repo_info), default=0)

        # Repos
        for repo, display, list_info, branch in repo_info:
            if (show_actions or search_mode) and repo == selected_repo:
                styled = Colors.green(display)
                pad = name_width + 10  # +9 for ANSI green + 1 extra pad
            else:
                styled = Colors.bold(display)
                pad = name_width + 9  # +8 for ANSI bold + 1 extra pad
            line = f"  {styled:<{pad}}"
            if list_width:
                if list_info:
                    line += f"  {list_info:<{list_width}}"
                else:
                    line += f"  {'':<{list_width}}"
            if branch:
                line += f"  {Colors.dim(branch)}"
            menu_lines.append(f"{repo}\t{line}")

        # Underline + column header (last in input = visual top, above repos)
        # Underline first (closer to repos), then header above it
        total_width = 2 + name_width + (2 + list_width if list_width else 0) + 2 + 20
        menu_lines.append(f"---\t{Colors.dim('  ' + '─' * (total_width - 2))}")
        hdr = f"  {Colors.cyan('Repository'):<{name_width + 9}}"  # +9 for ANSI cyan codes
        if list_width:
            hdr += f"  {Colors.cyan('Mailing list'):<{list_width + 9}}"  # +9 for ANSI cyan codes
        hdr += f"  {Colors.cyan('Branch')}"
        menu_lines.append(f"---\t{hdr}")

        # Prepend search options at visual bottom (reversed so actions nearest prompt)
        if search_mode and selected_repo:
            options_lines = search_options.build_menu_lines()
            options_lines.reverse()
            menu_lines = options_lines + menu_lines
        elif show_actions and selected_repo:
            has_lore = _get_list_for_repo(selected_repo, defaults) is not None
            dialog_lines = _build_action_dialog_lines(selected_repo, has_lore=has_lore)
            menu_lines = dialog_lines + menu_lines

        # fzf command
        fzf_cmd = [
            "fzf",
            "--no-sort",
            "--no-multi",
            "--ansi",
            "--height", "100%",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--preview", preview_cmd,
            "--preview-window", "right:60%:wrap",
        ]

        if search_mode:
            # Options mode: --disabled captures query, --expect space for toggles
            fzf_cmd.extend([
                "--disabled", "--no-sort", "--print-query",
                "--bind", "esc:abort",
                "--expect", "space",
                "--query", search_query_prefill,
                "--header", f"b4 Patch Management  [b4: {b4_status}]\n"
                            f"{search_options.menu.header}\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", "Search lore: ",
            ])
            # Restore cursor to last-toggled item, or default to pos 1 (Search action)
            if search_cursor_key:
                for i, line in enumerate(menu_lines):
                    if line.split("\t")[0] == f"{search_options.PREFIX}{search_cursor_key}":
                        fzf_cmd.extend(get_position_binding(i + 1))
                        break
                search_cursor_key = None
        elif show_actions:
            repo_display = repo_display_name(selected_repo) if selected_repo else ""
            fzf_cmd.extend([
                "--disabled",
                "--header", f"b4 Patch Management  [b4: {b4_status}]\n"
                            f"Select action for {repo_display}  Esc=back\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", f"{repo_display}> ",
            ])
        else:
            fzf_cmd.extend([
                "--header", f"b4 Patch Management  [b4: {b4_status}]\n"
                            f"Enter=actions  q=quit\n"
                            f"{get_preview_header_suffix()}",
                "--prompt", "Repo> ",
            ])

        if not search_mode:
            fzf_cmd.extend(get_browser_bindings())
        fzf_cmd.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_cmd,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return 1

        if result.returncode != 0 or not result.stdout.strip():
            if search_mode:
                search_mode = False
                search_query_prefill = ""
                continue
            if show_actions:
                # Esc from action dialog → back to repo list
                show_actions = False
                continue
            return 0

        output = result.stdout.strip()

        # Search mode: use InlineOptionsState to parse toggle/action results
        if search_mode:
            opt_result = search_options.parse_selection(result.stdout, result.returncode)

            if opt_result.cancelled:
                search_mode = False
                search_query_prefill = ""
                continue

            # Handle toggle with radio-group mutual exclusivity
            if opt_result.toggled:
                _radio_groups = [
                    ["search_any", "search_subject", "search_body"],
                    ["time_2y", "time_5y", "time_all"],
                ]
                for group in _radio_groups:
                    if opt_result.toggled in group:
                        if search_options.get_state(opt_result.toggled):
                            # Turned ON → turn off others in group
                            for other in group:
                                if other != opt_result.toggled:
                                    search_options.set_state(other, False)
                        else:
                            # Turned OFF → prevent empty selection
                            search_options.set_state(opt_result.toggled, True)
                        break
                search_query_prefill = opt_result.query
                search_cursor_key = opt_result.toggled
                continue

            # Handle "search" action
            if opt_result.action == "search":
                search_mode = False
                search_query_prefill = ""
                query = opt_result.query.strip()
                if query and selected_repo:
                    # Extract search params from toggle states
                    states = search_options.get_all_states()
                    if states.get("search_subject"):
                        search_type = "subject"
                    elif states.get("search_body"):
                        search_type = "body"
                    else:
                        search_type = "any"
                    if states.get("time_5y"):
                        time_range = "5.years.ago.."
                    elif states.get("time_all"):
                        time_range = ""
                    else:
                        time_range = "2.years.ago.."
                    threads = states.get("threads", False)

                    list_name = _get_list_for_repo(selected_repo) if selected_repo else None
                    ctx = LoreSearchContext(query=query, list_name=list_name,
                                            search_type=search_type,
                                            time_range=time_range,
                                            threads=threads)
                    print("Searching...")
                    search_results = _search_with_context(ctx)
                    if search_results:
                        fzf_lore_browser(search_results, selected_repo, search_context=ctx)
                    else:
                        print("No results found on lore.kernel.org")
                        input("Press Enter to continue...")
                continue

            # Unknown selection in options mode — ignore
            continue

        if output == "BACK":
            if show_actions:
                show_actions = False
                continue
            return 0

        key = output.split("\t")[0]

        if show_actions:
            # Parse action selection
            show_actions = False

            if key.startswith(_ACTION_PREFIX):
                action = key[len(_ACTION_PREFIX):]
                if action == "SEARCH":
                    search_mode = True
                else:
                    _dispatch_action(action, selected_repo, repos, defaults_file, defaults)
            # If separator or unknown, just dismiss dialog
        else:
            # Parse repo or global action selection
            if key in ("---", ""):
                continue
            if key.startswith(_GLOBAL_PREFIX):
                action = key[len(_GLOBAL_PREFIX):]
                _dispatch_global_action(action, repos, defaults)
            elif any(key == r for r in repos):
                selected_repo = key
                show_actions = True
    finally:
        import shutil as _shutil
        _shutil.rmtree(preview_dir, ignore_errors=True)


def _dispatch_action(
    action: str,
    repo: str,
    all_repos: List[str],
    defaults_file: str,
    defaults: dict,
) -> None:
    """Execute a repo-specific b4 action."""
    if action == "BROWSE":
        _menu_browse_repo(repo, defaults)
    elif action == "SEARCH":
        _menu_search(repo)
    elif action == "DIRECT":
        _menu_direct(repo)
    elif action == "TY":
        _menu_ty(repo)
    elif action == "PREP":
        b4_prep(repo)
        input("Press Enter to continue...")
    elif action == "STATUS":
        b4_prep_status(repo)
        input("Press Enter to continue...")


def _dispatch_global_action(action: str, repos: List[str], defaults: dict) -> None:
    """Execute a global (non-repo-specific) b4 action."""
    if action == "SEND":
        repo = repos[0] if repos else None
        _menu_send(repo, defaults)


def _msgid_to_url(msgid: str) -> str:
    """Build a lore URL from a message-id."""
    return f"https://lore.kernel.org/all/{urllib.parse.quote(_normalize_msgid(msgid))}/"


def _menu_search(repo: Optional[str] = None) -> None:
    """Search lore → browse results with inline actions."""
    try:
        query = input("Search lore.kernel.org: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if not query:
        return
    list_name = _get_list_for_repo(repo) if repo else None
    ctx = LoreSearchContext(query=query, list_name=list_name, search_type="any")
    print("Searching...")
    results = _search_with_context(ctx)
    if repo:
        fzf_lore_browser(results, repo, search_context=ctx)
    else:
        selected = fzf_pick_lore_result(results)
        if selected:
            print(f"\nMessage-Id: {selected.msgid}\nURL: {selected.url}")
            input("Press Enter to continue...")


def _menu_browse(repo: Optional[str]) -> None:
    """Pick a mailing list → browse with inline actions."""
    picked = fzf_pick_mailing_list(repo=repo)
    if not picked:
        return
    _addr, lore_name = picked
    print(f"Fetching recent posts from {lore_name}...")
    results = lore_browse_list(lore_name)
    if not results:
        print(f"No results from {lore_name}")
        input("Press Enter to continue...")
        return
    if repo:
        fzf_lore_browser(results, repo)
    else:
        selected = fzf_pick_lore_result(results)
        if selected:
            print(f"\nMessage-Id: {selected.msgid}\nURL: {selected.url}")
            input("Press Enter to continue...")


def _menu_browse_repo(repo: str, defaults: dict) -> None:
    """Browse mailing list activity for a repo with inline actions."""
    cfg = get_b4_repo_config(defaults, repo)
    lore_name = cfg.get("lore_name", "") if cfg else ""

    if not lore_name:
        detected = _detect_lists_from_repo(repo, use_manifest=True)
        if detected:
            lore_name = detected[0][1]

    if not lore_name:
        _menu_browse(repo)
        return

    print(f"Fetching recent posts from {lore_name}...")
    results = lore_browse_list(lore_name)
    if not results:
        print(f"No results from {lore_name}")
        input("Press Enter to continue...")
        return

    fzf_lore_browser(results, repo)


def _menu_direct(repo: str) -> None:
    """Enter a message-id or URL directly → inline actions."""
    try:
        val = input("Message-Id or lore URL: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if not val:
        return
    msgid = _normalize_msgid(val)
    url = val if "lore.kernel.org" in val else _msgid_to_url(msgid)
    result = LoreResult(msgid=msgid, subject="", author="", date="", url=url)
    fzf_lore_browser([result], repo)


def _menu_send(repo: Optional[str], defaults: dict) -> None:
    """Send patches — discover patch dir, pick mailing list."""
    if not _require_b4():
        input("Press Enter to continue...")
        return

    try:
        patch_dir = input("Patch directory: ").strip()
    except (EOFError, KeyboardInterrupt):
        print()
        return
    if not patch_dir:
        return
    patch_dir = os.path.expanduser(patch_dir)
    if not os.path.isdir(patch_dir):
        print(f"Not a directory: {patch_dir}")
        input("Press Enter to continue...")
        return

    # Check repo-specific mailing list first, then project default, then global
    send_to = None
    if repo:
        repo_cfg = get_b4_repo_config(defaults, repo)
        if repo_cfg:
            send_to = repo_cfg.get("mailing_list", "")
    if not send_to:
        send_to = get_b4_setting(defaults, "b4_default_list")

    if send_to:
        try:
            choice = input(f"Send to {send_to}? [Y/n/pick other] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if choice in ("n", "no", "pick", "p", "other", "o"):
            picked = fzf_pick_mailing_list(repo=repo)
            if picked:
                send_to = picked[0]
            else:
                return
    else:
        picked = fzf_pick_mailing_list(repo=repo)
        if picked:
            send_to = picked[0]
        else:
            return

    b4_send(patch_dir, send_to=send_to)
    input("Press Enter to continue...")


def _menu_ty(repo: str) -> None:
    """Send thank-you messages for applied patches."""
    if not _require_b4():
        input("Press Enter to continue...")
        return

    b4_ty(repo)
    input("Press Enter to continue...")


def _menu_configure_repo(
    repos: List[str],
    defaults_file: str,
    defaults: dict,
) -> None:
    """Configure a repo's mailing list association."""
    repo = _fzf_pick_repo(repos)
    if not repo:
        return

    display = repo_display_name(repo)
    current_cfg = get_b4_repo_config(defaults, repo)

    if current_cfg:
        current_ml = current_cfg.get("mailing_list", "")
        current_lore = current_cfg.get("lore_name", "")
        print(f"\n{Colors.bold(display)} is currently configured:")
        print(f"  Mailing list: {current_ml}")
        if current_lore:
            print(f"  Lore archive: {current_lore}")
        print()
        try:
            choice = input("Change list / [C]lear / keep? [change/clear/Enter=keep] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return
        if choice in ("clear", "c"):
            remove_b4_repo_config(defaults_file, defaults, repo)
            print(f"Cleared b4 config for {display}")
            input("Press Enter to continue...")
            return
        elif not choice or choice == "keep":
            return
        # Fall through to pick new list

    picked = fzf_pick_mailing_list(repo=repo)
    if picked:
        addr, lore_name = picked
        set_b4_repo_config(defaults_file, defaults, repo, addr, lore_name)
        print(f"\n{Colors.green('Configured')} {display} → {addr}")
        input("Press Enter to continue...")


# =============================================================================
# Main Entry Point
# =============================================================================

def run_b4(args) -> int:
    """Main entry point for bit b4 command."""
    defaults_file = getattr(args, "defaults_file", ".bit.defaults")
    repos = _get_repos(args)

    b4_cmd = getattr(args, "b4_command", None)

    if b4_cmd == "apply":
        msgid = getattr(args, "msgid", None)
        if not msgid:
            print("Usage: bit b4 apply <message-id or lore URL>", file=sys.stderr)
            return 1
        repo = _fzf_pick_repo(repos) if repos else None
        if not repo:
            print("No repositories found.", file=sys.stderr)
            return 1
        return b4_apply(repo, msgid)

    elif b4_cmd == "send":
        patch_dir = getattr(args, "patch_dir", None)
        if not patch_dir:
            print("Usage: bit b4 send <patch-directory>", file=sys.stderr)
            return 1
        send_to = getattr(args, "to", None)
        return b4_send(patch_dir, send_to=send_to)

    elif b4_cmd == "trailers":
        msgid = getattr(args, "msgid", None)
        if not msgid:
            print("Usage: bit b4 trailers <message-id>", file=sys.stderr)
            return 1
        repo = _fzf_pick_repo(repos) if repos else None
        if not repo:
            print("No repositories found.", file=sys.stderr)
            return 1
        return b4_collect_trailers(repo, msgid)

    elif b4_cmd == "diff":
        msgid = getattr(args, "msgid", None)
        if not msgid:
            print("Usage: bit b4 diff <message-id> [message-id2]", file=sys.stderr)
            return 1
        msgid2 = getattr(args, "msgid2", None)
        return b4_diff_versions(msgid, msgid2)

    elif b4_cmd == "mbox":
        msgid = getattr(args, "msgid", None)
        if not msgid:
            print("Usage: bit b4 mbox <message-id or lore URL>", file=sys.stderr)
            return 1
        repo = _fzf_pick_repo(repos) if repos else None
        if not repo:
            print("No repositories found.", file=sys.stderr)
            return 1
        tmpdir = b4_mbox(repo, msgid)
        if tmpdir:
            print(f"Saved to {tmpdir}/")
            for f in sorted(os.listdir(tmpdir)):
                sz = os.path.getsize(os.path.join(tmpdir, f))
                print(f"  {f}  ({sz:,} bytes)")
            return 0
        return 1

    elif b4_cmd == "pr":
        msgid = getattr(args, "msgid", None)
        if not msgid:
            print("Usage: bit b4 pr <message-id or lore URL>", file=sys.stderr)
            return 1
        repo = _fzf_pick_repo(repos) if repos else None
        if not repo:
            print("No repositories found.", file=sys.stderr)
            return 1
        return b4_pr(repo, msgid)

    elif b4_cmd == "ty":
        repo = _fzf_pick_repo(repos) if repos else None
        if not repo:
            print("No repositories found.", file=sys.stderr)
            return 1
        return b4_ty(repo)

    else:
        # No subcommand - show interactive menu
        if not repos:
            print("No repositories found. Run from a project directory.", file=sys.stderr)
            return 1
        # Check for optional repo name argument
        repo_name = getattr(args, "repo_name", None)
        initial_repo = None
        if repo_name:
            defaults = load_defaults(defaults_file)
            initial_repo = _match_repo(repo_name, repos, defaults)
            if not initial_repo:
                print(f"No repo matching '{repo_name}'. Available:", file=sys.stderr)
                for r in repos:
                    print(f"  {repo_display_name(r)}", file=sys.stderr)
                return 1
        return fzf_b4_menu(repos, defaults_file=defaults_file, initial_repo=initial_repo)
