#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Branch command - view and switch branches across repos."""

import os
import re
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    fzf_available,
    get_fzf_color_args,
    get_fzf_preview_resize_bindings,
    load_defaults,
    repo_is_clean,
    save_defaults,
)
from ..fzf_bindings import (
    get_accept_binding,
    get_action_binding,
    get_exit_bindings,
    get_position_binding,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_preview_toggle_binding,
    get_toggle_binding,
)
from .projects import get_preview_window_arg
from .common import (
    collect_repos,
    repo_display_name,
    prompt_action,
    run_cmd,
    create_pull_branch,
    copy_to_clipboard,
)
from ..tui import (
    InlineSelector,
    InlineSelectorItem,
)


_STALE_BRANCH_SECONDS = 365 * 24 * 60 * 60  # 1 year


def get_branches(repo: str, max_age_secs: int = _STALE_BRANCH_SECONDS) -> List[str]:
    """Get list of local and remote branches for a repo.

    Branches whose tip commit is older than *max_age_secs* are excluded
    (set to 0 to include everything).  Local branches are always kept
    regardless of age so the user can see what they have checked out.
    """
    now = int(time.time())
    cutoff = now - max_age_secs if max_age_secs > 0 else 0

    try:
        # Single call per ref type: "refname:short<TAB>committerdate:unix"
        local_raw = subprocess.check_output(
            ["git", "-C", repo, "for-each-ref",
             "--format=%(refname:short)\t%(committerdate:unix)",
             "refs/heads/"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip().splitlines()

        remote_raw = subprocess.check_output(
            ["git", "-C", repo, "for-each-ref",
             "--format=%(refname:short)\t%(committerdate:unix)",
             "refs/remotes/"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip().splitlines()
    except subprocess.CalledProcessError:
        return []

    def _parse(line: str) -> Tuple[str, int]:
        parts = line.split("\t", 1)
        name = parts[0]
        try:
            ts = int(parts[1]) if len(parts) > 1 else 0
        except ValueError:
            ts = 0
        return name, ts

    # Always keep all local branches (user may be on them)
    branches: List[str] = []
    for line in local_raw:
        name, _ts = _parse(line)
        if name:
            branches.append(name)

    # Remote branches: filter stale ones
    for line in remote_raw:
        name, ts = _parse(line)
        if not name or name.endswith("/HEAD"):
            continue
        short = name.replace("origin/", "", 1) if name.startswith("origin/") else name
        if short in branches:
            continue  # already have a local branch with this name
        if cutoff and ts < cutoff:
            continue  # stale
        branches.append(name)

    return branches


def _branch_priority_key(
    name: str, ts: int, priorities: List[str],
) -> Tuple[int, int]:
    """Return sort key: (priority_index, -timestamp).

    Branches matching an earlier priority pattern sort first.
    Within the same priority group, most recent sorts first.
    Unmatched branches get priority = len(priorities) (sort last).

    Patterns support fnmatch-style globs (*, ?, [seq]).
    Both the full branch name and the short name (without origin/ prefix)
    are tested against each pattern.
    """
    import fnmatch
    short = name.replace("origin/", "", 1) if name.startswith("origin/") else name
    for idx, pattern in enumerate(priorities):
        if fnmatch.fnmatch(name, pattern) or fnmatch.fnmatch(short, pattern):
            return (idx, -ts)
    return (len(priorities), -ts)


def _matches_any(name: str, patterns: List[str]) -> bool:
    """Check if a branch name matches any of the given fnmatch patterns."""
    import fnmatch
    short = name.replace("origin/", "", 1) if name.startswith("origin/") else name
    return any(
        fnmatch.fnmatch(name, p) or fnmatch.fnmatch(short, p)
        for p in patterns
    )


def get_branches_by_recency(
    repo: str,
    max_age_secs: int = _STALE_BRANCH_SECONDS,
    priorities: Optional[List[str]] = None,
    excludes: Optional[List[str]] = None,
) -> List[str]:
    """Get branches sorted by priority then most recent commit date.

    Args:
        repo: Path to git repository.
        max_age_secs: Exclude remote branches older than this (0=keep all).
        priorities: Optional list of fnmatch glob patterns. Branches
            matching earlier patterns sort first. Within the same priority
            group, most recently updated branches sort first.
        excludes: Optional list of fnmatch glob patterns. Branches matching
            any exclude pattern are hidden entirely.
    """
    now = int(time.time())
    cutoff = now - max_age_secs if max_age_secs > 0 else 0

    try:
        local_raw = subprocess.check_output(
            ["git", "-C", repo, "for-each-ref",
             "--format=%(refname:short)\t%(committerdate:unix)",
             "refs/heads/"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip().splitlines()

        remote_raw = subprocess.check_output(
            ["git", "-C", repo, "for-each-ref",
             "--format=%(refname:short)\t%(committerdate:unix)",
             "refs/remotes/"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip().splitlines()
    except subprocess.CalledProcessError:
        return []

    def _parse(line: str) -> Tuple[str, int]:
        parts = line.split("\t", 1)
        name = parts[0]
        try:
            ts = int(parts[1]) if len(parts) > 1 else 0
        except ValueError:
            ts = 0
        return name, ts

    # Collect (name, timestamp) pairs
    branches: List[Tuple[str, int]] = []
    local_names: set = set()
    for line in local_raw:
        name, ts = _parse(line)
        if name:
            branches.append((name, ts))
            local_names.add(name)

    for line in remote_raw:
        name, ts = _parse(line)
        if not name or name.endswith("/HEAD"):
            continue
        short = name.replace("origin/", "", 1) if name.startswith("origin/") else name
        if short in local_names:
            continue
        if cutoff and ts < cutoff:
            if not priorities or not _matches_any(name, priorities):
                continue
        branches.append((name, ts))

    # Filter out excluded branches
    if excludes:
        branches = [(n, ts) for n, ts in branches if not _matches_any(n, excludes)]

    # Sort by priority (if given) then by timestamp descending
    if priorities:
        branches.sort(key=lambda x: _branch_priority_key(x[0], x[1], priorities))
    else:
        branches.sort(key=lambda x: x[1], reverse=True)
    return [name for name, _ts in branches]


def checkout_branch(repo: str, target: str) -> Tuple[bool, str]:
    """Checkout a branch in a repo. Returns (success, message)."""
    if not repo_is_clean(repo):
        return False, "dirty (has uncommitted changes)"

    # Handle origin/branch format
    if target.startswith("origin/"):
        local_name = target[7:]  # Strip origin/
        # Check if local branch exists
        local_exists = subprocess.run(
            ["git", "-C", repo, "rev-parse", "--verify", local_name],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        ).returncode == 0
        if local_exists:
            target = local_name
        else:
            # Create tracking branch
            try:
                subprocess.run(
                    ["git", "-C", repo, "checkout", "-b", local_name, "--track", target],
                    check=True,
                    capture_output=True,
                    text=True,
                )
                return True, f"created and switched to {local_name} (tracking {target})"
            except subprocess.CalledProcessError as e:
                return False, e.stderr.strip() or "checkout failed"

    try:
        subprocess.run(
            ["git", "-C", repo, "checkout", target],
            check=True,
            capture_output=True,
            text=True,
        )
        return True, f"switched to {target}"
    except subprocess.CalledProcessError as e:
        return False, e.stderr.strip() or "checkout failed"


def collect_union_branches(
    repos: List[str],
    excludes: Optional[List[str]] = None,
) -> List[Tuple[str, int]]:
    """Collect the union of branches across all repos with per-branch repo counts.

    Returns list of (branch_name, count) tuples sorted: local branches first,
    then remote-only.  Within each group, branches present in all repos come
    first, then descending by count, then alphabetical.

    Args:
        repos: List of repo paths.
        excludes: Optional list of fnmatch glob patterns to hide.
    """
    local_counts: Dict[str, int] = {}
    remote_counts: Dict[str, int] = {}

    for repo in repos:
        branches = get_branches(repo)
        for b in branches:
            if excludes and _matches_any(b, excludes):
                continue
            if b.startswith("origin/"):
                remote_counts[b] = remote_counts.get(b, 0) + 1
            else:
                local_counts[b] = local_counts.get(b, 0) + 1

    total = len(repos)
    result = sorted(local_counts.items(),
                    key=lambda x: (-1 if x[1] == total else 0, -x[1], x[0]))
    result += sorted(remote_counts.items(),
                     key=lambda x: (-1 if x[1] == total else 0, -x[1], x[0]))
    return result


def switch_repos_to_branch(repos: List[str], target_branch: str) -> None:
    """Switch all repos to the same branch, printing results."""
    for repo in repos:
        display = repo_display_name(repo)
        cur = current_branch(repo)
        if cur == target_branch:
            print(f"  {display}: already on {target_branch}")
            continue
        success, msg = checkout_branch(repo, target_branch)
        if success:
            print(f"  {Colors.green(display)}: {msg}")
        else:
            print(f"  {display}: {Colors.red(msg)}")


def fzf_branch_repos(repos: List[str]) -> int:
    """Interactive fzf-based branch management. Returns exit code."""
    if not repos:
        print("No repos found.")
        return 1

    expanded_repos: Set[str] = set()
    next_selection: Optional[str] = None
    show_branch_all_picker = False

    def build_menu_lines() -> List[str]:
        """Build fzf menu lines with inline branch expansion."""
        max_name_len = 20
        for repo in repos:
            display = repo_display_name(repo)
            if len(display) > max_name_len:
                max_name_len = len(display)

        data_lines = []
        for idx, repo in enumerate(repos, start=1):
            display = repo_display_name(repo)
            branch = current_branch(repo) or "(detached)"
            is_clean = repo_is_clean(repo)
            status = f"{Colors.green('[clean]')}" if is_clean else f"{Colors.red('[DIRTY]')}"
            expand_marker = "- " if repo in expanded_repos else "+ "
            upstream_ref = get_upstream_ref(repo, branch)
            if upstream_ref and not upstream_ref.startswith("origin/"):
                tracking_hint = f" \u2192 {upstream_ref.split('/')[0]}"
            else:
                tracking_hint = ""
            line = f"{repo}\t{expand_marker}{idx:<4} {display:<{max_name_len}} {branch}{tracking_hint:<20} {status}"
            data_lines.append(line)

            # Inline branch expansion
            if repo in expanded_repos:
                branches = get_branches(repo)
                for i, b in enumerate(branches):
                    is_last = (i == len(branches) - 1)
                    tree = "  └─ " if is_last else "  ├─ "
                    if b == branch:
                        display_b = f"● {b}"
                    elif b.startswith("origin/"):
                        display_b = f"  {b} (remote)"
                    else:
                        display_b = f"  {b}"
                    data_lines.append(f"BRANCH:{repo}:{b}\t{tree}{display_b}")

        # Reverse so item N is first (appears at bottom), item 1 near end
        menu_lines = list(reversed(data_lines))

        # Column header as LAST line (appears at TOP in default fzf layout)
        header_line = f"HEADER\t  {'#':<4} {'Name':<{max_name_len}} {'Branch':<20} Status"
        sep_len = 2 + 4 + 1 + max_name_len + 1 + 20 + 1 + 8
        separator = f"SEPARATOR\t{'─' * sep_len}"
        menu_lines.append(separator)
        menu_lines.append(header_line)

        return menu_lines

    def switch_all_repos(target_branch: str) -> None:
        """Switch all repos to the same branch."""
        print()
        switch_repos_to_branch(repos, target_branch)
        print()

    def _switch_branch_line(key: str) -> Optional[str]:
        """Handle a BRANCH:repo:branch key — switch and return repo_path for cursor."""
        parts = key.split(":", 2)
        if len(parts) != 3:
            return None
        repo_path, branch_name = parts[1], parts[2]
        display = repo_display_name(repo_path)
        cur = current_branch(repo_path)
        if branch_name == cur:
            print(f"\n  {display}: already on {branch_name}")
        else:
            success, msg = checkout_branch(repo_path, branch_name)
            if success:
                print(f"\n  {Colors.green(display)}: {msg}")
            else:
                print(f"\n  {display}: {Colors.red(msg)}")
        return repo_path

    header = "Enter/→=expand/switch | ←=collapse | B=switch all | q=quit"

    while True:
        menu_lines = build_menu_lines()
        menu_input = "\n".join(menu_lines)

        # Build branch-all InlineSelector if active
        branch_selector = None
        if show_branch_all_picker:
            union = collect_union_branches(repos)
            # Detect common branch across repos
            branches_set = set(current_branch(r) or "" for r in repos)
            common = branches_set.pop() if len(branches_set) == 1 else ""
            items = [
                InlineSelectorItem(
                    name,
                    f"{name:<30} ({count}/{len(repos)} repos)",
                    marker="•" if name == common else "",
                )
                for name, count in union
            ]
            branch_selector = InlineSelector("Switch all repos to branch", items)

        if branch_selector:
            selector_lines = branch_selector.build_menu_lines()
            menu_input = menu_input + "\n" + "\n".join(selector_lines)
            current_header = branch_selector.header
            current_prompt = "Branch: "
        else:
            current_header = header
            current_prompt = "Branch: "

        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--no-info",
            "--ansi",
            "--height", "~50%",
            "--header", current_header,
            "--prompt", current_prompt,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ] + get_fzf_color_args()

        if branch_selector:
            fzf_cmd.extend(branch_selector.get_fzf_args())
        else:
            fzf_cmd.extend(
                get_action_binding("q", "QUIT") +
                get_action_binding("B", "BRANCH_ALL") +
                get_action_binding("right", "RIGHT {1}") +
                get_action_binding("left", "LEFT {1}") +
                get_accept_binding()
            )

        # Position cursor on previously selected item
        if next_selection:
            for i, line in enumerate(menu_lines):
                if line.startswith(next_selection + "\t"):
                    fzf_cmd.extend(get_position_binding(i + 1))
                    break

        try:
            result = subprocess.run(
                fzf_cmd,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            print("fzf not found. Use CLI: bit branch <repo> <branch>")
            return 1

        next_selection = None

        if result.returncode != 0 or not result.stdout.strip():
            if show_branch_all_picker:
                show_branch_all_picker = False
                continue
            break

        output = result.stdout.strip()

        # Branch-all picker mode
        if branch_selector:
            selected_key = branch_selector.parse_selection(result.stdout, result.returncode)
            show_branch_all_picker = False
            if selected_key:
                switch_all_repos(selected_key)
            continue

        if output == "QUIT":
            break
        elif output == "BRANCH_ALL":
            show_branch_all_picker = True
            continue

        # Handle RIGHT action
        if output.startswith("RIGHT "):
            key = output[6:].strip()
            if key in ("HEADER", "SEPARATOR") or key.startswith("SEPARATOR"):
                continue
            if key.startswith("BRANCH:"):
                next_selection = _switch_branch_line(key)
                continue
            # RIGHT on a repo → expand if not already
            if key not in expanded_repos:
                expanded_repos.add(key)
            next_selection = key
            continue

        # Handle LEFT action
        if output.startswith("LEFT "):
            key = output[5:].strip()
            if key in ("HEADER", "SEPARATOR") or key.startswith("SEPARATOR"):
                continue
            if key.startswith("BRANCH:"):
                # LEFT on a branch line → collapse parent repo
                parts = key.split(":", 2)
                if len(parts) == 3:
                    repo_path = parts[1]
                    expanded_repos.discard(repo_path)
                    next_selection = repo_path
                continue
            # LEFT on an expanded repo → collapse
            if key in expanded_repos:
                expanded_repos.discard(key)
                next_selection = key
            continue

        # Handle Enter (accept)
        if "\t" in output:
            key = output.split("\t")[0]
            if key in ("HEADER", "SEPARATOR") or key.startswith("SEPARATOR"):
                continue
            if key.startswith("BRANCH:"):
                next_selection = _switch_branch_line(key)
                continue
            # Enter on a repo → toggle expand/collapse
            if key in expanded_repos:
                expanded_repos.discard(key)
            else:
                expanded_repos.add(key)
            next_selection = key

    return 0



def run_branch(args) -> int:
    """View and switch branches across repos."""
    defaults = load_defaults(args.defaults_file)
    repos, _repo_sets = collect_repos(args.bblayers, defaults)

    # Handle --all mode
    if args.all_repos:
        if not args.target_branch:
            print("Error: --all requires a branch name")
            print("Usage: bit branch --all <branch>")
            return 1

        print(f"Switching all repos to branch: {args.target_branch}\n")
        had_errors = False
        for repo in repos:
            display = repo_display_name(repo)
            success, msg = checkout_branch(repo, args.target_branch)
            if success:
                print(f"→ {Colors.green(display)}: {msg}")
            else:
                print(f"→ {display}: {Colors.red(msg)}")
                had_errors = True
        return 1 if had_errors else 0

    # If no repo specified, use fzf interactive interface
    if args.repo is None:
        return fzf_branch_repos(repos)

    # Find the target repo by index, display name, or path
    target_repo = None
    try:
        idx = int(args.repo)
        if 1 <= idx <= len(repos):
            target_repo = repos[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(repos)}")
            return 1
    except ValueError:
        # Try matching by display name first
        for repo in repos:
            if repo_display_name(repo).lower() == args.repo.lower():
                target_repo = repo
                break
        # Then try as path
        if not target_repo and os.path.isdir(args.repo):
            target_repo = os.path.abspath(args.repo)
        # Finally try partial path match
        if not target_repo:
            for repo in repos:
                if args.repo in repo or repo.endswith(args.repo):
                    target_repo = repo
                    break

    if not target_repo:
        print(f"Repo not found: {args.repo}")
        return 1

    # If no branch specified, show current branch for this repo
    if args.target_branch is None:
        display = repo_display_name(target_repo)
        branch = current_branch(target_repo) or "(detached)"
        is_clean = repo_is_clean(target_repo)
        status = Colors.green("[clean]") if is_clean else Colors.red("[DIRTY]")
        print(f"Repo: {target_repo}")
        print(f"Display name: {display}")
        print(f"Branch: {Colors.bold(branch)} {status}")
        return 0

    # Switch to the specified branch
    display = repo_display_name(target_repo)
    success, msg = checkout_branch(target_repo, args.target_branch)
    if success:
        print(f"→ {Colors.green(display)}: {msg}")
        return 0
    else:
        print(f"→ {display}: {Colors.red(msg)}")
        return 1


# ------------------------ Prepare Export ------------------------


def get_upstream_ref(repo: str, branch: str) -> Optional[str]:
    """
    Get the upstream tracking ref for a branch.
    Tries in order:
      1. Configured upstream (e.g. origin/master for a branch tracking it)
      2. origin/<branch> (same name on remote)
      3. origin/HEAD (remote's default branch, for untracked local branches)
    Returns the ref name or None if none exist.
    """
    # Try configured upstream tracking ref
    try:
        ref = subprocess.check_output(
            ["git", "-C", repo, "rev-parse", "--abbrev-ref", f"{branch}@{{upstream}}"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if ref:
            return ref
    except subprocess.CalledProcessError:
        pass

    # Fall back to origin/<branch>
    fallback = f"origin/{branch}"
    if subprocess.run(
        ["git", "-C", repo, "rev-parse", "--verify", fallback],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    ).returncode == 0:
        return fallback

    # Fall back to origin/HEAD (remote's default branch)
    try:
        ref = subprocess.check_output(
            ["git", "-C", repo, "symbolic-ref", "--short", "refs/remotes/origin/HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if ref:
            return ref
    except subprocess.CalledProcessError:
        pass

    return None


def get_local_commits(repo: str, branch: str) -> Tuple[List[Tuple[str, str]], Optional[str]]:
    """
    Get local commits between the upstream tracking ref and HEAD.
    Returns (list of (hash, subject) tuples in chronological order oldest-first, base_ref or None).
    """
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return [], None

    try:
        # Get commits oldest-first (--reverse)
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--reverse", "--format=%H %s", f"{remote_ref}..HEAD"],
            text=True,
        )
    except subprocess.CalledProcessError:
        return [], remote_ref

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))

    return commits, remote_ref


def get_local_commits_for_layer(
    repo: str, branch: str, layer: str,
) -> Tuple[List[Tuple[str, str]], Optional[str]]:
    """Get local commits filtered to a specific layer path.

    Like get_local_commits() but only returns commits touching files under
    the given layer directory.  Returns oldest-first.
    """
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return [], None
    try:
        relpath = os.path.relpath(layer, repo)
    except ValueError:
        return [], remote_ref
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--reverse", "--format=%H %s",
             f"{remote_ref}..HEAD", "--", f"{relpath}/"],
            text=True, stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return [], remote_ref
    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits, remote_ref


def prompt_branch_name(prompt: str = "Branch name for PR (Enter to skip): ") -> Optional[str]:
    """Prompt user for branch name. Returns None if skipped."""
    try:
        name = input(prompt).strip()
        return name if name else None
    except (EOFError, KeyboardInterrupt):
        print()  # Newline after ^C
        return None



def fzf_multiselect_commits(
    repo: str,
    branch: str,
    commits: List[Tuple[str, str]],
    base_ref: str = "",
    header_text: str = "",
    skip_branch_prompt: bool = False,
) -> Optional[Tuple[List[str], str, bool]]:
    """
    Use fzf to multi-select commits for upstream grouping.
    Supports:
    - Tab: range selection (first Tab = start, second Tab = end, selects all between)
    - Space: toggle individual commits
    - b: request branch name prompt after selection
    Returns (selected_hashes in oldest-first order, action, branch_mode, want_backup) where action is:
    - "selected": User made selections
    - "skip": User chose to skip this repo
    - "skip_rest": User chose to skip all remaining repos
    - None if cancelled (Escape pressed)
    branch_mode is None, "create" (b key), or "replace" (B key)
    want_backup is True if user pressed '!' for backup
    """
    if not commits:
        return ([], "skip", None, False)

    display_name = repo_display_name(repo)

    # Get upstream commits for context (dimmed)
    upstream_commits = []
    if base_ref:
        upstream_commits = get_upstream_context_commits(repo, base_ref, count=3)

    # Build menu with --layout=reverse-list: first input line appears at top
    # We want: newest local -> oldest local -> separator -> upstream context -> menu options
    menu_lines = []

    # Local commits newest first at top
    for hash_val, subject in reversed(commits):
        green_line = Colors.green(f"   {hash_val[:12]} {subject[:70]}")
        menu_lines.append(green_line)

    # Separator
    menu_lines.append("────────────────────────────────────────")

    # Upstream commits for context (newest upstream at top of this section)
    if upstream_commits:
        for hash_val, subject in upstream_commits:
            dimmed = Colors.dim(f"   {hash_val[:12]} {subject[:70]}")
            menu_lines.append(dimmed)

    # Menu options at bottom (near prompt)
    menu_lines.append("────────────────────────────────────────")
    menu_lines.append("── [S] Skip all remaining repos ──")
    menu_lines.append("►► Select NONE (skip this repo)")
    menu_lines.append(f"►► Select ALL {len(commits)} commits for upstream")

    menu_input = "\n".join(menu_lines)

    header = f"Repo: {Colors.bold(display_name)}  Branch: {Colors.bold(branch)}\n"
    header += f"Local commits: {len(commits)}\n"
    if header_text:
        header += header_text + "\n"
    if skip_branch_prompt:
        header += "Space=range | Tab=single | !=backup | ?=preview | Enter=confirm\n"
    else:
        header += "Space=range | Tab=single | b/B=branch | !=backup | ?=preview | Enter\n"
    header += get_preview_header_suffix()

    # Temp files for tracking fzf interactions
    range_file = f"/tmp/fzf_range_{os.getpid()}"
    branch_file = f"/tmp/fzf_branch_{os.getpid()}"
    backup_file = f"/tmp/fzf_backup_{os.getpid()}"
    if os.path.exists(range_file):
        os.remove(range_file)
    if os.path.exists(branch_file):
        os.remove(branch_file)
    if os.path.exists(backup_file):
        os.remove(backup_file)

    # Preview command to show commit details
    # {1} is the first field (hash), git show fails gracefully for non-commits
    preview_cmd = f'git -C {repo} show --stat --color=always {{1}} 2>/dev/null || echo "Select a commit to preview"'

    # Shell script to build combined prompt showing branch, backup, and range bounds in yellow
    # ANSI: \033[33m = yellow, \033[0m = reset
    prompt_script = (
        f'br=; bk=; rng=; '
        f'[ -f {branch_file} ] && {{ c=$(cat {branch_file}); [ "$c" = B ] && br="[+BRANCH]" || br="[+branch]"; }}; '
        f'[ -f {backup_file} ] && bk="[!backup]"; '
        f'if [ -f {range_file} ]; then '
        f'first=$(head -1 {range_file} | cut -c1-12); last=$(tail -1 {range_file} | cut -c1-12); '
        f'[ -n "$first" ] && rng=$(printf "\\033[33m[%s..%s]\\033[0m" "$first" "$last"); '
        f'fi; '
        f'echo "Select$br$bk$rng: "'
    )

    # Build fzf command arguments
    fzf_args = [
        "fzf",
        "--multi",
        "--no-sort",
        "--ansi",
        "--height", "100%",
        "--layout=reverse-list",
        "--header", header,
        "--prompt", "Select for upstream: ",
        "--marker", "> ",
        "--info", "inline",
        "--preview", preview_cmd,
        "--preview-window", get_preview_window_arg("50%") + ",wrap",
    ] + get_preview_toggle_binding() + get_preview_scroll_bindings() + get_toggle_binding() + [
        "--bind", f"space:toggle+execute-silent(echo {{}} >> {range_file})+transform-prompt({prompt_script})+down",
    ] + get_action_binding("s", "SKIP_THIS") + get_action_binding("S", "SKIP_REST")

    # Add 'b'/'B' bindings to flag branch creation request (doesn't exit fzf)
    # 'b' = create branch (skip if exists), 'B' = replace existing branch
    if not skip_branch_prompt:
        fzf_args.extend([
            "--bind", f"b:execute-silent(echo b > {branch_file})+transform-prompt({prompt_script})",
            "--bind", f"B:execute-silent(echo B > {branch_file})+transform-prompt({prompt_script})",
        ])

    # Add '!' binding to toggle backup mode
    fzf_args.extend([
        "--bind", f"!:execute-silent(touch {backup_file})+transform-prompt({prompt_script})",
    ])

    # Add preview window resize bindings and theme colors
    fzf_args.extend(get_fzf_preview_resize_bindings())
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        if os.path.exists(range_file):
            os.remove(range_file)
        if os.path.exists(branch_file):
            os.remove(branch_file)
        if os.path.exists(backup_file):
            os.remove(backup_file)
        return None  # fzf not found

    # Read range markers if any
    range_markers = []
    if os.path.exists(range_file):
        with open(range_file) as f:
            range_markers = [line.strip() for line in f.readlines() if line.strip()]
        os.remove(range_file)

    # Check if user pressed 'b' or 'B' for branch creation
    # 'b' = create (skip if exists), 'B' = replace (delete if exists)
    branch_mode = None  # None, "create", or "replace"
    if os.path.exists(branch_file):
        with open(branch_file) as f:
            content = f.read().strip()
        os.remove(branch_file)
        if content == "B":
            branch_mode = "replace"
        elif content == "b":
            branch_mode = "create"

    # Check if user pressed '!' for backup
    want_backup = os.path.exists(backup_file)
    if os.path.exists(backup_file):
        os.remove(backup_file)

    if result.returncode != 0 or not result.stdout.strip():
        return None  # Cancelled with Escape

    selected_lines = result.stdout.strip().splitlines()

    # Check for special outputs from keybindings
    if len(selected_lines) == 1:
        line = selected_lines[0].strip()
        if line == "SKIP_THIS":
            return ([], "skip", branch_mode, want_backup)
        if line == "SKIP_REST":
            return ([], "skip_rest", branch_mode, want_backup)

    # Check for menu options
    for line in selected_lines:
        if "Select ALL" in line:
            return ([h for h, _ in commits], "selected", branch_mode, want_backup)
        if "Select NONE" in line or "skip this repo" in line.lower():
            return ([], "skip", branch_mode, want_backup)
        if "Skip all remaining" in line:
            return ([], "skip_rest", branch_mode, want_backup)

    # Extract selected commit hashes
    hash_set = {h[:12]: h for h, _ in commits}  # Map short hash to full hash
    # Also create index mapping for range calculation
    hash_to_idx = {h[:12]: i for i, (h, _) in enumerate(commits)}

    selected_hashes = set()

    # Process range markers (Tab presses) - fill in all commits between first and last
    if len(range_markers) >= 2:
        # Extract hashes from range markers
        range_hashes = []
        for marker in range_markers:
            parts = marker.strip().split(maxsplit=1)
            if parts and parts[0] in hash_set:
                range_hashes.append(parts[0])

        if len(range_hashes) >= 2:
            # Get indices of first and last range marker
            first_hash = range_hashes[0]
            last_hash = range_hashes[-1]
            if first_hash in hash_to_idx and last_hash in hash_to_idx:
                start_idx = hash_to_idx[first_hash]
                end_idx = hash_to_idx[last_hash]
                # Ensure start <= end
                if start_idx > end_idx:
                    start_idx, end_idx = end_idx, start_idx
                # Add all commits in range
                for i in range(start_idx, end_idx + 1):
                    selected_hashes.add(commits[i][0])

    # Process space-selected commits (from fzf output)
    for line in selected_lines:
        stripped = line.strip()
        if stripped.startswith("►") or stripped.startswith("─"):
            continue  # Skip menu items
        parts = stripped.split(maxsplit=1)
        if parts and parts[0] in hash_set:
            selected_hashes.add(hash_set[parts[0]])

    # Return in original (oldest-first) order
    selected_ordered = [h for h, _ in commits if h in selected_hashes]
    return (selected_ordered, "selected", branch_mode, want_backup)



def get_upstream_context_commits(repo: str, base_ref: str, count: int = 5) -> List[Tuple[str, str]]:
    """Get recent commits from upstream for context display."""
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--format=%H %s", f"-n{count}", base_ref],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits



def get_upstream_to_pull(repo: str, branch: str, count: int = 50) -> List[Tuple[str, str]]:
    """Get commits in upstream tracking ref that are not in HEAD (commits to pull)."""
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return []
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--format=%H %s", f"-n{count}", f"HEAD..{remote_ref}"],
            text=True,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []

    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits


def get_upstream_to_pull_for_layer(repo: str, branch: str, layer: str, count: int = 500) -> List[Tuple[str, str]]:
    """Get upstream commits filtered to a specific layer path."""
    remote_ref = get_upstream_ref(repo, branch)
    if not remote_ref:
        return []
    try:
        relpath = os.path.relpath(layer, repo)
    except ValueError:
        return []
    try:
        output = subprocess.check_output(
            ["git", "-C", repo, "log", "--format=%H %s", f"-n{count}", f"HEAD..{remote_ref}", "--", f"{relpath}/"],
            text=True, stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return []
    commits = []
    for line in output.strip().splitlines():
        if line:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                commits.append((parts[0], parts[1]))
            elif len(parts) == 1:
                commits.append((parts[0], ""))
    return commits



def fzf_select_insertion_point(
    repo: str,
    branch: str,
    base_ref: str,
    remaining_commits: List[Tuple[str, str]],
    selected_commits: List[Tuple[str, str]] = None,
    current_branch_mode: Optional[str] = None,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Use fzf to select insertion point for upstream commits.
    Shows a unified view: local commits (newest first), separator, upstream context.
    Selected commits are marked with ">>" prefix.
    Returns (insertion_point, branch_mode):
    - insertion_point: base_ref, a commit hash, or None if cancelled
    - branch_mode: None, "create", or "replace" (can be set/changed here with b/B)
    """
    display_name = repo_display_name(repo)
    selected_commits = selected_commits or []
    selected_set = {h for h, _ in selected_commits}
    num_selected = len(selected_commits)

    # Get upstream commits for context
    upstream_commits = get_upstream_context_commits(repo, base_ref)

    # Temp file for branch mode (may already have value from selection screen)
    branch_file = f"/tmp/fzf_branch_{os.getpid()}"
    if current_branch_mode:
        with open(branch_file, "w") as f:
            f.write("B" if current_branch_mode == "replace" else "b")

    # Build display for fzf with --layout=reverse-list (first line at top)
    # Display order: remaining local (newest) -> selected (newest) -> insertion point -> upstream
    menu_lines = []

    # Remaining local commits (not selected) - newest first at top
    for hash_val, subject in reversed(remaining_commits):
        menu_lines.append(f"   {hash_val[:12]} {subject[:70]}")

    # Selected commits (will be moved here after reorder) - in green, newest first
    for hash_val, subject in reversed(selected_commits):
        green_line = Colors.green(f">> {hash_val[:12]} {subject[:70]}")
        menu_lines.append(green_line)

    # Default insertion point (the cut line) - between selected and upstream
    menu_lines.append(f"►► {base_ref} (default - insert here)")
    menu_lines.append("────────────────────────────────────────")

    # Upstream commits for context at bottom (dimmed)
    if upstream_commits:
        for hash_val, subject in upstream_commits:
            dimmed = Colors.dim(f"   {hash_val[:12]} {subject[:70]}")
            menu_lines.append(dimmed)

    menu_input = "\n".join(menu_lines)

    # Position of default line: remaining + selected + 1 (1-indexed for fzf)
    num_remaining = len(remaining_commits)
    num_selected = len(selected_commits)
    default_line_pos = num_remaining + num_selected + 1

    # Shell script for dynamic prompt showing branch mode
    prompt_script = (
        f'br=; '
        f'[ -f {branch_file} ] && {{ c=$(cat {branch_file}); [ "$c" = B ] && br="[+BRANCH]" || br="[+branch]"; }}; '
        f'echo "Insert {num_selected}$br after: "'
    )

    # Build initial prompt based on current branch mode
    if current_branch_mode == "replace":
        initial_prompt = f"Insert {num_selected}[+BRANCH] after: "
    elif current_branch_mode == "create":
        initial_prompt = f"Insert {num_selected}[+branch] after: "
    else:
        initial_prompt = f"Insert {num_selected} after: "

    header = f"Repo: {Colors.bold(display_name)}  Branch: {Colors.bold(branch)}\n"
    header += f"Selected: {num_selected} commits (marked with >>)\n"
    header += "b=branch | B=replace branch | Select insertion point"

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--layout=reverse-list",
                "--height", "100%",
                "--header", header,
                "--prompt", initial_prompt,
                "--sync",
            ] + get_position_binding(default_line_pos) + [
                "--bind", f"b:execute-silent(echo b > {branch_file})+transform-prompt({prompt_script})",
                "--bind", f"B:execute-silent(echo B > {branch_file})+transform-prompt({prompt_script})",
            ] + get_fzf_color_args(),
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return base_ref, current_branch_mode  # Default if fzf not available

    # Read branch mode from file
    branch_mode = current_branch_mode
    if os.path.exists(branch_file):
        with open(branch_file) as f:
            content = f.read().strip()
        if content == "B":
            branch_mode = "replace"
        elif content == "b":
            branch_mode = "create"
        os.remove(branch_file)

    if result.returncode != 0 or not result.stdout.strip():
        return None, branch_mode  # Cancelled

    selected = result.stdout.strip()

    # Check if default was selected
    if base_ref in selected:
        return base_ref, branch_mode

    # Strip whitespace and ignore separator line
    selected = selected.strip()
    if selected.startswith("───"):
        return base_ref, branch_mode

    # Extract commit hash
    parts = selected.split(maxsplit=1)
    if parts:
        # Handle ">>" prefix for selected commits
        hash_part = parts[0].lstrip(">").strip()
        # Find full hash in remaining commits (local)
        for h, _ in remaining_commits:
            if h[:12] == hash_part:
                return h, branch_mode
        # Check selected commits too
        for h, _ in selected_commits:
            if h[:12] == hash_part:
                return h, branch_mode
        # If selected an upstream commit, treat as default
        for h, _ in upstream_commits:
            if h[:12] == hash_part:
                return base_ref, branch_mode

    return base_ref, branch_mode  # Fallback to default


# ------------------------ Browse Command ------------------------



