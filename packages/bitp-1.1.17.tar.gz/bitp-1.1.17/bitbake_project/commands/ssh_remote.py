#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""SSH remote project support — all SSH transport logic for remote projects."""

import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import textwrap
import time
from typing import Dict, List, Optional, Tuple


# --- URI parsing ---

_REMOTE_URI_RE = re.compile(r'^(?:([^@]+)@)?([^:]+):(.+)$')


def parse_remote_uri(uri: str) -> Optional[Tuple[str, str, str]]:
    """Parse ``user@host:/path`` into ``(user, host, path)`` or ``None``.

    The user part is optional; defaults to the current login user.
    """
    m = _REMOTE_URI_RE.match(uri.strip())
    if not m:
        return None
    user = m.group(1) or os.environ.get("USER", "")
    host = m.group(2)
    path = m.group(3)
    if not host or not path:
        return None
    return (user, host, path)


def format_remote_uri(user: str, host: str, path: str) -> str:
    """Build a ``user@host:/path`` URI string."""
    return f"{user}@{host}:{path}"


# --- SSH connection multiplexing ---
#
# ControlMaster=auto makes the first SSH connection the "master" and
# subsequent connections multiplex over the same TCP socket.  This means
# passphrase/password is only needed once per host.

def _ssh_mux_opts() -> List[str]:
    """Return SSH options for connection multiplexing.

    The first connection to a host becomes the master (may prompt for
    passphrase).  All later connections reuse it — no extra auth needed.
    The master stays alive for 10 minutes after the last client exits
    so it survives long interactive sessions (explore, dashboard).
    ServerAliveInterval detects dead connections within ~15 seconds.
    """
    ssh_dir = os.path.expanduser("~/.ssh")
    os.makedirs(ssh_dir, mode=0o700, exist_ok=True)
    return [
        "-o", f"ControlPath={ssh_dir}/bit-mux-%r@%h-%p",
        "-o", "ControlMaster=auto",
        "-o", "ControlPersist=600",
        "-o", "ServerAliveInterval=5",
        "-o", "ServerAliveCountMax=3",
    ]


def _ssh_no_prompt_env() -> dict:
    """Return env dict that suppresses interactive SSH password prompts.

    Prevents ssh-askpass / SSH_ASKPASS GUI dialogs from stealing focus
    when the agent key is unavailable or the mux socket is stale.
    """
    env = os.environ.copy()
    env["SSH_ASKPASS_REQUIRE"] = "never"
    env.pop("SSH_ASKPASS", None)
    return env


def _log_ssh_stderr(stderr):
    """Filter SSH mux noise from stderr; log anything else via log_message."""
    if not stderr:
        return
    if isinstance(stderr, bytes):
        stderr = stderr.decode("utf-8", errors="replace")
    from .common import log_message
    for line in stderr.splitlines():
        line = line.strip()
        if not line:
            continue
        # Suppress SSH connection-multiplexing teardown messages
        if line.startswith("Shared connection to ") and line.endswith(" closed."):
            continue
        log_message(line)


def _check_mux_alive(user: str, host: str) -> bool:
    """Return True if the control-master socket is alive, False otherwise.

    If the socket file exists but the master is dead, remove the stale
    socket so a fresh connection can be established.
    """
    target = f"{user}@{host}" if user else host
    ssh_dir = os.path.expanduser("~/.ssh")
    # Must match _ssh_mux_opts ControlPath pattern
    socket_path = os.path.join(ssh_dir, f"bit-mux-{user}@{host}-22")
    try:
        r = subprocess.run(
            ["ssh",
             "-o", f"ControlPath={socket_path}",
             "-o", "BatchMode=yes",
             "-O", "check", target],
            capture_output=True, text=True, timeout=5,
            env=_ssh_no_prompt_env(),
        )
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        # Stale socket — remove it
        try:
            os.unlink(socket_path)
        except OSError:
            pass
        return False


# --- Core SSH runner ---

def ssh_run(user: str, host: str, cmd: str, timeout: int = 30,
            interactive: bool = False) -> subprocess.CompletedProcess:
    """Run a command on a remote host via SSH.

    Uses ``BatchMode=yes`` and ``ConnectTimeout=5`` for non-interactive
    calls. When *interactive* is True the command gets a pseudo-tty and
    replaces the current process (exec).

    Returns a ``CompletedProcess`` (non-interactive) or does not return
    (interactive — uses ``os.execvp``).
    """
    target = f"{user}@{host}" if user else host
    mux = _ssh_mux_opts()
    if interactive:
        ssh_argv = [
            "ssh", "-t",
            *mux,
            "-o", "ConnectTimeout=5",
            target,
            cmd,
        ]
        os.execvp("ssh", ssh_argv)
        # Does not return

    ssh_argv = [
        "ssh",
        *mux,
        "-o", "BatchMode=yes",
        "-o", "ConnectTimeout=5",
        "-o", "StrictHostKeyChecking=accept-new",
        target,
        cmd,
    ]
    return subprocess.run(
        ssh_argv,
        capture_output=True,
        text=True,
        timeout=timeout,
        env=_ssh_no_prompt_env(),
    )


# --- Connection & path checks ---

_ssh_connection_cache: Dict[str, Tuple[float, bool]] = {}
_SSH_CONN_CACHE_TTL = 300.0  # 5 minutes


def _make_askpass_script() -> str:
    """Create a temporary SSH_ASKPASS script that prompts on /dev/tty.

    The script opens /dev/tty directly (bypassing stdin/stdout which SSH
    has redirected), displays the prompt with input masking, and prints the
    password to stdout for SSH to read.

    Returns the path to the temporary script.
    """
    import tempfile
    script = textwrap.dedent("""\
        #!/bin/sh
        # SSH_ASKPASS helper — prompt on the real terminal
        exec < /dev/tty 2>/dev/tty
        trap 'stty echo 2>/dev/null' EXIT INT TERM HUP
        printf '[bit] %s ' "$1" > /dev/tty
        stty -echo 2>/dev/null
        IFS= read -r pw || pw=""
        stty echo 2>/dev/null
        printf '\\n' > /dev/tty
        printf '%s\\n' "$pw"
    """)
    fd, path = tempfile.mkstemp(prefix="bit-askpass-", suffix=".sh")
    os.write(fd, script.encode())
    os.close(fd)
    os.chmod(path, 0o700)
    return path


def ssh_check_connection(user: str, host: str) -> bool:
    """Test SSH connectivity, prompting for password if needed.

    First tries BatchMode (keys / existing mux socket).  If that fails,
    uses SSH_ASKPASS with a helper script that prompts on /dev/tty with
    masked input — this establishes the ControlMaster mux socket so all
    subsequent BatchMode calls reuse it without further prompts.

    Results are cached for 5 minutes.
    """
    key = f"{user}@{host}"
    now = time.monotonic()
    if key in _ssh_connection_cache:
        ts, ok = _ssh_connection_cache[key]
        if now - ts < _SSH_CONN_CACHE_TTL:
            return ok

    # Fast path: try BatchMode (keys or live mux socket)
    try:
        r = ssh_run(user, host, "true", timeout=10)
        if r.returncode == 0:
            _ssh_connection_cache[key] = (now, True)
            return True
    except (subprocess.TimeoutExpired, OSError):
        pass

    # Batch failed — use SSH_ASKPASS to prompt for password.
    # SSH only invokes ASKPASS when it has no TTY, so we pipe stdin
    # from /dev/null and set SSH_ASKPASS_REQUIRE=force.  Our askpass
    # script opens /dev/tty directly for the masked prompt.
    target = f"{user}@{host}" if user else host
    mux = _ssh_mux_opts()
    askpass = _make_askpass_script()
    try:
        env = os.environ.copy()
        env["SSH_ASKPASS"] = askpass
        env["SSH_ASKPASS_REQUIRE"] = "force"
        env.pop("DISPLAY", None)  # not needed with force
        r = subprocess.run(
            ["ssh", *mux,
             "-o", "ConnectTimeout=10",
             "-o", "StrictHostKeyChecking=accept-new",
             target, "true"],
            stdin=subprocess.DEVNULL,
            timeout=60,
            env=env,
        )
        ok = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        ok = False
    finally:
        # Restore terminal in case askpass was killed mid-prompt
        try:
            os.system("stty echo 2>/dev/null")
        except OSError:
            pass
        try:
            os.unlink(askpass)
        except OSError:
            pass

    _ssh_connection_cache[key] = (now, ok)
    return ok


def ssh_path_exists(user: str, host: str, path: str) -> bool:
    """Check whether a remote directory exists."""
    try:
        r = ssh_run(user, host, f"test -d {shlex.quote(path)}", timeout=10)
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


def ssh_path_is_empty(user: str, host: str, path: str) -> bool:
    """Check whether a remote directory is empty or non-existent."""
    try:
        r = ssh_run(user, host,
                    f'test -d {shlex.quote(path)} && '
                    f'[ -z "$(ls -A {shlex.quote(path)})" ] && echo empty',
                    timeout=10)
        return "empty" in r.stdout
    except (subprocess.TimeoutExpired, OSError):
        return False


def fetch_remote_projects(user: str, host: str) -> list:
    """Read remote bit instance's local projects via SSH.

    Returns list of dicts: [{"path": "/abs/path", "name": "...", "description": "..."}, ...]
    Only returns projects that are local on the remote (no host key).
    """
    if not ssh_check_connection(user, host):
        return []

    r = ssh_run(user, host,
                "cat ~/.config/bit/projects.json 2>/dev/null",
                timeout=15)
    if r.returncode != 0 or not r.stdout.strip():
        return []

    try:
        data = json.loads(r.stdout)
    except (json.JSONDecodeError, ValueError):
        return []

    results = []
    for key, info in data.items():
        if key.startswith("__"):
            continue
        if not isinstance(info, dict):
            continue
        if "host" in info:
            continue  # skip — this is already a remote project on that machine
        results.append({
            "path": key,
            "name": info.get("name", os.path.basename(key)),
            "description": info.get("description", ""),
        })
    return results


# --- Remote git helpers ---

_GET_REPOS_SCRIPT = r'''
cd {path} || exit 1
seen=""
found=""

# Check bblayers.conf for layer repos (Yocto projects)
# Try both conf/ (build-as-project-root) and build/conf/ (standard layout)
bblayers=""
if [ -f conf/bblayers.conf ]; then
    bblayers=conf/bblayers.conf
elif [ -f build/conf/bblayers.conf ]; then
    bblayers=build/conf/bblayers.conf
fi
if [ -n "$bblayers" ]; then
    for layer in $(grep -oE '/[^ "\\]+' "$bblayers"); do
        [ -d "$layer" ] || continue
        repo=$(git -C "$layer" rev-parse --show-toplevel 2>/dev/null)
        [ -z "$repo" ] && continue
        case " $seen " in *" $repo "*) continue ;; esac
        seen="$seen $repo"
        found="y"
        echo "$repo"
    done
fi

# Add extra repos from .bit.defaults (e.g. bitbake)
if [ -f .bit.defaults ] && command -v python3 >/dev/null 2>&1; then
    extras=$(python3 -c "
import json,sys
try:
    d=json.load(open('.bit.defaults'))
    hidden=set(d.get('__hidden_repos__',[]))
    for r in d.get('__extra_repos__',[]):
        if r not in hidden: print(r)
except: pass
" 2>/dev/null)
    for repo in $extras; do
        [ -d "$repo/.git" ] || continue
        case " $seen " in *" $repo "*) continue ;; esac
        seen="$seen $repo"
        found="y"
        echo "$repo"
    done
fi

# Fallback: scan for .git dirs if no tracked repos found
if [ -z "$found" ]; then
    for d in . */ */*/; do
        d="${{d%/}}"
        [ -d "$d/.git" ] && echo "$d"
    done
fi
'''


def ssh_get_git_repos(user: str, host: str, path: str) -> List[str]:
    """Find tracked git repos for a remote project (single SSH call).

    Prefers tracked repos (bblayers.conf layers + .bit.defaults extra repos)
    over blind scanning.  Falls back to scanning for ``.git`` dirs up to
    2 levels deep when no project metadata exists.
    """
    script = _GET_REPOS_SCRIPT.format(path=shlex.quote(path))
    try:
        r = ssh_run(user, host, script, timeout=30)
        if r.returncode != 0:
            return []
        repos = []
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            if line == ".":
                repos.append(path)
            elif line.startswith("/"):
                # Absolute path (from bblayers.conf fallback)
                repos.append(line)
            else:
                repos.append(os.path.join(path, line))
        return repos
    except (subprocess.TimeoutExpired, OSError):
        return []


def ssh_current_branch(user: str, host: str, repo: str) -> Optional[str]:
    """Get the current branch of a remote git repo."""
    cmd = f"git -C {shlex.quote(repo)} rev-parse --abbrev-ref HEAD"
    try:
        r = ssh_run(user, host, cmd, timeout=10)
        if r.returncode == 0:
            return r.stdout.strip() or None
        return None
    except (subprocess.TimeoutExpired, OSError):
        return None


# --- Batched dashboard summary ---

_SUMMARY_SCRIPT = r'''
if [ -d {path} ] && [ -n "$(ls -A {path} 2>/dev/null)" ]; then
    path_exists="true"
    cd {path}
else
    path_exists="false"
fi

total=0
dirty=0
ahead=0
behind=0
branches=""

# Collect repo directories to scan.
# Prefer tracked repos (bblayers.conf + .bit.defaults) over blind scanning.
repo_dirs=""
seen=""
if [ "$path_exists" = "true" ]; then
    # Check bblayers.conf for layer repos (Yocto projects)
    if [ -f conf/bblayers.conf ]; then
        for layer in $(grep -oE '/[^ "\\]+' conf/bblayers.conf); do
            [ -d "$layer" ] || continue
            repo=$(git -C "$layer" rev-parse --show-toplevel 2>/dev/null)
            [ -z "$repo" ] && continue
            case " $seen " in *" $repo "*) continue ;; esac
            seen="$seen $repo"
            repo_dirs="$repo_dirs $repo"
        done
    fi

    # Add extra repos from .bit.defaults (e.g. bitbake)
    if [ -f .bit.defaults ] && command -v python3 >/dev/null 2>&1; then
        extras=$(python3 -c "
import json,sys
try:
    d=json.load(open('.bit.defaults'))
    hidden=set(d.get('__hidden_repos__',[]))
    for r in d.get('__extra_repos__',[]):
        if r not in hidden: print(r)
except: pass
" 2>/dev/null)
        for repo in $extras; do
            [ -d "$repo/.git" ] || continue
            case " $seen " in *" $repo "*) continue ;; esac
            seen="$seen $repo"
            repo_dirs="$repo_dirs $repo"
        done
    fi

    # Fallback: if no tracked repos found, scan for .git dirs
    if [ -z "$repo_dirs" ]; then
        for d in . */ */*/; do
            d="${{d%/}}"
            [ -d "$d/.git" ] || continue
            repo_dirs="$repo_dirs $d"
        done
    fi
fi

for d in $repo_dirs; do
    total=$((total + 1))

    b=$(git -C "$d" rev-parse --abbrev-ref HEAD 2>/dev/null)
    [ -n "$b" ] && branches="$branches $b"

    s=$(git -C "$d" status --porcelain -uno --no-renames 2>/dev/null)
    [ -n "$s" ] && dirty=$((dirty + 1))

    lr=$(git -C "$d" rev-list --left-right --count HEAD...@{{u}} 2>/dev/null)
    if [ -n "$lr" ]; then
        a=$(echo "$lr" | awk '{{print $1}}')
        b2=$(echo "$lr" | awk '{{print $2}}')
        ahead=$((ahead + a))
        behind=$((behind + b2))
    fi
done

# Most common branch
best=""
best_n=0
for b in $branches; do
    n=$(echo "$branches" | tr ' ' '\n' | grep -cx "$b")
    if [ "$n" -gt "$best_n" ]; then
        best_n=$n
        best=$b
    fi
done

echo "REPO_COUNT=$total"
echo "DIRTY_COUNT=$dirty"
echo "AHEAD=$ahead"
echo "BEHIND=$behind"
echo "BRANCH=$best"

# Check needs_setup: .bit.defaults with applied=false
needs_setup="false"
if [ "$path_exists" = "true" ] && [ -f .bit.defaults ]; then
    if command -v python3 >/dev/null 2>&1; then
        needs_setup=$(python3 -c "
import json,sys
try:
    d=json.load(open('.bit.defaults'))
    m=d.get('__conf_json__',{{}})
    print('true' if m and not m.get('applied',True) else 'false')
except: print('false')
" 2>/dev/null)
    else
        if grep -q '"applied".*false' .bit.defaults 2>/dev/null; then
            needs_setup="true"
        fi
    fi
fi
echo "NEEDS_SETUP=$needs_setup"
echo "PATH_EXISTS=$path_exists"
'''


def _parse_summary_output(output: str) -> dict:
    """Parse KEY=VALUE lines from batched summary script output."""
    summary = {
        "repo_count": 0,
        "dirty_count": 0,
        "ahead": 0,
        "behind": 0,
        "branch": "",
        "needs_setup": False,
        "exists": True,
    }
    for line in output.strip().splitlines():
        line = line.strip()
        if "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip().lower()
        value = value.strip()
        if key == "repo_count":
            summary["repo_count"] = int(value)
        elif key == "dirty_count":
            summary["dirty_count"] = int(value)
        elif key == "ahead":
            summary["ahead"] = int(value)
        elif key == "behind":
            summary["behind"] = int(value)
        elif key == "branch":
            summary["branch"] = value
        elif key == "needs_setup":
            summary["needs_setup"] = value == "true"
        elif key == "path_exists":
            summary["exists"] = value == "true"
    return summary


def ssh_get_dashboard_summary(user: str, host: str, path: str,
                              timeout: int = 60) -> dict:
    """Gather repo-level summary for a remote project (single SSH call).

    Returns the same dict shape as ``_get_dashboard_summary()``:
    ``{repo_count, dirty_count, ahead, behind, branch, needs_setup}``.
    """
    empty = {"repo_count": 0, "dirty_count": 0, "ahead": 0,
             "behind": 0, "branch": "", "needs_setup": False,
             "exists": True}
    script = _SUMMARY_SCRIPT.format(path=shlex.quote(path))
    try:
        r = ssh_run(user, host, f"bash -c {shlex.quote(script)}", timeout=timeout)
        if r.returncode != 0:
            return dict(empty)
        return _parse_summary_output(r.stdout)
    except (subprocess.TimeoutExpired, OSError, ValueError):
        return dict(empty)


# --- Update helpers ---

def ssh_run_single_repo_update(user: str, host: str, repo: str,
                               branch: str, action: str) -> bool:
    """Run ``git pull --rebase`` or ``git pull`` on a remote repo over SSH.

    Returns True on success.
    """
    if action not in ("rebase", "merge"):
        return False
    if not branch:
        return False

    pull_cmd = "git pull --rebase" if action == "rebase" else "git pull"
    cmd = f"cd {shlex.quote(repo)} && {pull_cmd}"
    try:
        r = ssh_run(user, host, cmd, timeout=120)
        return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False


# --- Remote bit detection (cached) ---

_bit_cache: Dict[str, Tuple[float, bool]] = {}
_BIT_CACHE_TTL = 300.0  # 5 minutes

_tmux_cache: Dict[str, Tuple[float, bool]] = {}
_TMUX_CACHE_TTL = 300.0  # 5 minutes

_BIT_CONFIG_DIR = os.path.expanduser("~/.config/bit")
_DEFAULT_TMUX_PREFIX = "C-a"


_EXTRA_PATH = "$HOME/.cache/bit:$HOME/bin:$HOME/.local/bin"


def _remote_has_tmux(user: str, host: str) -> bool:
    """Check whether tmux is available on the remote host (5min cache)."""
    key = f"{user}@{host}"
    now = time.monotonic()
    if key in _tmux_cache:
        ts, has_tmux = _tmux_cache[key]
        if now - ts < _TMUX_CACHE_TTL:
            return has_tmux

    try:
        r = ssh_run(user, host, "command -v tmux >/dev/null 2>&1", timeout=10)
        has_tmux = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        has_tmux = False

    _tmux_cache[key] = (now, has_tmux)
    return has_tmux


def _tmux_session_name(path: str) -> str:
    """Derive a tmux session name from a remote project path."""
    basename = os.path.basename(path.rstrip("/"))
    sanitized = re.sub(r'[^a-zA-Z0-9_-]', '-', basename)
    return f"bit-{sanitized}"


def get_tmux_prefix() -> str:
    """Get configured tmux prefix key from global config.

    Defaults to ``C-a`` so it doesn't collide with an outer tmux using
    the default ``C-b``.
    """
    config_file = os.path.join(_BIT_CONFIG_DIR, "projects.json")
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__tmux_prefix__", _DEFAULT_TMUX_PREFIX)
        except (json.JSONDecodeError, OSError):
            pass
    return _DEFAULT_TMUX_PREFIX


def set_tmux_prefix(prefix: str) -> None:
    """Set tmux prefix key in global config."""
    os.makedirs(_BIT_CONFIG_DIR, exist_ok=True)
    config_file = os.path.join(_BIT_CONFIG_DIR, "projects.json")
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__tmux_prefix__"] = prefix
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2, sort_keys=True)
    except OSError:
        pass


def _tmux_wrap(session_name: str, window_name: str, inner_cmd: str,
               prefix: Optional[str] = None) -> str:
    """Build a shell snippet that runs inner_cmd inside a named tmux session.

    If the session already exists, adds a new window and attaches.
    Otherwise creates a new session, sets the prefix key, and attaches.
    """
    q_session = shlex.quote(session_name)
    q_window = shlex.quote(window_name)
    q_cmd = shlex.quote(inner_cmd)

    if prefix:
        q_prefix = shlex.quote(prefix)
        # Create detached so we can set prefix before attaching
        new_session = (
            f"tmux new-session -d -s {q_session} -n {q_window} {q_cmd}; "
            f"tmux set-option -t {q_session} prefix {q_prefix}; "
            f"exec tmux attach-session -t {q_session}"
        )
    else:
        new_session = (
            f"exec tmux new-session -s {q_session} -n {q_window} {q_cmd}"
        )

    return (
        f"if tmux has-session -t {q_session} 2>/dev/null; then "
        f"tmux new-window -t {q_session} -n {q_window} {q_cmd}; "
        f"exec tmux attach-session -t {q_session}; "
        f"else "
        f"{new_session}; "
        f"fi"
    )


def _find_local_bit() -> Optional[str]:
    """Find the path to the local bit zipapp binary."""
    # sys.argv[0] is the script/zipapp path when invoked directly
    candidate = os.path.abspath(sys.argv[0])
    if os.path.isfile(candidate):
        return candidate
    # Fallback: search PATH
    which = shutil.which("bit")
    if which:
        return which
    return None


def _deploy_bit_to_remote(user: str, host: str) -> bool:
    """Auto-deploy the local bit binary to ``~/.cache/bit/bit`` on the remote.

    Pipes the zipapp over a single SSH call.  Returns True on success.
    """
    local_bit = _find_local_bit()
    if not local_bit:
        return False

    local_size = os.path.getsize(local_bit)
    target = f"{user}@{host}" if user else host

    # Check if remote already has the same version (by file size)
    try:
        r = ssh_run(user, host,
                    'stat -c%s "$HOME/.cache/bit/bit" 2>/dev/null || echo 0',
                    timeout=10)
        if r.returncode == 0:
            remote_size = int(r.stdout.strip())
            if remote_size == local_size:
                return True  # Already deployed and up to date
    except (subprocess.TimeoutExpired, OSError, ValueError):
        pass

    # Deploy
    try:
        with open(local_bit, "rb") as f:
            r = subprocess.run(
                ["ssh", *_ssh_mux_opts(),
                 "-o", "BatchMode=yes",
                 "-o", "ConnectTimeout=5",
                 "-o", "StrictHostKeyChecking=accept-new",
                 target,
                 'mkdir -p "$HOME/.cache/bit" && '
                 'cat > "$HOME/.cache/bit/bit" && '
                 'chmod +x "$HOME/.cache/bit/bit"'],
                stdin=f,
                capture_output=True,
                timeout=60,
                env=_ssh_no_prompt_env(),
            )
            return r.returncode == 0
    except (subprocess.TimeoutExpired, OSError, IOError):
        return False


def remote_has_bit_cached(user: str, host: str) -> bool:
    """Check whether ``bit`` is installed on the remote host (5min cache).

    Extends PATH with common user-local directories so that standalone
    installs in ``~/bin`` are found.
    """
    key = f"{user}@{host}"
    now = time.monotonic()
    if key in _bit_cache:
        ts, has_bit = _bit_cache[key]
        if now - ts < _BIT_CACHE_TTL:
            return has_bit

    try:
        r = ssh_run(user, host,
                    f'PATH="{_EXTRA_PATH}:$PATH" command -v bit '
                    '>/dev/null 2>&1',
                    timeout=10)
        has_bit = r.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        has_bit = False

    _bit_cache[key] = (now, has_bit)
    return has_bit


# --- Action dispatch with fallback ---

def remote_run_action(user: str, host: str, path: str, cmd: str) -> int:
    """Run a bit command on a remote project with fallback chain.

    1. Try ``bit <cmd>`` on remote (if bit is installed)
    2. For git operations (update): dispatch raw git commands
    3. Ultimate fallback: open a shell at the project directory

    Returns exit code (0 = success).  Always returns (never replaces
    the process) so the dashboard loop can continue.
    """
    from ..core import Colors
    from .common import log_message

    # Pre-check: verify SSH auth works before launching interactive session.
    # This prevents password/askpass prompts from hijacking the terminal.
    if not ssh_check_connection(user, host):
        log_message(f"{Colors.red('✗')} SSH connection to {host} failed — check agent/key")
        # Invalidate connection cache so next attempt retries
        _ssh_connection_cache.pop(f"{user}@{host}", None)
        return 1

    # Stage 1: ensure remote has current bit version.
    # Always deploy so the streamed copy stays current; PATH puts
    # ~/.cache/bit first so it wins over stale installs in ~/bin.
    if _deploy_bit_to_remote(user, host):
        has_bit = True
        _bit_cache[f"{user}@{host}"] = (time.monotonic(), True)
    else:
        has_bit = remote_has_bit_cached(user, host)

    if has_bit:
        # Extend PATH inline so bit is found; no bash -l -c wrapper
        # so that fzf gets direct PTY access for proper terminal handling.
        # Set BIT_REMOTE_HOST so remote bit menus show ⇄ indicator.
        inner_cmd = (f'export PATH="{_EXTRA_PATH}:$PATH" '
                     f'BIT_REMOTE_HOST={shlex.quote(host)} && '
                     f"cd {shlex.quote(path)} && bit {cmd}")
        if _remote_has_tmux(user, host):
            session = _tmux_session_name(path)
            window = cmd.split()[0]
            prefix = get_tmux_prefix()
            full_cmd = _tmux_wrap(session, window, inner_cmd, prefix)
        else:
            full_cmd = inner_cmd
        target = f"{user}@{host}" if user else host
        try:
            r = subprocess.run(
                ["ssh", "-t", *_ssh_mux_opts(),
                 "-o", "ConnectTimeout=5", target, full_cmd],
                stderr=subprocess.PIPE,
                timeout=300,
                env=_ssh_no_prompt_env(),
            )
            _log_ssh_stderr(r.stderr)
            return r.returncode
        except (subprocess.TimeoutExpired, OSError):
            pass

    # Stage 2: for update commands, try raw git
    if cmd.strip() in ("update", "update -y"):
        repos = ssh_get_git_repos(user, host, path)
        if repos:
            ok = True
            for repo in repos:
                branch = ssh_current_branch(user, host, repo)
                if branch:
                    if not ssh_run_single_repo_update(user, host, repo,
                                                      branch, "rebase"):
                        ok = False
            return 0 if ok else 1

    # Stage 3: fallback to interactive shell (subprocess, not exec)
    log_message(f"{Colors.yellow('Note:')} bit not available on {host}, opening shell at {path}")
    remote_shell(user, host, path)
    return 0


def remote_shell(user: str, host: str, path: str,
                 replace_process: bool = False) -> None:
    """Open an interactive SSH shell at the remote project directory.

    Looks for ``oe-init-build-env`` in the project tree (up to 3 levels
    deep inside a ``layers`` subdirectory, or in the project root) and
    sources it — mirroring the local ``run_init_shell`` behaviour.
    Falls back to a plain login shell if no init script is found.

    When *replace_process* is True, replaces the current process via
    ``os.execvp`` (used for standalone shell action).  Otherwise runs
    as a subprocess and returns when the user exits the shell.
    """
    target = f"{user}@{host}" if user else host
    qpath = shlex.quote(path)

    # Build a shell snippet that finds oe-init-build-env on the remote,
    # creates a temp rcfile that sources ~/.bashrc then the OE init script,
    # and starts bash --rcfile so the environment is fully set up.
    # Mirrors the local run_init_shell behaviour.
    shell_cmd = f'''\
cd {qpath} || exit 1
_proj="$PWD"
_oe_init=""
[ -f oe-init-build-env ] && _oe_init="$_proj/oe-init-build-env"
if [ -z "$_oe_init" ] && [ -d layers ]; then
    _found=$(find layers -maxdepth 3 -name oe-init-build-env -type f 2>/dev/null | head -1)
    [ -n "$_found" ] && _oe_init="$_proj/$_found"
fi
if [ -n "$_oe_init" ]; then
    _tpl=""
    _d=$(dirname "$_oe_init")
    for _t in "$_d"/../*/conf/templates/default; do
        [ -d "$_t" ] || continue
        case "$_t" in *meta-poky*) _tpl=$(cd "$_t" && pwd); break;; esac
        [ -z "$_tpl" ] && _tpl=$(cd "$_t" && pwd)
    done
    _rc=$(mktemp /tmp/bit-oe-XXXXXX)
    [ -f ~/.bashrc ] && printf '. ~/.bashrc\\n' >> "$_rc"
    printf 'cd "%s"\\n' "$_proj" >> "$_rc"
    [ -n "$_tpl" ] && printf 'export TEMPLATECONF="%s"\\n' "$_tpl" >> "$_rc"
    printf '. "%s"\\n' "$_oe_init" >> "$_rc"
    printf 'PS1="(oe) $PS1"\\n' >> "$_rc"
    printf 'rm -f "%s"\\n' "$_rc" >> "$_rc"
    exec bash --rcfile "$_rc"
else
    exec $SHELL -l
fi\
'''
    if _remote_has_tmux(user, host):
        session = _tmux_session_name(path)
        prefix = get_tmux_prefix()
        shell_cmd = _tmux_wrap(session, "shell", shell_cmd, prefix)
    ssh_argv = [
        "ssh", "-t",
        *_ssh_mux_opts(),
        "-o", "ConnectTimeout=5",
        target,
        shell_cmd,
    ]
    env = _ssh_no_prompt_env()
    if replace_process:
        os.environ.update(env)
        os.execvp("ssh", ssh_argv)
        # Does not return
    else:
        r = subprocess.run(ssh_argv, stderr=subprocess.PIPE, env=env)
        _log_ssh_stderr(r.stderr)
        return r.returncode


# --- Remote commit helpers ---

def ssh_get_commit_log(user: str, host: str, repo: str,
                       count: int = 200,
                       since: str = "") -> List[Tuple[str, str]]:
    """Fetch recent commits from a remote repo.

    Args:
        since: If set, only return commits reachable from HEAD but not
            from *since* (i.e. ``since..HEAD``).  Typically the local
            HEAD hash so only "new" remote commits are shown.

    Returns ``[(full_hash, subject), ...]`` in oldest-first order,
    matching the format ``fzf_explore_commits()`` uses for *local_commits*.
    """
    qrepo = shlex.quote(repo)
    if since:
        # Commits on remote that are not in local — git log since..HEAD
        cmd = (f"git -C {qrepo} log "
               f"--format='%H %s' --reverse {shlex.quote(since)}..HEAD")
    else:
        cmd = (f"git -C {qrepo} log "
               f"--format='%H %s' --reverse -{count}")
    try:
        r = ssh_run(user, host, cmd, timeout=30)
        if r.returncode != 0:
            return []
        results = []
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if not line:
                continue
            parts = line.split(" ", 1)
            if len(parts) == 2:
                results.append((parts[0], parts[1]))
            elif parts:
                results.append((parts[0], ""))
        return results
    except (subprocess.TimeoutExpired, OSError):
        return []


def ssh_get_branch_info(user: str, host: str,
                        repo: str) -> Tuple[str, str]:
    """Fetch branch name and upstream ref in a single SSH call.

    Returns ``(branch, upstream_ref)``.  *upstream_ref* is empty when
    the branch has no tracking configuration.
    """
    script = (
        f'cd {shlex.quote(repo)} && '
        f'b=$(git rev-parse --abbrev-ref HEAD 2>/dev/null) && echo "BRANCH=$b"; '
        f'u=$(git rev-parse --abbrev-ref "@{{u}}" 2>/dev/null) && echo "UPSTREAM=$u"'
    )
    branch = ""
    upstream = ""
    try:
        r = ssh_run(user, host, script, timeout=15)
        for line in r.stdout.strip().splitlines():
            line = line.strip()
            if line.startswith("BRANCH="):
                branch = line[7:]
            elif line.startswith("UPSTREAM="):
                upstream = line[9:]
    except (subprocess.TimeoutExpired, OSError):
        pass
    return (branch, upstream)


def ssh_format_patch_stdout(user: str, host: str, repo: str,
                            commits: List[str],
                            timeout: int = 120) -> str:
    """Run ``git format-patch --stdout`` on the remote for selected commits.

    Returns the raw mbox text as a string (all patches concatenated).
    For a contiguous range, uses a range spec; otherwise generates
    individual ``-1 <hash>`` patches.
    """
    if not commits:
        return ""

    # Build the format-patch command — individual -1 for each commit
    parts = []
    for h in commits:
        parts.append(
            f"git -C {shlex.quote(repo)} format-patch --stdout -1 {shlex.quote(h)}"
        )
    cmd = " && ".join(parts)

    try:
        r = ssh_run(user, host, cmd, timeout=timeout)
        if r.returncode != 0:
            return ""
        return r.stdout
    except (subprocess.TimeoutExpired, OSError):
        return ""


# --- Convenience helpers for project detection ---

def is_remote_project(project_info: dict) -> bool:
    """Return True if a project dict represents a remote (SSH) project.

    The single authoritative test: the dict contains a ``"host"`` key.
    """
    return bool(project_info.get("host"))
