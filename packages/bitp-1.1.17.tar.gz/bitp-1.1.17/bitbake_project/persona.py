#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Persona system for bit.

A persona defines how bit discovers repos and which commands are available.
The default persona is "yocto" (repo discovery via bblayers.conf); the
"generic" persona discovers repos by scanning for .git/ directories.

Selection priority (highest wins):
    1. CLI flag: --persona <name>
    2. Environment variable: BIT_PERSONA=<name>
    3. Per-project config: "persona" field in project registry entry
    4. Global config: ~/.config/bit/config.json → {"persona": "yocto"}
    5. Default: "yocto"
"""

import json
import os
from typing import Dict, List, Optional, Set, Tuple


class Persona:
    """Base class for bit personas."""

    name: str = ""
    description: str = ""

    # ---- Repo discovery (THE critical method) ----

    def resolve_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = True,
        discover_all: bool = True,
    ) -> Tuple[list, object]:
        """Discover repos for this persona.

        Returns:
            (pairs, repo_sets) where pairs is a list of (layer_path, repo_path)
            tuples and repo_sets carries discovery metadata.
        """
        raise NotImplementedError

    def collect_repos(
        self,
        config_path: Optional[str],
        defaults: Optional[dict] = None,
        include_external: bool = False,
        discover_all: bool = False,
    ) -> Tuple[list, object]:
        """Collect unique repos (convenience wrapper around resolve_repos)."""
        raise NotImplementedError

    # ---- Command tree ----

    def get_commands(self) -> List[tuple]:
        """Return persona-specific COMMAND_TREE entries."""
        return []

    def get_command_categories(self) -> Dict[str, tuple]:
        """Return persona-specific COMMAND_CATEGORIES entries."""
        return {}

    # ---- CLI integration ----

    def add_global_args(self, parser) -> None:
        """Add persona-specific global arguments to the CLI parser."""

    def get_completers(self) -> dict:
        """Return tab-completion providers keyed by argument name."""
        return {}

    # ---- Project detection ----

    def matches_project(self, path: str) -> float:
        """Return confidence (0.0–1.0) that path is a project of this type.

        Used for auto-detection when adding projects. Higher = better match.
        Subclasses should override with persona-specific file marker checks.
        """
        return 0.0

    # ---- Dashboard integration ----

    def detect_project_info(self, path: str) -> dict:
        """Detect persona-specific info about a project directory."""
        return {}

    def get_dashboard_actions(self, path: str) -> list:
        """Return persona-specific dashboard quick actions."""
        return []

    # ---- Config integration ----

    def get_config_sections(self) -> list:
        """Return persona-specific config UI sections."""
        return []


# ---------------------------------------------------------------------------
# Persona registry
# ---------------------------------------------------------------------------

_PERSONAS: Dict[str, Persona] = {}


def register_persona(persona: Persona) -> None:
    """Register a persona instance by name."""
    _PERSONAS[persona.name] = persona


def _ensure_registered() -> None:
    """Lazily register built-in personas on first access."""
    if _PERSONAS:
        return

    from .personas.yocto import YoctoPersona
    register_persona(YoctoPersona())

    # GenericPersona will be registered in Phase 6
    try:
        from .personas.generic import GenericPersona
        register_persona(GenericPersona())
    except ImportError:
        pass


def get_persona(
    cli_persona: Optional[str] = None,
    project: Optional[dict] = None,
) -> Persona:
    """Return the active persona based on selection priority.

    Args:
        cli_persona: --persona flag value (highest priority)
        project: Active project dict (may contain "persona" key)

    Returns:
        The resolved Persona instance (defaults to Yocto).
    """
    _ensure_registered()

    # 1. CLI flag
    name = cli_persona

    # 2. Environment variable
    if not name:
        name = os.environ.get("BIT_PERSONA")

    # 3. Per-project config
    if not name and project:
        name = project.get("persona")

    # 4. Global config
    if not name:
        try:
            with open(_global_config_path(), encoding="utf-8") as f:
                cfg = json.load(f)
            name = cfg.get("persona")
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass

    # 5. Default
    if not name:
        name = "yocto"

    persona = _PERSONAS.get(name)
    if persona is None:
        available = ", ".join(sorted(_PERSONAS)) or "(none)"
        raise ValueError(
            f"Unknown persona '{name}'. Available: {available}"
        )
    return persona


def list_personas() -> List[str]:
    """Return names of all registered personas."""
    _ensure_registered()
    return sorted(_PERSONAS)


def detect_persona(path: str) -> Optional[str]:
    """Auto-detect the best persona for a project path.

    Returns the persona name with the highest confidence, or None if
    no persona scores above 0.
    """
    _ensure_registered()
    best_name = None
    best_score = 0.0
    for name, persona in _PERSONAS.items():
        score = persona.matches_project(path)
        if score > best_score:
            best_score = score
            best_name = name
    return best_name


def _global_config_path() -> str:
    """Return path to ~/.config/bit/config.json."""
    return os.path.join(
        os.environ.get("XDG_CONFIG_HOME", os.path.expanduser("~/.config")),
        "bit", "config.json",
    )


def get_global_default_persona() -> str:
    """Read the global default persona from config (or 'yocto')."""
    try:
        with open(_global_config_path(), encoding="utf-8") as f:
            cfg = json.load(f)
        return cfg.get("persona") or "yocto"
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return "yocto"


def set_global_default_persona(name: str) -> None:
    """Write the global default persona to ~/.config/bit/config.json."""
    path = _global_config_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    try:
        with open(path, encoding="utf-8") as f:
            cfg = json.load(f)
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        cfg = {}
    cfg["persona"] = name
    with open(path, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2)
        f.write("\n")
