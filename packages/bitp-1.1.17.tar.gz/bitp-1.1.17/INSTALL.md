# Installation

## Requirements

**Required:**
- Python 3.9 or later
- Git

**Optional (recommended):**
- [fzf](https://github.com/junegunn/fzf) - for interactive menus and navigation
- [argcomplete](https://github.com/kislyuk/argcomplete) - for bash tab completion
- xclip or xsel - for clipboard support on Linux

## Installation Options

### Option 1: Standalone Binary (Recommended)

Download the standalone zipapp - a single executable file with no dependencies:

```bash
# Download the standalone binary
curl -o ~/.local/bin/bit \
  https://gitlab.com/bruce-ashfield/bitbake-project/-/raw/main/dist/bit

# Make it executable
chmod +x ~/.local/bin/bit

# Ensure ~/.local/bin is in your PATH
echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
source ~/.bashrc
```

### Option 2: Clone and Build Standalone

```bash
# Clone the repository
git clone https://gitlab.com/bruce-ashfield/bitbake-project.git ~/git/bitbake-project

# Build the standalone
cd ~/git/bitbake-project
python3 scripts/build-standalone.py

# Create symlink in your PATH
ln -s ~/git/bitbake-project/dist/bit ~/.local/bin/bit
```

### Option 3: Pip Install (Development)

```bash
# Clone and install as editable package
git clone https://gitlab.com/bruce-ashfield/bitbake-project.git ~/git/bitbake-project
cd ~/git/bitbake-project
pip install -e .

# With tab completion support
pip install -e ".[completion]"

# With development dependencies
pip install -e ".[dev]"
```

### Option 4: System-wide Install

```bash
# Build standalone first
python3 scripts/build-standalone.py

# Install system-wide
sudo cp dist/bit /usr/local/bin/
sudo chmod +x /usr/local/bin/bit
```

## Installing Dependencies

### fzf (Recommended)

fzf provides the interactive menus. Without it, the tool falls back to text prompts.
fzf 0.40.0+ is recommended. Version 0.53.0+ enables preview debounce for smoother browsing.

**Ubuntu/Debian:**
```bash
sudo apt install fzf
```

**Fedora:**
```bash
sudo dnf install fzf
```

**From source:**
```bash
git clone --depth 1 https://github.com/junegunn/fzf.git ~/.fzf
~/.fzf/install
```

### argcomplete (Optional)

Enables bash tab completion for commands, repo names, and options.

```bash
pip install argcomplete
```

Then add to your `~/.bashrc`:
```bash
eval "$(register-python-argcomplete bit)"
```

Reload your shell:
```bash
source ~/.bashrc
```

**Verify it works:**
```bash
bit config <TAB>    # Should show repo names
bit -<TAB>          # Should show options
```

### Clipboard Support (Optional)

For copying commands to clipboard (used by `init` and `search` commands).

**Ubuntu/Debian:**
```bash
sudo apt install xclip
# or
sudo apt install xsel
```

**Fedora:**
```bash
sudo dnf install xclip
# or
sudo dnf install xsel
```

## Verifying Installation

```bash
# Check version/help
bit --help

# Run the interactive menu (requires fzf)
bit

# Check tab completion (requires argcomplete)
bit --completion
```

## Updating

### If installed via git clone:
```bash
cd ~/git/bitbake-project
git pull
python3 scripts/build-standalone.py  # Rebuild standalone
```

### If installed via direct download:
```bash
curl -o ~/.local/bin/bit \
  https://gitlab.com/bruce-ashfield/bitbake-project/-/raw/main/dist/bit
chmod +x ~/.local/bin/bit
```

### If installed via pip:
```bash
cd ~/git/bitbake-project
git pull
pip install -e .
```

## Uninstalling

```bash
# Remove the script/symlink
rm ~/.local/bin/bit

# If pip installed
pip uninstall bitbake-project

# Remove configuration files (optional, in your project directories)
rm -f .bit.defaults
rm -f .bit.export-state.json
rm -f .bit.prep-state.json

# Remove cache (optional)
rm -rf ~/.cache/bit
```

## Troubleshooting

### "command not found: bit"

Ensure the script location is in your PATH:
```bash
echo $PATH | tr ':' '\n' | grep -E "(local/bin|bitbake)"
```

If not, add it:
```bash
export PATH="$HOME/.local/bin:$PATH"
```

### fzf menus not appearing

Check if fzf is installed:
```bash
which fzf
```

If not installed, the tool will fall back to text prompts. Install fzf for the best experience.

### Tab completion not working

1. Verify argcomplete is installed:
   ```bash
   python3 -c "import argcomplete" && echo "OK"
   ```

2. Check if the completion is registered:
   ```bash
   complete -p bit
   ```

3. Re-run the setup:
   ```bash
   eval "$(register-python-argcomplete bit)"
   ```

### Clipboard not working

Check for xclip or xsel:
```bash
which xclip xsel
```

Install one of them if missing. On Wayland, you may need `wl-copy` instead.

### Permission denied

Make the script executable:
```bash
chmod +x /path/to/bit
```

### "bitbake-getvar not found" in config

This is expected if you haven't sourced the OE build environment:
```bash
source oe-init-build-env
```

The config command will work but project-level variable expansion requires bitbake tools.
