#!/usr/bin/env python3
#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Build a standalone single-file version of bit using zipapp.

This creates a .pyz file that Python can execute directly, preserving
the full module structure with no text processing.

Usage:
    python scripts/build-standalone.py
    # Output: dist/bit (executable pyz file)
"""

import os
import shutil
import stat
import sys
import zipapp
from pathlib import Path

# Project paths
PROJECT_ROOT = Path(__file__).parent.parent
PACKAGE_DIR = PROJECT_ROOT / "bitbake_project"
OUTPUT_DIR = PROJECT_ROOT / "dist"
OUTPUT_FILE = OUTPUT_DIR / "bit"
BUILD_DIR = PROJECT_ROOT / "build" / "zipapp"


def build_standalone():
    """Build the standalone script using zipapp."""
    print("Building standalone bit (zipapp)...")
    print(f"  Source: {PACKAGE_DIR}")
    print(f"  Output: {OUTPUT_FILE}")

    # Clean and create build directory
    if BUILD_DIR.exists():
        shutil.rmtree(BUILD_DIR)
    BUILD_DIR.mkdir(parents=True)

    # Copy package to build directory
    dest_package = BUILD_DIR / "bitbake_project"
    shutil.copytree(PACKAGE_DIR, dest_package)

    # Create __main__.py at the root level for zipapp entry point
    main_py = BUILD_DIR / "__main__.py"
    main_py.write_text('''\
#!/usr/bin/env python3
# PYTHON_ARGCOMPLETE_OK
from bitbake_project.cli import main
import sys
sys.exit(main())
''')

    # Create output directory
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    # Build the zipapp
    zipapp.create_archive(
        BUILD_DIR,
        OUTPUT_FILE,
        interpreter='/usr/bin/env python3',
        compressed=True,
    )

    # Make executable
    os.chmod(OUTPUT_FILE, os.stat(OUTPUT_FILE).st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    # Clean up build directory
    shutil.rmtree(BUILD_DIR.parent)

    # Show file size
    size_kb = OUTPUT_FILE.stat().st_size / 1024
    print(f"  Size: {size_kb:.1f} KB")
    print("  Done!")

    return 0


if __name__ == "__main__":
    sys.exit(build_standalone())
