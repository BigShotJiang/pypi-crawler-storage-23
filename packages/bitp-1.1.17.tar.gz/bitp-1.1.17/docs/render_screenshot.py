#!/usr/bin/env python3
"""Render terminal-style screenshots from text content.

Usage:
    python3 docs/render_screenshot.py

Generates PNG images in docs/images/ that look like terminal windows.
"""

import os
import re
from PIL import Image, ImageDraw, ImageFont

# ── Theme ──────────────────────────────────────────────────────────────
BG = (30, 30, 46)          # dark background
FG = (205, 214, 244)       # default text
DIM = (108, 112, 134)      # dim/gray
CYAN = (137, 220, 235)     # cyan
GREEN = (166, 227, 161)    # green
RED = (243, 139, 168)      # red
YELLOW = (249, 226, 175)   # yellow
MAGENTA = (203, 166, 247)  # magenta
BLUE = (137, 180, 250)     # blue
WHITE = (255, 255, 255)
TITLEBAR_BG = (49, 50, 68)
TITLEBAR_FG = (166, 173, 200)
BORDER = (69, 71, 90)

CHAR_W = 10
CHAR_H = 20
PAD_X = 16
PAD_Y = 12
TITLEBAR_H = 36


def _find_font(size=16):
    """Find a monospace font."""
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationMono-Regular.ttf",
        "/usr/share/fonts/truetype/ubuntu/UbuntuMono-R.ttf",
        "/usr/share/fonts/truetype/hack/Hack-Regular.ttf",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return ImageFont.truetype(path, size)
    return ImageFont.load_default()


def _parse_ansi_color(text):
    """Parse text with simplified color markers and return [(text, color)] segments."""
    # Support markers: {cyan}, {green}, {dim}, {red}, {yellow}, {magenta}, {blue}, {/}
    color_map = {
        "cyan": CYAN, "green": GREEN, "dim": DIM, "red": RED,
        "yellow": YELLOW, "magenta": MAGENTA, "blue": BLUE, "white": WHITE,
        "bold": WHITE,
    }
    segments = []
    current_color = FG
    parts = re.split(r'\{(\w+|/)\}', text)
    for i, part in enumerate(parts):
        if i % 2 == 0:
            if part:
                segments.append((part, current_color))
        else:
            if part == "/":
                current_color = FG
            elif part in color_map:
                current_color = color_map[part]
    return segments


def render_terminal(lines, title="bit", filename="screenshot.png", width_chars=100):
    """Render lines of text as a terminal window PNG."""
    font = _find_font(16)
    bold_font = _find_font(16)

    height_chars = len(lines)
    img_w = width_chars * CHAR_W + PAD_X * 2
    img_h = height_chars * CHAR_H + PAD_Y * 2 + TITLEBAR_H

    img = Image.new("RGB", (img_w, img_h), BG)
    draw = ImageDraw.Draw(img)

    # Title bar
    draw.rectangle([0, 0, img_w, TITLEBAR_H], fill=TITLEBAR_BG)
    # Window dots
    dot_y = TITLEBAR_H // 2
    for i, color in enumerate([(255, 95, 86), (255, 189, 46), (39, 201, 63)]):
        draw.ellipse([12 + i * 22, dot_y - 6, 24 + i * 22, dot_y + 6], fill=color)
    # Title text
    draw.text((img_w // 2 - len(title) * CHAR_W // 2, 8), title, fill=TITLEBAR_FG, font=font)

    # Content
    y = TITLEBAR_H + PAD_Y
    for line in lines:
        x = PAD_X
        segments = _parse_ansi_color(line)
        for text, color in segments:
            draw.text((x, y), text, fill=color, font=font)
            x += len(text) * CHAR_W
        y += CHAR_H

    # Border
    draw.rectangle([0, 0, img_w - 1, img_h - 1], outline=BORDER, width=1)

    output_dir = os.path.join(os.path.dirname(__file__), "images")
    os.makedirs(output_dir, exist_ok=True)
    output_path = os.path.join(output_dir, filename)
    img.save(output_path, "PNG")
    print(f"  Saved: {output_path}")
    return output_path


def main():
    print("Rendering screenshots...")

    # ── 1. Dashboard ──
    render_terminal([
        "{dim}    Name                Branch       Status               Path{/}",
        "{dim}  ─────────────────────────────────────────────────────────────────────────────────────────────{/}",
        "  {dim}- ⌂ Local{/}",
        "{green}>   - ● poky              master       6 repos {yellow}↓37{/}{green}         /opt/bruce/poky{/}  {dim}[main poky build]{/}",
        "      {dim}├─{/} {cyan}explore{/}       Browse commits and repos",
        "      {dim}├─{/} {cyan}update{/}        Update git repos",
        "      {dim}├─{/} {cyan}config{/}        Repo and layer settings",
        "      {dim}├─{/} {cyan}export{/}        Export config to .conf.json",
        "      {dim}└─{/} {cyan}shell{/}         Build environment shell",
        "    + ○ test              master       3 repos {yellow}↓139{/}        /opt/bruce/poky-test",
        "{dim}  ╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌{/}",
        "  {dim}- ⇄ Remote ── build4{/}",
        "    + ○ poky-build4       master      11 repos {cyan}↑26{/}         bruce@build4:/opt/bruce/poky",
        "    {dim}└─{/} {cyan}sync{/}          Sync projects from this host",
        "{dim}  ╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌╌{/}",
        "  {dim}- ⇄ Remote ── xps{/}",
        "    + ○ master            master       7 repos {red}✎1{/} {cyan}↑9{/} {yellow}↓32{/}   bruce@xps:/home/bruce/poky/build",
        "    + ○ poky-kirkstone    kirkstone    1 repos {cyan}↑7{/}          bruce@xps:/opt/bruce/poky-kirkstone",
        "    + ○ poky-scarthgap    scarthgap    1 repos {cyan}↑10{/}         bruce@xps:/opt/bruce/poky-scarthgap",
        "    - ○ poky-whinlatter   whinlatter   3 repos {cyan}↑8{/}          bruce@xps:/opt/bruce/poky-whinlatter",
        "      {dim}├─{/} {cyan}explore{/}       Browse commits and repos",
        "      {dim}├─{/} {cyan}update{/}        Update git repos",
        "      {dim}├─{/} {cyan}config{/}        Repo and layer settings",
        "      {dim}├─{/} {cyan}export{/}        Export config to .conf.json",
        "      {dim}├─{/} {cyan}shell{/}         Build environment shell",
        "      {dim}└─{/} {cyan}properties{/}    Project name and description",
        "    + ○ poky-xps          master      11 repos {red}✎1{/} {cyan}↑9{/} {yellow}↓32{/}   bruce@xps:/home/bruce/poky/",
        "    {dim}└─{/} {cyan}sync{/}          Sync projects from this host",
        "{dim}  ─────────────────────────────────────────────────────────────────────────────────────────────{/}",
        "  {dim}⚙  Manage projects...{/}",
        "  {dim}⚙  Configure...{/}",
        "  {green}✓ Activated: poky{/}",
        "{dim}  Space=activate | Enter/→=open | \\=fold | ?/m=commands | +/-=add/remove | q=quit{/}",
        "{dim}  x=explore | u=update | c=config | S=shell | R=refresh | M=messages | P=persona | /,ctrl-s=search{/}",
        "{cyan}  Dashboard:{/} ",
    ], title="bit projects", filename="dashboard.png", width_chars=100)

    # ── 2. Explore repos view ──
    render_terminal([
        "{dim}    Name                  Commits,   Branch            Status{/}",
        "{dim}  ─────────────────────────────────────────────────────────────{/}",
        "{white}  + openembedded-core       0 local, master            [clean]{/}",
        "{white}  + meta-yocto              0 local, master            [clean]{/}",
        "{white}  + meta-openembedded       0 local, master {yellow}↓ upstream{/} [clean]{/}",
        "{white}    meta-security           0 local, master            [clean]{/}",
        "{green}>   meta-virtualization     0 local, master {yellow}↓ upstream{/} [clean]{/}",
        "{white}    bitbake                 0 local, master            [clean]{/}",
        "",
        "{dim}    project               config                       build/conf{/}",
        "{dim}    info                  build                        layers + variables{/}",
        "{dim}  [poky] {/}{cyan}REPOS VIEW{/}{dim} | Enter=explore | q=quit | L=layers view{/}",
        "{cyan}  Update:{/}{dim} u=single | U=all | m=merge | r=refresh | R=refresh all | b=branch | B=branch all{/}",
        "{cyan}  View:{/}{dim} v=verbose | Enter/←/→/\\=fold | t=history | S=shell | M=messages{/}",
        "{cyan}  Manage:{/}{dim} a/d=add/remove | +/-=track/hide | c=config | A=discover{/}",
        "{cyan}  Yocto:{/}{dim} i=info | ctrl-r=recipes | D=deps | f=fragments{/}",
        "{cyan}  Select repo:{/} ",
    ], title="bit explore", filename="explore.png", width_chars=95)

    # ── 3. Explore expanded (layers visible) ──
    render_terminal([
        "{dim}    Name                  Commits,   Branch            Status{/}",
        "{dim}  ─────────────────────────────────────────────────────────────{/}",
        "{white}  + openembedded-core       0 local, master            [clean]{/}",
        "{dim}    ├─ meta{/}",
        "{dim}    ├─ meta-selftest (?){/}",
        "{dim}    └─ meta-skeleton (?){/}",
        "{white}  + meta-yocto              0 local, master            [clean]{/}",
        "{green}>   ├─ meta-poky{/}",
        "{dim}    └─ meta-yocto-bsp{/}",
        "{white}  + meta-openembedded       0 local, master {yellow}↓ upstream{/} [clean]{/}",
        "{dim}    ├─ meta-oe{/}",
        "{dim}    ├─ meta-python{/}",
        "{dim}    ├─ meta-networking{/}",
        "{dim}    ├─ meta-filesystems{/}",
        "{dim}    └─ meta-perl{/}",
        "{dim}  [poky] {/}{cyan}REPOS VIEW{/}{dim} | Enter=explore | q=quit | L=layers view{/}",
        "{cyan}  Yocto:{/}{dim} i=info | ctrl-r=recipes | D=deps | f=fragments{/}",
        "{cyan}  Select repo:{/} ",
    ], title="bit explore (expanded)", filename="explore-expanded.png", width_chars=95)

    # ── 4. Recipe browser ──
    render_terminal([
        "{green}> + busybox                          1.37.0       meta               Tiny versions of common UNIX utilities{/}",
        "  + curl                             8.12.1       meta               Command line tool and library for transferring data",
        "  + gstreamer1.0                     1.24.12      meta               GStreamer multimedia framework",
        "  + linux-yocto                      6.12+git     meta               Linux kernel",
        "  + mesa                             25.0.1       meta               Mesa graphics library",
        "  + openssh                          9.9p2        meta               Secure rlogin/rsh/rcp/telnet replacement",
        "  + python3                          3.13.2       meta               The Python Programming Language",
        "  + systemd                          257.2        meta               System and Service Manager",
        "  + u-boot                           2025.01      meta               Universal Boot Loader",
        "  + zlib                             1.3.1        meta               Zlib Compression Library",
        "",
        "{dim}  [Configured+Local] 1841 recipes{/}",
        "{dim}  Enter/→=expand | ←=collapse | ctrl-v=view | ctrl-e=edit | alt-c=copy | alt-d=deps | ctrl-f=file{/}",
        "{dim}  ctrl-g=group | ctrl-s=search | ctrl-r=reset | esc=quit{/}",
        "{cyan}  Recipe (Configured+Local):{/} ",
    ], title="bit recipes --layer meta", filename="recipes.png", width_chars=105)

    # ── 5. Recipe with deps expanded ──
    render_terminal([
        "  - {white}busybox                          1.37.0       meta               Tiny versions of common UNIX utilities{/}",
        "    ├─ + {white}virtual/libc                                meta{/}",
        "    ├─ + {white}virtual/crypt                               meta{/}",
        "    ├─ + {white}update-rc.d                  0.8            meta{/}",
        "    └─ + {magenta}update-alternatives-opkg      0.1.0          meta{/} {dim}(runtime){/}",
        "  + curl                             8.12.1       meta               Command line tool and library for transferring data",
        "  + gstreamer1.0                     1.24.12      meta               GStreamer multimedia framework",
        "{green}> + linux-yocto                      6.12+git     meta               Linux kernel{/}",
        "  + mesa                             25.0.1       meta               Mesa graphics library",
        "  + openssh                          9.9p2        meta               Secure rlogin/rsh/rcp/telnet replacement",
        "",
        "{dim}  [Configured+Local] 1841 recipes{/}",
        "{dim}  Enter/→=expand | ←=collapse | ctrl-v=view | ctrl-e=edit | alt-c=copy | alt-d=deps | ctrl-f=file{/}",
        "{cyan}  Recipe (Configured+Local):{/} ",
    ], title="bit recipes", filename="recipes-deps.png", width_chars=105)

    # ── 6. Commit browser ──
    render_terminal([
        "{dim}  ○  {/}{yellow}01a65e8{/}  {white}Bruce Ashfield{/}     layer.conf: update to scarthgap              {dim}2 days ago{/}",
        "{dim}  ○  {/}{yellow}f2c8b91{/}  {white}Richard Purdie{/}     bitbake: Update to 2.10 release branch        {dim}3 days ago{/}",
        "{green}> ○  {/}{yellow}de4abc0{/}  {white}Ross Burton{/}        devtool: ide-sdk: vscode: replace scripts     {dim}4 days ago{/}",
        "{dim}  ○  {/}{yellow}9b3d2e1{/}  {white}Alexander Kanavin{/}  python3: upgrade 3.13.1 -> 3.13.2             {dim}5 days ago{/}",
        "{dim}  ○  {/}{yellow}a1f9c42{/}  {white}Khem Raj{/}           gcc: Update to 14.3 snapshot                  {dim}5 days ago{/}",
        "{dim}  ○  {/}{yellow}7e2d5a3{/}  {white}Bruce Ashfield{/}     linux-yocto/6.12: update to v6.12.15          {dim}6 days ago{/}",
        "{dim}  ○  {/}{yellow}c4b8e12{/}  {white}Steve Sakoman{/}       mesa: upgrade 25.0.0 -> 25.0.1                {dim}1 week ago{/}",
        "{dim}  ○  {/}{yellow}8f1a3d7{/}  {white}Wang Mingyu{/}         curl: upgrade 8.12.0 -> 8.12.1                {dim}1 week ago{/}",
        "{dim}  ○  {/}{yellow}b5e9f23{/}  {white}Richard Purdie{/}     systemd: upgrade 257.1 -> 257.2               {dim}1 week ago{/}",
        "",
        "{dim}  [openembedded-core] meta ← master (0 local, 127 upstream){/}",
        "{dim}  Tab=mark | Space=range | d=diff | ?=preview | e=export | t=tig | ←/b=back | q=quit{/}",
        "{cyan}  Commit:{/} ",
    ], title="bit explore → commits", filename="commits.png", width_chars=105)

    print("\nDone! Images saved to docs/images/")


if __name__ == "__main__":
    main()
