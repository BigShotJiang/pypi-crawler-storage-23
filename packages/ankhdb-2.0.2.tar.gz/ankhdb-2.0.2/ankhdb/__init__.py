"""
AnkhDB Python SDK v2.0.2
https://github.com/your-org/ankhdb
"""
import json
import requests
from urllib.parse import urlencode

ANKHDB_SERVER_URL = "https://ankhdb-server.up.railway.app"


# ─── Error Taxonomy ────────────────────────────────────────────────────────────

class AnkhDBError(Exception):
    """Base exception for all AnkhDB SDK errors."""
    def __init__(self, message: str, status: int = None, raw=None):
        super().__init__(message)
        self.status = status
        self.raw    = raw

class AuthError(AnkhDBError):
    """Raised on 401 Unauthorized responses."""

class PermissionError(AnkhDBError):
    """Raised on 403 Forbidden responses."""

class ValidationError(AnkhDBError):
    """Raised on 400 Bad Request responses."""

class NotFoundError(AnkhDBError):
    """Raised on 404 Not Found responses."""

class RateLimitError(AnkhDBError):
    """Raised on 429 Too Many Requests responses."""

class ServerError(AnkhDBError):
    """Raised on 5xx server error responses."""


def _raise_for_status(status: int, message: str, raw=None):
    if status == 400: raise ValidationError(message, status, raw)
    if status == 401: raise AuthError(message, status, raw)
    if status == 403: raise PermissionError(message, status, raw)
    if status == 404: raise NotFoundError(message, status, raw)
    if status == 429: raise RateLimitError(message, status, raw)
    if status >= 500: raise ServerError(message, status, raw)
    raise AnkhDBError(message, status, raw)


# ─── Query Builder ─────────────────────────────────────────────────────────────

class AnkhQuery:
    """Chainable query builder for a collection."""

    def __init__(self, db: "AnkhDB", collection: str):
        self._db         = db
        self._collection = collection
        self._filters    = {}
        self._limit      = None
        self._offset     = None
        self._joins      = []

    def _add_filter(self, field: str, op: str, value):
        self._filters.setdefault(field, {})[op] = value
        return self

    def eq(self, field, value):  return self._add_filter(field, "eq",  value)
    def neq(self, field, value): return self._add_filter(field, "neq", value)
    def gt(self, field, value):  return self._add_filter(field, "gt",  value)
    def gte(self, field, value): return self._add_filter(field, "gte", value)
    def lt(self, field, value):  return self._add_filter(field, "lt",  value)
    def lte(self, field, value): return self._add_filter(field, "lte", value)

    def limit(self, n: int):  self._limit  = n; return self
    def offset(self, n: int): self._offset = n; return self

    def join(self, foreign_collection: str, fk_field: str):
        self._joins.append(f"{foreign_collection}:{fk_field}")
        return self

    def _build_qs(self) -> str:
        parts = []
        for field, ops in self._filters.items():
            for op, val in ops.items():
                parts.append(f"filter[{field}][{op}]={val}")
        if self._limit  is not None: parts.append(f"limit={self._limit}")
        if self._offset is not None: parts.append(f"offset={self._offset}")
        for j in self._joins:       parts.append(f"join={j}")
        return ("?" + "&".join(parts)) if parts else ""

    def select(self)              -> list:  return self._db._request(f"/db/{self._collection}{self._build_qs()}")
    def get(self, doc_id: str)    -> dict:  return self._db._request(f"/db/{self._collection}/{doc_id}")
    def insert(self, data: dict)  -> dict:  return self._db._request(f"/db/{self._collection}", method="POST", body=data)
    def update(self, doc_id, data: dict) -> dict: return self._db._request(f"/db/{self._collection}/{doc_id}", method="PUT", body=data)
    def delete(self, doc_id: str) -> dict:  return self._db._request(f"/db/{self._collection}/{doc_id}", method="DELETE")

    def subscribe(self, callback):
        """
        Stream realtime events for this collection (blocking generator).
        Usage:
            for event in db.from_collection('posts').subscribe():
                print(event)
        Or pass a callback:
            db.from_collection('posts').subscribe(lambda e: print(e))
        """
        url = f"{self._db.base_url}/db/{self._collection}/realtime"
        with requests.get(url, headers=self._db._headers, stream=True) as resp:
            for line in resp.iter_lines():
                if line and line.startswith(b"data:"):
                    try:
                        payload = json.loads(line[5:].strip())
                        callback(payload)
                    except Exception:
                        pass


# ─── Main Client ───────────────────────────────────────────────────────────────

class AnkhDB:
    """
    Client for the AnkhDB Backend-as-a-Service platform.

    Args:
        project_id (str): Your Project ID (proj_...).
        api_key    (str): Your Project API Key (ankh_sec_...).
        server_url (str): Override the server URL. Defaults to production.
        token      (str): Optional bearer token for an authenticated end-user.
    """

    def __init__(self, project_id: str, api_key: str, server_url: str = None, token: str = None):
        self.project_id = project_id
        self.api_key    = api_key
        self.base_url   = (server_url or ANKHDB_SERVER_URL).rstrip("/")
        self.token      = token

    @property
    def _headers(self) -> dict:
        h = {
            "Content-Type": "application/json",
            "x-api-key":    self.api_key,
            "x-project-id": self.project_id,
        }
        if self.token:
            h["Authorization"] = f"Bearer {self.token}"
        return h

    def _request(self, path: str, method: str = "GET", body: dict = None):
        url      = f"{self.base_url}{path}"
        response = requests.request(method, url, headers=self._headers, json=body)
        if response.ok:
            return response.json()
        try:
            msg = response.json().get("error", response.text)
        except Exception:
            msg = response.text
        _raise_for_status(response.status_code, msg, response.text)

    # ─── Collection query builder ───────────────────────────────────────────────

    def from_collection(self, name: str) -> AnkhQuery:
        """Return a chainable query builder for the given collection."""
        return AnkhQuery(self, name)

    def get_collections(self) -> list:
        return self._request("/db/").get("collections", [])

    # ─── Auth ───────────────────────────────────────────────────────────────────

    def register(self, email: str, password: str) -> dict:
        """Register a new end-user. Auto-sets token if email verification is not required."""
        data = self._request("/api/auth/register", method="POST", body={"email": email, "password": password})
        if data and "token" in data:
            self.token = data["token"]
        return data

    def login(self, email: str, password: str) -> dict:
        """Login an end-user. Auto-stores the returned JWT token."""
        data = self._request("/api/auth/login", method="POST", body={"email": email, "password": password})
        if data and "token" in data:
            self.token = data["token"]
        return data

    def logout(self):
        """Clear the local token."""
        self.token = None

    def get_session(self) -> dict:
        """Verify the current end-user token and return their info."""
        return self._request("/api/auth/session")

    # ─── Storage ────────────────────────────────────────────────────────────────

    def storage_upload(self, filepath: str, filename: str = None) -> dict:
        """Upload a local file to the Storage service."""
        import os
        fname = filename or os.path.basename(filepath)
        headers = {k: v for k, v in self._headers.items() if k != "Content-Type"}
        with open(filepath, "rb") as f:
            resp = requests.post(f"{self.base_url}/storage/upload", headers=headers, files={"file": (fname, f)})
        if resp.ok:
            return resp.json()
        _raise_for_status(resp.status_code, resp.json().get("error", "Upload failed"), resp.text)

    def storage_list(self) -> list:   return self._request("/storage/files")
    def storage_get(self, fid: str):  return self._request(f"/storage/files/{fid}")
    def storage_delete(self, fid: str): return self._request(f"/storage/files/{fid}", method="DELETE")

    # ─── Edge Functions ─────────────────────────────────────────────────────────

    def invoke_function(self, name: str, payload: dict = None) -> dict:
        """Invoke an Edge Function by name."""
        return self._request(f"/edge/invoke/{name}", method="POST", body=payload or {})
