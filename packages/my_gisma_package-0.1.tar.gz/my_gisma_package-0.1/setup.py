from setuptools import setup, find_packages

 

setup(

    name='my_gisma_package',                    # Your package name

    version='0.1',                        # Version number

    packages=find_packages(),             # Automatically find packages

    install_requires=[],                  # List dependencies if any

    author='AmirTariq',                   # Your name

    author_email='amir.tariq7@gmail.com',# Your email

    description='A brief description of your package',

    url='https://github.com/amirtariqmehmood/my_gisma_package', # Your project URL

)
