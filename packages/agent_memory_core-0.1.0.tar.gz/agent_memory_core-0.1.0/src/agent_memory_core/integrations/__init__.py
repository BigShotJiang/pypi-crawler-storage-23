"""Platform integrations for agent-memory-core."""
