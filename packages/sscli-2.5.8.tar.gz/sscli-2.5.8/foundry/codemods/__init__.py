"""
Codemods module for safe configuration transformations.

This module provides a clean, type-safe interface for modifying project
configuration files (especially pyproject.toml) using proper parsing
instead of string manipulation.
"""

from foundry.codemods.base import (
    BaseCodemod,
    TomlTransformer,
    CodemodPipeline,
    ModificationResult
)

from foundry.codemods.toml_codemods import (
    AddPythonDependencyCM,
    RemovePythonDependencyCM,
    RemoveToolSectionsCM,
    UpdateValueCM,
    AddPythonVersionCM,
    IdempotentAddDependencyCM
)

from foundry.codemods.delta_store import (
    CodemodMetadata,
    CodemodDefinition,
    DeltaStore
)

__all__ = [
    # Base classes
    "BaseCodemod",
    "TomlTransformer",
    "CodemodPipeline",
    "ModificationResult",
    # Concrete implementations
    "AddPythonDependencyCM",
    "RemovePythonDependencyCM",
    "RemoveToolSectionsCM",
    "UpdateValueCM",
    "AddPythonVersionCM",
    "IdempotentAddDependencyCM",
    # Delta Store (Phase 3)
    "CodemodMetadata",
    "CodemodDefinition",
    "DeltaStore",
]
