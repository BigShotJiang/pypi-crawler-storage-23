from datetime import date, datetime
from typing import Optional

from rich.console import Console

from .models import AlphaInfo, ExpirationStatus
from .view import show_expiration_message, show_status, show_warning_message

console = Console()


class AlphaExpirationManager:
    """Central manager for alpha package expiration."""

    def __init__(self):
        """Initialize the expiration manager."""
        self.alpha_info: Optional[AlphaInfo] = None
        self._load_from_auth()

    def _load_from_auth(self) -> None:
        """Load and parse license info from local auth credentials."""
        try:
            from foundry.auth import get_current_license_info

            info = get_current_license_info()
            if not info or info.get("tier") != "alpha":
                return

            user_id = info.get("user_id", "local-user")
            email = info.get("email", "unknown")
            expires_str = info.get("expires", date.today().isoformat())
            issued_str = info.get("issued", date.today().isoformat())

            expires = datetime.strptime(expires_str, "%Y-%m-%d").date()
            issued = datetime.strptime(issued_str, "%Y-%m-%d").date()

            today = date.today()
            days_remaining = (expires - today).days
            status = self._determine_status(expires, days_remaining)

            self.alpha_info = AlphaInfo(
                user_id=user_id,
                email=email,
                issue_date=issued,
                expires=expires,
                status=status,
                days_remaining=days_remaining,
            )
        except Exception as e:
            console.print(f"[yellow]⚠️  Warning: Could not load license info: {e}[/yellow]")

    def _determine_status(self, expires: date, days_remaining: int) -> ExpirationStatus:
        if days_remaining < 0:
            return ExpirationStatus.EXPIRED
        return ExpirationStatus.WARNING if days_remaining <= 7 else ExpirationStatus.ACTIVE

    def is_alpha(self) -> bool:
        return self.alpha_info is not None

    def is_expired(self) -> bool:
        return self.alpha_info is not None and self.alpha_info.status == ExpirationStatus.EXPIRED

    def is_near_expiration(self) -> bool:
        return self.alpha_info is not None and self.alpha_info.status in [
            ExpirationStatus.WARNING,
            ExpirationStatus.EXPIRED,
        ]

    def check_before_action(self, action: str = "Generate Project") -> bool:
        if not self.is_alpha():
            return True

        if self.is_expired():
            show_expiration_message(self.alpha_info)
            return False

        if self.is_near_expiration():
            show_warning_message(self.alpha_info)

        return True

    def show_status(self) -> None:
        if not self.is_alpha():
            console.print("[dim]Not running in alpha mode[/dim]")
            return
        show_status(self.alpha_info)
