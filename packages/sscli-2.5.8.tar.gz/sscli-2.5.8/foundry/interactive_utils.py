import questionary
from questionary import Choice
from pathlib import Path
from foundry.constants import console, QUESTIONARY_STYLE
from foundry.actions.health import run_health_check
from foundry.actions.setup import run_setup
from foundry.utils import is_internal_dev


def manage_config_menu():
    while True:
        action = questionary.select(
            "Configuration Management:",
            choices=[
                Choice("🔍 View Validation Status", value="validate", description="Check Docker builds and installation status"),
                Choice("⚙️  Run Template Setup (Full Suite)", value="setup", description="Install and configure all available templates"),
                "Back",
            ],
            style=questionary.Style(QUESTIONARY_STYLE)
        ).ask()
        
        # Map choice values back
        if action == "validate":
            action = "View Validation Status"
        elif action == "setup":
            action = "Run Template Setup (Full Suite)"

        if action == "Back":
            break

        if action == "View Validation Status":
            run_health_check()
            pause()

        if action == "Run Template Setup (Full Suite)":
            run_setup()
            pause()


def pause():
    input("\nPress Enter to return...")


def internal_ops_menu():
    """Menu for internal development and ops tasks."""
    try:
        from foundry.ops.manager import InternalManager
        from foundry.ops.runner import run_verification_script
        from foundry.ops.menus import manage_licenses_menu, generate_pdf_menu
    except ImportError:
        console.print("[red]Ops manager not available in this build.[/]")
        return

    # Show auth status for internal devs too
    from foundry.auth import get_current_license_info
    auth_info = get_current_license_info()
    if auth_info.get("tier") != "free":
        console.print(f"[green]✓ Authenticated as {auth_info.get('tier', 'user').upper()}[/green]")
    else:
        console.print("[yellow]⚠️  Not authenticated - limited access[/yellow]")

    manager = InternalManager()

    while True:
        # Build choices based on internal dev mode
        base_choices = [
            Choice("🔧 Verify All Builds (Docker)", value="builds", description="Run Docker build verification for all templates"),
            Choice("🧹 Run Hygiene Checks (Repo Health)", value="hygiene", description="Check code quality and file structure standards"),
            Choice("📊 Full Verification Suite", value="full", description="Run all verification checks (builds, hygiene, runtime)"),
            Choice("🗑️  Clean Verification Reports", value="clean", description="Remove previous verification result files"),
        ]
        
        # Only show admin/sensitive options in internal dev mode
        if is_internal_dev():
            base_choices.extend([
                Choice("🎫 Manage Licenses (User/Org)", value="licenses", description="Upgrade users and organizations to PRO/ALPHA tiers"),
                Choice("📄 Generate Onboarding Materials (PDF)", value="pdf", description="Create branded PDF guides for customers"),
            ])
        
        base_choices.append("Back to Main")
        
        choice = questionary.select(
            "Foundry Ops - Internal Development:",
            choices=base_choices,
            style=questionary.Style(QUESTIONARY_STYLE),
        ).ask()
        
        # Map choice values back
        if choice == "builds":
            choice = "Verify All Builds (Docker)"
        elif choice == "hygiene":
            choice = "Run Hygiene Checks (Repo Health)"
        elif choice == "full":
            choice = "Full Verification Suite"
        elif choice == "clean":
            choice = "Clean Verification Reports"
        elif choice == "licenses":
            choice = "Manage Licenses (User/Org)"
        elif choice == "pdf":
            choice = "Generate Onboarding Materials (PDF)"

        if not choice or choice == "Back to Main":
            break

        if choice == "Verify All Builds (Docker)":
            manager.verify_builds()
            pause()
        elif choice == "Run Hygiene Checks (Repo Health)":
            from pathlib import Path
            root_dir = Path(__file__).parent.parent.parent.parent
            run_verification_script(
                root_dir, "verify_hygiene", "Code Hygiene (File Lengths)"
            )
            pause()
        elif choice == "Full Verification Suite":
            manager.verify_full_suite()
            pause()
        elif choice == "Clean Verification Reports":
            manager.clean_reports()
            pause()
        elif choice == "Manage Licenses (User/Org)" and is_internal_dev():
            manage_licenses_menu()
            pause()
        elif choice == "Generate Onboarding Materials (PDF)" and is_internal_dev():
            generate_pdf_menu()
            pause()
