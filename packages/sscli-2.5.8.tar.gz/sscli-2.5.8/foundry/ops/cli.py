import typer
from foundry.constants import console
from foundry.ops.manager import InternalManager
from foundry.ops.version_manager import VersionManager

ops_app = typer.Typer(help="Internal maintenance commands.")

@ops_app.command("dev-mode")
def dev_mode():
    """Point sscli to the LOCAL license-server (localhost:8000)."""
    console.print("[bold yellow]Switching to LOCAL LICENSE SERVER (localhost:8000)...[/bold yellow]")

@ops_app.command("verify-builds")
def verify_builds():
    """Run docker builds for all templates."""
    manager = InternalManager()
    manager.verify_builds()


@ops_app.command("hygiene")
def hygiene():
    """Run code hygiene checks (file lengths)."""
    manager = InternalManager()
    manager.run_verification_script("verify_hygiene", "Code Hygiene (File Lengths)")


@ops_app.command("suite")
def suite():
    """Run full verification suite (Builds, Install, Runtime)."""
    manager = InternalManager()
    manager.verify_full_suite()


@ops_app.command("clean")
def clean():
    """Clean up verification reports."""
    manager = InternalManager()
    report = manager.root_dir / "verification_results.csv"
    if report.exists():
        report.unlink()
        console.print("Cleaned verification_results.csv")
    else:
        console.print("No report found.")


@ops_app.command("bump-version")
def bump_version(
    bump_type: str = typer.Argument(..., help="Version bump type (major|minor|patch)")
):
    """Bump semantic version and update all references.
    
    Examples:
        sscli ops bump-version patch    # 2.1.0 → 2.1.1
        sscli ops bump-version minor    # 2.1.0 → 2.2.0
        sscli ops bump-version major    # 2.1.0 → 3.0.0
    
    What it does:
    1. Updates version in pyproject.toml
    2. Updates all version references in docs (design spec, README)
    3. Stages changes with git add (does NOT commit)
    
    Next steps:
    - Review: git diff --cached
    - Commit: git commit -m "chore: bump sscli to vX.Y.Z"
    - Tag: git tag -a vX.Y.Z -m "Release vX.Y.Z"
    - Push: git push origin main --follow-tags
    """
    console.print("\n[bold cyan]════════════════════════════════════════[/bold cyan]")
    console.print("[bold cyan]sscli Version Bump[/bold cyan]")
    console.print("[bold cyan]════════════════════════════════════════[/bold cyan]\n")
    
    try:
        manager = VersionManager()
        current = manager.get_current_version()
        
        # Validate bump type
        if bump_type not in ("major", "minor", "patch"):
            console.print(f"[red]✗ Invalid bump type: {bump_type}[/red]")
            console.print("[yellow]Use: major, minor, or patch[/yellow]")
            raise typer.Exit(1)
        
        new = manager.increment_version(current, bump_type)
        
        console.print(f"Current Version: [yellow]v{current}[/yellow]")
        console.print(f"New Version: [green]v{new}[/green]\n")
        
        # Confirm
        confirmation = typer.confirm(f"Proceed with {bump_type} bump?")
        if not confirmation:
            console.print("[yellow]✗ Cancelled[/yellow]")
            raise typer.Exit(0)
        
        console.print("\n[blue]Updating files...[/blue]")
        
        # Perform bump
        result = manager.bump_version(bump_type)
        
        console.print(f"  [blue]pyproject.toml[/blue] ... [green]✓[/green]")
        if manager.design_spec.exists():
            console.print(f"  [blue]DESIGN_SPEC_LANDING_PAGE.md[/blue] ... [green]✓[/green]")
        if manager.readme.exists():
            console.print(f"  [blue]README.md[/blue] ... [green]✓[/green]")
        
        console.print("\n[blue]Staging changes...[/blue]")
        
        console.print(f"\n[green]✓ Changes staged with git add[/green]\n")
        
        console.print("[blue]Staged changes:[/blue]")
        console.print(result["staged_summary"])
        
        console.print("[yellow]⚠ Next steps:[/yellow]")
        console.print("  1. Review changes: [blue]git diff --cached[/blue]")
        console.print(f"  2. Commit changes: [blue]git commit -m \"chore: bump sscli to v{new}\"[/blue]")
        console.print(f"  3. Create git tag: [blue]git tag -a v{new} -m \"Release v{new}\"[/blue]")
        console.print("  4. Push to trigger CI/CD: [blue]git push origin main --follow-tags[/blue]")
        console.print(f"\n[green]✓ Ready for commit[/green]\n")
    
    except Exception as e:
        console.print(f"[red]✗ Error: {e}[/red]")
        raise typer.Exit(1)
