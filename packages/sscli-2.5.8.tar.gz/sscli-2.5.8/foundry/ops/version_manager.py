"""
Version Manager for sscli - Semantic versioning automation.

Handles bumping version numbers (major|minor|patch) and updating all
version references across the codebase. Stages changes but does NOT commit.
"""

import re
import subprocess
from pathlib import Path
from typing import Tuple
from foundry.constants import console


class VersionManager:
    """Manages semantic version bumping and documentation updates."""
    
    def __init__(self):
        """Initialize version manager with paths."""
        self.stack_cli_root = Path(__file__).parent.parent.parent
        self.foundry_meta_root = self.stack_cli_root.parent.parent.parent
        
        # Stack CLI
        self.pyproject = self.stack_cli_root / "pyproject.toml"
        self.readme = self.stack_cli_root / "README.md"
        
        # Documentation
        self.design_spec = self.foundry_meta_root / "docs" / "plans" / "DESIGN_SPEC_LANDING_PAGE.md"
        
        # Template paths
        self.react_client_package = self.foundry_meta_root / "templates" / "react-client" / "package.json"
        self.static_landing_package = self.foundry_meta_root / "templates" / "static-landing" / "package.json"
        self.static_landing_hero = self.foundry_meta_root / "templates" / "static-landing" / "src" / "components" / "Hero.astro"
        self.python_saas_pyproject = self.foundry_meta_root / "templates" / "python-saas" / "pyproject.toml"
        self.data_pipeline_pyproject = self.foundry_meta_root / "templates" / "data-pipeline" / "pyproject.toml"
        
        # Services
        self.license_server_pyproject = self.foundry_meta_root / "tooling" / "services" / "license-server" / "pyproject.toml"
    
    def get_current_version(self) -> str:
        """Read current version from pyproject.toml."""
        if not self.pyproject.exists():
            raise FileNotFoundError(f"pyproject.toml not found at {self.pyproject}")
        
        content = self.pyproject.read_text()
        match = re.search(r'^version = "([^"]+)"', content, re.MULTILINE)
        if not match:
            raise ValueError("Could not find version in pyproject.toml")
        
        return match.group(1)
    
    def parse_version(self, version: str) -> Tuple[int, int, int]:
        """Parse semantic version string into (major, minor, patch)."""
        parts = version.split('.')
        if len(parts) != 3:
            raise ValueError(f"Invalid version format: {version}")
        
        try:
            return int(parts[0]), int(parts[1]), int(parts[2])
        except ValueError:
            raise ValueError(f"Version parts must be integers: {version}")
    
    def increment_version(self, version: str, bump_type: str) -> str:
        """Increment version based on bump type."""
        if bump_type not in ("major", "minor", "patch"):
            raise ValueError(f"Invalid bump type: {bump_type}. Use major|minor|patch")
        
        major, minor, patch = self.parse_version(version)
        
        if bump_type == "major":
            return f"{major + 1}.0.0"
        elif bump_type == "minor":
            return f"{major}.{minor + 1}.0"
        else:  # patch
            return f"{major}.{minor}.{patch + 1}"
    
    def update_pyproject(self, current: str, new: str) -> None:
        """Update version in pyproject.toml."""
        content = self.pyproject.read_text()
        updated = re.sub(
            rf'^version = "{re.escape(current)}"',
            f'version = "{new}"',
            content,
            count=1,
            flags=re.MULTILINE
        )
        
        if updated == content:
            raise ValueError(f"Could not find version '{current}' in pyproject.toml")
        
        self.pyproject.write_text(updated)
    
    def update_design_spec(self, current: str, new: str) -> None:
        """Update version references in design spec."""
        if not self.design_spec.exists():
            console.print(f"[yellow]⚠ Design spec not found: {self.design_spec}[/yellow]")
            return
        
        content = self.design_spec.read_text()
        updated = content.replace(f"v{current}", f"v{new}")
        
        if updated != content:
            self.design_spec.write_text(updated)
    
    def update_readme(self, current: str, new: str) -> None:
        """Update version references in README if they exist."""
        if not self.readme.exists():
            return
        
        content = self.readme.read_text()
        if f"v{current}" in content:
            updated = content.replace(f"v{current}", f"v{new}")
            self.readme.write_text(updated)
    
    def _update_json_version(self, filepath: Path, current: str, new: str) -> None:
        """Update version in package.json files."""
        if not filepath.exists():
            return
        
        content = filepath.read_text()
        updated = re.sub(
            rf'"version":\s*"{re.escape(current)}"',
            f'"version": "{new}"',
            content,
            count=1
        )
        if updated != content:
            filepath.write_text(updated)
    
    def _update_poetry_version(self, filepath: Path, current: str, new: str) -> None:
        """Update version in Poetry pyproject.toml files."""
        if not filepath.exists():
            return
        
        content = filepath.read_text()
        updated = re.sub(
            rf'(version\s*=\s*)"{re.escape(current)}"',
            rf'\1"{new}"',
            content,
            count=1
        )
        if updated != content:
            filepath.write_text(updated)
    
    def _update_astro_version(self, filepath: Path, current: str, new: str) -> None:
        """Update version in Astro HTML/component files."""
        if not filepath.exists():
            return
        
        content = filepath.read_text()
        updated = content.replace(f"v{current}", f"v{new}")
        if updated != content:
            filepath.write_text(updated)
    
    def update_all_templates(self, current: str, new: str) -> None:
        """Update version across all templates and services."""
        # React client
        self._update_json_version(self.react_client_package, current, new)
        
        # Static landing
        self._update_json_version(self.static_landing_package, current, new)
        self._update_astro_version(self.static_landing_hero, current, new)
        
        # Python SaaS
        self._update_poetry_version(self.python_saas_pyproject, current, new)
        
        # Data Pipeline
        self._update_poetry_version(self.data_pipeline_pyproject, current, new)
        
        # License Server
        self._update_poetry_version(self.license_server_pyproject, current, new)
    
    def stage_changes(self, current: str, new: str) -> None:
        """Stage all updated files with git add."""
        files_to_stage = [
            self.pyproject,
            self.design_spec,
            self.readme,
            self.react_client_package,
            self.static_landing_package,
            self.static_landing_hero,
            self.python_saas_pyproject,
            self.data_pipeline_pyproject,
            self.license_server_pyproject,
        ]
        
        try:
            for filepath in files_to_stage:
                if filepath.exists():
                    # Check if file has changes
                    result = subprocess.run(
                        ["git", "diff", str(filepath.relative_to(self.foundry_meta_root))],
                        cwd=self.foundry_meta_root,
                        capture_output=True,
                        text=True
                    )
                    
                    if result.stdout or result.returncode != 0:  # Has changes or is untracked
                        subprocess.run(
                            ["git", "add", str(filepath.relative_to(self.foundry_meta_root))],
                            cwd=self.foundry_meta_root,
                            check=True,
                            capture_output=True
                        )
        
        except subprocess.CalledProcessError as e:
            raise RuntimeError(f"Failed to stage changes: {e.stderr}")
    
    def get_staged_summary(self) -> str:
        """Get summary of staged changes."""
        try:
            result = subprocess.run(
                ["git", "diff", "--cached", "--stat"],
                cwd=self.foundry_meta_root,
                capture_output=True,
                text=True,
                check=True
            )
            return result.stdout
        except subprocess.CalledProcessError:
            return "(could not get diff)"
    
    def bump_version(self, bump_type: str) -> dict:
        """
        Perform full version bump operation.
        
        Args:
            bump_type: One of 'major', 'minor', 'patch'
        
        Returns:
            Dictionary with before/after versions and summary
        """
        current_version = self.get_current_version()
        new_version = self.increment_version(current_version, bump_type)
        
        # Validate paths
        if not all(p.exists() for p in [self.pyproject]):
            raise ValueError("Required files not found")
        
        # Update all files
        self.update_pyproject(current_version, new_version)
        self.update_design_spec(current_version, new_version)
        self.update_readme(current_version, new_version)
        self.update_all_templates(current_version, new_version)
        
        # Stage changes
        self.stage_changes(current_version, new_version)
        
        # Get summary
        staged_summary = self.get_staged_summary()
        
        return {
            "current": current_version,
            "new": new_version,
            "bump_type": bump_type,
            "staged_summary": staged_summary
        }
