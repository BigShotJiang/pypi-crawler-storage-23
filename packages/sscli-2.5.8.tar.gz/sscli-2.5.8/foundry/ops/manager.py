import subprocess
from foundry.constants import TEMPLATES_DIR, TEMPLATE_REGISTRY, console
from rich.panel import Panel
from .reporter import create_result, write_report, clean_reports
from .runner import run_verification_script


class InternalManager:
    """Internal Manager for Seed & Source checks, verifications, and builds."""

    def __init__(self):
        self.root_dir = TEMPLATES_DIR
        self.templates = [{"name": k, "type": "docker"} for k in TEMPLATE_REGISTRY.keys()]

    def verify_builds(self):
        """Runs docker build for all templates to verify integrity."""
        console.print(Panel("[bold yellow]Internal Manager: Verifying Builds[/bold yellow]"))
        results = []
        for t in self.templates:
            name, path = t["name"], self.root_dir / t["name"]
            console.print(f"Testing: [cyan]{name}[/cyan] ... ", end="")
            if not path.exists():
                console.print("[red]MISSING DIRECTORY[/red]")
                results.append(create_result(name, "Failed", "Missing Directory"))
                continue
            try:
                cmd = ["docker", "build", "-t", f"test-{name}", "."]
                process = subprocess.run(cmd, cwd=path, capture_output=True, text=True)
                if process.returncode == 0:
                    console.print("[green]PASS[/green]")
                    results.append(create_result(name, "Success", "Build passed"))
                else:
                    console.print("[red]FAIL[/red]")
                    console.print(f"[dim]{process.stderr[:200]}...[/dim]")
                    results.append(create_result(name, "Failed", "Docker build failed"))
            except Exception as e:
                console.print(f"[red]ERROR: {e}[/red]")
                results.append(create_result(name, "Error", str(e)))
        write_report(self.root_dir, results)
        console.print("\n[bold green]Build verification cycle complete.[/bold green]")

    def verify_full_suite(self):
        """Runs the complete internal verification suite."""
        self.verify_builds()
        run_verification_script(self.root_dir, "verify_hygiene", "Code Hygiene (File Lengths)")
        run_verification_script(self.root_dir, "verify_installation", "Installation Verification")
        run_verification_script(self.root_dir, "verify_runtime", "Runtime Verification")

    def clean_reports(self):
        """Removes local verification CSV logs."""
        clean_reports(self.root_dir)
