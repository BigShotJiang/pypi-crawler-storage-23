"""Development tools sub-application."""
from typing import Optional
import typer
from foundry.constants import console
from foundry.telemetry import log_event
from foundry.actions.development import (
    dev_tools_menu,
    show_status,
    run_build,
    run_swap,
    run_bump_version,
)

dev_app = typer.Typer(help="Development and maintenance tools", invoke_without_command=True)


@dev_app.callback()
def dev_callback(ctx: typer.Context):
    """Development tools for maintenance and local testing."""
    if ctx.invoked_subcommand is None:
        log_event("COMMAND", "dev")
        dev_tools_menu()



@dev_app.command("status")
def status(
    verbose: bool = typer.Option(
        False, "--verbose", "-v", help="Show detailed dependency information"
    ),
):
    """Show development environment status (local build vs pip package)."""
    log_event("COMMAND", "dev status")
    show_status(verbose=verbose)


@dev_app.command("build")
def build(
    clean: bool = typer.Option(
        False, "--clean", help="Clean build artifacts before building"
    ),
):
    """Build distribution packages (wheel and sdist)."""
    log_event("COMMAND", "dev build")
    if run_build(clean=clean):
        console.print("[green]✓[/green] Build successful")
    else:
        console.print("[red]✗[/red] Build failed")
        raise typer.Exit(code=1)


@dev_app.command("swap")
def swap(
    target: Optional[str] = typer.Option(
        None, help="Target: 'local' or 'pip' (interactive if not specified)"
    ),
):
    """Switch between local and pip package installations."""
    log_event("COMMAND", "dev swap")
    if not run_swap(target=target):
        console.print("[red]✗[/red] Swap failed")
        raise typer.Exit(code=1)


@dev_app.command("bump")
def bump(
    bump_type: str = typer.Argument(
        ..., help="Version bump type: major, minor, or patch"
    ),
):
    """Bump the version of sscli (major, minor, or patch)."""
    log_event("COMMAND", f"dev bump {bump_type}")
    if bump_type not in ["major", "minor", "patch"]:
        console.print(f"[red]✗ Invalid bump type: {bump_type}[/red]")
        console.print("Valid types: major, minor, patch")
        raise typer.Exit(code=1)

    console.print(f"[bold cyan]→[/bold cyan] Bumping {bump_type} version...")
    if run_bump_version(bump_type=bump_type, auto_confirm=True):
        console.print("[green]✓[/green] Version bump complete")
    else:
        console.print("[red]✗[/red] Version bump failed")
        raise typer.Exit(code=1)
