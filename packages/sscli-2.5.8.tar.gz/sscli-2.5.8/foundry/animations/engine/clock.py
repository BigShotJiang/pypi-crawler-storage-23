"""
Animation clock for stable frame rates in the terminal.
"""

import time


class AnimationClock:
    """
    Controls animation timing and frame pacing.

    Features:
    - Frame-rate independent (configurable FPS)
    - Pause/resume capability
    - Frame skipping for performance
    - Time delta computation for smooth animations
    """

    def __init__(self, fps: int = 60, max_frame_skip: int = 3):
        self.fps = fps
        self.frame_duration = 1.0 / fps
        self.max_frame_skip = max_frame_skip

        self.frame_count = 0
        self.elapsed_time = 0.0
        self.is_paused = False
        self.is_stopped = False

        self._last_tick_time = time.time()
        self._accumulated_time = 0.0

    def tick(self) -> float:
        """
        Wait for next frame and return delta time since last tick.
        Handles frame skipping if we're falling behind.
        """
        if self.is_paused or self.is_stopped:
            return 0.0

        now = time.time()
        dt = now - self._last_tick_time
        self._last_tick_time = now

        self._accumulated_time += dt

        # If we're too fast, sleep until the next frame
        if self._accumulated_time < self.frame_duration:
            sleep_time = self.frame_duration - self._accumulated_time
            time.sleep(sleep_time)
            # Update now and dt after sleep
            now = time.time()
            dt = now - self._last_tick_time
            self._last_tick_time = now
            self._accumulated_time = self.frame_duration

        # Prevent spiral of death by capping accumulated time
        max_accumulated = self.frame_duration * self.max_frame_skip
        if self._accumulated_time > max_accumulated:
            self._accumulated_time = max_accumulated

        # Advance timing
        frames_to_advance = int(self._accumulated_time / self.frame_duration)
        delta = frames_to_advance * self.frame_duration

        self.frame_count += frames_to_advance
        self.elapsed_time += delta
        self._accumulated_time -= delta

        return delta

    def pause(self) -> None:
        """Pause animation updates."""
        self.is_paused = True

    def resume(self) -> None:
        """Resume animation from pause."""
        self.is_paused = False
        self._last_tick_time = time.time()

    def stop(self) -> None:
        """Stop animation completely."""
        self.is_stopped = True

    def reset(self) -> None:
        """Reset clock to initial state."""
        self.frame_count = 0
        self.elapsed_time = 0.0
        self.is_paused = False
        self.is_stopped = False
        self._last_tick_time = time.time()
        self._accumulated_time = 0.0
