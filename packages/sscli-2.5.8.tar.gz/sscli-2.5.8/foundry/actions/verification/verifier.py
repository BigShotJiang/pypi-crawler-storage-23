import subprocess
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Optional

from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn

from .models import TemplateType, VerificationResult, VerificationStatus

console = Console()


class TemplateVerifier:
    """Verifies template integrity and buildability."""

    TEMPLATES = {
        "python-saas": TemplateType.DOCKER,
        "rails-api": TemplateType.DOCKER,
        "rails-ui-kit": TemplateType.DOCKER,
        "data-pipeline": TemplateType.DOCKER,
        "react-client": TemplateType.DOCKER,
        "mobile-android": TemplateType.DOCKER,
        "mobile-ios": TemplateType.DOCKER,
        "terraform-infra": TemplateType.TERRAFORM,
    }

    REQUIRED_FILES = {
        TemplateType.DOCKER: [".gitignore", "Dockerfile", "README.md"],
        TemplateType.TERRAFORM: [".gitignore", "main.tf", "README.md"],
    }

    def __init__(self, root_dir: Path):
        self.root_dir = root_dir
        self.results: Dict[str, VerificationResult] = {}

    def verify_all(self, include_docker: bool = True) -> Dict[str, VerificationResult]:
        console.print(Panel("[bold cyan]Template Verification Suite[/bold cyan]\n[dim]Checking template integrity, files, and buildability[/dim]", style="cyan"))
        console.print(f"Root directory: {self.root_dir}\n")
        
        with Progress(SpinnerColumn(), TextColumn("[progress.description]{task.description}"), console=console) as progress:
            for template_name, template_type in self.TEMPLATES.items():
                task_id = progress.add_task(f"Verifying {template_name}...", total=None)
                self.results[template_name] = self._verify_template(template_name, template_type, include_docker)
                progress.update(task_id, completed=True)
        return self.results

    def _verify_template(self, name: str, ttype: TemplateType, include_docker: bool) -> VerificationResult:
        start_time = time.time()
        # Templates are now in templates/ subfolder
        template_path = self.root_dir / "templates" / name
        res = VerificationResult(name=name, template_type=ttype, status=VerificationStatus.SUCCESS,
                                 git_ignore=False, git_attributes=False, docker_success=False,
                                 duration_seconds=0, timestamp=datetime.now().isoformat())

        if not template_path.exists():
            res.status, res.notes = VerificationStatus.FAILED, f"Directory not found: {template_path}"
        else:
            self._check_files(template_path, ttype, res)
            if res.status != VerificationStatus.FAILED:
                if include_docker and ttype == TemplateType.DOCKER:
                    self._run_docker(template_path, name, res)
                elif ttype == TemplateType.TERRAFORM:
                    self._run_terraform(template_path, res)

        res.duration_seconds = time.time() - start_time
        return res

    def _check_files(self, path: Path, ttype: TemplateType, res: VerificationResult):
        res.git_ignore = (path / ".gitignore").exists()
        res.git_attributes = (path / ".gitattributes").exists()
        if not res.git_ignore:
            res.status, res.notes = VerificationStatus.FAILED, "Missing .gitignore"
            return
        for f in self.REQUIRED_FILES.get(ttype, []):
            if f != ".gitignore" and not (path / f).exists():
                res.status, res.notes = VerificationStatus.FAILED, f"Missing {f}"
                return

    def _run_docker(self, path: Path, name: str, res: VerificationResult):
        try:
            cmd = ["docker", "build", "-t", f"test-{name}:latest", "."]
            proc = subprocess.run(cmd, cwd=path, capture_output=True, text=True, timeout=600)
            res.docker_success = (proc.returncode == 0)
            res.status = VerificationStatus.SUCCESS if res.docker_success else VerificationStatus.FAILED
            if not res.docker_success:
                res.notes = proc.stderr.strip().split("\n")[-1] if proc.stderr else "Docker build failed"
        except subprocess.TimeoutExpired:
            res.status, res.notes = VerificationStatus.FAILED, "Docker build timeout (10+ minutes)"
        except Exception as e:
            res.status, res.notes = VerificationStatus.ERROR, str(e)

    def _run_terraform(self, path: Path, res: VerificationResult):
        try:
            subprocess.run(["terraform", "init", "-backend=false"], cwd=path, capture_output=True, text=True, timeout=60, check=True)
            subprocess.run(["terraform", "validate"], cwd=path, capture_output=True, text=True, timeout=60, check=True)
            res.status, res.docker_success = VerificationStatus.SUCCESS, True
        except subprocess.CalledProcessError as e:
            res.status, res.docker_success, res.notes = VerificationStatus.FAILED, False, "Terraform validation failed"
        except FileNotFoundError:
            res.status, res.docker_success, res.notes = VerificationStatus.FAILED, False, "Terraform CLI not found"
        except Exception as e:
            res.status, res.docker_success, res.notes = VerificationStatus.ERROR, False, str(e)
