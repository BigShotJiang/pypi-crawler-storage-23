import csv
from datetime import datetime
from pathlib import Path
from typing import Dict
from rich.console import Console
from rich.table import Table

from .models import VerificationResult, VerificationStatus

console = Console()


def generate_reports(results: Dict[str, VerificationResult], root_dir: Path) -> None:
    """Generate CSV and markdown reports."""
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    docs_dir = root_dir / "docs" / "verification"
    docs_dir.mkdir(parents=True, exist_ok=True)

    def write_csv(path: Path):
        with open(path, mode="w", newline="") as f:
            fieldnames = ["template", "type", "status", "git_ignore", "git_attributes", "docker_build", "duration", "notes", "timestamp"]
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            for res in results.values():
                writer.writerow(res.to_dict())

    def write_markdown(path: Path):
        lines = ["# Template Verification Report\n", f"**Generated**: {datetime.now().isoformat()}\n", f"**Root**: {root_dir.name}\n", "\n## Summary\n"]
        total, succeeded = len(results), sum(1 for r in results.values() if r.status == VerificationStatus.SUCCESS)
        failed, errors = sum(1 for r in results.values() if r.status == VerificationStatus.FAILED), sum(1 for r in results.values() if r.status == VerificationStatus.ERROR)
        lines.extend([f"- **Total**: {total}\n", f"- **Success**: {succeeded} ✅\n", f"- **Failed**: {failed} ❌\n", f"- **Errors**: {errors} ⚠️\n", "\n## Results\n\n", "| Template | Type | Status | Build/Validate | Duration | Notes |\n", "|----------|------|--------|----------------|----------|-------|\n"])
        for res in sorted(results.values(), key=lambda r: r.name):
            build_status = "✓" if res.docker_success else "✗" if res.status != VerificationStatus.SKIPPED else "-"
            lines.append(f"| {res.name} | {res.template_type.value} | {res.status.value} | {build_status} | {res.duration_seconds:.2f}s | {res.notes} |\n")
        path.write_text("".join(lines))

    write_csv(docs_dir / f"verification_results_{timestamp}.csv")
    write_markdown(docs_dir / f"verification_results_{timestamp}.md")
    write_csv(docs_dir / "verification_results_latest.csv")
    write_markdown(docs_dir / "verification_results_latest.md")

    console.print("\n📊 Reports generated in docs/verification")


def print_summary(results: Dict[str, VerificationResult]) -> int:
    """Print summary table and return exit code."""
    table = Table(title="Verification Results")
    table.add_column("Template", style="cyan")
    table.add_column("Type", style="magenta")
    table.add_column("Status", style="green")
    table.add_column("Git Config", style="yellow")
    table.add_column("Build/Validate", style="blue")
    table.add_column("Duration", style="white")

    exit_code = 0
    for res in sorted(results.values(), key=lambda r: r.name):
        status_style = {VerificationStatus.SUCCESS: "green", VerificationStatus.FAILED: "red", VerificationStatus.ERROR: "red"}.get(res.status, "white")
        git_ok = "✓" if (res.git_ignore and res.git_attributes) else "✗"
        build_status = "✓" if res.docker_success else "✗" if res.status != VerificationStatus.SKIPPED else "-"
        table.add_row(res.name, res.template_type.value, f"[{status_style}]{res.status.value}[/{status_style}]", git_ok, build_status, f"{res.duration_seconds:.2f}s")
        if res.status in [VerificationStatus.FAILED, VerificationStatus.ERROR]:
            exit_code = 1

    console.print(table)
    if exit_code != 0:
        console.print("\n[bold red]❌ Verification failed[/bold red]")
    else:
        console.print("\n[bold green]✅ Success[/bold green]")
    return exit_code
