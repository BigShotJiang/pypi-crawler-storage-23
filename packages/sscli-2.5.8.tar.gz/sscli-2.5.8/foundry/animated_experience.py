from foundry.constants import console
from foundry.actions.documentation import run_view_docs
from foundry.actions.explore import run_explore
from foundry.actions.generator import run_generator
from foundry.actions.validation import run_smoke_tests
from foundry.auth import get_current_license_info, login_flow
from foundry.interactive_utils import manage_config_menu, pause, internal_ops_menu
from foundry.utils import is_internal_dev
from foundry.gate import check_auth_gate, check_internal_gate

import questionary

from typing import cast, List
from foundry.animations.base import Animation


def run_animated_experience():
    """Plays the full robust animation sequence and handles user choice loop."""
    # Import animations here to avoid unbound variables
    try:
        from foundry.animations import (AnimationSequence,
                                        InteractiveAnimationEngine)
        from foundry.animations.scenes import (LogoDisperseAnimation,
                                               LogoRevealAnimation,
                                               LogoStaticAnimation,
                                               TranquilityAnimation,
                                               ForgeAnimation)
    except Exception:
        console.print("[bold red]Animation system not fully loaded.[/]")
        return

    # Check authentication status
    auth_info = check_auth_gate()
    if auth_info is None:
        console.print("[yellow]Goodbye![/yellow]")
        return

    gate_result = check_internal_gate(auth_info)
    if gate_result == "EXIT":
        console.print("[yellow]Goodbye![/yellow]")
        return
    elif gate_result == "INTERNAL":
        from foundry.internal_experience import run_internal_animated_experience
        run_internal_animated_experience()
        return
    elif gate_result == "DEVELOPMENT":
        from foundry.development_experience import run_development_animated_experience
        run_development_animated_experience()
        return

    engine = InteractiveAnimationEngine(fps=60, console=console)

    # 1. Play Intro Sequence once
    try:
        intro = AnimationSequence(
            cast(List[Animation], [
                LogoRevealAnimation(duration=1.2),
                LogoStaticAnimation(duration=1.0),
                LogoDisperseAnimation(duration=2.0),
            ])
        )
        engine.play(intro)
    except KeyboardInterrupt:
        console.print("[yellow]Goodbye![/yellow]")
        return
    except Exception as e:
        console.print(f"[red]Error during intro: {e}[/]")

    # 2. Main Menu Loop
    while True:
        try:
            # Play Tranquility with menu until a choice is made
            choice = engine.play(TranquilityAnimation())

            if not choice or choice == "Exit":
                console.print("[yellow]Goodbye![/yellow]")
                break

            # Dispatch the choice
            if choice == "Explore Templates":
                run_explore()
                pause()
            elif choice == "Generate Project":
                run_generator(interactive=True)
                pause()
            elif choice == "Manage Config":
                manage_config_menu()
            elif choice == "System Validation":
                run_smoke_tests()
                pause()
            elif choice == "View Docs":
                run_view_docs(interactive=True)
                pause()

        except KeyboardInterrupt:
            console.print("[yellow]Goodbye![/yellow]")
            break
        except Exception as e:
            console.print(f"[red]Error during menu: {e}[/]")
            break

