from setuptools import setup,find_packages

setup(
    name='jarvis_stt_lovejeet_2026',
    version='0.1',
    author='Lovejeet',
    author_email='lovejeetpatel1805@gmail.com',
    description = 'this is speech to text package created by lovejeet'
)
packages = find_packages(),
install_requirements = [
    'selenium',
    'webdriver_manager'
]



# D:\J.A.R.V.I.S\package