# UiPath Agent Framework Samples

Sample agents built with [Agent Framework](https://github.com/microsoft/agent-framework) and [UiPath LLM providers](../src/uipath_agent_framework/chat/).

## Samples

| Sample | Description |
|--------|-------------|
| [quickstart-agent](./quickstart-agent/) | Single agent with tool calling: fetches live weather data for any location |
| [multi-agent](./multi-agent/) | Multi-agent coordinator: delegates research and code execution to specialist sub-agents via `as_tool()` |
