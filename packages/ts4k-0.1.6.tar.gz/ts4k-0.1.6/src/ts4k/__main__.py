from ts4k.cli import main; main()
