"""ts4k — Token Saver 4000. Token-efficient messaging gateway for LLM agents."""

__version__ = "0.1.0"
