---
name: ts
description: "Token-efficient messaging gateway (Gmail, WhatsApp, O365). Run 'ts4k skill' for commands."
argument-hint: "updates | list -q QUERY | get ID | thread TID | overview"
disable-model-invocation: false
allowed-tools: Bash(ts4k *)
---

# ts — Token Saver communication hub

Run `ts4k skill` for available commands. Run `ts4k skill more` for admin commands.
