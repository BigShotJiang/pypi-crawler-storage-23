from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.post_public_logs_list_response_200_logs_item import PostPublicLogsListResponse200LogsItem





T = TypeVar("T", bound="PostPublicLogsListResponse200")



@_attrs_define
class PostPublicLogsListResponse200:
    """ 
        Attributes:
            logs (list[PostPublicLogsListResponse200LogsItem]):
            total_count (int): The total number of logs matching the filters.
     """

    logs: list[PostPublicLogsListResponse200LogsItem]
    total_count: int





    def to_dict(self) -> dict[str, Any]:
        from ..models.post_public_logs_list_response_200_logs_item import PostPublicLogsListResponse200LogsItem
        logs = []
        for logs_item_data in self.logs:
            logs_item = logs_item_data.to_dict()
            logs.append(logs_item)



        total_count = self.total_count


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "logs": logs,
            "totalCount": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.post_public_logs_list_response_200_logs_item import PostPublicLogsListResponse200LogsItem
        d = dict(src_dict)
        logs = []
        _logs = d.pop("logs")
        for logs_item_data in (_logs):
            logs_item = PostPublicLogsListResponse200LogsItem.from_dict(logs_item_data)



            logs.append(logs_item)


        total_count = d.pop("totalCount")

        post_public_logs_list_response_200 = cls(
            logs=logs,
            total_count=total_count,
        )

        return post_public_logs_list_response_200

