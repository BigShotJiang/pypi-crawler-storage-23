from enum import Enum

class PostPublicLogsListBodyCategory(str, Enum):
    ENVELOPE = "envelope"
    TEAM = "team"
    USER = "user"

    def __str__(self) -> str:
        return str(self.value)
