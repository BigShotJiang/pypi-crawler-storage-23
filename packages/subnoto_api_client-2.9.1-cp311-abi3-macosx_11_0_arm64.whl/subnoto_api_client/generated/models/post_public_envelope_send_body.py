from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.post_public_envelope_send_body_distribution_method import PostPublicEnvelopeSendBodyDistributionMethod
from ..types import UNSET, Unset






T = TypeVar("T", bound="PostPublicEnvelopeSendBody")



@_attrs_define
class PostPublicEnvelopeSendBody:
    """ 
        Attributes:
            workspace_uuid (str): The UUID of the workspace to send the envelope from.
            envelope_uuid (str): The UUID of the envelope to send.
            distribution_method (PostPublicEnvelopeSendBodyDistributionMethod | Unset): When "email" (default), invitation
                emails are sent; when "none", no emails are sent and link medium is set to "none". Default:
                PostPublicEnvelopeSendBodyDistributionMethod.EMAIL.
            use_user_as_sender_name (bool | Unset): Deprecated. Use the update envelope endpoint to set this; value is
                ignored when sending. Whether to use the user's name or by default the company name as the sender name.
            custom_invitation_message (str | Unset): Deprecated. Use the update envelope endpoint to set this; value is
                ignored when sending. Custom message to include in the invitation email.
     """

    workspace_uuid: str
    envelope_uuid: str
    distribution_method: PostPublicEnvelopeSendBodyDistributionMethod | Unset = PostPublicEnvelopeSendBodyDistributionMethod.EMAIL
    use_user_as_sender_name: bool | Unset = UNSET
    custom_invitation_message: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        workspace_uuid = self.workspace_uuid

        envelope_uuid = self.envelope_uuid

        distribution_method: str | Unset = UNSET
        if not isinstance(self.distribution_method, Unset):
            distribution_method = self.distribution_method.value


        use_user_as_sender_name = self.use_user_as_sender_name

        custom_invitation_message = self.custom_invitation_message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "workspaceUuid": workspace_uuid,
            "envelopeUuid": envelope_uuid,
        })
        if distribution_method is not UNSET:
            field_dict["distributionMethod"] = distribution_method
        if use_user_as_sender_name is not UNSET:
            field_dict["useUserAsSenderName"] = use_user_as_sender_name
        if custom_invitation_message is not UNSET:
            field_dict["customInvitationMessage"] = custom_invitation_message

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        workspace_uuid = d.pop("workspaceUuid")

        envelope_uuid = d.pop("envelopeUuid")

        _distribution_method = d.pop("distributionMethod", UNSET)
        distribution_method: PostPublicEnvelopeSendBodyDistributionMethod | Unset
        if isinstance(_distribution_method,  Unset):
            distribution_method = UNSET
        else:
            distribution_method = PostPublicEnvelopeSendBodyDistributionMethod(_distribution_method)




        use_user_as_sender_name = d.pop("useUserAsSenderName", UNSET)

        custom_invitation_message = d.pop("customInvitationMessage", UNSET)

        post_public_envelope_send_body = cls(
            workspace_uuid=workspace_uuid,
            envelope_uuid=envelope_uuid,
            distribution_method=distribution_method,
            use_user_as_sender_name=use_user_as_sender_name,
            custom_invitation_message=custom_invitation_message,
        )


        post_public_envelope_send_body.additional_properties = d
        return post_public_envelope_send_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
