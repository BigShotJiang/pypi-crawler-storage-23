from enum import Enum

class PostPublicLogsListBodySortBy(str, Enum):
    ID = "id"
    TIMESTAMP = "timestamp"

    def __str__(self) -> str:
        return str(self.value)
