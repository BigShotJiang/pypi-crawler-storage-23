from enum import Enum

class PostPublicLogsListResponse200LogsItemCategory(str, Enum):
    ENVELOPE = "envelope"
    TEAM = "team"
    USER = "user"

    def __str__(self) -> str:
        return str(self.value)
