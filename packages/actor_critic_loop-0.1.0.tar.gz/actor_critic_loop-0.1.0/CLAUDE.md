# CLAUDE.md

A **spike** (learning experiment) exploring the actor-critic pattern for AI output refinement. Not production software.

## Quick Reference

```bash
uv sync                    # Install dependencies
uv run pytest --cov        # Run tests — must pass before completing any work
uv run actor-critic run --workspace ./examples/hello-world/template
uv run actor-critic wizard ./my-task   # Scaffold + interactive Claude setup
```

> **Current state:** Phase 10 complete (multi-agent backend, agent teams). Actors and critics now accept a `backend` parameter — the CLI resolves backend names (`claude`, `codex`, `opencode`, `pi`) to modules and binds them via `functools.partial`. The `--backend` CLI flag overrides all roles. Backends are in `src/actor_critic/backends/`. A team actor (`actors/team.py`) sets `CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1` for parallel work. PyPI publish workflow added (`.github/workflows/publish.yml`). Phase 9 (TDD hooks, code review agent, orchestrator decomposition, oscillation prevention) remains active. See `plans/` for the full roadmap.

## Tech Stack

- Python 3.13+, `uv` package manager, pytest, Jinja2
- Multiple coding agent CLIs supported as backends: Claude Code, Codex, OpenCode, pi-coding-agent

## Where to Put Code

All source lives in `src/actor_critic/`. When adding new implementations:

| Adding a new... | Put it in | Must export |
|-----------------|-----------|-------------|
| Actor | `actors/<name>.py` | `run(prompt, cwd, ...) → ActorOutput` |
| Critic | `critics/<name>.py` | `run(prompt, cwd, ...) → CriticFeedback` |
| Orchestrator | `orchestrators/<name>.py` | `run(actor_fn, critic_fn, stop_condition_fn, workspace, cli_prompt, critic_names, max_rounds, on_progress, history_critics, oscillation_config)` |
| Stop condition | `stop_conditions/<name>.py` | `should_stop(round, feedbacks, config) → str | None` (returns stop reason or None; orchestrator uses `functools.partial` → `should_stop(round, feedbacks) → str | None`) |
| Template | `templates/{actors,critics}/<name>/` | `template.yaml` + Jinja2 files |

**Shared modules:**

| Module | Purpose |
|--------|---------|
| `backends/base.py` | `BackendResult`, `BackendEvent` dataclasses |
| `backends/resolve.py` | `resolve(name) → module` for backend lookup |
| `backends/claude.py` | Claude Code backend (wraps `claude/invoke.py`) |
| `backends/codex.py` | OpenAI Codex CLI backend |
| `backends/opencode.py` | OpenCode CLI backend |
| `backends/pi.py` | pi-coding-agent CLI backend |
| `claude/invoke.py` | Core `invoke()` function for Claude Code subprocess calls |
| `claude/types.py` | `ClaudeResult`, `ClaudeEvent` dataclasses |
| `types.py` | `ActorOutput`, `CriticFeedback` dataclasses |
| `config.py` | YAML config loading (`load_config`) and dataclasses |
| `resolver.py` | Dynamic module import (`resolve`) |
| `scaffold.py` | Workspace scaffolding (`scaffold_workspace`) |
| `orchestrators/oscillation.py` | Oscillation detection and reconciliation prompt builder |
| `orchestrators/feedback.py` | Critic feedback JSON serialization |
| `scaffold_templates/` | Built-in template files for `init` command |

Create directories as needed — not all exist yet. See `plans/CONVENTIONS.md` for full signatures.

## Documentation Map

| Document | Purpose |
|----------|---------|
| `README.md` | User-facing overview, CLI usage, workspace structure |
| `plans/CONVENTIONS.md` | Implementation patterns, function signatures, test conventions |
| `plans/PLUGINS-SKILLS-RULES.md` | Claude Code plugins, skills, and rules configuration |
| `plans/PHASE*.md` | Detailed specs for each implementation phase |
| `docs/FUTURE.md` | Out-of-scope ideas for later exploration |
| `examples/` | Ready-to-run workspace examples |

## Plugins Quick Reference

Install official Anthropic plugins to actor/critic workspaces:

```bash
# Install to project scope (recommended)
cd my-workspace/actor
claude plugin install pyright-lsp --scope project
claude plugin install code-simplifier --scope project

# List available plugins
claude plugin list --json --available
```

**Recommended plugins by role:**

| Role | Plugins |
|------|---------|
| Python actors | `pyright-lsp`, `code-simplifier` |
| Code critics | `code-review`, `security-guidance` |
| Style critics | `pr-review-toolkit` |

See `plans/PLUGINS-SKILLS-RULES.md` for complete guidance on plugins, skills, and rules.

## Working Conventions

From `plans/CONVENTIONS.md` — these are mandatory:

- **Entry points:** Every actor, critic, orchestrator, and stop-condition module exposes a single `run()` function with a defined signature (see CONVENTIONS.md for details)
- **Subprocess pattern:** Use `subprocess.run` (blocking), not `Popen` — exception: `claude/invoke.py` uses `Popen` for streaming diagnostics in verbose mode
- **Backend injection:** Actors and critics receive a `backend` module via `functools.partial` binding in the CLI. They call `backend.invoke()` — never import a specific backend directly
- **Path handling:** `--add-dir` arguments must be absolute paths (resolved at runtime)
- **Testing:** Tests ship with the code they cover; `uv run pytest --cov` must pass at the end of every task
- **Test stubs:** System tests use stub `claude` scripts on PATH (generated inline in tests)
- **Critic prompt templates:** Critic `input/prompt.md` files are Jinja2 templates rendered at runtime with context variables (`actor_output_files`, `actor_prompt_file`, `actor_prompt`). Every critic must provide its own template — there is no default fallback
- **Phase completion:** When implementing a phase, update ALL of these before considering the work complete:
  1. The phase plan (`plans/PHASE*.md`) — mark completed, note any deviations
  2. `CLAUDE.md` — update "Current state" and any affected sections
  3. `README.md` — update CLI usage, examples, and feature descriptions
  4. `examples/` — ensure all examples work with the new functionality
  5. Tests — add/update unit, integration, and system tests as specified in the phase plan

## Key Design Decisions

- **Subprocess over SDK** — decoupled from API changes; each role gets full Claude Code environment
- **Filesystem artifact detection** — scan before/after invocation; don't trust self-reported file lists
- **Fully qualified module paths** — no short aliases; config values must be self-explanatory
- **Phased implementation** — each phase produces a runnable tool; later phases widen scope
- **No future-proofing** — don't add parameters, code, or abstractions for features planned in later phases; add them when the phase is implemented

## Common Gotchas

- **`init` creates workspaces** — `actor-critic init <path>` scaffolds a workspace; use `--template` to clone an existing example
- **Oscillation config** — `max_consecutive_fails` (default 3) and `oscillation_reversals` (default 2) are set in `stop_condition.config` in `actor-critic.yaml`; the orchestrator extracts them automatically
- **Extended thinking default** — on by default; control via `MAX_THINKING_TOKENS` env var
- **Path resolution** — `--add-dir` paths are relative in examples but resolved to absolute at runtime
