// OpenCode stop hook — combined quality gate + auto-commit
// Port of .claude/hooks/quality-gate.sh and auto-commit.sh
//
// On session.idle (agent finished responding):
//   1. Run quality gate (tests, coverage, lint, format, types, security, dead code)
//   2. If gate fails → prompt the agent to fix, skip commit
//   3. If gate passes + uncommitted changes → stage, commit, push

import type { Plugin } from "@opencode-ai/plugin"

interface CheckResult {
  name: string
  passed: boolean
  output: string
}

export default (async ({ client, project, $ }) => {
  let running = false

  async function runCheck(
    name: string,
    command: string,
    opts?: { skipEnvVar?: string; failOnOutput?: boolean },
  ): Promise<CheckResult> {
    if (opts?.skipEnvVar && process.env[opts.skipEnvVar] === "1") {
      return { name, passed: true, output: `Skipped (${opts.skipEnvVar}=1)` }
    }
    try {
      // command uses $WORK_DIR instead of interpolated cwd to avoid
      // shell injection if the worktree path contains metacharacters.
      const result = await $`bash -c ${command}`.env({ ...process.env, WORK_DIR: project.worktree }).text()
      // Some tools (e.g. vulture) exit 0 but print findings to stdout
      if (opts?.failOnOutput && result.trim().length > 0) {
        return { name, passed: false, output: result }
      }
      return { name, passed: true, output: result }
    } catch (err: any) {
      return {
        name,
        passed: false,
        output: err?.stdout || err?.stderr || err?.message || String(err),
      }
    }
  }

  async function qualityGate(): Promise<boolean> {
    const rawThreshold = process.env.COVERAGE_THRESHOLD || "80"
    const parsedThreshold = Number.parseInt(rawThreshold, 10)
    const threshold = Number.isNaN(parsedThreshold) ? "80" : String(parsedThreshold)

    await client.tui.showToast({
      body: {
        title: "Quality Gate",
        message: "Running checks...",
        variant: "info",
        duration: 60_000,
      },
    })

    const checks: CheckResult[] = [
      await runCheck(`Tests + Coverage (>=${threshold}%)`, `cd "$WORK_DIR" && uv run pytest -x --tb=short --cov=src/actor_critic --cov-report=term --cov-fail-under=${threshold} 2>&1`),
      await runCheck("Lint (ruff check)", `cd "$WORK_DIR" && uv run ruff check src/ tests/ 2>&1`),
      await runCheck("Format (ruff format)", `cd "$WORK_DIR" && uv run ruff format --check src/ tests/ 2>&1`),
      await runCheck("Types (pyright)", `cd "$WORK_DIR" && uv run pyright src/ 2>&1`, { skipEnvVar: "SKIP_TYPE_CHECK" }),
      await runCheck("Security (bandit)", `cd "$WORK_DIR" && uv run bandit -r src/ -q -ll 2>&1`, { skipEnvVar: "SKIP_SECURITY_SCAN" }),
      await runCheck("Dead code (vulture)", `cd "$WORK_DIR" && uv run vulture src/ --min-confidence 80 2>&1`, { skipEnvVar: "SKIP_DEAD_CODE", failOnOutput: true }),
    ]

    const failures = checks.filter((c) => !c.passed)

    if (failures.length === 0) {
      await client.tui.showToast({
        body: {
          title: "Quality Gate",
          message: `All ${checks.length} checks passed`,
          variant: "success",
          duration: 5_000,
        },
      })
      return true
    }

    const divider = "────────────────────────────────────────"
    const report = [
      "QUALITY GATE FAILED — FIX THESE ISSUES:",
      ...failures.map((f) => `${divider}\n${f.name}:\n${f.output.slice(0, 2000)}`),
      divider,
      "Fix all issues above, then the quality gate will run again.",
    ].join("\n")

    await client.tui.showToast({
      body: {
        title: "Quality Gate FAILED",
        message: `${failures.length} of ${checks.length} checks failed`,
        variant: "error",
        duration: 15_000,
      },
    })

    await client.session.prompt({ body: { message: report } })
    return false
  }

  async function autoCommit(cwd: string): Promise<void> {
    const status = (await $`git -C ${cwd} status --porcelain 2>/dev/null`.text()).trim()
    if (!status) return

    await client.tui.showToast({
      body: {
        title: "Auto-commit",
        message: "Committing...",
        variant: "info",
        duration: 15_000,
      },
    })

    await $`git -C ${cwd} add -A`

    const changedFiles = (await $`git -C ${cwd} diff --cached --name-only`.text())
      .trim()
      .split("\n")
      .slice(0, 10)

    const firstFile = changedFiles[0]?.trim() || "files"
    const commitMsg =
      changedFiles.length > 1
        ? `Update ${firstFile} and ${changedFiles.length - 1} other files`
        : `Update ${firstFile}`

    // Commit
    try {
      await $`git -C ${cwd} commit -m ${commitMsg + "\n\nCo-Authored-By: OpenCode <noreply@opencode.ai>"}`
      await client.tui.showToast({
        body: { title: "Auto-commit", message: `Committed: ${commitMsg}`, variant: "success", duration: 5_000 },
      })
    } catch (err: any) {
      const output = err?.stdout || err?.stderr || err?.message || String(err)
      await client.tui.showToast({
        body: { title: "Auto-commit FAILED", message: "Pre-commit hook failed", variant: "error", duration: 10_000 },
      })
      await client.session.prompt({
        body: { message: `[auto-commit] Pre-commit hook failed:\n${output.slice(0, 2000)}\n\nPlease fix the issues above.` },
      })
      return
    }

    // Push — mandatory in devcontainer; the working copy lives on a Docker
    // volume so pushing to origin is the only durable backup against
    // container or host failure.
    try {
      await $`git -C ${cwd} push origin HEAD`
      await client.tui.showToast({
        body: { title: "Auto-commit", message: "Push successful", variant: "success", duration: 3_000 },
      })
    } catch (err: any) {
      const output = err?.stdout || err?.stderr || err?.message || String(err)
      await client.tui.showToast({
        body: { title: "Auto-commit", message: `Push failed: ${output.slice(0, 100)}`, variant: "warning", duration: 8_000 },
      })
    }
  }

  return {
    event: async ({ event }) => {
      if (event.type !== "session.idle") return
      if (running) return
      running = true

      try {
        const passed = await qualityGate()
        if (passed) {
          await autoCommit(project.worktree)
        }
      } finally {
        running = false
      }
    },
  }
}) satisfies Plugin
