// OpenCode statusline plugin — toast-based status display after each agent response
// Mirrors a subset of the Claude Code statusline.sh functionality:
//   - Model name
//   - Git branch and worktree
//   - Response count per session
//   - Hooks summary (read from .claude/settings.json)

import type { Plugin } from "@opencode-ai/plugin"

export default (async ({ client, project, $ }) => {
  const stats = new Map<string, { responses: number; started: Date }>()

  // Cache slow lookups (refreshed every 30s)
  let cachedBranch = ""
  let cachedWorktree = ""
  let cachedHooks = ""
  let cacheTime = 0
  const CACHE_TTL = 30_000

  async function refreshCache() {
    const now = Date.now()
    if (now - cacheTime < CACHE_TTL) return

    let allSucceeded = true

    try {
      const branchResult = await $`git -C ${project.worktree} branch --show-current 2>/dev/null`.text()
      cachedBranch = branchResult.trim()
    } catch {
      cachedBranch = ""
      allSucceeded = false
    }

    // Detect worktree: git-dir differs from git-common-dir
    try {
      const gitDir = (await $`git -C ${project.worktree} rev-parse --git-dir 2>/dev/null`.text()).trim()
      const gitCommon = (await $`git -C ${project.worktree} rev-parse --git-common-dir 2>/dev/null`.text()).trim()
      if (gitDir && gitCommon && gitDir !== gitCommon) {
        const toplevel = (await $`git -C ${project.worktree} rev-parse --show-toplevel 2>/dev/null`.text()).trim()
        cachedWorktree = toplevel.split("/").pop() || ""
      } else {
        cachedWorktree = ""
      }
    } catch {
      cachedWorktree = ""
      allSucceeded = false
    }

    // Read hooks from settings files
    try {
      const hooksMap = new Map<string, Set<string>>()
      const settingsFiles = [
        `${project.worktree}/.claude/settings.json`,
        `${project.worktree}/.claude/settings.local.json`,
      ]
      for (const file of settingsFiles) {
        try {
          const content = await $`cat ${file} 2>/dev/null`.text()
          const settings = JSON.parse(content)
          if (settings.hooks) {
            for (const [event, matchers] of Object.entries(settings.hooks)) {
              if (!Array.isArray(matchers)) continue
              for (const matcher of matchers) {
                if (!matcher.hooks || !Array.isArray(matcher.hooks)) continue
                for (const hook of matcher.hooks) {
                  if (!hook.command) continue
                  const name = hook.command
                    .split("/")
                    .pop()
                    ?.replace(/\.(sh|py|js|ts)$/, "") || hook.command
                  if (!hooksMap.has(event)) hooksMap.set(event, new Set())
                  hooksMap.get(event)!.add(name)
                }
              }
            }
          }
        } catch {
          // file doesn't exist or invalid JSON — skip
        }
      }

      if (hooksMap.size > 0) {
        const parts: string[] = []
        for (const [event, names] of hooksMap) {
          parts.push(`${event}[${[...names].join(", ")}]`)
        }
        cachedHooks = parts.join(" ")
      } else {
        cachedHooks = ""
      }
    } catch {
      cachedHooks = ""
      allSucceeded = false
    }

    // Only update cache timestamp on full success so transient failures
    // retry on the next call instead of caching empty values for the full TTL.
    if (allSucceeded) {
      cacheTime = Date.now()
    }
  }

  async function getModelName(): Promise<string> {
    try {
      const config = await client.config.get()
      // Extract model name from config — format varies
      const model = (config as any)?.model || ""
      // Strip provider prefix: "anthropic/claude-opus" -> "claude-opus"
      const shortModel = model.includes("/") ? model.split("/").pop() || "" : model
      return shortModel || "?"
    } catch {
      return "?"
    }
  }

  return {
    event: async ({ event }) => {
      if (event.type === "session.created") {
        stats.set(event.properties?.sessionId || "default", {
          responses: 0,
          started: new Date(),
        })
      }

      if (event.type === "session.idle") {
        const sessionId = event.properties?.sessionId || "default"
        const session = stats.get(sessionId) || { responses: 0, started: new Date() }
        session.responses += 1
        stats.set(sessionId, session)

        await refreshCache()
        const model = await getModelName()

        // Build status lines
        const parts: string[] = []

        // Line 1: Model (branch) [worktree]
        let line1 = model
        if (cachedBranch) line1 += ` (${cachedBranch})`
        if (cachedWorktree) line1 += ` [${cachedWorktree}]`
        parts.push(line1)

        // Line 2: Stats
        const elapsed = Math.round((Date.now() - session.started.getTime()) / 60_000)
        let line2 = `#${session.responses}`
        if (elapsed > 0) line2 += ` | ${elapsed}m elapsed`
        parts.push(line2)

        // Line 3: Hooks (if any)
        if (cachedHooks) {
          parts.push(`hooks: ${cachedHooks}`)
        }

        await client.tui.showToast({
          body: {
            title: parts[0],
            message: parts.slice(1).join("\n"),
            variant: "info",
            duration: 10_000,
          },
        })
      }

      if (event.type === "session.deleted") {
        stats.delete(event.properties?.sessionId || "default")
      }
    },
  }
}) satisfies Plugin
