#Requires -Version 7.0
<#
.SYNOPSIS
    Build and start the devcontainer on Windows (no WSL2 required).
    PowerShell port of build.sh.
.DESCRIPTION
    Gathers host configuration (Git user, GitHub token, GPG settings),
    writes it to a temp env file, then builds and starts the devcontainer.
#>

$ErrorActionPreference = 'Stop'

# Navigate to repo root if in .devcontainer dir
if (Test-Path './devcontainer.json') { Set-Location .. }

# Check GitHub CLI authentication
Write-Host "`u{1F510} Checking GitHub CLI authentication..."
$ghStatus = gh auth status 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host "`u{274C} GitHub CLI is not authenticated."
    Write-Host "   Please run 'gh auth login' first, then retry."
    exit 1
}
Write-Host "`u{2705} GitHub CLI authenticated"

# Gather configuration from host
$ghToken = gh auth token
$gitUserName = git config --global user.name 2>$null
if (-not $gitUserName) { $gitUserName = '' }
$gitUserEmail = git config --global user.email 2>$null
if (-not $gitUserEmail) { $gitUserEmail = '' }
$gitSigningKey = git config --global user.signingkey 2>$null
if (-not $gitSigningKey) { $gitSigningKey = '' }
$gitGpgSign = git config --global commit.gpgsign 2>$null
if (-not $gitGpgSign) { $gitGpgSign = '' }
# Get GitHub repository in owner/name format for cloning in container
$githubRepo = gh repo view --json nameWithOwner -q .nameWithOwner 2>$null
if (-not $githubRepo) { $githubRepo = '' }

Write-Host "Environment for postCreate:"
Write-Host "  githubRepo: $githubRepo"
Write-Host "  gitUserName: $gitUserName"
Write-Host "  gitUserEmail: $gitUserEmail"
if ($gitSigningKey) {
    Write-Host "  gitSigningKey: $gitSigningKey"
    Write-Host "  gitGpgSign: $gitGpgSign"
} else {
    Write-Host "  gitSigningKey: (not configured)"
}
Write-Host "  GH_TOKEN: (set)"
Write-Host ""

# Write config to temp file (read by postCreate.sh inside the container)
$configDir = Join-Path '.devcontainer' 'config'
if (-not (Test-Path $configDir)) { New-Item -ItemType Directory -Path $configDir -Force | Out-Null }
$configFile = Join-Path $configDir 'postCreate.env.tmp'

@"
GH_TOKEN="$ghToken"
GITHUB_REPOSITORY="$githubRepo"
GIT_USER_NAME="$gitUserName"
GIT_USER_EMAIL="$gitUserEmail"
GIT_SIGNING_KEY="$gitSigningKey"
GIT_GPG_SIGN="$gitGpgSign"
"@ | Set-Content -Path $configFile -Encoding UTF8

# Build with cache management
Write-Host "Building DevContainer..."
devcontainer build --workspace-folder .
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed, retrying without cache..."
    devcontainer build --workspace-folder . --no-cache
    if ($LASTEXITCODE -ne 0) {
        Write-Host "`u{274C} Build failed even without cache."
        exit 1
    }
}

# Start container
devcontainer up --workspace-folder . --remove-existing-container
if ($LASTEXITCODE -ne 0) {
    Write-Host "`u{274C} Failed to start devcontainer."
    exit 1
}
