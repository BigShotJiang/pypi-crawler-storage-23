#Requires -Version 7.0
<#
.SYNOPSIS
    Start an existing devcontainer (use build.ps1 for fresh builds).
    PowerShell port of up.sh.
#>

$ErrorActionPreference = 'Stop'

if (Test-Path 'devcontainer.json') { Set-Location .. }
devcontainer up --workspace-folder . @args
