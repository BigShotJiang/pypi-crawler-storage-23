#Requires -Version 7.0
<#
.SYNOPSIS
    DevContainer Cleanup Script for Windows.
    PowerShell port of clean.sh.
.DESCRIPTION
    Removes all stale devcontainers, images, and volumes for the current repository.
    Supports -DryRun mode to preview operations without executing them.
#>

param(
    [switch]$DryRun,
    [switch]$Help
)

$ErrorActionPreference = 'Stop'

if ($Help) {
    Write-Host "Usage: .\clean.ps1 [OPTIONS]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -DryRun    Show what would be done without executing destructive operations"
    Write-Host "  -Help      Show this help message"
    Write-Host ""
    Write-Host "Cleans up all DevContainer resources (containers, images, volumes) for the current repository."
    exit 0
}

# Verify git is available
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "`u{274C} Error: git is not installed or not in PATH"
    exit 1
}

# Get the repository root directory
$repoRoot = git rev-parse --show-toplevel 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "`u{274C} Error: Not in a git repository"
    exit 1
}

$repoName = Split-Path $repoRoot -Leaf

# Try to get the full repository name using gh CLI
if (Get-Command gh -ErrorAction SilentlyContinue) {
    $ghRepo = gh repo view --json nameWithOwner -q .nameWithOwner 2>$null
    if ($ghRepo) {
        $repoName = ($ghRepo -split '/')[-1]
        Write-Host "`u{1F4E6} Detected GitHub repository: $ghRepo"
    }
} else {
    Write-Host "`u{26A0}`u{FE0F}  Warning: gh CLI not available, using local repository name: $repoName"
}

$volumeName = $repoName

if ($DryRun) {
    Write-Host "`u{1F9F9} DevContainer Cleanup Script for $repoName [DRY-RUN MODE]"
    Write-Host ("=" * 60)
    Write-Host "`u{26A0}`u{FE0F}  DRY-RUN: No destructive operations will be performed"
} else {
    Write-Host "`u{1F9F9} DevContainer Cleanup Script for $repoName"
    Write-Host ("=" * 50)
}

Write-Host "`u{1F50D} Finding containers and volumes..."

# Function to stop and remove containers using a volume
function Remove-VolumeContainers {
    param([string]$VolumeName)
    Write-Host "`u{1F50D} Finding containers using volume: $VolumeName"

    $containerIds = docker ps -a --format "{{.ID}}" 2>$null
    $usingVolume = @()
    foreach ($id in $containerIds) {
        if (-not $id) { continue }
        $mounts = docker inspect $id --format '{{range .Mounts}}{{if eq .Type "volume"}}{{.Name}} {{end}}{{end}}' 2>$null
        if ($mounts) {
            $mountNames = $mounts -split '\s+' | Where-Object { $_ }
            if ($mountNames -contains $VolumeName) {
                $usingVolume += $id
            }
        }
    }

    if ($usingVolume.Count -gt 0) {
        if ($DryRun) {
            Write-Host "  [DRY-RUN] Would stop containers using volume ${VolumeName}:"
            $usingVolume | ForEach-Object { Write-Host "    - Container ID: $_" }
            Write-Host "  [DRY-RUN] Would remove containers using volume $VolumeName"
        } else {
            Write-Host "`u{1F6D1} Stopping containers using volume ${VolumeName}..."
            $usingVolume | ForEach-Object { docker stop $_ 2>$null }
            Write-Host "`u{1F5D1}`u{FE0F}  Removing containers using volume ${VolumeName}..."
            $usingVolume | ForEach-Object { docker rm -f $_ 2>$null }
        }
    } else {
        Write-Host "`u{2705} No containers found using volume $VolumeName"
    }
}

# Step 1: Stop and remove all containers related to this repo
Write-Host ""
Write-Host "`u{1F4E6} Step 1: Cleaning up containers..."
$allContainers = docker ps -a --filter "label=devcontainer.local_folder" --format "{{.ID}} {{.Label `"devcontainer.local_folder`"}}" 2>$null
$containers = @()
foreach ($line in $allContainers) {
    if ($line -match [regex]::Escape($repoName)) {
        $containers += ($line -split ' ')[0]
    }
}

if ($containers.Count -gt 0) {
    if ($DryRun) {
        Write-Host "  [DRY-RUN] Would stop and remove devcontainers for ${repoName}:"
        $containers | ForEach-Object { Write-Host "    - Container ID: $_" }
    } else {
        Write-Host "`u{1F6D1} Stopping devcontainers for ${repoName}..."
        $containers | ForEach-Object { docker stop $_ 2>$null }
        Write-Host "`u{1F5D1}`u{FE0F}  Removing devcontainers for ${repoName}..."
        $containers | ForEach-Object { docker rm -f $_ 2>$null }
        Write-Host "`u{2705} Devcontainers cleaned up"
    }
} else {
    Write-Host "`u{2705} No devcontainers found for $repoName"
}

# Step 2: Remove containers using our volume
Remove-VolumeContainers -VolumeName $volumeName

# Step 3: Remove images
Write-Host ""
Write-Host "`u{1F5BC}`u{FE0F}  Step 2: Cleaning up images..."
$allImages = docker images --format "{{.Repository}}:{{.Tag}} {{.ID}}" 2>$null
$images = @()
foreach ($line in $allImages) {
    if ($line -match ("vsc-" + [regex]::Escape($repoName) + "-")) {
        $images += ($line -split ' ')[-1]
    }
}
$images = $images | Sort-Object -Unique

if ($images.Count -gt 0) {
    if ($DryRun) {
        Write-Host "  [DRY-RUN] Would remove devcontainer images for ${repoName}:"
        $images | ForEach-Object { Write-Host "    - Image ID: $_" }
    } else {
        Write-Host "`u{1F5D1}`u{FE0F}  Removing devcontainer images for ${repoName}..."
        $images | ForEach-Object { docker rmi -f $_ 2>$null }
        Write-Host "`u{2705} Images cleaned up"
    }
} else {
    Write-Host "`u{2705} No devcontainer images found for $repoName"
}

# Step 4: Remove the volume
Write-Host ""
Write-Host "`u{1F4BE} Step 3: Cleaning up volumes..."
$volumes = docker volume ls --format "{{.Name}}" 2>$null
if ($volumes -contains $volumeName) {
    if ($DryRun) {
        Write-Host "  [DRY-RUN] Would remove volume: $volumeName"
    } else {
        Write-Host "`u{1F5D1}`u{FE0F}  Removing volume: ${volumeName}..."
        docker volume rm $volumeName 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "`u{2705} Volume $volumeName removed successfully"
        } else {
            Write-Host "`u{274C} Failed to remove volume $volumeName"
            Write-Host "   Try inspecting containers manually and retry"
            exit 1
        }
    }
} else {
    Write-Host "`u{2705} Volume $volumeName not found (already cleaned)"
}

# Step 5: Clean up dangling resources
Write-Host ""
Write-Host "`u{1F9FD} Step 4: Cleaning up dangling resources..."
if ($DryRun) {
    Write-Host "  [DRY-RUN] Would remove dangling volumes with: docker volume prune -f"
    Write-Host "  [DRY-RUN] Would remove dangling images with: docker image prune -f"
} else {
    Write-Host "`u{1F5D1}`u{FE0F}  Removing dangling volumes..."
    docker volume prune -f 2>$null | Out-Null
    Write-Host "`u{1F5D1}`u{FE0F}  Removing dangling images..."
    docker image prune -f 2>$null | Out-Null
}

Write-Host ""
if ($DryRun) {
    Write-Host "`u{1F50D} Dry-run completed!"
    Write-Host "   No changes were made. Re-run without -DryRun to execute the cleanup."
} else {
    Write-Host "`u{1F389} Cleanup completed successfully!"
    Write-Host "   All containers, images, and volumes for $repoName have been removed"
    Write-Host "   Next devcontainer build will start fresh"
}
