#Requires -Version 7.0
<#
.SYNOPSIS
    Set up the actor-critic project for native Windows development (no WSL2).
    Creates .claude/settings.local.json with PowerShell hook references.
.DESCRIPTION
    This script is the Windows equivalent of the devcontainer postCreate.sh
    for users running Claude Code natively on Windows. It:
      1. Installs Python dependencies via uv
      2. Configures Claude Code hooks to use .ps1 scripts
      3. Creates .claude/settings.local.json (gitignored)

    Prerequisites:
      - Python 3.13+ installed
      - uv installed (pip install uv)
      - Git installed
      - GitHub CLI (gh) installed and authenticated
      - Claude Code CLI installed
#>

param(
    [switch]$SkipDeps,
    [switch]$Help
)

$ErrorActionPreference = 'Stop'

if ($Help) {
    Write-Host "Usage: .\install-windows.ps1 [OPTIONS]"
    Write-Host ""
    Write-Host "Options:"
    Write-Host "  -SkipDeps  Skip dependency installation (uv sync)"
    Write-Host "  -Help      Show this help message"
    Write-Host ""
    Write-Host "Sets up the actor-critic project for native Windows development."
    Write-Host "Run from the repository root or .devcontainer directory."
    exit 0
}

# Navigate to repo root if in .devcontainer dir
if (Test-Path './devcontainer.json') { Set-Location .. }

$repoRoot = git rev-parse --show-toplevel 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "`u{274C} Error: Not in a git repository"
    exit 1
}
Set-Location $repoRoot

Write-Host "`u{1F4E6} Setting up actor-critic for Windows..."
Write-Host ""

# Check prerequisites
$missing = @()
if (-not (Get-Command python -ErrorAction SilentlyContinue)) { $missing += 'python' }
if (-not (Get-Command uv -ErrorAction SilentlyContinue)) { $missing += 'uv' }
if (-not (Get-Command git -ErrorAction SilentlyContinue)) { $missing += 'git' }
if (-not (Get-Command gh -ErrorAction SilentlyContinue)) { $missing += 'gh' }

if ($missing.Count -gt 0) {
    Write-Host "`u{274C} Missing prerequisites: $($missing -join ', ')"
    Write-Host "   Please install them before running this script."
    exit 1
}
Write-Host "`u{2705} Prerequisites found"

# Check Python version
$pyVersion = python --version 2>&1
Write-Host "   Python: $pyVersion"
Write-Host "   uv: $(uv --version)"
Write-Host "   Git: $(git --version)"
Write-Host "   gh: $(gh --version | Select-Object -First 1)"

# Install dependencies
if (-not $SkipDeps) {
    Write-Host ""
    Write-Host "`u{1F4E6} Installing dependencies..."
    uv sync
    if ($LASTEXITCODE -ne 0) {
        Write-Host "`u{274C} Failed to install dependencies"
        exit 1
    }
    Write-Host "`u{2705} Dependencies installed"

    # Install pre-commit hooks if available
    uv run pre-commit install 2>$null
    if ($LASTEXITCODE -eq 0) {
        Write-Host "`u{2705} Pre-commit hooks installed"
    }
}

# Configure Claude Code local settings with PowerShell hooks
Write-Host ""
Write-Host "`u{1F527} Configuring Claude Code for Windows..."

$claudeDir = Join-Path $repoRoot '.claude'
$localSettings = Join-Path $claudeDir 'settings.local.json'

# Build settings.local.json with PowerShell hook references
# Uses $CLAUDE_PROJECT_DIR which Claude Code resolves at runtime
$settings = @{
    permissions = @{
        defaultMode = 'bypassPermissions'
    }
    model = 'opus'
    alwaysThinkingEnabled = $true
    env = @{
        CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS = '1'
    }
    statusLine = @{
        type = 'command'
        command = 'pwsh -NoProfile -File "$CLAUDE_PROJECT_DIR/.claude/statusline.ps1"'
    }
    hooks = @{
        SessionStart = @(
            @{
                matcher = ''
                hooks = @(
                    @{
                        type = 'command'
                        command = 'pwsh -NoProfile -File "$CLAUDE_PROJECT_DIR/.claude/hooks/session-start.ps1"'
                        timeout = 120
                    }
                )
            }
        )
        PostToolUse = @(
            @{
                matcher = 'Edit|Write'
                hooks = @(
                    @{
                        type = 'command'
                        command = 'pwsh -NoProfile -File "$CLAUDE_PROJECT_DIR/.claude/hooks/per-edit-fix.ps1"'
                        timeout = 60
                    }
                )
            }
        )
        Stop = @(
            @{
                matcher = ''
                hooks = @(
                    @{
                        type = 'command'
                        command = 'pwsh -NoProfile -File "$CLAUDE_PROJECT_DIR/.claude/hooks/quality-gate.ps1"'
                        timeout = 600
                    }
                    @{
                        type = 'command'
                        command = 'pwsh -NoProfile -File "$CLAUDE_PROJECT_DIR/.claude/hooks/auto-commit.ps1"'
                        timeout = 240
                    }
                )
            }
        )
    }
}

$settings | ConvertTo-Json -Depth 32 | Set-Content $localSettings -Encoding UTF8
Write-Host "`u{2705} Claude Code local settings created at: $localSettings"

# Create AGENTS.md copy for opencode (if CLAUDE.md exists)
$claudeMd = Join-Path $repoRoot 'CLAUDE.md'
$agentsMd = Join-Path $repoRoot 'AGENTS.md'
if ((Test-Path $claudeMd) -and -not (Test-Path $agentsMd)) {
    Copy-Item $claudeMd $agentsMd
    Write-Host "`u{2705} AGENTS.md copied from CLAUDE.md"
}

Write-Host ""
Write-Host "`u{1F389} Windows setup completed!"
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. Run 'claude' to start Claude Code"
Write-Host "  2. Run 'uv run pytest --cov' to verify tests pass"
Write-Host "  3. Run 'uv run actor-critic run --workspace ./examples/hello-world/template' to try it"
Write-Host ""
Write-Host "Note: The hooks in .claude/settings.local.json reference PowerShell (.ps1) scripts."
Write-Host "      The repo's .claude/settings.json references bash (.sh) scripts for Linux/macOS."
Write-Host "      settings.local.json takes precedence and is gitignored."
