#!/usr/bin/env bash
# Run the code-review example with actor-critic refinement loop
set -euo pipefail

VERBOSE=""
for arg in "$@"; do
    case "$arg" in
        --verbose|-v) VERBOSE="--verbose" ;;
    esac
done

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../.." && pwd)"
TEMPLATE_DIR="$SCRIPT_DIR/template"
WORKSPACE="$SCRIPT_DIR/workspace"
SAMPLES_DIR="$SCRIPT_DIR/samples"

# Clean previous workspace (full re-scaffold each run)
rm -rf "$WORKSPACE"

# Scaffold from template
cd "$REPO_ROOT"
uv run actor-critic init "$WORKSPACE" --template "$TEMPLATE_DIR"

# Run actor-critic loop
uv run actor-critic run \
    --workspace "$WORKSPACE" \
    $VERBOSE

# Archive entire workspace as a timestamped sample
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
SAMPLE_DIR="$SAMPLES_DIR/$TIMESTAMP"
mkdir -p "$SAMPLE_DIR"
cp -r "$WORKSPACE"/* "$SAMPLE_DIR"/
echo "Archived workspace to: $SAMPLE_DIR"

# Clean up ephemeral workspace
rm -rf "$WORKSPACE"
