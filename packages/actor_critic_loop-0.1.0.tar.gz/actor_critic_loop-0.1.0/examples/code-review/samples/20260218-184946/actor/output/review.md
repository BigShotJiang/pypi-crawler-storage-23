# Code Review: sample.py

**Reviewed:** 2026-02-18
**File:** `sample.py`
**Reviewer:** Code Review Actor

---

## Summary

Three functions were reviewed: `calculate_average`, `find_user`, and `process_data`. The code is functional but contains a critical crash bug, a built-in name shadowing issue, and several opportunities to use idiomatic Python.

---

## Issues by Severity

### CRITICAL

#### 1. `calculate_average` — ZeroDivisionError on empty input

**Location:** `calculate_average`, line 5
**Severity:** Critical — crashes at runtime with no error message

```python
# Current (crashes on empty list)
def calculate_average(numbers):
    total = 0
    for n in numbers:
        total += n
    return total / len(numbers)  # ZeroDivisionError if numbers == []
```

Calling `calculate_average([])` raises `ZeroDivisionError: division by zero` and terminates the program. This is one of the most common real-world Python bugs, particularly in data pipelines.

**Recommended fix:**

```python
def calculate_average(numbers: list[float]) -> float:
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)
```

Alternatively, return `0.0` or `None` if the caller expects a sentinel. Raise `ValueError` when the contract requires at least one element — it signals a programmer error rather than a runtime condition.

**References:**
- [Python Built-in Exceptions — ZeroDivisionError](https://docs.python.org/3/library/exceptions.html)
- [Real Python — ZeroDivisionError](https://realpython.com/ref/builtin-exceptions/zerodivisionerror/)

---

### HIGH

#### 2. `find_user` — implicit `None` return is invisible to callers

**Location:** `find_user`, lines 8–11
**Severity:** High — silent failure; callers may dereference `None` without realizing it

```python
# Current — returns None implicitly when not found
def find_user(users, id):
    for user in users:
        if user["id"] == id:
            return user
```

When no user matches, the function falls off the end and returns `None`. Callers that assume a user is always found will get an `AttributeError` or `TypeError` on the returned value. The issue is invisible at the call site.

**Recommended fix — raise on miss:**

```python
def find_user(users: list[dict], user_id: int) -> dict:
    for user in users:
        if user["id"] == user_id:
            return user
    raise KeyError(f"User {user_id!r} not found")
```

**Or — return `None` explicitly with a typed signature:**

```python
def find_user(users: list[dict], user_id: int) -> dict | None:
    for user in users:
        if user["id"] == user_id:
            return user
    return None
```

The explicit `return None` and `| None` in the return type forces callers to handle the miss case.

**References:**
- [PEP 484 — Type Hints](https://peps.python.org/pep-0484/)
- [Typing best practices — python.org](https://typing.python.org/en/latest/reference/best_practices.html)

#### 3. `find_user` — parameter `id` shadows the built-in `id()`

**Location:** `find_user`, line 8
**Severity:** High — violates Python style rules; triggers Pylint W0622 / Ruff A002

```python
def find_user(users, id):   # "id" shadows the built-in id()
```

`id` is a Python built-in function that returns the memory address of an object. Shadowing it with a parameter name is flagged by every major linter ([Pylint W0622](https://pylint.pycqa.org/en/latest/user_guide/messages/warning/redefined-builtin.html), [Ruff A002 — builtin-argument-shadowing](https://docs.astral.sh/ruff/rules/builtin-argument-shadowing/)).

**Fix:** rename to `user_id` (or `id_` as a minimal change):

```python
def find_user(users: list[dict], user_id: int) -> dict | None:
```

**References:**
- [Ruff A002 — builtin-argument-shadowing](https://docs.astral.sh/ruff/rules/builtin-argument-shadowing/)
- [Pylint W0622 — redefined-builtin](https://pylint.pycqa.org/en/latest/user_guide/messages/warning/redefined-builtin.html)

---

### MEDIUM

#### 4. All functions — no type annotations

**Location:** `calculate_average` line 1, `find_user` line 8, `process_data` line 14
**Severity:** Medium — reduces IDE support, static analysis, and documentation quality

```python
def calculate_average(numbers):   # line 1 — no type hints
def find_user(users, id):          # line 8 — no type hints
def process_data(data):            # line 14 — no type hints
```

None of the functions have type hints. Since Python 3.10+, native generics (`list[int]`, `dict[str, int]`) are preferred over `typing.List`, `typing.Dict`.

**Recommended annotations:**

```python
def calculate_average(numbers: list[float]) -> float: ...
def find_user(users: list[dict], user_id: int) -> dict | None: ...
def process_data(data: list[float]) -> list[float]: ...
```

**References:**
- [PEP 484 — Type Hints](https://peps.python.org/pep-0484/)
- [Python Typing in 2025 — Medium](https://khaled-jallouli.medium.com/python-typing-in-2025-a-comprehensive-guide-d61b4f562b99)

#### 5. All functions — no docstrings

**Location:** `calculate_average` line 1, `find_user` line 8, `process_data` line 14
**Severity:** Medium — hinders discoverability and `help()` output

```python
def calculate_average(numbers):   # line 1 — no docstring
def find_user(users, id):          # line 8 — no docstring
def process_data(data):            # line 14 — no docstring
```

None of the functions document their parameters, return values, or contract (e.g., what happens on empty input). A minimal docstring prevents misuse.

**Example:**

```python
def calculate_average(numbers: list[float]) -> float:
    """Return the arithmetic mean of *numbers*.

    Raises:
        ValueError: If *numbers* is empty.
    """
```

---

### LOW

#### 6. `calculate_average` — manual sum loop instead of `sum()`

**Location:** `calculate_average`, lines 2–4
**Severity:** Low — stylistic; the built-in is clearer and slightly faster

```python
# Current
total = 0
for n in numbers:
    total += n
return total / len(numbers)
```

Python's `sum()` built-in is the idiomatic choice ([docs](https://docs.python.org/3/library/functions.html#sum)). For floating-point data, `math.fsum()` offers higher accuracy by avoiding accumulated rounding error.

```python
# Idiomatic
return sum(numbers) / len(numbers)

# For floating-point precision
import math
return math.fsum(numbers) / len(numbers)
```

**References:**
- [Python docs — `sum()`](https://docs.python.org/3/library/functions.html#sum)
- [Python docs — `math.fsum()`](https://docs.python.org/3/library/math.html#math.fsum)

#### 7. `process_data` — `range(len(...))` anti-pattern

**Location:** `process_data`, lines 16–17
**Severity:** Low — un-Pythonic; list comprehension is cleaner and ~20% faster

```python
# Current
result = []
for i in range(len(data)):
    result.append(data[i] * 2)
return result
```

Iterating with `range(len(x))` to then index `x[i]` is the canonical Python anti-pattern. A list comprehension is idiomatic, faster (avoids per-iteration `.append` attribute lookup), and more readable.

```python
# Pythonic
return [item * 2 for item in data]
```

**References:**
- [Real Python — List Comprehensions](https://realpython.com/list-comprehension-python/)
- [Toolbly — List Comprehension vs For Loop Benchmark (2026)](https://toolbly.com/blog/python-list-comprehension-vs-for-loop-benchmark)
- [PEP 202 — List Comprehensions](https://peps.python.org/pep-0202/)

#### 8. `find_user` — linear search on a list is O(n)

**Location:** `find_user`, lines 8–11
**Severity:** Low (design note) — acceptable for small datasets; a dict lookup is O(1)

```python
def find_user(users, id):        # line 8
    for user in users:           # line 9 — iterates entire list each call
        if user["id"] == id:     # line 10
            return user          # line 11
```

If `users` is frequently searched by ID, storing users in a `dict` keyed by ID (`users: dict[int, dict]`) makes lookups O(1):

```python
def find_user(users: dict[int, dict], user_id: int) -> dict | None:
    return users.get(user_id)
```

This is an architectural suggestion rather than a bug; the current approach is correct for small data.

---

## Security Vulnerabilities

No security vulnerabilities were identified. The code performs arithmetic and dictionary lookups without:
- Shell or SQL injection risk
- Unsafe `eval`/`exec` usage
- Insecure deserialization
- Hardcoded secrets or credentials

**Note:** `find_user` does not validate that `user` items are dicts before accessing `user["id"]`. If the `users` list contains non-dict elements, a `TypeError` will be raised. Add input validation if the list comes from untrusted external data.

---

## Refactored Sample

```python
"""Utility functions for numeric and user data processing."""

import math


def calculate_average(numbers: list[float]) -> float:
    """Return the arithmetic mean of *numbers*.

    Uses math.fsum for accurate floating-point summation.

    Args:
        numbers: Non-empty sequence of numeric values.

    Raises:
        ValueError: If *numbers* is empty.
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return math.fsum(numbers) / len(numbers)


def find_user(users: list[dict], user_id: int) -> dict | None:
    """Return the first user whose 'id' matches *user_id*, or None.

    Args:
        users: List of user dicts, each containing an 'id' key.
        user_id: The ID to search for.

    Returns:
        Matching user dict, or None if not found.
    """
    for user in users:
        if user["id"] == user_id:
            return user
    return None


def process_data(data: list[float]) -> list[float]:
    """Return a new list with each element of *data* doubled.

    Args:
        data: List of numeric values.

    Returns:
        New list with each value multiplied by 2.
    """
    return [item * 2 for item in data]
```

---

## Issue Summary Table

| # | Location | Severity | Issue |
|---|----------|----------|-------|
| 1 | `calculate_average` L5 | **Critical** | ZeroDivisionError on empty input |
| 2 | `find_user` L8–11 | **High** | Implicit `None` return invisible to callers |
| 3 | `find_user` L8 | **High** | `id` shadows built-in `id()` |
| 4 | All functions | Medium | No type annotations |
| 5 | All functions | Medium | No docstrings |
| 6 | `calculate_average` L2–4 | Low | Manual loop instead of `sum()` |
| 7 | `process_data` L16–17 | Low | `range(len(...))` anti-pattern |
| 8 | `find_user` L8–11 | Low | O(n) linear search (design note) |

---

*Sources consulted:*
- [Python Built-in Exceptions](https://docs.python.org/3/library/exceptions.html)
- [Real Python — ZeroDivisionError](https://realpython.com/ref/builtin-exceptions/zerodivisionerror/)
- [Python docs — `sum()`](https://docs.python.org/3/library/functions.html#sum)
- [PEP 484 — Type Hints](https://peps.python.org/pep-0484/)
- [Typing best practices — python.org](https://typing.python.org/en/latest/reference/best_practices.html)
- [Ruff A002 — builtin-argument-shadowing](https://docs.astral.sh/ruff/rules/builtin-argument-shadowing/)
- [Pylint W0622 — redefined-builtin](https://pylint.pycqa.org/en/latest/user_guide/messages/warning/redefined-builtin.html)
- [Real Python — List Comprehensions](https://realpython.com/list-comprehension-python/)
- [Toolbly — List Comprehension vs For Loop Benchmark (2026)](https://toolbly.com/blog/python-list-comprehension-vs-for-loop-benchmark)
- [PEP 202 — List Comprehensions](https://peps.python.org/pep-0202/)
- [Python Typing in 2025 — Medium](https://khaled-jallouli.medium.com/python-typing-in-2025-a-comprehensive-guide-d61b4f562b99)
