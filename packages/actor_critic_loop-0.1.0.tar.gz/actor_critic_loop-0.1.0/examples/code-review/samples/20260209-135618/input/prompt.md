Review the Python code in sample.py thoroughly.

Review for:
- Potential bugs (edge cases, errors)
- Style improvements
- Pythonic alternatives
- Security vulnerabilities

Requirements:
- You MUST use WebSearch to check current best practices for any libraries used
- You MUST use WebFetch to verify official documentation for any patterns or APIs referenced
- Include links to relevant PEPs or documentation for your suggestions
- Check for any deprecated patterns by fetching current library documentation

Write the output to ./output/review.md. Categorize all issues by severity.
