def calculate_average(numbers):
    total = 0
    for n in numbers:
        total += n
    return total / len(numbers)


def find_user(users, id):
    for user in users:
        if user["id"] == id:
            return user


def process_data(data):
    result = []
    for i in range(len(data)):
        result.append(data[i] * 2)
    return result
