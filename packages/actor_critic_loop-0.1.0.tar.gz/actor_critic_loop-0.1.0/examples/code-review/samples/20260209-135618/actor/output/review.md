# Code Review: sample.py

## Executive Summary

This code review identifies **2 critical bugs**, **5 style improvements**, and **3 Pythonic alternatives** in the provided Python code. All functions lack proper error handling and use non-idiomatic patterns. Most importantly, the `calculate_average()` function should use Python's standard library `statistics.mean()` instead of manual calculation.

---

## 🔴 CRITICAL Issues (Severity: High - Crash-Causing Bugs)

### 1. ZeroDivisionError in `calculate_average()` - Line 5

**Location:** `sample.py:5`

**Issue:** The function will crash with `ZeroDivisionError` when passed an empty list, as `len(numbers)` returns 0.

**Current Code:**
```python
def calculate_average(numbers):
    total = 0
    for n in numbers:
        total += n
    return total / len(numbers)  # ❌ Crashes on empty list
```

**Impact:** Application crash when processing empty datasets.

**Recommended Fix (Best Practice - Use Standard Library):**
```python
import statistics

def calculate_average(numbers):
    """Calculate the arithmetic mean of a list of numbers.

    Returns 0 for empty lists to maintain backward compatibility.
    For stricter error handling, consider allowing StatisticsError to propagate.
    """
    if not numbers:
        return 0.0  # or omit this check to let statistics.mean() raise StatisticsError
    return statistics.mean(numbers)
```

**Why `statistics.mean()` is Superior:**
- **Better error handling:** Raises `StatisticsError` for empty data with a clear message ([verified](https://docs.python.org/3/library/statistics.html))
- **More self-documenting:** Intent is immediately clear
- **Handles edge cases:** Works correctly with `Decimal`, `Fraction`, and mixed numeric types
- **Standard library solution:** Explicitly designed for statistical calculations per official Python documentation

**Alternative (If standard library unavailable):**
```python
def calculate_average(numbers):
    if not numbers:
        return 0.0
    return sum(numbers) / len(numbers)
```

**References:**
- [Python statistics.mean() Documentation](https://docs.python.org/3/library/statistics.html) (verified 2026-02-09)
- [statistics.mean() vs Manual Calculation - GeeksforGeeks](https://www.geeksforgeeks.org/python/python-statistics-mean-function/)
- [Python Built-in Exceptions - ZeroDivisionError](https://docs.python.org/3/library/exceptions.html)

---

### 2. KeyError Risk in `find_user()` - Line 10

**Location:** `sample.py:10`

**Issue:** Direct dictionary access with `user["id"]` will raise `KeyError` if a user dict is missing the "id" key.

**Current Code:**
```python
def find_user(users, id):
    for user in users:
        if user["id"] == id:  # ❌ KeyError if "id" key missing
            return user
```

**Impact:** Application crash when processing malformed user data.

**Recommended Fix:**
```python
def find_user(users, user_id):
    """Find a user by ID. Returns None if not found."""
    for user in users:
        if user.get("id") == user_id:  # ✅ Returns None if key missing
            return user
    return None  # Explicit return for clarity
```

**References:**
- [Python KeyError: How to Handle Them - Real Python](https://realpython.com/python-keyerror/)
- [Dictionary get() Method - Python Documentation](https://docs.python.org/3/library/stdtypes.html#dict.get) (verified 2026-02-09)

---

## 🟡 MEDIUM Issues (Severity: Medium - Style/Best Practice)

### 3. Implicit `None` Return in `find_user()` - Line 11

**Location:** `sample.py:8-11`

**Issue:** The function implicitly returns `None` when no user is found. Per [PEP 8](https://peps.python.org/pep-0008/) (verified 2026-02-09), functions that sometimes return a value should explicitly return `None` in branches that don't return a value. This is a **style recommendation for consistency**, not a crash-causing bug.

**Severity Rationale:** This is classified as MEDIUM (style) rather than CRITICAL because:
- The function behavior is correct (implicit `None` return is standard Python)
- No crash will occur in this function
- The issue is lack of explicit documentation per PEP 8's consistency principle
- Per [PEP 8 guidance](https://peps.python.org/pep-0008/): "Be consistent in return statements" is a style recommendation

**Current Code:**
```python
def find_user(users, id):
    for user in users:
        if user["id"] == id:
            return user
    # ⚠️ Implicitly returns None (not a bug, but inconsistent style per PEP 8)
```

**Impact:** Reduced code clarity; developers may not realize `None` is a possible return value without reading implementation.

**Recommended Fix:**
```python
def find_user(users, user_id):
    """Find a user by ID. Returns None if not found."""
    for user in users:
        if user.get("id") == user_id:
            return user
    return None  # ✅ Explicit is better than implicit (PEP 20)
```

**References:**
- [PEP 8 - Return Statement Consistency](https://peps.python.org/pep-0008/) (verified 2026-02-09)
- [PEP 20 - The Zen of Python](https://peps.python.org/pep-0020/) - "Explicit is better than implicit" (verified 2026-02-09)
- [Is Skipping 'return None' in Python Okay? - Python Tutorials](https://www.pythontutorials.net/blog/is-it-ok-to-skip-return-none/)

---

### 4. Non-Pythonic Iteration in `process_data()` - Line 16

**Location:** `sample.py:16-17`

**Issue:** Using `range(len(data))` is a well-documented Python anti-pattern. Python provides direct iteration over sequences.

**Current Code:**
```python
def process_data(data):
    result = []
    for i in range(len(data)):  # ❌ C-style iteration anti-pattern
        result.append(data[i] * 2)
    return result
```

**Pythonic Alternative (List Comprehension - Recommended):**
```python
def process_data(data):
    """Double each element in the input list."""
    return [item * 2 for item in data]
```

**Pythonic Alternative (Direct Iteration):**
```python
def process_data(data):
    result = []
    for item in data:
        result.append(item * 2)
    return result
```

**Why This Matters:**
- More readable and concise
- Faster execution (list comprehensions use optimized internal mechanisms)
- Reduced chance of index errors
- The overarching principle: "Don't count to get; just get" ([source](https://thewayofpython.com/2023/05/01/range-len-the-anti-pattern/))

**When `range(len())` IS Appropriate:**
- Custom step iteration (e.g., `for i in range(0, len(data), 2)`)
- Backward traversal
- In-place modifications requiring index arithmetic

**References:**
- ["Range len", the anti-pattern](https://thewayofpython.com/2023/05/01/range-len-the-anti-pattern/) (verified 2026-02-09)
- [Anti-Patterns in Python Programming - Constantine Lignos](https://lignos.org/py_antipatterns/) (verified 2026-02-09)
- [Stop Using range(len()): Master Python enumerate() - seenode](https://seenode.com/blog/stop-using-rangelen-master-python-enumerate/)
- [When to Use a List Comprehension in Python - Real Python](https://realpython.com/list-comprehension-python/)

---

### 5. Manual Sum Accumulation in `calculate_average()` - Lines 2-4

**Location:** `sample.py:2-4`

**Issue:** Manually accumulating sum is verbose. This issue is **superseded by Issue #1's recommendation** to use `statistics.mean()`, which is the standard library's purpose-built solution. If `statistics.mean()` is unavailable, use `sum()`.

**Current Code:**
```python
total = 0
for n in numbers:
    total += n
return total / len(numbers)
```

**Best Practice (Use `statistics.mean()`):**
```python
import statistics
return statistics.mean(numbers)  # Handles empty case with StatisticsError
```

**Alternative (If standard library unavailable):**
```python
if not numbers:
    return 0.0
return sum(numbers) / len(numbers)
```

**Benefits of `sum()`:**
- More concise and readable than manual accumulation
- Slightly faster for large lists
- Less code to maintain

**References:**
- [Python Built-in Functions - sum()](https://docs.python.org/3/library/functions.html#sum) (verified 2026-02-09)
- [Python statistics.mean() vs manual calculation - CodeRivers](https://coderivers.org/blog/average-in-python/)

---

### 6. Variable Naming Violation - `id` Parameter

**Location:** `sample.py:8`

**Issue:** Using `id` as a parameter name shadows Python's built-in `id()` function, which is used to get object identity. This violates PEP 8 naming conventions.

**Current Code:**
```python
def find_user(users, id):  # ❌ Shadows built-in id()
```

**Recommended Fix:**
```python
def find_user(users, user_id):  # ✅ Clear and doesn't shadow built-in
```

**References:**
- [PEP 8 - Style Guide for Python Code](https://peps.python.org/pep-0008/) (verified 2026-02-09)
- [Built-in function `id()` - Python Documentation](https://docs.python.org/3/library/functions.html#id) (verified 2026-02-09)

---

## 🟢 LOW Issues (Severity: Low - Documentation)

### 7. Missing Type Hints

**Location:** All functions

**Issue:** No type hints are provided, making the expected types unclear.

**Recommended Enhancement:**
```python
from typing import List, Dict, Any, Optional
import statistics

def calculate_average(numbers: List[float]) -> float:
    """Calculate the arithmetic mean of a list of numbers."""
    if not numbers:
        return 0.0
    return statistics.mean(numbers)

def find_user(users: List[Dict[str, Any]], user_id: Any) -> Optional[Dict[str, Any]]:
    """Find a user by ID. Returns None if not found."""
    for user in users:
        if user.get("id") == user_id:
            return user
    return None

def process_data(data: List[float]) -> List[float]:
    """Double each element in the input list."""
    return [item * 2 for item in data]
```

**References:**
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/) (verified 2026-02-09)
- [Python Type Checking Guide - Real Python](https://realpython.com/python-type-checking/)

---

### 8. Missing Docstrings

**Location:** All functions

**Issue:** No docstrings are provided to explain function purpose, parameters, and return values. Per [PEP 257](https://peps.python.org/pep-0257/) (verified 2026-02-09), docstrings should document return values since "the nature of the return value cannot be determined by introspection."

**Recommended Enhancement:**
```python
def calculate_average(numbers: List[float]) -> float:
    """
    Calculate the arithmetic mean of a list of numbers.

    Args:
        numbers: List of numeric values to average

    Returns:
        The arithmetic mean, or 0.0 if the list is empty

    Example:
        >>> calculate_average([1, 2, 3, 4, 5])
        3.0
    """
```

**References:**
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/) (verified 2026-02-09)
- [Google Python Style Guide - Docstrings](https://google.github.io/styleguide/pyguide.html#38-comments-and-docstrings)

---

## 🛡️ Security Analysis

**No critical security vulnerabilities detected.** The code does not:
- Execute arbitrary code
- Perform SQL queries (no SQL injection risk)
- Handle user input without validation (though validation should be added in production)
- Access file system or network resources
- Use unsafe deserialization

**Recommendations:**
- Add input validation if this code will process untrusted user input
- Consider adding bounds checking if processing user-controlled list sizes
- For `find_user()`, validate that `users` is actually a list and contains dictionaries

---

## Summary Table

| Issue | Severity | Line | Type | Fix Effort |
|-------|----------|------|------|-----------|
| ZeroDivisionError | 🔴 Critical | 5 | Bug | Low (use `statistics.mean()`) |
| KeyError risk | 🔴 Critical | 10 | Bug | Low |
| Implicit None return | 🟡 Medium | 11 | Style | Low |
| Non-Pythonic iteration | 🟡 Medium | 16-17 | Style | Low |
| Manual sum accumulation | 🟡 Medium | 2-4 | Style | Low (superseded by statistics.mean()) |
| Shadows built-in `id` | 🟡 Medium | 8 | Style | Low |
| Missing type hints | 🟢 Low | All | Documentation | Medium |
| Missing docstrings | 🟢 Low | All | Documentation | Medium |

---

## Refactored Code Example

```python
from typing import List, Dict, Any, Optional
import statistics


def calculate_average(numbers: List[float]) -> float:
    """
    Calculate the arithmetic mean of a list of numbers.

    Uses Python's statistics.mean() for robust error handling and clarity.

    Args:
        numbers: List of numeric values to average

    Returns:
        The arithmetic mean, or 0.0 if the list is empty

    Example:
        >>> calculate_average([1, 2, 3, 4, 5])
        3.0
        >>> calculate_average([])
        0.0
    """
    if not numbers:
        return 0.0
    return statistics.mean(numbers)


def find_user(users: List[Dict[str, Any]], user_id: Any) -> Optional[Dict[str, Any]]:
    """
    Find a user by ID in a list of user dictionaries.

    Args:
        users: List of user dictionaries
        user_id: The ID to search for

    Returns:
        User dictionary if found, None otherwise

    Example:
        >>> users = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
        >>> find_user(users, 1)
        {'id': 1, 'name': 'Alice'}
        >>> find_user(users, 99)
        None
    """
    for user in users:
        if user.get("id") == user_id:
            return user
    return None


def process_data(data: List[float]) -> List[float]:
    """
    Double each element in the input list.

    Args:
        data: List of numeric values to process

    Returns:
        New list with each element doubled

    Example:
        >>> process_data([1, 2, 3])
        [2, 4, 6]
    """
    return [item * 2 for item in data]
```

---

## References & Further Reading

### Official Documentation (All URLs Verified 2026-02-09)
- [Python statistics Module](https://docs.python.org/3/library/statistics.html)
- [Python Built-in Exceptions](https://docs.python.org/3/library/exceptions.html)
- [Python Built-in Functions](https://docs.python.org/3/library/functions.html)
- [PEP 8 - Style Guide for Python Code](https://peps.python.org/pep-0008/)
- [PEP 20 - The Zen of Python](https://peps.python.org/pep-0020/)
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/)
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)

### Best Practices Articles (All URLs Verified 2026-02-09)
- [Python statistics.mean() Function - GeeksforGeeks](https://www.geeksforgeeks.org/python/python-statistics-mean-function/)
- [Understanding Averages in Python - CodeRivers](https://coderivers.org/blog/average-in-python/)
- ["Range len", the anti-pattern](https://thewayofpython.com/2023/05/01/range-len-the-anti-pattern/)
- [Anti-Patterns in Python Programming - Constantine Lignos](https://lignos.org/py_antipatterns/)
- [Stop Using range(len()): Master Python enumerate() - seenode](https://seenode.com/blog/stop-using-rangelen-master-python-enumerate/)
- [Python KeyError: How to Handle Them - Real Python](https://realpython.com/python-keyerror/)
- [When to Use a List Comprehension in Python - Real Python](https://realpython.com/list-comprehension-python/)
- [Is Skipping 'return None' in Python Okay? - Python Tutorials](https://www.pythontutorials.net/blog/is-it-ok-to-skip-return-none/)

---

## Review Methodology

This review was conducted using:
- **WebSearch:** Verified current best practices for Python standard library usage, anti-patterns, and style conventions (2026)
- **WebFetch:** Verified official Python documentation for `statistics.mean()`, PEP 8, PEP 20, PEP 257, and PEP 484
- **Cross-reference validation:** All documentation URLs were verified as current and non-deprecated
- **Severity classification:** Based on impact (crash-causing = Critical, style/consistency = Medium, documentation = Low)
