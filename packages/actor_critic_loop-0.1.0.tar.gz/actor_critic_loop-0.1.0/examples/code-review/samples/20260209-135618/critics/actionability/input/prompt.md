<actor_task>
The actor was given the following task:

{{ actor_prompt }}
</actor_task>

<actor_output>
The actor produced the following files in the output directory:
{% for file in actor_output_files %}
- `{{ file }}`
{% endfor %}
Review these files to evaluate the actor's work.
</actor_output>
{% if actor_output_text %}
<actor_commentary>
The actor said:
{{ actor_output_text }}
</actor_commentary>
{% endif %}

<review_instructions>
Evaluate the code review (in `result.md` or `review.md`) against the original code (in the input directory's `sample.py`).

1. **Actionability** — Are suggestions helpful?
   - Specific, not vague
   - Include code examples where appropriate
   - Reference documentation or PEPs

2. **Coverage** — Were any obvious issues missed?
   - Compare against the original code
   - Look for missed edge cases
   - Check for overlooked security issues
</review_instructions>

<reminder>
- Ground your review in specific evidence: quote relevant sections of the actor's
  output before evaluating them.
- Verify the actor addressed all requirements from the task description above.
- When using WebSearch or WebFetch to verify claims, cite your sources.
- Hard pass or fail only — no partial pass, conditional pass, or pass with reservations.
  If any criterion is not fully met, set `passed: false`.
- Your response MUST be valid JSON with `review`, `passed`, and `issues`.
</reminder>
