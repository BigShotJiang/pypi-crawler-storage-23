# Code Review: sample.py

## Executive Summary

This code review identifies **8 issues** across three functions in `sample.py`. Issues include one critical bug (ZeroDivisionError), style improvements, and missing type hints. All functions lack proper error handling and type annotations, which are now standard practice in modern Python (3.9+).

**Key Finding:** The `calculate_average()` function contains a ZeroDivisionError bug on empty input. The recommended fix is to use Python's standard library `statistics.mean()` function, which is a standard approach for calculating averages. Note that `mean()` is strongly affected by outliers - use `statistics.median()` for outlier-resistant analysis.

---

## 🔴 Critical Issues (Severity: HIGH)

### 1. ZeroDivisionError in `calculate_average()`
**Location:** Line 5
**Severity:** HIGH - Will crash on empty input

**Issue:**
```python
return total / len(numbers)
```

When `numbers` is an empty list, `len(numbers)` returns 0, causing a ZeroDivisionError. This is a common real-world bug in data processing scripts.

**Recommendation (Pythonic Approach):**
Use Python's standard library `statistics.mean()` function, which is the canonical way to calculate averages:

```python
from statistics import mean

def calculate_average(numbers: list[int | float]) -> float:
    """Calculate the arithmetic mean of a list of numbers.

    Args:
        numbers: List of numeric values

    Returns:
        The arithmetic mean as a float

    Raises:
        StatisticsError: If numbers is empty
    """
    return mean(numbers)
```

**Why `statistics.mean()` is the Pythonic approach:**
- **Built-in error handling:** Automatically raises `StatisticsError` on empty input (no manual guard clause needed)
- **Type flexibility:** Supports int, float, Decimal, Fraction
- **Standard library solution:** Canonical approach for calculating averages in Python
- **Well-documented behavior:** Official Python documentation clearly specifies behavior and exceptions

**⚠️ Important Limitation:**
According to the [official Python documentation](https://docs.python.org/3/library/statistics.html), "The mean is strongly affected by outliers and is not necessarily a typical example of the data points. For a more robust, although less efficient, measure of central tendency, see `median()`."

**When to use alternatives:**
- **Data with outliers:** Use `statistics.median()` for outlier-resistant central tendency
- **Trimmed mean:** Use `statistics.mean()` with manual trimming or `scipy.stats.trim_mean()`
- **Robust statistics:** Consider `statistics.median()` or mode-based measures for skewed distributions

**Alternative (Manual Approach):**
If you prefer explicit control:
```python
def calculate_average(numbers: list[int | float]) -> float:
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    return sum(numbers) / len(numbers)
```

**References:**
- [Python statistics.mean() documentation](https://docs.python.org/3/library/statistics.html)
- [GeeksforGeeks - Python statistics.mean() Function](https://www.geeksforgeeks.org/python/python-statistics-mean-function/)
- [W3Schools - Python statistics.mean() Method](https://www.w3schools.com/python/ref_stat_mean.asp)
- [Real Python - ZeroDivisionError Best Practices](https://realpython.com/ref/builtin-exceptions/zerodivisionerror/)

---

### 2. Missing Type Hints on All Functions
**Location:** Lines 1, 8, 14
**Severity:** MEDIUM - Reduces maintainability and prevents static analysis

**Issue:**
None of the three functions include type annotations, which have been standard practice since Python 3.5 and significantly enhanced in Python 3.9+ with built-in generic types and Python 3.10+ with union syntax (`|`).

**Recommendation:**
Add type hints to all function signatures using modern Python 3.10+ syntax:

```python
def calculate_average(numbers: list[int | float]) -> float:
    ...

def find_user(users: list[dict], user_id: int) -> dict | None:
    ...

def process_data(data: list[int | float]) -> list[int | float]:
    ...
```

**Benefits:**
- Enable static type checking with mypy, pyright, etc.
- Improve IDE autocomplete and refactoring
- Serve as inline documentation
- Catch type errors before runtime

**Modern Type Hints (Python 3.9+):**
- Use built-in `list`, `dict`, `tuple` instead of `typing.List`, `typing.Dict`, etc.
- Use `X | None` instead of `Optional[X]` (Python 3.10+)
- Type hints are not enforced at runtime but used by static analyzers

**References:**
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)
- [PEP 585 - Type Hinting Generics In Standard Collections](https://peps.python.org/pep-0585/)
- [Modern Python Type Hints Guide](https://betterstack.com/community/guides/scaling-python/python-type-hints/)
- [Python typing module documentation](https://docs.python.org/3/library/typing.html)
- [Modern Python 3.12+ Features: Type Hints, Generics, and Performance](https://dasroot.net/posts/2026/01/modern-python-312-features-type-hints-generics-performance/)

---

## 🟡 Medium Issues (Severity: MEDIUM)

### 3. Style: Parameter Named `id` Shadows Built-in
**Location:** Line 8
**Severity:** MEDIUM - Reduces code clarity

**Issue:**
```python
def find_user(users, id):
```

The parameter name `id` shadows Python's built-in `id()` function, which can cause confusion.

**Note:** This is a style preference, not a PEP 8 violation. [PEP 8](https://peps.python.org/pep-0008/) specifically mandates trailing underscores for reserved **keywords** (like `class_`, `for_`), but makes no requirements for built-in function names. However, avoiding shadowing of built-ins is widely considered best practice for code clarity.

**Recommendation:**
Use a more descriptive name:

```python
def find_user(users: list[dict], user_id: int) -> dict | None:
    for user in users:
        if user.get("id") == user_id:
            return user
    return None
```

**References:**
- [PEP 8 - Naming Conventions](https://peps.python.org/pep-0008/)
- [Python Shadowing Best Practices](https://oznetnerd.com/2017/07/17/python-shadowing/)
- [Variable Shadowing in Python](https://medium.com/@nicbencini/variable-shadowing-in-python-cfc5457a67c3)

---

## 🟢 Low Issues (Severity: LOW - Style/Performance)

### 4. Implicit `None` Return Could Be More Explicit
**Location:** Lines 8-11
**Severity:** LOW - Documentation/clarity improvement

**Issue:**
```python
def find_user(users, id):
    for user in users:
        if user["id"] == id:
            return user
    # Implicitly returns None if not found
```

The function implicitly returns `None` when no user is found. While this is idiomatic Python (similar to `dict.get()`, `next()`, `re.search()` which all return `None` on failure), making the return explicit improves clarity.

**Recommendation:**
Make the return type explicit for better documentation:

```python
def find_user(users: list[dict], user_id: int) -> dict | None:
    """Find a user by ID.

    Args:
        users: List of user dictionaries
        user_id: User ID to search for

    Returns:
        User dictionary if found, None otherwise
    """
    for user in users:
        if user.get("id") == user_id:
            return user
    return None  # Explicit is better than implicit (PEP 20)
```

**Why This Is Not a Bug:**
Returning `None` for "not found" is a standard Python pattern used throughout the standard library. The caller is expected to check for `None` just as they would when using `dict.get()` or `re.search()`. This is a documentation clarity improvement, not a defect.

**References:**
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)
- [Python typing documentation - Optional types](https://docs.python.org/3/library/typing.html)
- [Real Python - Python Return Statement](https://realpython.com/python-return-statement/)

---

### 5. Non-Pythonic Iteration in `calculate_average()`
**Location:** Lines 2-4
**Severity:** LOW - Less idiomatic, slightly slower

**Issue:**
```python
total = 0
for n in numbers:
    total += n
return total / len(numbers)
```

Manually accumulating values is less Pythonic than using the built-in `sum()` function, which is implemented in C and optimized for performance.

**Recommendation:**
If you choose not to use `statistics.mean()`, use `sum()`:
```python
def calculate_average(numbers: list[int | float]) -> float:
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    return sum(numbers) / len(numbers)
```

**Note:** A standard approach is to use `statistics.mean()` (see Issue #1), though be aware of its sensitivity to outliers.

**Benefits:**
- More concise and readable
- Built-in `sum()` is optimized in C
- Follows "There should be one-- and preferably only one --obvious way to do it" (Zen of Python)

**References:**
- [Python sum() documentation](https://docs.python.org/3/library/functions.html#sum)
- [Python Best Practices – Real Python](https://realpython.com/tutorials/best-practices/)

---

### 6. Non-Pythonic Loop with Index in `process_data()`
**Location:** Lines 15-17
**Severity:** LOW - Less idiomatic, slower than list comprehension

**Issue:**
```python
def process_data(data):
    result = []
    for i in range(len(data)):
        result.append(data[i] * 2)
    return result
```

Using `range(len())` with indexing is a common anti-pattern in Python. This approach is both less readable and slower than a list comprehension.

**Recommendation:**
```python
def process_data(data: list[int | float]) -> list[int | float]:
    return [x * 2 for x in data]
```

**Benefits:**
- **Performance:** List comprehensions are approximately **2x faster** than equivalent for loops for simple operations
- **Readability:** More concise and expressive
- **Pythonic:** Follows Python idioms

**Performance Evidence:**
According to a [2024 IEEE study](https://ieeexplore.ieee.org/document/10589802/), list comprehensions are faster than procedural code in benchmarks. Practical tests show list comprehensions run almost twice as fast as for loops for simple operations.

**References:**
- [For Loop vs. List Comprehension Performance](https://switowski.com/blog/for-loop-vs-list-comprehension/)
- [IEEE Study: List Comprehensions vs For Loops (2024)](https://ieeexplore.ieee.org/document/10589802/)
- [Real Python - When to Use List Comprehension](https://realpython.com/list-comprehension-python/)
- [List Comprehensions vs. For Loops: It is not what you think](https://medium.com/data-science/list-comprehensions-vs-for-loops-it-is-not-what-you-think-34071d4d8207)

---

### 7. Unsafe Dictionary Access in `find_user()`
**Location:** Line 10
**Severity:** LOW - Could fail on malformed data

**Issue:**
```python
if user["id"] == id:
```

If a user dictionary doesn't have an "id" key, this will raise a `KeyError`.

**Recommendation:**
Use `.get()` method for safer dictionary access:

```python
def find_user(users: list[dict], user_id: int) -> dict | None:
    for user in users:
        if user.get("id") == user_id:
            return user
    return None
```

The `.get()` method is the most Pythonic approach for safer key access according to [Real Python's KeyError guide](https://realpython.com/python-keyerror/).

**References:**
- [Python KeyError Exceptions and How to Handle Them - Real Python](https://realpython.com/python-keyerror/)
- [How to Fix KeyError in Python - GeeksforGeeks](https://www.geeksforgeeks.org/python/how-to-fix-keyerror-in-python-how-to-fix-dictionary-error/)
- [Python dict.get() documentation](https://docs.python.org/3/library/stdtypes.html#dict.get)

---

### 8. Missing Docstrings
**Location:** All functions
**Severity:** LOW - Reduces maintainability

**Issue:**
None of the functions have docstrings explaining their purpose, parameters, return values, or potential exceptions.

**Recommendation:**
Add docstrings following [PEP 257](https://peps.python.org/pep-0257/):

```python
def calculate_average(numbers: list[int | float]) -> float:
    """Calculate the arithmetic mean of a list of numbers.

    Args:
        numbers: List of numeric values

    Returns:
        The arithmetic mean as a float

    Raises:
        ValueError: If numbers is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    return sum(numbers) / len(numbers)
```

**References:**
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/)

---

## 🔵 Security Assessment

**Overall Security Status:** ✅ **No security vulnerabilities found**

**Positive Findings:**
- ✅ No usage of dangerous code execution functions (`eval`, `exec`, `compile`)
- ✅ No shell injection risks (no subprocess calls)
- ✅ No SQL injection risks (no database queries)
- ✅ No file system manipulation
- ✅ No network operations
- ✅ No deserialization of untrusted data

**Note:** The KeyError risk (Issue #7) is classified as a **reliability bug**, not a security vulnerability, as it causes crashes rather than data exposure or unauthorized access.

---

## 📋 Deprecation Verification (Task Requirement)

I used WebSearch and WebFetch to verify the current status of all recommended patterns and functions as of February 2026:

### ✅ Not Deprecated - Current Best Practices
| Function/Pattern | Status | Verification Source |
|-----------------|--------|-------------------|
| `statistics.mean()` | ✅ Active, recommended | [Python 3.14 docs](https://docs.python.org/3/library/statistics.html) - Last updated Feb 9, 2026 |
| `sum()` | ✅ Active, enhanced in 3.12 (float accuracy), 3.14 (complex support) | [Python 3.14 Built-in Functions](https://docs.python.org/3/library/functions.html) |
| `dict.get()` | ✅ Active, standard method | [Python Deprecations Index](https://docs.python.org/3/deprecations/index.html) - No mention of deprecation |
| List comprehensions | ✅ Active, preferred over map/filter | [PEP 202](https://peps.python.org/pep-0202/) - Core language feature |
| Type hints (`list`, `dict`, `X \| None`) | ✅ Active, modern syntax (3.9-3.10+) | [PEP 585](https://peps.python.org/pep-0585/), [PEP 604](https://peps.python.org/pep-0604/) |

### 📌 Important Notes:
- **`typing.Dict`, `typing.List`** are deprecated in favor of built-in `dict`, `list` (Python 3.9+)
- **`Optional[X]`** can be replaced with `X | None` (Python 3.10+), though both remain valid
- **pandas 3.0** (Jan 2026) deprecated many pandas-specific methods, but this doesn't affect core Python

**Verification Method:**
- Used WebSearch to check current status of each function/pattern
- Used WebFetch to verify official Python documentation (docs.python.org)
- Confirmed no deprecation notices in Python 3.14.3 documentation (Feb 2026)

**References:**
- [Python 3.14 Built-in Functions Documentation](https://docs.python.org/3/library/functions.html)
- [Python 3.14 Deprecations Index](https://docs.python.org/3/deprecations/index.html)
- [Python statistics Module Documentation](https://docs.python.org/3/library/statistics.html)
- [W3Schools - Python Dictionary get() Method](https://www.w3schools.com/python/ref_dictionary_get.asp)
- [PEP 202 - List Comprehensions](https://peps.python.org/pep-0202/)

---

## Complete Refactored Code (Using `statistics.mean()`)

Here's the complete refactored version addressing all issues and using the Pythonic `statistics.mean()` approach:

```python
"""Sample utility functions for data processing and user management."""

from statistics import mean, StatisticsError


def calculate_average(numbers: list[int | float]) -> float:
    """Calculate the arithmetic mean of a list of numbers.

    Uses Python's standard library statistics.mean() for average
    calculation with built-in error handling. Note: mean() is strongly
    affected by outliers; consider median() for outlier-resistant analysis.

    Args:
        numbers: List of numeric values

    Returns:
        The arithmetic mean as a float

    Raises:
        StatisticsError: If numbers is empty
    """
    return mean(numbers)


def find_user(users: list[dict], user_id: int) -> dict | None:
    """Find a user by ID in a list of user dictionaries.

    Args:
        users: List of user dictionaries, each containing an 'id' key
        user_id: User ID to search for

    Returns:
        User dictionary if found, None otherwise
    """
    for user in users:
        if user.get("id") == user_id:
            return user
    return None


def process_data(data: list[int | float]) -> list[int | float]:
    """Double each element in the input list.

    Args:
        data: List of numeric values

    Returns:
        New list with each element doubled
    """
    return [x * 2 for x in data]
```

### Alternative Version (Manual Approach)

If you prefer explicit control without importing `statistics`:

```python
"""Sample utility functions for data processing and user management."""


def calculate_average(numbers: list[int | float]) -> float:
    """Calculate the arithmetic mean of a list of numbers.

    Args:
        numbers: List of numeric values

    Returns:
        The arithmetic mean as a float

    Raises:
        ValueError: If numbers is empty
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty list")
    return sum(numbers) / len(numbers)


def find_user(users: list[dict], user_id: int) -> dict | None:
    """Find a user by ID in a list of user dictionaries.

    Args:
        users: List of user dictionaries, each containing an 'id' key
        user_id: User ID to search for

    Returns:
        User dictionary if found, None otherwise
    """
    for user in users:
        if user.get("id") == user_id:
            return user
    return None


def process_data(data: list[int | float]) -> list[int | float]:
    """Double each element in the input list.

    Args:
        data: List of numeric values

    Returns:
        New list with each element doubled
    """
    return [x * 2 for x in data]
```

---

## Summary Statistics

| Severity | Count | Issues |
|----------|-------|--------|
| 🔴 HIGH | 1 | ZeroDivisionError |
| 🟡 MEDIUM | 2 | Missing type hints, parameter naming (shadowing `id`) |
| 🟢 LOW | 5 | Implicit None return, non-Pythonic patterns, missing docstrings, unsafe dict access |
| 🔵 SECURITY | 0 | No vulnerabilities found |

**Total Issues:** 8

---

## Verification Checklist

Priority-ordered action items:

- [ ] **HIGH:** Fix ZeroDivisionError in `calculate_average()` by using `statistics.mean()` (note: sensitive to outliers; use `median()` for robust analysis)
- [ ] **MEDIUM:** Add type hints to all functions (enables static type checking)
- [ ] **MEDIUM:** Rename `id` parameter to `user_id` (avoids shadowing built-in)
- [ ] **LOW:** Make None return explicit in `find_user()` for clarity
- [ ] **LOW:** Convert indexed loop to list comprehension in `process_data()`
- [ ] **LOW:** Use `.get()` for safe dictionary access in `find_user()`
- [ ] **LOW:** Add docstrings to all functions
- [ ] **VALIDATION:** Run mypy/pyright for type checking validation
- [ ] **VALIDATION:** Add unit tests covering edge cases (empty lists, missing keys, etc.)

---

## References

### Official Python Documentation
- [Python statistics Module](https://docs.python.org/3/library/statistics.html)
- [PEP 8 - Style Guide for Python Code](https://peps.python.org/pep-0008/)
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/)
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)
- [PEP 585 - Type Hinting Generics In Standard Collections](https://peps.python.org/pep-0585/)
- [Python typing module](https://docs.python.org/3/library/typing.html)
- [Built-in Exceptions](https://docs.python.org/3/library/exceptions.html)
- [Python 3.14 Built-in Functions](https://docs.python.org/3/library/functions.html)
- [Python 3.14 Deprecations Index](https://docs.python.org/3/deprecations/index.html)

### statistics.mean() Resources
- [GeeksforGeeks - Python statistics.mean() Function](https://www.geeksforgeeks.org/python/python-statistics-mean-function/)
- [W3Schools - Python statistics.mean() Method](https://www.w3schools.com/python/ref_stat_mean.asp)
- [Statology - How to Use the Python statistics.mean() Function](https://www.statology.org/how-to-use-the-python-statistics-mean-function/)
- [Tutorialspoint - Python statistics mean() Function](https://www.tutorialspoint.com/python/python_statistics_mean_function.htm)

### Best Practices & Performance
- [Real Python - ZeroDivisionError](https://realpython.com/ref/builtin-exceptions/zerodivisionerror/)
- [List Comprehension vs For Loop Performance](https://switowski.com/blog/for-loop-vs-list-comprehension/)
- [IEEE Study: List Comprehensions Performance (2024)](https://ieeexplore.ieee.org/document/10589802/)
- [Modern Python Type Hints Guide](https://betterstack.com/community/guides/scaling-python/python-type-hints/)
- [Real Python - When to Use List Comprehension](https://realpython.com/list-comprehension-python/)
- [Python Best Practices – Real Python](https://realpython.com/tutorials/best-practices/)
- [Modern Python 3.12+ Features](https://dasroot.net/posts/2026/01/modern-python-312-features-type-hints-generics-performance/)

### Error Handling
- [LabEx - How to Prevent Zero Division Error](https://labex.io/tutorials/python-how-to-prevent-zero-division-error-418012)
- [What Causes ZeroDivisionError in Python](https://blog.newtum.com/zerodivisionerror-in-python/)
- [Real Python - Python KeyError](https://realpython.com/python-keyerror/)
- [GeeksforGeeks - How to Fix KeyError](https://www.geeksforgeeks.org/python/how-to-fix-keyerror-in-python-how-to-fix-dictionary-error/)
- [Python Exception Handling](https://www.askpython.com/python/python-exception-handling)

### Code Quality
- [Python Shadowing Best Practices](https://oznetnerd.com/2017/07/17/python-shadowing/)
- [Variable Shadowing in Python](https://medium.com/@nicbencini/variable-shadowing-in-python-cfc5457a67c3)
- [List Comprehensions vs For Loops Analysis](https://medium.com/data-science/list-comprehensions-vs-for-loops-it-is-not-what-you-think-34071d4d8207)
- [PEP 202 - List Comprehensions](https://peps.python.org/pep-0202/)

### Deprecation Verification (2026)
- [W3Schools - Python Dictionary get() Method](https://www.w3schools.com/python/ref_dictionary_get.asp)
- [Real Python - Dictionaries in Python](https://realpython.com/python-dicts/)
- [GeeksforGeeks - Python Dictionary get() Method](https://www.geeksforgeeks.org/python/python-dictionary-get-method/)
