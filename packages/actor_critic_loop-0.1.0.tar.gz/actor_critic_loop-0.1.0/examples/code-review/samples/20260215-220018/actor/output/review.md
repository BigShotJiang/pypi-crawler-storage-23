# Code Review: sample.py

## Executive Summary

This review identifies **3 CRITICAL** bugs, **2 HIGH** priority style issues, and **3 MEDIUM** priority improvements. The code has no security vulnerabilities but contains several edge cases that will cause runtime errors and uses non-Pythonic patterns that reduce readability and performance.

---

## CRITICAL Issues (Must Fix)

### 1. ZeroDivisionError in `calculate_average()` - Line 5

**Severity:** CRITICAL
**Type:** Bug - Edge Case

**Issue:**
The function will raise `ZeroDivisionError` when called with an empty list because `len(numbers)` will be 0.

```python
def calculate_average(numbers):
    total = 0
    for n in numbers:
        total += n
    return total / len(numbers)  # ❌ Crashes if numbers is empty
```

**Impact:**
```python
calculate_average([])  # ZeroDivisionError: division by zero
```

**Fix:**
Add input validation before division:

```python
def calculate_average(numbers):
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)
```

**Alternative (with default value):**
```python
def calculate_average(numbers):
    if not numbers:
        return 0.0  # or None, depending on requirements
    return sum(numbers) / len(numbers)
```

**References:**
- [ZeroDivisionError Best Practices](https://realpython.com/ref/builtin-exceptions/zerodivisionerror/)
- [Python Error Handling Documentation](https://docs.python.org/3/tutorial/errors.html)
- [Handling Empty Iterables](https://blog.newtum.com/zerodivisionerror-in-python/)

---

### 2. Missing Return Value in `find_user()` - Lines 8-11

**Severity:** CRITICAL
**Type:** Bug - Missing Error Handling

**Issue:**
The function implicitly returns `None` when no user is found, which can cause `AttributeError` or `TypeError` in calling code that expects a user dictionary.

```python
def find_user(users, id):
    for user in users:
        if user["id"] == id:
            return user
    # ❌ Implicit return None - no indication of failure
```

**Impact:**
```python
user = find_user(users, 999)
print(user["name"])  # TypeError: 'NoneType' object is not subscriptable
```

**Fix:**
Explicitly handle the not-found case:

```python
def find_user(users, user_id):
    for user in users:
        if user["id"] == user_id:
            return user
    raise ValueError(f"User with id {user_id} not found")
```

**Alternative (return None explicitly with better pattern):**
```python
def find_user(users, user_id):
    """Find user by ID. Returns None if not found."""
    return next((user for user in users if user["id"] == user_id), None)
```

**References:**
- [Python next() Built-in Function](https://docs.python.org/3/library/functions.html#next)
- [Python Exception Handling](https://docs.python.org/3/tutorial/errors.html)

---

### 3. Shadowing Built-in `id` Function - Line 8

**Severity:** CRITICAL
**Type:** Bug - Name Shadowing

**Issue:**
The parameter name `id` shadows Python's built-in `id()` function, which can cause subtle bugs in code that needs to use `id()` within the function scope.

```python
def find_user(users, id):  # ❌ Shadows built-in id()
    # Now id() function is inaccessible in this scope
```

**Impact:**
```python
def find_user(users, id):
    debug_id = id(users)  # ❌ TypeError: 'int' object is not callable
    # id now refers to the parameter, not the built-in function
```

**Fix:**
Rename the parameter to avoid shadowing:

```python
def find_user(users, user_id):  # ✅ Clear and doesn't shadow built-ins
    for user in users:
        if user["id"] == user_id:
            return user
```

**References:**
- [Ruff builtin-argument-shadowing Rule (A002)](https://docs.astral.sh/ruff/rules/builtin-argument-shadowing/)
- [PEP 8 - Function Argument Naming](https://peps.python.org/pep-0008/) (addresses keyword conflicts with trailing underscore convention)
- This is a widely recognized anti-pattern caught by linters like Ruff, pylint, and flake8-builtins

---

## HIGH Priority Issues (Should Fix)

### 4. Non-Pythonic Manual Summation - Lines 2-5

**Severity:** HIGH
**Type:** Style - Non-Idiomatic Code

**Issue:**
Manually accumulating sum with a for loop instead of using Python's built-in `sum()` function.

```python
def calculate_average(numbers):
    total = 0
    for n in numbers:
        total += n  # ❌ Manual accumulation
    return total / len(numbers)
```

**Why It Matters:**
- Less readable - requires more mental parsing
- Slower performance - bytecode optimization in built-ins
- More verbose - 3 lines vs 1 line
- Error-prone - easy to forget initialization

**Fix:**
Use the built-in `sum()` function:

```python
def calculate_average(numbers):
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)  # ✅ Pythonic and concise
```

**Performance Note:**
The `sum()` function is implemented in C and optimized for numeric operations. As of Python 3.12+, it uses an algorithm with higher accuracy for floating-point summation.

**References:**
- [Python sum() Documentation](https://docs.python.org/3/library/functions.html#sum)
- [sum() Best Practices](https://realpython.com/ref/builtin-functions/sum/)
- [PEP 8 Style Guide](https://peps.python.org/pep-0008/)

---

### 5. Manual Index Iteration - Lines 15-18

**Severity:** HIGH
**Type:** Style - Non-Idiomatic Code

**Issue:**
Using `range(len(data))` with manual indexing instead of direct iteration or list comprehension.

```python
def process_data(data):
    result = []
    for i in range(len(data)):  # ❌ C-style iteration
        result.append(data[i] * 2)
    return result
```

**Why It Matters:**
- Less Pythonic - doesn't leverage Python's iteration protocol
- More error-prone - risk of index errors
- Less readable - indirect access pattern
- Slower - extra lookup operations

**Fix (List Comprehension - Preferred):**
```python
def process_data(data):
    return [item * 2 for item in data]  # ✅ Pythonic, fast, concise
```

**Alternative (Direct Iteration):**
```python
def process_data(data):
    result = []
    for item in data:  # ✅ Better than range(len())
        result.append(item * 2)
    return result
```

**Performance Impact:**
List comprehensions are faster than manual append loops because they use the optimized `LIST_APPEND` bytecode instruction rather than looking up the list variable and calling its `append()` method on each iteration.

**References:**
- [PEP 202 - List Comprehensions](https://peps.python.org/pep-0202/)
- [List Comprehension vs For Loops](https://realpython.com/list-comprehension-python/)
- [List Comprehension Performance](https://switowski.com/blog/for-loop-vs-list-comprehension/)

---

## MEDIUM Priority Issues (Nice to Have)

### 6. Inconsistent Function Documentation - Lines 1, 8, 14

**Severity:** MEDIUM
**Type:** Style - Missing Docstrings

**Issue:**
All three functions lack docstrings explaining purpose, parameters, return values, and potential exceptions.

```python
def calculate_average(numbers):  # ❌ Line 1: No docstring
    # ...

def find_user(users, id):  # ❌ Line 8: No docstring
    # ...

def process_data(data):  # ❌ Line 14: No docstring
    # ...
```

**Fix:**
Add comprehensive docstrings following PEP 257 conventions:

```python
def calculate_average(numbers):
    """Calculate the arithmetic mean of a sequence of numbers.

    Args:
        numbers: An iterable of numeric values.

    Returns:
        float: The arithmetic mean of the input values.

    Raises:
        ValueError: If numbers is empty.

    Examples:
        >>> calculate_average([1, 2, 3, 4, 5])
        3.0
        >>> calculate_average([10, 20])
        15.0
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)
```

**References:**
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/)
- [Real Python - Documenting Python Code](https://realpython.com/documenting-python-code-a-complete-guide/)

---

### 7. Type Hints Missing - Lines 1, 8, 14

**Severity:** MEDIUM
**Type:** Style - Missing Type Annotations

**Issue:**
No type hints for function parameters or return values, reducing IDE support and static analysis capabilities.

```python
def calculate_average(numbers):  # ❌ Line 1: No type hints
    # ...

def find_user(users, id):  # ❌ Line 8: No type hints
    # ...

def process_data(data):  # ❌ Line 14: No type hints
    # ...
```

**Fix:**
Add type hints following PEP 484:

```python
from typing import Sequence, Optional, Dict, Any, List

def calculate_average(numbers: Sequence[float]) -> float:
    """Calculate the arithmetic mean of a sequence of numbers."""
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)

def find_user(users: List[Dict[str, Any]], user_id: int) -> Optional[Dict[str, Any]]:
    """Find user by ID. Returns None if not found."""
    return next((user for user in users if user["id"] == user_id), None)

def process_data(data: Sequence[float]) -> List[float]:
    """Double each value in the input sequence."""
    return [item * 2 for item in data]
```

**Benefits:**
- Better IDE autocomplete and IntelliSense
- Static type checking with mypy/pyright
- Self-documenting code
- Earlier bug detection

**References:**
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)
- [Python typing Module](https://docs.python.org/3/library/typing.html)
- [Real Python - Type Checking](https://realpython.com/python-type-checking/)

---

### 8. `find_user()` Could Use Generator Expression - Lines 9-11

**Severity:** MEDIUM
**Type:** Optimization - More Pythonic Alternative

**Issue:**
The manual for loop in `find_user()` (lines 9-11) can be replaced with a more Pythonic `next()` with generator expression.

**Current Implementation:**
```python
def find_user(users, id):
    for user in users:         # ❌ Line 9: Manual loop
        if user["id"] == id:   # ❌ Line 10
            return user        # ❌ Line 11
```

**Pythonic Alternative:**
```python
def find_user(users: List[Dict[str, Any]], user_id: int) -> Optional[Dict[str, Any]]:
    """Find user by ID. Returns None if not found."""
    return next((user for user in users if user["id"] == user_id), None)
```

**Advantages:**
- More concise - single expression
- Memory efficient - generator doesn't create intermediate list
- Explicit default value - clearly shows None return case
- Idiomatic Python - leverages built-in iteration tools

**References:**
- [Python next() Function](https://docs.python.org/3/library/functions.html#next)
- [Generator Expressions](https://peps.python.org/pep-0289/)

---

## Security Analysis

✅ **No security vulnerabilities detected.**

The code does not use any dangerous functions like:
- `eval()` or `exec()` (code injection risk)
- `subprocess` with `shell=True` (command injection risk)
- `pickle.loads()` on untrusted data (arbitrary code execution)
- SQL string concatenation (SQL injection risk)

**References:**
- [Python Security Best Practices](https://www.aikido.dev/blog/python-security-vulnerabilities)
- [Python eval() Security Risks](https://www.codiga.io/blog/python-eval/)
- [Subprocess Security](https://www.codiga.io/blog/python-subprocess-security/)

---

## Complete Refactored Version

Here's the fully refactored code incorporating all recommendations:

```python
"""Utility functions for data processing and user management."""

from typing import Sequence, Optional, Dict, Any, List


def calculate_average(numbers: Sequence[float]) -> float:
    """Calculate the arithmetic mean of a sequence of numbers.

    Args:
        numbers: An iterable of numeric values.

    Returns:
        The arithmetic mean of the input values.

    Raises:
        ValueError: If numbers is empty.

    Examples:
        >>> calculate_average([1, 2, 3, 4, 5])
        3.0
        >>> calculate_average([10.5, 20.5])
        15.5
    """
    if not numbers:
        raise ValueError("Cannot calculate average of empty sequence")
    return sum(numbers) / len(numbers)


def find_user(users: List[Dict[str, Any]], user_id: int) -> Optional[Dict[str, Any]]:
    """Find user by ID in a list of user dictionaries.

    Args:
        users: List of user dictionaries, each containing an 'id' key.
        user_id: The ID to search for.

    Returns:
        The user dictionary if found, None otherwise.

    Examples:
        >>> users = [{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]
        >>> find_user(users, 1)
        {'id': 1, 'name': 'Alice'}
        >>> find_user(users, 999)
        None
    """
    return next((user for user in users if user["id"] == user_id), None)


def process_data(data: Sequence[float]) -> List[float]:
    """Double each value in the input sequence.

    Args:
        data: An iterable of numeric values.

    Returns:
        A new list with each value doubled.

    Examples:
        >>> process_data([1, 2, 3])
        [2, 4, 6]
        >>> process_data([])
        []
    """
    return [item * 2 for item in data]
```

---

## Summary of Changes

| Issue | Severity | Type | Impact |
|-------|----------|------|--------|
| ZeroDivisionError in `calculate_average()` | CRITICAL | Bug | Runtime crash on empty input |
| Missing return handling in `find_user()` | CRITICAL | Bug | Unexpected None returns |
| Shadowing built-in `id` | CRITICAL | Bug | Function name collision |
| Manual summation instead of `sum()` | HIGH | Style | Less readable, slower |
| Manual indexing with `range(len())` | HIGH | Style | Less Pythonic, slower |
| Missing docstrings | MEDIUM | Style | Reduced maintainability |
| Missing type hints | MEDIUM | Style | Reduced IDE support |
| Manual loop in `find_user()` | MEDIUM | Optimization | Less idiomatic |

**Priority Actions:**
1. Fix the ZeroDivisionError (prevents crashes)
2. Rename `id` parameter to `user_id` (prevents shadowing)
3. Handle missing user case explicitly (prevents TypeErrors)
4. Replace manual loops with Pythonic alternatives (improves readability)
5. Add type hints and docstrings (improves maintainability)

---

## Additional Resources

- [PEP 8 - Style Guide for Python Code](https://peps.python.org/pep-0008/)
- [PEP 202 - List Comprehensions](https://peps.python.org/pep-0202/)
- [PEP 257 - Docstring Conventions](https://peps.python.org/pep-0257/)
- [PEP 484 - Type Hints](https://peps.python.org/pep-0484/)
- [Python Built-in Functions Documentation](https://docs.python.org/3/library/functions.html)
- [Real Python - Writing Beautiful Pythonic Code with PEP 8](https://realpython.com/python-pep8/)
- [Python Error and Exception Handling](https://docs.python.org/3/tutorial/errors.html)
