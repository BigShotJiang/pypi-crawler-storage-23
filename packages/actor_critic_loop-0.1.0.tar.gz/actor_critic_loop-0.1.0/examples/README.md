# Example Workspaces

Ready-to-use workspaces demonstrating the actor-critic refinement loop. All examples run multiple rounds by default, where the actor refines its output based on critic feedback.

## Available Examples

### hello-world

The simplest possible example. An actor that responds as a friendly assistant and shares a tech news headline. Critic evaluates tone and relevance.

```bash
./examples/hello-world/run.sh
```

### code-review

A code review example. An actor configured as a code reviewer analyzes Python code for bugs and style issues. Critic evaluates completeness and constructiveness.

```bash
./examples/code-review/run.sh
```

### epic-refinement

A product management example. An actor that breaks down epics into well-defined user stories with acceptance criteria. Critic evaluates story quality and INVEST principles.

```bash
./examples/epic-refinement/run.sh
```

### blog-post

A content writing example. An actor that transforms rough notes into polished blog posts. Critic evaluates structure, engagement, and accuracy.

```bash
./examples/blog-post/run.sh
```

### summarizer

A text summarization example. An actor that creates concise summaries of longer content. Critic evaluates accuracy and conciseness.

```bash
./examples/summarizer/run.sh
```

## Workspace Structure

Each example uses a `template/` directory that `init --template` copies into an ephemeral workspace:

```
example-name/
├── template/                  # Blueprint for init --template
│   ├── actor-critic.yaml      # Orchestration configuration
│   ├── actor/                 # Actor role configuration
│   │   ├── CLAUDE.md
│   │   ├── .claude/
│   │   │   ├── settings.json
│   │   │   └── rules/
│   │   │       └── output.md
│   │   └── output/            # Actor's working output
│   ├── input/                 # Source material + prompt.md
│   │   ├── prompt.md
│   │   └── [domain files]
│   ├── critics/               # Critic(s) for reviewing actor output
│   │   └── <name>/
│   │       ├── CLAUDE.md
│   │       ├── .claude/
│   │       │   └── settings.json
│   │       ├── input/
│   │       │   └── prompt.md  # Jinja2 template
│   │       └── output/
│   └── output/                # Final output (written by orchestrator)
├── run.sh                     # Scaffolds, runs, archives, cleans up
└── samples/                   # Timestamped archived workspace snapshots
```

Most examples use a `quality` critic; code-review uses `review`.

## How run.sh Works

Each `run.sh` follows this pattern:

1. **Clean** — Remove any previous ephemeral workspace
2. **Scaffold** — `actor-critic init workspace/ --template template/`
3. **Run** — `actor-critic run --workspace workspace/`
4. **Archive** — Copy the entire workspace to `samples/<timestamp>/`
5. **Clean up** — Remove the ephemeral workspace

## How the Refinement Loop Works

All examples run multiple rounds (controlled by `max_rounds` in `actor-critic.yaml`). Each round:

1. **Actor generates** — Produces output in `actor/output/`
2. **Critic reviews** — Evaluates output, returns JSON feedback (`passed`, `review`, `issues`)
3. **Actor refines** — If not stopped, actor receives feedback and revises its output
4. **Repeat** — Loop continues until the stop condition is met

After the final round, the actor's output is copied to `output/` for easy access.

## Customizing Examples

Use `init --template` to create a new workspace from any example:

```bash
uv run actor-critic init ./my-task --template ./examples/hello-world/template
```

Then edit the workspace files (`actor/CLAUDE.md`, `input/prompt.md`, etc.) to customize.
