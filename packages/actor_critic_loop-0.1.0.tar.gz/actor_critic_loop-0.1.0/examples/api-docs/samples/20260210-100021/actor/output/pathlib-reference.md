# pathlib.Path API Reference

This document provides API reference documentation for selected `pathlib.Path` methods and properties.

---

## Methods

### Path.exists()

**Signature:**
```python
Path.exists(*, follow_symlinks: bool = True) -> bool
```

**Description:**
Checks whether the path exists in the filesystem. Returns `True` if the path points to an existing file or directory, `False` otherwise. By default, this method follows symbolic links, meaning it will return `True` if the link target exists. This behavior can be controlled with the `follow_symlinks` parameter.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `follow_symlinks` | `bool` | `True` | If `True`, follows symbolic links and checks if the target exists. If `False`, checks if the symlink itself exists. |

**Return type:**
`bool` — `True` if the path exists, `False` otherwise

**Example:**
```python
from pathlib import Path

path = Path("example.txt")
if path.exists():
    print("File exists!")
else:
    print("File not found")
```

---

### Path.mkdir()

**Signature:**
```python
Path.mkdir(mode: int = 0o777, parents: bool = False, exist_ok: bool = False) -> None
```

**Description:**
Creates a new directory at the path location. By default, raises an error if the parent directory doesn't exist or if the directory already exists. These behaviors can be controlled with the `parents` and `exist_ok` parameters. The `mode` parameter controls the directory permissions.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mode` | `int` | `0o777` | The Unix permissions to apply to the directory. Default `0o777` gives read, write, and execute permissions to all. |
| `parents` | `bool` | `False` | If `True`, creates any missing parent directories. If `False`, raises `FileNotFoundError` if parent doesn't exist. |
| `exist_ok` | `bool` | `False` | If `True`, does not raise an error if the directory already exists. If `False`, raises `FileExistsError` if directory exists. |

**Return type:**
`None`

**Example:**
```python
from pathlib import Path

# Create a single directory
Path("new_dir").mkdir()

# Create nested directories
Path("parent/child/grandchild").mkdir(parents=True, exist_ok=True)
```

---

### Path.iterdir()

**Signature:**
```python
Path.iterdir() -> Iterator[Path]
```

**Description:**
Iterates over the contents of a directory, yielding `Path` objects for each entry. The iteration order is arbitrary and does not include the special entries `.` and `..`. Raises `NotADirectoryError` if the path is not a directory.

**Parameters:**
None

**Return type:**
`Iterator[Path]` — an iterator yielding `Path` objects for each entry in the directory

**Example:**
```python
from pathlib import Path

directory = Path(".")
for item in directory.iterdir():
    print(item.name)
```

---

### Path.glob()

**Signature:**
```python
Path.glob(pattern: str | PathLike, *, case_sensitive: bool | None = None, recurse_symlinks: bool = False) -> Iterator[Path]
```

**Description:**
Finds all files and directories matching the specified glob pattern. The pattern can include wildcards like `*` (matches any characters) and `**` (matches any files and zero or more directories). The method returns an iterator that yields matching `Path` objects.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pattern` | `str \| PathLike` | (required) | The glob pattern to match against. Supports wildcards like `*.txt` or `**/*.py`. |
| `case_sensitive` | `bool \| None` | `None` | If `True`, matches are case-sensitive. If `False`, matches are case-insensitive. If `None`, uses the platform default (case-insensitive on Windows, case-sensitive on Unix). |
| `recurse_symlinks` | `bool` | `False` | If `True`, follows symbolic links when using the `**` recursive wildcard. If `False`, does not follow symlinks. |

**Return type:**
`Iterator[Path]` — an iterator yielding `Path` objects matching the pattern

**Example:**
```python
from pathlib import Path

# Find all .txt files in current directory
for txt_file in Path(".").glob("*.txt"):
    print(txt_file)

# Find all .py files recursively
for py_file in Path(".").glob("**/*.py"):
    print(py_file)
```

---

### Path.read_text()

**Signature:**
```python
Path.read_text(encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> str
```

**Description:**
Reads the contents of the file as a string. The file is opened in text mode, and the entire contents are read into memory. By default, uses the platform's default encoding, but this can be overridden with the `encoding` parameter.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `encoding` | `str \| None` | `None` | The text encoding to use when reading the file. If `None`, uses the platform default encoding. |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values include `'strict'`, `'ignore'`, and `'replace'`. |
| `newline` | `str \| None` | `None` | Controls how universal newlines mode works. Can be `None`, `''`, `'\n'`, `'\r'`, or `'\r\n'`. |

**Return type:**
`str` — the file contents as a string

**Example:**
```python
from pathlib import Path

path = Path("example.txt")
content = path.read_text(encoding="utf-8")
print(content)
```

---

### Path.write_text()

**Signature:**
```python
Path.write_text(data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int
```

**Description:**
Writes a string to the file, overwriting the file if it already exists. The file is opened in text mode. Returns the number of characters written.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `str` | (required) | The string data to write to the file. |
| `encoding` | `str \| None` | `None` | The text encoding to use when writing the file. If `None`, uses the platform default encoding. |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values include `'strict'`, `'ignore'`, and `'replace'`. |
| `newline` | `str \| None` | `None` | Controls how newlines are written. Can be `None`, `''`, `'\n'`, `'\r'`, or `'\r\n'`. |

**Return type:**
`int` — the number of characters written

**Example:**
```python
from pathlib import Path

path = Path("output.txt")
chars_written = path.write_text("Hello, World!", encoding="utf-8")
print(f"Wrote {chars_written} characters")
```

---

### Path.resolve()

**Signature:**
```python
Path.resolve(strict: bool = False) -> Path
```

**Description:**
Converts the path to an absolute path, resolving any symbolic links and eliminating `.` and `..` components. The resulting path is normalized and absolute.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `strict` | `bool` | `False` | If `True`, raises `FileNotFoundError` if the path doesn't exist. If `False`, the path is resolved as far as possible. |

**Return type:**
`Path` — the resolved absolute path

**Example:**
```python
from pathlib import Path

relative_path = Path("../parent/file.txt")
absolute_path = relative_path.resolve()
print(absolute_path)
```

---

## Properties

### Path.stem

**Signature:**
```python
Path.stem -> str
```

**Description:**
Returns the final component of the path without its suffix (file extension). For example, `Path('document.txt').stem` returns `'document'`. If the path has multiple suffixes, only the last one is removed.

**Return type:**
`str` — the filename without extension

**Example:**
```python
from pathlib import Path

path = Path("report.pdf")
print(path.stem)  # Output: "report"

path2 = Path("archive.tar.gz")
print(path2.stem)  # Output: "archive.tar"
```

---

### Path.suffix

**Signature:**
```python
Path.suffix -> str
```

**Description:**
Returns the file extension of the final component, including the leading dot. Returns an empty string if the path has no extension. For files with multiple extensions like `archive.tar.gz`, only the last extension (`.gz`) is returned.

**Return type:**
`str` — the file extension including the dot, or empty string if no extension

**Example:**
```python
from pathlib import Path

path = Path("document.txt")
print(path.suffix)  # Output: ".txt"

path2 = Path("README")
print(path2.suffix)  # Output: ""

path3 = Path("archive.tar.gz")
print(path3.suffix)  # Output: ".gz"
```

---

### Path.parent

**Signature:**
```python
Path.parent -> Path
```

**Description:**
Returns the logical parent directory of the path. This is the path with the final component removed. For a root path, the parent is the path itself.

**Return type:**
`Path` — the parent directory as a `Path` object

**Example:**
```python
from pathlib import Path

path = Path("/home/user/documents/file.txt")
print(path.parent)  # Output: /home/user/documents

# Can chain to get grandparent
print(path.parent.parent)  # Output: /home/user
```
