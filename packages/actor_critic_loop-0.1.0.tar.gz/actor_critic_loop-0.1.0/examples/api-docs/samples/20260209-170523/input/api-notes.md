# pathlib.Path Method Notes

Rough notes on selected Path methods and properties. Use these as source material.

## Methods

- **Path.exists()** — checks if path exists, returns bool

- **Path.mkdir()** — creates directory, has `parents` and `exist_ok` params

- **Path.iterdir()** — iterates over directory contents

- **Path.glob(pattern)** — find files matching pattern, like `*.txt`

- **Path.read_text()** — reads file as string, something about encoding

- **Path.write_text(data)** — writes string to file

- **Path.resolve()** — makes path absolute

## Properties

- **Path.stem** — filename without extension

- **Path.suffix** — file extension

- **Path.parent** — parent directory
