Write API reference documentation for selected Python `pathlib.Path` methods.

Use ONLY the rough notes provided in `./input/api-notes.md` as your source material — do NOT access the internet or use any external resources.

Output the documentation to `./output/pathlib-reference.md`.

For each method or property, include:

1. **Signature** — the full method/property signature
2. **Description** — what it does, clearly explained
3. **Parameters** — a table with parameter name, type, default value, and description (skip for properties)
4. **Return type** — what the method/property returns
5. **Example** — a short, runnable code example

Cover ALL methods and properties listed in the notes file. Be precise about parameter names, types, and default values.
