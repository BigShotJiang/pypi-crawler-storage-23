# Python pathlib.Path API Reference

This document provides detailed reference documentation for selected methods and properties of the `pathlib.Path` class.

---

## Methods

### Path.exists()

**Signature:**
```python
def exists(self, *, follow_symlinks: bool = True) -> bool
```

**Description:**
Checks whether the path exists in the filesystem. Returns `True` if the path points to an existing file, directory, or symbolic link. Returns `False` otherwise. This method does not raise an exception if the path is inaccessible due to permissions.

**Note:** The rough notes did not specify the `follow_symlinks` parameter. Based on standard Python `pathlib` behavior, this parameter controls whether symbolic links are followed when checking existence.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `follow_symlinks` | `bool` | `True` | If `True`, follows symbolic links when checking existence. If `False`, checks the symlink itself. |

**Return Type:**
`bool` — `True` if the path exists, `False` otherwise.

**Example:**
```python
from pathlib import Path

p = Path("/etc/hosts")
if p.exists():
    print("File exists")
else:
    print("File does not exist")
```

---

### Path.mkdir()

**Signature:**
```python
def mkdir(self, mode: int = 0o777, parents: bool = False, exist_ok: bool = False) -> None
```

**Description:**
Creates a new directory at the path. By default, raises `FileExistsError` if the directory already exists and `FileNotFoundError` if parent directories don't exist. Use the `parents` and `exist_ok` parameters to control this behavior.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mode` | `int` | `0o777` | The file mode and access flags for the new directory. |
| `parents` | `bool` | `False` | If `True`, creates any missing parent directories. If `False`, raises `FileNotFoundError` if a parent directory doesn't exist. |
| `exist_ok` | `bool` | `False` | If `True`, does not raise an error if the directory already exists. If `False`, raises `FileExistsError` if the target directory already exists. |

**Return Type:**
`None`

**Example:**
```python
from pathlib import Path

# Create a directory with parent directories
p = Path("./data/logs/2024")
p.mkdir(parents=True, exist_ok=True)

# Create a simple directory
p2 = Path("./temp")
p2.mkdir()
```

---

### Path.iterdir()

**Signature:**
```python
def iterdir(self) -> Generator[Path, None, None]
```

**Description:**
Iterates over the contents of a directory, yielding `Path` objects for each item (file, directory, or symlink) in the directory. The order of iteration is arbitrary. Does not include the special entries `.` and `..`. Raises `NotADirectoryError` if the path is not a directory.

**Parameters:**
None

**Return Type:**
`Generator[Path, None, None]` — A generator yielding `Path` objects for each entry in the directory.

**Example:**
```python
from pathlib import Path

p = Path("./")
for item in p.iterdir():
    print(item.name, "Directory" if item.is_dir() else "File")
```

---

### Path.glob()

**Signature:**
```python
def glob(self, pattern: str, *, case_sensitive: bool | None = None, recurse_symlinks: bool = False) -> Generator[Path, None, None]
```

**Description:**
Finds all files and directories matching the specified glob pattern. The pattern can include wildcards like `*` (matches any characters) and `**` (matches directories recursively). Returns a generator of matching `Path` objects. The pattern is matched relative to the current path.

**Note:** The rough notes did not specify the `case_sensitive` and `recurse_symlinks` parameters. These are included based on standard Python `pathlib` behavior for controlling pattern matching and symlink handling.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pattern` | `str` | (required) | A glob pattern string, such as `"*.txt"` for all text files or `"**/*.py"` for all Python files recursively. |
| `case_sensitive` | `bool \| None` | `None` | Controls case sensitivity of pattern matching. If `None`, uses platform default behavior. |
| `recurse_symlinks` | `bool` | `False` | If `True`, follows symbolic links when recursing with `**` patterns. If `False`, does not follow symlinks. |

**Return Type:**
`Generator[Path, None, None]` — A generator yielding `Path` objects matching the pattern.

**Example:**
```python
from pathlib import Path

p = Path("./src")
# Find all Python files
for py_file in p.glob("*.py"):
    print(py_file)

# Find all text files recursively
for txt_file in p.glob("**/*.txt"):
    print(txt_file)
```

---

### Path.read_text()

**Signature:**
```python
def read_text(self, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> str
```

**Description:**
Reads the file contents as a string. Opens the file in text mode, reads the entire contents, and returns it as a string. The file is automatically closed after reading. Use the `encoding` parameter to specify the character encoding.

**Note:** The rough notes mentioned encoding but did not specify the `newline` parameter. This parameter controls newline handling with the same semantics as the built-in `open()` function.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `encoding` | `str \| None` | `None` | The character encoding to use when reading the file. If `None`, uses the system default encoding. |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values include `'strict'` (raise an error), `'ignore'` (skip bad characters), and `'replace'` (replace with a placeholder). |
| `newline` | `str \| None` | `None` | Controls newline handling. If `None`, uses universal newlines mode. Can be `''`, `'\n'`, `'\r'`, or `'\r\n'`. |

**Return Type:**
`str` — The entire contents of the file as a string.

**Example:**
```python
from pathlib import Path

p = Path("./config.txt")
content = p.read_text(encoding="utf-8")
print(content)
```

---

### Path.write_text()

**Signature:**
```python
def write_text(self, data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int
```

**Description:**
Writes a string to the file, overwriting any existing content. Opens the file in text mode, writes the data, and closes it automatically. If the file doesn't exist, it is created. If it exists, its previous contents are replaced.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `str` | (required) | The string content to write to the file. |
| `encoding` | `str \| None` | `None` | The character encoding to use when writing. If `None`, uses the system default encoding. |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values include `'strict'`, `'ignore'`, and `'replace'`. |
| `newline` | `str \| None` | `None` | Controls newline handling. If `None`, uses the system default. |

**Return Type:**
`int` — The number of characters written to the file.

**Example:**
```python
from pathlib import Path

p = Path("./output.txt")
num_chars = p.write_text("Hello, World!\n", encoding="utf-8")
print(f"Wrote {num_chars} characters")
```

---

### Path.resolve()

**Signature:**
```python
def resolve(self, strict: bool = False) -> Path
```

**Description:**
Returns an absolute version of the path, resolving any symbolic links and eliminating `.` and `..` components. The resulting path is fully resolved and normalized. By default, does not raise an error if the path doesn't exist.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `strict` | `bool` | `False` | If `True`, raises `FileNotFoundError` if the path doesn't exist. If `False`, returns the resolved path even if it doesn't exist. |

**Return Type:**
`Path` — A new `Path` object representing the absolute, resolved path.

**Example:**
```python
from pathlib import Path

p = Path("../src/main.py")
absolute_path = p.resolve()
print(absolute_path)  # e.g., /home/user/project/src/main.py
```

---

## Properties

### Path.stem

**Signature:**
```python
@property
def stem(self) -> str
```

**Description:**
The final path component without its suffix (file extension). For example, if the path is `"document.tar.gz"`, the stem is `"document.tar"`. If the path points to a directory or has no suffix, returns the entire final component.

**Return Type:**
`str` — The filename without its extension.

**Example:**
```python
from pathlib import Path

p = Path("/home/user/report.pdf")
print(p.stem)  # Output: report

p2 = Path("archive.tar.gz")
print(p2.stem)  # Output: archive.tar
```

---

### Path.suffix

**Signature:**
```python
@property
def suffix(self) -> str
```

**Description:**
The file extension of the final path component, including the leading dot. For example, `".txt"` or `".py"`. If the path has no extension or points to a directory, returns an empty string. Only returns the final extension for files with multiple dots (e.g., `".gz"` for `"file.tar.gz"`).

**Return Type:**
`str` — The file extension including the dot, or an empty string if there is no extension.

**Example:**
```python
from pathlib import Path

p = Path("/home/user/script.py")
print(p.suffix)  # Output: .py

p2 = Path("archive.tar.gz")
print(p2.suffix)  # Output: .gz

p3 = Path("README")
print(p3.suffix)  # Output: (empty string)
```

---

### Path.parent

**Signature:**
```python
@property
def parent(self) -> Path
```

**Description:**
The logical parent directory of the path. Returns a new `Path` object representing the directory containing the current path. For a path like `"/home/user/file.txt"`, the parent is `"/home/user"`. Accessing `.parent` repeatedly moves up the directory hierarchy.

**Return Type:**
`Path` — A new `Path` object representing the parent directory.

**Example:**
```python
from pathlib import Path

p = Path("/home/user/documents/report.pdf")
print(p.parent)  # Output: /home/user/documents
print(p.parent.parent)  # Output: /home/user

# Get parent of a directory
p2 = Path("/var/log/")
print(p2.parent)  # Output: /var
```
