IMPORTANT: Always write output files to `./output/` immediately using the Write tool.
Permissions are already granted — write the file directly as your first action.
Only write files inside `./output/`.
