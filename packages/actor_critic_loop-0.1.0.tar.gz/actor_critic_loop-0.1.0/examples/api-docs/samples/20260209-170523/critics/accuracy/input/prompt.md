<actor_task>
The original requirements given to the actor are in `{{ actor_prompt_file }}`.
Use these to verify the actor addressed all requirements.
</actor_task>

<actor_output>
The actor produced the following files in the output directory:
{% for file in actor_output_files %}
- `{{ file }}`
{% endfor %}
Review these files to evaluate the actor's work.
</actor_output>
{% if actor_output_text %}
<actor_commentary>
The actor said:
{{ actor_output_text }}
</actor_commentary>
{% endif %}

<review_instructions>
Verify EVERY technical claim in the actor's API documentation against the official Python docs.

For each of the 10 methods/properties documented:

1. **Signature** — Use WebSearch or WebFetch to check `docs.python.org/3/library/pathlib.html`. Compare the official signature against what the actor wrote.
2. **Parameters** — Verify every parameter name, type, and default value matches the official docs.
3. **Return type** — Confirm the documented return type is correct.
4. **Behavior** — Check that the description accurately reflects what the method/property does.

For any discrepancy, show:
- What the actor wrote (quote it)
- What the official docs say (cite the source)
- What needs to be corrected
</review_instructions>

<reminder>
- Ground your review in specific evidence: quote relevant sections of the actor's
  output before evaluating them.
- Verify the actor addressed all requirements from `{{ actor_prompt_file }}`.
- When using WebSearch or WebFetch to verify claims, cite your sources.
- Hard pass or fail only — no partial pass, conditional pass, or pass with reservations.
  If any criterion is not fully met, set `passed: false`.
- Your response MUST be valid JSON with `review`, `passed`, and `issues`.
</reminder>
