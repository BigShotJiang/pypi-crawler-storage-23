# pathlib.Path API Reference

Complete API reference for selected `pathlib.Path` methods and properties.

---

## Methods

### Path.exists()

**Signature:**
```python
Path.exists(*, follow_symlinks: bool = True) -> bool
```

**Description:**
Checks whether the path exists in the filesystem. Returns `True` if the path points to an existing file or directory, `False` otherwise.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `follow_symlinks` | `bool` | `True` | If `True`, follows symbolic links and checks if the target exists; if `False`, checks if the symbolic link itself exists |

**Return type:**
`bool` — `True` if the path exists, `False` otherwise

**Example:**
```python
from pathlib import Path

path = Path("example.txt")
if path.exists():
    print("File exists")
else:
    print("File does not exist")
```

---

### Path.mkdir()

**Signature:**
```python
Path.mkdir(mode: int = 0o777, parents: bool = False, exist_ok: bool = False) -> None
```

**Description:**
Creates a new directory at the path location. The method allows creating parent directories automatically and handling cases where the directory already exists.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mode` | `int` | `0o777` | The file mode and access flags for the new directory |
| `parents` | `bool` | `False` | If `True`, creates parent directories as needed; if `False`, raises `FileNotFoundError` if parent doesn't exist |
| `exist_ok` | `bool` | `False` | If `True`, does not raise an error if the directory already exists; if `False`, raises `FileExistsError` when directory exists |

**Return type:**
`None`

**Example:**
```python
from pathlib import Path

# Create a single directory
path = Path("new_folder")
path.mkdir()

# Create nested directories
nested_path = Path("parent/child/grandchild")
nested_path.mkdir(parents=True, exist_ok=True)
```

---

### Path.iterdir()

**Signature:**
```python
Path.iterdir() -> Generator[Path, None, None]
```

**Description:**
Iterates over the contents of a directory, yielding `Path` objects for each entry. The method does not recurse into subdirectories and does not return special entries `.` and `..`. The order of yielded entries is arbitrary.

**Parameters:**
None

**Return type:**
`Generator[Path, None, None]` — A generator yielding `Path` objects for each directory entry

**Example:**
```python
from pathlib import Path

directory = Path(".")
for item in directory.iterdir():
    print(f"Found: {item.name} ({'dir' if item.is_dir() else 'file'})")
```

---

### Path.glob()

**Signature:**
```python
Path.glob(pattern: str, *, case_sensitive: bool | None = None, recurse_symlinks: bool = False) -> Generator[Path, None, None]
```

**Description:**
Finds all files and directories matching the specified glob pattern. The pattern can include wildcards like `*` (matches any characters) and `**` (matches directories recursively). The method returns a generator of matching `Path` objects.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pattern` | `str` | (required) | Glob pattern to match files against (e.g., `"*.txt"`, `"**/*.py"`) |
| `case_sensitive` | `bool \| None` | `None` | Whether pattern matching is case-sensitive; `None` uses platform default (case-sensitive on Unix, case-insensitive on Windows) |
| `recurse_symlinks` | `bool` | `False` | If `True`, `**` pattern will follow symbolic links; if `False`, symbolic links are not followed during recursive matching |

**Return type:**
`Generator[Path, None, None]` — A generator yielding `Path` objects matching the pattern

**Example:**
```python
from pathlib import Path

# Find all .txt files in current directory
path = Path(".")
for txt_file in path.glob("*.txt"):
    print(f"Found text file: {txt_file}")

# Find all Python files recursively
for py_file in path.glob("**/*.py"):
    print(f"Found Python file: {py_file}")
```

---

### Path.read_text()

**Signature:**
```python
Path.read_text(encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> str
```

**Description:**
Reads the entire contents of the file as a text string. The file is opened in text mode, read completely, and then closed. This is a convenience method for simple file reading operations.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `encoding` | `str \| None` | `None` | The text encoding to use (e.g., `"utf-8"`, `"ascii"`); defaults to platform default |
| `errors` | `str \| None` | `None` | How to handle encoding errors (e.g., `"strict"`, `"ignore"`, `"replace"`) |
| `newline` | `str \| None` | `None` | Controls line ending handling; `None` uses universal newlines mode |

**Return type:**
`str` — The contents of the file as a string

**Example:**
```python
from pathlib import Path

path = Path("example.txt")
content = path.read_text(encoding="utf-8")
print(f"File contents: {content}")
```

---

### Path.write_text()

**Signature:**
```python
Path.write_text(data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int
```

**Description:**
Writes a text string to the file, creating the file if it doesn't exist or overwriting it if it does. The file is opened in text mode, written to, and then closed. This is a convenience method for simple file writing operations.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `str` | (required) | The text content to write to the file |
| `encoding` | `str \| None` | `None` | The text encoding to use; defaults to platform default |
| `errors` | `str \| None` | `None` | How to handle encoding errors |
| `newline` | `str \| None` | `None` | Controls line ending handling |

**Return type:**
`int` — The number of characters written

**Example:**
```python
from pathlib import Path

path = Path("output.txt")
chars_written = path.write_text("Hello, World!\n", encoding="utf-8")
print(f"Wrote {chars_written} characters")
```

---

### Path.resolve()

**Signature:**
```python
Path.resolve(strict: bool = False) -> Path
```

**Description:**
Converts the path to an absolute path, resolving any symbolic links and eliminating `..` (parent directory) and `.` (current directory) components. This produces a canonical absolute path.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `strict` | `bool` | `False` | If `True`, raises `FileNotFoundError` if the path doesn't exist; if `False`, the path is resolved as far as possible |

**Return type:**
`Path` — An absolute version of the path

**Example:**
```python
from pathlib import Path

relative_path = Path("../documents/file.txt")
absolute_path = relative_path.resolve()
print(f"Absolute path: {absolute_path}")
```

---

## Properties

### Path.stem

**Signature:**
```python
Path.stem -> str
```

**Description:**
Returns the filename without its extension (suffix). This is the final path component with the last extension removed. If the path has no extension, the entire filename is returned.

**Return type:**
`str` — The filename without its extension

**Example:**
```python
from pathlib import Path

path = Path("document.txt")
print(f"Stem: {path.stem}")  # Output: document

path2 = Path("archive.tar.gz")
print(f"Stem: {path2.stem}")  # Output: archive.tar
```

---

### Path.suffix

**Signature:**
```python
Path.suffix -> str
```

**Description:**
Returns the file extension of the final path component, including the leading dot. If the path has no extension, returns an empty string. Only the last extension is returned for files with multiple extensions.

**Return type:**
`str` — The file extension including the dot (e.g., `".txt"`), or empty string if no extension

**Example:**
```python
from pathlib import Path

path = Path("document.txt")
print(f"Suffix: {path.suffix}")  # Output: .txt

path2 = Path("archive.tar.gz")
print(f"Suffix: {path2.suffix}")  # Output: .gz

path3 = Path("README")
print(f"Suffix: {path3.suffix}")  # Output: (empty string)
```

---

### Path.parent

**Signature:**
```python
Path.parent -> Path
```

**Description:**
Returns the logical parent directory of the path. This is the path with the final component removed. For a path with only one component, returns the current directory (`.`). This property can be chained to access ancestor directories.

**Return type:**
`Path` — The parent directory path

**Example:**
```python
from pathlib import Path

path = Path("/home/user/documents/file.txt")
print(f"Parent: {path.parent}")  # Output: /home/user/documents
print(f"Grandparent: {path.parent.parent}")  # Output: /home/user
```

---

## See Also

- Official Python documentation: [pathlib — Object-oriented filesystem paths](https://docs.python.org/3/library/pathlib.html)
