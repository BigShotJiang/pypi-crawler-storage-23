# pathlib.Path API Reference

This document provides API reference documentation for selected Python `pathlib.Path` methods and properties.

---

## Methods

### `Path.exists()`

**Signature:**
```python
def exists(*, follow_symlinks: bool = True) -> bool
```

**Description:**

Checks whether the path exists in the filesystem. Returns `True` if the path points to an existing file or directory, `False` otherwise.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `follow_symlinks` | `bool` | `True` | If `True`, follows symbolic links and checks if the target exists. If `False`, checks if the symbolic link itself exists. |

**Return type:**

`bool` — `True` if the path exists, `False` otherwise.

**Example:**

```python
from pathlib import Path

# Check if a file exists
config_path = Path("config.json")
if config_path.exists():
    print("Config file found")
else:
    print("Config file not found")

# Check if a symbolic link exists without following it
link = Path("shortcut.txt")
if link.exists(follow_symlinks=False):
    print("Symbolic link exists")
```

---

### `Path.mkdir()`

**Signature:**
```python
def mkdir(mode: int = 0o777, parents: bool = False, exist_ok: bool = False) -> None
```

**Description:**

Creates a new directory at the path location. By default, fails if the directory already exists or if parent directories don't exist.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mode` | `int` | `0o777` | The file mode (permissions) for the directory. The actual mode will be affected by the current umask. |
| `parents` | `bool` | `False` | If `True`, creates any missing parent directories. If `False`, raises `FileNotFoundError` if parents don't exist. |
| `exist_ok` | `bool` | `False` | If `True`, does not raise an exception if the directory already exists. If `False`, raises `FileExistsError` if the directory exists. |

**Return type:**

`None` — This method does not return a value.

**Example:**

```python
from pathlib import Path

# Create a single directory
new_dir = Path("output")
new_dir.mkdir(exist_ok=True)

# Create nested directories
nested_dir = Path("data/raw/2024")
nested_dir.mkdir(parents=True, exist_ok=True)

# Create with specific permissions
secure_dir = Path("secrets")
secure_dir.mkdir(mode=0o700)  # Owner read/write/execute only
```

---

### `Path.iterdir()`

**Signature:**
```python
def iterdir() -> Iterator[Path]
```

**Description:**

Iterates over the contents of a directory, yielding `Path` objects for each entry. The order of entries is arbitrary. Does not include special entries `.` and `..`. Raises `NotADirectoryError` if the path is not a directory.

**Parameters:**

This method takes no parameters.

**Return type:**

`Iterator[Path]` — An iterator that yields `Path` objects for each entry in the directory.

**Example:**

```python
from pathlib import Path

# List all files and directories
project_dir = Path(".")
for item in project_dir.iterdir():
    print(f"Found: {item.name}")

# Filter for Python files
src_dir = Path("src")
python_files = [f for f in src_dir.iterdir() if f.suffix == ".py"]
print(f"Python files: {python_files}")

# Count directory entries
data_dir = Path("data")
entry_count = sum(1 for _ in data_dir.iterdir())
print(f"Directory contains {entry_count} entries")
```

---

### `Path.glob(pattern)`

**Signature:**
```python
def glob(pattern: str, *, case_sensitive: bool | None = None, recurse_symlinks: bool = False) -> Iterator[Path]
```

**Description:**

Finds all files matching a glob pattern relative to this path. The pattern uses shell-style wildcards: `*` matches any characters within a single path component, `**` matches zero or more directories recursively, and `?` matches a single character. Returns an iterator of matching `Path` objects.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `pattern` | `str` | *(required)* | The glob pattern to match files against. Supports wildcards: `*` (any characters), `**` (recursive directories), `?` (single character). |
| `case_sensitive` | `bool \| None` | `None` | If `True`, performs case-sensitive matching. If `False`, performs case-insensitive matching. If `None`, uses platform default (case-sensitive on Unix, case-insensitive on Windows). |
| `recurse_symlinks` | `bool` | `False` | If `True`, follows symbolic links when `**` is used in the pattern. If `False`, does not follow symbolic links. |

**Return type:**

`Iterator[Path]` — An iterator that yields `Path` objects matching the pattern.

**Example:**

```python
from pathlib import Path

# Find all text files in current directory
current = Path(".")
for txt_file in current.glob("*.txt"):
    print(f"Text file: {txt_file}")

# Find all Python files recursively
project = Path("src")
all_python = list(project.glob("**/*.py"))
print(f"Found {len(all_python)} Python files")

# Case-insensitive search
data_dir = Path("data")
readme_files = list(data_dir.glob("readme.*", case_sensitive=False))
for readme in readme_files:
    print(f"README file: {readme.name}")
```

---

### `Path.read_text()`

**Signature:**
```python
def read_text(encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> str
```

**Description:**

Reads the entire file contents and returns it as a string. The file is opened in text mode and automatically closed after reading. If encoding is not specified, the platform default encoding is used.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `encoding` | `str \| None` | `None` | The character encoding to use when reading the file. If `None`, uses the platform default encoding (typically UTF-8 on modern systems). |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values: `'strict'` (raise exception), `'ignore'` (skip invalid characters), `'replace'` (replace with replacement character). If `None`, uses `'strict'`. |
| `newline` | `str \| None` | `None` | Controls how line endings are interpreted. If `None`, universal newlines mode is enabled. Pass `''` to disable newline translation. |

**Return type:**

`str` — The complete contents of the file as a string.

**Example:**

```python
from pathlib import Path

# Read a text file with default encoding
readme = Path("README.md")
content = readme.read_text()
print(content)

# Read with explicit encoding
config = Path("config.txt")
text = config.read_text(encoding="utf-8")

# Handle potential encoding errors gracefully
log_file = Path("app.log")
log_content = log_file.read_text(encoding="utf-8", errors="replace")
print(f"Log has {len(log_content)} characters")
```

---

### `Path.write_text(data)`

**Signature:**
```python
def write_text(data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int
```

**Description:**

Writes a string to the file, creating the file if it doesn't exist or overwriting it if it does. The file is opened in text mode and automatically closed after writing. Returns the number of characters written.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `data` | `str` | *(required)* | The string content to write to the file. |
| `encoding` | `str \| None` | `None` | The character encoding to use when writing the file. If `None`, uses the platform default encoding (typically UTF-8 on modern systems). |
| `errors` | `str \| None` | `None` | How to handle encoding errors. Common values: `'strict'` (raise exception), `'ignore'` (skip invalid characters), `'replace'` (replace with replacement character). If `None`, uses `'strict'`. |
| `newline` | `str \| None` | `None` | Controls line ending handling. If `None`, uses platform default (`\n` on Unix, `\r\n` on Windows). |

**Return type:**

`int` — The number of characters written to the file.

**Example:**

```python
from pathlib import Path

# Write simple text to a file
output = Path("result.txt")
output.write_text("Hello, World!")

# Write with explicit encoding
log = Path("app.log")
bytes_written = log.write_text("Application started\n", encoding="utf-8")
print(f"Wrote {bytes_written} characters")

# Write multi-line content
report = Path("report.txt")
content = """Report Summary
==============
Total: 42
Status: Complete
"""
report.write_text(content)
```

---

### `Path.resolve()`

**Signature:**
```python
def resolve(strict: bool = False) -> Path
```

**Description:**

Makes the path absolute, resolving any symbolic links and normalizing the path (removing `.` and `..` components). Returns a new `Path` object representing the absolute path.

**Parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `strict` | `bool` | `False` | If `True`, raises `OSError` if the path doesn't exist. If `False`, resolves the path as far as possible without checking existence. |

**Return type:**

`Path` — A new `Path` object representing the absolute, normalized path.

**Example:**

```python
from pathlib import Path

# Resolve relative path to absolute
relative = Path("../data/input.txt")
absolute = relative.resolve()
print(f"Absolute path: {absolute}")

# Resolve current working directory
cwd = Path(".").resolve()
print(f"Current directory: {cwd}")

# Resolve symbolic link to actual file
link = Path("shortcut.txt")
if link.exists():
    actual_file = link.resolve()
    print(f"Link points to: {actual_file}")

# Strict mode - ensure path exists
config = Path("config.json")
try:
    absolute_config = config.resolve(strict=True)
    print(f"Config found at: {absolute_config}")
except OSError:
    print("Config file does not exist")
```

---

## Properties

### `Path.stem`

**Signature:**
```python
@property
def stem() -> str
```

**Description:**

Returns the final path component without its file extension. For a path like `document.txt`, this returns `"document"`. If the filename has multiple extensions (e.g., `archive.tar.gz`), only the last extension is removed, returning `"archive.tar"`.

**Return type:**

`str` — The filename without the extension.

**Example:**

```python
from pathlib import Path

# Get filename without extension
file1 = Path("report.pdf")
print(file1.stem)  # Output: "report"

file2 = Path("/home/user/photo.jpg")
print(file2.stem)  # Output: "photo"

# Multiple extensions
archive = Path("backup.tar.gz")
print(archive.stem)  # Output: "backup.tar"

# No extension
readme = Path("README")
print(readme.stem)  # Output: "README"
```

---

### `Path.suffix`

**Signature:**
```python
@property
def suffix() -> str
```

**Description:**

Returns the file extension including the leading dot. For a path like `document.txt`, this returns `".txt"`. If the path has no extension, returns an empty string. For files with multiple extensions (e.g., `archive.tar.gz`), returns only the last extension (`".gz"`).

**Return type:**

`str` — The file extension including the dot, or empty string if no extension.

**Example:**

```python
from pathlib import Path

# Get file extension
file1 = Path("report.pdf")
print(file1.suffix)  # Output: ".pdf"

file2 = Path("/data/image.png")
print(file2.suffix)  # Output: ".png"

# Multiple extensions (only last one returned)
archive = Path("backup.tar.gz")
print(archive.suffix)  # Output: ".gz"

# No extension
readme = Path("README")
print(readme.suffix)  # Output: ""

# Check file type
script = Path("run.py")
if script.suffix == ".py":
    print("This is a Python file")
```

---

### `Path.parent`

**Signature:**
```python
@property
def parent() -> Path
```

**Description:**

Returns the parent directory of the path as a new `Path` object. For a path like `/home/user/document.txt`, this returns `/home/user`. The parent of a root directory (e.g., `/`) is the root itself. Successive calls to `.parent` can traverse up the directory tree.

**Return type:**

`Path` — A new `Path` object representing the parent directory.

**Example:**

```python
from pathlib import Path

# Get parent directory
file = Path("/home/user/documents/report.txt")
print(file.parent)  # Output: /home/user/documents

# Navigate up the directory tree
print(file.parent.parent)  # Output: /home/user
print(file.parent.parent.parent)  # Output: /home

# Relative paths
relative = Path("src/utils/helpers.py")
print(relative.parent)  # Output: src/utils

# Create file in parent directory
current_file = Path("data/output.txt")
sibling = current_file.parent / "input.txt"
print(sibling)  # Output: data/input.txt
```
