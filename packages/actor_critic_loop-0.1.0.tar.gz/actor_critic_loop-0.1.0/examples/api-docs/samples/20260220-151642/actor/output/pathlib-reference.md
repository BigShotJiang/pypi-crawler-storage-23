# pathlib.Path API Reference

Selected methods and properties from Python's `pathlib.Path` class.

---

## Methods

### `Path.exists()`

**Signature**

```python
Path.exists(*, follow_symlinks: bool = True) -> bool
```

**Description**

Returns `True` if the path points to an existing file or directory, `False` otherwise. Broken symbolic links return `False`. When `follow_symlinks` is `False`, returns `True` if the path itself exists (even if it is a broken symlink).

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `follow_symlinks` | `bool` | `True` | If `False`, checks the symlink itself rather than its target. |

**Return type**

`bool`

**Example**

```python
from pathlib import Path

p = Path("/tmp/myfile.txt")
if p.exists():
    print("File found")
else:
    print("File not found")
```

---

### `Path.mkdir()`

**Signature**

```python
Path.mkdir(mode: int = 0o777, parents: bool = False, exist_ok: bool = False) -> None
```

**Description**

Creates the directory at this path. Raises `FileExistsError` if the directory already exists and `exist_ok` is `False`. Raises `FileNotFoundError` if a parent directory is missing and `parents` is `False`.

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `mode` | `int` | `0o777` | Permission bits for the new directory (subject to the process umask). |
| `parents` | `bool` | `False` | If `True`, missing parent directories are created as needed. |
| `exist_ok` | `bool` | `False` | If `True`, no error is raised when the directory already exists. |

**Return type**

`None`

**Example**

```python
from pathlib import Path

p = Path("/tmp/a/b/c")
p.mkdir(parents=True, exist_ok=True)
print(p.exists())  # True
```

---

### `Path.iterdir()`

**Signature**

```python
Path.iterdir() -> Iterator[Path]
```

**Description**

Yields `Path` objects for each item (file or directory) directly inside this directory. Does not recurse into subdirectories. The path must point to an existing directory.

**Parameters**

_None._

**Return type**

`Iterator[Path]`

**Example**

```python
from pathlib import Path

p = Path("/tmp")
for item in p.iterdir():
    print(item.name)
```

---

### `Path.glob(pattern)`

**Signature**

```python
Path.glob(pattern: str, *, case_sensitive: bool | None = None, recurse_symlinks: bool = False) -> Iterator[Path]
```

**Description**

Yields all matching `Path` objects within the directory tree rooted at this path, according to the given glob pattern. Use `**` to match any number of directory levels recursively.

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `pattern` | `str` | _required_ | Glob pattern to match against, e.g. `"*.txt"` or `"**/*.py"`. |
| `case_sensitive` | `bool \| None` | `None` | If `True`, match case-sensitively; if `False`, case-insensitively; if `None`, use the OS default. |
| `recurse_symlinks` | `bool` | `False` | If `True`, follow symlinks when expanding `**` patterns. |

**Return type**

`Iterator[Path]`

**Example**

```python
from pathlib import Path

p = Path("/tmp/project")
for txt_file in p.glob("*.txt"):
    print(txt_file)
```

---

### `Path.read_text()`

**Signature**

```python
Path.read_text(encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> str
```

**Description**

Opens the file, reads its contents as a string, and closes the file. If `encoding` is not specified, the platform default encoding is used (typically UTF-8 on modern systems).

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `encoding` | `str \| None` | `None` | Text encoding to use when decoding the file (e.g. `"utf-8"`). Defaults to the platform locale encoding. |
| `errors` | `str \| None` | `None` | Error-handling mode for the codec (e.g. `"strict"`, `"ignore"`, `"replace"`). |
| `newline` | `str \| None` | `None` | Controls universal newlines mode, passed to the underlying `open()` call. |

**Return type**

`str`

**Example**

```python
from pathlib import Path

p = Path("/tmp/hello.txt")
p.write_text("Hello, world!", encoding="utf-8")
content = p.read_text(encoding="utf-8")
print(content)  # Hello, world!
```

---

### `Path.write_text(data)`

**Signature**

```python
Path.write_text(data: str, encoding: str | None = None, errors: str | None = None, newline: str | None = None) -> int
```

**Description**

Opens the file, writes the given string, and closes the file. Creates the file if it does not exist, or truncates and overwrites it if it does.

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `data` | `str` | _required_ | The string content to write to the file. |
| `encoding` | `str \| None` | `None` | Text encoding to use when encoding the string. Defaults to the platform locale encoding. |
| `errors` | `str \| None` | `None` | Error-handling mode for the codec (e.g. `"strict"`, `"ignore"`, `"replace"`). |
| `newline` | `str \| None` | `None` | Controls newline translation, passed to the underlying `open()` call. |

**Return type**

`int` — the number of characters written.

**Example**

```python
from pathlib import Path

p = Path("/tmp/output.txt")
chars_written = p.write_text("Hello, pathlib!", encoding="utf-8")
print(chars_written)  # 15
```

---

### `Path.resolve()`

**Signature**

```python
Path.resolve(strict: bool = False) -> Path
```

**Description**

Returns a new `Path` object with the path made absolute, resolving any symlinks and normalizing `..` components. If `strict` is `True`, the path must exist or `OSError` is raised.

**Parameters**

| Name | Type | Default | Description |
|------|------|---------|-------------|
| `strict` | `bool` | `False` | If `True`, raises `OSError` if any component of the resolved path does not exist. |

**Return type**

`Path`

**Example**

```python
from pathlib import Path

p = Path("../mydir/./file.txt")
absolute = p.resolve()
print(absolute)  # e.g. /home/user/mydir/file.txt
```

---

## Properties

### `Path.stem`

**Signature**

```python
Path.stem: str
```

**Description**

The final component of the path without its suffix (file extension). If the filename has no suffix, `stem` is identical to `name`.

**Return type**

`str`

**Example**

```python
from pathlib import Path

p = Path("/tmp/archive.tar.gz")
print(p.stem)  # archive.tar

p2 = Path("/tmp/README")
print(p2.stem)  # README
```

---

### `Path.suffix`

**Signature**

```python
Path.suffix: str
```

**Description**

The file extension of the final component of the path, including the leading dot. Returns an empty string if there is no suffix.

**Return type**

`str`

**Example**

```python
from pathlib import Path

p = Path("/tmp/report.pdf")
print(p.suffix)  # .pdf

p2 = Path("/tmp/Makefile")
print(p2.suffix)  # (empty string)
```

---

### `Path.parent`

**Signature**

```python
Path.parent: Path
```

**Description**

The logical parent directory of the path. For the root path or a single-component path with no parent, `parent` returns the path itself.

**Return type**

`Path`

**Example**

```python
from pathlib import Path

p = Path("/tmp/subdir/file.txt")
print(p.parent)        # /tmp/subdir
print(p.parent.parent) # /tmp
```
