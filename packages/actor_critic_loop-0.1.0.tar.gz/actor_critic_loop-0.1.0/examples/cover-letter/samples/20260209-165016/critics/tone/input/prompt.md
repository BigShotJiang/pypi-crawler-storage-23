<actor_task>
The original requirements given to the actor are in `{{ actor_prompt_file }}`.
Use these to verify the actor addressed all requirements.
</actor_task>

<actor_output>
The actor produced the following files in the output directory:
{% for file in actor_output_files %}
- `{{ file }}`
{% endfor %}
Review these files to evaluate the actor's work.
</actor_output>
{% if actor_output_text %}
<actor_commentary>
The actor said:
{{ actor_output_text }}
</actor_commentary>
{% endif %}

<review_instructions>
Evaluate the writing quality and professionalism of the cover letter:

1. **Opening** — No boilerplate phrases ("I am writing to express my interest in..." or "I am excited to apply for..."). The opening should be distinctive and engaging.
2. **Voice** — Active voice predominates. Flag any passive constructions.
3. **Tone** — Confident without arrogance. The candidate should sound assured but not boastful.
4. **Flow** — Natural transitions between paragraphs. The letter should read as a cohesive narrative, not a list of bullet points in prose form.
5. **Word count** — Must be 250-400 words. Count them.
6. **Grammar and spelling** — No errors.

Quote specific passages that work well or need improvement.
</review_instructions>

<reminder>
- Ground your review in specific evidence: quote relevant sections of the actor's
  output before evaluating them.
- Verify the actor addressed all requirements from `{{ actor_prompt_file }}`.
- Hard pass or fail only — no partial pass, conditional pass, or pass with reservations.
  If any criterion is not fully met, set `passed: false`.
- Your response MUST be valid JSON with `review`, `passed`, and `issues`.
</reminder>
