<actor_task>
The original requirements given to the actor are in `{{ actor_prompt_file }}`.
Use these to verify the actor addressed all requirements.
</actor_task>

<actor_output>
The actor produced the following files in the output directory:
{% for file in actor_output_files %}
- `{{ file }}`
{% endfor %}
Review these files to evaluate the actor's work.
</actor_output>
{% if actor_output_text %}
<actor_commentary>
The actor said:
{{ actor_output_text }}
</actor_commentary>
{% endif %}

<review_instructions>
Cross-reference the cover letter against the job posting requirements and resume.
For each criterion, check if the letter addresses it with specific evidence:

1. **Requirements coverage** — Every key requirement from the job posting is addressed with evidence from the resume
2. **Irrelevant experience** — Retail and sales experience from the resume is NOT mentioned in the letter
3. **Specific accomplishments** — The letter cites specific accomplishments from the resume (numbers, metrics, outcomes), not just generic claims
4. **Company and role** — The company name (FinFlow Technologies) and role (Senior Software Engineer, Payments Platform) are mentioned correctly
5. **Keywords** — Technical keywords from the posting (Python, asyncio, distributed systems, PostgreSQL, event-driven, mentoring) appear naturally in the letter
</review_instructions>

<reminder>
- Ground your review in specific evidence: quote relevant sections of the actor's
  output before evaluating them.
- Verify the actor addressed all requirements from `{{ actor_prompt_file }}`.
- Hard pass or fail only — no partial pass, conditional pass, or pass with reservations.
  If any criterion is not fully met, set `passed: false`.
- Your response MUST be valid JSON with `review`, `passed`, and `issues`.
</reminder>
