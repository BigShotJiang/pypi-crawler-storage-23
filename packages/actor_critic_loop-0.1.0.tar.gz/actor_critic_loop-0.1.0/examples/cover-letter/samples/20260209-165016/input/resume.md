# Alex Chen

**Email:** alex.chen@email.com
**Location:** Portland, OR
**GitHub:** github.com/alexchen

## Summary

Software engineer with 7 years of experience building scalable backend systems. Passionate about clean code, distributed systems, and mentoring.

## Experience

### Senior Backend Engineer — CloudScale Inc. (2022–Present)
- Designed and built Python microservices processing 8K requests/second
- Led migration from monolith to event-driven architecture using RabbitMQ
- Mentored 3 junior engineers; established code review practices
- Implemented async payment webhook processing with 99.95% uptime
- Technologies: Python (asyncio, FastAPI), PostgreSQL, RabbitMQ, Docker, Kubernetes

### Software Engineer — DataPipe Analytics (2019–2022)
- Built ETL pipelines processing 50M+ records daily
- Designed PostgreSQL schema optimizations reducing query time by 60%
- Contributed to open-source Python testing library (500+ GitHub stars)
- Technologies: Python, PostgreSQL, Apache Airflow, AWS

### Junior Developer — RetailMax (2017–2019)
- Built inventory management features for e-commerce platform
- Maintained legacy PHP codebase serving 100K daily users
- Technologies: PHP, MySQL, jQuery, Bootstrap

### Sales Associate — TechMart Electronics (2015–2017)
- Provided customer service for consumer electronics
- Consistently exceeded monthly sales targets by 15%
- Trained new team members on product knowledge

## Education

**B.S. Computer Science** — Oregon State University (2017)

## Skills

Python, PostgreSQL, Docker, Kubernetes, RabbitMQ, FastAPI, asyncio, Git, Terraform, AWS, Linux
