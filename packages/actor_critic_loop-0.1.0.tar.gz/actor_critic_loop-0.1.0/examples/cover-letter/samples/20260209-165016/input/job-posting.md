# Senior Software Engineer — Payments Platform

**Company:** FinFlow Technologies
**Location:** Remote (US)
**Team:** Payments Infrastructure

## About Us

FinFlow builds the payment infrastructure that powers next-generation fintech apps. Our platform processes $2B+ in transactions monthly, serving 200+ enterprise clients.

## The Role

We're looking for a Senior Software Engineer to join our Payments Infrastructure team. You'll design and build the core systems that move money — reliably, securely, and at scale.

## What You'll Do

- Design and implement distributed payment processing pipelines
- Build and maintain Python microservices handling 10K+ TPS
- Lead architectural decisions for our event-driven platform (Kafka, PostgreSQL)
- Mentor junior engineers through code reviews and pair programming
- Collaborate with product and compliance teams on PCI-DSS requirements
- Own service reliability: on-call rotation, SLOs, incident response

## Requirements

- 5+ years of professional software engineering experience
- Strong Python proficiency (asyncio, type hints, testing)
- Experience with distributed systems (message queues, eventual consistency)
- Familiarity with payment processing or financial systems
- Track record of mentoring and technical leadership
- Experience with PostgreSQL and event-driven architectures

## Nice to Have

- Experience with Kafka or similar streaming platforms
- Knowledge of PCI-DSS compliance requirements
- Contributions to open-source projects
- Experience with infrastructure-as-code (Terraform, Kubernetes)
