<actor_task>
The original requirements given to the actor are in `{{ actor_prompt_file }}`.
Use these to verify the actor addressed all requirements.
</actor_task>

<actor_output>
The actor produced the following files in the output directory:
{% for file in actor_output_files %}
- `{{ file }}`
{% endfor %}
Review these files to evaluate the actor's work.
</actor_output>
{% if actor_output_text %}
<actor_commentary>
The actor said:
{{ actor_output_text }}
</actor_commentary>
{% endif %}

<review_instructions>
Evaluate the blog post against these criteria:

1. **Title** — Compelling and draws readers in?
2. **Introduction** — Strong hook that engages?
3. **Statistics** — 2-3 verified stats with source links?
4. **Practical Value** — Actionable tips or examples?
5. **Conclusion** — Clear with call to action?
</review_instructions>

<reminder>
- Ground your review in specific evidence: quote relevant sections of the actor's
  output before evaluating them.
- Verify the actor addressed all requirements from `{{ actor_prompt_file }}`.
- When using WebSearch or WebFetch to verify claims, cite your sources.
- Hard pass or fail only — no partial pass, conditional pass, or pass with reservations.
  If any criterion is not fully met, set `passed: false`.
- Your response MUST be valid JSON with `review`, `passed`, and `issues`.
</reminder>
