Write a blog post about remote work productivity based on notes.md.

Target audience: Knowledge workers new to or struggling with remote work.
Tone: Friendly and practical.
Length: 800-1000 words.

Requirements:
- You MUST use WebSearch to find 2-3 recent statistics (2025-2026) about remote work
- You MUST use WebFetch to verify the source articles
- Cite all sources with links

Write the output to ./output/blog-post.md.

Quality criteria:
- Compelling title that draws readers in
- Strong introduction with a hook
- Clear structure with logical headings
- 2-3 verified statistics with source links
- Practical examples or actionable tips
- Smooth transitions between sections
- Clear conclusion with call to action
- Word count between 800-1000 words
