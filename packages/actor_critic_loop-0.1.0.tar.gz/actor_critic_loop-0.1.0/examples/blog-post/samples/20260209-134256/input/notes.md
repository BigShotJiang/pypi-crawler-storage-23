# Notes: Remote Work Productivity

- WFH becoming permanent for many companies
- Challenges: distractions, isolation, work-life boundaries
- Tips that worked for me:
  - dedicated workspace (even small corner counts)
  - consistent schedule, "commute" ritual (walk around block)
  - async communication > meetings
  - take real breaks, go outside
  - separate work/personal devices or profiles
- Tools: Slack huddles for quick chats, Loom for async video
- Mental health: schedule social time, don't skip lunch
- Managers: trust output not hours, regular 1:1s
- Stats: 77% of remote workers report higher productivity (cite: Owl Labs 2023)
- But burnout risk is real - need boundaries
