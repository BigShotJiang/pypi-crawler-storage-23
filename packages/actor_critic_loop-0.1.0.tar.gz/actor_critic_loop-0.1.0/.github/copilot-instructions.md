# Copilot Code Review Instructions

## Project Context

This is a **spike** (learning experiment) exploring the actor-critic pattern for AI output refinement. The tool invokes Claude Code CLI as subprocesses - actors generate output, critics review it.

## Architecture

- **Actors** (`src/actor_critic/actors/`): Generate output via Claude Code subprocess
- **Critics** (`src/actor_critic/critics/`): Review actor output, return structured feedback
- **Orchestrators** (future): Coordinate actor-critic loops
- **Shared invocation** (`src/actor_critic/claude/`): Common subprocess handling

## Review Focus

### Subprocess Handling
- All Claude Code invocations MUST use `claude.invoke()` from `src/actor_critic/claude/invoke.py`
- Direct `subprocess.run` or `subprocess.Popen` calls outside `claude/invoke.py` are errors
- `claude.invoke()` always uses `subprocess.Popen` with streaming NDJSON mode (`--output-format stream-json --verbose`)
- Logging verbosity is controlled at CLI level via `_setup_logging()`, not via subprocess flags

### Path Handling
- `--add-dir` arguments MUST be absolute paths (resolved via `Path.resolve()`)
- Use `pathlib.Path` over string paths throughout

### Function Signatures
- Actors: `run(prompt, cwd, add_dirs, thinking_tokens) -> ActorOutput`
- Critics: `run(prompt, cwd, critic_name, add_dirs, thinking_tokens) -> CriticFeedback`
- Stop conditions: `should_stop(round, feedback, config) -> bool`

### Data Types
- `ActorOutput`: must have `text`, optional `artifacts` and `reasoning`
- `CriticFeedback`: `critic_name` is set by Python code, NOT from Claude's JSON response
- `CRITIC_FEEDBACK_SCHEMA` excludes `critic_name` intentionally

### Testing
- Tests MUST ship with the code they cover
- `uv run pytest --cov` must pass
- System tests use stub `claude` scripts on PATH that output NDJSON
- Unit tests mock `invoke()` from `actor_critic.claude`

## Conventions

- Follow conventional commits: `feat:`, `fix:`, `refactor:`, `test:`, `docs:`
- No error handling for non-zero claude exits until Phase 6
- Extended thinking is on by default; control via `MAX_THINKING_TOKENS` env var

## Do Not Flag

- Missing docstrings on private helper functions (`_prefixed`)
- Type annotations in test files (optional)
