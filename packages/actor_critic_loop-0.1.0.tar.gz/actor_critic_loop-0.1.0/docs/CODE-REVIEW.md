# Comprehensive Code Review

**Date:** 2026-02-17
**Scope:** All source and test files in the actor-critic codebase
**Reviewers:** Architecture, Code Quality, Test Quality, Security & Robustness (4 parallel agents)

---

## Executive Summary

The codebase is **well-structured for a spike project**. Test coverage is 99% (53 of 3,855 lines uncovered), the dependency DAG is enforced by import-linter contracts, subprocess calls avoid `shell=True`, and YAML parsing uses `safe_load` throughout. The architecture cleanly separates actors, critics, orchestrators, and the Claude subprocess layer.

The review identified **42 findings** across four domains. The highest-impact items are: the orchestrator god module (772 lines mixing infrastructure and domain logic), a functional bug where multi-critic implementations are silently ignored, and a missing subprocess timeout that can hang the tool indefinitely.

**Stats:** 24 source files, 25 test files, 476 tests (471 passing, 5 environment-sensitive failures)

---

## Consolidated Findings

Findings are deduplicated across all four reviews and organized by severity. Each finding includes the source review domain(s) in brackets.

### Critical / High

#### 1. Sequential orchestrator is a god module (772 lines, ~30 functions)
**File:** `orchestrators/sequential.py` | **Domain:** [Architecture, Quality]

The largest module owns prompt building, directory management, feedback serialization, history tracking, progress events, and the main loop. New orchestrator implementations would need to duplicate ~500 lines of utility code.

Three functions (`_run_critic_phase`, `_execute_round`, `_run_all_critics`) each take 13-14 parameters, creating high coupling. The `run()` function initializes many mutable lists passed by reference throughout.

**Recommendation:**
- Extract prompt building, output/directory management, and critic feedback I/O into shared modules (`prompts.py`, `workspace_io.py`)
- Introduce a `LoopState` dataclass to bundle mutable round-level state and reduce parameter threading
- The orchestrator should only own loop control flow

---

#### 2. CLI hardcodes `config.critics[0].impl` for all critics
**File:** `cli.py:151` | **Domain:** [Architecture]

```python
"critic": resolve(config.critics[0].impl),
```

`_resolve_implementations` resolves only the first critic's implementation and passes it as the sole `critic_fn` to the orchestrator. Multi-critic configs with different `impl` values silently ignore all but the first. The config schema supports per-critic implementations, creating a broken contract.

**Recommendation:** Resolve each critic's implementation separately and pass a mapping to the orchestrator, or document the single-impl limitation.

---

#### 3. Subprocess `Popen` without timeout
**File:** `claude/invoke.py:129-139` | **Domain:** [Security]

`invoke()` uses `subprocess.Popen` with `process.wait()` and no timeout. A hung `claude` CLI blocks the tool permanently. The `while True` loop in `sequential.py:711` compounds this.

**Recommendation:** Add `process.wait(timeout=timeout_seconds)` with a configurable default. Consider `threading.Timer` as a safety net for the stream-reading loop.

---

#### 4. Resolver uses string heuristic for entry point detection
**File:** `resolver.py:35` | **Domain:** [Architecture, Quality]

```python
func_name = "should_stop" if "stop_condition" in impl_path else "run"
```

A module named `actors/stop_condition_aware.py` would silently resolve to `should_stop` instead of `run`.

**Recommendation:** Add an explicit `entry_point` config field, or accept the function name as a parameter to `resolve()`.

---

#### 5. Dynamic import accepts arbitrary module paths
**File:** `resolver.py:28` | **Domain:** [Security]

`importlib.import_module(impl_path)` runs on values from user-controlled YAML with no allowlist. A crafted config can import and execute any Python module on the system.

**Recommendation:** Validate that `impl_path` starts with an allowed prefix (e.g., `actor_critic.`) or log a warning for out-of-namespace imports.

---

#### 6. Five failing tests in CI
**File:** `tests/system/test_examples.py` | **Domain:** [Tests]

All 5 parameterized `test_claude_can_read_settings` instances fail inside Claude Code sessions due to the `CLAUDECODE` env var blocking nested sessions.

**Recommendation:** Scrub `CLAUDECODE` from the subprocess environment or add `@pytest.mark.skipif("CLAUDECODE" in os.environ, ...)`.

---

### Medium

#### 7. Jinja2 template injection via actor output
**File:** `orchestrators/sequential.py:179-198` | **Domain:** [Security]

Actor output (raw Claude stdout) is passed as a Jinja2 template variable to critic prompt rendering. If the output contains `{{ }}` or `{% %}` syntax, it gets evaluated. Jinja2's default sandbox doesn't restrict attribute access, enabling `{{ config.__class__.__mro__ }}` style attacks.

**Recommendation:** Use `jinja2.SandboxedEnvironment` or escape actor output before template rendering.

---

#### 8. Unbounded snapshot disk growth
**File:** `orchestrators/sequential.py:412-422` | **Domain:** [Security]

`_snapshot_actor_output()` copies the entire actor output directory every round with no size limit. High `max_rounds` with large actor output can exhaust disk.

**Recommendation:** Add a configurable snapshot size limit or warn when cumulative size exceeds a threshold.

---

#### 9. History/snapshot feature has zero test coverage
**File:** `orchestrators/sequential.py` (~20 lines) | **Domain:** [Tests]

The `history_critics` parameter, `_snapshot_actor_output`, history accumulation, and history-aware critic calls are completely untested. This is the largest coverage gap in the codebase.

**Recommendation:** Add unit tests for snapshot creation, history passing to critics, and cleanup.

---

#### 10. YAML config template rendered without escaping
**File:** `scaffold_templates/actor-critic.yaml.j2` | **Domain:** [Security]

User-provided values (`critic_name`, `actor_impl`, etc.) are rendered directly into YAML without escaping. Special characters can corrupt the config or inject YAML structure.

**Recommendation:** Validate names against `^[a-z][a-z0-9_-]*$` before template rendering.

---

#### 11. `shutil.copytree` follows symlinks in scaffold
**File:** `scaffold.py:227` | **Domain:** [Security]

Template directory copy follows symlinks by default. A malicious template could contain symlinks to sensitive files.

**Recommendation:** Pass `symlinks=True` to `shutil.copytree()` to preserve rather than follow symlinks.

---

#### 12. Full prompt logged at INFO level
**File:** `claude/invoke.py:126` | **Domain:** [Security]

The complete `cmd` list including prompt text is logged at INFO. Prompts can contain workspace file contents.

**Recommendation:** Log prompt length at INFO, full command at DEBUG only.

---

#### 13. `StopConditionConfig.config` typed too restrictively
**Files:** `config.py:49`, all stop condition modules | **Domain:** [Quality]

Typed as `dict[str, int]` but `graduated.py` uses optional keys. The annotation constrains extension.

**Recommendation:** Change to `dict[str, Any]` to match actual usage.

---

#### 14. `round` parameter shadows Python built-in
**Files:** All 5 stop condition modules | **Domain:** [Quality]

All `should_stop` functions use `round` as a parameter name.

**Recommendation:** Rename to `round_num` for consistency with `RoundSummary.round_num`.

---

### Low

#### 15. Duplicated `_resolve_add_dirs` between actor and critic
**Files:** `actors/basic.py:53-62`, `critics/basic.py:13-22` | **Domain:** [Architecture, Quality]

Identical function copy-pasted. Extract to `actor_critic/utils.py` or `claude/invoke.py`.

---

#### 16. Duplicated prompt preview logging
**Files:** `actors/basic.py:65-70`, `critics/basic.py:68-70` | **Domain:** [Quality]

Same truncate-to-200-chars + newline-escaping pattern. Extract shared `_log_prompt_preview()` helper.

---

#### 17. `_build_row_values` and `_build_colored_row_values` are near-duplicates
**File:** `cli.py:224-265` | **Domain:** [Quality]

~80% identical logic. Unify with a `colored: bool` parameter or compute widths from fixed strings.

---

#### 18. Inconsistent directory filtering patterns
**Files:** `actors/basic.py`, `critics/basic.py`, `orchestrators/sequential.py:258-260` | **Domain:** [Quality]

Two different patterns for the same concern: `_resolve_add_dirs(list)` vs `_collect_dirs((path, bool), ...)`. Standardize on one.

---

#### 19. Scattered `or None` coercion for `add_dirs`
**Files:** `actors/basic.py:108`, `critics/basic.py:82`, `orchestrators/sequential.py:287,371` | **Domain:** [Quality]

`invoke()` handles empty lists and None identically. Remove unnecessary coercion at call sites.

---

#### 20. `scaffold.py` imports `config.py` (conceptual coupling)
**File:** `scaffold.py:11` | **Domain:** [Architecture]

`_apply_overrides` round-trips YAML through `load_config`. Work directly with the YAML dict instead.

---

#### 21. CLI display logic is extensive (~180 lines)
**File:** `cli.py:192-372` | **Domain:** [Architecture]

Presentation logic mixed into CLI module. Extract to `display.py` for reuse and isolated testing.

---

#### 22. Parallel data structures (progress events vs RoundSummary)
**Files:** `progress.py`, `orchestrators/sequential.py` | **Domain:** [Architecture]

Two parallel data flows for the same round information. Consider making `ProgressEvent` the canonical model.

---

#### 23. `events.py` module is largely unused
**File:** `claude/events.py` | **Domain:** [Quality]

Exports `parse_event()` and constants, but `invoke.py` does inline parsing. Integrate or remove.

---

#### 24. Duplicated test helpers across files
**Files:** `test_cli.py`, `test_scaffold.py`, 4 stop condition test files, `test_claude_invoke.py`/`test_invoke.py` | **Domain:** [Tests]

- `_create_template` duplicated between CLI and scaffold tests
- `_fb()` factory copy-pasted across 4 stop condition test files
- `TestFormatToolInput` duplicated between two invoke test files
- CLI workspace setup boilerplate repeated in 15+ tests

**Recommendation:** Extract to `conftest.py` fixtures and shared helpers.

---

#### 25. CLI coverage gaps (18 uncovered lines)
**File:** `cli.py` (94% coverage) | **Domain:** [Tests]

Uncovered: `KeyboardInterrupt` handler, `ResolverError` path, summary table conditional columns (`has_actor_time`, `has_critic_time`), wizard `ScaffoldError` path.

---

#### 26. Stale output cleanup without error handling
**File:** `orchestrators/sequential.py:55` | **Domain:** [Security]

`file.unlink()` without catching `OSError`. Use `missing_ok=True` or try/except.

---

#### 27. No config schema version
**File:** `config.py` | **Domain:** [Architecture]

No `version` field in YAML format. Add optional `version: 1` now for future migration support.

---

### Cosmetic / Informational

#### 28. `_error` function name is overly generic
**File:** `cli.py:116-120` | Rename to `_cli_error`.

#### 29. `_output_contents_filter` name is misleading
**File:** `scaffold.py:215` | It's an ignore function, not a keep function. Rename to `_ignore_output_contents`.

#### 30. Mixed stdout/stderr convention undocumented
**Files:** `cli.py`, `progress.py` | Progress to stderr, results to stdout -- add a comment.

#### 31. Inconsistent `__init__.py` docstrings
Some have docstrings, others are empty. Pick a convention.

#### 32. Fragile `click.echo` monkey-patch in tests
**File:** `test_progress.py` | Use `CliRunner` or `capsys` instead.

#### 33. Dead `_noop` class in test_progress.py
Leftover debugging code. Remove.

#### 34. Missing class variable annotation
**File:** `cli.py:40` | `_ColorFormatter._plain` not annotated.

---

## What's Done Well

| Practice | Details |
|----------|---------|
| **99% test coverage** | 476 tests, 53 lines uncovered out of 3,855 |
| **No `shell=True`** | All subprocess calls use list-form commands |
| **`yaml.safe_load()` everywhere** | No deserialization attack vectors |
| **Import-linter contracts** | 4 contracts enforce the dependency DAG in CI |
| **Behavioral tests** | Tests assert on outputs, not implementation details |
| **Graceful Ctrl+C** | Both CLI and orchestrator produce clean partial results |
| **Custom exceptions** | `ConfigError`, `ResolverError` prevent tracebacks reaching users |
| **Environment isolation** | `_build_env()` copies `os.environ` before modification |
| **Clean dependency DAG** | `cli.py` at top, `types.py` and `claude/` at bottom |
| **`StrictUndefined` in Jinja2** | Prevents silent variable misses in templates |

---

## Dependency Flow Diagram

```
cli.py
  |-- config.py (load_config)
  |-- resolver.py (resolve)
  |-- scaffold.py (scaffold_workspace)
  |-- progress.py (cli_progress_display)
  |-- types.py (LoopResult, RoundSummary)
  |
  +-> orchestrators/sequential.py (run)
        |-- types.py (ActorOutput, CriticFeedback, LoopResult, RoundSummary)
        |-- progress.py (ProgressCallback, event types)
        |
        +-> actors/basic.py (run)
        |     |-- claude/ (invoke)
        |     |-- types.py (ActorOutput)
        |
        +-> critics/basic.py (run)
        |     |-- claude/ (invoke)
        |     |-- types.py (CriticFeedback, CRITIC_FEEDBACK_SCHEMA)
        |
        +-> stop_conditions/*.py (should_stop)
              |-- types.py (CriticFeedback)

scaffold.py
  |-- config.py (load_config) -- for _apply_overrides only

claude/__init__.py
  |-- claude/invoke.py
  |-- claude/types.py
  |-- claude/events.py
```

---

## Summary Table

| Severity | Count | Key Themes |
|----------|-------|------------|
| Critical/High | 6 | God module, broken multi-critic, no subprocess timeout, fragile resolver, arbitrary imports, failing tests |
| Medium | 8 | Template injection, unbounded snapshots, untested history feature, type annotation gaps |
| Low | 13 | Code duplication, inconsistent patterns, coverage gaps, missing error handling |
| Cosmetic | 7 | Naming, documentation, dead code |
| **Total** | **34** | (deduplicated from 42 raw findings across 4 reviews) |

---

## Recommended Action Order

| Priority | Finding | Effort | Impact |
|----------|---------|--------|--------|
| 1 | Fix 5 failing tests (#6) | Low | Unblocks CI |
| 2 | Add subprocess timeout (#3) | Low | Prevents hangs |
| 3 | Fix multi-critic resolution bug (#2) | Medium | Correctness |
| 4 | Add explicit resolver entry point (#4) | Low | Prevents silent breakage |
| 5 | Use `SandboxedEnvironment` for Jinja2 (#7) | Low | Security |
| 6 | Extract orchestrator utilities (#1) | High | Enables alternative orchestrators |
| 7 | Add history/snapshot tests (#9) | Medium | Coverage |
| 8 | Validate config names (#10) | Low | Robustness |
| 9 | Introduce `LoopState` dataclass (#1) | Medium | Readability |
| 10 | Extract duplicated helpers (#15, #16, #24) | Low | DRY |
