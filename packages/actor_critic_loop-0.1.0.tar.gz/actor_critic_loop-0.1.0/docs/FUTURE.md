# Future

Ideas that are out of scope for the current phase plan. See `plans/PHASE*.md` for in-scope work.

## CLI

- Input preparation wizard
- Incremental workspace building

## Role Templates (Shelved Phase 7)

Parameterized role templates with Jinja2 variables, `template.yaml` metadata, `templates list/show` CLI commands, and `--config` flag for `init`. The concept: package proven actor/critic configurations as reusable templates with variable substitution (language, project name, strictness level, etc.).

Phase 5's `--template <dir>` already covers the primary use case — cloning an existing workspace. The incremental value of Jinja2-powered parameterization didn't justify the infrastructure cost (~500+ lines, new module, dataclasses, CLI commands, tests) for a spike project.

Full spec preserved in `plans/PHASE7-TEMPLATES.md`.

## Orchestration

- Multiple actors in a single run
- Session resume strategy (`--resume` flag for Claude Code subprocess) — allows actors/critics to build on prior context across rounds

## Output & Observability

- Detailed steps and traces in output
- Critics feedback summary

## Infrastructure

- Containerization
