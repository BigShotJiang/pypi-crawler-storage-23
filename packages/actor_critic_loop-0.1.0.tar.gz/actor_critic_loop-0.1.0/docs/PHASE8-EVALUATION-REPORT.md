# Actor-Critic Examples Evaluation Report

**Date:** 2026-02-15
**Examples Run:** 10/10
**Overall Success Rate:** 9/10 (90%)

---

## Per-Example Results

### 1. hello-world

- **Status:** SUCCESS
- **Rounds:** 2 of 5
- **Total Time:** 231.4s
- **Critic Verdicts by Round:**

| Round | friendliness | insight | factcheck |
|-------|-------------|---------|-----------|
| 1     | FAIL        | PASS    | PASS      |
| 2     | PASS        | PASS    | PASS      |

- **Output Quality:** High. A well-structured greeting with a real, verified tech news story (Microsoft February 2026 Patch Tuesday) including source link and insightful commentary.
- **Actor-Critic Loop Value:** **Moderate.** The friendliness critic caught a generic AI phrase ("feel free to reach out") in the closing and the actor replaced it with more natural language ("Stay curious and stay secure!"). A small but genuine improvement to the output's authenticity.

---

### 2. haiku

- **Status:** SUCCESS
- **Rounds:** 4 of 5
- **Total Time:** 346.6s
- **Critic Verdicts by Round:**

| Round | syllable | imagery | rewrite |
|-------|----------|---------|---------|
| 1     | PASS     | PASS    | FAIL    |
| 2     | PASS     | PASS    | FAIL    |
| 3     | PASS     | PASS    | FAIL    |
| 4     | PASS     | PASS    | PASS    |

- **Output Quality:** High. Final haiku ("Frost cracks autumn's skin / Beneath: waiting seeds dream spring / Death becomes the seed") demonstrates sophisticated paradoxical compression, concrete sensory imagery, and unified philosophical insight.
- **Actor-Critic Loop Value:** **High.** The rewrite critic drove substantial iterative improvement over 4 rounds:
  - Round 1: "Crimson leaves drift down" (pleasant but conventional)
  - Round 2: Added death/renewal paradox per feedback
  - Round 3: Compressed paradox into each line, added oxymoron ("Frost burns")
  - Round 4: Achieved geological/bodily grounding, maximum word economy, unified insight
  Each revision was materially stronger. The rewrite critic was demanding but pushed the output to a genuinely superior poem.

---

### 3. code-review

- **Status:** SUCCESS
- **Rounds:** 3 of 5
- **Total Time:** 844.5s
- **Critic Verdicts by Round:**

| Round | review | actionability |
|-------|--------|---------------|
| 1     | PASS   | FAIL          |
| 2     | FAIL   | PASS          |
| 3     | PASS   | PASS          |

- **Output Quality:** High. Comprehensive 8-issue review with correct severity levels (3 critical, 2 high, 3 medium), accurate line numbers, before/after code examples, and verified documentation references.
- **Actor-Critic Loop Value:** **High.** Two distinct improvements:
  1. Round 1->2: Actionability critic caught an incorrect PEP 8 citation (PEP 8 only covers keyword conflicts, not built-in shadowing). Actor corrected to cite Ruff A002 rule instead.
  2. Round 2->3: Review critic caught missing line numbers on 3 issues. Actor added exact line references.
  Both were legitimate accuracy and completeness improvements that a human reviewer would appreciate.

---

### 4. cover-letter

- **Status:** SUCCESS
- **Rounds:** 2 of 5
- **Total Time:** 174.1s
- **Critic Verdicts by Round:**

| Round | relevance | tone |
|-------|-----------|------|
| 1     | PASS      | FAIL |
| 2     | PASS      | PASS |

- **Output Quality:** High. Well-tailored cover letter matching the candidate's resume to the job posting, with specific metrics (8K+ RPS, 99.95% uptime) and proper company/role references. 327 words within target range.
- **Actor-Critic Loop Value:** **Moderate.** The tone critic caught a banned opening phrase ("I'm writing to express my strong interest...") that the prompt explicitly prohibited. The actor replaced it with a direct, experience-led opening. A clear rule enforcement catch.

---

### 5. elevator-pitch

- **Status:** SUCCESS
- **Rounds:** 5 of 5 (max)
- **Total Time:** 449.1s
- **Critic Verdicts by Round:**

| Round | brevity | persuasion | rewrite |
|-------|---------|------------|---------|
| 1     | PASS    | PASS       | FAIL    |
| 2     | PASS    | FAIL       | PASS    |
| 3     | PASS    | PASS       | FAIL    |
| 4     | PASS    | FAIL       | FAIL    |
| 5     | PASS    | PASS       | PASS    |

- **Output Quality:** Good. Final 56-word pitch covers all 5 required elements with specific numbers ($1,500 waste, $20B market, 130M households, $2M pre-seed), competitive differentiation ("without lock-in"), and urgency ("closing March 15th").
- **Actor-Critic Loop Value:** **Mixed.** The critics drove real improvements (removed jargon, added market size, added deadline urgency) but also showed oscillation -- the rewrite and persuasion critics sometimes contradicted each other (rewrite wanted fewer words while persuasion wanted more detail). Round 4 saw both fail simultaneously with conflicting demands. The actor navigated these competing pressures by Round 5, but the oscillation pattern wasted cycles.

---

### 6. epic-refinement

- **Status:** SUCCESS
- **Rounds:** 3 of 5
- **Total Time:** 1465.5s (24.4 min -- longest example)
- **Critic Verdicts by Round:**

| Round | format | completeness | testability |
|-------|--------|-------------|-------------|
| 1     | FAIL   | FAIL        | FAIL        |
| 2     | PASS   | FAIL        | PASS         |
| 3     | PASS   | PASS        | PASS        |

- **Output Quality:** Very high. 37 user stories organized into 12 themes, each with standard format, 3-5 measurable acceptance criteria, S/M/L sizing with justifications, dependencies, and standards references (OWASP, NIST, OAuth 2.1).
- **Actor-Critic Loop Value:** **Very high.** Every round produced substantial improvements:
  - Round 1->2: Added sizing justifications to all stories, added measurable acceptance criteria (numeric thresholds), expanded from 24 to 35 stories with error handling, non-functional, and operational stories
  - Round 2->3: Added 3 premium tier/subscription stories that the completeness critic correctly identified as a gap from the epic's explicit "premium tier functionality" requirement
  This example demonstrates the pattern at its best -- critics catching genuine missing requirements.

---

### 7. api-docs

- **Status:** SUCCESS
- **Rounds:** 2 of 5
- **Total Time:** 348.3s
- **Critic Verdicts by Round:**

| Round | accuracy | completeness |
|-------|----------|-------------|
| 1     | FAIL     | PASS         |
| 2     | PASS     | PASS         |

- **Output Quality:** High. Complete reference documentation for 10 pathlib methods/properties with correct signatures, type annotations, descriptions, parameters, and examples.
- **Actor-Critic Loop Value:** **High.** The accuracy critic caught 3 missing parameters in method signatures:
  - `Path.exists()` missing `follow_symlinks` parameter
  - `Path.glob()` missing `case_sensitive` and `recurse_symlinks` parameters
  - `Path.read_text()` missing `newline` parameter
  These are real API accuracy issues that would mislead developers. The critic verified against official Python docs.

---

### 8. blog-post

- **Status:** FAILURE (max rounds reached)
- **Rounds:** 5 of 5 (max)
- **Total Time:** 778.5s
- **Critic Verdicts by Round:**

| Round | quality | structure |
|-------|---------|-----------|
| 1     | PASS    | FAIL      |
| 2     | FAIL    | PASS      |
| 3     | FAIL    | PASS      |
| 4     | FAIL    | PASS      |
| 5     | PASS    | FAIL      |

- **Output Quality:** Good despite the FAIL verdict. The blog post covers remote work productivity with verified statistics, practical tips, and clear structure. The final "failure" was a single missing transition sentence.
- **Actor-Critic Loop Value:** **Negative.** This is the worst case for the pattern -- the two critics oscillated destructively:
  - Round 1: quality PASS, structure FAIL (missing transition)
  - Round 2: quality FAIL (word count exceeded 1000), structure PASS
  - Round 3: quality FAIL (misrepresented a statistic), structure PASS
  - Round 4: quality FAIL (word count 886, below 900 escalation threshold), structure PASS
  - Round 5: quality PASS, structure FAIL (missing transition again)
  The quality and structure critics kept creating conflicting demands. Fixing one broke the other. The output was probably "good enough" after Round 2 or 3, but the competing critic standards prevented convergence.

---

### 9. summarizer

- **Status:** SUCCESS
- **Rounds:** 3 of 5
- **Total Time:** 455.0s
- **Critic Verdicts by Round:**

| Round | accuracy | faithfulness | conciseness |
|-------|----------|-------------|-------------|
| 1     | FAIL     | PASS        | PASS        |
| 2     | PASS     | PASS        | FAIL        |
| 3     | PASS     | PASS        | PASS        |

- **Output Quality:** High. Clean 3-sentence summary of Paul Graham's "Superlinear Returns" essay that captures the thesis, mechanisms, and practical implications without fabrication or verbatim copying.
- **Actor-Critic Loop Value:** **Moderate.** Two legitimate catches:
  1. Round 1: Accuracy critic noted the summary was technically one long sentence instead of the required 2-3 sentences
  2. Round 2: Conciseness critic noted sentence 3 was 67 words with too much detail crammed in via semicolons
  Both were valid structural/formatting issues. The final output is genuinely better.

---

### 10. test-writer

- **Status:** SUCCESS
- **Rounds:** 1 of 5
- **Total Time:** 115.4s (fastest example)
- **Critic Verdicts by Round:**

| Round | coverage | correctness |
|-------|----------|-------------|
| 1     | PASS     | PASS        |

- **Output Quality:** High. Comprehensive pytest test suite covering all 6 calculator functions with parametrized tests, edge cases (zero, negatives, floats, large numbers), exception testing with message matching, and proper pytest conventions.
- **Actor-Critic Loop Value:** **None (not needed).** The actor produced a complete, correct test suite on the first attempt. Both critics passed immediately. This suggests the task was well-defined enough that the actor could get it right without iteration. For straightforward, well-specified tasks, the actor-critic loop adds latency without benefit.

---

## Overall Assessment

### Summary Statistics

| Metric | Value |
|--------|-------|
| Examples run | 10 |
| Successes | 9 (90%) |
| Failures | 1 (blog-post) |
| Average rounds to convergence | 2.8 |
| Median rounds to convergence | 2.5 |
| First-round passes | 1 (test-writer) |
| Max-round exhaustions | 2 (elevator-pitch succeeded at 5, blog-post failed at 5) |
| Total execution time | ~5,207s (~87 min) |

### Which examples benefited most from the actor-critic loop?

1. **epic-refinement** -- Greatest benefit. Critics caught missing sizing justifications, non-measurable acceptance criteria, and an entire missing feature category (premium tier). The output went from 24 vague stories to 37 detailed, testable, well-structured stories.
2. **haiku** -- Surprising depth of improvement. The rewrite critic pushed the poem through 4 revisions, each materially better, from a conventional autumn haiku to a sophisticated paradoxical poem with compressed imagery.
3. **api-docs** -- High-value accuracy catch. The critic found 3 genuinely missing API parameters by cross-referencing official Python documentation.
4. **code-review** -- Two distinct catches: an incorrect PEP 8 citation and missing line numbers.

### Which critics were most effective?

1. **Accuracy/fact-checking critics** (accuracy, factcheck, correctness) -- Most reliably useful. They caught real factual errors: wrong PEP 8 claims, missing API parameters, structural requirement violations.
2. **Completeness critics** -- High value for complex outputs. Caught missing premium tier stories in epic-refinement.
3. **Tone/style critics** -- Moderate value. Caught specific banned phrases (cover-letter) and AI-sounding language (hello-world).
4. **Rewrite critics** -- High variance. Drove genuine improvement in haiku but caused oscillation in elevator-pitch. These critics are the most subjective and hardest to satisfy.

### False Positives (critics failing good outputs)

- **blog-post structure critic Round 5** -- Failed on "missing transition between manager section and conclusion" after the output had been refined 4 times. The post was likely good enough; this feels like diminishing returns.
- **elevator-pitch rewrite critic Round 3** -- Failed on "juxtaposition distributed across three lines" when the pitch already met all 5 requirements. The critic was chasing stylistic perfection beyond the prompt's requirements.
- **blog-post quality critic Round 4** -- Failed because word count was 886, "14 words short of the 900+ escalation requirement." This is an artificially strict threshold that escalated requirements beyond the original 800-1000 word range.

### False Negatives (critics passing outputs with real issues)

- **haiku syllable/imagery critics** -- Both passed the Round 1 haiku that the rewrite critic (correctly) identified as conventional and improvable. The technical criteria were met but artistic quality had room to grow.
- **test-writer critics** -- Both passed on Round 1. The tests are solid but do not test edge cases like `float('inf')`, `float('nan')`, or extremely large factorials. Depending on requirements, this could be a gap.

### Oscillation Pattern

The most significant failure mode is **critic oscillation**, where fixing one critic's feedback breaks another critic's requirements. This appeared in:
- **blog-post** (fatal): quality and structure critics created a deadlock
- **elevator-pitch** (near-miss): rewrite and persuasion critics had competing demands about brevity vs. detail

Oscillation occurs when critics have overlapping or conflicting standards without a mechanism to prioritize or negotiate between them.

### Overall Verdict on the Actor-Critic Pattern

**The pattern is effective for complex, multi-dimensional tasks** where different quality dimensions need independent evaluation. It works best when:

1. **Tasks have objective criteria** (api-docs accuracy, code-review line numbers, epic completeness) -- critics can verify facts
2. **Tasks have well-separated quality dimensions** (cover-letter: relevance vs. tone) -- critics don't interfere with each other
3. **The initial output has real gaps** (epic-refinement Round 1 had 3 failing critics) -- the loop adds genuine value

It works poorly when:

1. **Critics have competing demands** (blog-post quality vs. structure) -- oscillation risk
2. **Tasks are well-defined and simple** (test-writer) -- the actor gets it right on first try; the loop adds latency
3. **Critics chase subjective perfection** (rewrite critics) -- diminishing returns and potentially infinite loops

**Recommendation:** The actor-critic pattern should be paired with oscillation detection (already partially implemented based on CLAUDE.md notes about the "epic-refinement oscillation bug fix"). Consider adding a "good enough" threshold where if the same critic alternates between PASS and FAIL, the system accepts the output rather than continuing to iterate.

> **Update (2026-02-20):** Oscillation prevention has been implemented in `orchestrators/oscillation.py`. The orchestrator now detects two patterns: **verdict reversals** (PASS↔FAIL cycling, default threshold: 2 reversals) and **consecutive fails** (same critic failing with different issues, default threshold: 3 rounds). When detected, the suspect critic is re-invoked with its own verdict history and asked to reconcile. If the critic determines its FAIL was self-contradictory, the verdict is overridden to PASS* (reconciled). This directly addresses the blog-post deadlock (quality↔structure oscillation) and elevator-pitch near-miss (rewrite↔persuasion competing demands). Thresholds are configurable via `max_consecutive_fails` and `oscillation_reversals` in `stop_condition.config`.
