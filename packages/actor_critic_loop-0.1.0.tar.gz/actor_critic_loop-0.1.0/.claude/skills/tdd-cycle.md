---
name: tdd-cycle
description: Implement a feature using strict Test-Driven Development (red-green-refactor)
---

# TDD Cycle

Execute the Red-Green-Refactor cycle for the requested feature.

## Phase 1: RED — Write a Failing Test

1. Spawn `tdd-test-writer` subagent (context-isolated)
2. Agent writes ONE failing test in `tests/` that describes the desired behavior
3. Run `uv run pytest -x` — confirm the new test FAILS
4. Do NOT proceed to Green until failure is confirmed

## Phase 2: GREEN — Minimal Implementation

1. Spawn `tdd-implementer` subagent (receives only the test file path + requirement)
2. Agent writes the MINIMUM code in `src/actor_critic/` to make the test pass
3. Run `uv run pytest -x` — confirm ALL tests PASS
4. Do NOT proceed to Refactor until all tests pass

## Phase 3: REFACTOR — Clean Up

1. Spawn `tdd-refactorer` subagent
2. Agent evaluates: extract helpers? remove duplication? simplify conditionals?
3. If no refactoring needed → skip (don't over-engineer)
4. Run `uv run pytest -x` — confirm tests still pass after refactoring

## Completion

Report: test file created, implementation file(s) changed, refactoring applied (if any).
If multiple features requested, complete full R-G-R cycle for Feature 1 before starting Feature 2.
