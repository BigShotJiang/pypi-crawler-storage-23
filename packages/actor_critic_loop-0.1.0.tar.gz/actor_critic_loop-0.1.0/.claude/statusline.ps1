#Requires -Version 7.0
<#
.SYNOPSIS
    Claude Code status line script (PowerShell port of statusline.sh).
.DESCRIPTION
    Reads JSON session data from stdin, outputs up to 4 lines:
      Line 1 (always): Model (branch) | tokens used/total | % used | % remain | thinking
      Line 2 (if authenticated): 5h usage bar | 7d usage bar | extra usage bar
      Line 3 (if authenticated): Reset times for each usage bucket
      Line 4 (if hooks configured): Configured hooks overview
#>

# --- 1. Constants ---

# oh-my-posh inspired true-color palette
$C_BLUE   = "`e[38;2;0;153;255m"
$C_ORANGE = "`e[38;2;255;176;85m"
$C_GREEN  = "`e[38;2;0;160;0m"
$C_CYAN   = "`e[38;2;46;149;153m"
$C_RED    = "`e[38;2;255;85;85m"
$C_YELLOW = "`e[38;2;230;200;0m"
$C_DIM    = "`e[38;2;80;80;80m"
$C_WHITE  = "`e[38;2;220;220;220m"
$C_RESET  = "`e[0m"

$USAGE_CACHE = Join-Path $env:TEMP 'claude-statusline-usage.json'
$USAGE_CACHE_TTL = 60
$GIT_CACHE_TTL = 5

# --- 2. Fallback trap ---

trap {
    Write-Host -NoNewline "Claude"
    exit 0
}

# --- 3. Functions ---

function Format-Tokens {
    param([long]$n)
    if ($n -ge 1000000) {
        $v = $n / 1000000
        if ($v -eq [math]::Floor($v)) { return "{0}m" -f [int]$v }
        return "{0:F1}m" -f $v
    }
    if ($n -ge 1000) { return "{0}k" -f [int]($n / 1000) }
    return "$n"
}

function Format-Number {
    param([long]$n)
    return $n.ToString('N0')
}

function Get-ColorForPct {
    param([int]$pct)
    if ($pct -ge 90) { return $C_RED }
    if ($pct -ge 70) { return $C_YELLOW }
    if ($pct -ge 50) { return $C_ORANGE }
    return $C_GREEN
}

function Build-Bar {
    param([int]$pct = 0, [int]$width = 10)
    if ($pct -lt 0) { $pct = 0 }
    if ($pct -gt 100) { $pct = 100 }
    $filled = [int]($pct * $width / 100)
    if ($filled -gt $width) { $filled = $width }
    $empty = $width - $filled
    $barColor = Get-ColorForPct $pct
    $bar = ''
    if ($filled -gt 0) { $bar += "$barColor" + ([string]::new([char]0x25CF, $filled)) }
    if ($empty -gt 0) { $bar += "$C_DIM" + ([string]::new([char]0x25CB, $empty)) }
    return "$bar$C_RESET"
}

function Format-ResetTimeRelative {
    param([string]$timestamp)
    if (-not $timestamp) { return '' }
    try {
        $resetTime = [DateTimeOffset]::Parse($timestamp)
        $now = [DateTimeOffset]::UtcNow
        $diff = $resetTime - $now
        if ($diff.TotalSeconds -gt 0) {
            $hours = [int]$diff.TotalHours
            $mins = $diff.Minutes
            if ($hours -gt 0) { return "{0}h{1:D2}m" -f $hours, $mins }
            return "{0}m" -f $mins
        }
        return 'resetting...'
    } catch {
        return ''
    }
}

function Format-ResetTimeAbsolute {
    param([string]$timestamp)
    if (-not $timestamp) { return '' }
    try {
        $dt = [DateTimeOffset]::Parse($timestamp).LocalDateTime
        return $dt.ToString('MMM d, h:mmtt').ToLower()
    } catch {
        return ''
    }
}

# --- 4. Parse stdin JSON ---

$inputText = [Console]::In.ReadToEnd()
if (-not $inputText) {
    Write-Host -NoNewline "Claude"
    exit 0
}

try {
    $data = $inputText | ConvertFrom-Json
} catch {
    Write-Host -NoNewline "Claude"
    exit 0
}

$DISPLAY_NAME = if ($data.model.display_name) { $data.model.display_name } else { '?' }
$PROJECT_DIR  = if ($data.workspace.project_dir) { $data.workspace.project_dir } else { '.' }
$CTX_SIZE     = if ($data.context_window.context_window_size) { [long]$data.context_window.context_window_size } else { 200000 }
$CTX_PCT      = if ($null -ne $data.context_window.used_percentage) { [int][math]::Floor($data.context_window.used_percentage) } else { 0 }
$INPUT_TOK    = if ($data.context_window.current_usage.input_tokens) { [long]$data.context_window.current_usage.input_tokens } else { 0 }
$CACHE_CREATE = if ($data.context_window.current_usage.cache_creation_input_tokens) { [long]$data.context_window.current_usage.cache_creation_input_tokens } else { 0 }
$CACHE_READ   = if ($data.context_window.current_usage.cache_read_input_tokens) { [long]$data.context_window.current_usage.cache_read_input_tokens } else { 0 }

# --- 5. Git branch (cached) ---

$GIT_BRANCH = ''
$GIT_WORKTREE = ''
$insideGit = git -C $PROJECT_DIR rev-parse --is-inside-work-tree 2>$null
if ($insideGit -eq 'true') {
    $dirKey = $PROJECT_DIR -replace '[/\\:]', '-' -replace '^-', ''
    $GIT_CACHE = Join-Path $env:TEMP "claude-statusline-git-$dirKey.txt"
    $now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
    $cacheAge = 999
    if (Test-Path $GIT_CACHE) {
        $cacheMtime = [DateTimeOffset]::new((Get-Item $GIT_CACHE).LastWriteTimeUtc, [TimeSpan]::Zero).ToUnixTimeSeconds()
        $cacheAge = $now - $cacheMtime
    }
    if ($cacheAge -ge $GIT_CACHE_TTL) {
        $branch = git -C $PROJECT_DIR branch --show-current 2>$null
        $branch | Set-Content $GIT_CACHE -NoNewline -ErrorAction SilentlyContinue
        $GIT_BRANCH = $branch
    } else {
        $GIT_BRANCH = Get-Content $GIT_CACHE -Raw -ErrorAction SilentlyContinue
    }

    # Detect worktree
    $gitDir = git -C $PROJECT_DIR rev-parse --git-dir 2>$null
    $gitCommon = git -C $PROJECT_DIR rev-parse --git-common-dir 2>$null
    if ($gitDir -and $gitCommon -and $gitDir -ne $gitCommon) {
        $toplevel = git -C $PROJECT_DIR rev-parse --show-toplevel 2>$null
        $GIT_WORKTREE = Split-Path $toplevel -Leaf
    }
}

# --- 6. Context window calculations ---

$CURRENT_TOKENS = $INPUT_TOK + $CACHE_CREATE + $CACHE_READ
$REMAIN_PCT = 100 - $CTX_PCT
$REMAIN_TOKENS = $CTX_SIZE - $CURRENT_TOKENS
if ($REMAIN_TOKENS -lt 0) { $REMAIN_TOKENS = 0 }

$USED_FMT = Format-Tokens $CURRENT_TOKENS
$TOTAL_FMT = Format-Tokens $CTX_SIZE
$USED_COMMA = Format-Number $CURRENT_TOKENS
$REMAIN_COMMA = Format-Number $REMAIN_TOKENS

# --- 7. Thinking status ---

$THINKING = 'off'
$THINKING_COLOR = $C_DIM
$userSettings = Join-Path $HOME '.claude/settings.json'
if (Test-Path $userSettings) {
    try {
        $settings = Get-Content $userSettings -Raw | ConvertFrom-Json
        if ($settings.alwaysThinkingEnabled -eq $true) {
            $THINKING = 'on'
            $THINKING_COLOR = $C_ORANGE
        }
    } catch {}
}
if ($env:MAX_THINKING_TOKENS -and $env:MAX_THINKING_TOKENS -ne '0') {
    $THINKING = 'on'
    $THINKING_COLOR = $C_ORANGE
}

# --- 8. Usage API fetch (cached) ---

$HAVE_USAGE = $false

function Invoke-UsageFetch {
    $creds = Join-Path $HOME '.claude/.credentials.json'
    if (-not (Test-Path $creds)) { return $false }

    try {
        $credsData = Get-Content $creds -Raw | ConvertFrom-Json
        $token = $credsData.claudeAiOauth.accessToken
    } catch {
        return $false
    }
    if (-not $token) { return $false }

    try {
        $headers = @{
            'Authorization' = "Bearer $token"
            'Accept'        = 'application/json'
            'Content-Type'  = 'application/json'
            'User-Agent'    = 'claude-code/2.1.34'
            'anthropic-beta' = 'oauth-2025-04-20'
        }
        $response = Invoke-RestMethod -Uri 'https://api.anthropic.com/api/oauth/usage' -Headers $headers -TimeoutSec 5 -ErrorAction Stop
        $response | ConvertTo-Json -Depth 10 | Set-Content $USAGE_CACHE -Encoding UTF8 -ErrorAction SilentlyContinue
        return $true
    } catch {
        return $false
    }
}

$now = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
$cacheAge = 999
if (Test-Path $USAGE_CACHE) {
    $cacheMtime = [DateTimeOffset]::new((Get-Item $USAGE_CACHE).LastWriteTimeUtc, [TimeSpan]::Zero).ToUnixTimeSeconds()
    $cacheAge = $now - $cacheMtime
}

if ($cacheAge -ge $USAGE_CACHE_TTL) {
    Invoke-UsageFetch | Out-Null
}

# --- 9. Parse usage cache ---

$FIVE_HOUR_PCT = 0; $FIVE_HOUR_RESET = ''
$SEVEN_DAY_PCT = 0; $SEVEN_DAY_RESET = ''
$EXTRA_ENABLED = $false; $EXTRA_PCT = 0; $EXTRA_USED = '0'; $EXTRA_LIMIT = '0'

$credsFile = Join-Path $HOME '.claude/.credentials.json'
if ((Test-Path $USAGE_CACHE) -and (Test-Path $credsFile)) {
    try {
        $usage = Get-Content $USAGE_CACHE -Raw | ConvertFrom-Json
        $FIVE_HOUR_PCT = [int][math]::Round($usage.five_hour.utilization)
        $FIVE_HOUR_RESET = $usage.five_hour.resets_at
        $SEVEN_DAY_PCT = [int][math]::Round($usage.seven_day.utilization)
        $SEVEN_DAY_RESET = $usage.seven_day.resets_at
        $EXTRA_ENABLED = [bool]$usage.extra_usage.is_enabled
        $EXTRA_PCT = [int][math]::Round($usage.extra_usage.utilization)
        $EXTRA_USED = [math]::Round($usage.extra_usage.used_credits / 100, 2)
        $EXTRA_LIMIT = [math]::Round($usage.extra_usage.monthly_limit / 100, 2)
        $HAVE_USAGE = $true
    } catch {}
}

# --- 10. Hooks aggregation ---

$HOOKS_LINE = ''
if (Test-Path (Join-Path $PROJECT_DIR '.claude')) {
    $allHooks = @()
    foreach ($settingsFile in @(
        (Join-Path $PROJECT_DIR '.claude/settings.json'),
        (Join-Path $PROJECT_DIR '.claude/settings.local.json')
    )) {
        if (-not (Test-Path $settingsFile)) { continue }
        try {
            $s = Get-Content $settingsFile -Raw | ConvertFrom-Json
            if ($s.hooks) {
                foreach ($prop in $s.hooks.PSObject.Properties) {
                    $eventName = $prop.Name
                    foreach ($matcher in $prop.Value) {
                        foreach ($hook in $matcher.hooks) {
                            if ($hook.command) {
                                $scriptName = Split-Path $hook.command -Leaf
                                $scriptName = $scriptName -replace '\.(sh|ps1|py|js|ts)$', ''
                                $allHooks += "${eventName}|${scriptName}"
                            }
                        }
                    }
                }
            }
        } catch {}
    }

    if ($allHooks.Count -gt 0) {
        $unique = $allHooks | Sort-Object -Unique
        $grouped = @{}
        foreach ($entry in $unique) {
            $parts = $entry -split '\|', 2
            $ev = $parts[0]
            $name = $parts[1]
            if ($grouped.ContainsKey($ev)) {
                $grouped[$ev] += ", $name"
            } else {
                $grouped[$ev] = $name
            }
        }
        $HOOKS_LINE = ($grouped.GetEnumerator() | Sort-Object Name | ForEach-Object {
            "$($_.Name)[$($_.Value)]"
        }) -join ' '
    }
}

# --- 11. Render output ---

# Line 1: Model (branch) | tokens | % used | % remain | thinking
$usedColor = Get-ColorForPct $CTX_PCT
$line1 = "${C_BLUE}${DISPLAY_NAME}${C_RESET}"
if ($GIT_BRANCH) {
    $line1 += " ${C_DIM}(${C_CYAN}${GIT_BRANCH}${C_DIM})${C_RESET}"
}
if ($GIT_WORKTREE) {
    $line1 += " ${C_DIM}[${C_ORANGE}${GIT_WORKTREE}${C_DIM}]${C_RESET}"
}
$line1 += " ${C_DIM}|${C_RESET} "
$line1 += "${C_ORANGE}${USED_FMT}/${TOTAL_FMT}${C_RESET}"
$line1 += " ${C_DIM}|${C_RESET} "
$line1 += "${usedColor}${CTX_PCT}% used${C_RESET} ${C_ORANGE}${USED_COMMA}${C_RESET}"
$line1 += " ${C_DIM}|${C_RESET} "
$line1 += "${C_CYAN}${REMAIN_PCT}% remain${C_RESET} ${C_BLUE}${REMAIN_COMMA}${C_RESET}"
$line1 += " ${C_DIM}|${C_RESET} "
$line1 += "${C_WHITE}thinking:${C_RESET} ${THINKING_COLOR}${THINKING}${C_RESET}"

Write-Host -NoNewline $line1

# Lines 2-3: Usage bars and reset times (only if API data available)
if ($HAVE_USAGE) {
    $sep = " ${C_DIM}|${C_RESET} "
    $barWidth = 10

    $fiveBar = Build-Bar $FIVE_HOUR_PCT $barWidth
    $sevenBar = Build-Bar $SEVEN_DAY_PCT $barWidth

    $line2 = "${C_WHITE}current:${C_RESET} $fiveBar ${C_CYAN}${FIVE_HOUR_PCT}%${C_RESET}"
    $line2 += $sep
    $line2 += "${C_WHITE}weekly:${C_RESET} $sevenBar ${C_CYAN}${SEVEN_DAY_PCT}%${C_RESET}"

    if ($EXTRA_ENABLED) {
        $extraBar = Build-Bar $EXTRA_PCT $barWidth
        $line2 += $sep
        $line2 += "${C_WHITE}extra:${C_RESET} $extraBar ${C_CYAN}`$${EXTRA_USED}/`$${EXTRA_LIMIT}${C_RESET}"
    }

    Write-Host ""
    Write-Host -NoNewline $line2

    # Line 3: Reset times
    $fiveReset = Format-ResetTimeRelative $FIVE_HOUR_RESET
    $sevenReset = Format-ResetTimeAbsolute $SEVEN_DAY_RESET

    if ($fiveReset -or $sevenReset) {
        $line3 = ''
        if ($fiveReset) {
            $line3 = "${C_WHITE}resets${C_RESET} ${C_DIM}${fiveReset}${C_RESET}"
        }
        if ($sevenReset) {
            if ($line3) { $line3 += $sep }
            $line3 += "${C_WHITE}resets${C_RESET} ${C_DIM}${sevenReset}${C_RESET}"
        }
        if ($EXTRA_ENABLED) {
            $nextMonth = (Get-Date -Day 1).AddMonths(1)
            $nextMonthReset = $nextMonth.ToString('MMM d').ToLower()
            $line3 += "${sep}${C_WHITE}resets${C_RESET} ${C_DIM}${nextMonthReset}${C_RESET}"
        }
        Write-Host ""
        Write-Host -NoNewline $line3
    }
}

# Line 4: Hooks overview
if ($HOOKS_LINE) {
    Write-Host ""
    Write-Host -NoNewline "${C_DIM}hooks:${C_RESET} ${C_WHITE}${HOOKS_LINE}${C_RESET}"
}

# Set terminal window/tab title via OSC 2 escape sequence
$tabTitle = if ($GIT_BRANCH) { "Claude: $GIT_BRANCH" } else { "Claude: $DISPLAY_NAME" }
if ($GIT_WORKTREE) { $tabTitle += " [$GIT_WORKTREE]" }
Write-Host -NoNewline "`e]2;${tabTitle}`a"
