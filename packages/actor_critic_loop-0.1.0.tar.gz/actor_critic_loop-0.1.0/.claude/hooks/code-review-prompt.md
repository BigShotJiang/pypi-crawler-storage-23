Review the code changes in this session for:

1. **Correctness** — Logic errors, off-by-one, null/None handling, edge cases
2. **Test quality** — Are tests meaningful? Do they test behavior, not implementation?
3. **Conventions** — Does the code follow project conventions in CLAUDE.md?
4. **Simplicity** — Is the code as simple as it can be? Any unnecessary abstraction?

Also check for these project-specific patterns (from docs/CODE-REVIEW.md):

5. **Parameter count** — Functions with >8 parameters should use a dataclass
6. **Code duplication** — New actor/critic helpers must not duplicate existing ones (check actors/basic.py and critics/basic.py for prior art)
7. **Subprocess safety** — All subprocess calls must use list-form (no shell=True), include a timeout, and not log full prompts at INFO level
8. **Template safety** — Jinja2 rendering must use SandboxedEnvironment; user-provided values in YAML templates must be validated
9. **Built-in shadowing** — Do not use `round`, `type`, `id`, etc. as parameter names
10. **Test helpers** — Shared test helpers belong in conftest.py, not duplicated per file

Check the git diff to see what changed:
- Read the modified files
- Compare against project conventions

If you find issues, respond with:
{"ok": false, "reason": "Description of issues found"}

If the code looks good, respond with:
{"ok": true}

Focus on substantive issues. Ignore formatting (ruff handles that).
Do not flag issues in files that were not modified in this session.
