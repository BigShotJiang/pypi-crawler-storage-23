#Requires -Version 7.0
<#
.SYNOPSIS
    Per-edit hook: runs fast auto-fixers on changed Python files.
    PowerShell port of per-edit-fix.sh.
.DESCRIPTION
    Triggered by PostToolUse on Edit|Write.
    Exit 0 = success (fixes applied silently).
    Exit 2 = unfixable issues fed back to Claude.
#>

$ErrorActionPreference = 'Continue'

# Read hook input JSON from stdin
$hookInputJson = [Console]::In.ReadToEnd()
if (-not $hookInputJson) { exit 0 }

try {
    $hookInput = $hookInputJson | ConvertFrom-Json
} catch {
    exit 0
}

# Extract the file path from the hook input JSON
$filePath = $hookInput.tool_input.file_path
if (-not $filePath) {
    $filePath = $hookInput.tool_input.filePath
}

# Only process Python files
if (-not $filePath -or $filePath -notlike '*.py') {
    exit 0
}

# Verify file exists
if (-not (Test-Path $filePath)) {
    exit 0
}

$errors = ''

# 1. Ruff lint with auto-fix (safe fixes only)
$lintOutput = uv run ruff check --fix --quiet $filePath 2>&1 | Out-String
if ($LASTEXITCODE -ne 0) {
    # Re-check after fix to see what remains unfixed
    $remaining = uv run ruff check --quiet $filePath 2>&1 | Out-String
    if ($remaining.Trim()) {
        $errors += "LINT (ruff):`n$remaining`n`n"
    }
}

# 2. Ruff format (always auto-fixes)
uv run ruff format --quiet $filePath 2>&1 | Out-Null

# 3. Codespell with auto-fix
$spellOutput = uv run codespell --quiet-level=2 $filePath 2>&1 | Out-String
if ($spellOutput.Trim()) {
    # Try auto-fix first
    uv run codespell --write-changes --quiet-level=2 $filePath 2>$null | Out-Null
    # Re-check for remaining issues
    $remaining = uv run codespell --quiet-level=2 $filePath 2>&1 | Out-String
    if ($remaining.Trim()) {
        $errors += "SPELLING (codespell):`n$remaining`n`n"
    }
}

# Report unfixable issues back to Claude
if ($errors) {
    [Console]::Error.WriteLine("Per-edit check found issues in ${filePath}:`n$errors")
    exit 2
}

exit 0
