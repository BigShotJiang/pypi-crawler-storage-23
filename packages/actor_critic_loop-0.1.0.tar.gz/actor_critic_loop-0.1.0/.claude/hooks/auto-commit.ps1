#Requires -Version 7.0
<#
.SYNOPSIS
    Auto-commit hook: commits and pushes changes when Claude stops.
    PowerShell port of auto-commit.sh.
.DESCRIPTION
    Uses Claude CLI to generate commit messages.
    Exit code 2 = blocking (Claude will respond to fix issues).
    All output goes to stderr for Claude to display.
#>

$ErrorActionPreference = 'Stop'

# --- DEBUG LOGGING ---
$projectDir = if ($env:CLAUDE_PROJECT_DIR) { $env:CLAUDE_PROJECT_DIR } else { '.' }
$hookLog = Join-Path $projectDir '.claude/hooks/hook-debug.log'
function Write-DebugLog { param([string]$Message)
    "[auto-commit] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message" | Out-File -Append -FilePath $hookLog -Encoding UTF8
}
Write-DebugLog "=== HOOK STARTED (pid=$PID) ==="

# Guard against infinite loop: exit if we're already in a hook
if ($env:CLAUDE_HOOK_RUNNING) {
    [Console]::Error.WriteLine("[auto-commit] Skipping (already in hook)")
    Write-DebugLog "Skipping (CLAUDE_HOOK_RUNNING already set)"
    exit 0
}
$env:CLAUDE_HOOK_RUNNING = '1'

try {
    Set-Location $env:CLAUDE_PROJECT_DIR

    # Check for uncommitted changes
    $status = git status --porcelain
    if (-not $status) {
        [Console]::Error.WriteLine("[auto-commit] No changes to commit")
        Write-DebugLog "No changes to commit (exit 0)"
        exit 0
    }

    [Console]::Error.WriteLine("[auto-commit] Detected uncommitted changes")

    # Stage all changes first so we can get accurate diff
    git add -A

    # Get diff for commit message generation (staged changes)
    $diffSummary = git diff --cached --stat
    $changedFiles = (git diff --cached --name-only | Select-Object -First 10) -join ', '

    [Console]::Error.WriteLine("[auto-commit] Generating commit message...")

    # Try to generate commit message with Claude
    $commitMsg = $diffSummary | claude -p "Generate a concise git commit message (max 72 chars first line) for these changes. Output ONLY the commit message, no quotes or explanation:" --model sonnet 2>$null
    if ($LASTEXITCODE -ne 0) { $commitMsg = $null }
    if (-not $commitMsg) {
        $commitMsg = "WIP: $changedFiles"
        [Console]::Error.WriteLine("[auto-commit] Using fallback commit message")
    }

    [Console]::Error.WriteLine("[auto-commit] Committing: $commitMsg")

    # Commit and push - capture pre-commit hook failures
    # Use --no-gpg-sign to avoid GPG timeout in automated contexts
    $fullMsg = "$commitMsg`n`nCo-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>"
    $commitOutput = git commit --no-gpg-sign -m $fullMsg 2>&1
    if ($LASTEXITCODE -ne 0) {
        [Console]::Error.WriteLine("")
        [Console]::Error.WriteLine("[auto-commit] Pre-commit hook failed:")
        [Console]::Error.WriteLine($commitOutput)
        [Console]::Error.WriteLine("")
        [Console]::Error.WriteLine("Please fix the issues above.")
        exit 2
    }

    [Console]::Error.WriteLine("[auto-commit] Commit successful")

    [Console]::Error.WriteLine("[auto-commit] Pushing to origin...")
    $pushOutput = git push -u origin HEAD 2>&1
    if ($LASTEXITCODE -ne 0) {
        [Console]::Error.WriteLine("[auto-commit] Push failed: $pushOutput")
        [Console]::Error.WriteLine("[auto-commit] You may need to pull first")
        exit 0  # Don't fail the hook
    }

    [Console]::Error.WriteLine("[auto-commit] Push successful")
    Write-DebugLog "=== HOOK FINISHED - push successful (exit 0) ==="
    exit 0
} finally {
    Remove-Item Env:CLAUDE_HOOK_RUNNING -ErrorAction SilentlyContinue
}
