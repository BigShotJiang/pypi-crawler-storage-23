#Requires -Version 7.0
<#
.SYNOPSIS
    Style guide check for CLI output formatting.
    PowerShell port of style-guide-check.sh.
.DESCRIPTION
    Enforces design rules for user-facing terminal output.
    Rules:
      1. No ASCII art splitter lines (===, ---, ***) in click.echo/print calls
      2. Section headings must use click.style() with bold=True and a color
      3. Section headings should include an emoji (Unicode escape or literal)
    Scope: src/actor_critic/cli.py and src/actor_critic/progress.py
#>

$ErrorActionPreference = 'Stop'

$projectDir = if ($env:CLAUDE_PROJECT_DIR) {
    $env:CLAUDE_PROJECT_DIR
} else {
    git rev-parse --show-toplevel 2>$null
}

$srcDir = Join-Path $projectDir 'src/actor_critic'
$cliFiles = @(
    (Join-Path $srcDir 'cli.py'),
    (Join-Path $srcDir 'progress.py')
)

$errors = @()

foreach ($f in $cliFiles) {
    if (-not (Test-Path $f)) { continue }
    $basename = Split-Path $f -Leaf
    $lines = Get-Content $f

    for ($i = 0; $i -lt $lines.Count; $i++) {
        $line = $lines[$i]
        $lineNum = $i + 1

        # Rule 1: No ASCII splitter lines in echo/print calls
        if ($line -match '(echo|print)\(.*"[=\-\*]{3,}') {
            $errors += "${basename}:${lineNum}: ASCII splitter line detected - use emoji + click.style(ALL CAPS, bold=True) instead: $($line.Trim())"
        }

        # Rule 2: Section heading echo() calls should use click.style with bold
        if ($line -match 'click\.echo\("[^"]*[A-Z]{3,}[^"]*"\)') {
            if ($line -notmatch 'click\.style') {
                $errors += "${basename}:${lineNum}: Unstyled ALL-CAPS heading - wrap with click.style(..., bold=True, fg=COLOR): $($line.Trim())"
            }
        }
    }
}

if ($errors.Count -gt 0) {
    [Console]::Error.WriteLine("STYLE GUIDE VIOLATIONS:")
    [Console]::Error.WriteLine("")
    foreach ($err in $errors) {
        [Console]::Error.WriteLine("  - $err")
    }
    [Console]::Error.WriteLine("")
    [Console]::Error.WriteLine("Design rules: Section headings must use emoji + click.style(ALL CAPS text, fg=COLOR, bold=True). No ASCII splitter lines (===, ---, ***).")
    exit 1
}

exit 0
