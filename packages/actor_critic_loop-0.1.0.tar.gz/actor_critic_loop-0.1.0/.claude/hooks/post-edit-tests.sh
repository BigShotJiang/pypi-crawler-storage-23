#!/bin/bash
# Post-edit test runner: runs pytest after every Python file edit.
# Triggered by PostToolUse on Edit|Write|MultiEdit (after per-edit-fix.sh)
# Exit 0 = tests pass (or skipped)
# Exit 2 = tests fail → stderr feedback to Claude

# Parse stdin JSON for file path
INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.filePath // empty')

# Only run for Python files
if [ -z "$FILE_PATH" ] || [[ "$FILE_PATH" != *.py ]]; then
    exit 0
fi

# Escape hatch
if [ "${SKIP_POST_EDIT_TESTS:-0}" = "1" ]; then
    exit 0
fi

STATE_FILE="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.tdd-state.json"

# Run pytest with fast-fail settings
PYTEST_OUTPUT=$(uv run --no-sync pytest -x --tb=short -q 2>&1)
PYTEST_EXIT=$?

NOW=$(date +%s)
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

if [ "$PYTEST_EXIT" -ne 0 ]; then
    # Tests failed — feed output back to Claude
    echo "POST-EDIT TESTS FAILED after editing $FILE_PATH:" >&2
    echo "$PYTEST_OUTPUT" >&2
    echo "" >&2
    echo "Fix the failing tests before continuing." >&2

    # Update state file
    cat > "$STATE_FILE" <<EOF
{
  "last_check": "$TIMESTAMP",
  "last_check_epoch": $NOW,
  "test_status": "failing",
  "impl_file_checked": "$FILE_PATH"
}
EOF
    exit 2
fi

# Tests passed — update state file
cat > "$STATE_FILE" <<EOF
{
  "last_check": "$TIMESTAMP",
  "last_check_epoch": $NOW,
  "test_status": "passing",
  "impl_file_checked": "$FILE_PATH"
}
EOF
exit 0
