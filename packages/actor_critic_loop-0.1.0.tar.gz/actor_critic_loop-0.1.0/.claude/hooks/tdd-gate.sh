#!/bin/bash
# TDD gate: blocks writes to implementation files when no failing test exists.
# Triggered by PreToolUse on Write|Edit|MultiEdit
# Exit 0 = allow the write
# Exit 2 = block (advisory — see known limitation below) + stderr feedback to Claude
#
# Known limitation: PreToolUse exit 2 doesn't block Write/Edit (Claude Code bug #13744).
# The stderr feedback still reaches Claude, making this advisory. The post-edit test
# runner (post-edit-tests.sh) is the fallback.

# Escape hatch
if [ "${SKIP_TDD_GATE:-0}" = "1" ]; then
    exit 0
fi

# Parse stdin JSON for file path
INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // .tool_input.filePath // empty')

if [ -z "$FILE_PATH" ]; then
    exit 0
fi

# --- File classification ---

# Test files: always allow
case "$FILE_PATH" in
    tests/*.py|tests/**/*.py|test_*.py|*_test.py)
        exit 0
        ;;
esac

# Config/docs files: always allow
case "$FILE_PATH" in
    *.md|*.yaml|*.yml|*.json|*.toml|*.cfg|*.sh|*.txt|*.ini|*.lock)
        exit 0
        ;;
esac

# Only gate implementation files under src/
case "$FILE_PATH" in
    src/*.py|src/**/*.py)
        # Fall through to TDD check
        ;;
    *)
        # Not an implementation file — allow
        exit 0
        ;;
esac

# --- TDD check for implementation files ---

STATE_FILE="${CLAUDE_PROJECT_DIR:-.}/.claude/hooks/.tdd-state.json"

# Check cache: if tests were recently failing, allow without re-running
if [ -f "$STATE_FILE" ]; then
    CACHED_STATUS=$(jq -r '.test_status // empty' "$STATE_FILE" 2>/dev/null)
    CACHED_TIME=$(jq -r '.last_check_epoch // 0' "$STATE_FILE" 2>/dev/null)
    NOW=$(date +%s)
    AGE=$(( NOW - CACHED_TIME ))

    if [ "$CACHED_STATUS" = "failing" ] && [ "$AGE" -lt 30 ]; then
        exit 0
    fi
fi

# Run pytest to check for failing tests
PYTEST_OUTPUT=$(uv run --no-sync pytest --tb=no -q 2>&1)
PYTEST_EXIT=$?

NOW=$(date +%s)
TIMESTAMP=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

# Check if any test files exist
TEST_COUNT=$(echo "$PYTEST_OUTPUT" | grep -c "passed\|failed\|error" || true)
NO_TESTS=$(echo "$PYTEST_OUTPUT" | grep -c "no tests ran" || true)

if [ "$NO_TESTS" -gt 0 ]; then
    # No tests found at all
    cat > "$STATE_FILE" <<EOF
{
  "last_check": "$TIMESTAMP",
  "last_check_epoch": $NOW,
  "test_status": "no_tests",
  "impl_file_checked": "$FILE_PATH"
}
EOF
    echo "TDD GATE: No tests found. Write a test first." >&2
    exit 2
fi

if [ "$PYTEST_EXIT" -eq 0 ]; then
    # All tests pass — no failing test exists
    cat > "$STATE_FILE" <<EOF
{
  "last_check": "$TIMESTAMP",
  "last_check_epoch": $NOW,
  "test_status": "passing",
  "impl_file_checked": "$FILE_PATH"
}
EOF
    echo "TDD GATE: No failing test. Write a failing test first, then implement." >&2
    exit 2
fi

# Tests are failing — allow the implementation write
cat > "$STATE_FILE" <<EOF
{
  "last_check": "$TIMESTAMP",
  "last_check_epoch": $NOW,
  "test_status": "failing",
  "impl_file_checked": "$FILE_PATH"
}
EOF
exit 0
