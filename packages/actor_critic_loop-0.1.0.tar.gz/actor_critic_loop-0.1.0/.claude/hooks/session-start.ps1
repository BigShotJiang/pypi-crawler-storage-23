#Requires -Version 7.0
<#
.SYNOPSIS
    Session start hook: dependency hygiene checks.
    PowerShell port of session-start.sh.
.DESCRIPTION
    Runs once when a Claude Code session begins.
    Non-blocking: reports issues but doesn't prevent session start.
#>

$ErrorActionPreference = 'Continue'

$projectDir = if ($env:CLAUDE_PROJECT_DIR) { $env:CLAUDE_PROJECT_DIR } else { '.' }
Set-Location $projectDir

$warnings = ''

# 1. Dependency hygiene (deptry) - find unused/missing/transitive deps
$deptryOutput = uv run deptry . 2>&1 | Out-String
if ($LASTEXITCODE -ne 0) {
    $warnings += "DEPENDENCY ISSUES (deptry):`n$deptryOutput`n`n"
}

if ($warnings) {
    [Console]::Error.WriteLine("Session start checks found issues:`n$warnings")
    [Console]::Error.WriteLine("These are non-blocking warnings. Consider fixing them during this session.")
    exit 0  # Non-blocking
}

exit 0
