#Requires -Version 7.0
<#
.SYNOPSIS
    Quality gate hook for Claude Code Stop event.
    PowerShell port of quality-gate.sh.
.DESCRIPTION
    Fail-fast: stops at the first failing check, outputs its full stderr/stdout.
    Exit 2 feeds stderr to Claude for automatic fixing.
#>

$ErrorActionPreference = 'Continue'

$projectDir = if ($env:CLAUDE_PROJECT_DIR) { $env:CLAUDE_PROJECT_DIR } else { '.' }
$hookLog = Join-Path $projectDir '.claude/hooks/hook-debug.log'
function Write-DebugLog { param([string]$Message)
    "[quality-gate] $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $Message" | Out-File -Append -FilePath $hookLog -Encoding UTF8
}
Write-DebugLog "=== HOOK STARTED (pid=$PID) ==="

# Per-tool diagnostic hints
$toolHints = @{
    'pytest'        = "Read the failing test file and the source it tests. Run 'uv run pytest path/to/test_file.py::TestClass::test_name -x --tb=long' to see the full traceback. Fix the source code, not the test, unless the test itself is wrong."
    'coverage'      = "Run 'uv run pytest --cov=src/actor_critic --cov-report=term-missing' to see which lines are uncovered. Add tests for the uncovered code paths."
    'ruff check'    = "Run 'uv run ruff check src/ tests/ --output-format=full' for detailed explanations. Most issues are auto-fixable with 'uv run ruff check --fix'. Read the file at the reported line before editing."
    'ruff format'   = "Run 'uv run ruff format src/ tests/' to auto-fix all formatting issues."
    'pyright'       = "Read the file at the reported line number. Check type annotations, imports, and function signatures. Run 'uv run pyright src/path/to/file.py' to re-check a single file after fixing."
    'mypy'          = "Read the file at the reported line number. Fix type annotations - add missing type params, annotate untyped defs, fix incompatible assignments. Run 'uv run mypy src/path/to/file.py' to re-check a single file after fixing."
    'bandit'        = "Read the flagged code. Common fixes: use 'secrets' module instead of random for security, avoid shell=True in subprocess calls, use parameterized queries for SQL. Run 'uv run bandit -r src/ -ll --format custom --msg-template `"{relpath}:{line} {test_id} {msg}`"' for concise output."
    'vulture'       = "The reported code is detected as unused (dead code). Read the file to verify it is truly unused. If it is, delete it. If it's used dynamically (e.g. via getattr or as a public API), add it to a vulture whitelist."
    'xenon'         = "The reported function has cyclomatic complexity rank C or worse (CC > 10). Read the function and extract helper functions to reduce branching. Each 'if', 'elif', 'for', 'while', 'and', 'or', 'except', ternary, and comprehension-if adds +1 CC. Target: every function at rank B or better (CC <= 10)."
    'refurb'        = "Run 'uv run refurb --explain ERRCODE' (e.g. 'uv run refurb --explain FURB123') to understand the suggested modernization. These are usually simple one-line replacements. Read the file at the reported line, apply the suggested fix."
    'import-linter' = "Check the import layering rules in pyproject.toml under [tool.importlinter]. The error shows which import violates the dependency contract. Fix by restructuring the import or moving code to the correct layer."
    'semgrep'       = "The finding is a code pattern that matches a known security or correctness rule. Read the matched code and the rule ID. Fix the flagged pattern - do not suppress the rule unless it is a false positive."
    'ty'            = "Read the file at the reported line. Fix type errors - check annotations, return types, and argument types. Run 'uv run ty check src/path/to/file.py' to re-check a single file."
    'interrogate'   = "The reported module or function is missing a docstring. Add a one-line docstring to each flagged public function/class/module. Run 'uv run interrogate src/ -v --fail-under 70 -e tests/' to see which are missing."
    'style-guide'   = "CLI output formatting must follow the style guide: section headings use emoji + click.style(ALL CAPS text, fg=COLOR, bold=True). No ASCII splitter lines (===, ---, ***). See .claude/hooks/style-guide-check.ps1 for details."
}

function Invoke-QualityFail {
    param([string]$Name, [string]$Command, [string]$Output)

    $hint = $toolHints[$Name]

    [Console]::Error.WriteLine("")
    [Console]::Error.WriteLine("QUALITY GATE FAILED [$Name]:")
    [Console]::Error.WriteLine("Command: $Command")
    [Console]::Error.WriteLine("")
    [Console]::Error.WriteLine($Output)
    [Console]::Error.WriteLine("")
    if ($hint) {
        [Console]::Error.WriteLine("Hint: $hint")
        [Console]::Error.WriteLine("")
    }
    [Console]::Error.WriteLine("ACTION REQUIRED: You MUST fix the issue shown above. Do NOT stop or explain - read the failing file, edit the source code to resolve it, and the quality gate will re-run automatically.")
    Write-DebugLog "=== FAILED: $Name ==="
    exit 2
}

function Invoke-Check {
    param([string]$Name, [string[]]$Command)

    Write-DebugLog "Running $Name..."
    $cmdStr = $Command -join ' '
    $output = & $Command[0] $Command[1..($Command.Length-1)] 2>&1 | Out-String
    if ($LASTEXITCODE -ne 0) {
        Invoke-QualityFail -Name $Name -Command $cmdStr -Output $output
    }
}

function Invoke-CheckNonEmpty {
    param([string]$Name, [string[]]$Command)

    Write-DebugLog "Running $Name..."
    $cmdStr = $Command -join ' '
    $output = & $Command[0] $Command[1..($Command.Length-1)] 2>&1 | Out-String
    if ($output.Trim()) {
        Invoke-QualityFail -Name $Name -Command $cmdStr -Output $output
    }
}

# Sync once upfront so all tools are available
uv sync --frozen 2>$null
if ($LASTEXITCODE -ne 0) { uv sync 2>$null }

# Checks ordered by speed and likelihood of failure: fast/common first
Invoke-Check         'pytest'         @('uv', 'run', '--no-sync', 'pytest', '-x', '--tb=short')
Invoke-Check         'coverage'       @('uv', 'run', '--no-sync', 'pytest', '--cov=src/actor_critic', '--cov-report=term', '--cov-fail-under=80', '-q')
Invoke-Check         'ruff check'     @('uv', 'run', '--no-sync', 'ruff', 'check', 'src/', 'tests/')
Invoke-Check         'ruff format'    @('uv', 'run', '--no-sync', 'ruff', 'format', '--check', 'src/', 'tests/')
Invoke-Check         'pyright'        @('uv', 'run', '--no-sync', 'pyright', 'src/')
Invoke-Check         'mypy'           @('uv', 'run', '--no-sync', 'mypy', 'src/')
Invoke-Check         'bandit'         @('uv', 'run', '--no-sync', 'bandit', '-r', 'src/', '-q', '-ll')
Invoke-CheckNonEmpty 'vulture'        @('uv', 'run', '--no-sync', 'vulture', 'src/', '--min-confidence', '80')
Invoke-Check         'xenon'          @('uv', 'run', '--no-sync', 'xenon', '--max-absolute', 'B', '--max-modules', 'A', '--max-average', 'A', 'src/')
Invoke-CheckNonEmpty 'refurb'         @('uv', 'run', '--no-sync', 'refurb', 'src/', '--python-version', '3.13')
Invoke-Check         'import-linter'  @('uv', 'run', '--no-sync', 'lint-imports')
Invoke-CheckNonEmpty 'semgrep'        @('uv', 'run', '--no-sync', 'semgrep', 'scan', '--config', 'p/python', '--error', '--quiet', 'src/')
Invoke-Check         'ty'             @('uv', 'run', '--no-sync', 'ty', 'check', 'src/')
Invoke-Check         'interrogate'    @('uv', 'run', '--no-sync', 'interrogate', 'src/', '-v', '--fail-under', '70', '-e', 'tests/')

# Style guide check - call the PowerShell version
$styleScript = Join-Path $env:CLAUDE_PROJECT_DIR '.claude/hooks/style-guide-check.ps1'
if (Test-Path $styleScript) {
    Invoke-Check 'style-guide' @('pwsh', '-NoProfile', '-File', $styleScript)
} else {
    # Fall back to bash version if available
    $bashScript = Join-Path $env:CLAUDE_PROJECT_DIR '.claude/hooks/style-guide-check.sh'
    if (Test-Path $bashScript) {
        Invoke-Check 'style-guide' @('bash', $bashScript)
    }
}

Write-DebugLog "=== ALL 15 CHECKS PASSED ==="
exit 0
