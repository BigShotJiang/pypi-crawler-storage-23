"""Tests for Excel export format."""

from __future__ import annotations

import io
from typing import Any

import pytest

from data_export.formats.base import ExportOptions
from data_export.models import ColumnConfig

openpyxl = pytest.importorskip("openpyxl")

from data_export.formats.excel import ExcelExportFormat


class TestExcelExport:
    """Tests for ExcelExportFormat."""

    def test_basic_excel_export(self, sample_data: list[dict[str, Any]]):
        fmt = ExcelExportFormat()
        result = fmt.export(sample_data)

        wb = openpyxl.load_workbook(io.BytesIO(result))
        ws = wb.active
        assert ws.cell(1, 1).value == "id"
        assert ws.cell(1, 2).value == "name"
        assert ws.cell(2, 2).value == "Alice"
        assert ws.cell(4, 2).value == "Charlie"

    def test_excel_custom_sheet_name(self, sample_data: list[dict[str, Any]]):
        fmt = ExcelExportFormat()
        opts = ExportOptions(sheet_name="Users")
        result = fmt.export(sample_data, opts)

        wb = openpyxl.load_workbook(io.BytesIO(result))
        assert wb.active.title == "Users"

    def test_excel_bold_headers(self, sample_data: list[dict[str, Any]]):
        fmt = ExcelExportFormat()
        result = fmt.export(sample_data)

        wb = openpyxl.load_workbook(io.BytesIO(result))
        ws = wb.active
        assert ws.cell(1, 1).font.bold is True
        # Data rows should not be bold
        assert ws.cell(2, 1).font.bold is not True

    def test_excel_with_column_mapping(self, sample_data: list[dict[str, Any]]):
        fmt = ExcelExportFormat()
        columns = [
            ColumnConfig(field="name", header="Full Name", width=30),
            ColumnConfig(field="email", header="Email"),
        ]
        opts = ExportOptions(columns=columns)
        result = fmt.export(sample_data, opts)

        wb = openpyxl.load_workbook(io.BytesIO(result))
        ws = wb.active
        assert ws.cell(1, 1).value == "Full Name"
        assert ws.cell(1, 2).value == "Email"
        assert ws.max_column == 2

    def test_excel_auto_width(self, sample_data: list[dict[str, Any]]):
        fmt = ExcelExportFormat()
        columns = [ColumnConfig(field="name", header="Name", width=25)]
        opts = ExportOptions(columns=columns)
        result = fmt.export(sample_data, opts)

        wb = openpyxl.load_workbook(io.BytesIO(result))
        ws = wb.active
        assert ws.column_dimensions["A"].width == 25

    def test_excel_content_type(self):
        fmt = ExcelExportFormat()
        assert "spreadsheetml" in fmt.content_type
        assert fmt.extension == "xlsx"

    def test_excel_empty_data(self):
        fmt = ExcelExportFormat()
        result = fmt.export([])

        wb = openpyxl.load_workbook(io.BytesIO(result))
        ws = wb.active
        assert ws.max_row == 1 or ws.max_row is None
