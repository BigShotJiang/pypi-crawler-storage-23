"""Tests for CSV export format."""

from __future__ import annotations

from typing import Any

from data_export.formats.base import ExportOptions
from data_export.formats.csv_format import CSVExportFormat
from data_export.models import ColumnConfig


class TestCSVExport:
    """Tests for CSVExportFormat."""

    def test_basic_csv_export(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        result = fmt.export(sample_data)

        text = result.decode("utf-8")
        lines = text.strip().split("\n")
        assert len(lines) == 4  # header + 3 rows
        assert "id,name,email,age" in lines[0]
        assert "Alice" in lines[1]

    def test_csv_with_bom(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        opts = ExportOptions(bom=True)
        result = fmt.export(sample_data, opts)

        assert result.startswith(b"\xef\xbb\xbf")
        text = result[3:].decode("utf-8")
        assert "id,name,email,age" in text.split("\n")[0]

    def test_csv_custom_delimiter(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        opts = ExportOptions(delimiter=";")
        result = fmt.export(sample_data, opts)

        text = result.decode("utf-8")
        assert "id;name;email;age" in text.split("\n")[0]

    def test_csv_custom_encoding(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        opts = ExportOptions(encoding="latin-1")
        result = fmt.export(sample_data, opts)

        text = result.decode("latin-1")
        assert "Alice" in text

    def test_csv_with_column_mapping(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        columns = [
            ColumnConfig(field="name", header="Full Name"),
            ColumnConfig(field="email", header="Email Address"),
        ]
        opts = ExportOptions(columns=columns)
        result = fmt.export(sample_data, opts)

        text = result.decode("utf-8")
        lines = text.strip().split("\n")
        assert "Full Name" in lines[0]
        assert "Email Address" in lines[0]
        # id and age should NOT be present
        assert "id" not in lines[0]
        assert "age" not in lines[0]

    def test_csv_empty_data(self):
        fmt = CSVExportFormat()
        result = fmt.export([])
        assert result == b""

    def test_csv_content_type(self):
        fmt = CSVExportFormat()
        assert fmt.content_type == "text/csv"
        assert fmt.extension == "csv"

    def test_csv_bom_only_for_utf8(self, sample_data: list[dict[str, Any]]):
        fmt = CSVExportFormat()
        opts = ExportOptions(bom=True, encoding="latin-1")
        result = fmt.export(sample_data, opts)

        # BOM should NOT be added for non-UTF-8
        assert not result.startswith(b"\xef\xbb\xbf")
