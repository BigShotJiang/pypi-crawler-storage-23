"""Tests for JSON export format."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Any
from uuid import UUID, uuid4

from data_export.formats.base import ExportOptions
from data_export.formats.json_format import JSONExportFormat
from data_export.models import ColumnConfig


class TestJSONExport:
    """Tests for JSONExportFormat."""

    def test_basic_json_export(self, sample_data: list[dict[str, Any]]):
        fmt = JSONExportFormat()
        result = fmt.export(sample_data)

        parsed = json.loads(result)
        assert isinstance(parsed, list)
        assert len(parsed) == 3
        assert parsed[0]["name"] == "Alice"

    def test_json_pretty_print(self, sample_data: list[dict[str, Any]]):
        fmt = JSONExportFormat()
        opts = ExportOptions(pretty=True)
        result = fmt.export(sample_data, opts)

        text = result.decode("utf-8")
        # Pretty-printed JSON should have indentation
        assert "\n  " in text or "\n    " in text

    def test_json_compact(self, sample_data: list[dict[str, Any]]):
        fmt = JSONExportFormat()
        opts = ExportOptions(pretty=False)
        result = fmt.export(sample_data, opts)

        text = result.decode("utf-8")
        # Compact JSON should be a single line
        assert "\n" not in text.strip()

    def test_json_with_column_mapping(self, sample_data: list[dict[str, Any]]):
        fmt = JSONExportFormat()
        columns = [
            ColumnConfig(field="name", header="user_name"),
            ColumnConfig(field="email"),
        ]
        opts = ExportOptions(columns=columns)
        result = fmt.export(sample_data, opts)

        parsed = json.loads(result)
        assert "user_name" in parsed[0]
        assert "email" in parsed[0]
        assert "id" not in parsed[0]
        assert parsed[0]["user_name"] == "Alice"

    def test_json_handles_datetime(self):
        fmt = JSONExportFormat()
        dt = datetime(2025, 1, 15, 10, 30, 0, tzinfo=timezone.utc)
        data = [{"timestamp": dt, "value": 42}]
        result = fmt.export(data)

        parsed = json.loads(result)
        assert parsed[0]["timestamp"] == "2025-01-15T10:30:00+00:00"

    def test_json_handles_uuid(self):
        fmt = JSONExportFormat()
        uid = uuid4()
        data = [{"id": uid, "name": "test"}]
        result = fmt.export(data)

        parsed = json.loads(result)
        assert parsed[0]["id"] == str(uid)

    def test_json_empty_data(self):
        fmt = JSONExportFormat()
        result = fmt.export([])

        parsed = json.loads(result)
        assert parsed == []

    def test_json_content_type(self):
        fmt = JSONExportFormat()
        assert fmt.content_type == "application/json"
        assert fmt.extension == "json"
