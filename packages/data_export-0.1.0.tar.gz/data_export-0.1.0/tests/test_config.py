"""Tests for export configuration and initialization."""

from __future__ import annotations

import pytest

from data_export.config import (
    ExportConfig,
    get_config,
    get_export_service,
    init_export,
    reset,
)
from data_export.models import ExportFormat
from data_export.service import ExportService


class TestExportConfig:
    """Tests for ExportConfig model."""

    def test_default_config(self):
        config = ExportConfig()

        assert config.max_rows == 100_000
        assert config.default_format == ExportFormat.CSV
        assert config.gdpr_retention_days == 90
        assert config.streaming_chunk_size == 1000

    def test_custom_config(self):
        config = ExportConfig(max_rows=500, default_format=ExportFormat.JSON)

        assert config.max_rows == 500
        assert config.default_format == ExportFormat.JSON


class TestInitExport:
    """Tests for module initialization."""

    def test_init_with_config(self):
        config = ExportConfig(max_rows=50)
        result = init_export(config)

        assert result.max_rows == 50
        assert get_config().max_rows == 50

    def test_init_with_defaults(self):
        result = init_export()

        assert result.max_rows == 100_000

    def test_get_config_before_init_raises(self):
        with pytest.raises(RuntimeError, match="not initialized"):
            get_config()

    def test_get_export_service_before_init_raises(self):
        with pytest.raises(RuntimeError, match="not initialized"):
            get_export_service()

    def test_get_export_service_returns_service(self):
        init_export()
        service = get_export_service()

        assert isinstance(service, ExportService)

    def test_get_export_service_returns_singleton(self):
        init_export()
        service1 = get_export_service()
        service2 = get_export_service()

        assert service1 is service2

    def test_reset_clears_state(self):
        init_export()
        reset()

        with pytest.raises(RuntimeError):
            get_config()
