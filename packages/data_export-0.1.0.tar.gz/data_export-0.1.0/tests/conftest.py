"""Shared fixtures for willian-data-export tests."""

from __future__ import annotations

from typing import Any
from unittest.mock import AsyncMock

import pytest

import data_export.config as cfg
from data_export.config import ExportConfig
from data_export.gdpr import DataSource, GDPRService
from data_export.service import ExportService


@pytest.fixture(autouse=True)
def _reset_config():
    """Reset the global config and service before each test."""
    cfg.reset()
    yield
    cfg.reset()


@pytest.fixture()
def export_config() -> ExportConfig:
    """Return a standard test configuration."""
    return ExportConfig(max_rows=10_000, streaming_chunk_size=5)


@pytest.fixture()
def export_service(export_config: ExportConfig) -> ExportService:
    """Return an ExportService with test configuration."""
    cfg.init_export(export_config)
    return ExportService(export_config)


@pytest.fixture()
def sample_data() -> list[dict[str, Any]]:
    """Return sample data rows for export tests."""
    return [
        {"id": 1, "name": "Alice", "email": "alice@example.com", "age": 30},
        {"id": 2, "name": "Bob", "email": "bob@example.com", "age": 25},
        {"id": 3, "name": "Charlie", "email": "charlie@example.com", "age": 35},
    ]


class MockDataSource:
    """A mock DataSource for GDPR tests."""

    def __init__(self, data: dict[str, Any] | None = None) -> None:
        self._data = data or {"records": [{"field": "value"}]}
        self._deleted = False

    async def get_user_data(self, user_id: str) -> dict[str, Any]:
        return {"user_id": user_id, **self._data}

    async def delete_user_data(self, user_id: str) -> dict[str, Any]:
        self._deleted = True
        return {"deleted": True, "user_id": user_id}


class FailingDataSource:
    """A DataSource that raises on both operations."""

    async def get_user_data(self, user_id: str) -> dict[str, Any]:
        raise RuntimeError("Source unavailable")

    async def delete_user_data(self, user_id: str) -> dict[str, Any]:
        raise RuntimeError("Source unavailable")


@pytest.fixture()
def mock_data_source() -> MockDataSource:
    """Return a mock data source."""
    return MockDataSource()


@pytest.fixture()
def failing_data_source() -> FailingDataSource:
    """Return a data source that always fails."""
    return FailingDataSource()


@pytest.fixture()
def gdpr_service(mock_data_source: MockDataSource) -> GDPRService:
    """Return a GDPRService with a registered mock source."""
    service = GDPRService()
    service.register_data_source("users", mock_data_source)
    return service
