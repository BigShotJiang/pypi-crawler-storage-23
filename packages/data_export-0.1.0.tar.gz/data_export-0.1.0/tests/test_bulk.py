"""Tests for bulk import operations."""

from __future__ import annotations

import json
from typing import Any
from unittest.mock import AsyncMock

import pytest
from pydantic import BaseModel

from data_export.bulk import BulkImporter


class UserRow(BaseModel):
    """Schema for user import rows."""

    name: str
    email: str
    age: int


class TestBulkImportValidation:
    """Tests for BulkImporter.validate_row()."""

    def test_valid_row(self):
        importer = BulkImporter()
        errors = importer.validate_row({"name": "Alice", "email": "a@b.com", "age": 30}, UserRow)
        assert errors == []

    def test_invalid_row_missing_field(self):
        importer = BulkImporter()
        errors = importer.validate_row({"name": "Alice"}, UserRow)
        assert len(errors) >= 1
        assert any("email" in e for e in errors)

    def test_invalid_row_wrong_type(self):
        importer = BulkImporter()
        errors = importer.validate_row(
            {"name": "Alice", "email": "a@b.com", "age": "not_a_number"}, UserRow
        )
        assert len(errors) >= 1
        assert any("age" in e for e in errors)


class TestBulkImportWithReport:
    """Tests for BulkImporter.import_with_report()."""

    async def test_csv_import_success(self):
        importer = BulkImporter()
        csv_data = "name,email,age\nAlice,a@b.com,30\nBob,b@c.com,25"
        process_fn = AsyncMock()

        result = await importer.import_with_report(csv_data, UserRow, process_fn)

        assert result.total == 2
        assert result.success == 2
        assert result.errors == []
        assert process_fn.call_count == 2

    async def test_csv_import_with_errors(self):
        importer = BulkImporter()
        csv_data = "name,email,age\nAlice,a@b.com,30\nBob,,invalid"
        process_fn = AsyncMock()

        result = await importer.import_with_report(csv_data, UserRow, process_fn)

        assert result.total == 2
        assert result.success == 1
        assert len(result.errors) >= 1
        assert result.errors[0].row == 2

    async def test_json_import_success(self):
        importer = BulkImporter()
        data = [
            {"name": "Alice", "email": "a@b.com", "age": 30},
            {"name": "Bob", "email": "b@c.com", "age": 25},
        ]
        json_data = json.dumps(data)
        process_fn = AsyncMock()

        result = await importer.import_with_report(
            json_data, UserRow, process_fn, file_format="json"
        )

        assert result.total == 2
        assert result.success == 2

    async def test_import_process_fn_failure(self):
        importer = BulkImporter()
        csv_data = "name,email,age\nAlice,a@b.com,30"
        process_fn = AsyncMock(side_effect=RuntimeError("DB error"))

        result = await importer.import_with_report(csv_data, UserRow, process_fn)

        assert result.total == 1
        assert result.success == 0
        assert len(result.errors) == 1
        assert "DB error" in result.errors[0].message

    async def test_import_bytes_input(self):
        importer = BulkImporter()
        csv_data = b"name,email,age\nAlice,a@b.com,30"
        process_fn = AsyncMock()

        result = await importer.import_with_report(csv_data, UserRow, process_fn)

        assert result.total == 1
        assert result.success == 1


class TestBulkDryRun:
    """Tests for BulkImporter.dry_run()."""

    async def test_dry_run_valid_data(self):
        importer = BulkImporter()
        csv_data = "name,email,age\nAlice,a@b.com,30\nBob,b@c.com,25"

        result = await importer.dry_run(csv_data, UserRow)

        assert result.total == 2
        assert result.success == 2
        assert result.errors == []

    async def test_dry_run_invalid_data(self):
        importer = BulkImporter()
        csv_data = "name,email,age\nAlice,a@b.com,30\n,,invalid"

        result = await importer.dry_run(csv_data, UserRow)

        assert result.total == 2
        assert result.success == 1
        assert len(result.errors) >= 1

    async def test_dry_run_json(self):
        importer = BulkImporter()
        data = [{"name": "Alice", "email": "a@b.com", "age": 30}]
        json_data = json.dumps(data)

        result = await importer.dry_run(json_data, UserRow, file_format="json")

        assert result.total == 1
        assert result.success == 1


class TestBulkParseErrors:
    """Tests for parse error handling."""

    async def test_unsupported_format(self):
        importer = BulkImporter()

        with pytest.raises(ValueError, match="Unsupported import format"):
            await importer.dry_run("data", UserRow, file_format="xml")

    async def test_json_non_array(self):
        importer = BulkImporter()

        with pytest.raises(ValueError, match="must be an array"):
            await importer.dry_run('{"key": "value"}', UserRow, file_format="json")
