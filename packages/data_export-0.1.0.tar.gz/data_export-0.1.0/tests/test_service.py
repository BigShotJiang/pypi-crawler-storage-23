"""Tests for the export service layer."""

from __future__ import annotations

import asyncio
from typing import Any
from unittest.mock import AsyncMock

import pytest

from data_export.config import ExportConfig
from data_export.models import ColumnConfig, ExportFormat
from data_export.service import ExportService


class TestExportService:
    """Tests for ExportService.export()."""

    def test_export_csv(self, export_service: ExportService, sample_data: list[dict[str, Any]]):
        result = export_service.export(sample_data, format=ExportFormat.CSV)

        assert result.content_type == "text/csv"
        assert result.filename == "export.csv"
        assert result.row_count == 3
        assert b"Alice" in result.data

    def test_export_json(self, export_service: ExportService, sample_data: list[dict[str, Any]]):
        result = export_service.export(sample_data, format=ExportFormat.JSON)

        assert result.content_type == "application/json"
        assert result.filename == "export.json"
        assert result.row_count == 3

    def test_export_custom_filename(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        result = export_service.export(sample_data, filename="users_report")

        assert result.filename == "users_report.csv"

    def test_export_with_columns(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        columns = [ColumnConfig(field="name", header="Full Name")]
        result = export_service.export(sample_data, columns=columns)

        text = result.data.decode("utf-8")
        assert "Full Name" in text
        assert "email" not in text.split("\n")[0]

    def test_export_exceeds_max_rows(self, export_service: ExportService):
        export_service._config = ExportConfig(max_rows=2)
        data = [{"id": i} for i in range(5)]

        with pytest.raises(ValueError, match="exceeds maximum row limit"):
            export_service.export(data)

    def test_export_format_string(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        result = export_service.export(sample_data, format="json")

        assert result.content_type == "application/json"


class TestExportStreaming:
    """Tests for ExportService.export_streaming()."""

    async def test_streaming_csv(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        call_count = 0

        async def query_fn(offset: int, limit: int) -> list[dict[str, Any]]:
            nonlocal call_count
            call_count += 1
            if offset == 0:
                return sample_data[:2]
            return []

        chunks = []
        async for chunk in export_service.export_streaming(query_fn, format=ExportFormat.CSV):
            chunks.append(chunk)

        assert len(chunks) > 0
        combined = b"".join(chunks)
        assert b"Alice" in combined

    async def test_streaming_json(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        async def query_fn(offset: int, limit: int) -> list[dict[str, Any]]:
            if offset == 0:
                return sample_data[:2]
            return []

        chunks = []
        async for chunk in export_service.export_streaming(query_fn, format=ExportFormat.JSON):
            chunks.append(chunk)

        combined = b"".join(chunks)
        assert combined.startswith(b"[")
        assert combined.endswith(b"]")

    async def test_streaming_multiple_chunks(self, export_service: ExportService):
        all_data = [{"id": i, "val": f"item-{i}"} for i in range(12)]

        async def query_fn(offset: int, limit: int) -> list[dict[str, Any]]:
            return all_data[offset : offset + limit]

        chunks = []
        async for chunk in export_service.export_streaming(query_fn, format=ExportFormat.CSV):
            chunks.append(chunk)

        # With chunk_size=5, should get multiple chunks
        assert len(chunks) >= 2
        combined = b"".join(chunks)
        assert b"item-11" in combined


class TestScheduleExport:
    """Tests for ExportService.schedule_export()."""

    async def test_schedule_export_with_callback(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        callback = AsyncMock()

        task = await export_service.schedule_export(
            sample_data, format=ExportFormat.CSV, notify_fn=callback
        )
        result = await task

        assert result.row_count == 3
        callback.assert_called_once_with(result)

    async def test_schedule_export_without_callback(
        self, export_service: ExportService, sample_data: list[dict[str, Any]]
    ):
        task = await export_service.schedule_export(sample_data, format=ExportFormat.JSON)
        result = await task

        assert result.content_type == "application/json"
