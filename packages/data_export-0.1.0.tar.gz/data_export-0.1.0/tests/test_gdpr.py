"""Tests for the GDPR compliance service."""

from __future__ import annotations

import json
import zipfile
from io import BytesIO

import pytest

from data_export.gdpr import GDPRService
from data_export.models import GDPRRequestStatus, GDPRRequestType

from .conftest import FailingDataSource, MockDataSource


class TestGDPRExport:
    """Tests for GDPRService.export_user_data()."""

    async def test_exports_user_data_as_zip(self, gdpr_service: GDPRService):
        result = await gdpr_service.export_user_data("user-1")

        zf = zipfile.ZipFile(BytesIO(result))
        assert "users.json" in zf.namelist()

        data = json.loads(zf.read("users.json"))
        assert data["user_id"] == "user-1"

    async def test_exports_from_multiple_sources(self):
        service = GDPRService()
        service.register_data_source("users", MockDataSource({"name": "Alice"}))
        service.register_data_source("orders", MockDataSource({"orders": [1, 2, 3]}))

        result = await service.export_user_data("user-1")

        zf = zipfile.ZipFile(BytesIO(result))
        assert "users.json" in zf.namelist()
        assert "orders.json" in zf.namelist()

    async def test_exports_specific_sources(self):
        service = GDPRService()
        service.register_data_source("users", MockDataSource({"name": "Alice"}))
        service.register_data_source("orders", MockDataSource({"orders": []}))

        result = await service.export_user_data("user-1", data_sources=["users"])

        zf = zipfile.ZipFile(BytesIO(result))
        assert "users.json" in zf.namelist()
        assert "orders.json" not in zf.namelist()

    async def test_export_handles_source_failure(self):
        service = GDPRService()
        service.register_data_source("users", MockDataSource())
        service.register_data_source("broken", FailingDataSource())

        result = await service.export_user_data("user-1")

        zf = zipfile.ZipFile(BytesIO(result))
        assert "users.json" in zf.namelist()
        assert "broken_error.txt" in zf.namelist()

    async def test_export_logs_audit_trail(self, gdpr_service: GDPRService):
        await gdpr_service.export_user_data("user-42")

        trail = gdpr_service.audit_log
        assert len(trail) == 1
        assert trail[0].user_id == "user-42"
        assert trail[0].request_type == GDPRRequestType.EXPORT
        assert trail[0].status == GDPRRequestStatus.COMPLETED

    async def test_export_unknown_source_raises(self, gdpr_service: GDPRService):
        with pytest.raises(ValueError, match="Unknown data source"):
            await gdpr_service.export_user_data("user-1", data_sources=["nonexistent"])


class TestGDPRDelete:
    """Tests for GDPRService.delete_user_data()."""

    async def test_deletes_user_data(
        self, gdpr_service: GDPRService, mock_data_source: MockDataSource
    ):
        results = await gdpr_service.delete_user_data("user-1")

        assert results["users"]["status"] == "deleted"
        assert mock_data_source._deleted is True

    async def test_delete_across_multiple_sources(self):
        src1 = MockDataSource()
        src2 = MockDataSource()
        service = GDPRService()
        service.register_data_source("users", src1)
        service.register_data_source("orders", src2)

        results = await service.delete_user_data("user-1")

        assert results["users"]["status"] == "deleted"
        assert results["orders"]["status"] == "deleted"
        assert src1._deleted is True
        assert src2._deleted is True

    async def test_delete_handles_source_failure(self):
        service = GDPRService()
        service.register_data_source("users", MockDataSource())
        service.register_data_source("broken", FailingDataSource())

        results = await service.delete_user_data("user-1")

        assert results["users"]["status"] == "deleted"
        assert results["broken"]["status"] == "failed"

    async def test_delete_logs_audit_trail(self, gdpr_service: GDPRService):
        await gdpr_service.delete_user_data("user-99")

        trail = gdpr_service.audit_log
        assert len(trail) == 1
        assert trail[0].user_id == "user-99"
        assert trail[0].request_type == GDPRRequestType.DELETE

    async def test_delete_sets_failed_status_on_partial_failure(self):
        service = GDPRService()
        service.register_data_source("users", MockDataSource())
        service.register_data_source("broken", FailingDataSource())

        await service.delete_user_data("user-1")

        trail = service.audit_log
        assert trail[0].status == GDPRRequestStatus.FAILED


class TestGDPRGetRequests:
    """Tests for GDPRService.get_requests()."""

    async def test_filter_by_user_id(self, gdpr_service: GDPRService):
        await gdpr_service.export_user_data("user-1")
        await gdpr_service.export_user_data("user-2")

        results = gdpr_service.get_requests(user_id="user-1")
        assert len(results) == 1
        assert results[0].user_id == "user-1"

    async def test_filter_by_request_type(self, gdpr_service: GDPRService):
        await gdpr_service.export_user_data("user-1")
        await gdpr_service.delete_user_data("user-1")

        exports = gdpr_service.get_requests(request_type=GDPRRequestType.EXPORT)
        deletes = gdpr_service.get_requests(request_type=GDPRRequestType.DELETE)

        assert len(exports) == 1
        assert len(deletes) == 1
