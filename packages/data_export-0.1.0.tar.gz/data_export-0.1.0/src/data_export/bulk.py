"""Bulk import operations with validation and error reporting."""

from __future__ import annotations

import csv
import io
import json
import logging
from collections.abc import Callable, Coroutine
from typing import Any

from pydantic import BaseModel, ValidationError

from data_export.models import ImportError_, ImportResult

logger = logging.getLogger(__name__)


class BulkImporter:
    """Import CSV or JSON data with per-row validation and error reporting."""

    def validate_row(self, row: dict[str, Any], schema: type[BaseModel]) -> list[str]:
        """Validate a single row against a Pydantic schema.

        Args:
            row: The data row to validate.
            schema: Pydantic model class for validation.

        Returns:
            List of error messages. Empty list means the row is valid.
        """
        try:
            schema.model_validate(row)
            return []
        except ValidationError as exc:
            return [
                f"{err['loc'][0] if err['loc'] else 'unknown'}: {err['msg']}"
                for err in exc.errors()
            ]

    async def import_with_report(
        self,
        file_data: bytes | str,
        schema: type[BaseModel],
        process_fn: Callable[[dict[str, Any]], Coroutine[Any, Any, None]],
        *,
        file_format: str = "csv",
    ) -> ImportResult:
        """Import data with validation and processing, returning a detailed report.

        Args:
            file_data: Raw file content as bytes or string.
            schema: Pydantic model class for row validation.
            process_fn: Async callable to process each valid row.
            file_format: Input format, either 'csv' or 'json'.

        Returns:
            ImportResult with success/error counts and error details.
        """
        rows = self._parse_file(file_data, file_format)
        total = len(rows)
        success = 0
        errors: list[ImportError_] = []

        for row_num, row in enumerate(rows, start=1):
            validation_errors = self.validate_row(row, schema)

            if validation_errors:
                for msg in validation_errors:
                    field = msg.split(":")[0] if ":" in msg else None
                    errors.append(ImportError_(row=row_num, field=field, message=msg))
                continue

            try:
                await process_fn(row)
                success += 1
            except Exception as exc:
                errors.append(ImportError_(row=row_num, message=str(exc)))

        logger.info(
            "Bulk import completed: total=%d success=%d errors=%d", total, success, len(errors)
        )
        return ImportResult(total=total, success=success, errors=errors)

    async def dry_run(
        self,
        file_data: bytes | str,
        schema: type[BaseModel],
        *,
        file_format: str = "csv",
    ) -> ImportResult:
        """Validate all rows without importing, returning a validation report.

        Args:
            file_data: Raw file content.
            schema: Pydantic model class for row validation.
            file_format: Input format, either 'csv' or 'json'.

        Returns:
            ImportResult with validation results (no data is modified).
        """
        rows = self._parse_file(file_data, file_format)
        total = len(rows)
        success = 0
        errors: list[ImportError_] = []

        for row_num, row in enumerate(rows, start=1):
            validation_errors = self.validate_row(row, schema)
            if validation_errors:
                for msg in validation_errors:
                    field = msg.split(":")[0] if ":" in msg else None
                    errors.append(ImportError_(row=row_num, field=field, message=msg))
            else:
                success += 1

        logger.info("Dry run completed: total=%d valid=%d invalid=%d", total, success, len(errors))
        return ImportResult(total=total, success=success, errors=errors)

    def _parse_file(self, file_data: bytes | str, file_format: str) -> list[dict[str, Any]]:
        """Parse file content into a list of row dictionaries.

        Args:
            file_data: Raw file content.
            file_format: Either 'csv' or 'json'.

        Returns:
            List of row dictionaries.

        Raises:
            ValueError: If the format is unsupported or parsing fails.
        """
        if isinstance(file_data, bytes):
            file_data = file_data.decode("utf-8")

        match file_format.lower():
            case "csv":
                reader = csv.DictReader(io.StringIO(file_data))
                return list(reader)
            case "json":
                parsed = json.loads(file_data)
                if not isinstance(parsed, list):
                    raise ValueError("JSON import data must be an array of objects")
                return parsed
            case _:
                raise ValueError(f"Unsupported import format: {file_format}")
