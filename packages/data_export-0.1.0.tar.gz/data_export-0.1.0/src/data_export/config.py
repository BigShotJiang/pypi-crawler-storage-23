"""Export module configuration and initialization."""

from __future__ import annotations

from pathlib import Path
from tempfile import gettempdir

from pydantic import BaseModel

from data_export.models import ExportFormat


_config: ExportConfig | None = None
_service: object | None = None  # Lazy ref to avoid circular import


class ExportConfig(BaseModel):
    """Configuration for the data export module.

    Args:
        max_rows: Maximum rows allowed in a single export.
        default_format: Default export format when none is specified.
        temp_dir: Directory for temporary export files.
        gdpr_retention_days: How long to keep GDPR request records.
        streaming_chunk_size: Number of rows per chunk in streaming exports.
    """

    max_rows: int = 100_000
    default_format: ExportFormat = ExportFormat.CSV
    temp_dir: Path = Path(gettempdir())
    gdpr_retention_days: int = 90
    streaming_chunk_size: int = 1000


def init_export(config: ExportConfig | None = None) -> ExportConfig:
    """Initialize the export module with the given configuration.

    Args:
        config: Export configuration. Uses defaults if None.

    Returns:
        The active ExportConfig.
    """
    global _config, _service
    _config = config or ExportConfig()
    _service = None  # Reset cached service
    return _config


def get_config() -> ExportConfig:
    """Return the current module configuration.

    Raises:
        RuntimeError: If init_export() has not been called.
    """
    if _config is None:
        raise RuntimeError("Export module not initialized. Call init_export() first.")
    return _config


def get_export_service():
    """Return or create the singleton ExportService.

    Raises:
        RuntimeError: If init_export() has not been called.
    """
    global _service
    if _config is None:
        raise RuntimeError("Export module not initialized. Call init_export() first.")
    if _service is None:
        from data_export.service import ExportService

        _service = ExportService(_config)
    return _service


def set_config(config: ExportConfig) -> None:
    """Override the configuration (useful for testing)."""
    global _config
    _config = config


def reset() -> None:
    """Reset module state (useful for testing)."""
    global _config, _service
    _config = None
    _service = None
