"""FastAPI router factory for export, GDPR, and import endpoints."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query, UploadFile
from fastapi.responses import Response, StreamingResponse
from pydantic import BaseModel

from data_export.config import get_config, get_export_service
from data_export.gdpr import GDPRService
from data_export.models import (
    ExportFormat,
    ExportRequest,
    GDPRRequest,
    GDPRRequestType,
    ImportResult,
)
from errors import BusinessLogicError
from api_core.responses import ApiResponse, PaginatedResponse


class ExportResponse(BaseModel):
    """Metadata response after a triggered export."""

    filename: str
    content_type: str
    row_count: int
    size_bytes: int


class GDPRExportRequest(BaseModel):
    """Request body for GDPR data export."""

    user_id: str
    data_sources: list[str] | None = None


class GDPRDeleteRequest(BaseModel):
    """Request body for GDPR data deletion."""

    user_id: str
    data_sources: list[str] | None = None


class GDPRDeleteResponse(BaseModel):
    """Response for GDPR deletion requests."""

    user_id: str
    results: dict[str, Any]


def ExportRouter(
    *,
    gdpr_service: GDPRService | None = None,
    get_data_fn: Any | None = None,
    process_import_fn: Any | None = None,
    import_schema: Any | None = None,
    is_admin: Any | None = None,
    prefix: str = "",
    tags: list[str] | None = None,
) -> APIRouter:
    """Create a FastAPI router for export, GDPR, and import endpoints.

    Args:
        gdpr_service: GDPRService instance for GDPR endpoints. If None, GDPR
            endpoints will return 501.
        get_data_fn: Async callable(resource, filters, offset, limit) -> list[dict].
            Used by export and streaming endpoints to fetch data.
        process_import_fn: Async callable(resource, row) -> None for bulk import.
        import_schema: Pydantic model class for import row validation.
        is_admin: FastAPI dependency for admin-only endpoints.
        prefix: URL prefix for all routes.
        tags: OpenAPI tags.

    Returns:
        A configured APIRouter with export, GDPR, and import endpoints.
    """
    router = APIRouter(prefix=prefix, tags=tags or ["export"])

    @router.post("/export/{resource}")
    async def trigger_export(resource: str, request: ExportRequest) -> Response:
        """Export data for a resource in the requested format."""
        if get_data_fn is None:
            raise BusinessLogicError("Export data provider not configured")

        service = get_export_service()
        config = get_config()

        data = await get_data_fn(resource, request.filters, 0, config.max_rows)
        result = service.export(
            data,
            format=request.format,
            columns=request.columns,
            filename=request.filename or f"{resource}_export",
        )

        return Response(
            content=result.data,
            media_type=result.content_type,
            headers={"Content-Disposition": f'attachment; filename="{result.filename}"'},
        )

    @router.post("/export/stream/{resource}")
    async def streaming_export(
        resource: str,
        format: ExportFormat = Query(ExportFormat.CSV),
    ) -> StreamingResponse:
        """Stream a large export for a resource."""
        if get_data_fn is None:
            raise BusinessLogicError("Export data provider not configured")

        service = get_export_service()

        async def query_fn(offset: int, limit: int) -> list[dict[str, Any]]:
            return await get_data_fn(resource, {}, offset, limit)

        fmt_handler = __import__(
            "data_export.formats", fromlist=["get_format"]
        ).get_format(format.value)

        return StreamingResponse(
            service.export_streaming(query_fn, format=format),
            media_type=fmt_handler.content_type,
            headers={
                "Content-Disposition": f'attachment; filename="{resource}_export.{fmt_handler.extension}"'
            },
        )

    @router.post("/gdpr/export")
    async def gdpr_export(request: GDPRExportRequest) -> Response:
        """Request a GDPR data export for a user."""
        if gdpr_service is None:
            raise BusinessLogicError("GDPR service not configured")

        zip_bytes = await gdpr_service.export_user_data(
            request.user_id, data_sources=request.data_sources
        )

        return Response(
            content=zip_bytes,
            media_type="application/zip",
            headers={
                "Content-Disposition": f'attachment; filename="gdpr_export_{request.user_id}.zip"'
            },
        )

    @router.post("/gdpr/delete", response_model=GDPRDeleteResponse)
    async def gdpr_delete(request: GDPRDeleteRequest) -> GDPRDeleteResponse:
        """Request GDPR data deletion for a user."""
        if gdpr_service is None:
            raise BusinessLogicError("GDPR service not configured")

        results = await gdpr_service.delete_user_data(
            request.user_id, data_sources=request.data_sources
        )

        return GDPRDeleteResponse(user_id=request.user_id, results=results)

    # Build admin dependency list
    admin_deps: list[Any] = []
    if is_admin is not None:
        admin_deps.append(Depends(is_admin))

    @router.get("/gdpr/requests", response_model=list[GDPRRequest], dependencies=admin_deps)
    async def list_gdpr_requests(
        user_id: str | None = Query(None),
        request_type: GDPRRequestType | None = Query(None),
    ) -> list[GDPRRequest]:
        """List GDPR requests (admin only)."""
        if gdpr_service is None:
            raise BusinessLogicError("GDPR service not configured")

        return gdpr_service.get_requests(user_id=user_id, request_type=request_type)

    @router.post("/import/{resource}", response_model=ImportResult)
    async def bulk_import(resource: str, file: UploadFile) -> ImportResult:
        """Bulk import data for a resource from a CSV or JSON file."""
        if process_import_fn is None or import_schema is None:
            raise BusinessLogicError("Import not configured")

        from data_export.bulk import BulkImporter

        content = await file.read()
        file_format = "json" if file.filename and file.filename.endswith(".json") else "csv"

        importer = BulkImporter()

        async def process_row(row: dict[str, Any]) -> None:
            await process_import_fn(resource, row)

        return await importer.import_with_report(
            content, import_schema, process_row, file_format=file_format
        )

    return router
