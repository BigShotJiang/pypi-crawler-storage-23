"""GDPR compliance service for data subject requests."""

from __future__ import annotations

import io
import json
import logging
import zipfile
from collections.abc import Callable, Coroutine
from datetime import datetime, timezone
from typing import Any, Protocol, runtime_checkable

from data_export.models import GDPRRequest, GDPRRequestStatus, GDPRRequestType

logger = logging.getLogger(__name__)


@runtime_checkable
class DataSource(Protocol):
    """Protocol for any service or table that holds user data.

    Implementations must provide methods to retrieve and delete user data.
    """

    async def get_user_data(self, user_id: str) -> dict[str, Any]:
        """Retrieve all data for a given user.

        Args:
            user_id: The user identifier.

        Returns:
            Dictionary containing the user's data from this source.
        """
        ...

    async def delete_user_data(self, user_id: str) -> dict[str, Any]:
        """Delete or anonymize all data for a given user.

        Args:
            user_id: The user identifier.

        Returns:
            Dictionary with details about what was deleted/anonymized.
        """
        ...


class GDPRService:
    """Handles GDPR data subject requests across registered data sources.

    Provides export and deletion capabilities with audit trail logging.
    """

    def __init__(self) -> None:
        self._sources: dict[str, DataSource] = {}
        self._audit_log: list[GDPRRequest] = []

    def register_data_source(self, name: str, source: DataSource) -> None:
        """Register a data source that holds user data.

        Args:
            name: Unique name identifying the data source.
            source: Object implementing the DataSource protocol.
        """
        self._sources[name] = source
        logger.info("Registered GDPR data source: %s", name)

    @property
    def data_sources(self) -> dict[str, DataSource]:
        """Return the registered data sources."""
        return dict(self._sources)

    @property
    def audit_log(self) -> list[GDPRRequest]:
        """Return the audit trail of GDPR requests."""
        return list(self._audit_log)

    async def export_user_data(
        self,
        user_id: str,
        *,
        data_sources: list[str] | None = None,
    ) -> bytes:
        """Collect all user data from registered sources and return as a ZIP file.

        Args:
            user_id: The user whose data to export.
            data_sources: Optional list of source names to include. If None, all sources are used.

        Returns:
            ZIP file bytes containing a JSON file per data source.
        """
        request = GDPRRequest(
            user_id=user_id,
            request_type=GDPRRequestType.EXPORT,
            status=GDPRRequestStatus.PROCESSING,
        )
        self._audit_log.append(request)

        sources = self._resolve_sources(data_sources)
        buffer = io.BytesIO()

        try:
            with zipfile.ZipFile(buffer, "w", zipfile.ZIP_DEFLATED) as zf:
                for name, source in sources.items():
                    try:
                        data = await source.get_user_data(user_id)
                        content = json.dumps(data, indent=2, default=str, ensure_ascii=False)
                        zf.writestr(f"{name}.json", content)
                    except Exception:
                        logger.exception("Failed to export data from source: %s", name)
                        zf.writestr(f"{name}_error.txt", f"Failed to export data from {name}")

            request.status = GDPRRequestStatus.COMPLETED
            request.completed_at = datetime.now(timezone.utc)
            logger.info("GDPR export completed for user=%s sources=%d", user_id, len(sources))

        except Exception:
            request.status = GDPRRequestStatus.FAILED
            logger.exception("GDPR export failed for user=%s", user_id)
            raise

        return buffer.getvalue()

    async def delete_user_data(
        self,
        user_id: str,
        *,
        data_sources: list[str] | None = None,
    ) -> dict[str, Any]:
        """Delete or anonymize user data across registered sources.

        Args:
            user_id: The user whose data to delete.
            data_sources: Optional list of source names. If None, all sources are used.

        Returns:
            Dictionary with per-source deletion results.
        """
        request = GDPRRequest(
            user_id=user_id,
            request_type=GDPRRequestType.DELETE,
            status=GDPRRequestStatus.PROCESSING,
        )
        self._audit_log.append(request)

        sources = self._resolve_sources(data_sources)
        results: dict[str, Any] = {}

        try:
            for name, source in sources.items():
                try:
                    result = await source.delete_user_data(user_id)
                    results[name] = {"status": "deleted", "details": result}
                except Exception as exc:
                    logger.exception("Failed to delete data from source: %s", name)
                    results[name] = {"status": "failed", "error": str(exc)}

            all_ok = all(r["status"] == "deleted" for r in results.values())
            request.status = GDPRRequestStatus.COMPLETED if all_ok else GDPRRequestStatus.FAILED
            request.completed_at = datetime.now(timezone.utc)
            request.details = results
            logger.info("GDPR deletion completed for user=%s success=%s", user_id, all_ok)

        except Exception:
            request.status = GDPRRequestStatus.FAILED
            logger.exception("GDPR deletion failed for user=%s", user_id)
            raise

        return results

    def get_requests(
        self,
        *,
        user_id: str | None = None,
        request_type: GDPRRequestType | None = None,
    ) -> list[GDPRRequest]:
        """Query GDPR request audit trail with optional filters.

        Args:
            user_id: Filter by user ID.
            request_type: Filter by request type (export/delete).

        Returns:
            List of matching GDPR request records.
        """
        results = self._audit_log
        if user_id:
            results = [r for r in results if r.user_id == user_id]
        if request_type:
            results = [r for r in results if r.request_type == request_type]
        return results

    def _resolve_sources(self, names: list[str] | None) -> dict[str, DataSource]:
        """Resolve source names to DataSource instances.

        Args:
            names: Optional subset of source names. If None, return all.

        Returns:
            Dictionary of name -> DataSource.

        Raises:
            ValueError: If a requested source name is not registered.
        """
        if names is None:
            return dict(self._sources)

        resolved: dict[str, DataSource] = {}
        for name in names:
            if name not in self._sources:
                raise ValueError(f"Unknown data source: {name}")
            resolved[name] = self._sources[name]
        return resolved
