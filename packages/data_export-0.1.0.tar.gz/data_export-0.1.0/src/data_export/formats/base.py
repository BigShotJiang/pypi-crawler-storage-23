"""Abstract base class for export formats."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel

from data_export.models import ColumnConfig


class ExportOptions(BaseModel):
    """Options that control export behavior.

    Args:
        columns: Column configuration for field selection and renaming.
        pretty: Enable human-readable formatting where applicable (e.g., JSON indent).
        delimiter: Field delimiter for CSV exports.
        encoding: Character encoding for text-based exports.
        bom: Include a byte-order mark for Excel CSV compatibility.
        sheet_name: Worksheet name for Excel exports.
    """

    columns: list[ColumnConfig] | None = None
    pretty: bool = False
    delimiter: str = ","
    encoding: str = "utf-8"
    bom: bool = False
    sheet_name: str = "Sheet1"


class BaseExportFormat(ABC):
    """Abstract base for all export format implementations.

    Subclasses must implement `export()` and provide `content_type` and `extension`.
    """

    @property
    @abstractmethod
    def content_type(self) -> str:
        """MIME type for this format (e.g. 'text/csv')."""

    @property
    @abstractmethod
    def extension(self) -> str:
        """File extension without dot (e.g. 'csv')."""

    @abstractmethod
    def export(self, data: list[dict[str, Any]], options: ExportOptions | None = None) -> bytes:
        """Export data rows to bytes in this format.

        Args:
            data: List of dictionaries, each representing a row.
            options: Export options controlling columns, formatting, etc.

        Returns:
            The exported file content as bytes.
        """

    def apply_columns(
        self, data: list[dict[str, Any]], options: ExportOptions | None
    ) -> tuple[list[dict[str, Any]], list[str]]:
        """Apply column selection and renaming to the data.

        Args:
            data: Raw data rows.
            options: Export options with optional column config.

        Returns:
            Tuple of (transformed rows, ordered header names).
        """
        if not data:
            return [], []

        if options and options.columns:
            headers = [col.display_header for col in options.columns]
            fields = [col.field for col in options.columns]
            transformed = [{h: row.get(f) for h, f in zip(headers, fields)} for row in data]
            return transformed, headers

        # No column config: use all keys from the first row
        headers = list(data[0].keys())
        return data, headers
