"""JSON export format implementation."""

from __future__ import annotations

import json
from datetime import date, datetime
from typing import Any
from uuid import UUID

from data_export.formats.base import BaseExportFormat, ExportOptions


class _ExportEncoder(json.JSONEncoder):
    """JSON encoder that handles common Python types."""

    def default(self, o: Any) -> Any:
        if isinstance(o, (datetime, date)):
            return o.isoformat()
        if isinstance(o, UUID):
            return str(o)
        if isinstance(o, bytes):
            return o.decode("utf-8", errors="replace")
        return super().default(o)


class JSONExportFormat(BaseExportFormat):
    """Export data as JSON array with optional pretty-printing."""

    @property
    def content_type(self) -> str:
        return "application/json"

    @property
    def extension(self) -> str:
        return "json"

    def export(self, data: list[dict[str, Any]], options: ExportOptions | None = None) -> bytes:
        """Export data rows to JSON bytes.

        Args:
            data: List of row dictionaries.
            options: Controls pretty-printing and column mapping.

        Returns:
            JSON file content as bytes.
        """
        opts = options or ExportOptions()
        transformed, _headers = self.apply_columns(data, opts)

        indent = 2 if opts.pretty else None
        content = json.dumps(transformed, indent=indent, cls=_ExportEncoder, ensure_ascii=False)

        return content.encode(opts.encoding)
