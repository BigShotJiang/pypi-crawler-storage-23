"""CSV export format implementation."""

from __future__ import annotations

import csv
import io
from typing import Any

from data_export.formats.base import BaseExportFormat, ExportOptions


class CSVExportFormat(BaseExportFormat):
    """Export data as CSV with configurable delimiter, encoding, and BOM support."""

    @property
    def content_type(self) -> str:
        return "text/csv"

    @property
    def extension(self) -> str:
        return "csv"

    def export(self, data: list[dict[str, Any]], options: ExportOptions | None = None) -> bytes:
        """Export data rows to CSV bytes.

        Args:
            data: List of row dictionaries.
            options: Controls delimiter, encoding, BOM, and column mapping.

        Returns:
            CSV file content as bytes.
        """
        opts = options or ExportOptions()
        transformed, headers = self.apply_columns(data, opts)

        if not headers:
            return b""

        output = io.StringIO()
        writer = csv.DictWriter(
            output,
            fieldnames=headers,
            delimiter=opts.delimiter,
            extrasaction="ignore",
        )
        writer.writeheader()
        for row in transformed:
            writer.writerow(row)

        content = output.getvalue()
        encoded = content.encode(opts.encoding)

        if opts.bom and opts.encoding.lower().replace("-", "") == "utf8":
            return b"\xef\xbb\xbf" + encoded

        return encoded
