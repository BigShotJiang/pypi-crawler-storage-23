"""Excel export format implementation using openpyxl."""

from __future__ import annotations

import io
from typing import Any

from data_export.formats.base import BaseExportFormat, ExportOptions

try:
    import openpyxl
    from openpyxl.utils import get_column_letter

    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


class ExcelExportFormat(BaseExportFormat):
    """Export data as an Excel .xlsx file with header styling and auto-width columns."""

    def __init__(self) -> None:
        if not HAS_OPENPYXL:
            raise ImportError(
                "openpyxl is required for Excel export. "
                "Install with: pip install willian-data-export[excel]"
            )

    @property
    def content_type(self) -> str:
        return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    @property
    def extension(self) -> str:
        return "xlsx"

    def export(self, data: list[dict[str, Any]], options: ExportOptions | None = None) -> bytes:
        """Export data rows to Excel bytes.

        Args:
            data: List of row dictionaries.
            options: Controls column mapping, sheet name, and column widths.

        Returns:
            Excel file content as bytes.
        """
        opts = options or ExportOptions()
        transformed, headers = self.apply_columns(data, opts)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = opts.sheet_name

        # Write header row with bold styling
        from openpyxl.styles import Font

        bold_font = Font(bold=True)
        for col_idx, header in enumerate(headers, start=1):
            cell = ws.cell(row=1, column=col_idx, value=header)
            cell.font = bold_font

        # Write data rows
        for row_idx, row in enumerate(transformed, start=2):
            for col_idx, header in enumerate(headers, start=1):
                ws.cell(row=row_idx, column=col_idx, value=row.get(header))

        # Auto-width columns based on content
        self._auto_width(ws, headers, transformed, opts)

        buffer = io.BytesIO()
        wb.save(buffer)
        return buffer.getvalue()

    def _auto_width(
        self,
        ws: Any,
        headers: list[str],
        data: list[dict[str, Any]],
        opts: ExportOptions,
    ) -> None:
        """Set column widths based on explicit config or content length."""
        col_configs = {col.display_header: col for col in (opts.columns or [])}

        for col_idx, header in enumerate(headers, start=1):
            config = col_configs.get(header)
            if config and config.width:
                ws.column_dimensions[get_column_letter(col_idx)].width = config.width
                continue

            # Calculate width from content
            max_len = len(str(header))
            for row in data[:100]:  # Sample first 100 rows for performance
                val = row.get(header)
                if val is not None:
                    max_len = max(max_len, len(str(val)))

            ws.column_dimensions[get_column_letter(col_idx)].width = min(max_len + 2, 50)
