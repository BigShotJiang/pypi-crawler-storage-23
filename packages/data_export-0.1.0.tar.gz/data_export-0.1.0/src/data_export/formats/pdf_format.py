"""PDF table export format implementation using reportlab."""

from __future__ import annotations

import io
from typing import Any

from data_export.formats.base import BaseExportFormat, ExportOptions

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle

    HAS_REPORTLAB = True
except ImportError:
    HAS_REPORTLAB = False


class PDFExportFormat(BaseExportFormat):
    """Export data as a PDF table using reportlab."""

    def __init__(self) -> None:
        if not HAS_REPORTLAB:
            raise ImportError(
                "reportlab is required for PDF export. "
                "Install with: pip install willian-data-export[pdf]"
            )

    @property
    def content_type(self) -> str:
        return "application/pdf"

    @property
    def extension(self) -> str:
        return "pdf"

    def export(self, data: list[dict[str, Any]], options: ExportOptions | None = None) -> bytes:
        """Export data rows to PDF bytes as a formatted table.

        Args:
            data: List of row dictionaries.
            options: Controls column mapping.

        Returns:
            PDF file content as bytes.
        """
        opts = options or ExportOptions()
        transformed, headers = self.apply_columns(data, opts)

        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=A4)
        elements: list[Any] = []

        # Build table data: header row + data rows
        table_data = [headers]
        for row in transformed:
            table_data.append([str(row.get(h, "")) for h in headers])

        table = Table(table_data)
        table.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#4472C4")),
                    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                    ("FONTSIZE", (0, 0), (-1, 0), 9),
                    ("FONTSIZE", (0, 1), (-1, -1), 8),
                    ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
                    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#D9E2F3")]),
                    ("TOPPADDING", (0, 0), (-1, -1), 4),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
                ]
            )
        )
        elements.append(table)
        doc.build(elements)

        return buffer.getvalue()
