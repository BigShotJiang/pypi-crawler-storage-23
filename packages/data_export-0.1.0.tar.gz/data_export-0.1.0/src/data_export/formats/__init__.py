"""Export format implementations."""

from data_export.formats.base import BaseExportFormat, ExportOptions
from data_export.formats.csv_format import CSVExportFormat
from data_export.formats.json_format import JSONExportFormat

__all__ = [
    "BaseExportFormat",
    "CSVExportFormat",
    "ExportOptions",
    "JSONExportFormat",
    "get_format",
]


def get_format(format_name: str) -> BaseExportFormat:
    """Return the appropriate format handler for the given format name.

    Args:
        format_name: One of 'csv', 'json', 'excel', 'pdf'.

    Returns:
        An instance of the corresponding format handler.

    Raises:
        ValueError: If the format is not supported or its optional dependency is missing.
    """
    match format_name:
        case "csv":
            return CSVExportFormat()
        case "json":
            return JSONExportFormat()
        case "excel":
            return _get_excel_format()
        case "pdf":
            return _get_pdf_format()
        case _:
            raise ValueError(f"Unsupported export format: {format_name}")


def _get_excel_format() -> BaseExportFormat:
    """Load Excel format, raising a clear error if openpyxl is missing."""
    try:
        from data_export.formats.excel import ExcelExportFormat

        return ExcelExportFormat()
    except ImportError:
        raise ValueError(
            "Excel export requires openpyxl. Install with: pip install willian-data-export[excel]"
        ) from None


def _get_pdf_format() -> BaseExportFormat:
    """Load PDF format, raising a clear error if reportlab is missing."""
    try:
        from data_export.formats.pdf_format import PDFExportFormat

        return PDFExportFormat()
    except ImportError:
        raise ValueError(
            "PDF export requires reportlab. Install with: pip install willian-data-export[pdf]"
        ) from None
