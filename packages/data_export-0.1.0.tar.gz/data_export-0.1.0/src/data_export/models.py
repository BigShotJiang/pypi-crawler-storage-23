"""Pydantic models for export, GDPR, and import operations."""

from __future__ import annotations

import enum
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, Field


class ExportFormat(str, enum.Enum):
    """Supported export output formats."""

    CSV = "csv"
    JSON = "json"
    EXCEL = "excel"
    PDF = "pdf"


class GDPRRequestType(str, enum.Enum):
    """Type of GDPR data subject request."""

    EXPORT = "export"
    DELETE = "delete"


class GDPRRequestStatus(str, enum.Enum):
    """Processing status of a GDPR request."""

    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


class ColumnConfig(BaseModel):
    """Column mapping and formatting configuration.

    Args:
        field: Source field name in the data.
        header: Display header in the export output.
        formatter: Optional callable name or format string for values.
        width: Suggested column width (used by Excel/PDF).
    """

    field: str
    header: str | None = None
    formatter: str | None = None
    width: int | None = None

    @property
    def display_header(self) -> str:
        """Return the header for display, falling back to field name."""
        return self.header or self.field


class ExportRequest(BaseModel):
    """Request to export data in a given format.

    Args:
        format: Output format (csv, json, excel, pdf).
        columns: Optional column configuration. If None, all fields are exported.
        filters: Key-value filters to pass to the query function.
        filename: Desired filename for the export output.
    """

    format: ExportFormat = ExportFormat.CSV
    columns: list[ColumnConfig] | None = None
    filters: dict[str, Any] = Field(default_factory=dict)
    filename: str | None = None


class ExportResult(BaseModel):
    """Result of an export operation.

    Args:
        data: Raw file bytes of the exported content.
        content_type: MIME type for the response (e.g. text/csv).
        filename: Suggested filename including extension.
        row_count: Number of data rows in the export.
    """

    data: bytes
    content_type: str
    filename: str
    row_count: int


class GDPRRequest(BaseModel):
    """A GDPR data subject request record.

    Args:
        user_id: The user whose data is being requested.
        request_type: Whether this is an export or deletion request.
        status: Current processing status.
        created_at: When the request was created.
        completed_at: When the request finished processing.
        details: Additional metadata about the request.
    """

    user_id: str
    request_type: GDPRRequestType
    status: GDPRRequestStatus = GDPRRequestStatus.PENDING
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: datetime | None = None
    details: dict[str, Any] = Field(default_factory=dict)


class ImportError_(BaseModel):
    """A single import validation or processing error.

    Args:
        row: The 1-indexed row number where the error occurred.
        field: The field that caused the error, if applicable.
        message: Human-readable error description.
    """

    row: int
    field: str | None = None
    message: str


class ImportResult(BaseModel):
    """Result of a bulk import operation.

    Args:
        total: Total number of rows processed.
        success: Number of rows imported successfully.
        errors: List of per-row errors encountered.
    """

    total: int
    success: int
    errors: list[ImportError_] = Field(default_factory=list)

    @property
    def failed(self) -> int:
        """Number of rows that failed."""
        return self.total - self.success
