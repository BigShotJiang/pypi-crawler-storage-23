"""Export service for orchestrating data exports."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import AsyncGenerator, Callable, Coroutine
from typing import Any

from data_export.config import ExportConfig
from data_export.formats import get_format
from data_export.formats.base import ExportOptions
from data_export.models import ColumnConfig, ExportFormat, ExportResult
from errors import NotFoundError, ValidationError

logger = logging.getLogger(__name__)


class ExportService:
    """Orchestrates data exports across all supported formats.

    Args:
        config: Export configuration.
    """

    def __init__(self, config: ExportConfig) -> None:
        self._config = config

    def export(
        self,
        data: list[dict[str, Any]],
        *,
        format: ExportFormat | str = ExportFormat.CSV,
        columns: list[ColumnConfig] | None = None,
        filename: str | None = None,
        options: ExportOptions | None = None,
    ) -> ExportResult:
        """Export data synchronously to the requested format.

        Args:
            data: List of data rows as dictionaries.
            format: Output format (csv, json, excel, pdf).
            columns: Optional column configuration for field selection/renaming.
            filename: Base filename without extension.
            options: Additional export options (delimiter, BOM, etc.).

        Returns:
            ExportResult with file bytes, content type, filename, and row count.

        Raises:
            ValueError: If row count exceeds max_rows or format is unsupported.
        """
        format_str = format.value if isinstance(format, ExportFormat) else format

        if len(data) > self._config.max_rows:
            raise ValidationError(
                f"Export exceeds maximum row limit: {len(data)} > {self._config.max_rows}"
            )

        fmt = get_format(format_str)
        opts = options or ExportOptions()
        if columns:
            opts = opts.model_copy(update={"columns": columns})

        file_bytes = fmt.export(data, opts)
        base_name = filename or "export"
        full_filename = f"{base_name}.{fmt.extension}"

        logger.info("Export completed: format=%s rows=%d size=%d", format_str, len(data), len(file_bytes))

        return ExportResult(
            data=file_bytes,
            content_type=fmt.content_type,
            filename=full_filename,
            row_count=len(data),
        )

    async def export_streaming(
        self,
        query_fn: Callable[..., Coroutine[Any, Any, list[dict[str, Any]]]],
        *,
        format: ExportFormat | str = ExportFormat.CSV,
        columns: list[ColumnConfig] | None = None,
        options: ExportOptions | None = None,
    ) -> AsyncGenerator[bytes, None]:
        """Stream data export in chunks to avoid memory bloat.

        Fetches data in pages using query_fn(offset, limit) and yields
        formatted bytes for each chunk.

        Args:
            query_fn: Async callable that accepts (offset, limit) and returns rows.
            format: Output format (csv or json supported for streaming).
            columns: Optional column configuration.
            options: Additional export options.

        Yields:
            Bytes chunks of the exported data.
        """
        format_str = format.value if isinstance(format, ExportFormat) else format
        fmt = get_format(format_str)
        opts = options or ExportOptions()
        if columns:
            opts = opts.model_copy(update={"columns": columns})

        chunk_size = self._config.streaming_chunk_size
        offset = 0
        is_first = True

        if format_str == "json":
            yield b"["

        while True:
            rows = await query_fn(offset, chunk_size)
            if not rows:
                break

            if format_str == "json":
                chunk_bytes = fmt.export(rows, opts)
                # Strip the surrounding brackets from the JSON array
                inner = chunk_bytes.strip()
                if inner.startswith(b"["):
                    inner = inner[1:]
                if inner.endswith(b"]"):
                    inner = inner[:-1]
                if not is_first:
                    yield b","
                yield inner
            else:
                if is_first:
                    # First chunk includes header
                    yield fmt.export(rows, opts)
                else:
                    # Subsequent chunks: export without header, then strip header line
                    chunk_bytes = fmt.export(rows, opts)
                    lines = chunk_bytes.split(b"\n", 1)
                    if len(lines) > 1:
                        yield lines[1]

            is_first = False
            offset += chunk_size

            if len(rows) < chunk_size:
                break

        if format_str == "json":
            yield b"]"

        logger.info("Streaming export completed: format=%s total_offset=%d", format_str, offset)

    async def schedule_export(
        self,
        data: list[dict[str, Any]],
        *,
        format: ExportFormat | str = ExportFormat.CSV,
        columns: list[ColumnConfig] | None = None,
        filename: str | None = None,
        options: ExportOptions | None = None,
        notify_fn: Callable[[ExportResult], Coroutine[Any, Any, None]] | None = None,
    ) -> asyncio.Task[ExportResult]:
        """Schedule an export to run in the background with an optional callback.

        Args:
            data: Data rows to export.
            format: Output format.
            columns: Optional column configuration.
            filename: Base filename.
            options: Additional export options.
            notify_fn: Async callback invoked with the result when export completes.

        Returns:
            An asyncio.Task that resolves to the ExportResult.
        """

        async def _run() -> ExportResult:
            result = self.export(
                data, format=format, columns=columns, filename=filename, options=options
            )
            if notify_fn is not None:
                await notify_fn(result)
            return result

        task = asyncio.create_task(_run())
        logger.info("Scheduled background export: format=%s", format)
        return task
