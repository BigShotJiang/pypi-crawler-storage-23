"""
Substr8 Platform CLI - Verifiable AI Infrastructure

Components:
- GAM: Git-Native Agent Memory
- FDAA: File-Driven Agent Architecture (planned)
- ACC: Agent Capability Control (planned)

Usage:
    substr8 gam init
    substr8 gam remember "fact"
    substr8 gam recall "query"
"""

__version__ = "1.0.0"
