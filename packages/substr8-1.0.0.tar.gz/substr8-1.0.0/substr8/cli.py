"""
Substr8 CLI - Unified command-line interface

Usage:
    substr8 gam <command>      Git-Native Agent Memory
    substr8 fdaa <command>     File-Driven Agent Architecture (planned)
    substr8 acc <command>      Agent Capability Control (planned)
"""

import click
from rich.console import Console

console = Console()


@click.group()
@click.version_option(version="0.1.0", prog_name="substr8")
def main():
    """Substr8 Platform CLI - Verifiable AI Infrastructure"""
    pass


# === GAM Integration ===

from substr8.gam.cli import main as gam_main

# Register GAM as a subcommand group
main.add_command(gam_main, name="gam")


# === FDAA Placeholder ===

@main.group()
def fdaa():
    """File-Driven Agent Architecture (coming soon)"""
    pass


@fdaa.command("status")
def fdaa_status():
    """Show FDAA status."""
    console.print("[yellow]FDAA CLI coming soon.[/yellow]")
    console.print("See: https://github.com/Substr8-Labs/fdaa")


# === ACC Placeholder ===

@main.group()
def acc():
    """Agent Capability Control (coming soon)"""
    pass


@acc.command("status")
def acc_status():
    """Show ACC status."""
    console.print("[yellow]ACC CLI coming soon.[/yellow]")
    console.print("See: https://github.com/Substr8-Labs/acc")


# === Info Commands ===

@main.command()
def info():
    """Show Substr8 platform information."""
    from rich.panel import Panel
    from rich.table import Table
    
    table = Table(show_header=False, box=None)
    table.add_column("Component", style="cyan")
    table.add_column("Status", style="green")
    table.add_column("Description")
    
    # Check GAM (bundled)
    try:
        from substr8.gam import __version__ as gam_version
        gam_status = f"✅ v{gam_version}"
    except ImportError:
        gam_status = "✅ bundled"
    
    table.add_row("GAM", gam_status, "Git-Native Agent Memory")
    table.add_row("FDAA", "🔜 planned", "File-Driven Agent Architecture")
    table.add_row("ACC", "🔜 planned", "Agent Capability Control")
    
    console.print(Panel(
        table,
        title="[bold]Substr8 Platform v1.0.0[/bold]",
        subtitle="https://substr8labs.com",
    ))


if __name__ == "__main__":
    main()
