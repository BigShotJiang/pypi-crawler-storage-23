"""
GAM CLI - Git-Native Agent Memory Command Line Interface

Usage:
    gam init [path]           Initialize GAM repository
    gam remember <content>    Store a new memory
    gam recall <query>        Search memories
    gam verify <id>           Verify memory provenance
    gam forget <id>           Delete a memory
    gam status                Show repository status
"""

import base64
import sys
from pathlib import Path
from typing import Optional

import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.markdown import Markdown

from .core import (
    GAMRepository,
    MemoryMetadata,
    init_gam,
    open_gam,
)
from .identity import IdentityManager, HAS_CRYPTO
from .permissions import PermissionManager, PermissionLevel, PathPolicy

console = Console()


def find_repo(path: Optional[str] = None) -> GAMRepository:
    """Find and open GAM repository."""
    search = Path(path) if path else Path.cwd()
    
    # Walk up to find .gam directory
    current = search.resolve()
    while current != current.parent:
        if (current / ".gam").exists():
            return open_gam(current)
        current = current.parent
    
    # Check if current dir is a git repo we can init
    if (search / ".git").exists():
        return init_gam(search)
    
    console.print("[red]Not a GAM repository (no .gam found)[/red]")
    console.print("Run 'gam init' to initialize.")
    sys.exit(1)


@click.group()
@click.version_option(version="0.1.0")
def main():
    """GAM - Git-Native Agent Memory"""
    pass


@main.command()
@click.argument("path", default=".", required=False)
def init(path: str):
    """Initialize a GAM repository."""
    target = Path(path).resolve()
    
    if (target / ".gam").exists():
        console.print(f"[yellow]GAM already initialized at {target}[/yellow]")
        return
    
    try:
        repo = init_gam(target)
        console.print(f"[green]✓ GAM initialized at {target}[/green]")
        console.print(f"  Config: {repo.gam_dir / 'config.yaml'}")
    except Exception as e:
        console.print(f"[red]Failed to initialize: {e}[/red]")
        sys.exit(1)


@main.command()
@click.argument("content")
@click.option("--title", "-t", help="Memory title")
@click.option("--source", "-s", 
              type=click.Choice(["conversation", "observation", "user", "inferred", "import"]),
              default="user", help="Source type")
@click.option("--confidence", "-c",
              type=click.Choice(["high", "medium", "low"]),
              default="medium", help="Confidence level")
@click.option("--classification",
              type=click.Choice(["private", "shared", "public"]),
              default="private", help="Classification")
@click.option("--tag", "-T", multiple=True, help="Tags (can be repeated)")
@click.option("--related", "-r", multiple=True, help="Related paths (can be repeated)")
@click.option("--permanent", is_flag=True, help="Mark as decay-exempt")
def remember(
    content: str,
    title: Optional[str],
    source: str,
    confidence: str,
    classification: str,
    tag: tuple,
    related: tuple,
    permanent: bool,
):
    """Store a new memory."""
    repo = find_repo()
    
    metadata = MemoryMetadata(
        source=source,
        confidence=confidence,
        classification=classification,
        tags=list(tag),
        related=list(related),
        decay_exempt=permanent,
    )
    
    try:
        memory = repo.remember(content, title=title, metadata=metadata)
        
        console.print(Panel(
            f"[green]Memory stored successfully[/green]\n\n"
            f"ID: [cyan]{memory.id}[/cyan]\n"
            f"File: {memory.file_path}\n"
            f"Commit: [dim]{memory.commit_sha[:8]}[/dim]",
            title="✓ Remembered"
        ))
    except Exception as e:
        console.print(f"[red]Failed to remember: {e}[/red]")
        sys.exit(1)


@main.command()
@click.argument("query")
@click.option("--limit", "-n", default=10, help="Maximum results")
@click.option("--classification",
              type=click.Choice(["private", "shared", "public"]),
              help="Filter by classification")
@click.option("--verbose", "-v", is_flag=True, help="Show full content")
@click.option("--semantic", "-s", is_flag=True, help="Use semantic (embedding) search")
def recall(query: str, limit: int, classification: Optional[str], verbose: bool, semantic: bool):
    """Search memories."""
    repo = find_repo()
    
    try:
        if semantic:
            results = repo.recall_semantic(query, limit=limit, classification=classification)
        else:
            results = repo.recall(query, limit=limit, classification=classification)
        
        if not results:
            console.print("[yellow]No memories found matching query.[/yellow]")
            return
        
        table = Table(title=f"Memories matching: {query}")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("File", style="dim")
        table.add_column("Content", max_width=60)
        table.add_column("Source", style="green")
        table.add_column("Created", style="blue")
        
        for mem in results:
            content_preview = mem.content[:100].replace("\n", " ")
            if len(mem.content) > 100:
                content_preview += "..."
            
            table.add_row(
                mem.id[-12:],  # Last 12 chars for readability
                mem.file_path,
                content_preview if not verbose else mem.content[:200],
                mem.metadata.source,
                mem.created_at.strftime("%Y-%m-%d"),
            )
        
        console.print(table)
        console.print(f"\n[dim]Found {len(results)} memories[/dim]")
        
    except Exception as e:
        console.print(f"[red]Failed to recall: {e}[/red]")
        sys.exit(1)


@main.command()
@click.argument("memory_id")
def verify(memory_id: str):
    """Verify memory provenance."""
    repo = find_repo()
    
    try:
        result = repo.verify(memory_id)
        
        if result.valid:
            lineage_str = " → ".join(result.lineage[:5])
            if len(result.lineage) > 5:
                lineage_str += f" ... (+{len(result.lineage) - 5} more)"
            
            console.print(Panel(
                f"[green]Memory verified[/green]\n\n"
                f"Commit: [cyan]{result.commit_sha[:8]}[/cyan]\n"
                f"Author: {result.author}\n"
                f"Timestamp: {result.timestamp}\n"
                f"Signature: {'✓ Valid' if result.signature_valid else '○ Not signed'}\n"
                f"Lineage: [dim]{lineage_str}[/dim]",
                title="✓ Verified"
            ))
        else:
            console.print(Panel(
                f"[red]Verification failed[/red]\n\n"
                f"Reason: {result.reason}",
                title="✗ Invalid"
            ))
            
    except Exception as e:
        console.print(f"[red]Verification error: {e}[/red]")
        sys.exit(1)


@main.command()
@click.argument("memory_id")
@click.option("--reason", "-r", default="User requested", help="Reason for deletion")
@click.option("--hard", is_flag=True, help="Rewrite history (for PII)")
@click.confirmation_option(prompt="Are you sure you want to forget this memory?")
def forget(memory_id: str, reason: str, hard: bool):
    """Delete a memory."""
    repo = find_repo()
    
    try:
        success = repo.forget(memory_id, reason=reason, hard=hard)
        
        if success:
            console.print(f"[green]✓ Memory {memory_id} forgotten[/green]")
        else:
            console.print(f"[yellow]Memory {memory_id} not found[/yellow]")
            
    except NotImplementedError as e:
        console.print(f"[yellow]{e}[/yellow]")
    except Exception as e:
        console.print(f"[red]Failed to forget: {e}[/red]")
        sys.exit(1)


@main.command()
def status():
    """Show GAM repository status."""
    repo = find_repo()
    
    # Count memories
    memory_count = 0
    file_count = 0
    for pattern in ["MEMORY.md", "memory/**/*.md"]:
        for file_path in repo.path.glob(pattern):
            if ".gam" in str(file_path):
                continue
            file_count += 1
            memories = repo._parse_memory_file(file_path)
            memory_count += len(memories)
    
    # Git status
    git_status = "clean" if not repo.repo.is_dirty() else "dirty"
    branch = repo.repo.active_branch.name
    
    # Recent commits
    recent = list(repo.repo.iter_commits(max_count=3))
    
    console.print(Panel(
        f"[cyan]GAM Repository Status[/cyan]\n\n"
        f"Path: {repo.path}\n"
        f"Branch: {branch} ({git_status})\n"
        f"Memories: {memory_count} in {file_count} files\n\n"
        f"[dim]Recent commits:[/dim]",
        title="📦 GAM"
    ))
    
    for commit in recent:
        console.print(f"  [dim]{commit.hexsha[:8]}[/dim] {commit.message.split(chr(10))[0]}")


@main.command()
def reindex():
    """Rebuild all indexes from memory files."""
    repo = find_repo()
    
    try:
        count = repo.rebuild_index()
        console.print(f"[green]✓ Indexed {count} memories[/green]")
    except Exception as e:
        console.print(f"[red]Failed to reindex: {e}[/red]")
        sys.exit(1)


@main.command("import")
@click.argument("pattern", default="memory/*.md")
@click.option("--source", "-s", default="import", help="Source type for imported memories")
@click.option("--dry-run", is_flag=True, help="Show what would be imported")
def import_memories(pattern: str, source: str, dry_run: bool):
    """Import existing markdown files into GAM index.
    
    This indexes files without GAM frontmatter, treating each file
    or each H2 section as a separate memory.
    """
    repo = find_repo()
    
    import re
    from datetime import datetime, timezone
    
    count = 0
    for file_path in repo.path.glob(pattern):
        if ".gam" in str(file_path) or file_path.name.startswith("."):
            continue
        
        content = file_path.read_text()
        rel_path = str(file_path.relative_to(repo.path))
        
        # Split by H2 sections if present
        sections = re.split(r'^## ', content, flags=re.MULTILINE)
        
        if len(sections) > 1:
            # Has H2 sections - index each as separate memory
            # First section is the title/intro
            intro = sections[0].strip()
            
            for i, section in enumerate(sections[1:], 1):
                lines = section.split('\n', 1)
                title = lines[0].strip()
                body = lines[1].strip() if len(lines) > 1 else ""
                
                # Generate deterministic ID from file + section
                section_id = f"{file_path.stem}_{i}"
                memory_id = f"mem_import_{section_id}"
                
                if dry_run:
                    console.print(f"[dim]Would import:[/dim] {memory_id} - {title[:50]}")
                else:
                    # Index in temporal index
                    repo.index.temporal.index_memory(
                        memory_id=memory_id,
                        file_path=rel_path,
                        content=f"## {title}\n{body}",
                        source=source,
                    )
                count += 1
        else:
            # No sections - index whole file
            memory_id = f"mem_import_{file_path.stem}"
            
            if dry_run:
                console.print(f"[dim]Would import:[/dim] {memory_id} - {file_path.name}")
            else:
                repo.index.temporal.index_memory(
                    memory_id=memory_id,
                    file_path=rel_path,
                    content=content,
                    source=source,
                )
            count += 1
    
    if dry_run:
        console.print(f"\n[yellow]Dry run: would import {count} memories[/yellow]")
    else:
        console.print(f"[green]✓ Imported {count} memories[/green]")


@main.command()
@click.argument("memory_id")
def show(memory_id: str):
    """Show a specific memory."""
    repo = find_repo()
    
    # Find the memory
    for pattern in ["MEMORY.md", "memory/**/*.md"]:
        for file_path in repo.path.glob(pattern):
            if ".gam" in str(file_path):
                continue
            memories = repo._parse_memory_file(file_path)
            for mem in memories:
                if mem.id == memory_id or mem.id.endswith(memory_id):
                    console.print(Panel(
                        Markdown(mem.content),
                        title=f"Memory: {mem.id}",
                        subtitle=f"{mem.file_path} | {mem.metadata.source} | {mem.metadata.confidence}"
                    ))
                    return
    
    console.print(f"[yellow]Memory {memory_id} not found[/yellow]")


@main.group()
def identity():
    """Manage cryptographic identities."""
    pass


@identity.command("init")
@click.option("--passphrase", "-p", prompt=True, hide_input=True,
              confirmation_prompt=True, help="Master seed passphrase")
def identity_init(passphrase: str):
    """Initialize master seed for agent key derivation."""
    if not HAS_CRYPTO:
        console.print("[red]cryptography package required. Install with: pip install cryptography[/red]")
        sys.exit(1)
    
    repo = find_repo()
    manager = IdentityManager(repo.gam_dir)
    
    try:
        manager.init_master_seed(passphrase)
        console.print("[green]✓ Master seed initialized[/green]")
        console.print("[dim]Note: You'll need to provide this passphrase each session.[/dim]")
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")
        sys.exit(1)


@identity.command("create-agent")
@click.argument("name")
@click.option("--index", "-i", default=0, help="Agent index for key derivation")
@click.option("--passphrase", "-p", prompt=True, hide_input=True,
              help="Master seed passphrase")
def identity_create_agent(name: str, index: int, passphrase: str):
    """Create a new agent identity with DID."""
    if not HAS_CRYPTO:
        console.print("[red]cryptography package required. Install with: pip install cryptography[/red]")
        sys.exit(1)
    
    repo = find_repo()
    manager = IdentityManager(repo.gam_dir)
    manager.init_master_seed(passphrase)
    
    try:
        agent = manager.create_agent(name, index)
        
        console.print(Panel(
            f"[green]Agent identity created[/green]\n\n"
            f"Name: [cyan]{agent.name}[/cyan]\n"
            f"DID: [dim]{agent.did}[/dim]\n"
            f"Path: {agent.derivation_path}",
            title="🤖 Agent Identity"
        ))
    except Exception as e:
        console.print(f"[red]Failed: {e}[/red]")
        sys.exit(1)


@identity.command("list")
def identity_list():
    """List all identities."""
    repo = find_repo()
    manager = IdentityManager(repo.gam_dir)
    
    agents = manager.list_agents()
    human = manager.get_human()
    
    if not agents and not human:
        console.print("[yellow]No identities configured.[/yellow]")
        console.print("Run 'gam identity create-agent <name>' to create an agent identity.")
        return
    
    table = Table(title="Identities")
    table.add_column("Type", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("ID", style="dim", max_width=50)
    
    if human:
        table.add_row("👤 Human", human.name, f"GPG: {human.key_id}")
    
    for agent in agents:
        table.add_row("🤖 Agent", agent.name, agent.did[:50] + "...")
    
    console.print(table)


@identity.command("register-human")
def identity_register_human():
    """Register human GPG identity."""
    repo = find_repo()
    manager = IdentityManager(repo.gam_dir)
    
    # Try to detect GPG key
    detected = manager.detect_gpg_key()
    
    if detected:
        console.print(f"[green]Detected GPG key:[/green] {detected['key_id']}")
        console.print(f"[dim]{detected['uid']}[/dim]")
        
        if click.confirm("Use this key?"):
            # Parse uid for name and email
            uid = detected['uid']
            name = uid.split("<")[0].strip() if "<" in uid else uid
            email = uid.split("<")[1].rstrip(">") if "<" in uid else ""
            
            human = manager.register_human(
                key_id=detected['key_id'],
                email=email,
                name=name,
                fingerprint=detected['key_id'],
            )
            console.print(f"[green]✓ Registered human identity: {human.name}[/green]")
            return
    
    # Manual entry
    key_id = click.prompt("GPG Key ID")
    name = click.prompt("Name")
    email = click.prompt("Email")
    
    human = manager.register_human(
        key_id=key_id,
        email=email,
        name=name,
        fingerprint=key_id,
    )
    console.print(f"[green]✓ Registered human identity: {human.name}[/green]")


@main.group()
def permissions():
    """Manage path-based permissions."""
    pass


@permissions.command("list")
def permissions_list():
    """List all permission policies."""
    repo = find_repo()
    
    table = Table(title="Permission Policies")
    table.add_column("Pattern", style="cyan")
    table.add_column("Permission", style="green")
    table.add_column("Description", style="dim", max_width=40)
    
    for policy in repo.permissions.config.policies:
        perm_color = {
            PermissionLevel.HUMAN_SIGN: "red",
            PermissionLevel.AGENT_SIGN: "yellow",
            PermissionLevel.OPEN: "green",
            PermissionLevel.READONLY: "dim",
        }.get(policy.permission, "white")
        
        table.add_row(
            policy.pattern,
            f"[{perm_color}]{policy.permission.value}[/{perm_color}]",
            policy.description,
        )
    
    console.print(table)
    console.print(f"\n[dim]Default: {repo.permissions.config.default_permission.value}[/dim]")


@permissions.command("check")
@click.argument("path")
def permissions_check(path: str):
    """Check permission for a path."""
    repo = find_repo()
    
    perm = repo.permissions.config.get_permission(path)
    
    perm_info = {
        PermissionLevel.HUMAN_SIGN: ("🔒", "red", "Human GPG signature required"),
        PermissionLevel.AGENT_SIGN: ("🤖", "yellow", "Agent DID signature required"),
        PermissionLevel.OPEN: ("✅", "green", "Open - no signature required"),
        PermissionLevel.READONLY: ("🚫", "dim", "Read-only - no writes allowed"),
    }
    
    emoji, color, desc = perm_info.get(perm, ("?", "white", "Unknown"))
    
    console.print(Panel(
        f"{emoji} [bold {color}]{perm.value.upper()}[/bold {color}]\n\n"
        f"Path: {path}\n"
        f"Meaning: {desc}",
        title="Permission Check"
    ))


@permissions.command("add")
@click.argument("pattern")
@click.option("--level", "-l", 
              type=click.Choice(["open", "agent", "human", "readonly"]),
              required=True, help="Permission level")
@click.option("--description", "-d", default="", help="Policy description")
def permissions_add(pattern: str, level: str, description: str):
    """Add a permission policy."""
    repo = find_repo()
    
    perm_map = {
        "open": PermissionLevel.OPEN,
        "agent": PermissionLevel.AGENT_SIGN,
        "human": PermissionLevel.HUMAN_SIGN,
        "readonly": PermissionLevel.READONLY,
    }
    
    repo.permissions.add_policy(pattern, perm_map[level], description)
    console.print(f"[green]✓ Added policy: {pattern} → {level}[/green]")


@permissions.command("remove")
@click.argument("pattern")
def permissions_remove(pattern: str):
    """Remove a permission policy."""
    repo = find_repo()
    
    if repo.permissions.remove_policy(pattern):
        console.print(f"[green]✓ Removed policy: {pattern}[/green]")
    else:
        console.print(f"[yellow]Policy not found: {pattern}[/yellow]")


@permissions.command("hitl")
def permissions_hitl():
    """Show paths requiring human-in-the-loop signature."""
    repo = find_repo()
    
    hitl_paths = repo.permissions.get_hitl_paths()
    
    if not hitl_paths:
        console.print("[green]No paths require human signature.[/green]")
        return
    
    console.print("[bold red]🔒 Human-in-the-Loop Required:[/bold red]\n")
    for policy in hitl_paths:
        console.print(f"  • {policy.pattern}")
        if policy.description:
            console.print(f"    [dim]{policy.description}[/dim]")


@identity.command("sign")
@click.argument("memory_id")
@click.option("--agent", "-a", help="Agent name to sign with")
@click.option("--passphrase", "-p", help="Master seed passphrase (for agent signing)")
def identity_sign(memory_id: str, agent: Optional[str], passphrase: Optional[str]):
    """Sign a memory with an identity."""
    repo = find_repo()
    manager = IdentityManager(repo.gam_dir)
    
    if agent:
        if not passphrase:
            passphrase = click.prompt("Master seed passphrase", hide_input=True)
        
        manager.init_master_seed(passphrase)
        agent_identity = manager.get_agent(agent)
        
        if not agent_identity:
            console.print(f"[red]Agent '{agent}' not found[/red]")
            sys.exit(1)
        
        # Sign the memory ID as proof
        signature = agent_identity.sign(memory_id.encode())
        sig_b64 = base64.b64encode(signature).decode()
        
        console.print(Panel(
            f"[green]Memory signed[/green]\n\n"
            f"Memory: {memory_id}\n"
            f"Signer: {agent_identity.did[:40]}...\n"
            f"Signature: [dim]{sig_b64[:40]}...[/dim]",
            title="✍️ Signed"
        ))
    else:
        console.print("[yellow]GPG signing not yet implemented in CLI.[/yellow]")
        console.print("Use: git commit -S -m 'message' for GPG-signed commits.")


if __name__ == "__main__":
    main()
