"""
GAM - Git-Native Agent Memory

Verifiable, auditable memory for AI agents using git primitives.
"""

from .core import (
    GAMRepository,
    Memory, 
    MemoryMetadata,
    VerificationResult,
    init_gam,
    open_gam,
)
from .index import (
    GAMIndex,
    TemporalIndex,
    SemanticIndex,
    ScoredMemory,
    HAS_EMBEDDINGS,
)
from .identity import (
    AgentIdentity,
    HumanIdentity,
    IdentityManager,
    create_did_key,
    verify_agent_signature,
    verify_git_commit_signature,
    HAS_CRYPTO,
)
from .sparse import (
    enable_sparse_checkout,
    disable_sparse_checkout,
    setup_partial_clone,
    is_sparse_enabled,
    get_sparse_patterns,
)
from .permissions import (
    PermissionLevel,
    PathPolicy,
    PermissionConfig,
    PermissionManager,
)

__version__ = "0.1.0"
__all__ = [
    "GAMRepository",
    "Memory", 
    "MemoryMetadata",
    "VerificationResult",
    "init_gam",
    "open_gam",
    "GAMIndex",
    "TemporalIndex",
    "SemanticIndex",
    "ScoredMemory",
    "HAS_EMBEDDINGS",
]
