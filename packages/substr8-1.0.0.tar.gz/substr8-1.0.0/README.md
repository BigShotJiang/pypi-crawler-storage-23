# Substr8 CLI

Unified command-line interface for the Substr8 Platform.

## Installation

```bash
# Core CLI
pip install substr8

# With GAM (Git-Native Agent Memory)
pip install substr8[gam]

# Everything
pip install substr8[full]
```

## Usage

```bash
# Show platform status
substr8 info

# Git-Native Agent Memory
substr8 gam init
substr8 gam remember "Important fact" --tag knowledge
substr8 gam recall "important"
substr8 gam verify <memory-id>

# Identity management
substr8 gam identity create-agent ada --passphrase <secret>
substr8 gam identity list

# Permissions (W^X)
substr8 gam permissions list
substr8 gam permissions check SOUL.md
substr8 gam permissions hitl
```

## Components

| Command | Description | Status |
|---------|-------------|--------|
| `substr8 gam` | Git-Native Agent Memory | ✅ Available |
| `substr8 fdaa` | File-Driven Agent Architecture | 🔜 Planned |
| `substr8 acc` | Agent Capability Control | 🔜 Planned |

## Documentation

- [GAM Whitepaper](docs/whitepapers/GIT-NATIVE-AGENT-MEMORY.md)
- [FDAA Specification](https://fdaa.substr8labs.com)
- [Substr8 Platform](https://substr8labs.com)

## License

MIT - Substr8 Labs
