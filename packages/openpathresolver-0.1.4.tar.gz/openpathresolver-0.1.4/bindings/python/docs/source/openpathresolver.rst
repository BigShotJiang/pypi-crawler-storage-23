openpathresolver package
========================

Module contents
---------------

.. automodule:: openpathresolver
   :members:
   :undoc-members:
   :show-inheritance:
