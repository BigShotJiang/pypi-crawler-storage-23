> **Navigation**: [Home](../INDEX.md) > DB Split

# FK Audit: omnimemory (OMN-2069)

**Audit Date**: 2026-02-10
**Parent Ticket**: OMN-2054 (DB-SPLIT-03)
**Scope**: All migration files in `deployment/database/migrations/`

## Migration Files Scanned

| File | Tables Created | FK Count |
|------|---------------|----------|
| `001_create_subscription_tables.sql` | `subscriptions` | 0 |
| `002_create_memories_table.sql` | `memories` | 0 |

**Total migrations scanned**: 2
**Total tables**: 2
**Total FOREIGN KEY / REFERENCES found**: 0

## Tables Owned by omnimemory

| Table | Notable Constraints (excl. NOT NULL / DEFAULT) | Notes |
|-------|--------------------------------------------------|-------|
| `subscriptions` | `UNIQUE(agent_id, topic)`, `CHECK(status)` | No FKs |
| `memories` | `CHECK(lifecycle_state)` | No FKs |

## Cross-Service FK Violations

**None found.** Neither table references any external table via `FOREIGN KEY` or `REFERENCES`.

## Scan Methodology

1. Searched all `.sql` files under `deployment/database/migrations/` for `REFERENCES` and `FOREIGN KEY` keywords
2. Searched all Python source files under `src/` for `ForeignKey`, `ForeignKeyConstraint`, and `foreign_key`
3. Verified no SQLAlchemy ORM model definitions declare FK relationships

## Resolution Plans

No resolution plans needed — omnimemory has zero foreign key constraints. All tables are fully self-contained within the service boundary.
