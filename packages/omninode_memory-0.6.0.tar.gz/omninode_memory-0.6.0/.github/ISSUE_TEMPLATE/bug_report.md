---
name: Bug Report
about: Report a reproducible bug
title: '[Bug] '
labels: bug
---
## Describe the bug
## To Reproduce
## Expected behavior
## Environment
- OS:
- Python:
- Package version:
