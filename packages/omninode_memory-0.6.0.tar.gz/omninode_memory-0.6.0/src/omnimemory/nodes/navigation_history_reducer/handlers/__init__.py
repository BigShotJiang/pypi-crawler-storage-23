# SPDX-License-Identifier: MIT
# Copyright (c) 2025 OmniNode Team
"""Navigation History Reducer - handlers package."""

from .handler_navigation_history_reducer import (
    HandlerNavigationHistoryReducer,
    HandlerNavigationHistoryWriter,
)

__all__ = ["HandlerNavigationHistoryReducer", "HandlerNavigationHistoryWriter"]
