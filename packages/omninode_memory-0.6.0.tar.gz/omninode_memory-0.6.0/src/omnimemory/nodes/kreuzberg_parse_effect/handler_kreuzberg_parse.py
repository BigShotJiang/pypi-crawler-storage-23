# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

# Copyright (c) 2025 OmniNode Team
"""KreuzbergParse handler: calls kreuzberg HTTP service to extract text from documents.

Architecture:
    This handler implements the kreuzberg parse step described in OMN-2733.
    It consumes document-discovered and document-changed events, calls the
    kreuzberg REST API to extract plain text, and emits either
    document-indexed (kreuzberg variant) or document-parse-failed events.

    Hard Limits:
        - Documents > max_doc_bytes (default 50 MB): emit parse-failed with
          error_code=too_large without calling kreuzberg.
        - Requests exceeding timeout_ms (default 30 s): emit parse-failed
          with error_code=timeout.
        - HTTP errors from kreuzberg: emit parse-failed with error_code=parse_error.

    Idempotency:
        Before calling kreuzberg, check if a text file already exists at
        <text_store_path>/<sha256_of_source_url>.txt. If so, compare the
        stored content_fingerprint (first line of the file, prefix "fingerprint:").
        If the fingerprint matches event.content_fingerprint, re-emit the
        indexed event without re-parsing and return immediately.

    Text Storage:
        Texts shorter than inline_text_max_chars are stored inline in
        extracted_text_ref. Longer texts are written to disk and referenced
        as "file://<absolute_path>".

    Document ID:
        Computed as UUID from the first 16 bytes of
        sha256(source_url + content_hash + parser_version).

Example::

    from omnimemory.nodes.kreuzberg_parse_effect.handler_kreuzberg_parse import (
        HandlerKreuzbergParse,
    )
    from omnimemory.nodes.kreuzberg_parse_effect.models import ModelKreuzbergParseConfig

    config = ModelKreuzbergParseConfig(
        kreuzberg_url="http://localhost:8090",
        text_store_path="/tmp/kreuzberg_texts",
        parser_version="1.0.0",
    )
    handler = HandlerKreuzbergParse(config=config)
    await handler.process_event(event=event, env_prefix="dev", publish_callback=cb)

.. versionadded:: 0.5.0
    Initial implementation for OMN-2733.
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import mimetypes
import uuid
from collections.abc import Callable, Coroutine
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING, Any
from uuid import UUID

from omnimemory.models.crawl.model_document_indexed_kreuzberg_event import (
    ModelDocumentIndexedKreuzbergEvent,
)
from omnimemory.models.crawl.model_document_parse_failed_event import (
    ModelDocumentParseFailedEvent,
)
from omnimemory.nodes.kreuzberg_parse_effect.clients.client_kreuzberg import (
    KreuzbergExtractionError,
    KreuzbergTimeoutError,
    call_kreuzberg_extract,
    read_cached_text,
    write_cached_text,
)
from omnimemory.nodes.kreuzberg_parse_effect.models.model_kreuzberg_parse_result import (
    ModelKreuzbergParseResult,
)

if TYPE_CHECKING:
    from omnimemory.models.crawl.model_document_changed_event import (
        ModelDocumentChangedEvent,
    )
    from omnimemory.models.crawl.model_document_discovered_event import (
        ModelDocumentDiscoveredEvent,
    )
    from omnimemory.nodes.kreuzberg_parse_effect.models.model_kreuzberg_parse_config import (
        ModelKreuzbergParseConfig,
    )

_log = logging.getLogger(__name__)


def _validate_source_path(source_url: str, document_root: Path) -> Path:
    """Validate that source_url resolves to a path within document_root.

    Raises:
        ValueError: If source_url is absolute and outside document_root, or
            contains ``..`` components that would escape document_root.
    """
    candidate = Path(source_url)
    # Resolve relative to document_root so that relative paths are anchored.
    if not candidate.is_absolute():
        resolved = (document_root / candidate).resolve()
    else:
        resolved = candidate.resolve()

    # Ensure the resolved path is within the document root.
    try:
        resolved.relative_to(document_root.resolve())
    except ValueError:
        raise ValueError(
            f"source_url {source_url!r} resolves to {resolved} which is outside "
            f"the permitted document root {document_root.resolve()}"
        )
    return resolved


def _compute_document_id(
    source_url: str,
    content_hash: str,
    parser_version: str,
) -> UUID:
    """Compute a stable document UUID from source_url, content_hash, and parser_version.

    Uses the first 16 bytes of sha256(source_url + content_hash + parser_version)
    formatted as a UUID v4-like identifier.
    """
    raw = (source_url + content_hash + parser_version).encode("utf-8")
    digest = hashlib.sha256(raw).digest()
    return uuid.UUID(bytes=digest[:16])


def _source_url_slug(source_url: str) -> str:
    """Compute sha256 hex of source_url for use as a filename component."""
    return hashlib.sha256(source_url.encode("utf-8")).hexdigest()


def _detect_mime_type(source_url: str) -> str:
    """Best-effort MIME type detection from source URL/path."""
    mime, _ = mimetypes.guess_type(source_url)
    return mime or "application/octet-stream"


class HandlerKreuzbergParse:
    """Handler that calls kreuzberg to extract text from documents.

    This handler is stateless except for the injected configuration.
    All I/O is async; filesystem operations run via asyncio.to_thread.
    """

    def __init__(self, config: ModelKreuzbergParseConfig) -> None:
        self._config = config

    async def process_event(
        self,
        event: ModelDocumentDiscoveredEvent | ModelDocumentChangedEvent,
        env_prefix: str,
        publish_callback: Callable[[str, dict[str, object]], Coroutine[Any, Any, None]],
    ) -> ModelKreuzbergParseResult:
        """Process a single document discovered or changed event.

        Args:
            event: The triggering document event carrying source_ref and
                content_fingerprint.
            env_prefix: Environment prefix used to build fully-qualified
                topic names (e.g. "dev", "prod").
            publish_callback: Async callable that accepts (topic, payload_dict)
                and publishes the message to the event bus.

        Returns:
            ModelKreuzbergParseResult summarising the outcome of this
            invocation (counts for indexed, failed, too_large, timeout).
        """
        source_url = event.source_ref
        content_hash = event.content_fingerprint
        config = self._config

        indexed_topic = (
            f"{env_prefix}.{config.publish_topic_indexed}"
            if env_prefix
            else config.publish_topic_indexed
        )
        failed_topic = (
            f"{env_prefix}.{config.publish_topic_parse_failed}"
            if env_prefix
            else config.publish_topic_parse_failed
        )
        now = datetime.now(tz=timezone.utc)

        # ------------------------------------------------------------------
        # Step 1: Validate source path is within document root
        # ------------------------------------------------------------------
        document_root = Path(config.document_root)
        if str(document_root) == "/":
            _log.warning(
                "document_root is set to filesystem root ('/'). "
                "Set KREUZBERG_DOCUMENT_ROOT to a tighter path in production."
            )
        try:
            validated_path = _validate_source_path(source_url, document_root)
        except ValueError as exc:
            _log.warning(
                "Invalid source_ref path rejected",
                extra={"source_url": source_url, "error": str(exc)},
            )
            failed_event = ModelDocumentParseFailedEvent(
                correlation_id=event.correlation_id,
                emitted_at_utc=now,
                source_url=source_url,
                content_hash=content_hash,
                error_code="parse_error",
                error_detail=f"Invalid source_ref path: {exc}",
                parser_version=config.parser_version,
            )
            await publish_callback(failed_topic, failed_event.model_dump(mode="json"))
            return ModelKreuzbergParseResult(
                indexed_count=0,
                failed_count=1,
                skipped_too_large_count=0,
                timeout_count=0,
            )

        # ------------------------------------------------------------------
        # Step 2: Idempotency check — skip re-parse if text already stored.
        # This check uses only source_url (for the cache slug) and
        # event.content_fingerprint, so no file read is required yet.
        # ------------------------------------------------------------------
        slug = _source_url_slug(source_url)
        text_store = Path(config.text_store_path)
        text_path = text_store / f"{slug}.txt"

        cached = await asyncio.to_thread(read_cached_text, text_path)
        if cached is not None:
            stored_fingerprint, cached_text = cached
            if stored_fingerprint == content_hash:
                _log.debug(
                    "Idempotent: re-emitting indexed event without re-parsing",
                    extra={"source_url": source_url},
                )
                document_id = _compute_document_id(
                    source_url, content_hash, config.parser_version
                )
                extracted_text_ref = (
                    cached_text
                    if len(cached_text) < config.inline_text_max_chars
                    else f"file://{text_path.resolve()}"
                )
                indexed_event = ModelDocumentIndexedKreuzbergEvent(
                    correlation_id=event.correlation_id,
                    emitted_at_utc=now,
                    document_id=document_id,
                    source_url=source_url,
                    content_hash=content_hash,
                    extracted_text_ref=extracted_text_ref,
                    mime_type=_detect_mime_type(source_url),
                    parser_version=config.parser_version,
                )
                await publish_callback(
                    indexed_topic, indexed_event.model_dump(mode="json")
                )
                return ModelKreuzbergParseResult(
                    indexed_count=1,
                    failed_count=0,
                    skipped_too_large_count=0,
                    timeout_count=0,
                )

        # ------------------------------------------------------------------
        # Step 3: Read file bytes (deferred until after idempotency check)
        # ------------------------------------------------------------------
        try:
            file_bytes: bytes = await asyncio.to_thread(validated_path.read_bytes)
        except OSError as exc:
            _log.warning(
                "Failed to read source file",
                extra={"source_url": source_url, "error": str(exc)},
            )
            failed_event = ModelDocumentParseFailedEvent(
                correlation_id=event.correlation_id,
                emitted_at_utc=now,
                source_url=source_url,
                content_hash=content_hash,
                error_code="parse_error",
                error_detail=f"Failed to read source file: {exc}",
                parser_version=config.parser_version,
            )
            await publish_callback(failed_topic, failed_event.model_dump(mode="json"))
            return ModelKreuzbergParseResult(
                indexed_count=0,
                failed_count=1,
                skipped_too_large_count=0,
                timeout_count=0,
            )

        # ------------------------------------------------------------------
        # Step 4: Hard limit — too large
        # ------------------------------------------------------------------
        if len(file_bytes) > config.max_doc_bytes:
            _log.warning(
                "Document too large for kreuzberg",
                extra={
                    "source_url": source_url,
                    "size_bytes": len(file_bytes),
                    "max_doc_bytes": config.max_doc_bytes,
                },
            )
            failed_event = ModelDocumentParseFailedEvent(
                correlation_id=event.correlation_id,
                emitted_at_utc=now,
                source_url=source_url,
                content_hash=content_hash,
                error_code="too_large",
                error_detail=(
                    f"Document size {len(file_bytes)} bytes exceeds "
                    f"max_doc_bytes={config.max_doc_bytes}"
                ),
                parser_version=config.parser_version,
            )
            await publish_callback(failed_topic, failed_event.model_dump(mode="json"))
            return ModelKreuzbergParseResult(
                indexed_count=0,
                failed_count=0,
                skipped_too_large_count=1,
                timeout_count=0,
            )

        # ------------------------------------------------------------------
        # Step 5: Call kreuzberg POST /extract
        # ------------------------------------------------------------------
        filename = validated_path.name
        mime_type = _detect_mime_type(source_url)
        timeout_seconds = config.timeout_ms / 1000.0

        try:
            result = await call_kreuzberg_extract(
                kreuzberg_url=config.kreuzberg_url,
                file_bytes=file_bytes,
                filename=filename,
                mime_type=mime_type,
                timeout_seconds=timeout_seconds,
            )
        except KreuzbergTimeoutError:
            _log.warning(
                "kreuzberg request timed out",
                extra={"source_url": source_url, "timeout_ms": config.timeout_ms},
            )
            failed_event = ModelDocumentParseFailedEvent(
                correlation_id=event.correlation_id,
                emitted_at_utc=now,
                source_url=source_url,
                content_hash=content_hash,
                error_code="timeout",
                error_detail=(
                    f"kreuzberg extract request timed out after {config.timeout_ms} ms"
                ),
                parser_version=config.parser_version,
            )
            await publish_callback(failed_topic, failed_event.model_dump(mode="json"))
            return ModelKreuzbergParseResult(
                indexed_count=0,
                failed_count=1,
                skipped_too_large_count=0,
                timeout_count=1,
            )
        except KreuzbergExtractionError as exc:
            _log.warning(
                "kreuzberg HTTP error",
                extra={"source_url": source_url, "status_code": exc.status_code},
            )
            failed_event = ModelDocumentParseFailedEvent(
                correlation_id=event.correlation_id,
                emitted_at_utc=now,
                source_url=source_url,
                content_hash=content_hash,
                error_code="parse_error",
                error_detail=exc.detail,
                parser_version=config.parser_version,
            )
            await publish_callback(failed_topic, failed_event.model_dump(mode="json"))
            return ModelKreuzbergParseResult(
                indexed_count=0,
                failed_count=1,
                skipped_too_large_count=0,
                timeout_count=0,
            )

        # ------------------------------------------------------------------
        # Step 6: Extract text from response
        # ------------------------------------------------------------------
        extracted_text = result.extracted_text

        # ------------------------------------------------------------------
        # Step 7: Store text and compute extracted_text_ref
        # ------------------------------------------------------------------
        # Write cache for idempotency on next call (always, regardless of branch).
        try:
            await asyncio.to_thread(
                write_cached_text, text_path, content_hash, extracted_text
            )

            if len(extracted_text) < config.inline_text_max_chars:
                extracted_text_ref = extracted_text
            else:
                extracted_text_ref = f"file://{text_path.resolve()}"
        except OSError as exc:
            _log.warning(
                "Failed to write kreuzberg text cache; using inline fallback",
                extra={
                    "source_url": source_url,
                    "text_path": str(text_path),
                    "error": str(exc),
                },
            )
            # Extraction succeeded; only caching failed.
            # Inline only if the text is small enough to fit safely in a Kafka event.
            if len(extracted_text) < config.inline_text_max_chars:
                extracted_text_ref = extracted_text
            else:
                failed_event = ModelDocumentParseFailedEvent(
                    correlation_id=event.correlation_id,
                    emitted_at_utc=now,
                    source_url=source_url,
                    content_hash=content_hash,
                    error_code="parse_error",
                    error_detail="cache write failed and text too large to inline",
                    parser_version=config.parser_version,
                )
                await publish_callback(
                    failed_topic, failed_event.model_dump(mode="json")
                )
                return ModelKreuzbergParseResult(
                    indexed_count=0,
                    failed_count=1,
                    skipped_too_large_count=0,
                    timeout_count=0,
                )

        # ------------------------------------------------------------------
        # Step 8: Emit document-indexed event
        # ------------------------------------------------------------------
        document_id = _compute_document_id(
            source_url, content_hash, config.parser_version
        )
        indexed_event = ModelDocumentIndexedKreuzbergEvent(
            correlation_id=event.correlation_id,
            emitted_at_utc=now,
            document_id=document_id,
            source_url=source_url,
            content_hash=content_hash,
            extracted_text_ref=extracted_text_ref,
            mime_type=mime_type,
            parser_version=config.parser_version,
        )
        await publish_callback(indexed_topic, indexed_event.model_dump(mode="json"))
        _log.info(
            "kreuzberg parse complete",
            extra={
                "source_url": source_url,
                "document_id": str(document_id),
                "extracted_text_len": len(extracted_text),
            },
        )
        return ModelKreuzbergParseResult(
            indexed_count=1,
            failed_count=0,
            skipped_too_large_count=0,
            timeout_count=0,
        )
