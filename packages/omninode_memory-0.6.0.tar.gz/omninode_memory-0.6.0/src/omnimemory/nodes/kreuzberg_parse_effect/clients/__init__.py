# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT
"""Kreuzberg parse effect clients — HTTP transport boundary."""
