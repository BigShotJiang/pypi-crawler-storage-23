# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

# Copyright (c) 2025 OmniNode Team
"""Handler models for omnimemory.

This module exports configuration and data models used by handlers
in the omnimemory package.

Exports:
    ModelHandlerIntentConfig: Configuration for HandlerIntent.
"""

from omnimemory.handlers.models.model_handler_intent_config import (
    ModelHandlerIntentConfig,
)

__all__ = [
    "ModelHandlerIntentConfig",
]
