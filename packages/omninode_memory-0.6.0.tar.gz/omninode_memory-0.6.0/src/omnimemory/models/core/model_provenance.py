# SPDX-FileCopyrightText: 2025 OmniNode.ai Inc.
# SPDX-License-Identifier: MIT

"""
Provenance tracking model following ONEX standards.
"""

from datetime import datetime, timezone
from uuid import UUID

from pydantic import BaseModel, ConfigDict, Field

from omnimemory.models.foundation.model_semver import ModelSemVer


class ModelProvenanceEntry(BaseModel):
    """Single provenance entry following ONEX standards."""

    model_config = ConfigDict(frozen=False, extra="forbid")

    # Operation identification
    operation_id: UUID = Field(
        description="Unique identifier for the operation that created this entry",
    )
    operation_type: str = Field(
        description="Type of operation (store, retrieve, update, delete, migrate)",
    )

    # Source identification
    source_component: str = Field(
        description="Component that performed the operation (e.g., memory_manager)",
    )
    source_version: ModelSemVer | None = Field(
        default=None,
        description="Semantic version of the source component that performed the operation",
    )

    # Actor identification
    actor_type: str = Field(
        description="Type of actor that initiated the operation (user, system, agent)",
    )
    actor_id: str | None = Field(
        default=None,
        description="Identifier of the actor (user ID, system name, agent name)",
    )

    # Temporal information
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this provenance entry was created",
    )

    # Operation context
    operation_context: dict[str, str] = Field(
        default_factory=dict,
        description="Additional context about the operation",
    )

    # Data transformation
    input_hash: str | None = Field(
        default=None,
        description="Hash of input data for integrity verification",
    )
    output_hash: str | None = Field(
        default=None,
        description="Hash of output data for integrity verification",
    )
    transformation_description: str | None = Field(
        default=None,
        description="Description of how data was transformed",
    )


class ModelProvenanceChain(BaseModel):
    """Complete provenance chain for memory data following ONEX standards."""

    model_config = ConfigDict(frozen=False, extra="forbid")

    # Chain metadata
    chain_id: UUID = Field(
        description="Unique identifier for this provenance chain",
    )
    root_operation_id: UUID = Field(
        description="Identifier of the operation that started this chain",
    )

    # Chain entries
    entries: list[ModelProvenanceEntry] = Field(
        default_factory=list,
        description="Chronological list of provenance entries in this chain",
    )

    # Chain statistics
    total_operations: int = Field(
        default=0,
        description="Total number of operations in this chain",
    )
    chain_started_at: datetime = Field(
        default_factory=lambda: datetime.now(timezone.utc),
        description="When this provenance chain was started",
    )
    chain_updated_at: datetime | None = Field(
        default=None,
        description="When this provenance chain was last updated",
    )

    # Integrity verification
    chain_hash: str | None = Field(
        default=None,
        description="Hash of the entire chain for integrity verification",
    )
    verified: bool = Field(
        default=False,
        description="Whether this provenance chain has been cryptographically verified",
    )

    def add_entry(self, entry: ModelProvenanceEntry) -> None:
        """Add a new provenance entry to the chain."""
        self.entries.append(entry)
        self.total_operations = len(self.entries)
        self.chain_updated_at = datetime.now(timezone.utc)

    def get_latest_entry(self) -> ModelProvenanceEntry | None:
        """Get the most recent provenance entry."""
        return self.entries[-1] if self.entries else None

    def get_entry_by_operation_id(
        self, operation_id: UUID
    ) -> ModelProvenanceEntry | None:
        """Find a provenance entry by operation ID."""
        for entry in self.entries:
            if entry.operation_id == operation_id:
                return entry
        return None
