"""
pysynapse — Connect heterogeneous datasources to a vector store for RAG-powered AI agents.

Quick start:

    from pysynapse import Pipeline, TxtConnector, LocalEmbedder, ChromaStore

    pipeline = Pipeline(
        connector=TxtConnector("./docs"),
        embedder=LocalEmbedder(),
        store=ChromaStore(),
    )

    async def main():
        count = await pipeline.run()
        results = await pipeline.search("my question", k=5)
"""

from pysynapse.connectors.document import CsvConnector, DocxConnector, PdfConnector, TxtConnector
from pysynapse.connectors.sqlite import SQLiteConfig, SQLiteConnector
from pysynapse.core.document import Document
from pysynapse.core.exceptions import (
    ConfigError,
    ConnectorError,
    EmbedderError,
    MissingDependencyError,
    PySynapseError,
    StoreError,
)
from pysynapse.core.protocols import DataConnector, Embedder, VectorStore
from pysynapse.embedders.local import LocalEmbedder
from pysynapse.pipeline.pipeline import Pipeline
from pysynapse.processors.chunker import RecursiveCharacterChunker
from pysynapse.stores.chroma import ChromaConfig, ChromaStore

__version__ = "0.1.0"

__all__ = [
    # Pipeline
    "Pipeline",
    # Connectors — Documents
    "TxtConnector",
    "CsvConnector",
    "PdfConnector",
    "DocxConnector",
    # Connectors — Databases
    "SQLiteConnector",
    "SQLiteConfig",
    # Processors
    "RecursiveCharacterChunker",
    # Embedders
    "LocalEmbedder",
    # Stores
    "ChromaStore",
    "ChromaConfig",
    # Core
    "Document",
    "DataConnector",
    "Embedder",
    "VectorStore",
    # Exceptions
    "PySynapseError",
    "ConnectorError",
    "EmbedderError",
    "StoreError",
    "ConfigError",
    "MissingDependencyError",
]
