from pysynapse.connectors.mongodb.connector import MongoDBConfig, MongoDBConnector

__all__ = ["MongoDBConnector", "MongoDBConfig"]
