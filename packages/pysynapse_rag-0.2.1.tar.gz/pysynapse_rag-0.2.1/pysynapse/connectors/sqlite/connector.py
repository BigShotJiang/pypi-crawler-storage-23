from typing import AsyncIterator

from pydantic import BaseModel

from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError, MissingDependencyError


class SQLiteConfig(BaseModel):
    db_path: str
    table: str
    text_column: str
    metadata_columns: list[str] = []
    where_clause: str | None = None


class SQLiteConnector:
    """
    Async SQLite connector.

    Each table row becomes a Document.
    Requires: pip install pysynapse[sqlite]
    """

    def __init__(self, config: SQLiteConfig) -> None:
        self.config = config
        try:
            import aiosqlite  # noqa: F401
        except ImportError as e:
            raise MissingDependencyError("aiosqlite", "sqlite") from e

    async def load(self) -> AsyncIterator[Document]:
        import aiosqlite

        cfg = self.config
        cols = [cfg.text_column] + cfg.metadata_columns
        cols_sql = ", ".join(f'"{c}"' for c in cols)
        query = f'SELECT {cols_sql} FROM "{cfg.table}"'
        if cfg.where_clause:
            query += f" WHERE {cfg.where_clause}"

        try:
            async with aiosqlite.connect(cfg.db_path) as db:
                db.row_factory = aiosqlite.Row
                async with db.execute(query) as cursor:
                    async for row in cursor:
                        row_dict = dict(row)
                        text = str(row_dict.pop(cfg.text_column, "") or "")
                        if not text.strip():
                            continue
                        meta = {
                            "source": cfg.db_path,
                            "table": cfg.table,
                            **{k: v for k, v in row_dict.items()},
                        }
                        yield Document(text=text, metadata=meta)
        except Exception as e:
            raise ConnectorError(f"SQLite error on '{cfg.db_path}': {e}") from e
