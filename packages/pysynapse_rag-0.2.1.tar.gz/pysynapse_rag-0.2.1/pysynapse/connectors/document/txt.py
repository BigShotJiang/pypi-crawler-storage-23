from pathlib import Path
from typing import AsyncIterator

import aiofiles

from pysynapse.connectors.document.base import BaseDocumentConnector
from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError


class TxtConnector(BaseDocumentConnector):
    """Connector for plain-text and Markdown files (.txt, .md, .rst)."""

    SUPPORTED_EXTENSIONS = frozenset({".txt", ".md", ".rst", ".text"})

    def __init__(self, path: str | Path, encoding: str = "utf-8") -> None:
        super().__init__(path)
        self.encoding = encoding

    async def load(self) -> AsyncIterator[Document]:
        for file_path in self._iter_paths():
            try:
                async with aiofiles.open(file_path, encoding=self.encoding) as f:
                    text = await f.read()
            except OSError as e:
                raise ConnectorError(f"Cannot read '{file_path}': {e}") from e

            if text.strip():
                yield Document(
                    text=text,
                    metadata={
                        "source": str(file_path),
                        "filename": file_path.name,
                        "extension": file_path.suffix.lower(),
                    },
                )
