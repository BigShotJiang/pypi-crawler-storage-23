import csv
import io
from pathlib import Path
from typing import AsyncIterator

import aiofiles

from pysynapse.connectors.document.base import BaseDocumentConnector
from pysynapse.core.document import Document
from pysynapse.core.exceptions import ConnectorError


class CsvConnector(BaseDocumentConnector):
    """
    CSV connector.

    Each row becomes a Document.
    `text_columns`: columns concatenated to form the text (all columns if None).
    `metadata_columns`: columns added to the document metadata.
    """

    SUPPORTED_EXTENSIONS = frozenset({".csv"})

    def __init__(
        self,
        path: str | Path,
        text_columns: list[str] | None = None,
        metadata_columns: list[str] | None = None,
        delimiter: str = ",",
        encoding: str = "utf-8",
    ) -> None:
        super().__init__(path)
        self.text_columns = text_columns
        self.metadata_columns = metadata_columns or []
        self.delimiter = delimiter
        self.encoding = encoding

    async def load(self) -> AsyncIterator[Document]:
        for file_path in self._iter_paths():
            try:
                async with aiofiles.open(file_path, encoding=self.encoding) as f:
                    raw = await f.read()
            except OSError as e:
                raise ConnectorError(f"Cannot read '{file_path}': {e}") from e

            reader = csv.DictReader(io.StringIO(raw), delimiter=self.delimiter)
            for row_num, row in enumerate(reader, start=1):
                cols = self.text_columns or list(row.keys())
                text_parts = [str(row[c]) for c in cols if c in row and str(row[c]).strip()]
                text = " | ".join(text_parts)

                if not text.strip():
                    continue

                meta: dict = {
                    "source": str(file_path),
                    "filename": file_path.name,
                    "row": row_num,
                }
                for col in self.metadata_columns:
                    if col in row:
                        meta[col] = row[col]

                yield Document(text=text, metadata=meta)
