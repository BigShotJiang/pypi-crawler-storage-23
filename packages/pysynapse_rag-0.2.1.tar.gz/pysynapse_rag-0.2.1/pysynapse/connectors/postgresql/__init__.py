from pysynapse.connectors.postgresql.connector import PostgreSQLConfig, PostgreSQLConnector

__all__ = ["PostgreSQLConnector", "PostgreSQLConfig"]
