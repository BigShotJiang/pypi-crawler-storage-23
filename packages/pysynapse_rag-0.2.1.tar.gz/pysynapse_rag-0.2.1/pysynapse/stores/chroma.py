import asyncio
import gc
from functools import partial

from pydantic import BaseModel

from pysynapse.core.document import Document
from pysynapse.core.exceptions import StoreError


class ChromaConfig(BaseModel):
    persist_directory: str = "./chroma_db"
    collection_name: str = "pysynapse"


class ChromaStore:
    """
    Local ChromaDB vector store (persistent file mode).

    The ChromaDB API is synchronous, so all operations run
    in an executor to avoid blocking the asyncio loop.
    """

    def __init__(self, config: ChromaConfig | None = None) -> None:
        self.config = config or ChromaConfig()
        self._client = None
        self._collection = None

    def _get_collection(self):
        if self._collection is None:
            try:
                import chromadb
            except ImportError as e:
                raise StoreError(
                    "chromadb is not installed. "
                    "Install it with: pip install chromadb"
                ) from e
            self._client = chromadb.PersistentClient(
                path=self.config.persist_directory
            )
            self._collection = self._client.get_or_create_collection(
                name=self.config.collection_name
            )
        return self._collection

    async def add(
        self,
        documents: list[Document],
        embeddings: list[list[float]],
    ) -> None:
        if not documents:
            return
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(
                None,
                partial(self._add_sync, documents, embeddings),
            )
        except Exception as e:
            raise StoreError(f"ChromaDB add error: {e}") from e

    def _add_sync(
        self,
        documents: list[Document],
        embeddings: list[list[float]],
    ) -> None:
        collection = self._get_collection()
        collection.upsert(
            ids=[doc.id for doc in documents],
            documents=[doc.text for doc in documents],
            embeddings=embeddings,
            metadatas=[doc.metadata for doc in documents],
        )

    async def search(
        self,
        query_embedding: list[float],
        k: int = 5,
    ) -> list[Document]:
        loop = asyncio.get_event_loop()
        try:
            results = await loop.run_in_executor(
                None,
                partial(self._search_sync, query_embedding, k),
            )
            return results
        except Exception as e:
            raise StoreError(f"ChromaDB search error: {e}") from e

    def _search_sync(
        self,
        query_embedding: list[float],
        k: int,
    ) -> list[Document]:
        collection = self._get_collection()
        results = collection.query(
            query_embeddings=[query_embedding],
            n_results=k,
            include=["documents", "metadatas", "distances"],
        )

        docs = []
        for doc_text, meta, doc_id, distance in zip(
            results["documents"][0],
            results["metadatas"][0],
            results["ids"][0],
            results["distances"][0],
        ):
            docs.append(Document(
                text=doc_text,
                metadata={**(meta or {}), "distance": distance},
                id=doc_id,
            ))
        return docs

    async def count(self) -> int:
        """Return the number of documents indexed in the collection."""
        loop = asyncio.get_event_loop()
        collection = await loop.run_in_executor(None, self._get_collection)
        return await loop.run_in_executor(None, collection.count)

    async def delete_collection(self) -> None:
        """Delete and recreate the collection (full reset)."""
        loop = asyncio.get_event_loop()
        try:
            await loop.run_in_executor(None, self._delete_sync)
        except Exception as e:
            raise StoreError(f"ChromaDB delete error: {e}") from e

    def _delete_sync(self) -> None:
        collection = self._get_collection()
        self._client.delete_collection(collection.name)
        self._collection = None

    def close(self) -> None:
        """Release ChromaDB file handles (important on Windows)."""
        self._collection = None
        self._client = None
        gc.collect()
        # ChromaDB maintains a singleton system cache (Rust/SQLite);
        # clear_system_cache() closes all open connections.
        try:
            from chromadb.api.client import SharedSystemClient
            SharedSystemClient.clear_system_cache()
        except Exception:
            pass
