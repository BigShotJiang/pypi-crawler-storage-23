class PySynapseError(Exception):
    """Base class for all pysynapse exceptions."""


class ConnectorError(PySynapseError):
    """Error raised when loading a datasource fails."""


class EmbedderError(PySynapseError):
    """Error raised when generating embeddings fails."""


class StoreError(PySynapseError):
    """Error raised when interacting with the vector store fails."""


class ConfigError(PySynapseError):
    """Invalid configuration."""


class MissingDependencyError(PySynapseError):
    """Optional dependency is not installed."""

    def __init__(self, package: str, extra: str) -> None:
        super().__init__(
            f"Package '{package}' is required. "
            f"Install it with: pip install pysynapse[{extra}]"
        )
