import asyncio
import concurrent.futures
import logging
from collections.abc import Callable
from pathlib import Path
from typing import AsyncIterator

from pysynapse.core.document import Document
from pysynapse.core.exceptions import EmbedderError, MissingDependencyError, StoreError
from pysynapse.core.protocols import DataConnector, Embedder, VectorStore
from pysynapse.processors.chunker import RecursiveCharacterChunker

logger = logging.getLogger(__name__)


def _run_sync(coro):
    """Run *coro* from a synchronous context.

    Works in plain scripts (no running loop) and inside a running loop
    such as Jupyter notebooks, by delegating to a fresh thread in the
    latter case.
    """
    try:
        asyncio.get_running_loop()
        # A loop is already running — delegate to a new thread.
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    except RuntimeError:
        return asyncio.run(coro)


async def _with_retry(fn: Callable, max_retries: int, base_delay: float):
    """Retry *fn* on EmbedderError / StoreError with exponential back-off."""
    for attempt in range(max_retries):
        try:
            return await fn()
        except (EmbedderError, StoreError):
            if attempt == max_retries - 1:
                raise
            wait = base_delay * (2 ** attempt)
            logger.warning(
                "Transient error on attempt %d/%d — retrying in %.1fs.",
                attempt + 1,
                max_retries,
                wait,
            )
            await asyncio.sleep(wait)


class Pipeline:
    """
    Orchestrates the flow: DataConnector → Chunker → Embedder → VectorStore.

    Usage:
        # Basic
        pipeline = Pipeline(connector=..., embedder=..., store=...)
        count = await pipeline.run()
        results = await pipeline.search("my question", k=5)

        # As a context manager (auto-closes the store)
        async with Pipeline(connector=..., embedder=..., store=...) as pipeline:
            count = await pipeline.run()
            results = await pipeline.hybrid_search("my question", k=5)
    """

    def __init__(
        self,
        connector: DataConnector,
        embedder: Embedder,
        store: VectorStore,
        chunker: RecursiveCharacterChunker | None = None,
        batch_size: int = 32,
        max_retries: int = 3,
        retry_delay: float = 1.0,
        on_progress: Callable[[int], None] | None = None,
    ) -> None:
        self.connector = connector
        self.embedder = embedder
        self.store = store
        self.chunker = chunker or RecursiveCharacterChunker()
        self.batch_size = batch_size
        self.max_retries = max_retries
        self.retry_delay = retry_delay
        self.on_progress = on_progress

        # BM25 state — populated during run(), used by hybrid_search()
        self._bm25_docs: list[Document] = []
        self._bm25_index = None  # built lazily on first hybrid_search call

    # ------------------------------------------------------------------ #
    # Factory                                                              #
    # ------------------------------------------------------------------ #

    @classmethod
    def from_files(
        cls,
        path: str | Path,
        *,
        persist_directory: str = "./.pysynapse",
        collection_name: str = "pysynapse",
        model_name: str = "all-MiniLM-L6-v2",
        chunk_size: int = 512,
        chunk_overlap: int = 64,
        **kwargs,
    ) -> "Pipeline":
        """
        Create a ready-to-use Pipeline from a file or directory.

        Auto-detects the connector based on file extension.
        Uses LocalEmbedder and a persistent ChromaStore with sensible defaults.

        Args:
            path:               File or directory to index.
            persist_directory:  Where ChromaDB stores its data on disk.
            collection_name:    ChromaDB collection name.
            model_name:         sentence-transformers model for embeddings.
            chunk_size:         Max characters per chunk.
            chunk_overlap:      Overlap between consecutive chunks.
            **kwargs:           Extra arguments forwarded to Pipeline.__init__
                                (batch_size, max_retries, retry_delay, on_progress).

        Example::

            async with Pipeline.from_files("./my_docs") as pipeline:
                await pipeline.run()
                results = await pipeline.search("What is RAG?", k=3)
        """
        from pysynapse.embedders.local import LocalEmbedder
        from pysynapse.stores.chroma import ChromaConfig, ChromaStore

        path = Path(path)
        connector = cls._connector_for(path)
        embedder = LocalEmbedder(model_name=model_name)
        store = ChromaStore(ChromaConfig(
            persist_directory=persist_directory,
            collection_name=collection_name,
        ))
        chunker = RecursiveCharacterChunker(
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )
        return cls(connector=connector, embedder=embedder, store=store, chunker=chunker, **kwargs)

    @staticmethod
    def _connector_for(path: Path) -> DataConnector:
        """Return the right connector for *path* based on its extension."""
        ext = path.suffix.lower() if path.is_file() else ""

        if ext == ".csv":
            from pysynapse.connectors.document.csv import CsvConnector
            return CsvConnector(path)
        if ext == ".pdf":
            from pysynapse.connectors.document.pdf import PdfConnector
            return PdfConnector(path)
        if ext in {".docx", ".doc"}:
            from pysynapse.connectors.document.docx import DocxConnector
            return DocxConnector(path)
        # Default: txt/md/rst files (also handles directories)
        from pysynapse.connectors.document.txt import TxtConnector
        return TxtConnector(path)

    # ------------------------------------------------------------------ #
    # Context manager                                                      #
    # ------------------------------------------------------------------ #

    # ------------------------------------------------------------------ #
    # Async context manager                                                #
    # ------------------------------------------------------------------ #

    async def __aenter__(self) -> "Pipeline":
        return self

    async def __aexit__(self, *_) -> None:
        if hasattr(self.store, "close"):
            self.store.close()

    # ------------------------------------------------------------------ #
    # Sync context manager                                                 #
    # ------------------------------------------------------------------ #

    def __enter__(self) -> "Pipeline":
        return self

    def __exit__(self, *_) -> None:
        if hasattr(self.store, "close"):
            self.store.close()

    # ------------------------------------------------------------------ #
    # Public API                                                           #
    # ------------------------------------------------------------------ #

    async def run(self) -> int:
        """
        Run the full pipeline: load → chunk → embed → store.

        Returns the total number of chunks indexed.
        Calls on_progress(total_so_far) after each batch if provided.
        """
        total = 0
        batch: list[Document] = []
        self._bm25_docs.clear()
        self._bm25_index = None

        async for raw_doc in self._load():
            chunks = self.chunker.split_document(raw_doc)
            batch.extend(chunks)

            while len(batch) >= self.batch_size:
                to_process = batch[: self.batch_size]
                batch = batch[self.batch_size :]
                await _with_retry(
                    lambda b=to_process: self._index_batch(b),
                    self.max_retries,
                    self.retry_delay,
                )
                self._bm25_docs.extend(to_process)
                total += len(to_process)
                logger.info("Indexed batch: %d chunks (total so far: %d).", len(to_process), total)
                if self.on_progress:
                    self.on_progress(total)

        if batch:
            await _with_retry(
                lambda b=batch: self._index_batch(b),
                self.max_retries,
                self.retry_delay,
            )
            self._bm25_docs.extend(batch)
            total += len(batch)
            logger.info("Indexed final batch: %d chunks (total: %d).", len(batch), total)
            if self.on_progress:
                self.on_progress(total)

        logger.info("Pipeline complete: %d chunks indexed.", total)
        return total

    async def search(self, query: str, k: int = 5) -> list[Document]:
        """
        Vector-only search — returns the k nearest documents to the query.

        Each result has a 'distance' field in its metadata.
        """
        query_embedding = await self.embedder.embed_one(query)
        return await self.store.search(query_embedding, k=k)

    async def hybrid_search(
        self,
        query: str,
        k: int = 5,
        vector_weight: float = 0.5,
    ) -> list[Document]:
        """
        Hybrid search — combines vector similarity and BM25 keyword search
        via Reciprocal Rank Fusion (RRF).

        Requires: pip install pysynapse[bm25]

        Args:
            query:         The search query string.
            k:             Number of results to return.
            vector_weight: Weight for vector results [0.0–1.0].
                           (1 - vector_weight) is applied to BM25 results.
        """
        try:
            from rank_bm25 import BM25Okapi
        except ImportError as e:
            raise MissingDependencyError("rank-bm25", "bm25") from e

        if not self._bm25_docs:
            raise RuntimeError(
                "No documents indexed yet. Call pipeline.run() before hybrid_search()."
            )

        # Build BM25 index lazily (or after run() invalidated it)
        if self._bm25_index is None:
            tokenized = [doc.text.lower().split() for doc in self._bm25_docs]
            self._bm25_index = BM25Okapi(tokenized)

        candidates = min(k * 4, len(self._bm25_docs))

        # --- Vector search ---
        query_embedding = await self.embedder.embed_one(query)
        vector_results = await self.store.search(query_embedding, k=candidates)

        # --- BM25 search ---
        tokenized_query = query.lower().split()
        bm25_scores = self._bm25_index.get_scores(tokenized_query)
        bm25_ranked_indices = sorted(
            range(len(bm25_scores)), key=lambda i: bm25_scores[i], reverse=True
        )[:candidates]
        bm25_results = [self._bm25_docs[i] for i in bm25_ranked_indices]

        # --- Reciprocal Rank Fusion ---
        rrf_scores: dict[str, float] = {}
        id_to_doc: dict[str, Document] = {}

        for rank, doc in enumerate(vector_results):
            rrf_scores[doc.id] = rrf_scores.get(doc.id, 0.0) + vector_weight / (rank + 60)
            id_to_doc[doc.id] = doc

        bm25_w = 1.0 - vector_weight
        for rank, doc in enumerate(bm25_results):
            rrf_scores[doc.id] = rrf_scores.get(doc.id, 0.0) + bm25_w / (rank + 60)
            id_to_doc.setdefault(doc.id, doc)

        ranked = sorted(rrf_scores.keys(), key=lambda doc_id: rrf_scores[doc_id], reverse=True)
        return [id_to_doc[doc_id] for doc_id in ranked[:k]]

    # ------------------------------------------------------------------ #
    # Sync convenience wrappers                                            #
    # ------------------------------------------------------------------ #

    def run_sync(self) -> int:
        """Synchronous wrapper for :meth:`run`. Safe to call from plain scripts."""
        return _run_sync(self.run())

    def search_sync(self, query: str, k: int = 5) -> list[Document]:
        """Synchronous wrapper for :meth:`search`."""
        return _run_sync(self.search(query, k=k))

    def hybrid_search_sync(
        self,
        query: str,
        k: int = 5,
        vector_weight: float = 0.5,
    ) -> list[Document]:
        """Synchronous wrapper for :meth:`hybrid_search`."""
        return _run_sync(self.hybrid_search(query, k=k, vector_weight=vector_weight))

    # ------------------------------------------------------------------ #
    # Internal helpers                                                     #
    # ------------------------------------------------------------------ #

    async def _load(self) -> AsyncIterator[Document]:
        async for doc in self.connector.load():
            yield doc

    async def _index_batch(self, documents: list[Document]) -> None:
        texts = [doc.text for doc in documents]
        embeddings = await self.embedder.embed(texts)
        await self.store.add(documents, embeddings)
        logger.debug("Stored batch of %d chunks.", len(documents))
