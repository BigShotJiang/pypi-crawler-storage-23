"""
Quickstart pysynapse — minimal complete example.

Requirements:
    pip install pysynapse

Usage:
    python examples/quickstart.py
"""

import asyncio
import tempfile
from pathlib import Path

from pysynapse import Pipeline


async def main() -> None:
    # 1. Create demo text files
    with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp_dir:
        docs_dir = Path(tmp_dir)
        (docs_dir / "intro.txt").write_text(
            "pysynapse is a Python library for connecting heterogeneous datasources "
            "to a ChromaDB vector store.\n\n"
            "It supports text documents, PDF, DOCX, CSV, SQLite, MongoDB and PostgreSQL.\n\n"
            "The goal is to simplify building RAG-based search pipelines.",
            encoding="utf-8",
        )
        (docs_dir / "faq.txt").write_text(
            "Q: What is RAG?\n"
            "A: RAG (Retrieval-Augmented Generation) is a technique that combines "
            "retrieval of relevant documents with text generation by an LLM.\n\n"
            "Q: Which embedding models are supported?\n"
            "A: pysynapse uses sentence-transformers running locally — no API key needed.",
            encoding="utf-8",
        )

        # 2. Build the pipeline in one line
        async with Pipeline.from_files(
            docs_dir,
            persist_directory=str(docs_dir / ".pysynapse"),
            on_progress=lambda n: print(f"  {n} chunks indexed…"),
        ) as pipeline:

            # 3. Index
            print("Indexing…")
            count = await pipeline.run()
            print(f"Done — {count} chunks indexed.\n")

            # 4. Search
            queries = [
                "What is RAG?",
                "Which data sources are supported?",
            ]
            for query in queries:
                print(f"Query: {query!r}")
                results = await pipeline.search(query, k=2)
                for i, doc in enumerate(results, 1):
                    print(f"  [{i}] {doc.text[:120].replace(chr(10), ' ')}")
                print()


if __name__ == "__main__":
    asyncio.run(main())
