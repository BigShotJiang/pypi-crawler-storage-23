<div align="center">

<img src="logo.svg" width="180" alt="pysynapse logo"/>

# ⚡ pysynapse

**Load · Chunk · Embed · Search — any datasource, in minutes.**

[![CI](https://github.com/adm-crow/pysynapse/actions/workflows/ci.yml/badge.svg)](https://github.com/adm-crow/pysynapse/actions/workflows/ci.yml)
[![tests](https://img.shields.io/badge/tests-24%20passing-brightgreen?style=flat-square)](https://github.com/adm-crow/pysynapse/actions/workflows/ci.yml)
[![build](https://img.shields.io/badge/build-passing-brightgreen?style=flat-square)](https://github.com/adm-crow/pysynapse/actions/workflows/ci.yml)
[![Python](https://img.shields.io/badge/python-3.11%2B-blue?style=flat-square&logo=python)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green?style=flat-square)](LICENSE)
[![PyPI](https://img.shields.io/pypi/v/pysynapse-rag?style=flat-square&logo=pypi&logoColor=white&label=pypi)](https://pypi.org/project/pysynapse-rag/)

[Quick Start](#-quick-start) · [Connectors](#-connectors) · [AI Agent](#-connecting-to-an-ai-agent) · [Extending](#-extending-pysynapse)

</div>

---

pysynapse is a Python library for building **RAG pipelines** — with a **full async API** and **sync wrappers** included. Load data from files or databases, chunk it, embed it locally, store it in ChromaDB — and search with vector or hybrid queries.

```
Your data  ──►  Connector  ──►  Chunker  ──►  Embedder  ──►  Vector Store
```

| | Feature | Details |
|:---:|:---|:---|
| 🔌 | **7 Connectors** | txt, csv, pdf, docx, SQLite, MongoDB, PostgreSQL |
| ✂️ | **Smart chunking** | Recursive character splitting with configurable overlap |
| 🧠 | **Local embeddings** | sentence-transformers — no API key, runs fully offline |
| 🗄️ | **ChromaDB** | Persistent vector store, zero config |
| 🔍 | **Hybrid search** | BM25 + vector fusion via Reciprocal Rank Fusion |
| ⚡ | **Async-first** | Full asyncio support · sync wrappers included |
| 🔁 | **Retry logic** | Exponential back-off on transient errors |

---

## 📦 Installation

> [!TIP]
> Install `pysynapse-rag[all]` to get every connector and feature at once.

```bash
pip install pysynapse-rag                    # core: txt, csv, embeddings, ChromaDB
pip install "pysynapse-rag[pdf]"             # + PDF
pip install "pysynapse-rag[docx]"            # + Word documents
pip install "pysynapse-rag[sqlite]"          # + SQLite
pip install "pysynapse-rag[mongodb]"         # + MongoDB
pip install "pysynapse-rag[postgresql]"      # + PostgreSQL
pip install "pysynapse-rag[bm25]"            # + hybrid search
pip install "pysynapse-rag[all]"             # everything
```

---

## 🚀 Quick Start

```python
import asyncio
from pysynapse import Pipeline

async def main():
    async with Pipeline.from_files("./my_docs") as pipeline:
        await pipeline.run()
        results = await pipeline.search("What is RAG?", k=3)
        for doc in results:
            print(doc.text)

asyncio.run(main())
```

> [!TIP]
> **No `async` in your project?** Use the sync API — same pipeline, zero boilerplate:

```python
from pysynapse import Pipeline

with Pipeline.from_files("./my_docs") as pipeline:
    pipeline.run_sync()
    results = pipeline.search_sync("What is RAG?", k=3)
    for doc in results:
        print(doc.text)
```

`from_files` auto-detects the connector (txt/csv/pdf/docx) and wires `LocalEmbedder` + `ChromaStore` with sensible defaults. No extra imports needed.

<details>
<summary>See all <code>from_files</code> options</summary>

```python
Pipeline.from_files(
    "./my_docs",
    persist_directory="./.pysynapse",   # where ChromaDB saves data
    collection_name="pysynapse",
    model_name="all-MiniLM-L6-v2",      # any sentence-transformers model
    chunk_size=512,
    chunk_overlap=64,
    on_progress=lambda n: print(f"{n} chunks indexed…"),
    max_retries=3,
)
```

</details>

<details>
<summary>Need full control? Use the constructor directly</summary>

```python
import asyncio
from pysynapse import Pipeline, TxtConnector, LocalEmbedder, ChromaStore
from pysynapse.stores.chroma import ChromaConfig

async def main():
    async with Pipeline(
        connector=TxtConnector("./my_docs"),
        embedder=LocalEmbedder(),
        store=ChromaStore(ChromaConfig(persist_directory="./.pysynapse")),
    ) as pipeline:
        count = await pipeline.run()
        results = await pipeline.search("What is RAG?", k=3)

asyncio.run(main())
```

</details>

---

## 🔌 Connectors

| Connector | Source | Extra |
|:---|:---|:---:|
| `TxtConnector` | `.txt`, `.md`, `.rst` files or directory | — |
| `CsvConnector` | CSV files — one `Document` per row | — |
| `PdfConnector` | PDF files — one `Document` per page | `[pdf]` |
| `DocxConnector` | Word documents | `[docx]` |
| `SQLiteConnector` | SQLite table | `[sqlite]` |
| `MongoDBConnector` | MongoDB collection | `[mongodb]` |
| `PostgreSQLConnector` | PostgreSQL table | `[postgresql]` |

> [!NOTE]
> All connectors accept a single file **or** a full directory — subdirectories are scanned recursively.

<details>
<summary>Database example — SQLite</summary>

```python
import asyncio
from pysynapse import Pipeline, SQLiteConnector, SQLiteConfig, LocalEmbedder, ChromaStore
from pysynapse.stores.chroma import ChromaConfig

async def main():
    async with Pipeline(
        connector=SQLiteConnector(SQLiteConfig(
            database="./app.db",
            table="articles",
            text_column="content",
            metadata_columns=["title", "author"],  # optional
        )),
        embedder=LocalEmbedder(),
        store=ChromaStore(ChromaConfig(persist_directory="./.pysynapse")),
    ) as pipeline:
        count = await pipeline.run()
        print(f"{count} chunks indexed.")

        results = await pipeline.search("machine learning", k=3)
        for doc in results:
            print(doc.metadata["title"], "—", doc.text[:100])

asyncio.run(main())
```

The same pattern works for **MongoDB** and **PostgreSQL** — swap `SQLiteConnector` for `MongoDBConnector` or `PostgreSQLConnector` with their respective config objects.

</details>

---

## ⚙️ Pipeline options

```python
Pipeline(
    connector   = ...,
    embedder    = ...,
    store       = ...,
    chunker     = RecursiveCharacterChunker(chunk_size=512, chunk_overlap=64),
    batch_size  = 32,
    max_retries = 3,              # exponential back-off on transient errors
    retry_delay = 1.0,
    on_progress = lambda n: ...,  # called after each batch with total indexed
)
```

> [!NOTE]
> The pipeline works as a context manager — use `async with` in async code or plain `with` in sync code. The store is closed automatically on exit.

---

## 🤖 Connecting to an AI Agent

pysynapse handles the **retrieval** half of RAG. Wire the search results to any LLM to build a complete agent:

```python
from openai import OpenAI
from pysynapse import Pipeline

client = OpenAI()  # or Anthropic(), ollama.Client(), …

with Pipeline.from_files("./my_docs") as pipeline:
    pipeline.run_sync()

    def ask(question: str) -> str:
        docs = pipeline.search_sync(question, k=4)
        context = "\n\n".join(doc.text for doc in docs)
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": f"Answer using only this context:\n\n{context}"},
                {"role": "user",   "content": question},
            ],
        )
        return response.choices[0].message.content

    print(ask("What is RAG?"))
```

> [!IMPORTANT]
> pysynapse is **model-agnostic** — it only provides the retrieved `Document` objects. The same pattern works with **Anthropic**, **Ollama**, **Mistral**, or any other LLM.

---

## 🏗️ Architecture

```
pysynapse/
├── core/           ← Document dataclass · Protocols · Exceptions
├── connectors/     ← TxtConnector, CsvConnector, PdfConnector, DocxConnector
│                     SQLiteConnector, MongoDBConnector, PostgreSQLConnector
├── processors/     ← RecursiveCharacterChunker
├── embedders/      ← LocalEmbedder (sentence-transformers)
├── stores/         ← ChromaStore (ChromaDB persistent)
└── pipeline/       ← Pipeline orchestrator
```

The central `Document` type flows through every stage:

```python
@dataclass
class Document:
    text: str
    metadata: dict[str, Any]  # source, page, chunk_index, distance…
    id: str                   # auto-generated UUID
```

---

## 🧩 Extending pysynapse

Implement any of the three Protocols to plug in your own components — no inheritance required. If your class has the right methods, pysynapse accepts it.

| Protocol | Required methods | Swap in your own… |
|:---|:---|:---|
| `DataConnector` | `async def load()` → yields `Document` | REST API, message queue, custom DB… |
| `Embedder` | `async def embed(texts)` + `async def embed_one(text)` | OpenAI, Cohere, custom model… |
| `VectorStore` | `async def add(docs, embeddings)` + `async def search(vec, k)` | Pinecone, Qdrant, in-memory… |

<details>
<summary>Example — custom <code>DataConnector</code> (load from a REST API)</summary>

```python
import aiohttp
from pysynapse.core.document import Document

class ApiConnector:
    def __init__(self, url: str):
        self.url = url

    async def load(self):
        async with aiohttp.ClientSession() as session:
            async with session.get(self.url) as resp:
                articles = await resp.json()
        for article in articles:
            yield Document(
                text=article["body"],
                metadata={"title": article["title"]},
            )

# Drop it straight into the pipeline — nothing else changes
pipeline = Pipeline(
    connector=ApiConnector("https://api.example.com/articles"),
    embedder=LocalEmbedder(),
    store=ChromaStore(),
)
```

</details>

<details>
<summary>Example — custom <code>Embedder</code> (use OpenAI instead of local model)</summary>

```python
from openai import AsyncOpenAI

class OpenAIEmbedder:
    def __init__(self, model: str = "text-embedding-3-small"):
        self.client = AsyncOpenAI()
        self.model = model

    async def embed(self, texts: list[str]) -> list[list[float]]:
        response = await self.client.embeddings.create(input=texts, model=self.model)
        return [item.embedding for item in response.data]

    async def embed_one(self, text: str) -> list[float]:
        return (await self.embed([text]))[0]

pipeline = Pipeline(
    connector=TxtConnector("./docs"),
    embedder=OpenAIEmbedder(),   # swap LocalEmbedder for OpenAIEmbedder
    store=ChromaStore(),
)
```

</details>

<details>
<summary>Example — custom <code>VectorStore</code> (simple in-memory store)</summary>

```python
import numpy as np
from pysynapse.core.document import Document

class InMemoryStore:
    def __init__(self):
        self._docs: list[Document] = []
        self._vecs: list[list[float]] = []

    async def add(self, documents, embeddings) -> None:
        self._docs.extend(documents)
        self._vecs.extend(embeddings)

    async def search(self, query_embedding, k: int = 5) -> list[Document]:
        if not self._vecs:
            return []
        scores = [np.dot(query_embedding, v) for v in self._vecs]
        top_k = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[:k]
        return [self._docs[i] for i in top_k]

pipeline = Pipeline(
    connector=TxtConnector("./docs"),
    embedder=LocalEmbedder(),
    store=InMemoryStore(),       # no ChromaDB needed
)
```

</details>

---

## 🛠️ Development

```bash
git clone https://github.com/adm-crow/pysynapse.git
cd pysynapse
pip install -e ".[all,dev]"   # import stays: from pysynapse import ...
pytest                        # 24 tests
python examples/quickstart.py
```

---

## 🗺️ Roadmap

- [x] File & database connectors (txt, csv, pdf, docx, SQLite, MongoDB, PostgreSQL)
- [x] Recursive character chunking · local embeddings · ChromaDB store
- [x] Progress callbacks · retry logic · context manager · hybrid search (BM25 + vector)
- [x] Sync API (`run_sync`, `search_sync`, `hybrid_search_sync`)

---

Contributions welcome — open an issue or a PR on [GitHub](https://github.com/adm-crow/pysynapse).

<div align="center">

MIT License &nbsp;·&nbsp; [adm-crow](https://github.com/adm-crow)

</div>
