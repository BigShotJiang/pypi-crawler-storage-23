"wing test"

from gpkit import Model, Vectorize, parse_variables

from gpkitmodels.GP.aircraft.wing.boxspar import BoxSpar
from gpkitmodels.GP.aircraft.wing.wing import Wing

# pylint: disable=no-member, exec-used


class FlightState(Model):
    """Flight State

    Variables
    ---------
    V           50      [m/s]        airspeed
    rho         1.255   [kg/m^3]     air density
    mu          1.5e-5  [N*s/m**2]   air viscosity
    qne                 [kg/s^2/m]   never exceed dynamic pressure

    """

    @parse_variables(__doc__, globals())
    def setup(self):
        return [qne == V**2 * rho * 1.2]


def wing_test():
    "test wing models"

    W = Wing()
    W.substitutions[W.W] = 50
    W.substitutions[W.planform.tau] = 0.115
    fs = FlightState()
    perf = W.flight_model(W, fs)
    loading = [W.spar.loading(W, fs)]
    loading[0].substitutions["W"] = 100
    loading.append(W.spar.gustloading(W, fs))
    loading[1].substitutions["W"] = 100

    from gpkit import settings

    if settings["default_solver"] == "cvxopt":
        for l in loading:
            for v in ["Mtip", "Stip", "wroot", "throot"]:
                l.substitutions[v] = 1e-1

    m = Model(
        perf.Cd,
        [
            loading[1].v == fs.V,
            loading[1].cl == perf.CL,
            loading[1].Ww == W.W,
            loading[1].Ww <= 0.5 * fs.rho * fs.V**2 * perf.CL * W.planform.S,
            W,
            fs,
            perf,
            loading,
        ],
    )
    m.solve(verbosity=0)


def box_spar():
    "test wing models"

    Wing.sparModel = BoxSpar
    W = Wing()
    W.substitutions[W.W] = 50
    W.substitutions[W.planform.tau] = 0.115
    fs = FlightState()
    perf = W.flight_model(W, fs)
    loading = [W.spar.loading(W, fs)]
    loading[0].substitutions["W"] = 100
    loading.append(W.spar.gustloading(W, fs))
    loading[1].substitutions["W"] = 100

    from gpkit import settings

    if settings["default_solver"] == "cvxopt":
        for l in loading:
            for v in ["Mtip", "Stip", "wroot", "throot"]:
                l.substitutions[v] = 1e-2

    m = Model(
        perf.Cd,
        [
            loading[1].v == fs.V,
            loading[1].cl == perf.CL,
            loading[1].Ww == W.W,
            loading[1].Ww <= fs.qne * perf.CL * W.planform.S,
            W,
            fs,
            perf,
            loading,
        ],
    )
    m.solve(verbosity=0)


def wing_aero_vectorized():
    "WingAero must be constructable inside Vectorize (rhoValue/muValue bool bug)"
    W = Wing()
    W.substitutions[W.planform.tau] = 0.115
    with Vectorize(5):
        fs = FlightState()
        perf = W.flight_model(W, fs)  # previously raised ValueError on bool(array)
    assert hasattr(perf, "rhoValue")
    assert perf.rhoValue is True


def test():
    "tests"
    wing_test()
    box_spar()
    wing_aero_vectorized()


if __name__ == "__main__":
    test()
