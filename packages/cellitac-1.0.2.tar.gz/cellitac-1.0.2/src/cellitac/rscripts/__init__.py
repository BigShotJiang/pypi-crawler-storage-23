# R scripts bundled with the package - loaded at runtime via importlib.resources
# conda activate cellitac
#cellitac --input ~/trial --output ~/results

