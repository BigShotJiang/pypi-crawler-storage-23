"""
cellitac.config
===============
Central configuration for all paths, QC thresholds, and ML parameters.
Every value can be overridden via:
  1. Environment variables  (e.g.  export SCATAC_INPUT_DIR=/data)
  2. CLI flags              (e.g.  cellitac --input /data)
  3. Python API args        (e.g.  run_full_pipeline(input_dir='/data'))
"""

import os
from pathlib import Path


# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
INPUT_DIR         = os.environ.get("SCATAC_INPUT_DIR",
                                   os.path.expanduser("~/singlecell/ATAC"))
OUTPUT_DIR_TEAM1  = os.environ.get("SCATAC_OUT_TEAM1",  "team1_rna_output")
OUTPUT_DIR_TEAM2  = os.environ.get("SCATAC_OUT_TEAM2",  "team2_atac_output")
OUTPUT_DIR_PYTHON = os.environ.get("SCATAC_OUT_PYTHON", "python_ready_data")
OUTPUT_DIR_ML     = os.environ.get("SCATAC_OUT_ML",     "ml_results")

# ---------------------------------------------------------------------------
# Input file names — DEFAULT 10x Genomics names (used as fallback only).
# The function find_input_files() below auto-detects the real file names
# so the pipeline works regardless of naming convention.
# ---------------------------------------------------------------------------
H5_FILENAME        = "pbmc_unsorted_10k_filtered_feature_bc_matrix.h5"
QC_FILENAME        = "pbmc_unsorted_10k_per_barcode_metrics.csv"
FRAGMENTS_FILENAME = "pbmc_unsorted_10k_atac_fragments.tsv.gz"
PEAKS_FILENAME     = "pbmc_unsorted_10k_atac_peaks.bed"


# ---------------------------------------------------------------------------
# Auto file detection
# ---------------------------------------------------------------------------

# ── H5 matrix file ──────────────────────────────────────────────────────────
# Any .h5 file that is NOT a peaks file
_H5_PATTERNS = ["*.h5"]

# ── Per-barcode QC/metrics CSV (optional) ───────────────────────────────────
_QC_PATTERNS = [
    "*per_barcode*metrics*.csv",
    "*barcode*metrics*.csv",
    "*barcode*qc*.csv",
    "*qc*barcode*.csv",
    "*metrics*.csv",
    "*qc*.csv",
]

# ── ATAC fragments file ──────────────────────────────────────────────────────
# Compressed tabix-indexed TSV — ANY of these extensions/patterns
_FRAGMENTS_PATTERNS = [
    "*fragment*.tsv.gz",
    "*fragment*.tsv.bgz",
    "*frag*.tsv.gz",
    "*frag*.tsv.bgz",
    "*.tsv.gz",          # broadest fallback: any .tsv.gz
]

# ── Peaks BED file ───────────────────────────────────────────────────────────
_PEAKS_PATTERNS = [
    "*peak*.bed",
    "*peaks*.bed",
    "*.bed",             # broadest fallback: any .bed
]


def _find_file(directory, patterns, label, required=True):
    """
    Search `directory` for a file matching any of the glob `patterns`.
    Returns the absolute path as a string, or None if optional and not found.
    Raises FileNotFoundError with a helpful message if required and missing.
    """
    seen = set()
    for pattern in patterns:
        for match in sorted(directory.glob(pattern)):
            key = str(match)
            if key not in seen:
                seen.add(key)
                return key        # return first unique match

    if required:
        files_present = "\n".join(
            f"    {f.name}" for f in sorted(directory.iterdir()) if f.is_file()
        ) or "    (directory is empty)"

        raise FileNotFoundError(
            f"\n[cellitac] Cannot find the {label} file in:\n"
            f"    {directory}\n\n"
            f"  Tried patterns: {patterns}\n\n"
            f"  Files found in that folder:\n{files_present}\n\n"
            f"  TIP: rename your file so it matches one of the patterns above,\n"
            f"       or pass the exact path directly to run_full_pipeline()."
        )
    return None


def find_input_files(input_dir):
    """
    Auto-detect all required input files inside `input_dir`.

    Supports any file naming convention — not just the default 10x names.

    Parameters
    ----------
    input_dir : str or Path
        Folder that contains the raw input files.

    Returns
    -------
    dict with keys:
        h5        – path to the feature-barcode matrix .h5   (required)
        qc        – path to the per-barcode metrics CSV       (optional → None)
        fragments – path to the ATAC fragments .tsv.gz        (required)
        peaks     – path to the peaks .bed file               (required)

    Raises
    ------
    FileNotFoundError
        With a clear, human-readable message listing what was searched
        and what files are actually present in the folder.

    Examples
    --------
    >>> files = find_input_files("/data/my_sample")
    >>> print(files["h5"])        # works regardless of filename
    /data/my_sample/GSM123_matrix.h5
    """
    d = Path(input_dir)
    if not d.exists():
        raise FileNotFoundError(
            f"\n[cellitac] Input directory not found:\n"
            f"    {input_dir}\n\n"
            f"  Please check the path and try again."
        )

    print(f"  [cellitac] Scanning: {d}")

    result = {
        "h5":        _find_file(d, _H5_PATTERNS,        "H5 matrix",       required=True),
        "qc":        _find_file(d, _QC_PATTERNS,         "QC metrics CSV",  required=False),
        "fragments": _find_file(d, _FRAGMENTS_PATTERNS,  "ATAC fragments",  required=True),
        "peaks":     _find_file(d, _PEAKS_PATTERNS,      "peaks BED",       required=True),
    }

    print("  [cellitac] Files detected:")
    for key, path in result.items():
        if path:
            print(f"    {key:12s}  ->  {Path(path).name}")
        else:
            print(f"    {'qc':12s}  ->  not found (optional — will be skipped)")

    return result


# ---------------------------------------------------------------------------
# RNA QC thresholds
# ---------------------------------------------------------------------------
RNA_MIN_FEATURES        = 500
RNA_MAX_FEATURES        = 7000
RNA_MIN_COUNTS          = 1000
RNA_MAX_MT_PERCENT      = 20
RNA_MIN_CELLS           = 3
RNA_MIN_FEATURES_SEURAT = 200
RNA_GENE_MIN_CELLS      = 5
RNA_SCALE_FACTOR        = 10000
RNA_N_VARIABLE          = 2000
RNA_PCA_DIMS            = 15
RNA_CLUSTER_RES         = 0.5

# ---------------------------------------------------------------------------
# ATAC QC thresholds
# ---------------------------------------------------------------------------
ATAC_MIN_CELLS             = 10
ATAC_MIN_FEATURES          = 200
ATAC_MIN_PEAK_COUNT        = 1000
ATAC_MAX_PEAK_COUNT        = 100000
ATAC_MIN_TSS_ENRICHMENT    = 2
ATAC_MAX_NUCLEOSOME_SIGNAL = 4
ATAC_MIN_PCT_IN_PEAKS      = 15
ATAC_MAX_BLACKLIST_RATIO   = 0.05
ATAC_LSI_DIMS              = "2:30"
ATAC_CLUSTER_ALG           = 3
ATAC_N_TOP_PEAKS           = 5000

# ---------------------------------------------------------------------------
# Integration / split
# ---------------------------------------------------------------------------
TRAIN_FRACTION = 0.7
RANDOM_SEED    = 42

# ---------------------------------------------------------------------------
# ML pipeline
# ---------------------------------------------------------------------------
ML_RARE_CLASS_MIN      = 10
ML_CORR_THRESHOLD      = 0.95
ML_K_BEST_FEATURES     = 1000
ML_TEST_SIZE           = 0.2
ML_CV_FOLDS            = 5
ML_SMOTE_K_NEIGHBORS   = 3
ML_IMBALANCE_THRESHOLD = 2.0

# Random Forest
RF_N_ESTIMATORS      = 100
RF_MAX_DEPTH         = 10
RF_MIN_SAMPLES_SPLIT = 20
RF_MIN_SAMPLES_LEAF  = 10

# XGBoost
XGB_N_ESTIMATORS     = 100
XGB_MAX_DEPTH        = 6
XGB_LEARNING_RATE    = 0.1
XGB_SUBSAMPLE        = 0.8
XGB_COLSAMPLE        = 0.8
XGB_REG_ALPHA        = 0.1
XGB_REG_LAMBDA       = 1.0
XGB_MIN_CHILD_WEIGHT = 3

# SVM
SVM_C      = 1.0
SVM_KERNEL = "rbf"
SVM_GAMMA  = "scale"

# Plots
PLOT_DPI = 300
