"""
cellitac.preprocessing
=======================
Runs the R-based preprocessing pipeline (Team 1 RNA + Team 2 ATAC + Integration)
via rpy2, then hands off the python_ready_data/ folder to the ML stage.

File names are auto-detected from the input directory — any 10x naming
convention is supported, not just the default PBMC names.
"""

import importlib.resources
import sys
import numpy as np
import pandas as pd

from cellitac import config as cfg
from cellitac.config import find_input_files

# ---------------------------------------------------------------------------
# rpy2 guard
# ---------------------------------------------------------------------------
try:
    import rpy2.robjects as ro
    from rpy2.robjects import pandas2ri
    pandas2ri.activate()
except ImportError:
    print(
        "\n[cellitac] ERROR: rpy2 is not installed.\n"
        "  pip install rpy2   (R must also be installed and on PATH)\n"
    )
    sys.exit(1)

# R packages required per step
_PKGS_TEAM1 = [
    "Seurat", "hdf5r", "dplyr", "ggplot2", "patchwork",
    "celldex", "SingleR", "SingleCellExperiment",
]
_PKGS_TEAM2 = [
    "Signac", "Seurat", "GenomicRanges", "data.table",
    "EnsDb.Hsapiens.v75", "biovizBase", "ggplot2", "Matrix",
]


def _check_r_packages(packages):
    quoted = ", ".join(f'"{p}"' for p in packages)
    ro.r(f"""
        pkgs    <- c({quoted})
        missing <- pkgs[!sapply(pkgs, requireNamespace, quietly = TRUE)]
        if (length(missing) > 0) {{
            stop(paste("Missing R packages:", paste(missing, collapse=", ")))
        }}
    """)


def _load_rscript(filename):
    pkg = importlib.resources.files("cellitac") / "rscripts" / filename
    return pkg.read_text(encoding="utf-8")


def _run_r(code):
    ro.r(code)


# ============================================================================
# Team 1 — RNA
# ============================================================================
def run_team1(
    input_dir:  str = cfg.INPUT_DIR,
    output_dir: str = cfg.OUTPUT_DIR_TEAM1,
) -> None:
    """Run RNA preprocessing (Seurat + SingleR)."""
    print("=== Team 1: RNA Processing ===")
    _check_r_packages(_PKGS_TEAM1)

    # Auto-detect input files
    files = find_input_files(input_dir)

    # Inject all paths into R environment
    _run_r(f'PBMC_INPUT_DIR  <- "{input_dir}"')
    _run_r(f'PBMC_OUT_TEAM1  <- "{output_dir}"')
    _run_r(f'PBMC_H5_FILE    <- "{files["h5"]}"')
    _run_r(f'PBMC_QC_FILE    <- "{files["qc"] or ""}"')

    _run_r(_load_rscript("team1_rna.R"))
    print(f"Team 1 done  ->  {output_dir}/")


# ============================================================================
# Team 2 — ATAC
# ============================================================================
def run_team2(
    input_dir:        str = cfg.INPUT_DIR,
    output_dir_team1: str = cfg.OUTPUT_DIR_TEAM1,
    output_dir:       str = cfg.OUTPUT_DIR_TEAM2,
) -> None:
    """Run ATAC preprocessing (Signac)."""
    print("=== Team 2: ATAC Processing ===")
    _check_r_packages(_PKGS_TEAM2)

    # Auto-detect input files
    files = find_input_files(input_dir)

    # Inject all paths into R environment
    _run_r(f'PBMC_INPUT_DIR       <- "{input_dir}"')
    _run_r(f'PBMC_OUT_TEAM1       <- "{output_dir_team1}"')
    _run_r(f'PBMC_OUT_TEAM2       <- "{output_dir}"')
    _run_r(f'PBMC_FRAGMENTS_FILE  <- "{files["fragments"]}"')
    _run_r(f'PBMC_PEAKS_FILE      <- "{files["peaks"]}"')

    _run_r(_load_rscript("team2_atac.R"))
    print(f"Team 2 done  ->  {output_dir}/")


# ============================================================================
# Integration — pure Python
# ============================================================================
def run_integration(
    output_dir_team1: str   = cfg.OUTPUT_DIR_TEAM1,
    output_dir_team2: str   = cfg.OUTPUT_DIR_TEAM2,
    output_dir:       str   = cfg.OUTPUT_DIR_PYTHON,
    train_fraction:   float = cfg.TRAIN_FRACTION,
    random_seed:      int   = cfg.RANDOM_SEED,
) -> dict:
    """Combine RNA + ATAC outputs into ML-ready CSVs."""
    import os
    os.makedirs(output_dir, exist_ok=True)
    print("=== Integration: Combining outputs ===")

    rna_features  = pd.read_csv(f"{output_dir_team1}/rna_features_2000.csv",  index_col=0)
    cell_labels   = pd.read_csv(f"{output_dir_team1}/cell_type_labels.csv")
    atac_features = pd.read_csv(f"{output_dir_team2}/atac_features_5000.csv", index_col=0)

    atac_set     = set(atac_features.index)
    common_cells = [c for c in rna_features.index if c in atac_set]
    print(f"  Common cells: {len(common_cells)}")

    rna_m    = rna_features.loc[common_cells]
    atac_m   = atac_features.loc[common_cells]
    combined = pd.concat([rna_m, atac_m], axis=1)

    lbl_m = cell_labels[cell_labels["cell_id"].isin(set(common_cells))].set_index("cell_id")
    final = pd.DataFrame({
        "cell_id":   common_cells,
        "cell_type": [lbl_m.loc[c, "cell_type"] if c in lbl_m.index else np.nan
                      for c in common_cells],
    })
    final    = final[final["cell_type"].notna()].reset_index(drop=True)
    combined = combined.loc[final["cell_id"]]

    np.random.seed(random_seed)
    train_idx = []
    for ct in final["cell_type"].unique():
        idx  = final.index[final["cell_type"] == ct].tolist()
        n_tr = int(np.floor(len(idx) * train_fraction))
        train_idx.extend(np.random.choice(idx, n_tr, replace=False).tolist())

    train_set   = set(train_idx)
    data_splits = pd.DataFrame({
        "cell_id": final["cell_id"].values,
        "split":   ["train" if i in train_set else "test" for i in final.index],
    })

    combined.to_csv(f"{output_dir}/combined_features.csv")
    rna_m.to_csv(f"{output_dir}/rna_features_2000.csv")
    atac_m.to_csv(f"{output_dir}/atac_features_5000.csv")
    final.to_csv(f"{output_dir}/cell_labels.csv", index=False)
    data_splits.to_csv(f"{output_dir}/data_splits.csv", index=False)

    feat_info = pd.DataFrame({
        "feature_name":  combined.columns.tolist(),
        "feature_type":  ["RNA"] * rna_m.shape[1] + ["ATAC"] * atac_m.shape[1],
        "feature_index": range(1, combined.shape[1] + 1),
    })
    feat_info.to_csv(f"{output_dir}/feature_info.csv", index=False)

    summary = pd.DataFrame({
        "metric": ["total_cells", "total_features", "rna_features", "atac_features",
                   "train_cells", "test_cells", "cell_types"],
        "value":  [len(combined), combined.shape[1], rna_m.shape[1], atac_m.shape[1],
                   (data_splits["split"] == "train").sum(),
                   (data_splits["split"] == "test").sum(),
                   final["cell_type"].nunique()],
    })
    summary.to_csv(f"{output_dir}/data_summary.csv", index=False)

    dist = (final["cell_type"].value_counts().reset_index()
            .rename(columns={"index": "Var1", "cell_type": "Freq"}))
    dist.to_csv(f"{output_dir}/cell_type_distribution.csv", index=False)

    print(f"  Integration done  ->  {output_dir}/")
    return {"features": combined, "labels": final, "splits": data_splits}
