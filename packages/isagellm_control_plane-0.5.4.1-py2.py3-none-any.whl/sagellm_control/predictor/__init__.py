"""Lifetime Predictor module for request lifetime prediction.

This module provides infrastructure for predicting how long a request
will take to complete, which is essential for scheduling decisions
and SLO management in the control plane.

Available predictors:
    - DummyPredictor: Simple baseline predictor with fixed or linear predictions
    - LengthBasedPredictor: Predictor based on input/output token length
    - HistoricalPredictor: Predictor based on historical request statistics
    - HybridHeuristicPredictor: Predictor combining multiple heuristic strategies

Main classes:
    - LifetimePredictor: Abstract base class for all predictors
    - RequestInfo: Input data for predictions
    - PredictionResult: Structured prediction output with metadata
    - DummyPredictor: Baseline predictor implementation
    - LengthBasedPredictor: Length-based heuristic predictor
    - HistoricalPredictor: Historical statistics predictor
    - HybridHeuristicPredictor: Hybrid heuristic predictor
    - PredictionEvaluator: Evaluator for prediction accuracy monitoring
    - PredictionRecord: Record of a single prediction vs. actual value
    - EvaluationMetrics: Aggregated evaluation metrics

Example usage:
    >>> from sagellm_control.predictor import LengthBasedPredictor, RequestInfo
    >>>
    >>> # Create a predictor
    >>> predictor = LengthBasedPredictor({"alpha": 0.0001, "beta": 0.05})
    >>>
    >>> # Make a prediction
    >>> request = RequestInfo(
    ...     request_id="req1",
    ...     model_name="Qwen2-7B",
    ...     prompt_length=200,
    ...     max_output_length=100,
    ... )
    >>> lifetime = predictor.predict(request)
    >>>
    >>> # Update with actual lifetime
    >>> predictor.update("req1", actual_lifetime=12.5)
"""

from __future__ import annotations

from sagellm_control.predictor.base import LifetimePredictor
from sagellm_control.predictor.dummy import DummyPredictor
from sagellm_control.predictor.evaluator import (
    EvaluationMetrics,
    PredictionEvaluator,
    PredictionRecord,
)
from sagellm_control.predictor.feature_extractor import ExtractedFeatures, FeatureExtractor
from sagellm_control.predictor.heuristic import (
    HistoricalPredictor,
    HybridHeuristicPredictor,
    LengthBasedPredictor,
)
from sagellm_control.predictor.types import PredictionResult, RequestInfo

__all__ = [
    "LifetimePredictor",
    "RequestInfo",
    "PredictionResult",
    "DummyPredictor",
    "FeatureExtractor",
    "ExtractedFeatures",
    "LengthBasedPredictor",
    "HistoricalPredictor",
    "HybridHeuristicPredictor",
    "PredictionEvaluator",
    "PredictionRecord",
    "EvaluationMetrics",
]
