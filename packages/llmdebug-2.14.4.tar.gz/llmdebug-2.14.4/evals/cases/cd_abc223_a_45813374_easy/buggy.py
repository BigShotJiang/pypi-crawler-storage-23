n = int(input())

if n < 100:
    print("No")
else:
    print("Yes")
