s = input()
if s[-2] == "er":
    print("er")
else:
    print("ist")
