a, b, c, d = map(int, input().split())
print("Takahashi" if a * 24 + b <= c * 24 + d else "Aoki")
