"""Fleet management — trust scoring and agent lifecycle."""
