# OutpostSpawner

```{eval-rst}
.. automodule:: outpostspawner
```

```{eval-rst}
.. autoconfigurable:: OutpostSpawner
   :exclude-members: args,auth_state_hook,cmd,consecutive_failure_limit,cpu_guarantee,cpu_limit,debug,default_url,disable_user_config,env_keep,environment,http_timeout,hub_connect_url,ip,mem_guarantee,mem_limit,notebook_dir,oauth_client_allowed_scopes,oauth_roles,options_form,options_from_form,port,post_stop_hook,pre_spawn_hook,server_token_scopes,start_timeout,ssl_alt_names_include_local,ssl_alt_names
```
