## 1.1.2 (2025-02-12)

No changes.

## 1.1.1 (2025-02-12)

No changes.

## 1.1.0 (2025-01-21)

No changes.

## 1.0.4 (2025-01-17)

No changes.

## 1.0.3 (2024-12-19)

No changes.

## 1.0.2 (2024-11-14)

No changes.

## 1.0.1 (2024-09-03)

### added|fixed|changed|deprecated|removed|security|performance|other (1 change)

- [Resolve "Start timeout when using sync start"](https://gitlab.jsc.fz-juelich.de/jupyterjsc/packages/jupyterhub-outpostspawner/-/commit/4dcc16722f1e322801c39e6ae64e2c6bbdf4cf2d) ([merge request](https://gitlab.jsc.fz-juelich.de/jupyterjsc/packages/jupyterhub-outpostspawner/-/merge_requests/4))

## 1.0.0 (2024-04-22)

### added (1 change)

- [Resolve "add changelog + releases in ci cd pipeline"](jupyterjsc/packages/jupyterhub-outpostspawner@f215e9c2ea33d5de5ff112e1a4b03d536b7f9ac3) ([merge request](jupyterjsc/packages/jupyterhub-outpostspawner!3))
