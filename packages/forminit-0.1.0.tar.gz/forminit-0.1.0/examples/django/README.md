# Django Example

This example demonstrates how to use the Forminit SDK with Django.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
```bash
export FORMINIT_API_KEY="your-api-key"
export FORMINIT_FORM_ID="your-form-id"
```

3. Run migrations (creates SQLite database):
```bash
python manage.py migrate
```

4. Run the development server:
```bash
python manage.py runserver
```

5. Open http://localhost:8000 in your browser

## Features

- Form submission with Django forms
- CSRF protection
- Direct JSON submission API
- User info tracking (IP, User-Agent, Referer)
- Django template integration