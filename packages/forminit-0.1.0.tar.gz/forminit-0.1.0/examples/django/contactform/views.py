"""Django views for Forminit example."""

import json
import os

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods

from forminit import ForminitClient


def index(request):
    """Render the contact form."""
    return render(request, "contactform/index.html")


@csrf_exempt
@require_http_methods(["POST"])
def submit(request):
    """Handle form submission."""
    # Get form data
    form_data = request.POST.dict()

    # Extract client information from request headers for accurate tracking
    # Note: Use HTTP_X_FORWARDED_FOR when behind proxies, load balancers, or CDNs
    forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded_for:
        # X-Forwarded-For can contain multiple IPs, get the first one (client IP)
        client_ip = forwarded_for.split(",")[0].strip()
    else:
        client_ip = request.META.get("REMOTE_ADDR", "127.0.0.1")
    
    user_agent = request.META.get("HTTP_USER_AGENT", "unknown")
    referer = request.META.get("HTTP_REFERER")

    # Get API key
    api_key = os.environ.get("FORMINIT_API_KEY")
    if not api_key:
        return JsonResponse(
            {"success": False, "message": "API key not configured"},
            status=500,
        )

    # Create client and set user info
    client = ForminitClient(api_key=api_key)
    client.set_user_info(
        ip=client_ip,
        user_agent=user_agent,
        referer=referer,
    )

    result = client.submit(
        form_id=os.environ.get("FORMINIT_FORM_ID", "your-form-id"),
        data=form_data,
    )

    client.close()

    if "error" in result:
        return JsonResponse(
            {
                "success": False,
                "message": result["error"].get("message", "Submission failed"),
            },
            status=result["error"].get("code", 400),
        )

    return JsonResponse({"success": True, "submissionId": result["data"]["hashId"]})


@csrf_exempt
@require_http_methods(["POST"])
def direct_submit(request):
    """Handle direct JSON submission."""
    try:
        data = json.loads(request.body)
    except json.JSONDecodeError:
        return JsonResponse(
            {"success": False, "message": "Invalid JSON"},
            status=400,
        )

    api_key = os.environ.get("FORMINIT_API_KEY")
    if not api_key:
        return JsonResponse(
            {"success": False, "message": "API key not configured"},
            status=500,
        )

    # Extract client information from request headers for accurate tracking
    forwarded_for = request.META.get("HTTP_X_FORWARDED_FOR")
    if forwarded_for:
        client_ip = forwarded_for.split(",")[0].strip()
    else:
        client_ip = request.META.get("REMOTE_ADDR", "127.0.0.1")
    
    user_agent = request.META.get("HTTP_USER_AGENT", "unknown")
    referer = request.META.get("HTTP_REFERER")

    # Build structured submission
    submission = {
        "blocks": [
            {
                "type": "sender",
                "properties": {
                    "email": data.get("email"),
                    "firstName": data.get("firstName"),
                    "lastName": data.get("lastName"),
                },
            },
            {"type": "text", "name": "message", "value": data.get("message")},
        ]
    }

    client = ForminitClient(api_key=api_key)
    client.set_user_info(
        ip=client_ip,
        user_agent=user_agent,
        referer=referer,
    )

    result = client.submit(
        form_id=data.get("formId", os.environ.get("FORMINIT_FORM_ID", "your-form-id")),
        data=submission,
        tracking=data.get("tracking"),
    )

    client.close()

    if "error" in result:
        return JsonResponse(
            {"success": False, "error": result["error"]},
            status=result["error"].get("code", 400),
        )

    return JsonResponse(
        {
            "success": True,
            "data": result["data"],
            "redirectUrl": result.get("redirectUrl"),
        }
    )
