"""URL configuration for contactform app."""

from django.urls import path

from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("submit/", views.submit, name="submit"),
    path("api/direct-submit/", views.direct_submit, name="direct_submit"),
]
