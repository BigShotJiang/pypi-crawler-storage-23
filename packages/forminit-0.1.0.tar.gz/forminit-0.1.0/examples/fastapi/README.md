# FastAPI Example

This example demonstrates how to use the Forminit SDK with FastAPI.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
```bash
export FORMINIT_API_KEY="your-api-key"
export FORMINIT_FORM_ID="your-form-id"
```

3. Run the application:
```bash
uvicorn main:app --reload
```

4. Open http://localhost:8000 in your browser

## Features

- Async form submission with AsyncForminitClient
- FormData submission
- Direct JSON submission with Pydantic models
- User info tracking (IP, User-Agent, Referer)
- Auto-generated API docs at http://localhost:8000/docs