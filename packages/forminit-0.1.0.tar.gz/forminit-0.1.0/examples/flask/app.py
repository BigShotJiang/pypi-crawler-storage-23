"""Flask example using Forminit SDK."""

import os

from flask import Flask, jsonify, render_template_string, request

from forminit import ForminitClient

app = Flask(__name__)

# HTML template for the contact form
HTML_TEMPLATE = """
<!DOCTYPE html>
<html>
<head>
    <title>Contact Form - Flask Example</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        textarea {
            height: 100px;
        }
        button {
            background: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background: #0056b3;
        }
        .success {
            color: green;
            margin-top: 10px;
        }
        .error {
            color: red;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <h1>Contact Us</h1>
    <form id="contactForm">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="fi-sender-fullName" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="fi-sender-email" required>
        </div>
        <div class="form-group">
            <label for="message">Message:</label>
            <textarea id="message" name="fi-text-message" required></textarea>
        </div>
        <button type="submit">Send Message</button>
        <div id="status"></div>
    </form>

    <script>
        document.getElementById('contactForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            const statusDiv = document.getElementById('status');
            statusDiv.textContent = 'Sending...';
            statusDiv.className = '';

            try {
                const response = await fetch('/submit', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();

                if (result.success) {
                    statusDiv.textContent = 'Message sent successfully!';
                    statusDiv.className = 'success';
                    e.target.reset();
                } else {
                    statusDiv.textContent = 'Error: ' + (result.message || 'Unknown error');
                    statusDiv.className = 'error';
                }
            } catch (error) {
                statusDiv.textContent = 'Error: ' + error.message;
                statusDiv.className = 'error';
            }
        });
    </script>
</body>
</html>
"""


@app.route("/")
def index():
    """Render the contact form."""
    return render_template_string(HTML_TEMPLATE)


@app.route("/submit", methods=["POST"])
def submit():
    """Handle form submission."""
    # Get form data
    form_data = request.form.to_dict()

    # Extract client information from request headers for accurate tracking
    # Note: Use X-Forwarded-For when behind proxies, load balancers, or CDNs
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    if client_ip and "," in client_ip:
        # X-Forwarded-For can contain multiple IPs, get the first one (client IP)
        client_ip = client_ip.split(",")[0].strip()
    
    user_agent = request.headers.get("User-Agent", "unknown")
    referer = request.headers.get("Referer")

    # Initialize Forminit client with API key
    api_key = os.environ.get("FORMINIT_API_KEY")
    if not api_key:
        return jsonify({"success": False, "message": "API key not configured"}), 500

    # Create client and set user info
    client = ForminitClient(api_key=api_key)
    client.set_user_info(
        ip=client_ip,
        user_agent=user_agent,
        referer=referer,
    )

    # Submit to Forminit
    result = client.submit(
        form_id=os.environ.get("FORMINIT_FORM_ID", "your-form-id"),
        data=form_data,
    )

    client.close()

    if "error" in result:
        return (
            jsonify(
                {
                    "success": False,
                    "message": result["error"].get("message", "Submission failed"),
                }
            ),
            400,
        )

    return jsonify({"success": True, "submissionId": result["data"]["hashId"]})


@app.route("/api/direct-submit", methods=["POST"])
def direct_submit():
    """Example of direct JSON submission with structured blocks."""
    data = request.get_json()

    api_key = os.environ.get("FORMINIT_API_KEY")
    if not api_key:
        return jsonify({"success": False, "message": "API key not configured"}), 500

    # Extract client information from request headers for accurate tracking
    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    if client_ip and "," in client_ip:
        client_ip = client_ip.split(",")[0].strip()
    
    user_agent = request.headers.get("User-Agent", "unknown")
    referer = request.headers.get("Referer")

    client = ForminitClient(api_key=api_key)
    client.set_user_info(
        ip=client_ip,
        user_agent=user_agent,
        referer=referer,
    )

    # Build structured submission
    submission = {
        "blocks": [
            {
                "type": "sender",
                "properties": {
                    "email": data.get("email"),
                    "firstName": data.get("firstName"),
                    "lastName": data.get("lastName"),
                },
            },
            {"type": "text", "name": "message", "value": data.get("message")},
        ]
    }

    result = client.submit(
        form_id=data.get("formId", os.environ.get("FORMINIT_FORM_ID", "your-form-id")),
        data=submission,
        tracking=data.get("tracking"),
    )

    client.close()

    if "error" in result:
        return jsonify({"success": False, "error": result["error"]}), 400

    return jsonify(
        {"success": True, "data": result["data"], "redirectUrl": result.get("redirectUrl")}
    )


if __name__ == "__main__":
    app.run(debug=True, port=5000)
