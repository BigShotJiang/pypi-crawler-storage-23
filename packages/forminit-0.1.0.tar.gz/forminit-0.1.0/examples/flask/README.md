# Flask Example

This example demonstrates how to use the Forminit SDK with Flask.

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set environment variables:
```bash
export FORMINIT_API_KEY="your-api-key"
export FORMINIT_FORM_ID="your-form-id"
```

3. Run the application:
```bash
python app.py
```

4. Open http://localhost:5000 in your browser

## Features

- Form submission with FormData
- Direct JSON submission with structured blocks
- User info tracking (IP, User-Agent, Referer)