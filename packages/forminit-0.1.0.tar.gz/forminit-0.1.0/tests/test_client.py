"""Tests for Forminit client."""

import pytest
import respx
from httpx import Response

from forminit import VERSION, AsyncForminitClient, ForminitClient


class TestForminitClient:
    """Tests for synchronous client."""

    def test_init_with_api_key(self):
        """Test client initialization with API key."""
        client = ForminitClient(api_key="test-key")
        assert client.api_key == "test-key"
        client.close()

    def test_init_with_proxy_url(self):
        """Test client initialization with proxy URL."""
        client = ForminitClient(proxy_url="https://example.com/proxy")
        assert client.proxy_url == "https://example.com/proxy"
        client.close()

    def test_context_manager(self):
        """Test client as context manager."""
        with ForminitClient(api_key="test-key") as client:
            assert client.api_key == "test-key"

    def test_set_user_info(self):
        """Test setting user information."""
        client = ForminitClient(api_key="test-key")
        client.set_user_info(
            ip="192.168.1.1",
            user_agent="TestAgent/1.0",
            referer="https://example.com",
        )
        assert client._user_info is not None
        assert client._user_info.ip == "192.168.1.1"
        assert client._user_info.user_agent == "TestAgent/1.0"
        assert client._user_info.referer == "https://example.com"
        client.close()

    @respx.mock
    def test_submit_json_success(self):
        """Test successful JSON submission."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "abc123",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                    "redirectUrl": "https://example.com/thanks",
                },
            )
        )

        with ForminitClient(api_key="test-key") as client:
            result = client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "message", "value": "Hello"}]},
            )

        assert "error" not in result
        assert "data" in result
        assert result["data"]["hashId"] == "abc123"
        assert result["redirectUrl"] == "https://example.com/thanks"
        assert route.called

    @respx.mock
    def test_submit_form_data_success(self):
        """Test successful form data submission."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "def456",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                },
            )
        )

        with ForminitClient(api_key="test-key") as client:
            result = client.submit(
                "test-form",
                {"name": "John", "email": "john@example.com"},
            )

        assert "error" not in result
        assert "data" in result
        assert result["data"]["hashId"] == "def456"
        assert route.called

    @respx.mock
    def test_submit_error_response(self):
        """Test handling error response."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                400,
                json={
                    "success": False,
                    "error": "VALIDATION_ERROR",
                    "message": "Invalid email format",
                    "fieldName": "email",
                    "code": 400,
                },
            )
        )

        with ForminitClient(api_key="test-key") as client:
            result = client.submit(
                "test-form",
                {"blocks": [{"type": "email", "name": "email", "value": "invalid"}]},
            )

        assert "error" in result
        assert result["error"]["error"] == "VALIDATION_ERROR"
        assert result["error"]["fieldName"] == "email"
        assert route.called

    def test_submit_without_api_key(self):
        """Test submission without API key returns error."""
        client = ForminitClient()
        result = client.submit(
            "test-form",
            {"blocks": [{"type": "text", "name": "test", "value": "data"}]},
        )

        assert "error" in result
        assert result["error"]["error"] == "MISSING_API_KEY"
        assert result["error"]["code"] == 401
        client.close()

    @respx.mock
    def test_submit_with_tracking(self):
        """Test submission with tracking parameters."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "ghi789",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                },
            )
        )

        with ForminitClient(api_key="test-key") as client:
            result = client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "message", "value": "Hello"}]},
                tracking={"utmSource": "newsletter", "utmMedium": "email"},
            )

        assert "error" not in result
        assert route.called

    @respx.mock
    def test_submit_to_proxy(self):
        """Test submission through proxy URL."""
        route = respx.post("https://example.com/proxy").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "jkl012",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                },
            )
        )

        with ForminitClient(proxy_url="https://example.com/proxy") as client:
            result = client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "message", "value": "Hello"}]},
            )

        assert "error" not in result
        assert "data" in result
        assert route.called

    @respx.mock
    def test_submit_json_decode_error(self):
        """Test handling non-JSON response."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(200, text="not valid json")
        )

        with ForminitClient(api_key="test-key") as client:
            result = client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "test", "value": "data"}]},
            )

        assert "error" in result
        assert result["error"]["error"] == "PARSE_ERROR"
        assert route.called


class TestAsyncForminitClient:
    """Tests for asynchronous client."""

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_submit_success(self):
        """Test successful async submission."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "mno345",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                },
            )
        )

        async with AsyncForminitClient(api_key="test-key") as client:
            result = await client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "message", "value": "Hello"}]},
            )

        assert "error" not in result
        assert "data" in result
        assert result["data"]["hashId"] == "mno345"
        assert route.called

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_submit_error(self):
        """Test async error handling."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                500,
                json={
                    "success": False,
                    "error": "SERVER_ERROR",
                    "message": "Internal server error",
                    "code": 500,
                },
            )
        )

        async with AsyncForminitClient(api_key="test-key") as client:
            result = await client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "test", "value": "data"}]},
            )

        assert "error" in result
        assert result["error"]["error"] == "SERVER_ERROR"
        assert result["error"]["code"] == 500
        assert route.called

    @pytest.mark.asyncio
    async def test_async_submit_without_api_key(self):
        """Test async submission without API key."""
        client = AsyncForminitClient()
        result = await client.submit(
            "test-form",
            {"blocks": [{"type": "text", "name": "test", "value": "data"}]},
        )

        assert "error" in result
        assert result["error"]["error"] == "MISSING_API_KEY"
        await client.close()

    @pytest.mark.asyncio
    @respx.mock
    async def test_async_context_manager(self):
        """Test async client as context manager."""
        route = respx.post("https://forminit.com/f/test-form").mock(
            return_value=Response(
                200,
                json={
                    "success": True,
                    "submission": {
                        "hashId": "pqr678",
                        "date": "2024-01-01T00:00:00Z",
                        "blocks": {},
                        "submissionInfo": {
                            "ip": "192.168.1.1",
                            "user_agent": "Test",
                            "referer": None,
                            "sdk_version": VERSION,
                            "location": {
                                "country": {"name": "Turkey", "iso": "TR"},
                                "city": {"name": "Istanbul"},
                                "geo": {"lat": 41.0, "lng": 29.0},
                                "timezone": "Europe/Istanbul",
                            },
                        },
                    },
                },
            )
        )

        async with AsyncForminitClient(api_key="test-key") as client:
            result = await client.submit(
                "test-form",
                {"blocks": [{"type": "text", "name": "message", "value": "Hello"}]},
            )

        assert "error" not in result
        assert route.called
