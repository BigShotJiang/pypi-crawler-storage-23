"""Tests for radio and checkbox block types."""

from forminit.types import CheckboxBlock, FormSubmissionData, RadioBlock


class TestRadioCheckboxTypes:
    """Tests for radio and checkbox type definitions."""

    def test_radio_block(self):
        """Test radio block type."""
        radio: RadioBlock = {
            "type": "radio",
            "name": "size",
            "value": "medium",
        }
        
        assert radio["type"] == "radio"
        assert radio["name"] == "size"
        assert radio["value"] == "medium"

    def test_checkbox_block(self):
        """Test checkbox block type."""
        checkbox: CheckboxBlock = {
            "type": "checkbox",
            "name": "interests",
            "value": ["coding", "design", "marketing"],
        }
        
        assert checkbox["type"] == "checkbox"
        assert checkbox["name"] == "interests"
        assert len(checkbox["value"]) == 3

    def test_form_submission_with_radio_checkbox(self):
        """Test form submission with radio and checkbox blocks."""
        submission: FormSubmissionData = {
            "blocks": [
                {
                    "type": "radio",
                    "name": "plan",
                    "value": "premium",
                },
                {
                    "type": "checkbox",
                    "name": "features",
                    "value": ["api", "support", "analytics"],
                },
            ]
        }
        
        assert len(submission["blocks"]) == 2
        assert submission["blocks"][0]["type"] == "radio"
        assert submission["blocks"][1]["type"] == "checkbox"
