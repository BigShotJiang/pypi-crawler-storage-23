"""Tests for Forminit types."""

from forminit.types import (
    FormResponse,
    FormSubmissionData,
    SenderBlock,
    TextBlock,
    TrackingBlock,
)


class TestTypes:
    """Tests for type definitions."""

    def test_tracking_block(self):
        """Test TrackingBlock structure."""
        block: TrackingBlock = {
            "type": "tracking",
            "properties": {
                "utmSource": "newsletter",
                "utmMedium": "email",
            },
        }
        assert block["type"] == "tracking"
        assert block["properties"]["utmSource"] == "newsletter"

    def test_sender_block(self):
        """Test SenderBlock structure."""
        block: SenderBlock = {
            "type": "sender",
            "properties": {
                "email": "test@example.com",
                "firstName": "John",
                "lastName": "Doe",
            },
        }
        assert block["type"] == "sender"
        assert block["properties"]["email"] == "test@example.com"

    def test_text_block(self):
        """Test TextBlock structure."""
        block: TextBlock = {
            "type": "text",
            "name": "message",
            "value": "Hello World",
        }
        assert block["type"] == "text"
        assert block["name"] == "message"
        assert block["value"] == "Hello World"

    def test_form_submission_data(self):
        """Test FormSubmissionData structure."""
        data: FormSubmissionData = {
            "blocks": [
                {"type": "text", "name": "name", "value": "John"},
                {"type": "email", "name": "email", "value": "john@example.com"},
            ]
        }
        assert len(data["blocks"]) == 2
        assert data["blocks"][0]["type"] == "text"

    def test_form_response_success(self):
        """Test successful FormResponse structure."""
        response: FormResponse = {
            "data": {
                "hashId": "abc123",
                "date": "2024-01-01T00:00:00Z",
                "blocks": {},
                "submissionInfo": {
                    "ip": "192.168.1.1",
                    "user_agent": "Test",
                    "referer": None,
                    "sdk_version": "0.1.0",
                    "location": {
                        "country": {"name": "Turkey", "iso": "TR"},
                        "city": {"name": "Istanbul"},
                        "geo": {"lat": 41.0, "lng": 29.0},
                        "timezone": "Europe/Istanbul",
                    },
                },
            },
            "redirectUrl": "https://example.com/thanks",
        }
        assert "data" in response
        assert response["data"]["hashId"] == "abc123"
        assert response["redirectUrl"] == "https://example.com/thanks"

    def test_form_response_error(self):
        """Test error FormResponse structure."""
        response: FormResponse = {
            "error": {
                "success": False,
                "error": "VALIDATION_ERROR",
                "message": "Invalid email",
                "fieldName": "email",
                "code": 400,
            }
        }
        assert "error" in response
        assert response["error"]["error"] == "VALIDATION_ERROR"
        assert response["error"]["code"] == 400
