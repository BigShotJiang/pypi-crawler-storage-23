"""Integration tests with real Forminit API.

Run with:
    FORMINIT_API_KEY=your-key FORMINIT_FORM_ID=your-form-id uv run pytest \
        tests/test_integration.py -v
"""

import os

import pytest

from forminit import AsyncForminitClient, ForminitClient

# Skip if no API key provided
pytestmark = pytest.mark.skipif(
    not os.environ.get("FORMINIT_API_KEY"),
    reason="FORMINIT_API_KEY not set",
)


@pytest.fixture
def api_key():
    """Get API key from environment."""
    return os.environ.get("FORMINIT_API_KEY")


@pytest.fixture
def form_id():
    """Get form ID from environment."""
    return os.environ.get("FORMINIT_FORM_ID", "test-form")


class TestIntegrationSync:
    """Integration tests for synchronous client."""

    def test_submit_real_form(self, api_key, form_id):
        """Test submitting to real Forminit API."""
        with ForminitClient(api_key=api_key) as client:
            result = client.submit(
                form_id=form_id,
                data={
                    "blocks": [
                        {
                            "type": "sender",
                            "properties": {
                                "email": "test@example.com",
                                "firstName": "Test",
                                "lastName": "User",
                            },
                        },
                        {
                            "type": "text",
                            "name": "message",
                            "value": "Integration test message",
                        },
                    ]
                },
            )

            # Check result
            if "error" in result:
                print(f"Error: {result['error']}")
                # Some errors are expected (e.g., form not found)
                assert "error" in result
            else:
                print(f"Success! Submission ID: {result['data']['hashId']}")
                assert "data" in result
                assert "hashId" in result["data"]

    def test_submit_form_data_style(self, api_key, form_id):
        """Test submitting form-style data."""
        with ForminitClient(api_key=api_key) as client:
            result = client.submit(
                form_id=form_id,
                data={
                    "fi-sender-fullName": "Test User",
                    "fi-sender-email": "test@example.com",
                    "fi-text-message": "Form-style test message",
                },
            )

            if "error" in result:
                print(f"Error: {result['error']}")
                assert "error" in result
            else:
                print(f"Success! Submission ID: {result['data']['hashId']}")
                assert "data" in result

    def test_submit_with_tracking(self, api_key, form_id):
        """Test submitting with tracking parameters."""
        with ForminitClient(api_key=api_key) as client:
            result = client.submit(
                form_id=form_id,
                data={
                    "blocks": [
                        {"type": "text", "name": "message", "value": "Test with tracking"},
                    ]
                },
                tracking={
                    "utmSource": "integration-test",
                    "utmMedium": "pytest",
                    "utmCampaign": "sdk-test",
                },
            )

            if "error" in result:
                print(f"Error: {result['error']}")
                assert "error" in result
            else:
                print(f"Success! Submission ID: {result['data']['hashId']}")
                assert "data" in result


class TestIntegrationAsync:
    """Integration tests for asynchronous client."""

    @pytest.mark.asyncio
    async def test_async_submit_real_form(self, api_key, form_id):
        """Test async submission to real Forminit API."""
        async with AsyncForminitClient(api_key=api_key) as client:
            result = await client.submit(
                form_id=form_id,
                data={
                    "blocks": [
                        {
                            "type": "sender",
                            "properties": {
                                "email": "async-test@example.com",
                                "firstName": "Async",
                                "lastName": "Test",
                            },
                        },
                        {
                            "type": "text",
                            "name": "message",
                            "value": "Async integration test",
                        },
                    ]
                },
            )

            if "error" in result:
                print(f"Error: {result['error']}")
                assert "error" in result
            else:
                print(f"Success! Submission ID: {result['data']['hashId']}")
                assert "data" in result
                assert "hashId" in result["data"]
