"""Forminit client for sync and async form submissions."""

from __future__ import annotations

import json
from typing import Any

import httpx

from forminit.constants import BASE_URL, FORM_ID_KEY, TRACKING_PARAM_MAP, VERSION
from forminit.types import (
    FormBlock,
    FormResponse,
    FormResponseError,
    FormSubmissionData,
    TrackingBlock,
)


class UserInfo:
    """User information for form submissions."""

    def __init__(
        self,
        ip: str | None = None,
        user_agent: str | None = None,
        referer: str | None = None,
    ) -> None:
        self.ip = ip
        self.user_agent = user_agent
        self.referer = referer


class BaseClient:
    """Base client with common functionality."""

    def __init__(
        self,
        api_key: str | None = None,
        proxy_url: str | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        self.api_key = api_key
        self.proxy_url = proxy_url
        self.base_url = base_url
        self._user_info: UserInfo | None = None

    def set_user_info(
        self,
        ip: str | None = None,
        user_agent: str | None = None,
        referer: str | None = None,
    ) -> None:
        """Set user information for tracking."""
        self._user_info = UserInfo(ip=ip, user_agent=user_agent, referer=referer)

    def _get_tracking_block(self, tracking: dict[str, str] | None = None) -> TrackingBlock | None:
        """Build tracking block from provided tracking data."""
        properties: dict[str, str] = {}

        if tracking:
            for key, value in tracking.items():
                if key in TRACKING_PARAM_MAP.values():
                    properties[key] = value

        if properties:
            return {"type": "tracking", "properties": properties}
        return None

    def _build_headers(self, is_json: bool = True) -> dict[str, str]:
        """Build request headers."""
        headers: dict[str, str] = {
            "FormInit-SDK-Version": f"py_{VERSION}",
            "Accept": "application/json",
        }

        if is_json:
            headers["Content-Type"] = "application/json"

        if self.api_key:
            headers["X-API-KEY"] = self.api_key

        if self._user_info:
            if self._user_info.ip:
                headers["X-Forwarded-For"] = self._user_info.ip
                headers["X-Real-IP"] = self._user_info.ip
            if self._user_info.user_agent:
                headers["User-Agent"] = self._user_info.user_agent
            if self._user_info.referer:
                headers["Referer"] = self._user_info.referer

        return headers

    def _build_url(self, form_id: str) -> str:
        """Build submission URL."""
        if self.proxy_url:
            return self.proxy_url
        return f"{self.base_url}/f/{form_id}"

    def _prepare_json_body(
        self,
        form_id: str,
        data: FormSubmissionData,
        tracking: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Prepare JSON request body."""
        blocks: list[FormBlock] = list(data.get("blocks", []))

        # Add tracking block if provided
        tracking_block = self._get_tracking_block(tracking)
        if tracking_block:
            # Check if tracking block already exists
            existing_idx = next(
                (i for i, b in enumerate(blocks) if b.get("type") == "tracking"),
                None,
            )
            if existing_idx is not None:
                # Merge with existing
                existing = blocks[existing_idx]
                if "properties" in existing:
                    merged_props = {**existing["properties"], **tracking_block["properties"]}
                    blocks[existing_idx] = {"type": "tracking", "properties": merged_props}
            else:
                blocks.append(tracking_block)

        if self.proxy_url:
            return {FORM_ID_KEY: form_id, "data": {"blocks": blocks}}
        return {"blocks": blocks}

    def _prepare_form_data(
        self,
        form_id: str,
        data: dict[str, Any],
        tracking: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Prepare form data for submission."""
        result = dict(data)

        # Add tracking parameters
        if tracking:
            for key, value in tracking.items():
                tracking_key = f"fi-tracking-{key}"
                if tracking_key not in result:
                    result[tracking_key] = value

        if self.proxy_url:
            result[FORM_ID_KEY] = form_id

        return result

    def _parse_response(self, response_data: dict[str, Any]) -> FormResponse:
        """Parse API response into FormResponse."""
        if not response_data.get("success", False):
            error: FormResponseError = {
                "success": False,
                "error": response_data.get("error", "UNKNOWN_ERROR"),
                "message": response_data.get("message", "Unknown error"),
            }
            if "fieldName" in response_data:
                error["fieldName"] = response_data["fieldName"]
            if "code" in response_data:
                error["code"] = response_data["code"]
            return {"error": error}

        result: FormResponse = {}
        if "submission" in response_data:
            result["data"] = response_data["submission"]
        if "redirectUrl" in response_data:
            result["redirectUrl"] = response_data["redirectUrl"]
        return result


class ForminitClient(BaseClient):
    """Synchronous Forminit client."""

    def __init__(
        self,
        api_key: str | None = None,
        proxy_url: str | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        super().__init__(api_key=api_key, proxy_url=proxy_url, base_url=base_url)
        self._client = httpx.Client(timeout=30.0)

    def __enter__(self) -> ForminitClient:
        return self

    def __exit__(self, *args: object) -> None:
        self._client.close()

    def submit(
        self,
        form_id: str,
        data: FormSubmissionData | dict[str, Any],
        tracking: dict[str, str] | None = None,
    ) -> FormResponse:
        """
        Submit form data to Forminit.

        Args:
            form_id: The form identifier
            data: Form data as FormSubmissionData or flat dict
            tracking: Optional tracking parameters (utm_source, etc.)

        Returns:
            FormResponse with data or error
        """
        if not self.api_key and not self.proxy_url:
            return {
                "error": {
                    "success": False,
                    "error": "MISSING_API_KEY",
                    "message": "API key is required for server-side submissions",
                    "code": 401,
                }
            }

        url = self._build_url(form_id)

        # Check if data is a flat dict (form-like) or structured blocks
        if isinstance(data, dict) and "blocks" not in data:
            # Treat as flat form data
            form_data = self._prepare_form_data(form_id, data, tracking)
            headers = self._build_headers(is_json=False)
            response = self._client.post(url, data=form_data, headers=headers)
        else:
            # Treat as structured submission data
            body = self._prepare_json_body(
                form_id,
                data,
                tracking,  # type: ignore[arg-type]
            )
            headers = self._build_headers(is_json=True)
            response = self._client.post(url, json=body, headers=headers)

        try:
            response_data = response.json()
        except json.JSONDecodeError:
            return {
                "error": {
                    "success": False,
                    "error": "PARSE_ERROR",
                    "message": f"Failed to parse response: {response.text}",
                    "code": 500,
                }
            }

        if not response.is_success:
            error_response: FormResponseError = {
                "success": False,
                "error": response_data.get("error", "HTTP_ERROR"),
                "message": response_data.get(
                    "message", f"HTTP {response.status_code}: {response.reason_phrase}"
                ),
            }
            if "code" in response_data:
                error_response["code"] = response_data["code"]
            if "fieldName" in response_data:
                error_response["fieldName"] = response_data["fieldName"]
            return {"error": error_response}

        return self._parse_response(response_data)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()


class AsyncForminitClient(BaseClient):
    """Asynchronous Forminit client."""

    def __init__(
        self,
        api_key: str | None = None,
        proxy_url: str | None = None,
        base_url: str = BASE_URL,
    ) -> None:
        super().__init__(api_key=api_key, proxy_url=proxy_url, base_url=base_url)
        self._client = httpx.AsyncClient(timeout=30.0)

    async def __aenter__(self) -> AsyncForminitClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self._client.aclose()

    async def submit(
        self,
        form_id: str,
        data: FormSubmissionData | dict[str, Any],
        tracking: dict[str, str] | None = None,
    ) -> FormResponse:
        """
        Submit form data to Forminit asynchronously.

        Args:
            form_id: The form identifier
            data: Form data as FormSubmissionData or flat dict
            tracking: Optional tracking parameters (utm_source, etc.)

        Returns:
            FormResponse with data or error
        """
        if not self.api_key and not self.proxy_url:
            return {
                "error": {
                    "success": False,
                    "error": "MISSING_API_KEY",
                    "message": "API key is required for server-side submissions",
                    "code": 401,
                }
            }

        url = self._build_url(form_id)

        # Check if data is a flat dict (form-like) or structured blocks
        if isinstance(data, dict) and "blocks" not in data:
            # Treat as flat form data
            form_data = self._prepare_form_data(form_id, data, tracking)
            headers = self._build_headers(is_json=False)
            response = await self._client.post(url, data=form_data, headers=headers)
        else:
            # Treat as structured submission data
            body = self._prepare_json_body(
                form_id,
                data,
                tracking,  # type: ignore[arg-type]
            )
            headers = self._build_headers(is_json=True)
            response = await self._client.post(url, json=body, headers=headers)

        try:
            response_data = response.json()
        except json.JSONDecodeError:
            return {
                "error": {
                    "success": False,
                    "error": "PARSE_ERROR",
                    "message": f"Failed to parse response: {response.text}",
                    "code": 500,
                }
            }

        if not response.is_success:
            error_response: FormResponseError = {
                "success": False,
                "error": response_data.get("error", "HTTP_ERROR"),
                "message": response_data.get(
                    "message", f"HTTP {response.status_code}: {response.reason_phrase}"
                ),
            }
            if "code" in response_data:
                error_response["code"] = response_data["code"]
            if "fieldName" in response_data:
                error_response["fieldName"] = response_data["fieldName"]
            return {"error": error_response}

        return self._parse_response(response_data)

    async def close(self) -> None:
        """Close the HTTP client."""
        await self._client.aclose()
