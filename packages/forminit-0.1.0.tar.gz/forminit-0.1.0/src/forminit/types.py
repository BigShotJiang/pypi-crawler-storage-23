"""Type definitions for Forminit SDK."""

from __future__ import annotations

import sys
from typing import TYPE_CHECKING, Union

if sys.version_info >= (3, 11):
    from typing import Literal, NotRequired, TypedDict
else:
    from typing import Literal, TypedDict

    from typing_extensions import NotRequired

if TYPE_CHECKING:
    pass


class TrackingProperties(TypedDict):
    """Tracking parameter properties."""

    utmSource: NotRequired[str]
    utmMedium: NotRequired[str]
    utmCampaign: NotRequired[str]
    utmTerm: NotRequired[str]
    utmContent: NotRequired[str]
    gclid: NotRequired[str]
    wbraid: NotRequired[str]
    gbraid: NotRequired[str]
    fbclid: NotRequired[str]
    msclkid: NotRequired[str]
    ttclid: NotRequired[str]
    twclid: NotRequired[str]
    li_fat_id: NotRequired[str]
    amzclid: NotRequired[str]
    mc_cid: NotRequired[str]
    mc_eid: NotRequired[str]


class SenderProperties(TypedDict):
    """Sender block properties."""

    title: NotRequired[str]
    userId: NotRequired[str]
    firstName: NotRequired[str]
    lastName: NotRequired[str]
    fullName: NotRequired[str]
    email: NotRequired[str]
    phone: NotRequired[str]
    company: NotRequired[str]
    position: NotRequired[str]
    address: NotRequired[str]
    country: NotRequired[str]
    city: NotRequired[str]


class FileMetadata(TypedDict):
    """File block metadata."""

    filename: NotRequired[str]
    size: NotRequired[int]
    mimeType: NotRequired[str]
    url: NotRequired[str]


class TrackingBlock(TypedDict):
    """Tracking block for UTM and ad parameters."""

    type: Literal["tracking"]
    properties: TrackingProperties


class SenderBlock(TypedDict):
    """Sender block for user information."""

    type: Literal["sender"]
    properties: SenderProperties


class TextBlock(TypedDict):
    """Text input block."""

    type: Literal["text"]
    name: str
    value: str | int | bool


class NumberBlock(TypedDict):
    """Number input block."""

    type: Literal["number"]
    name: str
    value: str | int | bool


class RatingBlock(TypedDict):
    """Rating input block."""

    type: Literal["rating"]
    name: str
    value: str | int | bool


class DateBlock(TypedDict):
    """Date input block."""

    type: Literal["date"]
    name: str
    value: str | int | bool


class EmailBlock(TypedDict):
    """Email input block."""

    type: Literal["email"]
    name: str
    value: str | int | bool


class UrlBlock(TypedDict):
    """URL input block."""

    type: Literal["url"]
    name: str
    value: str | int | bool


class PhoneBlock(TypedDict):
    """Phone input block."""

    type: Literal["phone"]
    name: str
    value: str | int | bool


class CountryBlock(TypedDict):
    """Country input block."""

    type: Literal["country"]
    name: str
    value: str | int | bool


class SelectBlock(TypedDict):
    """Select/dropdown block."""

    type: Literal["select"]
    name: str
    value: str | list[str]


class RadioBlock(TypedDict):
    """Radio button block (single selection)."""

    type: Literal["radio"]
    name: str
    value: str


class CheckboxBlock(TypedDict):
    """Checkbox block (multiple selection)."""

    type: Literal["checkbox"]
    name: str
    value: list[str]


class FileBlock(TypedDict):
    """File upload block."""

    type: Literal["file"]
    name: str
    value: str
    metadata: NotRequired[FileMetadata]


FormBlock = Union[
    TrackingBlock,
    SenderBlock,
    TextBlock,
    NumberBlock,
    SelectBlock,
    RadioBlock,
    CheckboxBlock,
    EmailBlock,
    UrlBlock,
    PhoneBlock,
    RatingBlock,
    DateBlock,
    FileBlock,
    CountryBlock,
]


class FormSubmissionData(TypedDict):
    """Form submission data structure."""

    blocks: list[FormBlock]


class FormProxyData(TypedDict):
    """Data structure for proxy submissions."""

    forminitFormId: str
    data: FormSubmissionData


class LocationData(TypedDict):
    """Location data in submission response."""

    country: dict[str, str]
    city: dict[str, str]
    geo: dict[str, float]
    timezone: str


class SubmissionInfo(TypedDict):
    """Submission metadata."""

    ip: str
    user_agent: str
    referer: str | None
    sdk_version: str | None
    location: LocationData


class FormResponseDataSubmission(TypedDict):
    """Successful submission response data."""

    hashId: str
    date: str
    blocks: dict[str, object]
    submissionInfo: SubmissionInfo


class FormResponseData(TypedDict):
    """Successful response structure."""

    success: Literal[True]
    redirectUrl: NotRequired[str]
    submission: FormResponseDataSubmission


class FormResponseError(TypedDict):
    """Error response structure."""

    success: Literal[False]
    error: str
    message: str
    fieldName: NotRequired[str]
    code: NotRequired[int]


class FormResponse(TypedDict):
    """Form submission response."""

    data: NotRequired[FormResponseDataSubmission]
    redirectUrl: NotRequired[str]
    error: NotRequired[FormResponseError]
