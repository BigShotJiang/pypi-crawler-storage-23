"""Constants for Forminit SDK."""

from typing import Dict, List

VERSION = "0.1.0"
FORM_ID_KEY = "forminitFormId"
BASE_URL = "https://forminit.com"

# URL param (snake_case) -> Property name (camelCase) mapping
TRACKING_PARAM_MAP: Dict[str, str] = {
    "utm_source": "utmSource",
    "utm_medium": "utmMedium",
    "utm_campaign": "utmCampaign",
    "utm_term": "utmTerm",
    "utm_content": "utmContent",
    "gclid": "gclid",
    "wbraid": "wbraid",
    "gbraid": "gbraid",
    "fbclid": "fbclid",
    "msclkid": "msclkid",
    "ttclid": "ttclid",
    "twclid": "twclid",
    "li_fat_id": "li_fat_id",
    "amzclid": "amzclid",
    "mc_cid": "mc_cid",
    "mc_eid": "mc_eid",
}

TRACKING_KEYS: List[str] = [
    "utmSource",
    "utmMedium",
    "utmCampaign",
    "utmTerm",
    "utmContent",
    "gclid",
    "wbraid",
    "gbraid",
    "fbclid",
    "msclkid",
    "ttclid",
    "twclid",
    "li_fat_id",
    "amzclid",
    "mc_cid",
    "mc_eid",
]
