"""Aperture Writer.

Note to developers:
Use this module to extend honeybee's Aperture writer for new extensions.
(eg. adding `idf` to this module adds the method `Aperture.to.idf`)
"""
