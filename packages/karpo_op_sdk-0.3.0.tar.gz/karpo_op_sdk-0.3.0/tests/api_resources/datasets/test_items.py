# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from karpo_sdk import Karpo, AsyncKarpo
from tests.utils import assert_matches_type
from karpo_sdk.types import DatasetItem
from karpo_sdk.pagination import SyncOffsetPagination, AsyncOffsetPagination
from karpo_sdk.types.datasets import (
    ItemCreateResponse,
    ItemDeleteResponse,
    ItemUpdateResponse,
    ItemBatchDeleteResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestItems:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Karpo) -> None:
        item = client.datasets.items.create(
            id="id",
            input={"foo": "bar"},
        )
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    def test_method_create_with_all_params(self, client: Karpo) -> None:
        item = client.datasets.items.create(
            id="id",
            input={"foo": "bar"},
            expected_output={"foo": "bar"},
            metadata={"foo": "bar"},
        )
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Karpo) -> None:
        response = client.datasets.items.with_raw_response.create(
            id="id",
            input={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = response.parse()
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Karpo) -> None:
        with client.datasets.items.with_streaming_response.create(
            id="id",
            input={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = response.parse()
            assert_matches_type(ItemCreateResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.datasets.items.with_raw_response.create(
                id="",
                input={"foo": "bar"},
            )

    @parametrize
    def test_method_update(self, client: Karpo) -> None:
        item = client.datasets.items.update(
            item_id="itemId",
            id="id",
        )
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    def test_method_update_with_all_params(self, client: Karpo) -> None:
        item = client.datasets.items.update(
            item_id="itemId",
            id="id",
            expected_output={"foo": "bar"},
            input={"foo": "bar"},
            metadata={"foo": "bar"},
        )
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Karpo) -> None:
        response = client.datasets.items.with_raw_response.update(
            item_id="itemId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = response.parse()
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Karpo) -> None:
        with client.datasets.items.with_streaming_response.update(
            item_id="itemId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = response.parse()
            assert_matches_type(ItemUpdateResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.datasets.items.with_raw_response.update(
                item_id="itemId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            client.datasets.items.with_raw_response.update(
                item_id="",
                id="id",
            )

    @parametrize
    def test_method_list(self, client: Karpo) -> None:
        item = client.datasets.items.list(
            id="id",
        )
        assert_matches_type(SyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    def test_method_list_with_all_params(self, client: Karpo) -> None:
        item = client.datasets.items.list(
            id="id",
            page=0,
            page_size=0,
            search="search",
        )
        assert_matches_type(SyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Karpo) -> None:
        response = client.datasets.items.with_raw_response.list(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = response.parse()
        assert_matches_type(SyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Karpo) -> None:
        with client.datasets.items.with_streaming_response.list(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = response.parse()
            assert_matches_type(SyncOffsetPagination[DatasetItem], item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_list(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.datasets.items.with_raw_response.list(
                id="",
            )

    @parametrize
    def test_method_delete(self, client: Karpo) -> None:
        item = client.datasets.items.delete(
            item_id="itemId",
            id="id",
        )
        assert_matches_type(ItemDeleteResponse, item, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Karpo) -> None:
        response = client.datasets.items.with_raw_response.delete(
            item_id="itemId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = response.parse()
        assert_matches_type(ItemDeleteResponse, item, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Karpo) -> None:
        with client.datasets.items.with_streaming_response.delete(
            item_id="itemId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = response.parse()
            assert_matches_type(ItemDeleteResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.datasets.items.with_raw_response.delete(
                item_id="itemId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            client.datasets.items.with_raw_response.delete(
                item_id="",
                id="id",
            )

    @parametrize
    def test_method_batch_delete(self, client: Karpo) -> None:
        item = client.datasets.items.batch_delete(
            id="id",
            ids=["string"],
        )
        assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

    @parametrize
    def test_raw_response_batch_delete(self, client: Karpo) -> None:
        response = client.datasets.items.with_raw_response.batch_delete(
            id="id",
            ids=["string"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = response.parse()
        assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

    @parametrize
    def test_streaming_response_batch_delete(self, client: Karpo) -> None:
        with client.datasets.items.with_streaming_response.batch_delete(
            id="id",
            ids=["string"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = response.parse()
            assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_batch_delete(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.datasets.items.with_raw_response.batch_delete(
                id="",
                ids=["string"],
            )


class TestAsyncItems:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.create(
            id="id",
            input={"foo": "bar"},
        )
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.create(
            id="id",
            input={"foo": "bar"},
            expected_output={"foo": "bar"},
            metadata={"foo": "bar"},
        )
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncKarpo) -> None:
        response = await async_client.datasets.items.with_raw_response.create(
            id="id",
            input={"foo": "bar"},
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = await response.parse()
        assert_matches_type(ItemCreateResponse, item, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncKarpo) -> None:
        async with async_client.datasets.items.with_streaming_response.create(
            id="id",
            input={"foo": "bar"},
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = await response.parse()
            assert_matches_type(ItemCreateResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.datasets.items.with_raw_response.create(
                id="",
                input={"foo": "bar"},
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.update(
            item_id="itemId",
            id="id",
        )
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    async def test_method_update_with_all_params(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.update(
            item_id="itemId",
            id="id",
            expected_output={"foo": "bar"},
            input={"foo": "bar"},
            metadata={"foo": "bar"},
        )
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncKarpo) -> None:
        response = await async_client.datasets.items.with_raw_response.update(
            item_id="itemId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = await response.parse()
        assert_matches_type(ItemUpdateResponse, item, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncKarpo) -> None:
        async with async_client.datasets.items.with_streaming_response.update(
            item_id="itemId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = await response.parse()
            assert_matches_type(ItemUpdateResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.datasets.items.with_raw_response.update(
                item_id="itemId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            await async_client.datasets.items.with_raw_response.update(
                item_id="",
                id="id",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.list(
            id="id",
        )
        assert_matches_type(AsyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    async def test_method_list_with_all_params(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.list(
            id="id",
            page=0,
            page_size=0,
            search="search",
        )
        assert_matches_type(AsyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncKarpo) -> None:
        response = await async_client.datasets.items.with_raw_response.list(
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = await response.parse()
        assert_matches_type(AsyncOffsetPagination[DatasetItem], item, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncKarpo) -> None:
        async with async_client.datasets.items.with_streaming_response.list(
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = await response.parse()
            assert_matches_type(AsyncOffsetPagination[DatasetItem], item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_list(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.datasets.items.with_raw_response.list(
                id="",
            )

    @parametrize
    async def test_method_delete(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.delete(
            item_id="itemId",
            id="id",
        )
        assert_matches_type(ItemDeleteResponse, item, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncKarpo) -> None:
        response = await async_client.datasets.items.with_raw_response.delete(
            item_id="itemId",
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = await response.parse()
        assert_matches_type(ItemDeleteResponse, item, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncKarpo) -> None:
        async with async_client.datasets.items.with_streaming_response.delete(
            item_id="itemId",
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = await response.parse()
            assert_matches_type(ItemDeleteResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.datasets.items.with_raw_response.delete(
                item_id="itemId",
                id="",
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `item_id` but received ''"):
            await async_client.datasets.items.with_raw_response.delete(
                item_id="",
                id="id",
            )

    @parametrize
    async def test_method_batch_delete(self, async_client: AsyncKarpo) -> None:
        item = await async_client.datasets.items.batch_delete(
            id="id",
            ids=["string"],
        )
        assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

    @parametrize
    async def test_raw_response_batch_delete(self, async_client: AsyncKarpo) -> None:
        response = await async_client.datasets.items.with_raw_response.batch_delete(
            id="id",
            ids=["string"],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        item = await response.parse()
        assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

    @parametrize
    async def test_streaming_response_batch_delete(self, async_client: AsyncKarpo) -> None:
        async with async_client.datasets.items.with_streaming_response.batch_delete(
            id="id",
            ids=["string"],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            item = await response.parse()
            assert_matches_type(ItemBatchDeleteResponse, item, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_batch_delete(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.datasets.items.with_raw_response.batch_delete(
                id="",
                ids=["string"],
            )
