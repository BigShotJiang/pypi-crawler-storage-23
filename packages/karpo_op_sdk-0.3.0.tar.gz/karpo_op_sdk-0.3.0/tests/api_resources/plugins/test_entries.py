# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from karpo_sdk import Karpo, AsyncKarpo
from tests.utils import assert_matches_type
from karpo_sdk.types.plugins import EntrySetResponse, EntryDeleteResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestEntries:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_delete(self, client: Karpo) -> None:
        entry = client.plugins.entries.delete(
            key="key",
            id="id",
            version=0,
        )
        assert_matches_type(EntryDeleteResponse, entry, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Karpo) -> None:
        response = client.plugins.entries.with_raw_response.delete(
            key="key",
            id="id",
            version=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        entry = response.parse()
        assert_matches_type(EntryDeleteResponse, entry, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Karpo) -> None:
        with client.plugins.entries.with_streaming_response.delete(
            key="key",
            id="id",
            version=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            entry = response.parse()
            assert_matches_type(EntryDeleteResponse, entry, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.plugins.entries.with_raw_response.delete(
                key="key",
                id="",
                version=0,
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `key` but received ''"):
            client.plugins.entries.with_raw_response.delete(
                key="",
                id="id",
                version=0,
            )

    @parametrize
    def test_method_set(self, client: Karpo) -> None:
        entry = client.plugins.entries.set(
            version=0,
            id="id",
            content="content",
            key="key",
        )
        assert_matches_type(EntrySetResponse, entry, path=["response"])

    @parametrize
    def test_raw_response_set(self, client: Karpo) -> None:
        response = client.plugins.entries.with_raw_response.set(
            version=0,
            id="id",
            content="content",
            key="key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        entry = response.parse()
        assert_matches_type(EntrySetResponse, entry, path=["response"])

    @parametrize
    def test_streaming_response_set(self, client: Karpo) -> None:
        with client.plugins.entries.with_streaming_response.set(
            version=0,
            id="id",
            content="content",
            key="key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            entry = response.parse()
            assert_matches_type(EntrySetResponse, entry, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_set(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.plugins.entries.with_raw_response.set(
                version=0,
                id="",
                content="content",
                key="key",
            )


class TestAsyncEntries:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_delete(self, async_client: AsyncKarpo) -> None:
        entry = await async_client.plugins.entries.delete(
            key="key",
            id="id",
            version=0,
        )
        assert_matches_type(EntryDeleteResponse, entry, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncKarpo) -> None:
        response = await async_client.plugins.entries.with_raw_response.delete(
            key="key",
            id="id",
            version=0,
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        entry = await response.parse()
        assert_matches_type(EntryDeleteResponse, entry, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncKarpo) -> None:
        async with async_client.plugins.entries.with_streaming_response.delete(
            key="key",
            id="id",
            version=0,
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            entry = await response.parse()
            assert_matches_type(EntryDeleteResponse, entry, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.plugins.entries.with_raw_response.delete(
                key="key",
                id="",
                version=0,
            )

        with pytest.raises(ValueError, match=r"Expected a non-empty value for `key` but received ''"):
            await async_client.plugins.entries.with_raw_response.delete(
                key="",
                id="id",
                version=0,
            )

    @parametrize
    async def test_method_set(self, async_client: AsyncKarpo) -> None:
        entry = await async_client.plugins.entries.set(
            version=0,
            id="id",
            content="content",
            key="key",
        )
        assert_matches_type(EntrySetResponse, entry, path=["response"])

    @parametrize
    async def test_raw_response_set(self, async_client: AsyncKarpo) -> None:
        response = await async_client.plugins.entries.with_raw_response.set(
            version=0,
            id="id",
            content="content",
            key="key",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        entry = await response.parse()
        assert_matches_type(EntrySetResponse, entry, path=["response"])

    @parametrize
    async def test_streaming_response_set(self, async_client: AsyncKarpo) -> None:
        async with async_client.plugins.entries.with_streaming_response.set(
            version=0,
            id="id",
            content="content",
            key="key",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            entry = await response.parse()
            assert_matches_type(EntrySetResponse, entry, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_set(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.plugins.entries.with_raw_response.set(
                version=0,
                id="",
                content="content",
                key="key",
            )
