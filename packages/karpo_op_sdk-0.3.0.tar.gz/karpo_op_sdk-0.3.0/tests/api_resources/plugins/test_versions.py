# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from karpo_sdk import Karpo, AsyncKarpo
from tests.utils import assert_matches_type
from karpo_sdk.types.plugins import (
    VersionCreateResponse,
    VersionPublishResponse,
    VersionRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestVersions:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Karpo) -> None:
        version = client.plugins.versions.create(
            "id",
        )
        assert_matches_type(VersionCreateResponse, version, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Karpo) -> None:
        response = client.plugins.versions.with_raw_response.create(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = response.parse()
        assert_matches_type(VersionCreateResponse, version, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Karpo) -> None:
        with client.plugins.versions.with_streaming_response.create(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = response.parse()
            assert_matches_type(VersionCreateResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_create(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.plugins.versions.with_raw_response.create(
                "",
            )

    @parametrize
    def test_method_retrieve(self, client: Karpo) -> None:
        version = client.plugins.versions.retrieve(
            version=0,
            id="id",
        )
        assert_matches_type(VersionRetrieveResponse, version, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Karpo) -> None:
        response = client.plugins.versions.with_raw_response.retrieve(
            version=0,
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = response.parse()
        assert_matches_type(VersionRetrieveResponse, version, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Karpo) -> None:
        with client.plugins.versions.with_streaming_response.retrieve(
            version=0,
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = response.parse()
            assert_matches_type(VersionRetrieveResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.plugins.versions.with_raw_response.retrieve(
                version=0,
                id="",
            )

    @parametrize
    def test_method_publish(self, client: Karpo) -> None:
        version = client.plugins.versions.publish(
            version=0,
            id="id",
        )
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    def test_method_publish_with_all_params(self, client: Karpo) -> None:
        version = client.plugins.versions.publish(
            version=0,
            id="id",
            change_note="changeNote",
        )
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    def test_raw_response_publish(self, client: Karpo) -> None:
        response = client.plugins.versions.with_raw_response.publish(
            version=0,
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = response.parse()
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    def test_streaming_response_publish(self, client: Karpo) -> None:
        with client.plugins.versions.with_streaming_response.publish(
            version=0,
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = response.parse()
            assert_matches_type(VersionPublishResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_publish(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.plugins.versions.with_raw_response.publish(
                version=0,
                id="",
            )


class TestAsyncVersions:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncKarpo) -> None:
        version = await async_client.plugins.versions.create(
            "id",
        )
        assert_matches_type(VersionCreateResponse, version, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncKarpo) -> None:
        response = await async_client.plugins.versions.with_raw_response.create(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = await response.parse()
        assert_matches_type(VersionCreateResponse, version, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncKarpo) -> None:
        async with async_client.plugins.versions.with_streaming_response.create(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = await response.parse()
            assert_matches_type(VersionCreateResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_create(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.plugins.versions.with_raw_response.create(
                "",
            )

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncKarpo) -> None:
        version = await async_client.plugins.versions.retrieve(
            version=0,
            id="id",
        )
        assert_matches_type(VersionRetrieveResponse, version, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncKarpo) -> None:
        response = await async_client.plugins.versions.with_raw_response.retrieve(
            version=0,
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = await response.parse()
        assert_matches_type(VersionRetrieveResponse, version, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncKarpo) -> None:
        async with async_client.plugins.versions.with_streaming_response.retrieve(
            version=0,
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = await response.parse()
            assert_matches_type(VersionRetrieveResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.plugins.versions.with_raw_response.retrieve(
                version=0,
                id="",
            )

    @parametrize
    async def test_method_publish(self, async_client: AsyncKarpo) -> None:
        version = await async_client.plugins.versions.publish(
            version=0,
            id="id",
        )
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    async def test_method_publish_with_all_params(self, async_client: AsyncKarpo) -> None:
        version = await async_client.plugins.versions.publish(
            version=0,
            id="id",
            change_note="changeNote",
        )
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    async def test_raw_response_publish(self, async_client: AsyncKarpo) -> None:
        response = await async_client.plugins.versions.with_raw_response.publish(
            version=0,
            id="id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        version = await response.parse()
        assert_matches_type(VersionPublishResponse, version, path=["response"])

    @parametrize
    async def test_streaming_response_publish(self, async_client: AsyncKarpo) -> None:
        async with async_client.plugins.versions.with_streaming_response.publish(
            version=0,
            id="id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            version = await response.parse()
            assert_matches_type(VersionPublishResponse, version, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_publish(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.plugins.versions.with_raw_response.publish(
                version=0,
                id="",
            )
