# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from karpo_sdk import Karpo, AsyncKarpo
from tests.utils import assert_matches_type
from karpo_sdk.types import (
    UserGroupListResponse,
    UserGroupCreateResponse,
    UserGroupDeleteResponse,
    UserGroupUpdateResponse,
    UserGroupRetrieveResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestUserGroups:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_create(self, client: Karpo) -> None:
        user_group = client.user_groups.create(
            name="name",
        )
        assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

    @parametrize
    def test_raw_response_create(self, client: Karpo) -> None:
        response = client.user_groups.with_raw_response.create(
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = response.parse()
        assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

    @parametrize
    def test_streaming_response_create(self, client: Karpo) -> None:
        with client.user_groups.with_streaming_response.create(
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = response.parse()
            assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_retrieve(self, client: Karpo) -> None:
        user_group = client.user_groups.retrieve(
            "id",
        )
        assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

    @parametrize
    def test_raw_response_retrieve(self, client: Karpo) -> None:
        response = client.user_groups.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = response.parse()
        assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

    @parametrize
    def test_streaming_response_retrieve(self, client: Karpo) -> None:
        with client.user_groups.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = response.parse()
            assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_retrieve(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.with_raw_response.retrieve(
                "",
            )

    @parametrize
    def test_method_update(self, client: Karpo) -> None:
        user_group = client.user_groups.update(
            id="id",
            name="name",
        )
        assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

    @parametrize
    def test_raw_response_update(self, client: Karpo) -> None:
        response = client.user_groups.with_raw_response.update(
            id="id",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = response.parse()
        assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

    @parametrize
    def test_streaming_response_update(self, client: Karpo) -> None:
        with client.user_groups.with_streaming_response.update(
            id="id",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = response.parse()
            assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_update(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.with_raw_response.update(
                id="",
                name="name",
            )

    @parametrize
    def test_method_list(self, client: Karpo) -> None:
        user_group = client.user_groups.list()
        assert_matches_type(UserGroupListResponse, user_group, path=["response"])

    @parametrize
    def test_raw_response_list(self, client: Karpo) -> None:
        response = client.user_groups.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = response.parse()
        assert_matches_type(UserGroupListResponse, user_group, path=["response"])

    @parametrize
    def test_streaming_response_list(self, client: Karpo) -> None:
        with client.user_groups.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = response.parse()
            assert_matches_type(UserGroupListResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_method_delete(self, client: Karpo) -> None:
        user_group = client.user_groups.delete(
            "id",
        )
        assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

    @parametrize
    def test_raw_response_delete(self, client: Karpo) -> None:
        response = client.user_groups.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = response.parse()
        assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

    @parametrize
    def test_streaming_response_delete(self, client: Karpo) -> None:
        with client.user_groups.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = response.parse()
            assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_delete(self, client: Karpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            client.user_groups.with_raw_response.delete(
                "",
            )


class TestAsyncUserGroups:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_create(self, async_client: AsyncKarpo) -> None:
        user_group = await async_client.user_groups.create(
            name="name",
        )
        assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

    @parametrize
    async def test_raw_response_create(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.with_raw_response.create(
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = await response.parse()
        assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.with_streaming_response.create(
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = await response.parse()
            assert_matches_type(UserGroupCreateResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_retrieve(self, async_client: AsyncKarpo) -> None:
        user_group = await async_client.user_groups.retrieve(
            "id",
        )
        assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

    @parametrize
    async def test_raw_response_retrieve(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.with_raw_response.retrieve(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = await response.parse()
        assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

    @parametrize
    async def test_streaming_response_retrieve(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.with_streaming_response.retrieve(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = await response.parse()
            assert_matches_type(UserGroupRetrieveResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_retrieve(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.with_raw_response.retrieve(
                "",
            )

    @parametrize
    async def test_method_update(self, async_client: AsyncKarpo) -> None:
        user_group = await async_client.user_groups.update(
            id="id",
            name="name",
        )
        assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

    @parametrize
    async def test_raw_response_update(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.with_raw_response.update(
            id="id",
            name="name",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = await response.parse()
        assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

    @parametrize
    async def test_streaming_response_update(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.with_streaming_response.update(
            id="id",
            name="name",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = await response.parse()
            assert_matches_type(UserGroupUpdateResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_update(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.with_raw_response.update(
                id="",
                name="name",
            )

    @parametrize
    async def test_method_list(self, async_client: AsyncKarpo) -> None:
        user_group = await async_client.user_groups.list()
        assert_matches_type(UserGroupListResponse, user_group, path=["response"])

    @parametrize
    async def test_raw_response_list(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.with_raw_response.list()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = await response.parse()
        assert_matches_type(UserGroupListResponse, user_group, path=["response"])

    @parametrize
    async def test_streaming_response_list(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.with_streaming_response.list() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = await response.parse()
            assert_matches_type(UserGroupListResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_method_delete(self, async_client: AsyncKarpo) -> None:
        user_group = await async_client.user_groups.delete(
            "id",
        )
        assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

    @parametrize
    async def test_raw_response_delete(self, async_client: AsyncKarpo) -> None:
        response = await async_client.user_groups.with_raw_response.delete(
            "id",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        user_group = await response.parse()
        assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

    @parametrize
    async def test_streaming_response_delete(self, async_client: AsyncKarpo) -> None:
        async with async_client.user_groups.with_streaming_response.delete(
            "id",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            user_group = await response.parse()
            assert_matches_type(UserGroupDeleteResponse, user_group, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_delete(self, async_client: AsyncKarpo) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `id` but received ''"):
            await async_client.user_groups.with_raw_response.delete(
                "",
            )
