# Agents

Types:

```python
from karpo_sdk.types import (
    Agent,
    AgentVersion,
    AgentCreateResponse,
    AgentRetrieveResponse,
    AgentUpdateResponse,
    AgentDeleteResponse,
)
```

Methods:

- <code title="post /agents">client.agents.<a href="./src/karpo_sdk/resources/agents/agents.py">create</a>(\*\*<a href="src/karpo_sdk/types/agent_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agent_create_response.py">AgentCreateResponse</a></code>
- <code title="get /agents/{id}">client.agents.<a href="./src/karpo_sdk/resources/agents/agents.py">retrieve</a>(id, \*\*<a href="src/karpo_sdk/types/agent_retrieve_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agent_retrieve_response.py">AgentRetrieveResponse</a></code>
- <code title="put /agents/{id}">client.agents.<a href="./src/karpo_sdk/resources/agents/agents.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/agent_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agent_update_response.py">AgentUpdateResponse</a></code>
- <code title="get /agents">client.agents.<a href="./src/karpo_sdk/resources/agents/agents.py">list</a>(\*\*<a href="src/karpo_sdk/types/agent_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agent.py">SyncOffsetPagination[Agent]</a></code>
- <code title="delete /agents/{id}">client.agents.<a href="./src/karpo_sdk/resources/agents/agents.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/agent_delete_response.py">AgentDeleteResponse</a></code>

## Versions

Types:

```python
from karpo_sdk.types.agents import (
    VersionCreateResponse,
    VersionRetrieveResponse,
    VersionListResponse,
    VersionUpdateTagsResponse,
)
```

Methods:

- <code title="post /agents/{id}/versions">client.agents.versions.<a href="./src/karpo_sdk/resources/agents/versions.py">create</a>(id, \*\*<a href="src/karpo_sdk/types/agents/version_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agents/version_create_response.py">VersionCreateResponse</a></code>
- <code title="get /agents/{id}/versions/{version}">client.agents.versions.<a href="./src/karpo_sdk/resources/agents/versions.py">retrieve</a>(version, \*, id) -> <a href="./src/karpo_sdk/types/agents/version_retrieve_response.py">VersionRetrieveResponse</a></code>
- <code title="get /agents/{id}/versions">client.agents.versions.<a href="./src/karpo_sdk/resources/agents/versions.py">list</a>(id) -> <a href="./src/karpo_sdk/types/agents/version_list_response.py">VersionListResponse</a></code>
- <code title="put /agents/{id}/versions/{version}/tags">client.agents.versions.<a href="./src/karpo_sdk/resources/agents/versions.py">update_tags</a>(version, \*, id, \*\*<a href="src/karpo_sdk/types/agents/version_update_tags_params.py">params</a>) -> <a href="./src/karpo_sdk/types/agents/version_update_tags_response.py">VersionUpdateTagsResponse</a></code>

# Prompts

Types:

```python
from karpo_sdk.types import (
    Prompt,
    PromptMessage,
    PromptVersion,
    PromptCreateResponse,
    PromptRetrieveResponse,
    PromptUpdateResponse,
    PromptDeleteResponse,
)
```

Methods:

- <code title="post /prompts">client.prompts.<a href="./src/karpo_sdk/resources/prompts/prompts.py">create</a>(\*\*<a href="src/karpo_sdk/types/prompt_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompt_create_response.py">PromptCreateResponse</a></code>
- <code title="get /prompts/{id}">client.prompts.<a href="./src/karpo_sdk/resources/prompts/prompts.py">retrieve</a>(id, \*\*<a href="src/karpo_sdk/types/prompt_retrieve_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompt_retrieve_response.py">PromptRetrieveResponse</a></code>
- <code title="put /prompts/{id}">client.prompts.<a href="./src/karpo_sdk/resources/prompts/prompts.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/prompt_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompt_update_response.py">PromptUpdateResponse</a></code>
- <code title="get /prompts">client.prompts.<a href="./src/karpo_sdk/resources/prompts/prompts.py">list</a>(\*\*<a href="src/karpo_sdk/types/prompt_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompt.py">SyncOffsetPagination[Prompt]</a></code>
- <code title="delete /prompts/{id}">client.prompts.<a href="./src/karpo_sdk/resources/prompts/prompts.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/prompt_delete_response.py">PromptDeleteResponse</a></code>

## Versions

Types:

```python
from karpo_sdk.types.prompts import (
    VersionCreateResponse,
    VersionRetrieveResponse,
    VersionListResponse,
    VersionUpdateTagsResponse,
)
```

Methods:

- <code title="post /prompts/{id}/versions">client.prompts.versions.<a href="./src/karpo_sdk/resources/prompts/versions.py">create</a>(id, \*\*<a href="src/karpo_sdk/types/prompts/version_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompts/version_create_response.py">VersionCreateResponse</a></code>
- <code title="get /prompts/{id}/versions/{version}">client.prompts.versions.<a href="./src/karpo_sdk/resources/prompts/versions.py">retrieve</a>(version, \*, id) -> <a href="./src/karpo_sdk/types/prompts/version_retrieve_response.py">VersionRetrieveResponse</a></code>
- <code title="get /prompts/{id}/versions">client.prompts.versions.<a href="./src/karpo_sdk/resources/prompts/versions.py">list</a>(id) -> <a href="./src/karpo_sdk/types/prompts/version_list_response.py">VersionListResponse</a></code>
- <code title="put /prompts/{id}/versions/{version}/tags">client.prompts.versions.<a href="./src/karpo_sdk/resources/prompts/versions.py">update_tags</a>(version, \*, id, \*\*<a href="src/karpo_sdk/types/prompts/version_update_tags_params.py">params</a>) -> <a href="./src/karpo_sdk/types/prompts/version_update_tags_response.py">VersionUpdateTagsResponse</a></code>

# Plugins

Types:

```python
from karpo_sdk.types import (
    Plugin,
    PluginDetail,
    PluginEntry,
    PluginVersionDetail,
    PluginCreateResponse,
    PluginRetrieveResponse,
    PluginUpdateResponse,
    PluginListResponse,
)
```

Methods:

- <code title="post /plugins">client.plugins.<a href="./src/karpo_sdk/resources/plugins/plugins.py">create</a>(\*\*<a href="src/karpo_sdk/types/plugin_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/plugin_create_response.py">PluginCreateResponse</a></code>
- <code title="get /plugins/{id}">client.plugins.<a href="./src/karpo_sdk/resources/plugins/plugins.py">retrieve</a>(id) -> <a href="./src/karpo_sdk/types/plugin_retrieve_response.py">PluginRetrieveResponse</a></code>
- <code title="put /plugins/{id}">client.plugins.<a href="./src/karpo_sdk/resources/plugins/plugins.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/plugin_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/plugin_update_response.py">PluginUpdateResponse</a></code>
- <code title="get /plugins">client.plugins.<a href="./src/karpo_sdk/resources/plugins/plugins.py">list</a>(\*\*<a href="src/karpo_sdk/types/plugin_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/plugin_list_response.py">PluginListResponse</a></code>

## Versions

Types:

```python
from karpo_sdk.types.plugins import (
    VersionCreateResponse,
    VersionRetrieveResponse,
    VersionPublishResponse,
)
```

Methods:

- <code title="post /plugins/{id}/versions">client.plugins.versions.<a href="./src/karpo_sdk/resources/plugins/versions.py">create</a>(id) -> <a href="./src/karpo_sdk/types/plugins/version_create_response.py">VersionCreateResponse</a></code>
- <code title="get /plugins/{id}/versions/{version}">client.plugins.versions.<a href="./src/karpo_sdk/resources/plugins/versions.py">retrieve</a>(version, \*, id) -> <a href="./src/karpo_sdk/types/plugins/version_retrieve_response.py">VersionRetrieveResponse</a></code>
- <code title="post /plugins/{id}/versions/{version}/publish">client.plugins.versions.<a href="./src/karpo_sdk/resources/plugins/versions.py">publish</a>(version, \*, id, \*\*<a href="src/karpo_sdk/types/plugins/version_publish_params.py">params</a>) -> <a href="./src/karpo_sdk/types/plugins/version_publish_response.py">VersionPublishResponse</a></code>

## Entries

Types:

```python
from karpo_sdk.types.plugins import EntryDeleteResponse, EntrySetResponse
```

Methods:

- <code title="delete /plugins/{id}/versions/{version}/entries/{key}">client.plugins.entries.<a href="./src/karpo_sdk/resources/plugins/entries.py">delete</a>(key, \*, id, version) -> <a href="./src/karpo_sdk/types/plugins/entry_delete_response.py">EntryDeleteResponse</a></code>
- <code title="post /plugins/{id}/versions/{version}/entries">client.plugins.entries.<a href="./src/karpo_sdk/resources/plugins/entries.py">set</a>(version, \*, id, \*\*<a href="src/karpo_sdk/types/plugins/entry_set_params.py">params</a>) -> <a href="./src/karpo_sdk/types/plugins/entry_set_response.py">EntrySetResponse</a></code>

# Datasets

Types:

```python
from karpo_sdk.types import (
    Dataset,
    DatasetItem,
    DatasetWithItemCount,
    ImportResult,
    ImportSession,
    DatasetCreateResponse,
    DatasetRetrieveResponse,
    DatasetUpdateResponse,
    DatasetDeleteResponse,
    DatasetDuplicateResponse,
    DatasetExportResponse,
)
```

Methods:

- <code title="post /datasets">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">create</a>(\*\*<a href="src/karpo_sdk/types/dataset_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/dataset_create_response.py">DatasetCreateResponse</a></code>
- <code title="get /datasets/{id}">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">retrieve</a>(id) -> <a href="./src/karpo_sdk/types/dataset_retrieve_response.py">DatasetRetrieveResponse</a></code>
- <code title="put /datasets/{id}">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/dataset_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/dataset_update_response.py">DatasetUpdateResponse</a></code>
- <code title="get /datasets">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">list</a>(\*\*<a href="src/karpo_sdk/types/dataset_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/dataset_with_item_count.py">SyncOffsetPagination[DatasetWithItemCount]</a></code>
- <code title="delete /datasets/{id}">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/dataset_delete_response.py">DatasetDeleteResponse</a></code>
- <code title="post /datasets/{id}/duplicate">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">duplicate</a>(id) -> <a href="./src/karpo_sdk/types/dataset_duplicate_response.py">DatasetDuplicateResponse</a></code>
- <code title="get /datasets/{id}/export">client.datasets.<a href="./src/karpo_sdk/resources/datasets/datasets.py">export</a>(id, \*\*<a href="src/karpo_sdk/types/dataset_export_params.py">params</a>) -> <a href="./src/karpo_sdk/types/dataset_export_response.py">DatasetExportResponse</a></code>

## Items

Types:

```python
from karpo_sdk.types.datasets import (
    ItemCreateResponse,
    ItemUpdateResponse,
    ItemDeleteResponse,
    ItemBatchDeleteResponse,
)
```

Methods:

- <code title="post /datasets/{id}/items">client.datasets.items.<a href="./src/karpo_sdk/resources/datasets/items.py">create</a>(id, \*\*<a href="src/karpo_sdk/types/datasets/item_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/datasets/item_create_response.py">ItemCreateResponse</a></code>
- <code title="put /datasets/{id}/items/{itemId}">client.datasets.items.<a href="./src/karpo_sdk/resources/datasets/items.py">update</a>(item_id, \*, id, \*\*<a href="src/karpo_sdk/types/datasets/item_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/datasets/item_update_response.py">ItemUpdateResponse</a></code>
- <code title="get /datasets/{id}/items">client.datasets.items.<a href="./src/karpo_sdk/resources/datasets/items.py">list</a>(id, \*\*<a href="src/karpo_sdk/types/datasets/item_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/dataset_item.py">SyncOffsetPagination[DatasetItem]</a></code>
- <code title="delete /datasets/{id}/items/{itemId}">client.datasets.items.<a href="./src/karpo_sdk/resources/datasets/items.py">delete</a>(item_id, \*, id) -> <a href="./src/karpo_sdk/types/datasets/item_delete_response.py">ItemDeleteResponse</a></code>
- <code title="post /datasets/{id}/items/batch-delete">client.datasets.items.<a href="./src/karpo_sdk/resources/datasets/items.py">batch_delete</a>(id, \*\*<a href="src/karpo_sdk/types/datasets/item_batch_delete_params.py">params</a>) -> <a href="./src/karpo_sdk/types/datasets/item_batch_delete_response.py">ItemBatchDeleteResponse</a></code>

## Imports

Types:

```python
from karpo_sdk.types.datasets import (
    ImportCreateResponse,
    ImportAbortResponse,
    ImportAddBatchResponse,
    ImportFinishResponse,
)
```

Methods:

- <code title="post /datasets/{id}/imports">client.datasets.imports.<a href="./src/karpo_sdk/resources/datasets/imports.py">create</a>(id) -> <a href="./src/karpo_sdk/types/datasets/import_create_response.py">ImportCreateResponse</a></code>
- <code title="post /datasets/{id}/imports/{importId}/abort">client.datasets.imports.<a href="./src/karpo_sdk/resources/datasets/imports.py">abort</a>(import_id, \*, id) -> <a href="./src/karpo_sdk/types/datasets/import_abort_response.py">ImportAbortResponse</a></code>
- <code title="post /datasets/{id}/imports/{importId}/batches">client.datasets.imports.<a href="./src/karpo_sdk/resources/datasets/imports.py">add_batch</a>(import_id, \*, id, \*\*<a href="src/karpo_sdk/types/datasets/import_add_batch_params.py">params</a>) -> <a href="./src/karpo_sdk/types/datasets/import_add_batch_response.py">ImportAddBatchResponse</a></code>
- <code title="post /datasets/{id}/imports/{importId}/finish">client.datasets.imports.<a href="./src/karpo_sdk/resources/datasets/imports.py">finish</a>(import_id, \*, id) -> <a href="./src/karpo_sdk/types/datasets/import_finish_response.py">ImportFinishResponse</a></code>

# Playgrounds

Types:

```python
from karpo_sdk.types import (
    Message,
    Playground,
    PlaygroundDetail,
    PlaygroundThread,
    PlaygroundCreateResponse,
    PlaygroundRetrieveResponse,
    PlaygroundUpdateResponse,
    PlaygroundDeleteResponse,
)
```

Methods:

- <code title="post /playgrounds">client.playgrounds.<a href="./src/karpo_sdk/resources/playgrounds/playgrounds.py">create</a>(\*\*<a href="src/karpo_sdk/types/playground_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playground_create_response.py">PlaygroundCreateResponse</a></code>
- <code title="get /playgrounds/{id}">client.playgrounds.<a href="./src/karpo_sdk/resources/playgrounds/playgrounds.py">retrieve</a>(id) -> <a href="./src/karpo_sdk/types/playground_retrieve_response.py">PlaygroundRetrieveResponse</a></code>
- <code title="put /playgrounds/{id}">client.playgrounds.<a href="./src/karpo_sdk/resources/playgrounds/playgrounds.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/playground_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playground_update_response.py">PlaygroundUpdateResponse</a></code>
- <code title="get /playgrounds">client.playgrounds.<a href="./src/karpo_sdk/resources/playgrounds/playgrounds.py">list</a>(\*\*<a href="src/karpo_sdk/types/playground_list_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playground.py">SyncOffsetPagination[Playground]</a></code>
- <code title="delete /playgrounds/{id}">client.playgrounds.<a href="./src/karpo_sdk/resources/playgrounds/playgrounds.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/playground_delete_response.py">PlaygroundDeleteResponse</a></code>

## Threads

Types:

```python
from karpo_sdk.types.playgrounds import (
    ThreadCreateResponse,
    ThreadUpdateResponse,
    ThreadListResponse,
    ThreadDeleteResponse,
    ThreadChatResponse,
    ThreadListMessagesResponse,
)
```

Methods:

- <code title="post /playgrounds/{id}/threads">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">create</a>(id, \*\*<a href="src/karpo_sdk/types/playgrounds/thread_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playgrounds/thread_create_response.py">ThreadCreateResponse</a></code>
- <code title="put /playgrounds/{id}/threads/{threadId}">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">update</a>(thread_id, \*, id, \*\*<a href="src/karpo_sdk/types/playgrounds/thread_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playgrounds/thread_update_response.py">ThreadUpdateResponse</a></code>
- <code title="get /playgrounds/{id}/threads">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">list</a>(id) -> <a href="./src/karpo_sdk/types/playgrounds/thread_list_response.py">ThreadListResponse</a></code>
- <code title="delete /playgrounds/{id}/threads/{threadId}">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">delete</a>(thread_id, \*, id) -> <a href="./src/karpo_sdk/types/playgrounds/thread_delete_response.py">ThreadDeleteResponse</a></code>
- <code title="post /playgrounds/{id}/threads/{threadId}/chat">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">chat</a>(thread_id, \*, id, \*\*<a href="src/karpo_sdk/types/playgrounds/thread_chat_params.py">params</a>) -> str</code>
- <code title="get /playgrounds/{id}/threads/{threadId}/messages">client.playgrounds.threads.<a href="./src/karpo_sdk/resources/playgrounds/threads.py">list_messages</a>(thread_id, \*, id, \*\*<a href="src/karpo_sdk/types/playgrounds/thread_list_messages_params.py">params</a>) -> <a href="./src/karpo_sdk/types/playgrounds/thread_list_messages_response.py">ThreadListMessagesResponse</a></code>

# UserGroups

Types:

```python
from karpo_sdk.types import (
    UserGroup,
    UserGroupMember,
    UserGroupCreateResponse,
    UserGroupRetrieveResponse,
    UserGroupUpdateResponse,
    UserGroupListResponse,
    UserGroupDeleteResponse,
)
```

Methods:

- <code title="post /user-groups">client.user_groups.<a href="./src/karpo_sdk/resources/user_groups/user_groups.py">create</a>(\*\*<a href="src/karpo_sdk/types/user_group_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/user_group_create_response.py">UserGroupCreateResponse</a></code>
- <code title="get /user-groups/{id}">client.user_groups.<a href="./src/karpo_sdk/resources/user_groups/user_groups.py">retrieve</a>(id) -> <a href="./src/karpo_sdk/types/user_group_retrieve_response.py">UserGroupRetrieveResponse</a></code>
- <code title="put /user-groups/{id}">client.user_groups.<a href="./src/karpo_sdk/resources/user_groups/user_groups.py">update</a>(id, \*\*<a href="src/karpo_sdk/types/user_group_update_params.py">params</a>) -> <a href="./src/karpo_sdk/types/user_group_update_response.py">UserGroupUpdateResponse</a></code>
- <code title="get /user-groups">client.user_groups.<a href="./src/karpo_sdk/resources/user_groups/user_groups.py">list</a>() -> <a href="./src/karpo_sdk/types/user_group_list_response.py">UserGroupListResponse</a></code>
- <code title="delete /user-groups/{id}">client.user_groups.<a href="./src/karpo_sdk/resources/user_groups/user_groups.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/user_group_delete_response.py">UserGroupDeleteResponse</a></code>

## Members

Types:

```python
from karpo_sdk.types.user_groups import (
    MemberCreateResponse,
    MemberListResponse,
    MemberDeleteResponse,
    MemberListAvailableResponse,
)
```

Methods:

- <code title="post /user-groups/{id}/members">client.user_groups.members.<a href="./src/karpo_sdk/resources/user_groups/members.py">create</a>(id, \*\*<a href="src/karpo_sdk/types/user_groups/member_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/user_groups/member_create_response.py">MemberCreateResponse</a></code>
- <code title="get /user-groups/{id}/members">client.user_groups.members.<a href="./src/karpo_sdk/resources/user_groups/members.py">list</a>(id) -> <a href="./src/karpo_sdk/types/user_groups/member_list_response.py">MemberListResponse</a></code>
- <code title="delete /user-groups/{id}/members/{userId}">client.user_groups.members.<a href="./src/karpo_sdk/resources/user_groups/members.py">delete</a>(user_id, \*, id) -> <a href="./src/karpo_sdk/types/user_groups/member_delete_response.py">MemberDeleteResponse</a></code>
- <code title="get /user-groups/{id}/available-users">client.user_groups.members.<a href="./src/karpo_sdk/resources/user_groups/members.py">list_available</a>(id) -> <a href="./src/karpo_sdk/types/user_groups/member_list_available_response.py">MemberListAvailableResponse</a></code>

# Models

Types:

```python
from karpo_sdk.types import LlmModel, ModelListEnabledResponse
```

Methods:

- <code title="get /models/enabled">client.models.<a href="./src/karpo_sdk/resources/models.py">list_enabled</a>() -> <a href="./src/karpo_sdk/types/model_list_enabled_response.py">ModelListEnabledResponse</a></code>

# Providers

Types:

```python
from karpo_sdk.types import Provider, ProviderListEnabledResponse
```

Methods:

- <code title="get /providers/enabled">client.providers.<a href="./src/karpo_sdk/resources/providers.py">list_enabled</a>() -> <a href="./src/karpo_sdk/types/provider_list_enabled_response.py">ProviderListEnabledResponse</a></code>

# APIKeys

Types:

```python
from karpo_sdk.types import (
    APIKey,
    CreateAPIKeyResponse,
    APIKeyCreateResponse,
    APIKeyListResponse,
    APIKeyDeleteResponse,
)
```

Methods:

- <code title="post /api-keys">client.api_keys.<a href="./src/karpo_sdk/resources/api_keys.py">create</a>(\*\*<a href="src/karpo_sdk/types/api_key_create_params.py">params</a>) -> <a href="./src/karpo_sdk/types/api_key_create_response.py">APIKeyCreateResponse</a></code>
- <code title="get /api-keys">client.api_keys.<a href="./src/karpo_sdk/resources/api_keys.py">list</a>() -> <a href="./src/karpo_sdk/types/api_key_list_response.py">APIKeyListResponse</a></code>
- <code title="delete /api-keys/{id}">client.api_keys.<a href="./src/karpo_sdk/resources/api_keys.py">delete</a>(id) -> <a href="./src/karpo_sdk/types/api_key_delete_response.py">APIKeyDeleteResponse</a></code>
