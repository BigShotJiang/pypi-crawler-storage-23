# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import httpx

from ...types import plugin_list_params, plugin_create_params, plugin_update_params
from .entries import (
    EntriesResource,
    AsyncEntriesResource,
    EntriesResourceWithRawResponse,
    AsyncEntriesResourceWithRawResponse,
    EntriesResourceWithStreamingResponse,
    AsyncEntriesResourceWithStreamingResponse,
)
from ..._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from ..._utils import maybe_transform, async_maybe_transform
from .versions import (
    VersionsResource,
    AsyncVersionsResource,
    VersionsResourceWithRawResponse,
    AsyncVersionsResourceWithRawResponse,
    VersionsResourceWithStreamingResponse,
    AsyncVersionsResourceWithStreamingResponse,
)
from ..._compat import cached_property
from ..._resource import SyncAPIResource, AsyncAPIResource
from ..._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from ..._base_client import make_request_options
from ...types.plugin_list_response import PluginListResponse
from ...types.plugin_create_response import PluginCreateResponse
from ...types.plugin_update_response import PluginUpdateResponse
from ...types.plugin_retrieve_response import PluginRetrieveResponse

__all__ = ["PluginsResource", "AsyncPluginsResource"]


class PluginsResource(SyncAPIResource):
    @cached_property
    def versions(self) -> VersionsResource:
        return VersionsResource(self._client)

    @cached_property
    def entries(self) -> EntriesResource:
        return EntriesResource(self._client)

    @cached_property
    def with_raw_response(self) -> PluginsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/machinepulse-ai/karpo-op-python-sdk#accessing-raw-response-data-eg-headers
        """
        return PluginsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PluginsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/machinepulse-ai/karpo-op-python-sdk#with_streaming_response
        """
        return PluginsResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        name: str,
        type: str,
        description: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginCreateResponse:
        """
        Create plugin

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/plugins",
            body=maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "description": description,
                },
                plugin_create_params.PluginCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginCreateResponse,
        )

    def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginRetrieveResponse:
        """
        Get plugin detail

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._get(
            f"/plugins/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginRetrieveResponse,
        )

    def update(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginUpdateResponse:
        """
        Update plugin

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return self._put(
            f"/plugins/{id}",
            body=maybe_transform(
                {
                    "description": description,
                    "name": name,
                },
                plugin_update_params.PluginUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginUpdateResponse,
        )

    def list(
        self,
        *,
        search: str | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginListResponse:
        """
        List plugins

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._get(
            "/plugins",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {
                        "search": search,
                        "type": type,
                    },
                    plugin_list_params.PluginListParams,
                ),
            ),
            cast_to=PluginListResponse,
        )


class AsyncPluginsResource(AsyncAPIResource):
    @cached_property
    def versions(self) -> AsyncVersionsResource:
        return AsyncVersionsResource(self._client)

    @cached_property
    def entries(self) -> AsyncEntriesResource:
        return AsyncEntriesResource(self._client)

    @cached_property
    def with_raw_response(self) -> AsyncPluginsResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/machinepulse-ai/karpo-op-python-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncPluginsResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPluginsResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/machinepulse-ai/karpo-op-python-sdk#with_streaming_response
        """
        return AsyncPluginsResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        name: str,
        type: str,
        description: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginCreateResponse:
        """
        Create plugin

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/plugins",
            body=await async_maybe_transform(
                {
                    "name": name,
                    "type": type,
                    "description": description,
                },
                plugin_create_params.PluginCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginCreateResponse,
        )

    async def retrieve(
        self,
        id: str,
        *,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginRetrieveResponse:
        """
        Get plugin detail

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._get(
            f"/plugins/{id}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginRetrieveResponse,
        )

    async def update(
        self,
        id: str,
        *,
        description: str | Omit = omit,
        name: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginUpdateResponse:
        """
        Update plugin

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        if not id:
            raise ValueError(f"Expected a non-empty value for `id` but received {id!r}")
        return await self._put(
            f"/plugins/{id}",
            body=await async_maybe_transform(
                {
                    "description": description,
                    "name": name,
                },
                plugin_update_params.PluginUpdateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PluginUpdateResponse,
        )

    async def list(
        self,
        *,
        search: str | Omit = omit,
        type: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PluginListResponse:
        """
        List plugins

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._get(
            "/plugins",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {
                        "search": search,
                        "type": type,
                    },
                    plugin_list_params.PluginListParams,
                ),
            ),
            cast_to=PluginListResponse,
        )


class PluginsResourceWithRawResponse:
    def __init__(self, plugins: PluginsResource) -> None:
        self._plugins = plugins

        self.create = to_raw_response_wrapper(
            plugins.create,
        )
        self.retrieve = to_raw_response_wrapper(
            plugins.retrieve,
        )
        self.update = to_raw_response_wrapper(
            plugins.update,
        )
        self.list = to_raw_response_wrapper(
            plugins.list,
        )

    @cached_property
    def versions(self) -> VersionsResourceWithRawResponse:
        return VersionsResourceWithRawResponse(self._plugins.versions)

    @cached_property
    def entries(self) -> EntriesResourceWithRawResponse:
        return EntriesResourceWithRawResponse(self._plugins.entries)


class AsyncPluginsResourceWithRawResponse:
    def __init__(self, plugins: AsyncPluginsResource) -> None:
        self._plugins = plugins

        self.create = async_to_raw_response_wrapper(
            plugins.create,
        )
        self.retrieve = async_to_raw_response_wrapper(
            plugins.retrieve,
        )
        self.update = async_to_raw_response_wrapper(
            plugins.update,
        )
        self.list = async_to_raw_response_wrapper(
            plugins.list,
        )

    @cached_property
    def versions(self) -> AsyncVersionsResourceWithRawResponse:
        return AsyncVersionsResourceWithRawResponse(self._plugins.versions)

    @cached_property
    def entries(self) -> AsyncEntriesResourceWithRawResponse:
        return AsyncEntriesResourceWithRawResponse(self._plugins.entries)


class PluginsResourceWithStreamingResponse:
    def __init__(self, plugins: PluginsResource) -> None:
        self._plugins = plugins

        self.create = to_streamed_response_wrapper(
            plugins.create,
        )
        self.retrieve = to_streamed_response_wrapper(
            plugins.retrieve,
        )
        self.update = to_streamed_response_wrapper(
            plugins.update,
        )
        self.list = to_streamed_response_wrapper(
            plugins.list,
        )

    @cached_property
    def versions(self) -> VersionsResourceWithStreamingResponse:
        return VersionsResourceWithStreamingResponse(self._plugins.versions)

    @cached_property
    def entries(self) -> EntriesResourceWithStreamingResponse:
        return EntriesResourceWithStreamingResponse(self._plugins.entries)


class AsyncPluginsResourceWithStreamingResponse:
    def __init__(self, plugins: AsyncPluginsResource) -> None:
        self._plugins = plugins

        self.create = async_to_streamed_response_wrapper(
            plugins.create,
        )
        self.retrieve = async_to_streamed_response_wrapper(
            plugins.retrieve,
        )
        self.update = async_to_streamed_response_wrapper(
            plugins.update,
        )
        self.list = async_to_streamed_response_wrapper(
            plugins.list,
        )

    @cached_property
    def versions(self) -> AsyncVersionsResourceWithStreamingResponse:
        return AsyncVersionsResourceWithStreamingResponse(self._plugins.versions)

    @cached_property
    def entries(self) -> AsyncEntriesResourceWithStreamingResponse:
        return AsyncEntriesResourceWithStreamingResponse(self._plugins.entries)
