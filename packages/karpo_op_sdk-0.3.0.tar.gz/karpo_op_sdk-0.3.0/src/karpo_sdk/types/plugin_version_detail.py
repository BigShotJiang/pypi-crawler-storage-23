# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .plugin_entry import PluginEntry

__all__ = ["PluginVersionDetail"]


class PluginVersionDetail(BaseModel):
    change_note: Optional[str] = FieldInfo(alias="changeNote", default=None)

    entries: Optional[List[PluginEntry]] = None

    name: Optional[str] = None

    plugin_id: Optional[str] = FieldInfo(alias="pluginId", default=None)

    status: Optional[str] = None

    type: Optional[str] = None

    version: Optional[int] = None
