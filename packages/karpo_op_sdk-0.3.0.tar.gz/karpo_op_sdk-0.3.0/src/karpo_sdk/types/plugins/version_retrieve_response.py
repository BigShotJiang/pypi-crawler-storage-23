# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel
from ..plugin_version_detail import PluginVersionDetail

__all__ = ["VersionRetrieveResponse"]


class VersionRetrieveResponse(BaseModel):
    data: Optional[PluginVersionDetail] = None
