# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["UserGroup"]


class UserGroup(BaseModel):
    id: Optional[int] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    member_count: Optional[int] = FieldInfo(alias="memberCount", default=None)

    name: Optional[str] = None

    owner_id: Optional[str] = FieldInfo(alias="ownerId", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
