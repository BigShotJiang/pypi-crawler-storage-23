# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel
from ..prompt_version import PromptVersion

__all__ = ["VersionCreateResponse"]


class VersionCreateResponse(BaseModel):
    data: Optional[PromptVersion] = None
