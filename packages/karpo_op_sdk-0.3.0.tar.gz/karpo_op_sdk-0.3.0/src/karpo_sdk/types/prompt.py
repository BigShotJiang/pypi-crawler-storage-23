# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .prompt_message import PromptMessage

__all__ = ["Prompt"]


class Prompt(BaseModel):
    id: Optional[str] = None

    content: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    creator_id: Optional[str] = FieldInfo(alias="creatorId", default=None)

    current_version: Optional[int] = FieldInfo(alias="currentVersion", default=None)

    description: Optional[str] = None

    messages: Optional[List[PromptMessage]] = None

    name: Optional[str] = None

    tags: Optional[List[str]] = None

    type: Optional[Literal["text", "context"]] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
