# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel
from .prompt_message import PromptMessage

__all__ = ["PromptVersion"]


class PromptVersion(BaseModel):
    id: Optional[str] = None

    content: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    creator_id: Optional[str] = FieldInfo(alias="creatorId", default=None)

    messages: Optional[List[PromptMessage]] = None

    prompt_id: Optional[str] = FieldInfo(alias="promptId", default=None)

    tags: Optional[List[str]] = None

    type: Optional[str] = None

    version: Optional[int] = None
