# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from .._models import BaseModel

__all__ = ["PromptMessage"]


class PromptMessage(BaseModel):
    id: Optional[str] = None

    content: Optional[str] = None

    role: Optional[str] = None
