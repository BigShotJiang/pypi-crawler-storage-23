# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PlaygroundThread"]


class PlaygroundThread(BaseModel):
    id: Optional[str] = None

    agents_config: Optional[Dict[str, object]] = FieldInfo(alias="agentsConfig", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    group_id: Optional[int] = FieldInfo(alias="groupId", default=None)

    name: Optional[str] = None

    playground_id: Optional[str] = FieldInfo(alias="playgroundId", default=None)

    scenario: Optional[str] = None

    test_user_id: Optional[str] = FieldInfo(alias="testUserId", default=None)

    thread_id: Optional[int] = FieldInfo(alias="threadId", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
