# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Optional

from pydantic import Field as FieldInfo

from .dataset import Dataset

__all__ = ["DatasetWithItemCount"]


class DatasetWithItemCount(Dataset):
    item_count: Optional[int] = FieldInfo(alias="itemCount", default=None)
