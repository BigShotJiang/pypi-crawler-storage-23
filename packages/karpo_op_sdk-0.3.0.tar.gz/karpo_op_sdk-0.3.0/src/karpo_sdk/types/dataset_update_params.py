# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["DatasetUpdateParams"]


class DatasetUpdateParams(TypedDict, total=False):
    description: str

    input_schema: Annotated[Dict[str, object], PropertyInfo(alias="inputSchema")]

    metadata: Dict[str, object]

    name: str

    output_schema: Annotated[Dict[str, object], PropertyInfo(alias="outputSchema")]
