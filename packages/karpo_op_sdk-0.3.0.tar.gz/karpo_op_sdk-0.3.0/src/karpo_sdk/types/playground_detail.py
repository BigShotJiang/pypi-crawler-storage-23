# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from .playground import Playground
from .playground_thread import PlaygroundThread

__all__ = ["PlaygroundDetail"]


class PlaygroundDetail(Playground):
    threads: Optional[List[PlaygroundThread]] = None
