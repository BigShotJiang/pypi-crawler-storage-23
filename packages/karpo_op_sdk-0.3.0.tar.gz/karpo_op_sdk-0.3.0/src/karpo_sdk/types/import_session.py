# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["ImportSession"]


class ImportSession(BaseModel):
    id: Optional[str] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    dataset_id: Optional[str] = FieldInfo(alias="datasetId", default=None)

    errors: Optional[List[str]] = None

    status: Optional[str] = None

    total_created: Optional[int] = FieldInfo(alias="totalCreated", default=None)

    total_skipped: Optional[int] = FieldInfo(alias="totalSkipped", default=None)
