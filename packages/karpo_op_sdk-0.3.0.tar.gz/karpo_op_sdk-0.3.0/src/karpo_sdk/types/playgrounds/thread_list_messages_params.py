# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ThreadListMessagesParams"]


class ThreadListMessagesParams(TypedDict, total=False):
    id: Required[str]

    max_seq: Annotated[int, PropertyInfo(alias="maxSeq")]
    """Return messages with seq less than this value (cursor)"""

    page_size: Annotated[int, PropertyInfo(alias="pageSize")]
