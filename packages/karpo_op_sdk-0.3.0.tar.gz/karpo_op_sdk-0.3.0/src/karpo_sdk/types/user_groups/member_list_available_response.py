# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from ..._models import BaseModel

__all__ = ["MemberListAvailableResponse", "Data"]


class Data(BaseModel):
    id: Optional[str] = None

    clerk_id: Optional[str] = FieldInfo(alias="clerkId", default=None)

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    is_test_user: Optional[bool] = FieldInfo(alias="isTestUser", default=None)

    name: Optional[str] = None

    status: Optional[str] = None

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)


class MemberListAvailableResponse(BaseModel):
    data: Optional[List[Data]] = None
