# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional

from ..._models import BaseModel
from ..user_group_member import UserGroupMember

__all__ = ["MemberListResponse"]


class MemberListResponse(BaseModel):
    data: Optional[List[UserGroupMember]] = None
