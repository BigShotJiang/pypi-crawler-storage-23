# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict
from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ItemUpdateParams"]


class ItemUpdateParams(TypedDict, total=False):
    id: Required[str]

    expected_output: Annotated[Dict[str, object], PropertyInfo(alias="expectedOutput")]

    input: Dict[str, object]

    metadata: Dict[str, object]
