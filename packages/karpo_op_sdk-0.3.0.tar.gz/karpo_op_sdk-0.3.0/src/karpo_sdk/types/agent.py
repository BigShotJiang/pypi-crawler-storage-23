# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Optional
from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["Agent"]


class Agent(BaseModel):
    id: Optional[str] = None

    config: Optional[Dict[str, object]] = None

    created_at: Optional[datetime] = FieldInfo(alias="createdAt", default=None)

    current_version: Optional[int] = FieldInfo(alias="currentVersion", default=None)

    description: Optional[str] = None

    name: Optional[str] = None

    tags: Optional[List[str]] = None

    template_id: Optional[str] = FieldInfo(alias="templateId", default=None)

    updated_at: Optional[datetime] = FieldInfo(alias="updatedAt", default=None)
