# Changelog

## 0.3.0 (2026-02-21)

Full Changelog: [v0.2.1...v0.3.0](https://github.com/machinepulse-ai/karpo-op-python-sdk/compare/v0.2.1...v0.3.0)

### Features

* **api:** manual updates ([80983df](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/80983dfb5f2cb9ffcc3d1f4f94b3180d85f15d3a))

## 0.2.1 (2026-02-21)

Full Changelog: [v0.2.0...v0.2.1](https://github.com/machinepulse-ai/karpo-op-python-sdk/compare/v0.2.0...v0.2.1)

### Chores

* update SDK settings ([bfc1b5c](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/bfc1b5c7538af87255cef72ca99792ee1497d1fa))

## 0.2.0 (2026-02-21)

Full Changelog: [v0.1.0...v0.2.0](https://github.com/machinepulse-ai/karpo-op-python-sdk/compare/v0.1.0...v0.2.0)

### Features

* add Claude Code Action workflow for automated PR review ([b93a984](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/b93a9848ccf4f3b2b6af59367b67e6c6f94548e5))

## 0.1.0 (2026-02-20)

Full Changelog: [v0.0.1...v0.1.0](https://github.com/machinepulse-ai/karpo-op-python-sdk/compare/v0.0.1...v0.1.0)

### Features

* **api:** api update ([1f759f7](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/1f759f7fc639473b49e37534aa5de88c6e4d28c7))
* **api:** api update ([77ff7db](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/77ff7db85ddbaca1f77eaca8c823216fcea91bb2))
* **api:** api update ([3aefb69](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/3aefb6999821563a7f8def5fc66c37e780224137))
* **api:** manual updates ([e5d2b5c](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/e5d2b5c7771d49b34657794ec6829bec689b2c85))


### Chores

* update mock server docs ([d01390d](https://github.com/machinepulse-ai/karpo-op-python-sdk/commit/d01390df3c34edc60292f823da35e0b475599da6))
