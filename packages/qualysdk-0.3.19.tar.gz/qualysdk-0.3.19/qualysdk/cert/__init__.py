"""
Certificate View module
"""

from .list_certs import list_certs
