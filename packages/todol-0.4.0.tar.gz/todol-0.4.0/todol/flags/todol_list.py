from ..functionality.functions import Functions

class TodolList():
    def list():
        Functions.openJson()
