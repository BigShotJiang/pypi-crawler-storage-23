"""Resolvers sub-package — concrete ValueResolver implementations."""

from .pointer import PointerResolver

__all__ = ["PointerResolver"]
