{%
    include-markdown "../CONTRIBUTING.md"
    start="<!--contributing-start-->"
    end="<!--contributing-end-->"
%}
