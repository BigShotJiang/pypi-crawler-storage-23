# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gngram_lookup']

package_data = \
{'': ['*']}

install_requires = \
['polars>=1.0,<2.0', 'pyarrow>=18.0,<19.0']

entry_points = \
{'console_scripts': ['ng-exists = gngram_lookup.cli:gngram_exists',
                     'ng-freq = gngram_lookup.cli:gngram_freq',
                     'ng-has-pos = gngram_lookup.cli:gngram_has_pos',
                     'ng-pos = gngram_lookup.cli:gngram_pos',
                     'ng-pos-freq = gngram_lookup.cli:gngram_pos_freq',
                     'ng-score = gngram_lookup.cli:gngram_score']}

setup_kwargs = {
    'name': 'gngram-lookup',
    'version': '1.2.0',
    'description': 'Static Hash-Based Lookup for Google Ngram Frequencies',
    'long_description': "# gngram-lookup\n\n[![PyPI version](https://badge.fury.io/py/gngram-lookup.svg)](https://badge.fury.io/py/gngram-lookup)\n[![Downloads](https://pepy.tech/badge/gngram-lookup)](https://pepy.tech/project/gngram-lookup)\n[![Downloads/Month](https://pepy.tech/badge/gngram-lookup/month)](https://pepy.tech/project/gngram-lookup)\n[![Tests](https://img.shields.io/badge/tests-131-brightgreen)](https://github.com/craigtrim/gngram-lookup/tree/main/tests)\n[![Python 3.9+](https://img.shields.io/badge/python-3.9%2B-blue.svg)](https://www.python.org/downloads/)\n\nWord frequency and part-of-speech tags from 500 years of books. O(1) lookup. 5 million words.\n\n## Install\n\n```bash\npip install gngram-lookup\npython -m gngram_lookup.download_data       # frequency data, ~110 MB\npython -m gngram_lookup.download_pos_data   # POS tag data, separate download\n```\n\n## Python\n\n```python\nimport gngram_lookup as ng\n\nng.exists('computer')       # True\nng.exists('xyznotaword')    # False\n\nng.frequency('computer')\n# {'peak_tf': 2000, 'peak_df': 2000, 'sum_tf': 892451, 'sum_df': 312876}\n\nng.batch_frequency(['the', 'algorithm', 'xyznotaword'])\n# {'the': {...}, 'algorithm': {...}, 'xyznotaword': None}\n\nng.pos('fast')                           # ['ADJ', 'ADV', 'VERB']\nng.pos('corn', min_tf=100000)            # ['ADJ', 'NOUN']\nng.pos_freq('corn')                      # {'NOUN': 11722803, 'ADJ': 1433642, ...}\nng.has_pos('sing', ng.PosTag.VERB)       # True\nng.has_pos('sing', ng.PosTag.VERB, min_tf=1000)  # True\n```\n\n## CLI\n\n```bash\nng-exists computer    # True, exit 0\nng-exists xyznotaword # False, exit 1\n\nng-freq computer\n# peak_tf_decade: 2000\n# peak_df_decade: 2000\n# sum_tf: 892451\n# sum_df: 312876\n\nng-pos fast           # ADJ ADV VERB\nng-pos-freq corn      # ADJ: 1,433,642 / NOUN: 11,722,803 / VERB: 85,411\nng-has-pos sing VERB  # True, exit 0\nng-has-pos fast NOUN  # False, exit 1\n```\n\n## Docs\n\n- [API Reference](https://github.com/craigtrim/gngram-lookup/blob/main/docs/api.md)\n- [CLI Reference](https://github.com/craigtrim/gngram-lookup/blob/main/docs/cli.md)\n- [Data Format](https://github.com/craigtrim/gngram-lookup/blob/main/docs/data-format.md)\n- [Use Cases](https://github.com/craigtrim/gngram-lookup/blob/main/docs/use-cases.md)\n- [Development](https://github.com/craigtrim/gngram-lookup/blob/main/docs/development.md)\n\n## See Also\n\n- [bnc-lookup](https://pypi.org/project/bnc-lookup/) - O(1) lookup for British National Corpus\n- [wordnet-lookup](https://pypi.org/project/wordnet-lookup/) - O(1) lookup for WordNet\n\n## Attribution\n\nData derived from the [Google Books Ngram](https://books.google.com/ngrams) dataset.\n\n## License\n\nProprietary. See [LICENSE](https://github.com/craigtrim/gngram-lookup/blob/main/LICENSE).\n",
    'author': 'Craig Trim',
    'author_email': 'craigtrim@gmail.com',
    'maintainer': 'Craig Trim',
    'maintainer_email': 'craigtrim@gmail.com',
    'url': 'https://github.com/craigtrim/gngram-lookup',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
