import sys
import os

MODULE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "irtorch"))
sys.path.append(MODULE_DIR)
