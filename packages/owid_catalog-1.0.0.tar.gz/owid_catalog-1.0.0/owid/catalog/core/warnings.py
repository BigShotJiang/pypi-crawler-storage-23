import contextlib
import warnings
from collections.abc import Iterable
from typing import Any
from warnings import catch_warnings, simplefilter, warn  # noqa: F401

import structlog

log = structlog.get_logger()


def warn_with_structlog(
    message: str, category: type, filename: str, lineno: int, file: Any = None, line: str | None = None
) -> None:
    log.warning(message, category=category.__name__, filename=filename, lineno=lineno)


# Replace the default showwarning with structlog warnings
warnings.showwarning = warn_with_structlog  # type: ignore


class MetadataWarning(Warning):
    pass


class StepWarning(Warning):
    pass


class DifferentValuesWarning(MetadataWarning):
    pass


class DisplayNameWarning(MetadataWarning):
    pass


class NoOriginsWarning(MetadataWarning):
    pass


class GroupingByCategoricalWarning(StepWarning):
    pass


@contextlib.contextmanager
def ignore_warnings(ignore_warnings: Iterable[type] = (Warning,)):
    """Ignore warnings. You can pass a list of specific warnings to ignore like MetadataWarning or StepWarning.

    Usage:
        with ignore_warnings():
            ds_garden = create_dataset(...)
    """
    with warnings.catch_warnings():
        for w in ignore_warnings:
            warnings.filterwarnings("ignore", category=w)  # type: ignore
        yield
