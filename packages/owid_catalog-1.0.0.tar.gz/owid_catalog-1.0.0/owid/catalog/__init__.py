__version__ = "1.0.0"

from owid.catalog import api
from owid.catalog.api import Client, fetch, search
from owid.catalog.core import processing, tables, utils
from owid.catalog.core.datasets import CHANNEL, Dataset
from owid.catalog.core.indicators import Indicator, Variable
from owid.catalog.core.meta import (
    DatasetMeta,
    License,
    Origin,
    Source,
    TableMeta,
    VariableMeta,
    VariablePresentationMeta,
)
from owid.catalog.core.tables import Table

__all__ = [
    # New unified client API
    "Client",
    "api",
    "search",
    "fetch",
    # Core data structures
    "Dataset",
    "Table",
    "Variable",
    "Indicator",
    # Metadata classes
    "DatasetMeta",
    "TableMeta",
    "VariableMeta",
    "VariablePresentationMeta",
    "Source",
    "Origin",
    "License",
    # backwards compatibility re-exports
    "utils",
    "tables",
    "CHANNEL",
    "processing",
]
