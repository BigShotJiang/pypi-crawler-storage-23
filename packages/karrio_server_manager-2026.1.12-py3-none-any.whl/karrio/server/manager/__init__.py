default_app_config = 'karrio.server.manager.apps.ManagerConfig'
