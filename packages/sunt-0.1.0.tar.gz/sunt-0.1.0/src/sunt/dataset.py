

class SuntDataset:
    def __init__(dir: str = None) -> None:
        print("hello world")