# compare-dir

Tool to compare files in two directories.
