from enum import Enum

class TipoVenta(Enum):
    CAFE = "Cafe"
    LIBRO = "Libro"