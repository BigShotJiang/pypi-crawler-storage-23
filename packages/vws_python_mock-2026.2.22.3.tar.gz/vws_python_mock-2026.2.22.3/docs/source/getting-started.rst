Getting started
---------------

Mocking calls made to Vuforia
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. include:: basic-example.rst

.. include:: httpx-example.rst
