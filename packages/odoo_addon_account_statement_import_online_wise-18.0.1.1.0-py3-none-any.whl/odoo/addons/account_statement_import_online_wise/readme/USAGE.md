To pull historical bank statements:

1.  Go to *Invoicing \> Configuration \> Bank Accounts*
2.  Select specific bank accounts
3.  Launch *Actions \> Online Bank Statements Pull Wizard*
4.  Configure date interval and click *Pull*

To configure Strong Customer Authentication:

#\. Go to provider-specific settings and either press *Generate Key* or
paste manually-generate private and public keys \#. Navigate to
[Wise.com](https://wise.com/public-keys/) and register the public key.

Note that it's no longer possible to sign API requests with public keys
on Personal Accounts.
