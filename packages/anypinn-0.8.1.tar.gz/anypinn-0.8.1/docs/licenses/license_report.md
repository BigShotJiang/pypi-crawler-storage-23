---
search:
  exclude: true
---

# License Report

## Summary

--8<-- "docs/licenses/summary.txt"

## License Files

```
--8<-- "docs/licenses/license_files.txt"
```
