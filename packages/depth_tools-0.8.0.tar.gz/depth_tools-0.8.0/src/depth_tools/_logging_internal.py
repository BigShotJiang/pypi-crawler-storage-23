import logging
from typing import Final

LOGGER: Final = logging.getLogger("depth_tools")
