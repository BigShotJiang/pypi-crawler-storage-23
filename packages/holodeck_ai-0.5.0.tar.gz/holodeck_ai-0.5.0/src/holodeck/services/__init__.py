"""Services package for external API integrations.

This package contains client classes for interacting with external services
such as the MCP Registry API.
"""
