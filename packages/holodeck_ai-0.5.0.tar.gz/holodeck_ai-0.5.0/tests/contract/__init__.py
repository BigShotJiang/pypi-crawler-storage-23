"""Contract tests for API compliance."""
