import mccnado        
        


mccnado.split_viewpoint_reads(snakemake.input.bam, snakemake.output.fq)