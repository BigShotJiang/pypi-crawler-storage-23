# Inputs API

This module handles the discovery and validation of input sequencing files.

::: seqnado.inputs.Metadata
    options:
      show_root_heading: true

::: seqnado.inputs.FastqCollection
    options:
      show_root_heading: true

::: seqnado.inputs.BamCollection
    options:
      show_root_heading: true

[← Back to API Overview](index.md)
