# Outputs API

This module manages the file structure and tracking of Snakemake workflow outputs.

::: seqnado.outputs.SeqnadoOutputFiles
    options:
      show_root_heading: true

[← Back to API Overview](index.md)
