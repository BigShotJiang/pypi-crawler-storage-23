# Core Types API

This module contains the core enumerations and basic data models used throughout SeqNado.

::: seqnado.core
    options:
      show_root_heading: true

[← Back to API Overview](index.md)
