## Description

<!-- What does this PR do? -->

## Type of change

- [ ] Bug fix
- [ ] New feature
- [ ] Refactoring
- [ ] Documentation

## Checklist

- [ ] Tests pass (`uv run pytest`)
- [ ] Lint passes (`uv run ruff check src/`)
- [ ] New code has tests
