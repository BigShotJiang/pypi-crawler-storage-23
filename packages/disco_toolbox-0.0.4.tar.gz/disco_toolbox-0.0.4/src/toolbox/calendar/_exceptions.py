class CalendarError(Exception):
    """Base class for all calendar-related errors."""
