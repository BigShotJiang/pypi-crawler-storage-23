"""Host AI Bot - AI Agent Hosting Platform."""

__version__ = "0.0.1"
