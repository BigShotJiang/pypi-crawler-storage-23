"""Tests for compliance integration."""
from unittest.mock import MagicMock, patch

import pytest

from surfinguard.client import Guard
from surfinguard.enums import Policy


@pytest.fixture
def mock_http():
    with patch("surfinguard.client.SurfinguardHTTPClient") as MockHTTP:
        client = MockHTTP.return_value
        client.post = MagicMock()
        client.get = MagicMock()
        client.close = MagicMock()
        yield client


def test_assess_compliance_calls_api(mock_http):
    mock_http.post.return_value = {
        "framework": "EU AI Act",
        "riskClassification": "minimal",
        "overallStatus": "compliant",
        "requirements": [],
        "summary": {"total": 1, "compliant": 1, "partial": 0, "nonCompliant": 0},
        "assessedAt": "2026-02-23T00:00:00Z",
    }

    guard = Guard(api_key="sg_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    report = guard.assess_compliance({
        "name": "Test Agent",
        "domain": "general",
        "autonomyLevel": "supervised",
    })

    mock_http.post.assert_called_once_with(
        "/v2/compliance/assess",
        {"agentProfile": {"name": "Test Agent", "domain": "general", "autonomyLevel": "supervised"}},
    )
    assert report["framework"] == "EU AI Act"
    assert report["riskClassification"] == "minimal"


def test_assess_compliance_with_full_profile(mock_http):
    mock_http.post.return_value = {
        "framework": "EU AI Act",
        "riskClassification": "high",
        "overallStatus": "partially_compliant",
        "requirements": [],
        "summary": {"total": 8, "compliant": 3, "partial": 4, "nonCompliant": 1},
        "assessedAt": "2026-02-23T00:00:00Z",
    }

    guard = Guard(api_key="sg_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    report = guard.assess_compliance({
        "name": "Medical AI",
        "description": "A medical triage agent",
        "domain": "healthcare",
        "autonomyLevel": "semi_autonomous",
        "usesPersonalData": True,
        "affectsSafety": False,
        "makesDecisions": True,
        "interactsWithPublic": True,
    })

    assert report["riskClassification"] == "high"
    body = mock_http.post.call_args[0][1]
    assert body["agentProfile"]["usesPersonalData"] is True


def test_telemetry_opt_in(mock_http):
    mock_http.post.return_value = {
        "score": 0, "level": "SAFE", "allow": True, "reasons": [],
    }

    guard = Guard(
        api_key="sg_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
        telemetry=True,
    )
    # Check that telemetry flag is stored
    assert guard._telemetry is True


def test_telemetry_off_by_default(mock_http):
    guard = Guard(api_key="sg_live_aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")
    assert guard._telemetry is False
