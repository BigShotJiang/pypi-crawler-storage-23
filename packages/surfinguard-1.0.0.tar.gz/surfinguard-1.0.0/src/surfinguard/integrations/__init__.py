"""Framework integrations for Surfinguard."""
