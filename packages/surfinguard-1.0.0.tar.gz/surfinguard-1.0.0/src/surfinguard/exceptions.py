from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import CheckResult


class SurfinguardError(Exception):
    """Base exception for Surfinguard SDK."""


class AuthenticationError(SurfinguardError):
    """Raised when API key authentication fails (401)."""


class RateLimitError(SurfinguardError):
    """Raised when rate limit is exceeded (429)."""

    def __init__(self, message: str, retry_after: int | None = None) -> None:
        super().__init__(message)
        self.retry_after = retry_after


class APIError(SurfinguardError):
    """Raised for unexpected API errors (4xx/5xx)."""

    def __init__(self, message: str, status_code: int) -> None:
        super().__init__(message)
        self.status_code = status_code


class NotAllowedError(SurfinguardError):
    """Raised when an action is blocked by policy enforcement."""

    def __init__(self, result: CheckResult) -> None:
        super().__init__(
            f"Action blocked: {result.level.value} (score={result.score})"
        )
        self.result = result
