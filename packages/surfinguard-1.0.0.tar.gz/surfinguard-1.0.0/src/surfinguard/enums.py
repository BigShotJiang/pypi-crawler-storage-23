from enum import Enum


class RiskLevel(str, Enum):
    SAFE = "SAFE"
    CAUTION = "CAUTION"
    DANGER = "DANGER"


class RiskPrimitive(str, Enum):
    DESTRUCTION = "DESTRUCTION"
    EXFILTRATION = "EXFILTRATION"
    ESCALATION = "ESCALATION"
    PERSISTENCE = "PERSISTENCE"
    MANIPULATION = "MANIPULATION"


class Policy(str, Enum):
    PERMISSIVE = "PERMISSIVE"
    MODERATE = "MODERATE"
    STRICT = "STRICT"


class ActionType(str, Enum):
    URL = "url"
    COMMAND = "command"
    TEXT = "text"
    FILE_READ = "file_read"
    FILE_WRITE = "file_write"
