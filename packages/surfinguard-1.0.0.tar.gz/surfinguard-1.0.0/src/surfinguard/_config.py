from __future__ import annotations

from dataclasses import dataclass

from .enums import Policy


@dataclass(frozen=True)
class SurfinguardConfig:
    api_key: str
    base_url: str = "https://api.surfinguard.com"
    policy: Policy = Policy.MODERATE
    environment: str = "live"
    timeout: float = 5.0
    local_only: bool = False
