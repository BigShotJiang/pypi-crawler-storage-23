from __future__ import annotations

import functools
from typing import TYPE_CHECKING, Any, Callable

if TYPE_CHECKING:
    from .client import Guard


def _make_protect_decorator(guard: Guard, action_type: str) -> Callable[..., Any]:
    """Create a decorator that checks the first argument before function execution."""

    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        @functools.wraps(fn)
        def wrapper(*args: Any, **kwargs: Any) -> Any:
            # Extract the value to check from the first positional arg
            # or the first keyword arg
            value: str | None = None
            if args:
                value = str(args[0])
            elif kwargs:
                first_key = next(iter(kwargs))
                value = str(kwargs[first_key])

            if value is not None:
                guard.check(action_type, value)

            return fn(*args, **kwargs)

        return wrapper

    return decorator
