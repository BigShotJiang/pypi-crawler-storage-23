# models/__init__.py
from .ConvMLP import ConvMLP
from .CNN import CNN 