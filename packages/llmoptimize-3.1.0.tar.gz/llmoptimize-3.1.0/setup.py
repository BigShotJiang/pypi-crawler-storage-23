"""
setup.py for LLMOptimize v3.1.0

AI Cost Optimization SDK with Interactive Dashboard
"""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="llmoptimize",
    version="3.1.0",  # ← Interactive dashboard release!
    author="LLMOptimize Team",
    author_email="hackrudra@gmail.com",
    description="Reduce LLM API costs by 90% with ML-powered recommendations and beautiful interactive dashboards",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/hackrudra1234/llmoptimize",
    packages=['llmoptimize'],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
        "Topic :: System :: Monitoring",
        "License :: Other/Proprietary License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Operating System :: OS Independent",
        "Environment :: Console",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.31.0",  # For server communication
    ],
    extras_require={
        "dev": [
            "pytest>=7.4.0",
            "black>=23.0.0",
            "mypy>=1.0.0",
            "flake8>=6.0.0",
        ],
        "server": [
            "fastapi>=0.104.1",
            "uvicorn[standard]>=0.24.0",
            "sqlalchemy>=2.0.23",
            "psycopg2-binary>=2.9.9",
            "pydantic>=2.0.0",
        ],
        "full": [
            # Optional AI provider integrations
            "anthropic>=0.3.0",   # For Claude support
            "groq>=0.4.0",        # For Groq support
            "langchain>=0.1.0",   # For LangChain support
            "crewai>=0.1.0",      # For CrewAI support
        ],
    },
    keywords=[
        # Core functionality
        "ai", "llm", "cost", "optimization", "tracking", "monitoring",
        # Providers
        "openai", "anthropic", "claude", "gpt", "groq", "gemini",
        # Frameworks
        "langchain", "crewai", "agent", "workflow",
        # Features
        "ml", "machine-learning", "recommendations", "dashboard",
        "cost-reduction", "api-monitoring", "interactive", "visualization",
        # Use cases
        "savings", "budget", "analytics", "insights"
    ],
    project_urls={
        "Homepage": "https://aioptimize.up.railway.app",
        "Dashboard": "https://aioptimize.up.railway.app",
        "Source Code": "https://github.com/hackrudra1234/llmoptimize",
        "Bug Reports": "https://github.com/hackrudra1234/llmoptimize/issues",
        "Documentation": "https://github.com/hackrudra1234/llmoptimize#readme",
    },
    license="Proprietary",
    include_package_data=True,
    zip_safe=False,
    entry_points={
        'console_scripts': [
            'llmoptimize=llmoptimize:report',  # CLI: llmoptimize command
        ],
    },
)