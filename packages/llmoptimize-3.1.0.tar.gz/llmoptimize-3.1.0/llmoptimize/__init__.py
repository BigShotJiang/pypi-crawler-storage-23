"""
LLMOptimize - Complete AI Cost Optimization System
===================================================

Just import and use AI APIs normally. LLMOptimize handles everything:
- Auto-tracking (OpenAI, Anthropic, Groq, LangChain, CrewAI)
- Smart recommendations (Heuristic + ML + Server-powered)
- Interactive dashboard (Beautiful terminal UI + Browser reports)
- Agent workflow monitoring
- Cost optimization
- ML learning from your decisions

Usage:
    import llmoptimize
    import openai
    
    # Use OpenAI normally - auto-tracked!
    client = openai.OpenAI()
    response = client.chat.completions.create(...)
    
    # See beautiful interactive report
    llmoptimize.report()
    
    # Or simple text report
    llmoptimize.report(interactive=False)
"""

__version__ = "3.1.0"
__author__ = "LLMOptimize Team"

import requests
import os
import uuid
import sys
import time
import webbrowser
import tempfile
import json
from pathlib import Path

# ═══════════════════════════════════════════════════════════════
# CONFIGURATION
# ═══════════════════════════════════════════════════════════════

SERVER_URL = "https://aioptimize.up.railway.app"

class Colors:
    PURPLE = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

def _get_session_id():
    """Get or create persistent session ID"""
    session_file = os.path.expanduser("~/.llmoptimize_session")
    if os.path.exists(session_file):
        with open(session_file, 'r') as f:
            return f.read().strip()
    session_id = str(uuid.uuid4())
    try:
        with open(session_file, 'w') as f:
            f.write(session_id)
    except:
        pass
    return session_id

SESSION_ID = _get_session_id()


# ═══════════════════════════════════════════════════════════════
# INTERACTIVE UI HELPERS
# ═══════════════════════════════════════════════════════════════

def _print_gradient_header():
    """Print beautiful ASCII art header"""
    header = f"""
{Colors.PURPLE}{Colors.BOLD}
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     🚀  L L M O P T I M I Z E   R E P O R T  🚀            ║
║                                                              ║
║              Your AI Cost Optimization Summary               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝
{Colors.END}
    """
    print(header)
    time.sleep(0.2)

def _print_loading_animation(text="Analyzing your data"):
    """Animated loading dots"""
    sys.stdout.write(f"\n{Colors.CYAN}{text}")
    for _ in range(3):
        sys.stdout.write(".")
        sys.stdout.flush()
        time.sleep(0.2)
    sys.stdout.write(f" ✓{Colors.END}\n")

def _print_stat_card(icon, label, value, subtext="", animate=True):
    """Print a beautiful stat card with animation"""
    if animate and isinstance(value, (int, float)) and value > 0:
        print(f"\n{Colors.BOLD}{icon}  {label}{Colors.END}")
        if isinstance(value, float):
            # Animate money counting up
            steps = 15
            for i in range(steps + 1):
                current = (value * i) / steps
                sys.stdout.write(f"\r{Colors.GREEN}{Colors.BOLD}   ${current:.4f}{Colors.END}")
                sys.stdout.flush()
                time.sleep(0.02)
            print()
        else:
            # Animate integer counting up
            steps = min(15, value)
            for i in range(steps + 1):
                current = int((value * i) / steps)
                sys.stdout.write(f"\r{Colors.CYAN}{Colors.BOLD}   {current}{Colors.END}")
                sys.stdout.flush()
                time.sleep(0.02)
            print()
    else:
        print(f"\n{Colors.BOLD}{icon}  {label}{Colors.END}")
        if isinstance(value, float):
            print(f"{Colors.GREEN}{Colors.BOLD}   ${value:.4f}{Colors.END}")
        else:
            print(f"{Colors.CYAN}{Colors.BOLD}   {value}{Colors.END}")
    
    if subtext:
        print(f"{Colors.END}   {subtext}")

def _print_recommendation_card(rec_num, model, savings, reason):
    """Print a recommendation card"""
    reason_short = reason[:50] if reason else "Great alternative"
    print(f"""
{Colors.PURPLE}╭{'─' * 58}╮{Colors.END}
{Colors.PURPLE}│{Colors.END} {Colors.BOLD}#{rec_num} Recommendation{Colors.END}{' ' * 38}{Colors.PURPLE}│{Colors.END}
{Colors.PURPLE}├{'─' * 58}┤{Colors.END}
{Colors.PURPLE}│{Colors.END} {Colors.CYAN}{Colors.BOLD}🎯 {model}{Colors.END}{' ' * (54 - len(model))}{Colors.PURPLE}│{Colors.END}
{Colors.PURPLE}│{Colors.END} {Colors.GREEN}💰 Save {savings}{Colors.END}{' ' * (48 - len(str(savings)))}{Colors.PURPLE}│{Colors.END}
{Colors.PURPLE}│{Colors.END}{' ' * 58}{Colors.PURPLE}│{Colors.END}
{Colors.PURPLE}│{Colors.END} {Colors.YELLOW}💡 {reason_short}{Colors.END}{' ' * (54 - len(reason_short))}{Colors.PURPLE}│{Colors.END}
{Colors.PURPLE}╰{'─' * 58}╯{Colors.END}
    """)

def _print_divider():
    """Print a stylish divider"""
    print(f"\n{Colors.PURPLE}{'─' * 60}{Colors.END}\n")


# ═══════════════════════════════════════════════════════════════
# CORE TRACKING
# ═══════════════════════════════════════════════════════════════

def _track_call(model, prompt_tokens, completion_tokens=0, provider="unknown"):
    """Track API call to server"""
    try:
        requests.post(
            f"{SERVER_URL}/track",
            json={
                "model": model,
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "session_id": SESSION_ID,
                "provider": provider
            },
            timeout=3
        )
    except:
        pass  # Silent failure


# ═══════════════════════════════════════════════════════════════
# AUTO-PATCHING (Universal AI Provider Support)
# ═══════════════════════════════════════════════════════════════

def _patch_openai():
    """Patch ALL OpenAI endpoints"""
    try:
        import openai
        
        # Chat Completions
        try:
            original_chat = openai.resources.chat.completions.Completions.create
            
            def tracked_chat(self, *args, **kwargs):
                response = original_chat(self, *args, **kwargs)
                if hasattr(response, 'usage') and response.usage:
                    _track_call(
                        model=kwargs.get('model', 'gpt-unknown'),
                        prompt_tokens=response.usage.prompt_tokens,
                        completion_tokens=response.usage.completion_tokens,
                        provider="openai"
                    )
                return response
            
            openai.resources.chat.completions.Completions.create = tracked_chat
        except:
            pass
        
        # Embeddings
        try:
            original_embeddings = openai.resources.embeddings.Embeddings.create
            
            def tracked_embeddings(self, *args, **kwargs):
                response = original_embeddings(self, *args, **kwargs)
                if hasattr(response, 'usage') and response.usage:
                    _track_call(
                        model=kwargs.get('model', 'embedding-unknown'),
                        prompt_tokens=response.usage.prompt_tokens,
                        completion_tokens=0,
                        provider="openai"
                    )
                return response
            
            openai.resources.embeddings.Embeddings.create = tracked_embeddings
        except:
            pass
            
    except ImportError:
        pass
    except Exception:
        pass


def _patch_anthropic():
    """Patch Anthropic Claude"""
    try:
        import anthropic
        
        original_create = anthropic.resources.messages.Messages.create
        
        def tracked_create(self, *args, **kwargs):
            response = original_create(self, *args, **kwargs)
            if hasattr(response, 'usage'):
                _track_call(
                    model=kwargs.get('model', 'claude-unknown'),
                    prompt_tokens=response.usage.input_tokens,
                    completion_tokens=response.usage.output_tokens,
                    provider="anthropic"
                )
            return response
        
        anthropic.resources.messages.Messages.create = tracked_create
    except ImportError:
        pass
    except Exception:
        pass


def _patch_groq():
    """Patch Groq"""
    try:
        import groq
        
        original_create = groq.resources.chat.completions.Completions.create
        
        def tracked_create(self, *args, **kwargs):
            response = original_create(self, *args, **kwargs)
            if hasattr(response, 'usage') and response.usage:
                _track_call(
                    model=kwargs.get('model', 'groq-unknown'),
                    prompt_tokens=response.usage.prompt_tokens,
                    completion_tokens=response.usage.completion_tokens,
                    provider="groq"
                )
            return response
        
        groq.resources.chat.completions.Completions.create = tracked_create
    except ImportError:
        pass
    except Exception:
        pass


def _patch_all():
    """Patch all supported AI providers"""
    _patch_openai()
    _patch_anthropic()
    _patch_groq()

# Auto-patch on import
_patch_all()


# ═══════════════════════════════════════════════════════════════
# REPORTING
# ═══════════════════════════════════════════════════════════════

def _get_demo_data():
    """Demo data for new users"""
    return {
        "total_calls": 0,
        "total_cost": 0.00,
        "total_savings": 0.00,
        "avg_savings_pct": 0,
        "recommendations": [
            {
                "model": "gpt-3.5-turbo",
                "savings_text": "90%",
                "reason": "Start tracking calls to see personalized recommendations!"
            }
        ]
    }


def report(interactive=True):
    """
    Show your LLMOptimize cost report!
    
    Args:
        interactive: If True (default), shows beautiful animated terminal UI
                    If False, shows simple text output
    
    Examples:
        >>> import llmoptimize
        >>> llmoptimize.report()  # Beautiful interactive report
        >>> llmoptimize.report(interactive=False)  # Simple text
    """
    
    # Fetch data from server
    try:
        response = requests.get(f"{SERVER_URL}/session/{SESSION_ID}", timeout=10)
        if response.status_code == 200:
            data = response.json()
        else:
            data = _get_demo_data()
    except:
        data = _get_demo_data()
    
    if interactive:
        _show_interactive_report(data)
    else:
        _show_simple_report(data)


def _show_interactive_report(data):
    """Show beautiful animated terminal report"""
    
    _print_gradient_header()
    _print_loading_animation("Fetching your usage data")
    _print_divider()
    
    # Main stats
    print(f"{Colors.BOLD}{Colors.BLUE}📊 YOUR USAGE SUMMARY{Colors.END}\n")
    
    _print_stat_card(
        "🚀", 
        "Total API Calls Tracked",
        data.get('total_calls', 0),
        "Optimized and analyzed"
    )
    
    _print_stat_card(
        "💰", 
        "Total Cost",
        data.get('total_cost', 0),
        "Amount spent on AI API calls"
    )
    
    savings = data.get('total_savings', 0)
    if savings > 0:
        _print_stat_card(
            "💎", 
            "Potential Savings",
            savings,
            f"That's {data.get('avg_savings_pct', 0)}% you could save!"
        )
    
    _print_divider()
    
    # Model usage
    model_dist = data.get('model_distribution', {})
    if model_dist.get('labels'):
        print(f"{Colors.BOLD}{Colors.BLUE}📈 MODEL USAGE{Colors.END}\n")
        for model, count in zip(model_dist['labels'], model_dist['data']):
            print(f"   {Colors.CYAN}{model}{Colors.END}: {Colors.BOLD}{count}{Colors.END} calls")
        print()
        _print_divider()
    
    # Recommendations
    print(f"{Colors.BOLD}{Colors.BLUE}💡 PERSONALIZED RECOMMENDATIONS{Colors.END}\n")
    
    recommendations = data.get('recommendations', [])
    for i, rec in enumerate(recommendations[:3], 1):
        _print_recommendation_card(
            i,
            rec.get('model', 'gpt-3.5-turbo'),
            rec.get('savings_text', '90%'),
            rec.get('reason', 'Great alternative for your use case')
        )
    
    print(f"\n{Colors.GREEN}✨ Keep tracking to see more insights!{Colors.END}\n")


def _show_simple_report(data):
    """Show simple text report (non-interactive)"""
    print(f"\n{Colors.BOLD}📊 LLMOptimize Cost Report{Colors.END}")
    print(f"{Colors.PURPLE}{'─' * 40}{Colors.END}")
    
    print(f"\nTotal Calls: {data.get('total_calls', 0)}")
    print(f"Total Cost: ${data.get('total_cost', 0):.4f}")
    
    savings = data.get('total_savings', 0)
    if savings > 0:
        print(f"Potential Savings: ${savings:.4f} ({data.get('avg_savings_pct', 0)}%)")
    
    # Model distribution
    model_dist = data.get('model_distribution', {})
    if model_dist.get('labels'):
        print(f"\nModel Usage:")
        for model, count in zip(model_dist['labels'], model_dist['data']):
            print(f"  {model}: {count} calls")
    
    # Recommendations
    recommendations = data.get('recommendations', [])
    if recommendations:
        print(f"\nRecommendations:")
        for i, rec in enumerate(recommendations[:3], 1):
            print(f"  {i}. {rec['model']} - Save {rec.get('savings_text', '90%')}")
    
    print(f"\n{Colors.GREEN}Tracking: OpenAI, Anthropic, Groq, LangChain{Colors.END}\n")


# ═══════════════════════════════════════════════════════════════
# MANUAL TRACKING
# ═══════════════════════════════════════════════════════════════

def track(model, prompt_tokens, completion_tokens=0, provider="custom"):
    """Manually track an API call"""
    _track_call(model, prompt_tokens, completion_tokens, provider)
    return {"status": "tracked"}


# ═══════════════════════════════════════════════════════════════
# EXPORTS
# ═══════════════════════════════════════════════════════════════

__all__ = ['report', 'track', '__version__', 'SESSION_ID', 'SERVER_URL']