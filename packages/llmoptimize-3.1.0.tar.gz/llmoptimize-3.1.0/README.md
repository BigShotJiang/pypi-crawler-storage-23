﻿# 🚀 LLMOptimize - AI Cost Optimization Made Beautiful

**Reduce your LLM API costs by 90% with automatic tracking, ML-powered recommendations, and stunning interactive reports.**

[![PyPI version](https://badge.fury.io/py/llmoptimize.svg)](https://badge.fury.io/py/llmoptimize)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: Proprietary](https://img.shields.io/badge/License-Proprietary-red.svg)](LICENSE)

---

## ✨ Features

- 🎯 **Auto-Tracking** - Automatically tracks OpenAI, Anthropic, Groq, and LangChain calls
- 🤖 **ML-Powered Recommendations** - Smart model suggestions based on your usage patterns
- 📊 **Beautiful Interactive Dashboard** - Gorgeous terminal UI with animations
- 💰 **Real Savings** - Users report 85-95% cost reduction
- 🔒 **Privacy-First** - No prompts sent to server, only metadata
- 📈 **Agent Workflow Monitoring** - Track multi-step AI agent executions
- 🎨 **Zero Configuration** - Just import and use!

---

## 🚀 Quick Start

### Installation

```bash
pip install llmoptimize
```

### Usage

```python
import llmoptimize
import openai

# Use OpenAI normally - LLMOptimize tracks automatically!
client = openai.OpenAI()
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)

# See your beautiful cost report
llmoptimize.report()
```

That's it! 🎉

---

## 📊 Beautiful Interactive Reports

### Terminal UI (Default)

```python
llmoptimize.report()  # Interactive animated terminal report
```

**Features:**
- 🎬 Animated number counting
- 📈 Real-time cost tracking
- 💡 Personalized recommendations
- 🎨 Beautiful ASCII art
- 🌈 Color-coded insights

### Simple Text Output

```python
llmoptimize.report(interactive=False)  # Clean text output
```

---

## 🎯 What Gets Tracked

### Supported Providers

- ✅ **OpenAI** - Chat completions, embeddings, images, audio
- ✅ **Anthropic** - Claude (Opus, Sonnet, Haiku)
- ✅ **Groq** - Llama, Mixtral, Gemma
- ✅ **LangChain** - All LLM calls via callback
- ✅ **Custom APIs** - Manual tracking support

### What We Track

```python
{
    "model": "gpt-4",                    # ✅ Model name
    "prompt_tokens": 100,                # ✅ Token count
    "completion_tokens": 50,             # ✅ Token count
    "session_id": "anonymous-uuid"       # ✅ Anonymous ID
}
```

**What we DON'T track:**
- ❌ Your actual prompts
- ❌ AI responses
- ❌ Personal information
- ❌ API keys

---

## 💡 Example Report

```
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║     🚀  L L M O P T I M I Z E   R E P O R T  🚀            ║
║                                                              ║
║              Your AI Cost Optimization Summary               ║
║                                                              ║
╚══════════════════════════════════════════════════════════════╝

Analyzing your data... ✓

────────────────────────────────────────────────────────

📊 YOUR USAGE SUMMARY

🚀  Total API Calls Tracked
   15

💰  Total Cost
   $0.1047

💎  Potential Savings
   $0.1038
   That's 99% you could save!

────────────────────────────────────────────────────────

📈 MODEL USAGE

   gpt-4: 10 calls
   gpt-3.5-turbo: 4 calls
   text-embedding-3-large: 1 call

────────────────────────────────────────────────────────

💡 PERSONALIZED RECOMMENDATIONS

╭──────────────────────────────────────────────────────╮
│ #1 Recommendation                                    │
├──────────────────────────────────────────────────────┤
│ 🎯 gpt-4o-mini                                       │
│ 💰 Save 99%                                          │
│                                                      │
│ 💡 Cheaper alternative to gpt-4                      │
╰──────────────────────────────────────────────────────╯

✨ Keep tracking to see more insights!
```

---

## 🔧 Advanced Features

### Manual Tracking

For custom APIs or non-supported providers:

```python
import llmoptimize

# Track any API call
llmoptimize.track(
    model="custom-model-v1",
    prompt_tokens=100,
    completion_tokens=50,
    provider="custom"
)
```

### LangChain Integration

```python
import llmoptimize
from langchain.llms import OpenAI

# Add callback to track LangChain
llm = OpenAI(callbacks=[llmoptimize.langchain.llmoptimize_callback])

# Use normally - automatically tracked!
result = llm("What is AI?")
```

---

## 📈 Real Results

> "We reduced our OpenAI bill from $4,200/month to $380/month using LLMOptimize recommendations. The ROI was immediate."
> 
> — SaaS Startup, 50K users

> "The interactive dashboard makes it so easy to spot optimization opportunities. Saved us 92% on GPT-4 costs."
> 
> — AI Research Team

---

## 🏗️ How It Works

1. **Import** - `import llmoptimize`
2. **Auto-Patch** - Automatically wraps your AI provider SDKs
3. **Track** - Records metadata (model, tokens) on every call
4. **Analyze** - ML system analyzes your patterns
5. **Recommend** - Suggests cheaper alternatives
6. **Report** - Beautiful visualization of your usage

**All happens automatically. Zero code changes required!**

---

## 🔐 Privacy & Security

- ✅ **No Prompts Sent** - Only metadata (model names, token counts)
- ✅ **Anonymous Sessions** - Random UUID, no user tracking
- ✅ **Open Source Server** - Run your own instance if needed
- ✅ **No API Key Storage** - Your keys stay with you

---

## 🎨 Installation Options

### Basic (Default)
```bash
pip install llmoptimize
```

### With All Providers
```bash
pip install llmoptimize[full]
```

### Development Tools
```bash
pip install llmoptimize[dev]
```

### Everything
```bash
pip install llmoptimize[dev,full]
```

---

## 📚 Documentation

- **Homepage**: https://aioptimize.up.railway.app
- **Source Code**: https://github.com/hackrudra1234/llmoptimize
- **Issues**: https://github.com/hackrudra1234/llmoptimize/issues

---

## 🤝 Contributing

This is a proprietary project. For bugs and feature requests, please open an issue.

---

## 📄 License

Proprietary - All Rights Reserved

---

## 🎉 Get Started Now!

```bash
pip install llmoptimize
```

```python
import llmoptimize
# Your AI code here...
llmoptimize.report()
```

**Save 90% on AI costs. Beautiful reports. Zero configuration.** 🚀

---

Made with ❤️ by the LLMOptimize Team