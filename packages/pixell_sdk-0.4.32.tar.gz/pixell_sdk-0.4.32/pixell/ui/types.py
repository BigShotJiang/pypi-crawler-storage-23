from typing import Any, Dict

JSON = Any
JSONDict = Dict[str, Any]
Props = Dict[str, Any]
