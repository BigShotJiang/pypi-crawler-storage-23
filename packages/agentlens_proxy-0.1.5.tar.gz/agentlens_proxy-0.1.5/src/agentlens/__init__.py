"""AgentLens — Profile AI agents by intercepting LLM API traffic."""

__version__ = "0.1.0"
