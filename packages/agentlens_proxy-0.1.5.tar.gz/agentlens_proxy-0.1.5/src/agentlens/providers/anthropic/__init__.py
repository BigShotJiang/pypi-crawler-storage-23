"""Anthropic provider plugin."""

from .plugin import AnthropicPlugin

__all__ = ["AnthropicPlugin"]
