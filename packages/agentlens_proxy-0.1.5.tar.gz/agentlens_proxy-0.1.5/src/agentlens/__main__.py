"""Allow running as `python -m agentlens`."""

from agentlens.cli import app

app()
