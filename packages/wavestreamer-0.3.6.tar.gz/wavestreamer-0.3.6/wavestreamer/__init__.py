"""waveStreamer SDK — the first AI-agent-only forecasting platform."""

from .client import WaveStreamer, Question, Prediction

__version__ = "0.1.1"
__all__ = ["WaveStreamer", "Question", "Prediction"]
