"""Text extraction utilities for PDF, Word, text documents, and spreadsheets."""

import glob
import logging
import os
import re
import shutil
import tempfile
import zipfile
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Dict, List, Union

import magic
import pandas as pd

logger = logging.getLogger(__name__)


def resolve_path_with_package_data(path_pattern: str) -> list[str]:
    """Resolve a file path or glob pattern, checking package data if not found locally.

    Args:
        path_pattern: File path or glob pattern (e.g., 'data/cfs/*.txt')

    Returns:
        List of resolved file paths

    Raises:
        FileNotFoundError: If pattern matches no files in either location
    """
    # First try current working directory
    matches = glob.glob(path_pattern)

    if matches:
        return matches

    # If no matches, try package data directory
    package_dir = Path(__file__).parent
    package_pattern = str(package_dir / path_pattern)
    package_matches = glob.glob(package_pattern)

    if package_matches:
        logger.info(f"Using package data files: {path_pattern}")
        return package_matches

    # No matches in either location
    raise FileNotFoundError(
        f"No files found matching '{path_pattern}' in current directory or package data"
    )


def strip_null_bytes(obj):
    """Recursively strip null bytes from strings in nested structures."""
    if isinstance(obj, str):
        return obj.replace("\u0000", "")
    elif isinstance(obj, dict):
        return {strip_null_bytes(k): strip_null_bytes(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [strip_null_bytes(i) for i in obj]
    elif isinstance(obj, tuple):
        return tuple(strip_null_bytes(i) for i in obj)
    elif isinstance(obj, set):
        return {strip_null_bytes(i) for i in obj}
    else:
        return obj


def get_scrubber(salt, model="en_core_web_md"):
    """Create PII scrubber with spaCy NER and strict email detection.

    Returns:
        Configured scrubadub.Scrubber with hashed replacements
    """

    import scrubadub
    from scrubadub.detectors import EmailDetector
    from scrubadub.post_processors import FilthReplacer, PrefixSuffixReplacer
    from scrubadub_spacy.detectors import SpacyEntityDetector

    class StrictEmailDetector(EmailDetector):
        """Only match proper RFC-style emails, not things like 'vague @ times'."""

        name = "strict_email"
        regex = re.compile(
            r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b", re.UNICODE
        )

    scrubber = scrubadub.Scrubber(
        post_processor_list=[
            FilthReplacer(include_hash=True, hash_salt=salt, hash_length=4),
            PrefixSuffixReplacer(prefix="[", suffix="]"),
        ],
        detector_list=[],  # start empty to avoid default detectors
    )
    spacy_detector = SpacyEntityDetector(model=model)
    scrubber.add_detector(spacy_detector)
    scrubber.add_detector(StrictEmailDetector())

    return scrubber


def safer_extract(zip_ref, dest_dir, max_files: int = 1000):
    """Safely extract zip archive with path traversal and symlink checks.

    Raises:
        Exception: If zip contains too many files, unsafe paths, or symlinks
    """
    members = zip_ref.infolist()

    if len(members) > max_files:
        raise Exception(f"Zip contains too many files ({len(members)} > {max_files})")

    for member in members:
        # Avoid path traversal
        dest_path = os.path.abspath(os.path.join(dest_dir, member.filename))
        if not dest_path.startswith(os.path.abspath(dest_dir)):
            raise Exception(f"Unsafe path in zip: {member.filename}")

        # Block symlinks
        is_symlink = (member.external_attr >> 16) & 0o170000 == 0o120000
        if is_symlink:
            raise Exception(f"Symlink found in zip: {member.filename}")

    zip_ref.extractall(dest_dir)


@contextmanager
def unpack_zip_to_temp_paths_if_needed(
    paths: list[str | Path],
) -> list[tuple[str, dict]]:
    """Unpack zip files to temp dir and yield file paths with metadata.

    Returns:
        List of (file_path, metadata) tuples. Metadata includes zip_source and zip_path.
        Temp dirs are cleaned up on context exit.
    """
    # Convert all paths to strings for consistent handling
    paths = [str(p) for p in paths]

    expanded_items = []
    temp_dirs = []

    try:
        for path in paths:
            # Check if it's a zip file (in current dir or package data)
            if path.endswith(".zip"):
                zip_path = None
                if os.path.isfile(path):
                    zip_path = path
                else:
                    # Try package data
                    package_dir = Path(__file__).parent
                    package_zip = package_dir / path
                    if package_zip.is_file():
                        zip_path = str(package_zip)
                        logger.info(f"Using package data zip: {path}")

                if zip_path:
                    zip_stem = Path(zip_path).stem  # "archive.zip" -> "archive"
                    with zipfile.ZipFile(zip_path, "r") as zip_ref:
                        tmpdir = tempfile.mkdtemp(prefix="unpacked_zip_")
                        temp_dirs.append(tmpdir)
                        safer_extract(zip_ref, tmpdir)
                        for root, _, files in os.walk(tmpdir):
                            for f in files:
                                file_path = os.path.join(root, f)
                                metadata = {
                                    "zip_source": zip_stem,
                                    "zip_path": zip_path,
                                }
                                expanded_items.append((file_path, metadata))
                    continue

                # Zip file not found
                logger.warning(f"Zip file not found: {path}")
            else:
                # Expand globs, checking package data if not found locally
                try:
                    resolved_paths = resolve_path_with_package_data(path)
                    for expanded_path in resolved_paths:
                        metadata = {"zip_source": None, "zip_path": None}
                        expanded_items.append((expanded_path, metadata))
                except FileNotFoundError:
                    # If no matches found, add the original path anyway
                    # This allows proper error messages from downstream code
                    logger.warning(f"No files found for pattern: {path}")
                    # Don't add anything - will cause empty list if all patterns fail

        yield expanded_items

    finally:
        for tmpdir in temp_dirs:
            shutil.rmtree(tmpdir, ignore_errors=True)


def is_spreadsheet(path: Union[str, Path]) -> bool:
    """Check if file is spreadsheet (CSV or XLSX) by extension."""
    suffix = Path(path).suffix.lower()
    return suffix in [".csv", ".xlsx"]


def extract_spreadsheet_rows(path: str) -> List[Dict[str, Any]]:
    """Extract rows from CSV or XLSX file as list of dictionaries.

    Each row becomes a dictionary with column names as keys.
    NaN values are converted to None.

    Args:
        path: Path to CSV or XLSX file

    Returns:
        List of dictionaries, one per row (excluding header)
    """
    suffix = Path(path).suffix.lower()

    try:
        if suffix == ".csv":
            df = pd.read_csv(path)
        elif suffix == ".xlsx":
            df = pd.read_excel(path, engine="openpyxl")
        else:
            raise ValueError(f"Unsupported spreadsheet format: {suffix}")

        # Convert NaN to None, convert to list of dicts
        rows = df.where(pd.notna(df), None).to_dict("records")

        logger.info(
            f"Loaded {len(rows)} rows from {path} with columns: {list(df.columns)}"
        )
        return rows

    except Exception as e:
        logger.error(f"Failed to read spreadsheet {path}: {e}")
        raise


def extract_text(path: str) -> Union[str, List[Dict[str, Any]]]:
    """Extract text from various document formats.

    Supports:
    - PDF files (.pdf)
    - Word documents (.docx)
    - Plain text files (.txt, .md, etc.)
    - CSV files (.csv) -- returns list of row dictionaries
    - Excel files (.xlsx) -- returns list of row dictionaries

    Args:
        path: Path to the document file

    Returns:
        Extracted text content (str) or list of row dictionaries for spreadsheets
    """
    path_obj = Path(path)

    # Handle spreadsheets differently - return structured data
    if is_spreadsheet(path_obj):
        return extract_spreadsheet_rows(path)

    # Regular text extraction for non-spreadsheet files
    mtime = path_obj.stat().st_mtime
    return strip_null_bytes(_extract_text_cached(str(path), mtime))


def _extract_docx_text(path: str) -> str:
    """Extract text from DOCX including headers and footers."""
    import docx

    try:
        doc = docx.Document(path)
        parts = []

        # Extract body text
        parts.extend(p.text for p in doc.paragraphs if p.text.strip())

        # Extract headers and footers from all sections
        for section in doc.sections:
            header = section.header
            footer = section.footer

            parts.extend(p.text for p in header.paragraphs if p.text.strip())
            parts.extend(p.text for p in footer.paragraphs if p.text.strip())

        return "\n".join(parts)

    except Exception as e:
        logger.error(f"DOCX read failed: {path}: {e}")
        return ""


def _extract_text_cached(path: str, mtime: float) -> str:
    """Extract text from PDF/DOCX/TXT with error handling. Cached by mtime."""
    import pdfplumber
    from pdfplumber.utils.exceptions import PdfminerException

    suffix = Path(path).suffix.lower()

    try:
        if suffix == ".pdf":
            with pdfplumber.open(path) as pdf:
                pages_text = []
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        pages_text.append(page_text)
                return "\n".join(pages_text)

        elif suffix == ".docx":
            return _extract_docx_text(path)

        else:
            # Default to plain text reading
            with open(path, "r", encoding="utf-8") as f:
                return f.read()

    except PdfminerException:
        logger.error(f"PDF read failed: {path}")
        return ""

    except Exception as e:
        logger.error(f"Read failed: {path}: {e}")
        return ""


def is_plain_text_file(path: Path) -> bool:
    """Check if file is plain text using MIME type detection."""
    try:
        mime = magic.from_file(str(path), mime=True)
        return mime.startswith("text/")
    except Exception:
        return False


def get_supported_extensions() -> list[str]:
    """Return list of supported file extensions."""
    return [".txt", ".md", ".pdf", ".docx", ".csv", ".xlsx"]


def is_supported_file(path: Path) -> bool:
    """Check if file is supported for text extraction."""
    suffix = path.suffix.lower()
    return suffix in get_supported_extensions() or is_plain_text_file(path)


def detect_file_type(path: Path) -> str:
    """Detect document type for logging (PDF, Word Document, etc.)."""
    suffix = path.suffix.lower()

    if suffix == ".pdf":
        return "PDF"
    elif suffix == ".docx":
        return "Word Document"
    elif suffix == ".csv":
        return "CSV Spreadsheet"
    elif suffix == ".xlsx":
        return "Excel Spreadsheet"
    elif suffix in [".txt", ".md"]:
        return "Text File"
    elif is_plain_text_file(path):
        return "Plain Text"
    else:
        return "Unknown"
