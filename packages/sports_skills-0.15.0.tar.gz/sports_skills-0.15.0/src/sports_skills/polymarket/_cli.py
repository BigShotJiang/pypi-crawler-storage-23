"""Polymarket trading via py_clob_client Python SDK.

Uses the native ``py_clob_client`` library for CLOB trading operations.
No external CLI binary required.  Install with::

    pip install sports-skills[polymarket]

For trading commands, configure a wallet via one of:

    # Option 1 — environment variable
    export POLYMARKET_PRIVATE_KEY=0x...

    # Option 2 — Python SDK
    from sports_skills import polymarket
    polymarket.configure(private_key="0x...")
"""

from __future__ import annotations

import functools
import os

# ============================================================
# Configuration (wallet / authentication)
# ============================================================

_CONFIG: dict = {}
_client_instance = None

# Mapping from human-readable names to py_clob_client integer codes.
_SIG_TYPE_MAP = {
    "eoa": 0,
    "poly_gnosis_safe": 1,
    "poly_proxy": 2,
    # Legacy aliases from the old CLI wrapper:
    "proxy": 2,
    "gnosis-safe": 1,
}


def configure(
    *,
    private_key: str | None = None,
    signature_type: str | int | None = None,
) -> dict:
    """Configure wallet for trading commands.

    Two ways to authenticate:
      1. Add POLYMARKET_PRIVATE_KEY=0x... to your .env file (simplest).
      2. Call this: configure(private_key="0x...").

    Args:
        private_key: Polygon wallet private key (hex string starting with 0x).
        signature_type: Signature type — 0 / "eoa" (default), 1 / "gnosis-safe",
            or 2 / "proxy".
    """
    global _client_instance
    if private_key is not None:
        _CONFIG["private_key"] = private_key
        _client_instance = None  # force re-init
    if signature_type is not None:
        if isinstance(signature_type, str):
            resolved = _SIG_TYPE_MAP.get(signature_type.lower())
            if resolved is None:
                return _error(
                    f"Unknown signature_type '{signature_type}'. "
                    f"Use one of: {', '.join(_SIG_TYPE_MAP.keys())} or an int 0-2."
                )
            signature_type = resolved
        _CONFIG["signature_type"] = signature_type
        _client_instance = None
    return _success(
        {"configured": list(_CONFIG.keys())},
        "Wallet configured for this session.",
    )


# ============================================================
# Response Helpers (match _connector.py pattern)
# ============================================================


def _success(data, message=""):
    return {"status": True, "data": data, "message": message}


def _error(message, data=None):
    return {"status": False, "data": data, "message": message}


def _wrap_required_params(fn):
    """Catch TypeError from missing required keyword args and return error dict."""
    @functools.wraps(fn)
    def wrapper(*args, **kwargs):
        try:
            return fn(*args, **kwargs)
        except TypeError as e:
            err_msg = str(e)
            if "missing" in err_msg and "required" in err_msg:
                return _error(err_msg)
            raise
    return wrapper


# ============================================================
# Client Initialization (lazy)
# ============================================================

CLOB_HOST = "https://clob.polymarket.com"
CHAIN_ID = 137


def _get_client():
    """Lazily initialize and return an authenticated ClobClient instance."""
    global _client_instance
    if _client_instance is not None:
        return _client_instance

    try:
        from py_clob_client.client import ClobClient
    except ImportError:
        return None

    key = _CONFIG.get("private_key") or os.environ.get("POLYMARKET_PRIVATE_KEY")
    if not key:
        return None

    sig_type = _CONFIG.get("signature_type", 0)

    client = ClobClient(
        CLOB_HOST,
        key=key,
        chain_id=CHAIN_ID,
        signature_type=sig_type,
    )
    client.set_api_creds(client.create_or_derive_api_creds())
    _client_instance = client
    return _client_instance


def is_cli_available() -> bool:
    """Check whether the py_clob_client package is installed."""
    try:
        import py_clob_client  # noqa: F401
        return True
    except ImportError:
        return False


def _require_client():
    """Return (client, None) or (None, error_dict)."""
    client = _get_client()
    if client is not None:
        return client, None

    if not is_cli_available():
        return None, _error(
            "py_clob_client not installed. Install with: "
            "pip install sports-skills[polymarket]"
        )
    return None, _error(
        "No private key configured. Set POLYMARKET_PRIVATE_KEY env var "
        "or call configure(private_key='0x...')"
    )


# ============================================================
# Trading Commands (authenticated — requires wallet)
# ============================================================


@_wrap_required_params
def create_order(
    *,
    token_id: str,
    side: str,
    price: str,
    size: str,
    order_type: str = "GTC",
) -> dict:
    """Place a limit order.

    Args:
        token_id: Market token ID.
        side: Order side — "buy" or "sell".
        price: Limit price (0.01–0.99).
        size: Number of shares.
        order_type: Order type — "GTC" (default), "FOK", or "GTD".
    """
    client, err = _require_client()
    if err:
        return err

    from py_clob_client.clob_types import OrderArgs, OrderType
    from py_clob_client.order_builder.constants import BUY, SELL

    side_const = BUY if side.lower() == "buy" else SELL
    otype_map = {"GTC": OrderType.GTC, "FOK": OrderType.FOK, "GTD": OrderType.GTD}
    otype = otype_map.get(order_type.upper(), OrderType.GTC)

    try:
        order_args = OrderArgs(
            token_id=token_id,
            price=float(price),
            size=float(size),
            side=side_const,
        )
        signed_order = client.create_order(order_args)
        resp = client.post_order(signed_order, otype)
        return _success(resp, "Order placed successfully.")
    except Exception as e:
        return _error(f"Failed to create order: {e}")


@_wrap_required_params
def market_order(*, token_id: str, side: str, amount: str) -> dict:
    """Place a market order.

    Args:
        token_id: Market token ID.
        side: Order side — "buy" or "sell".
        amount: USDC amount to spend.
    """
    client, err = _require_client()
    if err:
        return err

    from py_clob_client.clob_types import MarketOrderArgs, OrderType
    from py_clob_client.order_builder.constants import BUY, SELL

    side_const = BUY if side.lower() == "buy" else SELL

    try:
        mo_args = MarketOrderArgs(
            token_id=token_id,
            amount=float(amount),
            side=side_const,
        )
        signed_order = client.create_market_order(mo_args)
        resp = client.post_order(signed_order, OrderType.FOK)
        return _success(resp, "Market order placed successfully.")
    except Exception as e:
        return _error(f"Failed to place market order: {e}")


@_wrap_required_params
def cancel_order(*, order_id: str) -> dict:
    """Cancel a specific order.

    Args:
        order_id: The ID of the order to cancel.
    """
    client, err = _require_client()
    if err:
        return err

    try:
        resp = client.cancel(order_id)
        return _success(resp, "Order cancelled.")
    except Exception as e:
        return _error(f"Failed to cancel order: {e}")


def cancel_all_orders() -> dict:
    """Cancel all open orders."""
    client, err = _require_client()
    if err:
        return err

    try:
        resp = client.cancel_all()
        return _success(resp, "All orders cancelled.")
    except Exception as e:
        return _error(f"Failed to cancel orders: {e}")


def get_orders(*, market: str | None = None) -> dict:
    """View open orders.

    Args:
        market: Optional condition-ID to filter by.
    """
    client, err = _require_client()
    if err:
        return err

    try:
        from py_clob_client.clob_types import OpenOrderParams

        params = OpenOrderParams(market=market) if market else OpenOrderParams()
        resp = client.get_orders(params)
        return _success(resp, "Open orders retrieved.")
    except Exception as e:
        return _error(f"Failed to get orders: {e}")


def get_user_trades() -> dict:
    """View your recent trades."""
    client, err = _require_client()
    if err:
        return err

    try:
        resp = client.get_trades()
        return _success(resp, "Trades retrieved.")
    except Exception as e:
        return _error(f"Failed to get trades: {e}")
