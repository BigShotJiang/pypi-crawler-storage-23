# tests/conftest.py
# Django settings are configured via tests/settings.py
# (pointed to by DJANGO_SETTINGS_MODULE in pyproject.toml).
