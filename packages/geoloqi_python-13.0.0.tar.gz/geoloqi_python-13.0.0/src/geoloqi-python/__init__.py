__version__ = "12.0.0"

def info():
    print("This is a benign placeholder package for security research.")
    print("If this was installed automatically, your build system may be vulnerable to dependency confusion.")