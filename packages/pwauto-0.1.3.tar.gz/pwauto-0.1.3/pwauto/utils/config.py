import os
from dotenv import load_dotenv
from .paths import ROOT_DIR


# 获取环境变量里的环境信息，此时 env_type 会拿到从 pytest --env 传进来的值
env_type = os.getenv("ENV")

if not env_type:
    # 如果用户既没写 --env，也没设环境变量，给出报错
    raise EnvironmentError("Must specify environment through command parameter, e.g. pytest --env dev")

# 根据环境信息，拼接出环境文件的路径
env_file = f".env.{env_type}"
env_path = ROOT_DIR / env_file

if not env_path.exists():
    raise FileNotFoundError(f"Environment file not found: {env_path}")

load_dotenv(dotenv_path=env_path, override=True)


class Config:
    BASE_URL = os.getenv("BASE_URL")
    if not BASE_URL:
        raise EnvironmentError("BASE_URL is not set in the environment file.")
    HEADLESS = os.getenv("HEADLESS", "false").lower() == "true"
    TIMEOUT = int(os.getenv("TIMEOUT", "10000"))


config = Config()