# pwauto

A high-efficiency UI automation testing framework based on [Playwright](https://playwright.dev/python/) and [pytest](https://docs.pytest.org/).

Built to reduce the boilerplate of UI automation with enterprise-grade features out of the box.

## 🌟 Key Features

- **Global Auto-Login**: Log in just once per test session. Authentication state is automatically saved (`state.json`) and instantly reused across all subsequent tests.
- **Smart Failure Traces**: Automatically saves Playwright Traces (DOM snapshots, network requests, console logs, and videos) upon test failure, seamlessly attaching them to your Allure reports.
- **Out-of-the-Box Fixtures**:
  - `page`: Ready-to-use page fixture injected with global authenticated state.
  - `guest_page`: Clean, unauthenticated page fixture for testing login/registration flows.
- **Environment & Data Driven**: Built-in support for multiple `.env` environments and JSON-based data-driven testing.
- **Feishu (Lark) Integration**: Automatically sends elegant test execution summary cards to your Feishu group upon completion.

## 📦 Installation

```bash
pip install pwauto
playwright install chromium
```

## 🚀 Quick Start

### 1. Create a Page Object

```python
from pwauto.core.base import BasePage

class MyPage(BasePage):
    def open(self):
        self.navigate("/my-path")
        
    def submit(self):
        self.click('role=button[name="Submit"]', name="Click Submit Button")
```

### 2. Write a Test

Just request the `page` fixture (comes with authenticated state):

```python
def test_my_feature(page):
    my_page = MyPage(page)
    my_page.open()
    my_page.submit()
```

### 3. Run and Report

```bash
# Run tests for production environment
pytest --env dev

# View Allure report with attached failure traces
allure serve ./reports/allure-results
```

---

*Note: For detailed project structure, configuration, and advanced usage, please refer to the complete README in the GitHub repository.*