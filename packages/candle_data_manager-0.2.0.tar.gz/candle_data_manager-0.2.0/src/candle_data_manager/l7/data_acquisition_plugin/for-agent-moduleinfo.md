# DataAcquisitionPlugin

데이터 수집 + 저장 파이프라인.

## DataAcquisitionPlugin

DataFetchService.fetch -> DataSaveService.save 연결.

### __init__
__init__(fetch_service: DataFetchService, save_service: DataSaveService)

### Methods

acquire_and_save(symbol: Symbol, start_at: int, end_at: int) -> None
    Provider에서 캔들 수집 후 DB 저장.
