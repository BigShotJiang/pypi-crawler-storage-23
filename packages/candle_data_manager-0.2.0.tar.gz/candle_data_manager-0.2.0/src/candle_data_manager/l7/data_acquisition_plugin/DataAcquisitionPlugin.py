from loguru import logger

from candle_data_manager.l6.data_fetch_service import DataFetchService
from candle_data_manager.l3.data_save_service import DataSaveService
from candle_data_manager.l1.symbol import Symbol


class DataAcquisitionPlugin:
    def __init__(self, fetch_service: DataFetchService, save_service: DataSaveService):
        self._fetch_service = fetch_service
        self._save_service = save_service

    def acquire_and_save(self, symbol: Symbol, start_at: int, end_at: int) -> None:
        # 1. DataFetchService.fetch()로 데이터 획득
        data = self._fetch_service.fetch(symbol, start_at, end_at)

        # 2. DataSaveService.save()로 저장
        self._save_service.save(symbol, data)
