# UpdateOrchestrationPlugin

Active/Passive 업데이트 오케스트레이션.

## UpdateOrchestrationPlugin

여러 종목의 캔들 데이터를 일괄 수집/갱신. 버퍼링 + bulk save.

### __init__
__init__(symbol_service, data_fetch_service, data_save_service, symbol_metadata, symbol_prep_plugin, buffer_size: int = 50000)

### Methods

active_update(archetype, exchange, tradetype, base=None, quote=None, timeframe=None) -> UpdateResult
    거래소 마켓 목록 기반 신규 종목 자동 등록 + 데이터 수집.
    base/quote/timeframe: str 또는 list[str] 지원.
    실패 종목은 건너뛰고 결과에 기록.

passive_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, buffer_size=None) -> UpdateResult
    DB 등록된 Symbol 기반 최신 데이터까지 갱신.
    last_timestamp 이후부터 현재까지 수집.
