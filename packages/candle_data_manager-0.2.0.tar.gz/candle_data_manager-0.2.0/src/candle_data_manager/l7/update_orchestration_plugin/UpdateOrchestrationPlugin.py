import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from loguru import logger

from candle_data_manager.l1.symbol import Symbol
from candle_data_manager.l3.symbol_service import SymbolService
from candle_data_manager.l6.data_fetch_service import DataFetchService
from candle_data_manager.l3.data_save_service import DataSaveService
from candle_data_manager.l3.symbol_metadata import SymbolMetadata
from candle_data_manager.l4.symbol_preparation_plugin import SymbolPreparationPlugin
from candle_data_manager.l0.update_result import UpdateResult


class UpdateOrchestrationPlugin:
    # Active/Passive Update 조율 Plugin

    def __init__(
        self,
        symbol_service: SymbolService,
        data_fetch_service: DataFetchService,
        data_save_service: DataSaveService,
        symbol_metadata: SymbolMetadata,
        symbol_prep_plugin: SymbolPreparationPlugin,
        buffer_size: int = 50000,
        thread_delay: float = 0.5
    ):
        self.symbol_service = symbol_service
        self.data_fetch_service = data_fetch_service
        self.data_save_service = data_save_service
        self.symbol_metadata = symbol_metadata
        self.symbol_prep_plugin = symbol_prep_plugin
        self.buffer_size = buffer_size
        self.thread_delay = thread_delay
        self._buffer_lock = threading.Lock()
        logger.info(f"UpdateOrchestrationPlugin 초기화 완료 (buffer_size={buffer_size}, thread_delay={thread_delay})")

    def _worker_active(self, archetype, exchange, tradetype, base, quote, tf, full_name, listed_at):
        """Active Update worker - 1개 심볼 등록 + fetch"""
        symbol = self.symbol_prep_plugin.register_and_prepare(
            archetype=archetype,
            exchange=exchange,
            tradetype=tradetype,
            base=base,
            quote=quote,
            timeframe=tf,
            full_name=full_name,
            listed_at=listed_at
        )
        data = self.data_fetch_service.fetch_all_data(symbol)
        logger.debug(f"데이터 조회 완료: {symbol.to_string()} - {len(data)} rows")
        return symbol, data

    def _worker_passive(self, symbol):
        """Passive Update worker - 1개 심볼 증분 fetch"""
        status = self.symbol_metadata.get_table_status(
            symbol,
            symbol_id=symbol.id if symbol.is_unified() else None
        )
        last_timestamp = status.get("last_timestamp")

        if last_timestamp is not None:
            start_at = last_timestamp
        else:
            start_at = 0

        end_at = int(time.time())
        data = self.data_fetch_service.fetch(symbol, start_at, end_at)
        logger.debug(f"데이터 조회 완료: {symbol.to_string()} - {len(data)} rows")
        return symbol, data

    def _collect_results(self, futures, buffer_size):
        """Future 결과 수집 + 버퍼 관리"""
        buffer = {}
        buffer_row_count = 0
        success_symbols = []
        failed_symbols = []
        total_rows = 0

        for future in as_completed(futures):
            symbol_info = futures[future]
            try:
                symbol, data = future.result()

                if data:
                    with self._buffer_lock:
                        buffer[symbol] = data
                        buffer_row_count += len(data)
                        total_rows += len(data)

                        if buffer_row_count >= buffer_size:
                            logger.info(f"버퍼 오버플로우 ({buffer_row_count} rows) - bulk_save 실행")
                            self.data_save_service.bulk_save(buffer)
                            buffer.clear()
                            buffer_row_count = 0

                success_symbols.append(symbol)

            except Exception as e:
                error_msg = str(e)
                logger.error(f"Symbol 처리 실패: {symbol_info} - {error_msg}")
                failed_symbols.append((symbol_info, error_msg))

        # 남은 버퍼 flush
        if buffer:
            logger.info(f"마지막 버퍼 flush ({buffer_row_count} rows)")
            self.data_save_service.bulk_save(buffer)

        return success_symbols, failed_symbols, total_rows

    def active_update(
        self,
        archetype: str,
        exchange: str,
        tradetype: str,
        base: str | list[str] = None,
        quote: str | list[str] = None,
        timeframe: str | list[str] = None
    ) -> UpdateResult:
        # 마켓 리스트 획득 -> Symbol 등록 -> 전체 데이터 수집

        logger.info(f"Active Update 시작: {archetype}-{exchange}-{tradetype}" + (f" (base={base})" if base else "") + (f" (quote={quote})" if quote else "") + (f" (timeframe={timeframe})" if timeframe else ""))

        try:
            # 1. 마켓 리스트 획득
            market_list = self.data_fetch_service.get_market_list(archetype, exchange, tradetype)
            logger.info(f"마켓 리스트 조회 완료: {len(market_list)}개 마켓")

            # 1-1. base 필터링 (지정된 경우)
            if base is not None:
                base_list = [base.upper()] if isinstance(base, str) else [b.upper() for b in base]
                market_list = [m for m in market_list if m.get("base", "").upper() in base_list]
                logger.info(f"base={base} 필터링 후: {len(market_list)}개 마켓")

            # 1-2. quote 필터링 (지정된 경우)
            if quote is not None:
                quote_list = [quote.upper()] if isinstance(quote, str) else [q.upper() for q in quote]
                market_list = [m for m in market_list if m.get("quote", "").upper() in quote_list]
                logger.info(f"quote={quote} 필터링 후: {len(market_list)}개 마켓")

            # 1-3. timeframe 결정
            supported_timeframes = self.data_fetch_service.get_supported_timeframes(archetype, exchange, tradetype)

            if timeframe is None:
                target_timeframes = supported_timeframes
            else:
                requested = [timeframe] if isinstance(timeframe, str) else timeframe
                target_timeframes = [tf for tf in requested if tf in supported_timeframes]

            logger.info(f"대상 타임프레임: {target_timeframes}")

            if not target_timeframes:
                logger.warning("대상 타임프레임이 없습니다")
                return UpdateResult(success_symbols=[], failed_symbols=[], total_rows=0)

            # 2. 쓰레딩으로 병렬 처리
            total_symbols = len(market_list) * len(target_timeframes)
            logger.info(f"처리 대상: {total_symbols}개 심볼")

            futures = {}
            with ThreadPoolExecutor(max_workers=total_symbols) as executor:
                for market_info in market_list:
                    m_base = market_info["base"]
                    m_quote = market_info["quote"]
                    full_name = market_info.get("full_name")
                    listed_at = market_info.get("listed_at")

                    for tf in target_timeframes:
                        future = executor.submit(
                            self._worker_active,
                            archetype, exchange, tradetype,
                            m_base, m_quote, tf, full_name, listed_at
                        )
                        symbol_label = f"{m_base}-{m_quote}-{tf}"
                        futures[future] = symbol_label
                        logger.debug(f"쓰레드 제출: {symbol_label}")
                        time.sleep(self.thread_delay)

                success_symbols, failed_symbols, total_rows = self._collect_results(futures, self.buffer_size)

            logger.info(f"Active Update 완료: 성공 {len(success_symbols)}, 실패 {len(failed_symbols)}, 총 {total_rows} rows")

            return UpdateResult(
                success_symbols=success_symbols,
                failed_symbols=failed_symbols,
                total_rows=total_rows
            )

        except Exception as e:
            logger.error(f"Active Update 실패: {str(e)}")
            raise

    def passive_update(
        self,
        archetype: str = None,
        exchange: str = None,
        tradetype: str = None,
        base: str = None,
        quote: str = None,
        timeframe: str = None,
        buffer_size: int = None
    ) -> UpdateResult:
        # 기존 Symbol의 증분 업데이트

        logger.info(f"Passive Update 시작: archetype={archetype}, exchange={exchange}, tradetype={tradetype}")

        if buffer_size is None:
            buffer_size = self.buffer_size

        try:
            # 1. 조건으로 Symbol 검색
            kwargs = {}
            if archetype is not None:
                kwargs['archetype'] = archetype
            if exchange is not None:
                kwargs['exchange'] = exchange
            if tradetype is not None:
                kwargs['tradetype'] = tradetype
            if base is not None:
                kwargs['base'] = base
            if quote is not None:
                kwargs['quote'] = quote
            if timeframe is not None:
                kwargs['timeframe'] = timeframe

            symbols = self.symbol_service.find_symbols_immediate(**kwargs)
            logger.info(f"조건에 맞는 Symbol 개수: {len(symbols)}")

            if not symbols:
                return UpdateResult(success_symbols=[], failed_symbols=[], total_rows=0)

            # 2. 쓰레딩으로 병렬 처리
            futures = {}
            with ThreadPoolExecutor(max_workers=len(symbols)) as executor:
                for symbol in symbols:
                    future = executor.submit(self._worker_passive, symbol)
                    futures[future] = symbol
                    logger.debug(f"쓰레드 제출: {symbol.to_string()}")
                    time.sleep(self.thread_delay)

                success_symbols, failed_symbols, total_rows = self._collect_results(futures, buffer_size)

            logger.info(f"Passive Update 완료: 성공 {len(success_symbols)}, 실패 {len(failed_symbols)}, 총 {total_rows} rows")

            return UpdateResult(
                success_symbols=success_symbols,
                failed_symbols=failed_symbols,
                total_rows=total_rows
            )

        except Exception as e:
            logger.error(f"Passive Update 실패: {str(e)}")
            raise
