# DataRetrievalPlugin

데이터 로드 + 자동 수집 파이프라인.

## DataRetrievalPlugin

DB에 데이터 없으면 자동으로 Provider에서 수집 후 저장하여 반환.

### __init__
__init__(load_service: DataLoadService, fetch_service: DataFetchService, save_service: DataSaveService)

### Methods

load_with_auto_fetch(symbol: Symbol, start_at: int, end_at: int) -> pd.DataFrame
    DB에서 로드 시도. 데이터 부족 시 Provider에서 수집 후 저장, 재로드.
