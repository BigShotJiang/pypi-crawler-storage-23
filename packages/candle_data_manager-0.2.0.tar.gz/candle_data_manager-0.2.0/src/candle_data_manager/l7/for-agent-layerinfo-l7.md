# l7

## data_acquisition_plugin
DataAcquisitionPlugin.__init__(fetch_service: DataFetchService, save_service: DataSaveService) -> None
DataAcquisitionPlugin.acquire_and_save(symbol: Symbol, start_at: int, end_at: int) -> None

## data_retrieval_plugin
DataRetrievalPlugin.__init__(load_service: DataLoadService, fetch_service: DataFetchService, save_service: DataSaveService) -> None
DataRetrievalPlugin.load_with_auto_fetch(symbol: Symbol, start_at: int, end_at: int) -> pd.DataFrame

## update_orchestration_plugin
UpdateOrchestrationPlugin.__init__(symbol_service, data_fetch_service, data_save_service, symbol_metadata, symbol_prep_plugin, buffer_size: int = 50000) -> None
UpdateOrchestrationPlugin.active_update(archetype, exchange, tradetype, base=None, quote=None, timeframe=None) -> UpdateResult
UpdateOrchestrationPlugin.passive_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, buffer_size=None) -> UpdateResult
