# l8

## candle_data_api
CandleDataAPI.__init__(database_url: str = None) -> None
CandleDataAPI.active_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> UpdateResult
CandleDataAPI.passive_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, buffer_size=None) -> UpdateResult
CandleDataAPI.load(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, start_at=None, end_at=None, limit=None) -> list[Market]
CandleDataAPI.get_symbol(symbol_str: str) -> Symbol | None
CandleDataAPI.close() -> None
