import time
from loguru import logger

from candle_data_manager.l1.connection_manager import ConnectionManager
from candle_data_manager.l5.provider_registry import ProviderRegistry
from candle_data_manager.l2.initializer import Initializer
from candle_data_manager.l3.symbol_service import SymbolService
from candle_data_manager.l6.data_fetch_service import DataFetchService
from candle_data_manager.l3.data_save_service import DataSaveService
from candle_data_manager.l3.data_load_service import DataLoadService
from candle_data_manager.l3.symbol_metadata import SymbolMetadata
from candle_data_manager.l3.market_factory_service import MarketFactoryService
from candle_data_manager.l4.symbol_preparation_plugin import SymbolPreparationPlugin
from candle_data_manager.l7.update_orchestration_plugin import UpdateOrchestrationPlugin
from candle_data_manager.l7.data_retrieval_plugin import DataRetrievalPlugin
from candle_data_manager.l0.update_result import UpdateResult
from candle_data_manager.l2.market import Market
from candle_data_manager.l1.symbol import Symbol


class CandleDataAPI:
    def __init__(self, database_url: str = None):
        # DB 초기화
        if database_url is None:
            database_url = "mysql+pymysql://root@localhost/candle_data_manager"

        initializer = Initializer(database_url)
        initializer.initialize()

        # Core
        self._connection_manager = ConnectionManager(database_url)
        provider_registry = ProviderRegistry(self._connection_manager)

        # Service
        self._symbol_service = SymbolService(self._connection_manager)
        fetch_service = DataFetchService(provider_registry)
        save_service = DataSaveService(self._connection_manager)
        load_service = DataLoadService(self._connection_manager)
        symbol_metadata = SymbolMetadata(self._connection_manager)
        self._market_factory = MarketFactoryService()

        # Plugin
        symbol_prep_plugin = SymbolPreparationPlugin(self._symbol_service, symbol_metadata)
        self._update_plugin = UpdateOrchestrationPlugin(
            symbol_service=self._symbol_service,
            data_fetch_service=fetch_service,
            data_save_service=save_service,
            symbol_metadata=symbol_metadata,
            symbol_prep_plugin=symbol_prep_plugin
        )
        self._retrieval_plugin = DataRetrievalPlugin(load_service, fetch_service, save_service)

        logger.info("CandleDataAPI 초기화 완료")

    def active_update(
        self,
        archetype: str = None,
        exchange: str = None,
        tradetype: str = None,
        base: str | list[str] = None,
        quote: str | list[str] = None,
        timeframe: str | list[str] = None
    ) -> UpdateResult:
        # UpdateOrchestrationPlugin.active_update() 호출
        return self._update_plugin.active_update(
            archetype=archetype,
            exchange=exchange,
            tradetype=tradetype,
            base=base,
            quote=quote,
            timeframe=timeframe
        )

    def passive_update(
        self,
        archetype: str = None,
        exchange: str = None,
        tradetype: str = None,
        base: str = None,
        quote: str = None,
        timeframe: str = None,
        buffer_size: int = None
    ) -> UpdateResult:
        # UpdateOrchestrationPlugin.passive_update() 호출
        return self._update_plugin.passive_update(
            archetype=archetype,
            exchange=exchange,
            tradetype=tradetype,
            base=base,
            quote=quote,
            timeframe=timeframe,
            buffer_size=buffer_size
        )

    def load(
        self,
        archetype: str = None,
        exchange: str = None,
        tradetype: str = None,
        base: str = None,
        quote: str = None,
        timeframe: str = None,
        start_at: int = None,
        end_at: int = None,
        limit: int = None
    ) -> list[Market]:
        # 1. SymbolService.find_symbols_immediate()로 조건에 맞는 Symbol 검색
        symbols = self._symbol_service.find_symbols_immediate(
            archetype=archetype,
            exchange=exchange,
            tradetype=tradetype,
            base=base,
            quote=quote,
            timeframe=timeframe
        )

        # start_at, end_at 기본값 설정
        actual_start_at = start_at if start_at is not None else 0
        actual_end_at = end_at if end_at is not None else int(time.time())

        # 2. 각 Symbol에 대해 DataRetrievalPlugin.load_with_auto_fetch() 호출
        markets = []
        for symbol in symbols:
            # DataRetrievalPlugin으로 데이터 로드 (자동 획득 포함)
            df = self._retrieval_plugin.load_with_auto_fetch(
                symbol=symbol,
                start_at=actual_start_at,
                end_at=actual_end_at
            )

            # 3. MarketFactoryService.create_market()로 Market 생성
            market = self._market_factory.create_market(
                symbol=symbol,
                candles=df
            )

            markets.append(market)

        return markets

    def get_symbol(self, symbol_str: str) -> Symbol | None:
        # SymbolService.get_symbol() 호출 (내부에서 세션 관리)
        return self._symbol_service.get_symbol(symbol_str)

    def close(self) -> None:
        # 연결 종료
        self._connection_manager.close()
        logger.info("CandleDataAPI 종료")
