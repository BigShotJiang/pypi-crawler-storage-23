# CandleDataAPI

외부 공개 API. 패키지 진입점.

## CandleDataAPI

모든 내부 컴포넌트 조립 + 외부 인터페이스 제공.
from candle_data_manager import CandleDataAPI 로 사용.

### __init__
__init__(database_url: str = None)
    Initializer로 DB 초기화.
    ConnectionManager, 모든 Service/Plugin/Registry 자동 생성.
    database_url 미제공 시 기본 MySQL 설정.

### Methods

active_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> UpdateResult
    거래소 마켓 목록 기반 신규 종목 등록 + 데이터 수집.

passive_update(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, buffer_size=None) -> UpdateResult
    등록된 종목의 최신 데이터 갱신.

load(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None, start_at=None, end_at=None, limit=None) -> list[Market]
    조건에 맞는 Symbol 검색 후 각각 DB에서 캔들 로드.
    Market(symbol, candles) 리스트 반환.

get_symbol(symbol_str: str) -> Symbol | None
    "CRYPTO-BINANCE-SPOT-BTC-USDT-1h" 형식으로 Symbol 조회.

close() -> None
    DB 연결 종료.
