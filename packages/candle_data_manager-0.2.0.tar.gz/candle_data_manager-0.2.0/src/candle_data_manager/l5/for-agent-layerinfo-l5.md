# l5

## provider_registry
ProviderRegistry.__init__(conn_manager: ConnectionManager) -> None
ProviderRegistry.get_provider(symbol: Symbol) -> IProvider
ProviderRegistry.get_provider_by_key(archetype: str, exchange: str, tradetype: str) -> IProvider
