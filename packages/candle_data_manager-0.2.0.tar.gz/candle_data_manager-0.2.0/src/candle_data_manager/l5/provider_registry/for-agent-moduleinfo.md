# ProviderRegistry

archetype/exchange/tradetype 조합으로 Provider 인스턴스 매핑.

## ProviderRegistry

(archetype, exchange, tradetype) -> Provider 클래스 매핑.
인스턴스 캐싱으로 동일 키 재요청 시 기존 인스턴스 반환.

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

get_provider(symbol: Symbol) -> IProvider
    raise ProviderNotImplementedError
    Symbol의 archetype/exchange/tradetype으로 Provider 조회.
    미등록 조합이면 ProviderNotImplementedError.

get_provider_by_key(archetype: str, exchange: str, tradetype: str) -> IProvider
    raise ProviderNotImplementedError
    직접 키 지정으로 Provider 조회.
