from loguru import logger

from candle_data_manager.l0.exceptions import NoApiKeyError, ProviderNotImplementedError
from candle_data_manager.l1.connection_manager import ConnectionManager
from candle_data_manager.l1.symbol import Symbol
from candle_data_manager.l4.binance_spot_provider import BinanceSpotProvider
from candle_data_manager.l4.binance_futures_provider import BinanceFuturesProvider
from candle_data_manager.l4.upbit_provider import UpbitProvider
from candle_data_manager.l4.krx_provider import KRXProvider
from candle_data_manager.l4.krx_fallback_provider import KRXFallbackProvider
from candle_data_manager.l4.nyse_provider import NyseProvider
from candle_data_manager.l4.nasdaq_provider import NasdaqProvider


class ProviderRegistry:
    # Symbol -> Provider 인스턴스 선택 및 캐싱

    def __init__(self, conn_manager: ConnectionManager):
        self._conn_manager = conn_manager
        self._instance_cache = {}

    _provider_class_mapping = {
        ("CRYPTO", "BINANCE", "SPOT"): BinanceSpotProvider,
        ("CRYPTO", "BINANCE", "FUTURES"): BinanceFuturesProvider,
        ("CRYPTO", "UPBIT", "SPOT"): UpbitProvider,
        ("STOCK", "KRX", "SPOT"): KRXProvider,
        ("STOCK", "NYSE", "SPOT"): NyseProvider,
        ("STOCK", "NASDAQ", "SPOT"): NasdaqProvider,
    }

    _fallback_mapping = {
        ("STOCK", "KRX", "SPOT"): KRXFallbackProvider,
    }

    def get_provider(self, symbol: Symbol):
        # Symbol의 archetype, exchange, tradetype에 맞는 Provider 인스턴스 반환
        return self.get_provider_by_key(symbol.archetype, symbol.exchange, symbol.tradetype)

    def get_provider_by_key(self, archetype: str, exchange: str, tradetype: str):
        # archetype, exchange, tradetype으로 Provider 인스턴스 반환
        key = (archetype.upper(), exchange.upper(), tradetype.upper())

        if key in self._instance_cache:
            return self._instance_cache[key]

        if key not in self._provider_class_mapping:
            raise ProviderNotImplementedError(f"{archetype}-{exchange}-{tradetype}")

        provider_class = self._provider_class_mapping[key]

        try:
            provider_instance = provider_class(self._conn_manager)
        except NoApiKeyError:
            if key in self._fallback_mapping:
                fallback_class = self._fallback_mapping[key]
                logger.info(f"[ProviderRegistry] {provider_class.__name__} API 키 없음, "
                            f"{fallback_class.__name__}으로 전환")
                provider_instance = fallback_class(self._conn_manager)
            else:
                raise

        self._instance_cache[key] = provider_instance
        return provider_instance
