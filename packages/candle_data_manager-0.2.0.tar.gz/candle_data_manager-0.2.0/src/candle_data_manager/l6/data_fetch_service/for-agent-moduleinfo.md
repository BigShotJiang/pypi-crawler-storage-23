# DataFetchService

ProviderRegistry를 통한 데이터 수집 통합 서비스.

## DataFetchService

Provider 선택을 추상화. Symbol 또는 키로 적절한 Provider 호출.

### __init__
__init__(provider_registry: ProviderRegistry)

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    Symbol에 맞는 Provider로 캔들 데이터 수집.

fetch_all_data(symbol: Symbol) -> list[dict]
    Symbol의 전체 데이터 범위를 조회하여 수집.

get_market_list(archetype: str, exchange: str, tradetype: str) -> list[dict]
    해당 거래소의 마켓 목록 조회.

get_supported_timeframes(archetype: str, exchange: str, tradetype: str) -> list[str]
    해당 거래소의 지원 타임프레임 조회.
