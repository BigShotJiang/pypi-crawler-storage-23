# l6

## data_fetch_service
DataFetchService.__init__(provider_registry: ProviderRegistry) -> None
DataFetchService.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
DataFetchService.fetch_all_data(symbol: Symbol) -> list[dict]
DataFetchService.get_market_list(archetype: str, exchange: str, tradetype: str) -> list[dict]
DataFetchService.get_supported_timeframes(archetype: str, exchange: str, tradetype: str) -> list[str]
