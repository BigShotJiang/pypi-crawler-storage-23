# KRXFallbackProvider

KRX(한국거래소) 주식 캔들 데이터 수집 Fallback. IProvider 구현.
KRX API 키가 없을 때 FinanceDataReader 기반으로 동작.

## KRXFallbackProvider

FinanceDataReader 사용.

### Properties
archetype: str               # "STOCK" (property)
exchange: str                # "KRX" (property)
tradetype: str               # "SPOT" (property)

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    FDR로 KRX 종목 일봉 조회 후 정규화 + null 처리.

get_market_list() -> list[dict]
    KRX 전체 종목 목록 조회. base, full_name, quote("KRW"), listed_at 포함.

get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
    데이터 범위 반환. start=0이면 전체 조회.

get_supported_timeframes() -> list[str]
    ["1d"]
