import time
from datetime import datetime, timedelta, timezone

import requests
from loguru import logger

from candle_data_manager.l0.exceptions import ServerNotRespondedError
from candle_data_manager.l1.api_validation_service import ApiValidationService
from candle_data_manager.l1.connection_manager import ConnectionManager
from candle_data_manager.l1.symbol import Symbol
from candle_data_manager.l1.sync_throttler import SyncThrottler
from candle_data_manager.l3.normalization_service import NormalizationService
from candle_data_manager.l3.null_handling_service import NullHandlingService


# KRX OpenAPI (openapi.krx.co.kr) 기반 KRX 데이터 조회
class KRXProvider:

    _BASE_URL = "https://data-dbg.krx.co.kr/svc/apis"
    _ENDPOINTS = {
        "KOSPI": "sto/stk_bydd_trd",
        "KOSDAQ": "sto/ksq_bydd_trd",
    }
    # 2010-01-04 00:00:00 UTC (KRX API 최초 데이터)
    _EARLIEST_TIMESTAMP = 1262563200

    def __init__(self, conn_manager: ConnectionManager) -> None:
        self._api_validation = ApiValidationService()
        self._normalization = NormalizationService()
        self._null_handling = NullHandlingService(conn_manager)

        # API 키 확인 (없으면 NoApiKeyError)
        self._api_key = self._api_validation.get_api_key("KRX")

        # KRX: 초당 10회, 분당 500회
        self._throttler = SyncThrottler(
            requests_per_second=10,
            requests_per_minute=500,
            name="KRX"
        )

        self._session = requests.Session()
        self._session.headers.update({"Accept": "application/json"})

        # 날짜별 전종목 응답 캐시: {"YYYYMMDD": [raw_items...]}
        self._date_cache: dict[str, list[dict]] = {}

    @property
    def archetype(self) -> str:
        return "STOCK"

    @property
    def exchange(self) -> str:
        return "KRX"

    @property
    def tradetype(self) -> str:
        return "SPOT"

    def fetch(self, symbol: Symbol, start_at: int, end_at: int) -> list[dict]:
        ticker = symbol.base
        business_days = self._get_business_days(start_at, end_at)

        filtered_items = []
        for date_str in business_days:
            day_data = self._get_date_data(date_str)
            for item in day_data:
                if item.get("ISU_CD") == ticker:
                    filtered_items.append(item)
                    break  # 한 날짜에 같은 종목은 1건

        if not filtered_items:
            return []

        normalized_data = self._normalization.normalize_krx(filtered_items)
        result = self._null_handling.handle(normalized_data, symbol)

        return result

    def get_market_list(self) -> list[dict]:
        # 최근 영업일 기준 전종목 조회
        recent_date = self._find_recent_business_day()
        day_data = self._get_date_data(recent_date)

        result = []
        seen_codes = set()
        for item in day_data:
            code = item.get("ISU_CD")
            if code and code not in seen_codes:
                seen_codes.add(code)
                result.append({
                    "base": code,
                    "quote": "KRW",
                    "full_name": item.get("ISU_NM"),
                    "listed_at": None,
                })
        return result

    def get_data_range(self, symbol: Symbol) -> tuple[int | None, int | None]:
        return (self._EARLIEST_TIMESTAMP, int(time.time()))

    def get_supported_timeframes(self) -> list[str]:
        return ["1d"]

    # -- Internal Methods --

    def _get_date_data(self, date_str: str) -> list[dict]:
        # 캐시 확인
        if date_str in self._date_cache:
            return self._date_cache[date_str]

        # KOSPI + KOSDAQ 조회 후 병합
        merged = []
        for market, endpoint in self._ENDPOINTS.items():
            self._throttler.wait()
            url = f"{self._BASE_URL}/{endpoint}"
            params = {"AUTH_KEY": self._api_key, "basDd": date_str}

            try:
                response = self._session.get(url, params=params, timeout=30)
                response.raise_for_status()
                data = response.json()
                items = data.get("OutBlock_1", [])
                merged.extend(items)
            except requests.exceptions.RequestException as e:
                logger.warning(f"[KRX] {market} {date_str} 조회 실패: {e}")
                continue

        self._date_cache[date_str] = merged
        return merged

    def _get_business_days(self, start_at: int, end_at: int) -> list[str]:
        # Unix timestamp 범위를 영업일(주말 제외) YYYYMMDD 리스트로 변환
        start_dt = datetime.fromtimestamp(start_at, tz=timezone.utc)
        end_dt = datetime.fromtimestamp(end_at, tz=timezone.utc)

        days = []
        current = start_dt
        while current <= end_dt:
            # 월~금만 (0=월, 6=일)
            if current.weekday() < 5:
                days.append(current.strftime("%Y%m%d"))
            current += timedelta(days=1)

        return days

    def _find_recent_business_day(self) -> str:
        # 오늘 또는 가장 최근 영업일 반환
        now = datetime.now(tz=timezone.utc)
        current = now
        for _ in range(7):
            if current.weekday() < 5:
                date_str = current.strftime("%Y%m%d")
                # KRX 데이터는 익일 08:00 업데이트이므로 전일 사용
                prev = current - timedelta(days=1)
                while prev.weekday() >= 5:
                    prev -= timedelta(days=1)
                return prev.strftime("%Y%m%d")
            current -= timedelta(days=1)
        # fallback
        return now.strftime("%Y%m%d")
