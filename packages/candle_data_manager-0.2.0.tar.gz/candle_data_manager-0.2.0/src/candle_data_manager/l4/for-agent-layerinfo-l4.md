# l4

## binance_spot_provider
BinanceSpotProvider.__init__(conn_manager: ConnectionManager) -> None
BinanceSpotProvider.archetype -> str  # "CRYPTO"
BinanceSpotProvider.exchange -> str  # "BINANCE"
BinanceSpotProvider.tradetype -> str  # "SPOT"
BinanceSpotProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
BinanceSpotProvider.get_market_list() -> list[dict]
BinanceSpotProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
BinanceSpotProvider.get_supported_timeframes() -> list[str]

## binance_futures_provider
BinanceFuturesProvider.__init__(conn_manager: ConnectionManager) -> None
BinanceFuturesProvider.archetype -> str  # "CRYPTO"
BinanceFuturesProvider.exchange -> str  # "BINANCE"
BinanceFuturesProvider.tradetype -> str  # "FUTURES"
BinanceFuturesProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
BinanceFuturesProvider.get_market_list() -> list[dict]
BinanceFuturesProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
BinanceFuturesProvider.get_supported_timeframes() -> list[str]

## upbit_provider
UpbitProvider.__init__(conn_manager: ConnectionManager) -> None
UpbitProvider.archetype -> str  # "CRYPTO"
UpbitProvider.exchange -> str  # "UPBIT"
UpbitProvider.tradetype -> str  # "SPOT"
UpbitProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
UpbitProvider.get_market_list() -> list[dict]
UpbitProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
UpbitProvider.get_supported_timeframes() -> list[str]

## krx_provider
KRXProvider.__init__(conn_manager: ConnectionManager) -> None
KRXProvider.archetype -> str  # "STOCK"
KRXProvider.exchange -> str  # "KRX"
KRXProvider.tradetype -> str  # "SPOT"
KRXProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
KRXProvider.get_market_list() -> list[dict]
KRXProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
KRXProvider.get_supported_timeframes() -> list[str]

## krx_fallback_provider
KRXFallbackProvider.__init__(conn_manager: ConnectionManager) -> None
KRXFallbackProvider.archetype -> str  # "STOCK"
KRXFallbackProvider.exchange -> str  # "KRX"
KRXFallbackProvider.tradetype -> str  # "SPOT"
KRXFallbackProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
KRXFallbackProvider.get_market_list() -> list[dict]
KRXFallbackProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
KRXFallbackProvider.get_supported_timeframes() -> list[str]

## nasdaq_provider
NasdaqProvider.__init__(conn_manager: ConnectionManager) -> None
NasdaqProvider.archetype -> str  # "STOCK"
NasdaqProvider.exchange -> str  # "NASDAQ"
NasdaqProvider.tradetype -> str  # "SPOT"
NasdaqProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
NasdaqProvider.get_market_list() -> list[dict]
NasdaqProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
NasdaqProvider.get_supported_timeframes() -> list[str]

## nyse_provider
NyseProvider.__init__(conn_manager: ConnectionManager) -> None
NyseProvider.archetype -> str  # "STOCK"
NyseProvider.exchange -> str  # "NYSE"
NyseProvider.tradetype -> str  # "SPOT"
NyseProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
NyseProvider.get_market_list() -> list[dict]
NyseProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
NyseProvider.get_supported_timeframes() -> list[str]

## symbol_preparation_plugin
SymbolPreparationPlugin.__init__(symbol_service: SymbolService, symbol_metadata: SymbolMetadata) -> None
SymbolPreparationPlugin.register_and_prepare(archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol
