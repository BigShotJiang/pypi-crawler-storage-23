import time
from datetime import datetime

import pyupbit

from candle_data_manager.l1.connection_manager import ConnectionManager
from candle_data_manager.l1.symbol import Symbol
from candle_data_manager.l1.api_validation_service import ApiValidationService
from candle_data_manager.l1.sync_throttler import SyncThrottler
from candle_data_manager.l3.normalization_service import NormalizationService
from candle_data_manager.l3.null_handling_service import NullHandlingService


# Upbit API 호출 및 데이터 정규화
class UpbitProvider:
    def __init__(self, conn_manager: ConnectionManager) -> None:
        # Service 인스턴스 생성
        self._api_validation = ApiValidationService()
        self._normalization = NormalizationService()
        self._null_handling = NullHandlingService(conn_manager)

        # Throttler 설정 (QUOTATION: 초당 10회, 분당 600회)
        self._throttler = SyncThrottler(
            requests_per_second=10,
            requests_per_minute=600,
            name="Upbit"
        )

        # API 키/Secret 필수 체크
        api_key = self._api_validation.get_api_key("UPBIT")
        self._api_validation.get_api_secret("UPBIT")

        # 서버 응답 확인
        self._api_validation.check_server("UPBIT", api_key)

    @property
    def archetype(self) -> str:
        return "CRYPTO"

    @property
    def exchange(self) -> str:
        return "UPBIT"

    @property
    def tradetype(self) -> str:
        return "SPOT"

    def fetch(self, symbol: Symbol, start_at: int, end_at: int) -> list[dict]:
        ticker = f"{symbol.quote}-{symbol.base}"
        interval = self._map_timeframe_to_interval(symbol.timeframe)

        all_data = []
        current_to = datetime.fromtimestamp(end_at)
        prev_oldest_ts = None

        # 역방향 페이지네이션: to를 이동하면서 200개씩 반복 요청
        while True:
            self._throttler.wait()
            df = pyupbit.get_ohlcv(ticker=ticker, interval=interval, count=200, to=current_to)

            if df is None or df.empty:
                break

            oldest_ts = int(df.index[0].timestamp())

            # 진행 없으면 종료 (같은 시점 반복 = 데이터 끝)
            if oldest_ts == prev_oldest_ts:
                break
            prev_oldest_ts = oldest_ts

            for ts, row in df.iterrows():
                candle_ts = int(ts.timestamp())

                if candle_ts < start_at:
                    continue

                candle_dict = {
                    'timestamp': candle_ts,
                    'opening_price': row['open'],
                    'high_price': row['high'],
                    'low_price': row['low'],
                    'trade_price': row['close'],
                    'candle_acc_trade_volume': row['volume']
                }
                all_data.append(candle_dict)

            # start_at에 도달했으면 종료
            if start_at > 0 and oldest_ts <= start_at:
                break

            current_to = df.index[0]

        if not all_data:
            return []

        # 시간순 정렬 (오름차순)
        all_data.sort(key=lambda x: x['timestamp'])

        # 중복 제거 (timestamp 기준)
        seen = set()
        unique_data = []
        for candle in all_data:
            if candle['timestamp'] not in seen:
                seen.add(candle['timestamp'])
                unique_data.append(candle)

        normalized_data = self._normalization.normalize_upbit(unique_data)
        result = self._null_handling.handle(normalized_data, symbol)

        return result

    def get_market_list(self) -> list[dict]:
        """거래 가능한 마켓 목록 반환"""
        self._throttler.wait()
        tickers = pyupbit.get_tickers()

        result = []
        for ticker in tickers:
            parts = ticker.split("-")
            if len(parts) == 2:
                result.append({
                    "base": parts[1],
                    "quote": parts[0],
                    "full_name": None,
                    "listed_at": None,
                })
        return result

    def get_data_range(self, symbol: Symbol) -> tuple[int | None, int | None]:
        """심볼의 데이터 범위 반환 - start=0이면 fetch()에서 역방향 페이지네이션으로 전체 조회"""
        ticker = f"{symbol.quote}-{symbol.base}"
        interval = self._map_timeframe_to_interval(symbol.timeframe)

        self._throttler.wait()
        latest_df = pyupbit.get_ohlcv(ticker=ticker, interval=interval, count=1)
        if latest_df is None or latest_df.empty:
            return (None, None)

        latest_ts = int(latest_df.index[-1].timestamp())
        return (0, latest_ts)

    def get_supported_timeframes(self) -> list[str]:
        """지원하는 타임프레임 목록 반환"""
        return ["1m", "3m", "5m", "10m", "30m", "1h", "4h", "1d", "1w", "1M"]

    def _map_timeframe_to_interval(self, timeframe: str) -> str:
        # timeframe을 pyupbit interval로 매핑
        mapping = {
            "1m": "minute1",
            "3m": "minute3",
            "5m": "minute5",
            "10m": "minute10",
            "30m": "minute30",
            "1h": "minute60",
            "4h": "minute240",
            "1d": "day",
            "1w": "week",
            "1M": "month"
        }

        return mapping.get(timeframe, "day")
