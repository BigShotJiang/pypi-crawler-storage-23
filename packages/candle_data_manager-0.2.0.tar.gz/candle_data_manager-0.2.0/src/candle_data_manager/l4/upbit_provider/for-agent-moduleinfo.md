# UpbitProvider

Upbit 캔들 데이터 수집. IProvider 구현.

## UpbitProvider

pyupbit 라이브러리 사용. Rate limit: 8req/s, 500req/min.

### Properties
archetype: str               # "CRYPTO" (property)
exchange: str                # "UPBIT" (property)
tradetype: str               # "SPOT" (property)

### __init__
__init__(conn_manager: ConnectionManager)
    SyncThrottler 설정.

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    Upbit candles API 호출 후 정규화 + null 처리.

get_market_list() -> list[dict]
    Upbit 마켓 목록 조회.

get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
    이진 탐색으로 가장 오래된 데이터 timestamp 탐색.

get_supported_timeframes() -> list[str]
    ["1m", "3m", "5m", "10m", "15m", "30m", "1h", "4h", "1d", "1w", "1M"]
