# NyseProvider

NYSE 주식 캔들 데이터 수집. IProvider 구현.

## NyseProvider

FinanceDataReader 사용.

### Properties
archetype: str               # "STOCK" (property)
exchange: str                # "NYSE" (property)
tradetype: str               # "SPOT" (property)

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    FDR로 NYSE 종목 일봉 조회 후 정규화 + null 처리.

get_market_list() -> list[dict]
    NYSE 전체 종목 목록 조회. base, full_name, quote("USD"), listed_at 포함.

get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
    이진 탐색으로 가장 오래된 데이터 timestamp 탐색.

get_supported_timeframes() -> list[str]
    ["1d"]
