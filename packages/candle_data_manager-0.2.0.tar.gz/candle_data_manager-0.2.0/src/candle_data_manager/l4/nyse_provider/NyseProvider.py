import time
from datetime import datetime

import FinanceDataReader as fdr

from candle_data_manager.l1.connection_manager import ConnectionManager
from candle_data_manager.l1.symbol import Symbol
from candle_data_manager.l3.normalization_service import NormalizationService
from candle_data_manager.l3.null_handling_service import NullHandlingService


# FinanceDataReader를 사용한 NYSE 데이터 조회
class NyseProvider:
    def __init__(self, conn_manager: ConnectionManager) -> None:
        self._normalization = NormalizationService()
        self._null_handling = NullHandlingService(conn_manager)

    @property
    def archetype(self) -> str:
        return "STOCK"

    @property
    def exchange(self) -> str:
        return "NYSE"

    @property
    def tradetype(self) -> str:
        return "SPOT"

    def fetch(self, symbol: Symbol, start_at: int, end_at: int) -> list[dict]:
        ticker = symbol.base

        if start_at == 0:
            df = fdr.DataReader(ticker)
        else:
            start_datetime = datetime.fromtimestamp(start_at)
            end_datetime = datetime.fromtimestamp(end_at)
            df = fdr.DataReader(ticker, start_datetime, end_datetime)

        if df is None or df.empty:
            return []

        normalized_data = self._normalization.normalize_fdr(df)

        result = self._null_handling.handle(normalized_data, symbol)

        return result

    def get_market_list(self) -> list[dict]:
        """NYSE 상장 종목 목록 반환"""
        df = fdr.StockListing("NYSE")

        result = []
        for _, row in df.iterrows():
            result.append({
                "base": row.get("Symbol"),
                "quote": "USD",
                "full_name": row.get("Name"),
                "listed_at": None,
            })
        return result

    def get_data_range(self, symbol: Symbol) -> tuple[int | None, int | None]:
        """심볼의 데이터 범위 반환 - start=0이면 fetch()에서 전체 조회"""
        return (0, int(time.time()))

    def get_supported_timeframes(self) -> list[str]:
        """지원하는 타임프레임 목록 반환 (FDR은 일봉만 지원)"""
        return ["1d"]

