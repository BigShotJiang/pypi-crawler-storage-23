# SymbolPreparationPlugin

Symbol 등록 + 캔들 테이블 준비 통합 플러그인.

## SymbolPreparationPlugin

SymbolService.register_symbol_immediate + SymbolMetadata.prepare_table 결합.

### __init__
__init__(symbol_service: SymbolService, symbol_metadata: SymbolMetadata)

### Methods

register_and_prepare(archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol
    Symbol 등록 (없으면 생성) 후 캔들 테이블 준비. Symbol 반환.
