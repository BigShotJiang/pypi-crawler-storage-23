# BinanceSpotProvider

Binance Spot 캔들 데이터 수집. IProvider 구현.

## BinanceSpotProvider

binance-connector Spot 클라이언트 사용. Rate limit: 10req/s, 400req/min.

### Properties
archetype: str               # "CRYPTO" (property)
exchange: str                # "BINANCE" (property)
tradetype: str               # "SPOT" (property)

### __init__
__init__(conn_manager: ConnectionManager)
    ApiValidationService로 API key/secret 조회.
    Spot 클라이언트 초기화.
    SyncThrottler 설정.

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    Binance Spot klines API 호출 후 정규화 + null 처리.

get_market_list() -> list[dict]
    exchangeInfo API로 거래 가능 마켓 조회.

get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
    종목의 데이터 시작/끝 timestamp 조회.

get_supported_timeframes() -> list[str]
    ["1m", "3m", "5m", "15m", "30m", "1h", "2h", "4h", "6h", "8h", "12h", "1d", "3d", "1w", "1M"]
