# for-agent-layerinfo.md

## l0
- exceptions: ProviderNotImplementedError, NoApiKeyError, ServerNotRespondedError, InvalidDataError
- update_result: UpdateResult (frozen dataclass)

## l1
- symbol: Base (ORM base), Symbol (ORM model)
- connection_manager: DB connection/session management
- time_converter: timestamp/datetime 변환
- api_validation_service: API key/secret 조회, 서버 응답 확인
- sync_throttler: 슬라이딩 윈도우 rate limiter

## l2
- candle_repository: 캔들 테이블 동적 생성, UPSERT, 조회
- symbol_repository: Symbol CRUD
- initializer: DB/테이블 초기화
- adjust_history: 수정주가 이력 (ORM model)
- adjust_migration_history: 수정주가 마이그레이션 이력 (ORM model)
- iprovider: Provider Protocol 정의
- market: Symbol + DataFrame 컨테이너

## l3
- normalization_service: 거래소별 raw data 정규화
- null_handling_service: OHLC null 값 처리
- data_save_service: 캔들 데이터 저장/bulk insert
- data_load_service: 캔들 데이터 로드
- symbol_service: Symbol 등록/검색
- symbol_metadata: 테이블 준비/상태 조회
- market_factory_service: Market 객체 생성

## l4
- binance_spot_provider: Binance Spot 캔들 수집
- binance_futures_provider: Binance Futures 캔들 수집
- upbit_provider: Upbit 캔들 수집
- krx_provider: KRX OpenAPI 기반 주식 캔들 수집 (primary)
- krx_fallback_provider: KRX 주식 캔들 수집 (FDR, API 키 없을 때 fallback)
- nasdaq_provider: NASDAQ 주식 캔들 수집
- nyse_provider: NYSE 주식 캔들 수집
- symbol_preparation_plugin: Symbol 등록 + 테이블 준비

## l5
- provider_registry: archetype/exchange/tradetype -> Provider 매핑

## l6
- data_fetch_service: Provider를 통한 데이터 수집 통합

## l7
- data_acquisition_plugin: fetch + save 파이프라인
- data_retrieval_plugin: load + auto-fetch 파이프라인
- update_orchestration_plugin: active/passive update 오케스트레이션

## l8
- candle_data_api: 외부 공개 API (active_update, passive_update, load, get_symbol)
