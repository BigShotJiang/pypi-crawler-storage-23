# AdjustHistory

수정주가 이력 ORM 모델. 테이블명: adjust_histories.

## AdjustHistory

가격 조정(액면분할 등) 이력 기록.

### Properties
id: Mapped[int]                    # PK, autoincrement
symbol_id: Mapped[int]             # FK -> symbols.id
timestamp: Mapped[int]             # BigInteger, 조정 시점
old_price_multiplier: Mapped[float] # Float, 이전 가격 배수
reason: Mapped[str]                # String(100), nullable, 조정 사유
created_at: Mapped[int]            # BigInteger, 생성 시점
