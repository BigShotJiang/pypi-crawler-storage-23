# Market

Symbol + DataFrame 컨테이너.

## Market

@dataclass. 단일 종목의 캔들 시계열 데이터.

### Properties
symbol: Symbol               # 종목 식별 정보
candles: pd.DataFrame        # OHLCV 캔들 데이터
