from dataclasses import dataclass
import pandas as pd
from candle_data_manager.l1.symbol import Symbol


@dataclass
class Market:
    symbol: Symbol
    candles: pd.DataFrame
