# l2

## candle_repository
CandleRepository.to_storage(price: float) -> int  # staticmethod
CandleRepository.from_storage(value: int) -> float  # staticmethod
CandleRepository.get_or_create_table(conn: Connection, symbol) -> Table
CandleRepository.upsert(conn: Connection, symbol, data: Union[dict, list[dict]]) -> None
CandleRepository.query_to_dataframe(conn: Connection, symbol, symbol_id: int = None, start_ts: int = None, end_ts: int = None) -> pd.DataFrame
CandleRepository.table_exists(conn: Connection, symbol) -> bool
CandleRepository.get_last_timestamp(conn: Connection, symbol, symbol_id: int = None) -> int
CandleRepository.get_first_timestamp(conn: Connection, symbol, symbol_id: int = None) -> int
CandleRepository.count(conn: Connection, symbol, symbol_id: int = None) -> int
CandleRepository.has_data(conn: Connection, symbol, symbol_id: int = None) -> bool

## symbol_repository
SymbolRepository.get_by_id(session: Session, symbol_id: int) -> Symbol | None  # staticmethod
SymbolRepository.get_by_components(session, archetype, exchange, tradetype, base, quote, timeframe) -> Symbol | None  # staticmethod
SymbolRepository.get_or_create(session, archetype, exchange, tradetype, base, quote, timeframe, **optional) -> tuple[Symbol, bool]  # staticmethod
SymbolRepository.list_all(session: Session) -> list[Symbol]  # staticmethod
SymbolRepository.list_by_exchange(session: Session, exchange: str, tradetype: str = None) -> list[Symbol]  # staticmethod
SymbolRepository.update_last_timestamp(session: Session, symbol_id: int, timestamp: int) -> None  # staticmethod
SymbolRepository.delete(session: Session, symbol_id: int) -> None  # staticmethod

## initializer
Initializer.__init__(database_url: str) -> None
Initializer.check_connection() -> bool
Initializer.initialize() -> None
Initializer.get_engine() -> Engine

## adjust_history
AdjustHistory  # ORM model: id, symbol_id, timestamp, old_price_multiplier, reason, created_at

## adjust_migration_history
AdjustMigrationHistory  # ORM model: id, symbol_id, migration_type, executed_at, status

## iprovider
IProvider.archetype -> str  # property
IProvider.exchange -> str  # property
IProvider.tradetype -> str  # property
IProvider.fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
IProvider.get_market_list() -> list[dict]
IProvider.get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
IProvider.get_supported_timeframes() -> list[str]

## market
Market(symbol: Symbol, candles: pd.DataFrame)  # dataclass
