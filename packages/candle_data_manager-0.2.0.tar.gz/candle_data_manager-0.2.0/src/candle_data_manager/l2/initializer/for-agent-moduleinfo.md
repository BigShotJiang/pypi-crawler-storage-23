# Initializer

데이터베이스 및 기본 테이블 초기화.

## Initializer

DB 존재 확인/생성, ORM 테이블 생성, Engine 관리.

### __init__
__init__(database_url: str)
    DB URL 저장. DB명 제거한 URL도 별도 보관.

### Methods

check_connection() -> bool
    raise ConnectionError
    DB 서버 연결 가능 여부 확인.

initialize() -> None
    DB 없으면 CREATE DATABASE.
    Base.metadata.create_all()로 ORM 테이블 생성.

get_engine() -> Engine
    SQLAlchemy Engine 반환. initialize() 선행 필요.
