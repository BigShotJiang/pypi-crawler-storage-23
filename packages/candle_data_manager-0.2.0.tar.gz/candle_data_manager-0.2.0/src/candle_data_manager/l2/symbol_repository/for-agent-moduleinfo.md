# SymbolRepository

Symbol 테이블 CRUD. 모든 메서드 staticmethod.

## SymbolRepository

### Methods

get_by_id(session: Session, symbol_id: int) -> Symbol | None  # staticmethod
    ID로 Symbol 조회.

get_by_components(session, archetype, exchange, tradetype, base, quote, timeframe) -> Symbol | None  # staticmethod
    6개 컴포넌트로 Symbol 조회.

get_or_create(session, archetype, exchange, tradetype, base, quote, timeframe, **optional) -> tuple[Symbol, bool]  # staticmethod
    Symbol 조회, 없으면 생성. (symbol, created) 반환.
    optional: full_name, listed_at 등 추가 필드.

list_all(session: Session) -> list[Symbol]  # staticmethod
    모든 Symbol 조회.

list_by_exchange(session: Session, exchange: str, tradetype: str = None) -> list[Symbol]  # staticmethod
    거래소별 Symbol 조회. tradetype 필터 선택적.

update_last_timestamp(session: Session, symbol_id: int, timestamp: int) -> None  # staticmethod
    raise ValueError
    last_timestamp 갱신. Symbol 없으면 ValueError.

delete(session: Session, symbol_id: int) -> None  # staticmethod
    raise ValueError
    Symbol 삭제. 없으면 ValueError.
