from .IProvider import IProvider

__all__ = ['IProvider']
