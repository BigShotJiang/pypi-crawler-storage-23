# IProvider

데이터 Provider Protocol 인터페이스 정의.

## IProvider

typing.Protocol. 모든 Provider가 구현해야 하는 인터페이스.

### Properties
archetype: str               # CRYPTO, STOCK 등 (property)
exchange: str                # BINANCE, UPBIT, KRX 등 (property)
tradetype: str               # SPOT, FUTURES (property)

### Methods

fetch(symbol: Symbol, start_at: int, end_at: int) -> list[dict]
    캔들 데이터 조회. start_at/end_at은 Unix timestamp (초).
    반환 dict 키: timestamp, open, high, low, close, volume.

get_market_list() -> list[dict]
    현재 거래 가능한 모든 마켓 정보 반환.

get_data_range(symbol: Symbol) -> tuple[int | None, int | None]
    거래소가 제공하는 데이터의 (시작, 끝) timestamp.

get_supported_timeframes() -> list[str]
    지원 타임프레임 목록 반환. 예: ["1m", "5m", "1h", "1d"]
