# AdjustMigrationHistory

수정주가 마이그레이션 이력 ORM 모델. 테이블명: adjust_migration_histories.

## AdjustMigrationHistory

가격 조정 마이그레이션 실행 이력 추적.

### Properties
id: Mapped[int]              # PK, autoincrement
symbol_id: Mapped[int]       # FK -> symbols.id
migration_type: Mapped[str]  # String(50), 마이그레이션 유형
executed_at: Mapped[int]     # BigInteger, 실행 시점
status: Mapped[str]          # String(20), 실행 상태
