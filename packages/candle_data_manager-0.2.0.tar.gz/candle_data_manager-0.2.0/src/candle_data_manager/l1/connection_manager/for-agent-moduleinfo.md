# ConnectionManager

SQLAlchemy 기반 DB 연결/세션 관리.

## ConnectionManager

Engine, Session 팩토리 관리. context manager로 안전한 트랜잭션 제공.

### Properties
engine: Engine               # SQLAlchemy Engine
Session: sessionmaker         # Session 팩토리

### __init__
__init__(database_url: str = None, pool_size: int = 5, max_overflow: int = 10)
    database_url 미제공 시 기본값: mysql+pymysql://root@localhost/candle_data_manager
    MySQL charset utf8mb4, pool_pre_ping=True, pool_recycle=3600.

### Methods

get_session() -> Session
    새 Session 인스턴스 반환.

get_connection()  # context manager
    raise Exception
    Raw DB connection 제공. 정상 시 commit, 예외 시 rollback 후 재발생.

session_scope()  # context manager
    raise Exception
    Session 제공. 정상 시 commit, 예외 시 rollback 후 재발생.

check_health() -> bool
    raise ConnectionError
    SELECT 1 실행하여 연결 상태 확인.

close() -> None
    모든 연결 종료.
