# SyncThrottler

슬라이딩 윈도우 기반 동기 Rate Limiter. 스레드 세이프.

## SyncThrottler

여러 시간 단위(초/분) 동시 제한 지원.

### __init__
__init__(requests_per_second: float = None, requests_per_minute: float = None, name: str = "Throttler")
    둘 다 None이면 제한 없음.

### Methods

wait(cost: int = 1) -> float
    요청 전 호출. 제한 초과 시 필요한 만큼 sleep.
    실제 대기 시간(초) 반환.
    스레드 세이프 (threading.Lock).

get_stats() -> dict
    현재 상태 반환.
    각 제한별: window_seconds, max_requests, current_count, usage_percent.
