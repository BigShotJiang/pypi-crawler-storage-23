# l1

## symbol
Base  # SQLAlchemy DeclarativeBase
Symbol.__init__(archetype, exchange, tradetype, base, quote, timeframe, full_name=None, listed_at=None, last_timestamp=None)
Symbol.__hash__() -> int
Symbol.__eq__(other: object) -> bool
Symbol.is_unified() -> bool
Symbol.get_table_name() -> str
Symbol.from_string(symbol_str: str) -> Symbol  # classmethod
Symbol.to_string() -> str

## connection_manager
ConnectionManager.__init__(database_url: str = None, pool_size: int = 5, max_overflow: int = 10) -> None
ConnectionManager.get_session() -> Session
ConnectionManager.get_connection()  # context manager
ConnectionManager.session_scope()  # context manager
ConnectionManager.check_health() -> bool
ConnectionManager.close() -> None

## time_converter
TimeConverter.mutate_to(value: str | int | datetime, to_type: str) -> int | datetime  # staticmethod

## api_validation_service
ApiValidationService.__init__() -> None
ApiValidationService.get_api_key(exchange: str) -> str
ApiValidationService.get_api_secret(exchange: str) -> str
ApiValidationService.check_server(exchange: str, api_key: str) -> bool

## sync_throttler
SyncThrottler.__init__(requests_per_second: float = None, requests_per_minute: float = None, name: str = "Throttler") -> None
SyncThrottler.wait(cost: int = 1) -> float
SyncThrottler.get_stats() -> dict
