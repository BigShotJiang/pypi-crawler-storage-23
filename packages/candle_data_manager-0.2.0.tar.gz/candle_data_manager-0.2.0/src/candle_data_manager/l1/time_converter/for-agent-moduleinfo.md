# TimeConverter

timestamp/datetime 상호 변환 유틸리티.

## TimeConverter

모든 메서드 staticmethod.

### Methods

mutate_to(value: str | int | datetime, to_type: str) -> int | datetime  # staticmethod
    raise ValueError
    입력값을 datetime으로 변환 후 목표 형식으로 재변환.
    to_type: "timestamp" -> Unix timestamp (int), "datetime" -> datetime.
    int 입력: 10자리=초, 13자리=밀리초로 자동 판별.
    timezone 없으면 UTC 자동 추가.
