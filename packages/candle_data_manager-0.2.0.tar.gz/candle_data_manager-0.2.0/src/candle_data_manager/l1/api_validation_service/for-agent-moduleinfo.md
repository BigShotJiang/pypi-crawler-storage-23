# ApiValidationService

거래소 API key/secret 조회 및 서버 응답 확인.

## ApiValidationService

.env 파일에서 API 키 로드. 서버 헬스체크.

### Properties
server_urls: dict[str, str]  # 거래소별 API 서버 URL

### __init__
__init__()
    .env 파일 자동 로드. 서버 URL 설정.

### Methods

get_api_key(exchange: str) -> str
    raise NoApiKeyError
    .env에서 {EXCHANGE}_API_KEY 조회. 없으면 NoApiKeyError.

get_api_secret(exchange: str) -> str
    raise NoApiKeyError
    .env에서 {EXCHANGE}_API_SECRET 조회. 없으면 NoApiKeyError.

check_server(exchange: str, api_key: str) -> bool
    raise ServerNotRespondedError
    API 서버에 GET 요청 (타임아웃 5초). 무응답 시 ServerNotRespondedError.
