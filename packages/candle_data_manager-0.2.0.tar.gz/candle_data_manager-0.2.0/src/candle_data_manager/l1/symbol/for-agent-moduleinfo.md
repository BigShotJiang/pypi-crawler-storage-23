# Symbol

SQLAlchemy ORM 기본 클래스 및 Symbol 모델.

## Base

SQLAlchemy DeclarativeBase. 모든 ORM 모델의 부모 클래스.

## Symbol

종목 식별 정보를 담는 ORM 모델. 테이블명: symbols.

### Properties
id: Mapped[int]              # PK, autoincrement
archetype: Mapped[str]       # CRYPTO, STOCK
exchange: Mapped[str]        # BINANCE, UPBIT, KRX, NASDAQ, NYSE
tradetype: Mapped[str]       # SPOT, FUTURES
base: Mapped[str]            # BTC, ETH, 005930
quote: Mapped[str]           # USDT, KRW, USD
timeframe: Mapped[str]       # 1d, 4h, 1m
full_name: Mapped[str]       # nullable, 종목 전체명
listed_at: Mapped[int]       # nullable, 상장일 timestamp
last_timestamp: Mapped[int]  # nullable, 마지막 수집 timestamp

### __init__
__init__(archetype, exchange, tradetype, base, quote, timeframe, full_name=None, listed_at=None, last_timestamp=None)
    유니크 제약: (archetype, exchange, tradetype, base, quote, timeframe)

### Methods

is_unified() -> bool
    timeframe이 'm'으로 끝나지 않으면 통합 테이블(True).

get_table_name() -> str
    통합: {archetype}_{exchange}_{tradetype}_{timeframe} (소문자)
    개별: {archetype}_{exchange}_{tradetype}_{base}_{quote}_{timeframe} (소문자)

from_string(symbol_str: str) -> Symbol  # classmethod
    raise ValueError
    "CRYPTO-BINANCE-SPOT-BTC-USDT-1h" 형식 문자열을 Symbol로 변환.
    6개 컴포넌트가 아니면 ValueError.

to_string() -> str
    "CRYPTO-BINANCE-SPOT-BTC-USDT-1h" 형식 문자열 반환.
