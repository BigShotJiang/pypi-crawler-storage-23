# DataSaveService

캔들 데이터 DB 저장.

## DataSaveService

CandleRepository를 사용하여 단일/bulk 저장.

### __init__
__init__(conn_manager)

### Methods

save(symbol, data: list[dict]) -> None
    단일 Symbol 데이터 UPSERT 저장.

bulk_save(buffer: dict) -> None
    {symbol: [candles]} 형태의 버퍼를 테이블별로 재그룹화하여 bulk insert.
    통합 테이블의 경우 여러 Symbol 데이터를 하나의 테이블로 합침.
