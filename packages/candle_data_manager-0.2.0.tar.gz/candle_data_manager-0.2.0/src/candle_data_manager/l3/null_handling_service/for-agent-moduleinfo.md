# NullHandlingService

OHLC null 값 처리.

## NullHandlingService

OHLC 중 null이 있으면 이전 캔들의 close로 채움. DB 조회 포함.

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

handle(data: list[dict], symbol: Symbol) -> list[dict]
    raise InvalidDataError
    데이터 내 null 가격을 이전 캔들 close로 대체.
    첫 캔들이 null이면 DB에서 직전 close 조회.
    DB에도 없으면 InvalidDataError.
