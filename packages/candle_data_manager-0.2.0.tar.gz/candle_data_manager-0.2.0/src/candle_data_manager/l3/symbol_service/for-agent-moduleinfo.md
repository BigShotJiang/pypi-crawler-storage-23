# SymbolService

Symbol 등록/검색 비즈니스 로직.

## SymbolService

SymbolRepository 래핑. 세션 내부 관리 버전 메서드 포함.

### __init__
__init__(connection_manager: ConnectionManager)

### Methods

register_symbol(session, archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol
    Symbol 등록. 이미 존재하면 기존 반환.

find_symbols(session, archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> list[Symbol]
    조건부 Symbol 검색. 모든 파라미터 선택적.

get_by_string(session: Session, symbol_str: str) -> Symbol | None
    raise ValueError
    "CRYPTO-BINANCE-SPOT-BTC-USDT-1h" 형식으로 Symbol 조회.

find_symbols_immediate(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> list[Symbol]
    세션 자동 관리 버전 find_symbols.

get_symbol(symbol_str: str) -> Symbol | None
    세션 자동 관리 버전 get_by_string.

register_symbol_immediate(archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol
    세션 자동 관리 + 즉시 커밋 버전 register_symbol.
