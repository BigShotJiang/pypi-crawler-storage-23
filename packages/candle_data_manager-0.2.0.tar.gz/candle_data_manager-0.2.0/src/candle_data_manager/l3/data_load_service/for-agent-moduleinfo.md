# DataLoadService

DB에서 캔들 데이터 로드.

## DataLoadService

CandleRepository.query_to_dataframe 래핑.

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

load(symbol: Symbol, start_at: int = None, end_at: int = None, limit: int = None) -> pd.DataFrame
    DB에서 캔들 데이터 조회. timestamp 범위 및 건수 제한 가능.
    가격은 float로 자동 변환됨.
