# MarketFactoryService

Market 객체 팩토리.

## MarketFactoryService

### __init__
__init__()

### Methods

create_market(symbol: Symbol, candles: pd.DataFrame) -> Market
    Symbol과 DataFrame으로 Market 객체 생성.
