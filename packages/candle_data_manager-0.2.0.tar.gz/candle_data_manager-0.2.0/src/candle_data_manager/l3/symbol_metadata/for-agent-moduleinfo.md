# SymbolMetadata

Symbol의 캔들 테이블 준비 및 상태 조회.

## SymbolMetadata

CandleRepository를 사용하여 테이블 관리.

### __init__
__init__(conn_manager: ConnectionManager)

### Methods

prepare_table(symbol) -> None
    Symbol의 캔들 테이블이 없으면 생성.

get_table_status(symbol, symbol_id: int = None) -> dict
    테이블 상태 반환.
    키: exists, has_data, count, first_timestamp, last_timestamp.
