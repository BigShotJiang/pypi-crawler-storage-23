# l3

## normalization_service
NormalizationService.normalize_binance(raw_data: list[dict]) -> list[dict]
NormalizationService.normalize_upbit(raw_data: list[dict]) -> list[dict]
NormalizationService.normalize_binance_spot(raw_data: list) -> list[dict]
NormalizationService.normalize_binance_futures(raw_data: list) -> list[dict]
NormalizationService.normalize_fdr(raw_data: pd.DataFrame) -> list[dict]

## null_handling_service
NullHandlingService.__init__(conn_manager: ConnectionManager) -> None
NullHandlingService.handle(data: list[dict], symbol: Symbol) -> list[dict]

## data_save_service
DataSaveService.__init__(conn_manager) -> None
DataSaveService.save(symbol, data: list[dict]) -> None
DataSaveService.bulk_save(buffer: dict) -> None

## data_load_service
DataLoadService.__init__(conn_manager: ConnectionManager) -> None
DataLoadService.load(symbol: Symbol, start_at: int = None, end_at: int = None, limit: int = None) -> pd.DataFrame

## symbol_service
SymbolService.__init__(connection_manager: ConnectionManager) -> None
SymbolService.register_symbol(session, archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol
SymbolService.find_symbols(session, archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> list[Symbol]
SymbolService.get_by_string(session: Session, symbol_str: str) -> Symbol | None
SymbolService.find_symbols_immediate(archetype=None, exchange=None, tradetype=None, base=None, quote=None, timeframe=None) -> list[Symbol]
SymbolService.get_symbol(symbol_str: str) -> Symbol | None
SymbolService.register_symbol_immediate(archetype, exchange, tradetype, base, quote, timeframe, **optional) -> Symbol

## symbol_metadata
SymbolMetadata.__init__(conn_manager: ConnectionManager) -> None
SymbolMetadata.prepare_table(symbol) -> None
SymbolMetadata.get_table_status(symbol, symbol_id: int = None) -> dict

## market_factory_service
MarketFactoryService.__init__() -> None
MarketFactoryService.create_market(symbol: Symbol, candles: pd.DataFrame) -> Market
