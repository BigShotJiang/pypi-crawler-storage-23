# NormalizationService

거래소별 raw API 응답을 표준 캔들 dict 형식으로 정규화.

## NormalizationService

정규화 결과 dict 키: timestamp, open, high, low, close, volume.

### Methods

normalize_binance(raw_data: list[dict]) -> list[dict]
    Binance REST API dict 응답 정규화.

normalize_upbit(raw_data: list[dict]) -> list[dict]
    Upbit API dict 응답 정규화.

normalize_binance_spot(raw_data: list) -> list[dict]
    Binance Spot klines (list of lists) 정규화.

normalize_binance_futures(raw_data: list) -> list[dict]
    Binance Futures klines (list of lists) 정규화.

normalize_fdr(raw_data: pd.DataFrame) -> list[dict]
    FinanceDataReader DataFrame 정규화.
