# l0

## exceptions
InvalidDataError.__init__(reason: str) -> None
NoApiKeyError.__init__(exchange: str) -> None
ProviderNotImplementedError.__init__(exchange: str) -> None
ServerNotRespondedError.__init__(exchange: str) -> None

## update_result
UpdateResult(success_symbols: list, failed_symbols: list, total_rows: int)  # frozen dataclass
