# Exceptions

도메인 예외 클래스 모음. 모든 예외는 Exception 상속.

## InvalidDataError

유효하지 않은 데이터 발견 시 발생.

### Properties
reason: str                  # 오류 사유

### __init__
__init__(reason: str)
    메시지: "Invalid data: {reason}"

## NoApiKeyError

거래소 API 키가 환경변수에 없을 때 발생.

### Properties
exchange: str                # 거래소명

### __init__
__init__(exchange: str)
    메시지: "No API key found for {exchange}"

## ProviderNotImplementedError

미구현 Provider 호출 시 발생.

### Properties
exchange: str                # 거래소명

### __init__
__init__(exchange: str)
    메시지: "Provider not implemented for {exchange}"

## ServerNotRespondedError

API 서버 무응답 시 발생.

### Properties
exchange: str                # 거래소명

### __init__
__init__(exchange: str)
    메시지: "Server not responded for {exchange}"
