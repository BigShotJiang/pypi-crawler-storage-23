# UpdateResult

Active/Passive Update 결과를 담는 불변 데이터클래스.

## UpdateResult

@dataclass(frozen=True). 업데이트 작업 결과 요약.

### Properties
success_symbols: list        # 성공한 Symbol 리스트
failed_symbols: list         # 실패한 (symbol, reason) 튜플 리스트
total_rows: int              # 총 저장된 row 수
