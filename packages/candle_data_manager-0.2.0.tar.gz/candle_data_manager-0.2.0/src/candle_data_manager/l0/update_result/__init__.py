from .UpdateResult import UpdateResult

__all__ = ['UpdateResult']
