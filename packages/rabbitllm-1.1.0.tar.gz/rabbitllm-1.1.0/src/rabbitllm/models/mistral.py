# Backward-compatibility shim — implementation moved to base_models.py.
from .base_models import RabbitLLMMistral as RabbitLLMMistral  # noqa: F401
