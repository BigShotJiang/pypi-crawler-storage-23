# Backward-compatibility shim — implementation moved to base_models.py.
from .base_models import RabbitLLMLlama2 as RabbitLLMLlama2  # noqa: F401
