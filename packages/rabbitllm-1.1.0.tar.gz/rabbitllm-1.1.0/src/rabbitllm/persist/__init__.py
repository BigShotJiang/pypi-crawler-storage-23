from .base import ModelPersister as ModelPersister
