import reflex as rx

config = rx.Config(
    app_name="prs_ui",
    disable_plugins=["reflex.plugins.sitemap.SitemapPlugin"],
)
