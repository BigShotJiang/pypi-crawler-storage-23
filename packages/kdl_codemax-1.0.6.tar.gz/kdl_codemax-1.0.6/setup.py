from setuptools import setup, find_packages

setup(
    name="kdl_codemax",
    version="1.0.6",
    packages=["kdl_codemax"],
    package_dir={"kdl_codemax": "."},
    install_requires=["requests"],
)
