---
name: work-with-github
description: Work with GitHub repositories, including private ones. 
---

For github repositories that cannot be cloned with `git clone <repo-url>` due to permission issues, you can use the GitHub CLI (`gh`) to authenticate and clone the repository. 

The GitHub CLI uses a token set in the `GITHUB_TOKEN` environment variable to authenticate your requests. This allows you to access private repositories that your token has permissions for. 

You might also have write access to certain repositories, allowing you to push your changes back. However, always confirm with the user before pushing any changes.