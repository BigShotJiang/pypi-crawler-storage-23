"""deeprepo TUI — interactive command center."""

from .shell import DeepRepoShell

__all__ = ["DeepRepoShell"]
