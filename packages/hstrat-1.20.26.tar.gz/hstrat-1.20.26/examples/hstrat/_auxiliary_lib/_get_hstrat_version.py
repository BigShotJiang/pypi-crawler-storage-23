def get_hstrat_version() -> str:
    return "1.20.26"
