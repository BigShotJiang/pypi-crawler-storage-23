"""MCP server for mageflow workflow observability."""
from mageflow_mcp.server import create_server, main
