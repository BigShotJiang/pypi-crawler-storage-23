# Installation

You need to have Python 3.10 or higher installed on your system.

To install the latest release of `Rectangle` from PyPI:

```bash
pip install rectanglepy
```

For more details, see the [documentation](https://Rectanglepy.readthedocs.io).
