```{include} ../README.md

```

```{toctree}
:hidden: true
:maxdepth: 1

api.md
installation.md
tutorials.md
changelog.md
contributing.md
references.md


```
