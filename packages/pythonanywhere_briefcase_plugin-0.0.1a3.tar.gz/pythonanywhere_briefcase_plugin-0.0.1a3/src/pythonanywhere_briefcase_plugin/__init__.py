from pythonanywhere_briefcase_plugin.channel import PythonAnywherePublicationChannel

__version__ = "0.0.1a3"
__all__ = ["PythonAnywherePublicationChannel"]
