# from multiplied.analysis.extract import (
#     pq_extract_stages,
# )

# create fixture, mocks? teardowns?


def test_pq_extract_stages(): ...
