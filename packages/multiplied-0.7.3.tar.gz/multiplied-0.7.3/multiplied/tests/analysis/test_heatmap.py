# create fixture, mocks? teardowns?


def test_df_global_heatmap(): ...


def test_df_global_3d_heatmap(): ...


def test_df_stage_heatmap(): ...
