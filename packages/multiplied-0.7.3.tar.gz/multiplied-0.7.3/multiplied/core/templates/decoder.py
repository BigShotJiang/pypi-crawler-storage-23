########################################
# Decoders Reduce X Layers To Y Layers #
########################################


def build_simple_decoder():
    """ """
    ...
