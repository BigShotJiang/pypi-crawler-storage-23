####################################
# Adders Reduces Two Layers To One #
####################################


def build_4b_adder_slice():
    """ """
    ...


def build_8b_adder_slice():
    """ """
    ...


def build_16b_adder_slice():
    """ """
    ...


# def build_32b_adder_slice():
#     """

#     """
#     ...
