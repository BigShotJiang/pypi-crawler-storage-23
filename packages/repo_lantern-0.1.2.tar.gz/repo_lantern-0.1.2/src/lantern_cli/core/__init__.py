"""Core module - Architect, Runner, and Synthesizer."""
