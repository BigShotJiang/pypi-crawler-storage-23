"""
JSEye - JavaScript Intelligence & Attack Surface Discovery Engine
A production-grade tool for JavaScript reconnaissance and security analysis.
"""

from .version import __version__

__all__ = ['__version__']