"""Version information for JSEye."""

__version__ = "3.0.1"