//! Benchmark harness for measuring Spark Connect client performance.
//!
//! Measures query execution time across different row counts to compare
//! against alternative approaches (Python subprocess, HTTP service).

use std::time::Instant;

use serde::{Deserialize, Serialize};
use tracing::info;

use crate::spark_client::DatabricksClient;
use crate::sql_builder;

/// Single benchmark iteration result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IterationResult {
    pub iteration: usize,
    pub rows_fetched: usize,
    pub total_ms: u64,
    pub rows_per_sec: f64,
}

/// Aggregated results for a single row count.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RowCountResult {
    pub row_count: usize,
    pub iterations: Vec<IterationResult>,
    pub avg_ms: f64,
    pub min_ms: u64,
    pub max_ms: u64,
    pub p50_ms: u64,
    pub p95_ms: u64,
    pub avg_rows_per_sec: f64,
}

/// Full benchmark suite results.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BenchmarkResults {
    pub scenario: String,
    pub table_name: String,
    pub timestamp: String,
    pub row_counts: Vec<RowCountResult>,
}

/// Configuration for benchmark run.
#[derive(Debug, Clone)]
pub struct BenchmarkConfig {
    pub table_name: String,
    pub row_counts: Vec<usize>,
    pub iterations: usize,
    pub warmup_iterations: usize,
}

impl Default for BenchmarkConfig {
    fn default() -> Self {
        Self {
            table_name: String::new(),
            row_counts: vec![1000, 10_000, 100_000],
            iterations: 10,
            warmup_iterations: 2,
        }
    }
}

/// Run benchmark suite against Databricks via Rust Spark Connect client.
pub async fn run_benchmark(
    client: &DatabricksClient,
    config: &BenchmarkConfig,
) -> Result<BenchmarkResults, String> {
    info!(
        "Starting Rust client benchmark: table={}, row_counts={:?}, iterations={}",
        config.table_name, config.row_counts, config.iterations
    );

    let mut row_count_results = Vec::with_capacity(config.row_counts.len());

    for &row_count in &config.row_counts {
        info!("Benchmarking {} rows...", row_count);

        // Warmup runs (not counted)
        for i in 0..config.warmup_iterations {
            info!("  Warmup {}/{}", i + 1, config.warmup_iterations);
            let sql = sql_builder::select_data_sql(&config.table_name, row_count, 0);
            if let Err(e) = client.execute_sql_reattachable(&sql, row_count).await {
                return Err(format!("Warmup query failed: {}", e));
            }
        }

        // Actual benchmark iterations (use reattachable for >10K rows)
        let mut iterations = Vec::with_capacity(config.iterations);

        for i in 0..config.iterations {
            let sql = sql_builder::select_data_sql(&config.table_name, row_count, 0);

            let start = Instant::now();
            let response = client
                .execute_sql_reattachable(&sql, row_count)
                .await
                .map_err(|e| format!("Query failed: {}", e))?;
            let total_ms = start.elapsed().as_millis() as u64;

            let rows_fetched = response.row_count as usize;
            let rows_per_sec = if total_ms > 0 {
                (rows_fetched as f64) / (total_ms as f64 / 1000.0)
            } else {
                0.0
            };

            info!(
                "  Iteration {}/{}: {}ms, {} rows, {:.0} rows/sec",
                i + 1,
                config.iterations,
                total_ms,
                rows_fetched,
                rows_per_sec
            );

            iterations.push(IterationResult {
                iteration: i + 1,
                rows_fetched,
                total_ms,
                rows_per_sec,
            });
        }

        let result = aggregate_iterations(&iterations, row_count);
        info!(
            "  Summary: avg={}ms, p50={}ms, p95={}ms, {:.0} rows/sec",
            result.avg_ms as u64, result.p50_ms, result.p95_ms, result.avg_rows_per_sec
        );

        row_count_results.push(result);
    }

    Ok(BenchmarkResults {
        scenario: "rust_direct".to_string(),
        table_name: config.table_name.clone(),
        timestamp: chrono::Utc::now().to_rfc3339(),
        row_counts: row_count_results,
    })
}

fn aggregate_iterations(iterations: &[IterationResult], row_count: usize) -> RowCountResult {
    let mut timings: Vec<u64> = iterations.iter().map(|i| i.total_ms).collect();
    timings.sort_unstable();

    let sum_ms: u64 = timings.iter().sum();
    let avg_ms = sum_ms as f64 / timings.len() as f64;
    let min_ms = *timings.first().unwrap_or(&0);
    let max_ms = *timings.last().unwrap_or(&0);
    let p50_ms = percentile(&timings, 50);
    let p95_ms = percentile(&timings, 95);

    // Use actual rows_fetched, not the requested row_count
    let total_rows_fetched: usize = iterations.iter().map(|i| i.rows_fetched).sum();
    let avg_rows_fetched = total_rows_fetched as f64 / iterations.len() as f64;

    let avg_rows_per_sec = if avg_ms > 0.0 {
        avg_rows_fetched / (avg_ms / 1000.0)
    } else {
        0.0
    };

    RowCountResult {
        row_count,
        iterations: iterations.to_vec(),
        avg_ms,
        min_ms,
        max_ms,
        p50_ms,
        p95_ms,
        avg_rows_per_sec,
    }
}

fn percentile(sorted: &[u64], p: usize) -> u64 {
    if sorted.is_empty() {
        return 0;
    }
    let idx = (p * sorted.len() / 100).min(sorted.len() - 1);
    sorted[idx]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_percentile_empty() {
        assert_eq!(percentile(&[], 50), 0);
    }

    #[test]
    fn test_percentile_single() {
        assert_eq!(percentile(&[100], 50), 100);
    }

    #[test]
    fn test_percentile_multiple() {
        let sorted: Vec<u64> = (1..=100).collect();
        assert!(percentile(&sorted, 50) >= 50);
        assert!(percentile(&sorted, 95) >= 95);
    }

    #[test]
    fn test_aggregate_iterations() {
        let iterations = vec![
            IterationResult {
                iteration: 1,
                rows_fetched: 1000,
                total_ms: 100,
                rows_per_sec: 10000.0,
            },
            IterationResult {
                iteration: 2,
                rows_fetched: 1000,
                total_ms: 120,
                rows_per_sec: 8333.0,
            },
            IterationResult {
                iteration: 3,
                rows_fetched: 1000,
                total_ms: 110,
                rows_per_sec: 9090.0,
            },
        ];

        let result = aggregate_iterations(&iterations, 1000);
        assert_eq!(result.row_count, 1000);
        assert_eq!(result.min_ms, 100);
        assert_eq!(result.max_ms, 120);
        assert!((result.avg_ms - 110.0).abs() < 0.1);
    }

    #[test]
    fn test_benchmark_config_default() {
        let config = BenchmarkConfig::default();
        assert_eq!(config.row_counts, vec![1000, 10_000, 100_000]);
        assert_eq!(config.iterations, 10);
        assert_eq!(config.warmup_iterations, 2);
    }
}
