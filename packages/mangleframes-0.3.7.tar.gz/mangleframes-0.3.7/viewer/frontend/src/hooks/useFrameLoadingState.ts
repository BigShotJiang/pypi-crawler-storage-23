import { useIsFetching } from '@tanstack/react-query'

export function useFrameLoadingState(frameName: string): boolean {
  const schemaFetching = useIsFetching({ queryKey: ['schema', frameName] })
  const dataFetching = useIsFetching({ queryKey: ['data', frameName] })
  const statsFetching = useIsFetching({ queryKey: ['stats', frameName] })

  return schemaFetching > 0 || dataFetching > 0 || statsFetching > 0
}
