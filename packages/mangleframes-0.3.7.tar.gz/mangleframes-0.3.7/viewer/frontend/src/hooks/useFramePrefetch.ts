import { useEffect, useRef } from 'react'
import { useQueryClient } from '@tanstack/react-query'
import { useDataStore } from '@/stores/dataStore'
import { api } from '@/lib/api'

export function useFramePrefetch() {
  const queryClient = useQueryClient()
  const openTabs = useDataStore((s) => s.openTabs)
  const seenRef = useRef<Set<string>>(new Set())

  useEffect(() => {
    const currentNames = new Set(openTabs.map((t) => t.name))

    for (const tab of openTabs) {
      if (seenRef.current.has(tab.name)) continue
      seenRef.current.add(tab.name)

      console.log(`[MangleFrames] Prefetching schema, data, stats for "${tab.name}"`)

      queryClient.prefetchQuery({
        queryKey: ['schema', tab.name],
        queryFn: () => api.getSchema(tab.name),
      })
      queryClient.prefetchQuery({
        queryKey: ['data', tab.name, 0, 100],
        queryFn: () => api.getData(tab.name, 0, 100),
      })
      queryClient.prefetchQuery({
        queryKey: ['stats', tab.name],
        queryFn: () => api.getStats(tab.name),
      })
    }

    for (const name of seenRef.current) {
      if (currentNames.has(name)) continue
      seenRef.current.delete(name)

      console.log(`[MangleFrames] Cancelling and removing queries for closed tab "${name}"`)

      queryClient.cancelQueries({ queryKey: ['schema', name] })
      queryClient.cancelQueries({ queryKey: ['data', name] })
      queryClient.cancelQueries({ queryKey: ['stats', name] })
      queryClient.removeQueries({ queryKey: ['schema', name] })
      queryClient.removeQueries({ queryKey: ['data', name] })
      queryClient.removeQueries({ queryKey: ['stats', name] })
    }
  }, [openTabs, queryClient])
}
