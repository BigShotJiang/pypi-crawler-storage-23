import { X, Plus, Settings, RefreshCw, Zap, Loader2 } from 'lucide-react'
import { useDataStore, FrameTab } from '@/stores/dataStore'
import { useUIStore } from '@/stores/uiStore'
import { useFrameLoadingState } from '@/hooks/useFrameLoadingState'

function FrameTabButton({
  tab,
  isActive,
  onSelect,
  onClose,
}: {
  tab: FrameTab
  isActive: boolean
  onSelect: () => void
  onClose: () => void
}) {
  const isLoading = useFrameLoadingState(tab.name)

  return (
    <button
      onClick={onSelect}
      className={`flex items-center gap-2 px-3 py-1 text-xs rounded transition-colors ${
        isActive
          ? 'bg-mf-hover text-mf-text'
          : 'text-mf-muted hover:text-mf-text hover:bg-mf-hover'
      }`}
    >
      {isLoading && <Loader2 size={12} className="animate-spin text-mf-accent" />}
      <span className="truncate max-w-[120px]">{tab.name}</span>
      <X
        size={12}
        className="opacity-50 hover:opacity-100"
        onClick={(e) => {
          e.stopPropagation()
          onClose()
        }}
      />
    </button>
  )
}

export function TopBar() {
  const { openTabs, activeFrame, setActiveFrame, closeFrame } = useDataStore()
  const connected = useUIStore((s) => s.connected)

  return (
    <div className="flex items-center h-10 bg-mf-panel border-b border-mf-border px-2">
      <div className="flex items-center gap-2 mr-4">
        <span className="text-mf-accent font-semibold text-sm">MangleFrames</span>
      </div>

      <div className="flex items-center flex-1 gap-1 overflow-x-auto">
        {openTabs.map((tab) => (
          <FrameTabButton
            key={tab.name}
            tab={tab}
            isActive={activeFrame === tab.name}
            onSelect={() => setActiveFrame(tab.name)}
            onClose={() => closeFrame(tab.name)}
          />
        ))}
        {openTabs.length > 0 && (
          <button className="p-1 text-mf-muted hover:text-mf-text rounded hover:bg-mf-hover">
            <Plus size={14} />
          </button>
        )}
      </div>

      <div className="flex items-center gap-2">
        {connected && (
          <span title="Connected">
            <Zap size={14} className="text-green-500" />
          </span>
        )}
        <button className="p-1 text-mf-muted hover:text-mf-text rounded hover:bg-mf-hover">
          <RefreshCw size={14} />
        </button>
        <button className="p-1 text-mf-muted hover:text-mf-text rounded hover:bg-mf-hover">
          <Settings size={14} />
        </button>
      </div>
    </div>
  )
}
