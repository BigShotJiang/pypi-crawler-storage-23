import pytest

from hippotorch.memory.schedules import linear_mixture_schedule


def test_linear_schedule_bounds_and_monotonicity():
    sched = linear_mixture_schedule(0.1, 0.9, warmup_steps=10)
    values = [sched(step) for step in range(0, 11)]
    assert pytest.approx(values[0], rel=0, abs=1e-6) == 0.1
    assert pytest.approx(values[-1], rel=0, abs=1e-6) == 0.9
    assert all(0.0 <= v <= 1.0 for v in values)
    assert all(x <= y + 1e-6 for x, y in zip(values, values[1:]))
