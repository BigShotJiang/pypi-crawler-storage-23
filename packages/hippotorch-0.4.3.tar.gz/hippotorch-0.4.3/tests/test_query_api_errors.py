import pytest

torch = pytest.importorskip("torch")

from hippotorch.query_api import query, query_batch


def test_query_requires_backend():
    with pytest.raises(ValueError):
        _ = query(torch.zeros(3))


def test_query_batch_accepts_2d_and_3d():
    # 2D path must not raise, but will fail due to missing backend only if we call query()
    # Here we only check dimensionality errors for 1D inputs.
    with pytest.raises(ValueError):
        _ = query_batch(torch.zeros(3))
