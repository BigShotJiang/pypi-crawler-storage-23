from __future__ import annotations

import runpy
from pathlib import Path


def test_measure_once_smoke(tmp_path: Path) -> None:
    mod = runpy.run_path(str(Path("scripts/overhead_analysis.py")))
    measure_once = mod["measure_once"]  # type: ignore[assignment]
    OverheadRow = mod["OverheadRow"]  # type: ignore[assignment]

    row = measure_once(
        size=32,
        device="cpu",
        T=24,
        state_dim=8,
        action_dim=2,
        embed_dim=16,
        batch_size=8,
        sample_reps=5,
        consolidate_steps=1,
    )
    assert isinstance(row, OverheadRow)
    # Times should be non-negative numbers
    assert row.add_ms_ring >= 0.0
    assert row.add_ms_hippo >= 0.0
    assert row.sample_ms_ring >= 0.0
    assert row.sample_ms_hippo >= 0.0
    assert row.consolidate_ms_hippo >= 0.0
    # Ratios are finite when baselines are non-zero; within a reasonable range
    if row.add_ms_ring > 0:
        assert row.add_overhead >= 0.0
    if row.sample_ms_ring > 0:
        assert row.sample_overhead >= 0.0
