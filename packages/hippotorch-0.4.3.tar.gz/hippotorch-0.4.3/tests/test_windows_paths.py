from __future__ import annotations

import platform
from pathlib import Path

import pytest

torch = pytest.importorskip("torch")

from hippotorch.core.episode import Episode
from hippotorch.encoders.dual import DualEncoder
from hippotorch.memory.store import MemoryStore


@pytest.mark.skipif(platform.system() != "Windows", reason="Windows-only path sanity test")
def test_windows_save_load_roundtrip(tmp_path: Path):
    # Use a subdirectory with a space to exercise path handling
    target_dir = tmp_path / "with space"
    target_dir.mkdir(parents=True, exist_ok=True)
    ckpt = target_dir / "mem.pt"

    enc = DualEncoder(input_dim=4, embed_dim=8)
    mem = MemoryStore(embed_dim=8, capacity=4)
    ep = Episode(states=torch.randn(3, 2), actions=torch.zeros(3, 1), rewards=torch.ones(3))
    batch = mem.episodes_to_tensor([ep])
    key = enc.encode_key(batch)
    mem.write(key, [ep], encoder_step=0)

    mem.save(ckpt)
    restored = MemoryStore.load(ckpt)
    assert len(restored) == 1
    assert restored.keys.shape == mem.keys.shape
