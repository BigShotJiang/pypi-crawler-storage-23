from __future__ import annotations

import json
from pathlib import Path


def test_getting_started_notebook_exists_and_is_valid() -> None:
    nb_path = Path("docs/tutorials/getting_started.ipynb")
    assert nb_path.exists(), "Getting Started notebook is missing"
    data = json.loads(nb_path.read_text(encoding="utf-8"))
    assert data.get("nbformat") == 4
    assert isinstance(data.get("cells"), list) and len(data["cells"]) > 0
