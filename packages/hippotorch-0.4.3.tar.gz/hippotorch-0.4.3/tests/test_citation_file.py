from __future__ import annotations

from pathlib import Path


def test_citation_cff_exists_and_has_minimum_fields() -> None:
    root = Path(__file__).resolve().parents[1]
    path = root / "CITATION.cff"
    assert path.exists(), "CITATION.cff should exist at repository root"
    text = path.read_text(encoding="utf-8")
    # Minimal structural checks without requiring a YAML parser.
    assert "cff-version:" in text
    assert "message:" in text
    assert "title:" in text
    assert "authors:" in text
    assert "date-released:" in text
