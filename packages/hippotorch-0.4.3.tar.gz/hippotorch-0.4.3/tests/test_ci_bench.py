from __future__ import annotations

import runpy


def test_compare_against_baseline_logic() -> None:
    mod = runpy.run_path("scripts/ci_bench.py")
    BenchResult = mod["BenchResult"]  # type: ignore[assignment]
    compare = mod["compare_against_baseline"]  # type: ignore[assignment]

    baseline = {
        "write_ms_total": 1000.0,
        "sample_ms_total": 100.0,
        "consolidate_steps_per_sec": 50.0,
    }

    # Within tolerance (exactly at thresholds)
    ok, _ = compare(BenchResult(1200.0, 120.0, 40.0), baseline)
    assert ok is True

    # Regressions beyond tolerance
    ok, _ = compare(BenchResult(1200.1, 120.0, 40.0), baseline)
    assert ok is False  # write slower than +20%
    ok, _ = compare(BenchResult(1200.0, 120.1, 40.0), baseline)
    assert ok is False  # sample slower than +20%
    ok, _ = compare(BenchResult(1200.0, 120.0, 39.9), baseline)
    assert ok is False  # consolidate faster than -20%
