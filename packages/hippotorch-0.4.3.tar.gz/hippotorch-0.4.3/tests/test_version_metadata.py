from __future__ import annotations

import importlib.metadata as metadata

import pytest

import hippotorch


def test_version_matches_metadata() -> None:
    """Ensure package metadata matches exported __version__.

    When installed (including editable installs), the distribution metadata
    should be present and agree with hippotorch.__version__.
    If the distribution metadata is not available, skip the test to avoid
    false negatives in unusual local setups.
    """

    try:
        dist_version = metadata.version("hippotorch")
    except metadata.PackageNotFoundError:  # pragma: no cover - rare local setup
        pytest.skip("hippotorch not installed as a distribution")
    assert hippotorch.__version__ == dist_version
