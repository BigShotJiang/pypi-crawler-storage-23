from __future__ import annotations

import subprocess
import sys


def test_ingestion_benchmark_cli_prints_speedup() -> None:
    # Run the ingestion benchmark with tiny settings and assert output contains 'speedup='
    cmd = [
        sys.executable,
        "-u",
        "scripts/ingestion_benchmark.py",
        "--episodes",
        "8",
        "--T",
        "8",
        "--state-dim",
        "4",
        "--action-dim",
        "2",
        "--embed-dim",
        "8",
        "--device",
        "cpu",
    ]
    proc = subprocess.run(cmd, capture_output=True, text=True, check=True)
    assert "speedup=" in proc.stdout
