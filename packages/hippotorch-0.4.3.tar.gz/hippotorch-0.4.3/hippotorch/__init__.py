from hippotorch.agents.dqn import DQNAgent, DQNConfig
from hippotorch.analysis.attention import visualize_attention_weights
from hippotorch.analysis.projector import MemoryProjector, ProjectionResult
from hippotorch.core.episode import Episode
from hippotorch.encoders.backbone import EpisodeEncoderBackbone
from hippotorch.encoders.dual import DualEncoder
from hippotorch.encoders.visual import VisualEpisodeEncoder
from hippotorch.memory.consolidator import Consolidator, MemoryHealthReport
from hippotorch.memory.intrinsic import IntrinsicConsolidator
from hippotorch.memory.regression import (
    IdentityDualEncoder,
    RegressionResult,
    run_replay_regression,
)
from hippotorch.memory.replay import HippocampalReplayBuffer
from hippotorch.memory.sb3 import SB3ReplayBufferWrapper
from hippotorch.memory.schedules import cosine_mixture_schedule, linear_mixture_schedule
from hippotorch.memory.store import MemoryStore
from hippotorch.memory.wake_sleep import WakeSleepTrainer
from hippotorch.memory.wrapper import HippotorchMemoryWrapper
from hippotorch.query_api import QueryResult, query
from hippotorch.segmenters.base import (
    ChangePointSegmenter,
    EpisodeSegmenter,
    FixedWindowSegmenter,
    GoalAchievementSegmenter,
    TerminalSegmenter,
)
from hippotorch.utils.diagnostics import log_memory_pca, pca_keys, pca_keys_with_rewards
from hippotorch.utils.hub import load_memory_from_hub, push_memory_to_hub

try:
    # Single source of truth for the package version: distribution metadata.
    # Falls back to an "unknown" marker when not installed as a distribution.
    import importlib.metadata as _md  # Python 3.8+

    __version__ = _md.version("hippotorch")
except Exception:  # pragma: no cover - rare local dev without installed dist
    __version__ = "0.0.0+unknown"

__all__ = [
    "Episode",
    "EpisodeSegmenter",
    "FixedWindowSegmenter",
    "GoalAchievementSegmenter",
    "ChangePointSegmenter",
    "TerminalSegmenter",
    "EpisodeEncoderBackbone",
    "DualEncoder",
    "VisualEpisodeEncoder",
    "Consolidator",
    "HippocampalReplayBuffer",
    "SB3ReplayBufferWrapper",
    "MemoryStore",
    "WakeSleepTrainer",
    "MemoryHealthReport",
    "RegressionResult",
    "IdentityDualEncoder",
    "run_replay_regression",
    "linear_mixture_schedule",
    "cosine_mixture_schedule",
    "DQNAgent",
    "DQNConfig",
    "pca_keys",
    "pca_keys_with_rewards",
    "log_memory_pca",
    "MemoryProjector",
    "ProjectionResult",
    "visualize_attention_weights",
    "IntrinsicConsolidator",
    "push_memory_to_hub",
    "load_memory_from_hub",
    "query",
    "QueryResult",
    "HippotorchMemoryWrapper",
]

# __version__ provided above via importlib.metadata when available.
