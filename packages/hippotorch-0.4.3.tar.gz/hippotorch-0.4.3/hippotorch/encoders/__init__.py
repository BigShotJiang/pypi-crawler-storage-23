from .backbone import EpisodeEncoderBackbone
from .dual import DualEncoder
from .protocol import MemoryEncoder
from .registry import get_encoder, list_encoders, register_encoder
from .visual import VisualEpisodeEncoder

# Pre-register built-in encoders for convenience
register_encoder("dual", lambda **kwargs: DualEncoder(**kwargs))
register_encoder("visual", lambda **kwargs: VisualEpisodeEncoder(**kwargs))

__all__ = [
    "EpisodeEncoderBackbone",
    "DualEncoder",
    "VisualEpisodeEncoder",
    "MemoryEncoder",
    "register_encoder",
    "get_encoder",
    "list_encoders",
]
