from __future__ import annotations

from typing import Any, Callable, Optional

import numpy as np
import torch

try:  # pragma: no cover - optional dependency
    import gymnasium as gym
    from gymnasium import spaces
except Exception:  # pragma: no cover - handled lazily
    gym: Any = None  # type: ignore[no-redef]
    spaces: Any = None  # type: ignore[no-redef]

from hippotorch.memory.replay import HippocampalReplayBuffer
from hippotorch.query_api import QueryResult, query, query_batch

if gym is None or spaces is None:  # pragma: no cover - optional dependency

    class HippotorchMemoryWrapper:
        def __init__(self, *_, **__):
            raise ImportError(
                "gymnasium is required for HippotorchMemoryWrapper. "
                "Install hippotorch[envs] to pull in the dependency."
            )

        def reset(self, **kwargs):
            raise RuntimeError("gymnasium is required to use HippotorchMemoryWrapper")

        def step(self, action):
            raise RuntimeError("gymnasium is required to use HippotorchMemoryWrapper")

else:

    class HippotorchMemoryWrapper(gym.Wrapper):  # type: ignore[no-redef]
        """Observation wrapper that injects memory retrieval features."""

        def __init__(
            self,
            env: "gym.Env",
            buffer: HippocampalReplayBuffer,
            *,
            query_state_fn: Optional[Callable[[np.ndarray], np.ndarray]] = None,
            top_k: int = 5,
        ) -> None:
            super().__init__(env)
            self.buffer = buffer
            self.query_state_fn = query_state_fn
            self.top_k = top_k
            self._embed_dim = buffer.memory.embed_dim
            self._memory_dim = self._embed_dim + top_k
            low: np.ndarray = np.full((self._memory_dim,), -np.inf, dtype=np.float32)
            high: np.ndarray = np.full((self._memory_dim,), np.inf, dtype=np.float32)
            self.observation_space = spaces.Dict(
                {
                    "obs": env.observation_space,
                    "memory": spaces.Box(low=low, high=high, dtype=np.float32),
                }
            )
            self._last_memory: np.ndarray = np.zeros(self._memory_dim, dtype=np.float32)
            self._last_query: Optional[QueryResult] = None

        def reset(self, **kwargs):
            obs, info = self.env.reset(**kwargs)
            mem = self._compute_memory(obs)
            return {"obs": obs, "memory": mem}, info

        def step(self, action):
            obs, reward, terminated, truncated, info = self.env.step(action)
            mem = self._compute_memory(obs)
            return {"obs": obs, "memory": mem}, reward, terminated, truncated, info

        def _compute_memory(self, obs) -> np.ndarray:
            if self._is_vector_batch(obs):
                return self._compute_memory_batch(obs)
            result = query(
                observation=obs,
                buffer=self.buffer,
                query_state_fn=self._wrap_query_fn(),
                top_k=self.top_k,
                return_scores=True,
                return_attention=False,
            )
            self._last_query = result
            vec: np.ndarray = self._format_memory_vector(result, row=0)
            self._last_memory = vec
            return vec

        def _compute_memory_batch(self, obs_batch: np.ndarray) -> np.ndarray:
            device = next(self.buffer.encoder.parameters()).device
            builder = self._wrap_query_fn()
            prepared = []
            for row in torch.as_tensor(obs_batch, dtype=torch.float32, device=device):
                state = builder(row) if builder is not None else row
                prepared.append(self._format_query_tensor(state))
            query_tensor = torch.cat(prepared, dim=0)
            result = query_batch(
                query_tensor,
                buffer=self.buffer,
                top_k=self.top_k,
                return_scores=True,
                return_attention=False,
            )
            self._last_query = result
            vectors = [
                self._format_memory_vector(result, row=i) for i in range(query_tensor.size(0))
            ]
            return np.stack(vectors, axis=0)

        def _format_memory_vector(self, result: QueryResult, row: int) -> np.ndarray:
            vec: np.ndarray = np.zeros(self._memory_dim, dtype=np.float32)
            if result.query.shape[0] > row:
                q = result.query[row].view(-1).cpu().numpy().astype(np.float32)
                take = min(q.size, self._embed_dim)
                vec[:take] = q[:take]
            if result.scores is not None and result.scores.shape[0] > row:
                scores = result.scores[row].view(-1).cpu().numpy().astype(np.float32)
                take = min(scores.size, self.top_k)
                vec[self._embed_dim : self._embed_dim + take] = scores[:take]
            return vec

        def _format_query_tensor(self, tensor: torch.Tensor) -> torch.Tensor:
            if tensor.dim() == 1:
                return tensor.view(1, 1, -1)
            if tensor.dim() == 2:
                return tensor.unsqueeze(0)
            return tensor

        def _is_vector_batch(self, obs) -> bool:
            return (
                hasattr(self.env, "num_envs")
                and isinstance(obs, np.ndarray)
                and obs.ndim >= 1
                and obs.shape[0] == getattr(self.env, "num_envs", 1)
            )

        def _wrap_query_fn(self):
            if self.query_state_fn is None:
                return None

            def _builder(obs_tensor: torch.Tensor) -> torch.Tensor:
                arr = np.asarray(obs_tensor.cpu().numpy(), dtype=np.float32)
                fn = self.query_state_fn
                assert fn is not None
                built = fn(arr)
                return torch.as_tensor(built, dtype=torch.float32, device=obs_tensor.device)

            return _builder


__all__ = ["HippotorchMemoryWrapper"]
