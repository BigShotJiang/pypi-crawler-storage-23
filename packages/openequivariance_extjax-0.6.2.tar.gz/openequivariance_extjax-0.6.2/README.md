# OpenEquivariance JAX Extension

The JAX extension module for OpenEquivariance. 